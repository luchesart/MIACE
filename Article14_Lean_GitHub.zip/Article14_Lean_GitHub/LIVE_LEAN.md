# Single-file verification in live.lean

Open [live.lean-lang.org](https://live.lean-lang.org/) and paste the complete text of [`live/Article14_Live.lean`](live/Article14_Live.lean) into the editor. It includes the shared proofs needed by Paper 14 and all 62 Paper 14 modules. Only external mathlib imports remain.

The reproducible environment is **Lean 4.34.0** with mathlib commit **`5ed2965256430c3649e86755f9576b54eca72435`**. Matching the Lean version alone is not enough when mathlib has changed.

On 24 October 2026, the live.lean version selector showed Lean 4.35.0 as its stable release and 4.36.0-rc1 for the latest mathlib option. The pinned 4.34.0 environment was not among the listed choices. This file is prepared for single-file use, but the public service's current versions are not the same as the project's verified environment. A browser run on those versions is not claimed as passed.

The complete export is about 33,000 lines. Browser checking can take substantial time and may encounter service memory or time limits. Use the pinned local project for a reproducible full check:

```sh
lake exe cache get
bash tools/verify_single_file.sh
```

At the end, the file prints the axiom dependencies of all 1,005 named Paper 14 declarations and a completion marker. Confirm that there are **no errors** and no `sorryAx`, and that every listed axiom belongs to `{propext, Classical.choice, Quot.sound}`. The final marker alone is insufficient: Lean can report earlier errors and still process later commands.

The modular source is the authoritative editable version. Regenerate the export with `python3 tools/make_single_file.py` after an intentional source update, and verify again. The generator removes local import commands, lifts external imports to the header, and wraps each source body in a section to preserve local scope. It does not replace proofs by axioms or theorem statements.
