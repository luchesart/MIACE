# Paper 14: constrained 2DOF PIDF tuning

Lean formalization for **Constrained Setpoint-Zero Shaping in Two-Degree-of-Freedom PIDF Control: Modal Suppression, Monotone Tracking, and MIACE with Pure Delay**, by Latchezar P. Tomov.

This repository contains the Paper 14 proof layer, the shared MIACE library reused from Paper 13, a complete single-file export, and an English paper-to-Lean map. The mathematical source is the unchanged formalization v0.4.1. This GitHub package was prepared on 24 October 2026 and the English map follows the current MCSS manuscript numbering.

## Start here

| File or directory | Purpose |
| --- | --- |
| [Article14_Proof_Map_EN.md](Article14_Proof_Map_EN.md) | English map readable directly on GitHub |
| [Article14_Proof_Map_EN.html](Article14_Proof_Map_EN.html) | Detailed offline English map; download and open in a browser |
| [docs/article14/proof-map.en.json](docs/article14/proof-map.en.json) | Machine-readable English map |
| [Article14.lean](Article14.lean), [Article14/](Article14/) | The 62 Paper 14 modules and their aggregate import |
| [MIACE/](MIACE/) | Shared mathematical library; required for the project build |
| [live/Article14_Live.lean](live/Article14_Live.lean) | All local dependencies in one file, followed by the complete Paper 14 axiom audit |
| [LIVE_LEAN.md](LIVE_LEAN.md) | Instructions and version requirements for live.lean |
| [VALIDATION.md](VALIDATION.md) | What was checked, when, and with which environment |

## Reproduce the project check

Install Lean through [the official installation instructions](https://lean-lang.org/install/). From this repository's root, run:

```sh
lake exe cache get
bash tools/verify_article14.sh
```

The script builds `Article14`, runs all 1,005 axiom queries in `AuditArticle14.lean`, and checks the source inventory, English map and generated single file. The Paper 14 layer contains 779 theorem/lemma declarations in 13,441 source lines. The shared MIACE library is included because many Paper 14 proofs depend on it.

The environment is pinned by `lean-toolchain` and `lake-manifest.json`:

- Lean: `leanprover/lean4:v4.34.0`.
- mathlib: `5ed2965256430c3649e86755f9576b54eca72435`.
- All additional dependencies: exact revisions in `lake-manifest.json`.

Keep these pins when reproducing the reported checks. A dependency upgrade is a separate compatibility task.

## Check the complete single file

```sh
bash tools/verify_single_file.sh
```

This export contains every project-local module reachable from `Article14.lean`, not just the main theorem statements. It has no `import Article14` or `import MIACE` dependency. It still requires mathlib. Its source manifest records every included module, original hash, and position in the generated file.

To regenerate it from the unchanged modular source:

```sh
python3 tools/make_single_file.py
```

## Scope of the correspondence

The English map covers all 18 numbered results and identifies 140 distinct directly mapped Lean declarations. It records the hypotheses, reused results and differences between the written and formal proof routes. Lean checks the formal declarations; equivalence between mathematical prose and formal code remains a separate semantic assessment.

The count does not assert that every unnumbered remark, numerical experiment or an abstract Hardy-space theory has been formalized. The formal frequency norm uses the supremum of the physical kernel's transform on the imaginary axis. Internal stability and feasible-set assumptions remain explicit. The whole-weight-box IAE optimum belongs to the specific delayed example in Theorem 18.

The axioms permitted by the audit are `propext`, `Classical.choice` and `Quot.sound`. Admission constructs and custom axioms are rejected by the source check. The shared Paper 13 library also has its own aggregate and audit, `MIACE.lean` and `Audit.lean`; the Paper 14 audit checks the transitive axioms used by its declarations.

To regenerate the HTML and Markdown presentation from the English JSON, run `python3 tools/render_map_en.py`. This only renders the recorded map; it does not refresh manuscript or Lean excerpts after source edits.

## Upload to GitHub

Extract `Article14_Lean_GitHub.zip` and upload the **contents** of the extracted `Article14_Lean_GitHub` folder into the intended repository or branch, using GitHub Desktop or Git for the complete folder. Keep `Article14/`, `MIACE/`, `docs/`, `tools/` and `live/` as directories. Uploading only the ZIP stores an archive but does not make the individual proof files browsable.

For a new repository or dedicated Paper 14 branch, place `lakefile.toml` at the repository root. If Paper 13 already occupies that root, use a dedicated branch or a separate `paper14/` directory to keep the two project configurations separate. With a subdirectory, run the verification commands from that directory.

This package contains proof source, maps and verification evidence. Manuscript PDFs, LaTeX projects, numerical data, build caches and compiler binaries are omitted.
