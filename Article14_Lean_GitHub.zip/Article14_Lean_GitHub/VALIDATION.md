# Verification record — 24 October 2026

Both the modular Paper 14 project and the complete single-file export passed fresh local Lean verification in the pinned environment.

| Check | Result |
| --- | --- |
| `lake build Article14` | Passed; 3,800 build jobs |
| `lake env lean AuditArticle14.lean` | Passed; exactly 1,005 named declarations audited |
| `lake env lean live/Article14_Live.lean` | Passed; complete single file elaborated and all 1,005 axiom queries passed |
| Axiom dependencies, both forms | Only `propext`, `Classical.choice`, `Quot.sound`; no `sorryAx` |
| Original source and configuration | All 268 files byte-for-byte unchanged |
| Paper 14 inventory | 62 modules; 779 theorems/lemmas; 1,005 named declarations; 13,441 source lines |
| Single-file export | 204 local modules; 33,065 lines; 1,613,845 bytes; 75 external mathlib imports |
| English map | 18 numbered results; 140 distinct mapped declarations; 161 mapping occurrences |
| Manuscript alignment | All 18 statement blocks and 17 explicit proof blocks match after comments/whitespace normalization |
| Source/export/map regeneration | Passed; reproducible single file and byte-identical HTML/Markdown rendering |

The fresh compiler runs contain ordinary linter and deprecation warnings. These are recorded in the logs; no compiler error or admitted proof was accepted. The single-file log contains 226 warnings.

## Environment and reproducibility

- Lean: `leanprover/lean4:v4.34.0`, official commit `293d5d0c0c3f3dded4688b3ccd6a33939ac5102b`.
- mathlib: `5ed2965256430c3649e86755f9576b54eca72435`.
- All nine dependency revisions match `lake-manifest.json`; their tracked sources were clean at verification.
- Official dependency cache: 8,908 files retrieved. The project proofs were freshly compiled; the entire compiler and mathlib were not rebuilt from source.
- Official compiler archive SHA-256: `caaa98356098c85dc0fcbbd28e1ec66f39eb6551829972b752ff20e1286b646b`.
- Official shared library SHA-256: `ab523f803d805db2c08eb755f0fa8189345bf6ae9b408664cdf3cf67fa0112d9`.

The managed execution environment required an explicit-sysroot launcher against the official Lean shared library because the stock launcher could not discover its path. A source-path adapter was used only while preparing cache retrieval, and the original dependency file was restored before the proof builds. The proof sources, kernel, elaborator and trust level were unchanged. Ordinary installations should use the official Lean and Lake executables with the pinned configuration.

From the repository root, reproduce the checks with:

```sh
lake exe cache get
bash tools/verify_article14.sh
bash tools/verify_single_file.sh
```

The axiom logs were independently compared with every name in `docs/article14/inventory.json`; missing or extra names and nonstandard axioms cause failure. The source check rejects `sorry`, `admit`, custom `axiom`, `unsafe` and `native_decide` constructs. The English map preserves the canonical declaration lists and exact source locations.

## Evidence

The current run is recorded in `evidence/2026-10-24/`:

- `fresh-build.log`: complete modular build output.
- `fresh-axioms.log`: complete modular axiom audit.
- `monolith.log`: single-file elaboration and axiom audit.
- `audit_summary.json`: exact audit-coverage and axiom checks.
- `dependency_check.json`: pinned dependency revisions and source cleanliness.

The previous submission verification is preserved separately in `evidence/2026-10-23/`. It is historical evidence, not the basis for claiming a new run.

## Scope and online compatibility

These are local checks against the pinned environment. A successful run in the public live.lean editor is **not** claimed. Its version selector, inspected on 24 October 2026, offered newer Lean/mathlib environments and did not list the project's pinned 4.34.0 environment. See [LIVE_LEAN.md](LIVE_LEAN.md).

The check covers Paper 14 and the shared proofs it uses. Paper 13's separate aggregate audit was not rerun. Lean checks the formal declarations; the map's correspondence to mathematical prose is separately reviewed. No additional theorem was introduced during GitHub packaging.

The English HTML map's source links, structure and JavaScript syntax were checked. Its browser layout was not visually tested. The map renderer also corrects an old display issue: Corollary 4 has no separate proof block and must not display the following result's proof as its own.
