#!/usr/bin/env python3
"""Render the English HTML and Markdown maps from the packaged English JSON.

Run from any directory: python3 tools/render_map_en.py
No LaTeX project, original map, browser, or third-party Python package is needed.
The JSON contains the frozen manuscript excerpts and exact Lean source excerpts;
this renderer changes presentation only. It does not refresh those snapshots
from edited source files or verify their semantic correspondence.
"""
from pathlib import Path
import argparse
import html
import json

ROOT = Path(__file__).resolve().parents[1]

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--map', type=Path, default=ROOT/'docs/article14/proof-map.en.json')
    parser.add_argument('--output-dir', type=Path, default=ROOT)
    args = parser.parse_args()
    mapping = json.loads(args.map.read_text())
    if mapping.get('language') != 'en' or len(mapping.get('claims', [])) != 18:
        raise ValueError('Expected the 18-result English Paper 14 map')
    TRUST = mapping['scope_notes']
    ROUTES = mapping['proof_route_differences']
    out = args.output_dir
    out.mkdir(parents=True, exist_ok=True)
    esc = html.escape
    items = []
    for c in mapping['claims']:
        def ul(values): return '<ul>'+''.join('<li>'+esc(v)+'</li>' for v in values)+'</ul>'
        def section(title, body): return '<h3>'+title+'</h3>'+body
        body = '<p>'+esc(c['verified_scope'])+'</p>'
        body += '<p class="muted">Paper label: <code>'+esc(c['label'])+'</code><br>Paper source: <code>'+esc(c['source'])+'</code></p>'
        body += section('Hypotheses recorded in the map',ul(c['hypotheses']))
        body += section('Mathematical obligations',ul(c['obligations']))
        if c['dependencies']:
            body += section('Dependencies', '<p>'+', '.join('<a href="#claim-'+str(next(k['number'] for k in mapping['claims'] if k['label']==d))+'">'+esc(d)+'</a>' for d in c['dependencies'])+'</p>')
        if c.get('reuse'): body += section('Reuse from Paper 13',ul(c['reuse']))
        if str(c['number']) in ROUTES: body += section('Lean proof route','<p>'+esc(ROUTES[str(c['number'])])+'</p>')
        body += section('Scope and completion criterion','<p>'+esc(c['completion_rule'])+'</p>')
        body += '<div class="columns"><section><h3>Current paper: statement and proof</h3><pre>'+esc(c['paper_statement_latex']+'\n'+c['paper_proof_latex'])+'</pre>'
        if c['paper_proof_note']: body += '<p>'+esc(c['paper_proof_note'])+'</p>'
        body += '</section><section><h3>Lean: exact declaration names and source</h3>'
        for d in c['lean_declarations']:
            body += '<details class="proof"><summary><code>'+esc(d['name'])+'</code></summary><p class="muted"><a href="'+esc(d['source_link'])+'">'+esc(d['file'])+' · line '+str(d['line'])+'</a></p><pre>'+esc(d['code'])+'</pre></details>'
        body += '</section></div>'
        items.append('<details class="claim" id="claim-'+str(c['number'])+'"><summary><span class="num">'+str(c['number'])+'</span><span>'+c['kind'].title()+' '+str(c['number'])+': '+esc(c['title'])+'</span><span class="status">Complete mapping</span></summary><div class="body">'+body+'</div></details>')
    style = '''
    :root{color-scheme:light;--ink:#172c3c;--muted:#526777;--line:#cbd8df;--accent:#116a70}*{box-sizing:border-box}body{margin:0;background:#f5f8fa;color:var(--ink);font:16px/1.6 system-ui,sans-serif}header,main,footer{max-width:1380px;margin:auto;padding:24px}header{padding-top:38px}h1{font-size:clamp(26px,4vw,42px);line-height:1.2}h2{font-size:24px}h3{font-size:16px}p{max-width:1100px}.muted{color:var(--muted)}.notice{border-left:4px solid var(--accent);background:#eaf3f4;padding:14px 18px}.stats{display:flex;gap:12px;flex-wrap:wrap}.stats span{background:white;border:1px solid var(--line);border-radius:8px;padding:10px 14px}code{font-family:ui-monospace,monospace;font-size:12px;overflow-wrap:anywhere}pre{font:12px/1.6 ui-monospace,monospace;white-space:pre-wrap;overflow-wrap:anywhere;background:#eef2f5;padding:14px;border-radius:8px;max-height:650px;overflow:auto}li{margin:5px 0}.controls{display:flex;gap:10px;flex-wrap:wrap;position:sticky;top:0;background:#f5f8faee;padding:12px 0;z-index:1}input{flex:1;min-width:220px}input,button{font:inherit;padding:9px 12px;border:1px solid var(--line);border-radius:6px;background:white}button{cursor:pointer}.claim{background:white;border:1px solid var(--line);border-radius:9px;margin:12px 0}.claim>summary{display:flex;gap:12px;align-items:start;padding:15px;cursor:pointer;font-weight:600}.num{background:var(--accent);color:white;border-radius:5px;padding:0 9px;min-width:35px;text-align:center}.status{margin-left:auto;font-size:12px;color:#126a42;white-space:nowrap}.body{padding:0 22px 20px}.body h3{border-top:1px solid #edf1f3;padding-top:15px}.columns{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:20px}.proof{margin:10px 0}.proof summary{cursor:pointer;color:var(--accent)}a{color:var(--accent)}[hidden]{display:none!important}@media(max-width:850px){.columns{grid-template-columns:1fr}.status{display:none}header,main,footer{padding:16px}.claim>summary{padding:12px}.body{padding:0 14px 14px}}@media print{.controls{display:none}body{background:white}.columns{grid-template-columns:1fr}pre{max-height:none}.claim{break-inside:avoid}}
    '''
    intro = '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Paper 14: English manuscript-to-Lean map</title><style>'+style+'</style></head><body><header><p class="muted">PAPER 14 · ENGLISH FORMAL PROOF MAP · 24 OCTOBER 2026</p><h1>Constrained 2DOF PIDF: manuscript-to-Lean map</h1><p>'+esc(mapping['article'])+'</p><div class="stats"><span><strong>18</strong> numbered results</span><span><strong>140</strong> directly mapped declarations</span><span><strong>62</strong> Article14 modules</span><span><strong>779</strong> theorems</span></div><p class="notice">'+esc(TRUST[0])+'</p></header><main><h2>How to use the map</h2><p>Search a number, title, hypothesis, or Lean name. Open a result to compare the current paper statement and proof with the exact Lean declarations. The HTML works offline. Relative source links work when this file is at the Lean project root. On GitHub, use <code>Article14_Proof_Map_EN.md</code> for a rendered text view; download this HTML file to use the interactive view.</p><p>The formalization version is 0.4.1. The excerpted paper is the MCSS manuscript dated 24 October 2026. All 18 statements and 17 explicit proof blocks match the supplied formalization paper sources after comments and whitespace are removed. Corollary 4 has no separate proof block and is shown without borrowing the next result\'s proof.</p><h2>Scope and assumptions</h2><ul>'+''.join('<li>'+esc(t)+'</li>' for t in TRUST[1:])+'</ul><h2>Reproduction</h2><p>The project pins Lean 4.34.0 and its mathlib dependency in <code>lean-toolchain</code> and <code>lake-manifest.json</code>. Follow the package README and validation report for the exact commands and checks performed for this release. At minimum, with the pinned toolchain installed:</p><pre>lake exe cache get\nlake build Article14\nlake env lean AuditArticle14.lean</pre><p>This map is a correspondence aid, not a new build log. No browser verification is inferred from generating or reading it.</p><div class="controls"><input id="query" type="search" aria-label="Search the proof map" placeholder="Search a result, hypothesis, or Lean name"><button id="expand">Expand all</button><button id="collapse">Collapse all</button></div><p id="count" class="muted">Showing 18 of 18 results.</p>'
    script = '''<script>const claims=[...document.querySelectorAll('.claim')],q=document.getElementById('query');q.addEventListener('input',()=>{const term=q.value.trim().toLowerCase();let n=0;claims.forEach(c=>{c.hidden=!c.textContent.toLowerCase().includes(term);if(!c.hidden)n++});document.getElementById('count').textContent='Showing '+n+' of 18 results.'});document.getElementById('expand').addEventListener('click',()=>claims.filter(c=>!c.hidden).forEach(c=>c.open=true));document.getElementById('collapse').addEventListener('click',()=>claims.forEach(c=>c.open=false));</script>'''
    (out/'Article14_Proof_Map_EN.html').write_text(intro+'\n'.join(items)+'</main><footer>English navigation and summaries; exact Lean declaration names and unmodified source excerpts. No new formal result is introduced by this map.</footer>'+script+'</body></html>\n')

    md = ['# Paper 14: manuscript-to-Lean map', '', mapping['article'], '', '**English map dated 24 October 2026 · Formalization v0.4.1**', '', '18 numbered results · 140 distinct directly mapped declarations (161 occurrences) · 62 Article14 modules · 779 theorems · 1005 named declarations.', '', TRUST[0], '', 'For statement/proof text beside Lean source, download and open [Article14_Proof_Map_EN.html](Article14_Proof_Map_EN.html). The machine-readable version is [proof-map.en.json](docs/article14/proof-map.en.json).', '', '## Reading map', '', '| Result | Title | Paper label | Mapped declarations |','|---|---|---|---|']
    for c in mapping['claims']:
        md.append('| '+c['kind'].title()+' '+str(c['number'])+' | ['+c['title']+'](#result-'+str(c['number'])+') | `'+c['label']+'` | '+str(len(c['lean']))+' |')
    md += ['', '## Scope and assumptions', '']
    md += ['- '+t for t in TRUST[1:]]
    md += ['', 'The 18 statement blocks and 17 explicit proof blocks in the current MCSS manuscript match the supplied v0.4.1 paper sources after comments and whitespace are removed. Corollary 4 has no separate proof block. Proof-route differences below explain how the formal arguments implement the mathematical reasoning.', '', '## Verification', '', 'Use the pinned Lean/mathlib versions and follow the package README and validation report. Basic commands from the project directory:', '', '```bash','lake exe cache get','lake build Article14','lake env lean AuditArticle14.lean','```', '', 'This map adds no Lean declaration and is not a new compilation record. A local build and a live.lean browser run are separate checks.', '']
    for c in mapping['claims']:
        md += ['<a id="result-'+str(c['number'])+'"></a>', '', '## '+c['kind'].title()+' '+str(c['number'])+': '+c['title'], '', '**Paper label:** `'+c['label']+'`  ', '**Paper source:** `'+c['source']+'`  ', '**Mapping status:** Complete, with the hypotheses below.', '', c['verified_scope'], '', '### Hypotheses', '']
        md += ['- '+x for x in c['hypotheses']]
        md += ['', '### Mathematical obligations', '']
        md += ['- '+x for x in c['obligations']]
        if c['dependencies']:
            md += ['', '**Dependencies:** '+', '.join('['+d+'](#result-'+str(next(x['number'] for x in mapping['claims'] if x['label']==d))+')' for d in c['dependencies'])+'.']
        if c['reuse']:
            md += ['', '**Reuse from Paper 13:** '+', '.join('`'+s+'`' for s in c['reuse'])+'.']
        if str(c['number']) in ROUTES:
            md += ['', '**Proof route:** '+ROUTES[str(c['number'])]]
        md += ['', '**Completion criterion:** '+c['completion_rule'], '', '### Exact Lean declarations', '']
        for d in c['lean_declarations']:
            md.append('- [`'+d['name']+'`]('+d['source_link']+') — `'+d['file']+'`, line '+str(d['line'])+'.')
        if c['paper_proof_note']: md += ['', c['paper_proof_note']]
        md += ['']
    (out/'Article14_Proof_Map_EN.md').write_text('\n'.join(md))

    print('Rendered Article14_Proof_Map_EN.html and Article14_Proof_Map_EN.md')

if __name__ == '__main__':
    main()
