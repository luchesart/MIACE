#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p evidence/current
lake build Article14 2>&1 | tee evidence/current/build.log
lake env lean AuditArticle14.lean 2>&1 | tee evidence/current/axioms.log
python3 tools/check_package.py --axioms evidence/current/axioms.log
