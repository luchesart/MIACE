#!/usr/bin/env python3
"""Check source identity, mapping, generated file and optional fresh axiom logs."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'tools/article14'))
from inventory import collect
from make_single_file import build, mask_comments

def audit(path, names):
    text = path.read_text()
    found = {name:set(x.strip() for x in axs.split(',') if x.strip())
        for name,axs in re.findall(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]", text)}
    for name in re.findall(r"'([^']+)' does not depend on any axioms", text):
        found[name] = set()
    assert set(found) == names, f'Audit coverage mismatch in {path}'
    assert not re.search(r'(?m)^(?:[^\n]*?:\d+:\d+: )?error:|sorryAx', text), f'Lean error in {path}'
    allowed = {'propext','Classical.choice','Quot.sound'}
    assert all(ax <= allowed for ax in found.values()), f'Unexpected axiom in {path}'
    print(f'PASS: {len(found)} declarations; only standard axioms in {path.name}')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--axioms', type=Path)
    parser.add_argument('--single-file-log', type=Path)
    args = parser.parse_args()
    inv = json.loads((ROOT/'docs/article14/inventory.json').read_text())
    assert collect() == inv, 'Article14 declaration inventory mismatch'
    names = {d['name'] for d in inv['declarations']}
    hashes = json.loads((ROOT/'docs/article14/source-manifest.json').read_text())
    for file, expected in hashes.items():
        assert hashlib.sha256((ROOT/file).read_bytes()).hexdigest() == expected, 'Source changed: '+file
        if file.endswith('.lean'):
            assert not re.search(r'\b(sorry|admit|axiom|unsafe|native_decide)\b', mask_comments((ROOT/file).read_text())), 'Forbidden construct: '+file
    mapping = json.loads((ROOT/'docs/article14/proof-map.en.json').read_text())
    assert [c['number'] for c in mapping['claims']] == list(range(1,19)), 'Map claim coverage mismatch'
    mapped = {n for c in mapping['claims'] for n in c['lean']}
    assert mapped <= names, 'Unknown mapped declarations'
    assert len(mapped) == 140, 'Mapped declaration count changed'
    original = json.loads((ROOT/'docs/article14/proof-map.json').read_text())
    assert [c['lean'] for c in mapping['claims']] == [c['lean'] for c in original['claims']], 'English mapping changes formal references'
    data, manifest = build()
    assert (ROOT/'live/Article14_Live.lean').read_bytes() == data, 'Single-file source differs from generation'
    assert json.loads((ROOT/'live/single-file-manifest.json').read_text()) == manifest
    assert manifest['article14_module_count'] == 62
    assert manifest['axiom_query_count'] == len(names)
    assert not re.search(r'^import (Article14|MIACE)(?:\.|$)', data.decode(), re.M)
    print(f"PASS: {len(hashes)} unchanged source/configuration files; 18 mapped claims; {len(mapped)} mapped declarations; reproducible single file")
    if args.axioms: audit(args.axioms, names)
    if args.single_file_log:
        audit(args.single_file_log, names)
        assert 'Article14 single-file elaboration reached the end.' in args.single_file_log.read_text(), 'Missing completion marker'

if __name__ == '__main__': main()
