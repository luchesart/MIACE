#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p evidence/current
python3 tools/make_single_file.py --check
lake env lean live/Article14_Live.lean 2>&1 | tee evidence/current/single-file.log
python3 tools/check_package.py --single-file-log evidence/current/single-file.log
