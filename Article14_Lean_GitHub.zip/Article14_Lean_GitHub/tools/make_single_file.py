#!/usr/bin/env python3
"""Flatten Article14's local import closure, retaining exact proof bodies.

No third-party source is copied. External mathlib imports are lifted to the
header. Each source body is enclosed in a section to isolate file-local options,
open declarations and variables. The manifest records source and output hashes.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[1]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def mask_comments(text):
    """Mask nested Lean comments, preserving positions, strings and line breaks."""
    out = list(text)
    i = depth = 0
    in_string = False
    while i < len(text):
        if depth:
            if text.startswith('/-', i):
                out[i:i+2] = '  '; depth += 1; i += 2
            elif text.startswith('-/', i):
                out[i:i+2] = '  '; depth -= 1; i += 2
            else:
                if text[i] != '\n': out[i] = ' '
                i += 1
        elif in_string:
            if text[i] == '\\': i += 2
            elif text[i] == '"': in_string = False; i += 1
            else: i += 1
        elif text.startswith('/-', i):
            out[i:i+2] = '  '; depth = 1; i += 2
        elif text.startswith('--', i):
            j = text.find('\n', i)
            if j < 0: j = len(text)
            out[i:j] = ' ' * (j-i); i = j
        elif text[i] == '"': in_string = True; i += 1
        else: i += 1
    if depth: raise ValueError('Unclosed block comment')
    return ''.join(out)

def source(module):
    return ROOT.joinpath(*module.split('.')).with_suffix('.lean')

def imports(text):
    return list(re.finditer(r'^\s*import[ \t]+([^\n]+)', mask_comments(text), re.M))

def build():
    visited, active, ordered, external = set(), set(), [], []
    def visit(module):
        p = source(module)
        if not p.exists():
            if not module.startswith(('Mathlib.', 'Batteries.', 'Lean.', 'Std.')):
                raise ValueError('Missing local or unexpected external import: '+module)
            if module not in external: external.append(module)
            return
        if module in active: raise ValueError('Import cycle: '+module)
        if module in visited: return
        active.add(module)
        text = p.read_text()
        for m in imports(text):
            for name in m.group(1).split(): visit(name)
        active.remove(module); visited.add(module); ordered.append(module)
    visit('Article14')
    # Private declarations would require name isolation beyond an outer section.
    for module in ordered:
        if re.search(r'^\s*private\s', mask_comments(source(module).read_text()), re.M):
            raise ValueError('Private declaration requires explicit review: '+module)
    header = '''/-
PAPER 14 -- COMPLETE SINGLE-FILE FORMALIZATION
Generated from the unchanged v0.4.1 source; do not edit this generated file.
Pinned Lean: 4.34.0
Pinned mathlib: 5ed2965256430c3649e86755f9576b54eca72435

All project-local dependencies are included below. Only mathlib imports remain.
The full Article14 axiom audit is appended after the proofs.
For live.lean, paste the complete file into an environment with compatible
Lean and mathlib versions. The public service may use different versions;
the reproducible reference check is the pinned local Lake project.
See LIVE_LEAN.md and VALIDATION.md for the actual verification status.
-/
'''
    pieces = [header, '\n'.join('import '+n for n in external)+'\n\n']
    modules = []
    for index, module in enumerate(ordered):
        p = source(module); text = p.read_text()
        spans = imports(text)
        for m in reversed(spans):
            # Keep line counts stable inside each source body.
            text = text[:m.start()] + re.sub(r'[^\n]', ' ', text[m.start():m.end()]) + text[m.end():]
        start = sum(x.count('\n') for x in pieces)+1
        piece = '\n/- BEGIN SOURCE: '+str(p.relative_to(ROOT))+' -/\nsection\n'+text.rstrip()+'\nend\n/- END SOURCE: '+module+' -/\n'
        pieces.append(piece)
        modules.append({'module':module,'source':str(p.relative_to(ROOT)), 'source_sha256':sha(p.read_bytes()), 'start_line':start, 'end_line':start+piece.count('\n')-1})
    audit = (ROOT/'AuditArticle14.lean').read_text()
    for m in reversed(imports(audit)):
        audit = audit[:m.start()] + re.sub(r'[^\n]', ' ', audit[m.start():m.end()]) + audit[m.end():]
    pieces += ['\n/- COMPLETE ARTICLE14 AXIOM AUDIT -/\n', audit, '\n#check Article14.ExactDelay.physical_global_miace\n#eval "Article14 single-file elaboration reached the end."\n']
    result = ''.join(pieces).encode()
    manifest = {'generator':'tools/make_single_file.py', 'entrypoint':'Article14', 'lean_toolchain':(ROOT/'lean-toolchain').read_text().strip(),'mathlib_revision':'5ed2965256430c3649e86755f9576b54eca72435','local_module_count':len(modules),'article14_module_count':sum(m['module'].startswith('Article14.') for m in modules),'external_imports':external,'modules':modules,'single_file_sha256':sha(result),'single_file_lines':len(result.splitlines()),'axiom_query_count':audit.count('#print axioms ')}
    return result, manifest

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='Check reproducibility without rewriting files')
    args = parser.parse_args()
    data, manifest = build()
    target = ROOT/'live/Article14_Live.lean'
    manifest_path = ROOT/'live/single-file-manifest.json'
    meta = (json.dumps(manifest, ensure_ascii=False, indent=2)+'\n').encode()
    if args.check:
        assert target.read_bytes() == data, 'Generated Lean file differs'
        assert manifest_path.read_bytes() == meta, 'Generated manifest differs'
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data); manifest_path.write_bytes(meta)
    print(f"PASS: {manifest['local_module_count']} local modules, {manifest['single_file_lines']} lines, {manifest['axiom_query_count']} axiom queries")

if __name__ == '__main__': main()
