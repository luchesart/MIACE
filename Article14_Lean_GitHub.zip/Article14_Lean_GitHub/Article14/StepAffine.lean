import Article14.PhysicalStep
import MIACE.PIExplicit

/-!+# Affine families of actual delayed unit-step trajectories

The plant and feedback parameters remain fixed.  Three actual zero-history
step trajectories at weights `(0,0)`, `(1,0)`, and `(0,1)` generate the response
at every pair of reference weights.  Affinity is proved from the physical
differential equations, including the initial transport interval.
-/
namespace Article14
open MeasureTheory Filter Set MIACE
open scoped Topology

/-- Affine interpolation through three basis trajectories. -/
noncomputable def stepAffineFamily {E : Type*} [AddCommGroup E] [Module ℝ E]
    (q00 q10 q01 : ℝ → E) (b c t : ℝ) : E :=
  q00 t + b • (q10 t - q00 t) + c • (q01 t - q00 t)

theorem stepAffineFamily_basis {E : Type*} [AddCommGroup E] [Module ℝ E]
    (q00 q10 q01 : ℝ → E) :
    stepAffineFamily q00 q10 q01 0 0 = q00 ∧
    stepAffineFamily q00 q10 q01 1 0 = q10 ∧
    stepAffineFamily q00 q10 q01 0 1 = q01 := by
  simp [stepAffineFamily, funext_iff]

theorem stepAffineFamily_continuousOn {E : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    {q00 q10 q01 : ℝ → E} {s : Set ℝ}
    (h00 : ContinuousOn q00 s) (h10 : ContinuousOn q10 s)
    (h01 : ContinuousOn q01 s) (b c : ℝ) :
    ContinuousOn (stepAffineFamily q00 q10 q01 b c) s := by
  exact (h00.add ((h10.sub h00).const_smul b)).add
    ((h01.sub h00).const_smul c)

theorem stepAffineFamily_hasDerivAt {E : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    {q00 q10 q01 : ℝ → E} {v00 v10 v01 : E} {t : ℝ}
    (h00 : HasDerivAt q00 v00 t) (h10 : HasDerivAt q10 v10 t)
    (h01 : HasDerivAt q01 v01 t) (b c : ℝ) :
    HasDerivAt (stepAffineFamily q00 q10 q01 b c)
      (v00 + b • (v10-v00) + c • (v01-v00)) t := by
  exact (h00.add ((h10.sub h00).const_smul b)).add
    ((h01.sub h00).const_smul c)

theorem stepAffineFamily_ac {q00 q10 q01 : ℝ → ℝ} {a d : ℝ}
    (h00 : AbsolutelyContinuousOnInterval q00 a d)
    (h10 : AbsolutelyContinuousOnInterval q10 a d)
    (h01 : AbsolutelyContinuousOnInterval q01 a d) (b c : ℝ) :
    AbsolutelyContinuousOnInterval (stepAffineFamily q00 q10 q01 b c) a d := by
  exact (h00.add ((h10.sub h00).const_smul b)).add
    ((h01.sub h00).const_smul c)

theorem stepAffineFamily_deriv_ae {q00 q10 q01 : ℝ → ℝ}
    (h00 : ∀ T, 0 ≤ T → AbsolutelyContinuousOnInterval q00 0 T)
    (h10 : ∀ T, 0 ≤ T → AbsolutelyContinuousOnInterval q10 0 T)
    (h01 : ∀ T, 0 ≤ T → AbsolutelyContinuousOnInterval q01 0 T) (b c : ℝ) :
    ∀ᵐ t : ℝ, 0 < t → deriv (stepAffineFamily q00 q10 q01 b c) t =
      deriv q00 t + b*(deriv q10 t-deriv q00 t) +
        c*(deriv q01 t-deriv q00 t) := by
  filter_upwards [local_ac_ae_differentiable h00, local_ac_ae_differentiable h10,
    local_ac_ae_differentiable h01] with t h0 h1 h2 ht
  exact (stepAffineFamily_hasDerivAt (h0 ht).hasDerivAt (h1 ht).hasDerivAt
    (h2 ht).hasDerivAt b c).deriv

variable {n : Type*} [Fintype n]

theorem stepAffineFamily_output (C : n → ℝ)
    (q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ) (b c t : ℝ) :
    finitePlantOutput C (stepAffineFamily q00 q10 q01 b c t).1 =
      finitePlantOutput C (q00 t).1 + b*(finitePlantOutput C (q10 t).1-
        finitePlantOutput C (q00 t).1) + c*(finitePlantOutput C (q01 t).1-
        finitePlantOutput C (q00 t).1) := by
  rw [← finiteOutputMap_eq C]
  simp only [stepAffineFamily, Prod.fst_add, Prod.smul_fst, Prod.fst_sub,
    map_add, map_smul, map_sub, smul_eq_mul]

theorem stepAffineFamily_command (C : n → ℝ) (Kp Ti Td Tf b c : ℝ)
    (q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ) (t : ℝ) :
    stepCommand C Kp Ti Td Tf b c (stepAffineFamily q00 q10 q01 b c) t =
      stepCommand C Kp Ti Td Tf 0 0 q00 t +
        b*(stepCommand C Kp Ti Td Tf 1 0 q10 t-
          stepCommand C Kp Ti Td Tf 0 0 q00 t) +
        c*(stepCommand C Kp Ti Td Tf 0 1 q01 t-
          stepCommand C Kp Ti Td Tf 0 0 q00 t) := by
  simp only [stepCommand, sharedControllerRhs, stepAffineFamily_output]
  simp only [stepAffineFamily, Prod.snd_add, Prod.smul_snd, Prod.snd_sub,
    Prod.fst_add, Prod.smul_fst, Prod.fst_sub, smul_eq_mul]
  ring

theorem stepAffineFamily_normalized_command (C : n → ℝ) (Kp Ti Td Tf k b c : ℝ)
    (q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ) (t : ℝ) :
    k*stepCommand C Kp Ti Td Tf b c (stepAffineFamily q00 q10 q01 b c) t-1 =
      (k*stepCommand C Kp Ti Td Tf 0 0 q00 t-1) +
        b*((k*stepCommand C Kp Ti Td Tf 1 0 q10 t-1)-
          (k*stepCommand C Kp Ti Td Tf 0 0 q00 t-1)) +
        c*((k*stepCommand C Kp Ti Td Tf 0 1 q01 t-1)-
          (k*stepCommand C Kp Ti Td Tf 0 0 q00 t-1)) := by
  rw [stepAffineFamily_command]
  ring

theorem stepAffineFamily_error (C : n → ℝ)
    (q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ) (b c t : ℝ) :
    1-finitePlantOutput C (stepAffineFamily q00 q10 q01 b c t).1 =
      (1-finitePlantOutput C (q00 t).1) +
        b*((1-finitePlantOutput C (q10 t).1)-(1-finitePlantOutput C (q00 t).1)) +
        c*((1-finitePlantOutput C (q01 t).1)-(1-finitePlantOutput C (q00 t).1)) := by
  rw [stepAffineFamily_output]
  ring

/-- All three physical controller outputs are affine simultaneously: the
integrator derivative, the filter derivative, and the applied command. -/
theorem stepAffineFamily_controller (C : n → ℝ) (Kp Ti Td Tf b c : ℝ)
    (q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ) (t : ℝ) :
    sharedControllerRhs Kp Ti Td Tf b c 1
      (finitePlantOutput C (stepAffineFamily q00 q10 q01 b c t).1)
      (stepAffineFamily q00 q10 q01 b c t).2.1
      (stepAffineFamily q00 q10 q01 b c t).2.2 =
    sharedControllerRhs Kp Ti Td Tf 0 0 1
      (finitePlantOutput C (q00 t).1) (q00 t).2.1 (q00 t).2.2 +
    b • (sharedControllerRhs Kp Ti Td Tf 1 0 1
      (finitePlantOutput C (q10 t).1) (q10 t).2.1 (q10 t).2.2 -
      sharedControllerRhs Kp Ti Td Tf 0 0 1
      (finitePlantOutput C (q00 t).1) (q00 t).2.1 (q00 t).2.2) +
    c • (sharedControllerRhs Kp Ti Td Tf 0 1 1
      (finitePlantOutput C (q01 t).1) (q01 t).2.1 (q01 t).2.2 -
      sharedControllerRhs Kp Ti Td Tf 0 0 1
      (finitePlantOutput C (q00 t).1) (q00 t).2.1 (q00 t).2.2) := by
  simp only [sharedControllerRhs, stepAffineFamily_output]
  ext <;> simp only [stepAffineFamily, Prod.snd_add, Prod.smul_snd, Prod.snd_sub,
    Prod.fst_add, Prod.smul_fst, Prod.fst_sub, smul_eq_mul] <;> ring

theorem stepAffineFamily_stateField (A : Matrix n n ℝ)
    (q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ) (b c t : ℝ) (j : n) :
    (∑ l, A j l*(stepAffineFamily q00 q10 q01 b c t).1 l) =
      (∑ l, A j l*(q00 t).1 l) + b*((∑ l, A j l*(q10 t).1 l)-
        (∑ l, A j l*(q00 t).1 l)) + c*((∑ l, A j l*(q01 t).1 l)-
        (∑ l, A j l*(q00 t).1 l)) :=
  stepAffineFamily_output (A j) q00 q10 q01 b c t

/-- The post-delay physical vector field obeys the same affine identity. -/
theorem stepAffineFamily_retardedRhs (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf L b c : ℝ) (q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ) (t : ℝ) :
    retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L b c (fun _ => 1)
      (fun θ => stepAffineFamily q00 q10 q01 b c (t+θ)) =
    retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L 0 0 (fun _ => 1) (fun θ => q00 (t+θ)) +
    b • (retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L 1 0 (fun _ => 1) (fun θ => q10 (t+θ)) -
      retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L 0 0 (fun _ => 1) (fun θ => q00 (t+θ))) +
    c • (retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L 0 1 (fun _ => 1) (fun θ => q01 (t+θ)) -
      retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L 0 0 (fun _ => 1) (fun θ => q00 (t+θ))) := by
  simp only [retardedSharedRhs, add_zero, ← sub_eq_add_neg]
  rw [stepAffineFamily_controller, stepAffineFamily_controller]
  apply Prod.ext
  · ext j
    simp only [finitePlantDynamics, stepAffineFamily_stateField,
      Prod.snd_add, Prod.smul_snd, Prod.snd_sub, Prod.fst_add, Prod.smul_fst,
      Prod.fst_sub, Pi.add_apply, Pi.smul_apply, Pi.sub_apply, smul_eq_mul]
    ring
  · rfl

/-- Affinity of the physical step response follows from the equations of
three actual responses, with no transfer-function or affinity premise. -/
theorem stepLoopDynamics_affine_family
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf L : ℝ}
    {q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ}
    (h00 : StepLoopDynamics A B C Kp Ti Td Tf L 0 0 q00)
    (h10 : StepLoopDynamics A B C Kp Ti Td Tf L 1 0 q10)
    (h01 : StepLoopDynamics A B C Kp Ti Td Tf L 0 1 q01) (b c : ℝ) :
    StepLoopDynamics A B C Kp Ti Td Tf L b c
      (stepAffineFamily q00 q10 q01 b c) := by
  constructor
  · exact stepAffineFamily_continuousOn h00.continuous h10.continuous h01.continuous b c
  · intro j T hT
    exact stepAffineFamily_ac (h00.state_ac j T hT) (h10.state_ac j T hT)
      (h01.state_ac j T hT) b c
  · intro T hT
    exact stepAffineFamily_ac (h00.integral_ac T hT) (h10.integral_ac T hT)
      (h01.integral_ac T hT) b c
  · intro T hT
    exact stepAffineFamily_ac (h00.filter_ac T hT) (h10.filter_ac T hT)
      (h01.filter_ac T hT) b c
  · simp [stepAffineFamily, h00.initial, h10.initial, h01.initial]
  · intro j
    have hd := stepAffineFamily_deriv_ae (h00.state_ac j) (h10.state_ac j)
      (h01.state_ac j) b c
    filter_upwards [hd, h00.state_ode j, h10.state_ode j, h01.state_ode j]
      with t hder ho0 ho1 ho2 ht
    change deriv (stepAffineFamily (fun s => (q00 s).1 j)
      (fun s => (q10 s).1 j) (fun s => (q01 s).1 j) b c) t = _
    rw [hder ht, ho0 ht, ho1 ht, ho2 ht, stepAffineFamily_stateField]
    by_cases hwait : t ≤ L
    · simp only [hwait, ite_true, mul_zero, add_zero]
    · simp only [hwait, ite_false, stepAffineFamily_command]
      ring
  · have hd := stepAffineFamily_deriv_ae h00.integral_ac h10.integral_ac h01.integral_ac b c
    filter_upwards [hd, h00.integral_ode, h10.integral_ode, h01.integral_ode]
      with t hder ho0 ho1 ho2 ht
    change deriv (stepAffineFamily (fun s => (q00 s).2.1)
      (fun s => (q10 s).2.1) (fun s => (q01 s).2.1) b c) t = _
    rw [hder ht, ho0 ht, ho1 ht, ho2 ht, stepAffineFamily_controller]
    rfl
  · have hd := stepAffineFamily_deriv_ae h00.filter_ac h10.filter_ac h01.filter_ac b c
    filter_upwards [hd, h00.filter_ode, h10.filter_ode, h01.filter_ode]
      with t hder ho0 ho1 ho2 ht
    change deriv (stepAffineFamily (fun s => (q00 s).2.2)
      (fun s => (q10 s).2.2) (fun s => (q01 s).2.2) b c) t = _
    rw [hder ht, ho0 ht, ho1 ht, ho2 ht, stepAffineFamily_controller]
    rfl
  · intro t ht
    rw [stepAffineFamily_retardedRhs]
    exact stepAffineFamily_hasDerivAt (h00.after_delay t ht)
      (h10.after_delay t ht) (h01.after_delay t ht) b c

end Article14
