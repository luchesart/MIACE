import Article14.ExactDelayRationalUniqueness

/-! All-history classical exponential stability is now a consequence of the
inherited rational resolvent theorem and unrestricted differential-equation
uniqueness, with its original uniform constants. -/
namespace Article14.ExactDelay
open Set MeasureTheory Filter MIACE
open scoped Topology

/-- Every continuous complete history has exactly one classical future, and
one pair of exponential constants controls all those histories. -/
theorem rational_full_history_stability :
    ∃ η D : ℝ, 0 < η ∧ 0 ≤ D ∧
      ∀ h : ℝ → LoopState, ContinuousOn h (Icc (-(1/4 : ℝ)) 0) →
      ∃ z : ℝ → LoopState, IsRationalStateSolution h z ∧
        (∀ other, IsRationalStateSolution h other → EqOn other z (Ici (-(1/4 : ℝ)))) ∧
        ∀ H : ℝ, (∀ θ ∈ Icc (-(1/4 : ℝ)) 0, ‖h θ‖ ≤ H) →
          ∀ t, 0 ≤ t → ‖z t‖ ≤ D * Real.exp (-η*t) * H := by
  obtain ⟨η,D,hη,hD,hs⟩ := baseline_internal_stability
  refine ⟨η,D,hη,hD,?_⟩
  intro h hc
  obtain ⟨M,hM⟩ := isCompact_Icc.exists_bound_of_continuousOn hc
  obtain ⟨w,hw,hd,_⟩ := hs M (fullRationalHistory h) (fullRationalHistory_bound hc hM)
  have hz := rationalTrajectory_solution hc hw
  refine ⟨rationalTrajectory h w, hz, ?_, ?_⟩
  · intro other hother
    exact rationalStateSolution_unique hother hz
  · intro H hH t ht
    obtain ⟨v,hv,hvD,_⟩ := hs H (fullRationalHistory h) (fullRationalHistory_bound hc hH)
    have he := rationalStateSolution_unique hz (rationalTrajectory_solution hc hv)
    calc
      ‖rationalTrajectory h w t‖ = ‖rationalTrajectory h v t‖ :=
        congrArg norm (he (show t ∈ Ici (-(1/4 : ℝ)) by change -(1/4 : ℝ) ≤ t; linarith))
      _ ≤ (D*H)*Real.exp (-η*t) := rationalTrajectory_decay hc hv hvD t ht
      _ = D*Real.exp (-η*t)*H := by ring

end Article14.ExactDelay
