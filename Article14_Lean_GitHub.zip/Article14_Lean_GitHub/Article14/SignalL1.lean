import MIACE.TwoRate
import Article14.FeasibleGeometry

/-!
# Actual half-line signals as a continuous affine family in L¹

The causal extension and L¹ construction are reused from MIACE.  Equalities
below concern actual signal representatives; the affine map in L¹ is derived
from those equalities, rather than supplied as a physical certificate.
-/
namespace Article14
open MeasureTheory Filter Set MIACE
open scoped Topology

noncomputable def signalL1 (f : ℝ → ℝ) (hf : Integrable f halfLine) : RealL1 :=
  (causalize_integrable hf).toL1 (causalize f)

-- Actual representatives agree with the causal physical signal almost everywhere.
theorem signalL1_coe (f : ℝ → ℝ) (hf : Integrable f halfLine) :
    signalL1 f hf =ᵐ[volume] causalize f := Integrable.coeFn_toL1 _

theorem causalize_halfLine (f : ℝ → ℝ) : causalize f =ᵐ[halfLine] f := by
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  simp [causalize, le_of_lt (show 0 < t from ht)]

theorem signalL1_coe_halfLine (f : ℝ → ℝ) (hf : Integrable f halfLine) :
    signalL1 f hf =ᵐ[halfLine] f :=
  by
    have he : (signalL1 f hf : ℝ → ℝ) =ᵐ[halfLine] causalize f :=
      ae_restrict_of_ae (signalL1_coe f hf)
    exact he.trans (causalize_halfLine f)

-- The whole-line L¹ mass is exactly the actual half-line integral.
theorem signalL1_integral (f : ℝ → ℝ) (hf : Integrable f halfLine) :
    (∫ t, signalL1 f hf t) = ∫ t, f t ∂halfLine := by
  rw [integral_congr_ae (signalL1_coe f hf), causalize_integral]

-- Positivity of the L¹ vector is equivalent to positivity of the physical signal.
theorem signalL1_nonnegative_iff (f : ℝ → ℝ) (hf : Integrable f halfLine) :
    (0 : RealL1) ≤ signalL1 f hf ↔ ∀ᵐ t ∂halfLine, 0 ≤ f t := by
  rw [← Lp.coeFn_nonneg]
  constructor
  · intro h
    filter_upwards [ae_restrict_of_ae h, signalL1_coe_halfLine f hf] with t ht he
    rwa [← he]
  · intro h
    have h' : ∀ᵐ t : ℝ, 0 < t → 0 ≤ f t :=
      (ae_restrict_iff' measurableSet_Ioi).mp h
    filter_upwards [h', signalL1_coe f hf, volume.ae_ne (0 : ℝ)] with t ht he hn
    rw [he]
    by_cases hp : 0 ≤ t
    · simp [causalize, hp, ht (lt_of_le_of_ne hp (Ne.symm hn))]
    · simp [causalize, hp]

-- Equality in the actual L¹ space is exactly a.e. equality on physical time.
theorem signalL1_eq_iff {f g : ℝ → ℝ} (hf : Integrable f halfLine)
    (hg : Integrable g halfLine) :
    signalL1 f hf = signalL1 g hg ↔ f =ᵐ[halfLine] g := by
  constructor
  · intro h
    exact (signalL1_coe_halfLine f hf).symm.trans
      ((by rw [h] : (signalL1 f hf : ℝ → ℝ) =ᵐ[halfLine] signalL1 g hg).trans
        (signalL1_coe_halfLine g hg))
  · intro h
    have h' := (ae_restrict_iff' measurableSet_Ioi).mp h
    apply Lp.ext
    filter_upwards [signalL1_coe f hf, signalL1_coe g hg, h', volume.ae_ne (0 : ℝ)]
      with t hf' hg' he hn
    rw [hf', hg']
    by_cases hp : 0 ≤ t
    · simpa [causalize, hp] using he (lt_of_le_of_ne hp (Ne.symm hn))
    · simp [causalize, hp]

/-- The continuous linear coefficient map of two actual L¹ directions. -/
noncomputable def pairSpan (gb gc : RealL1) : (ℝ × ℝ) →L[ℝ] RealL1 :=
  (ContinuousLinearMap.fst ℝ ℝ ℝ).smulRight gb +
    (ContinuousLinearMap.snd ℝ ℝ ℝ).smulRight gc

theorem pairSpan_apply (gb gc : RealL1) (w : ℝ × ℝ) :
    pairSpan gb gc w = w.1 • gb + w.2 • gc := rfl

-- Any three given L¹ vectors determine a genuine continuous affine family.
noncomputable def basisAffineL1 (g00 g10 g01 : RealL1) (w : ℝ × ℝ) : RealL1 :=
  g00 + pairSpan (g10-g00) (g01-g00) w

-- The representative of this affine vector is the corresponding affine signal.
theorem basisAffineL1_coe (g00 g10 g01 : RealL1) (w : ℝ × ℝ) :
    basisAffineL1 g00 g10 g01 w =ᵐ[volume]
      (fun t => g00 t+w.1*(g10 t-g00 t)+w.2*(g01 t-g00 t)) := by
  unfold basisAffineL1 pairSpan
  filter_upwards [Lp.coeFn_add g00 (w.1 • (g10-g00)+w.2 • (g01-g00)),
    Lp.coeFn_add (w.1 • (g10-g00)) (w.2 • (g01-g00)),
    Lp.coeFn_smul w.1 (g10-g00), Lp.coeFn_smul w.2 (g01-g00),
    Lp.coeFn_sub g10 g00, Lp.coeFn_sub g01 g00] with t h0 h1 hb hc h10 h01
  change (g00+(w.1 • (g10-g00)+w.2 • (g01-g00))) t = _
  simp only [Pi.add_apply, Pi.sub_apply, Pi.smul_apply, smul_eq_mul] at h0 h1 hb hc h10 h01
  rw [h0, h1, hb, hc, h10, h01]
  ring

-- Physical a.e. affinity is sufficient; no choice of L¹ representatives is
-- required to agree pointwise, and no affine map is assumed as a certificate.
theorem signalL1_affine_family {f : (ℝ × ℝ) → ℝ → ℝ}
    (hf : ∀ w, Integrable (f w) halfLine)
    (ha : ∀ w, f w =ᵐ[halfLine]
      (fun t => f (0,0) t+w.1*(f (1,0) t-f (0,0) t)+
        w.2*(f (0,1) t-f (0,0) t))) (w : ℝ × ℝ) :
    signalL1 (f w) (hf w) = basisAffineL1
      (signalL1 (f (0,0)) (hf (0,0))) (signalL1 (f (1,0)) (hf (1,0)))
      (signalL1 (f (0,1)) (hf (0,1))) w := by
  apply Lp.ext
  have ha' := (ae_restrict_iff' measurableSet_Ioi).mp (ha w)
  filter_upwards [signalL1_coe (f w) (hf w),
    basisAffineL1_coe (signalL1 (f (0,0)) (hf (0,0)))
      (signalL1 (f (1,0)) (hf (1,0))) (signalL1 (f (0,1)) (hf (0,1))) w,
    signalL1_coe (f (0,0)) (hf (0,0)), signalL1_coe (f (1,0)) (hf (1,0)),
    signalL1_coe (f (0,1)) (hf (0,1)), ha', volume.ae_ne (0 : ℝ)]
    with t hw hb h0 h1 h2 hA hn
  rw [hw, hb, h0, h1, h2]
  by_cases hp : 0 ≤ t
  · simpa [causalize, hp] using hA (lt_of_le_of_ne hp (Ne.symm hn))
  · simp [causalize, hp]

end Article14
