import Article14.ModalRealizationCompatibility
import Article14.ModalStepExistence

/-!
# A finite SOCP for the same physical plant

The conic representation has five explicit affine polygon inequalities, four
affine inequalities per selected output/command sample, and one Lorentz cone
per selected modal coefficient.  Finiteness of the sample index is explicit.
No arbitrary compact convex set is claimed to be SOCP representable.  Sampled
bounds concern the selected times only, not a continuum of times or plants.
-/
namespace Article14.ModalRealization
open Set

/-- The five scalar affine inequalities defining the paper's admitted polygon.
Every expression is constrained to be nonpositive. -/
noncomputable def polygonLinearConstraints (Kp Td Tf umax : ℝ) :
    Fin 5 → (ℝ × ℝ) →ᵃ[ℝ] ℝ :=
  ![twoWeightAffine 0 (-1) 0, twoWeightAffine (-1) 1 0,
    twoWeightAffine 0 0 (-1), twoWeightAffine (-1) 0 1,
    twoWeightAffine (-umax) Kp (Kp*(Td/Tf))]

theorem polygonLinearConstraints_iff (Kp Td Tf umax : ℝ) (w : ℝ × ℝ) :
    (∀ j, polygonLinearConstraints Kp Td Tf umax j w ≤ 0) ↔
      w ∈ admittedModalPolygon Kp Td Tf umax := by
  simp only [polygonLinearConstraints, Fin.forall_fin_succ,
    Matrix.cons_val_zero, Matrix.cons_val_succ,
    twoWeightAffine_apply, smul_eq_mul, mul_zero, add_zero, zero_add,
    mul_neg_one, mul_one, Fin.forall_fin_zero, and_true]
  simp only [admittedModalPolygon, mem_inter_iff, mem_Icc, Prod.le_def,
    mem_ofPred_eq]
  constructor <;> intro h
  · refine ⟨⟨⟨?_, ?_⟩, ⟨?_, ?_⟩⟩, ?_⟩ <;> nlinarith [h.1, h.2.1, h.2.2.1,
      h.2.2.2.1, h.2.2.2.2]
  · rcases h with ⟨⟨⟨hb0, hc0⟩, ⟨hb1, hc1⟩⟩, hj⟩
    exact ⟨by linarith, by linarith, by linarith, by linarith, by nlinarith⟩

/-- Lower and upper bounds on two affine samples, as four scalar inequalities. -/
noncomputable def sampleLinearConstraints (y u : (ℝ × ℝ) →ᵃ[ℝ] ℝ)
    (yl yu ul uu : ℝ) : Fin 4 → (ℝ × ℝ) →ᵃ[ℝ] ℝ :=
  ![AffineMap.const ℝ (ℝ × ℝ) yl-y, y-AffineMap.const ℝ (ℝ × ℝ) yu,
    AffineMap.const ℝ (ℝ × ℝ) ul-u, u-AffineMap.const ℝ (ℝ × ℝ) uu]

theorem sampleLinearConstraints_iff (y u : (ℝ × ℝ) →ᵃ[ℝ] ℝ)
    (yl yu ul uu : ℝ) (w : ℝ × ℝ) :
    (∀ j, sampleLinearConstraints y u yl yu ul uu j w ≤ 0) ↔
      (yl ≤ y w ∧ y w ≤ yu) ∧ (ul ≤ u w ∧ u w ≤ uu) := by
  simp [sampleLinearConstraints, Fin.forall_fin_succ]
  tauto

/-- Explicit finite scalar inequalities: five for the polygon and four for
each sample.  The type of this family is finite whenever the samples are. -/
noncomputable def sampledPolygonLinearConstraints {κ : Type*}
    (Kp Td Tf umax : ℝ) (y u : κ → (ℝ × ℝ) →ᵃ[ℝ] ℝ)
    (yl yu ul uu : κ → ℝ) : (Fin 5 ⊕ (κ × Fin 4)) → (ℝ × ℝ) →ᵃ[ℝ] ℝ :=
  Sum.elim (polygonLinearConstraints Kp Td Tf umax)
    (fun j => sampleLinearConstraints (y j.1) (u j.1) (yl j.1) (yu j.1)
      (ul j.1) (uu j.1) j.2)

theorem sampledPolygonLinearConstraints_iff {κ : Type*}
    (Kp Td Tf umax : ℝ) (y u : κ → (ℝ × ℝ) →ᵃ[ℝ] ℝ)
    (yl yu ul uu : κ → ℝ) (w : ℝ × ℝ) :
    (∀ j, sampledPolygonLinearConstraints Kp Td Tf umax y u yl yu ul uu j w ≤ 0) ↔
      w ∈ admittedModalPolygon Kp Td Tf umax ∩
        (affineSampleSlabs y yl yu ∩ affineSampleSlabs u ul uu) := by
  simp only [sampledPolygonLinearConstraints, Sum.forall, Sum.elim_inl,
    Sum.elim_inr, Prod.forall, polygonLinearConstraints_iff,
    sampleLinearConstraints_iff, mem_inter_iff, affineSampleSlabs, mem_ofPred_eq]
  rw [forall_and]

/-- A finite SOCP epigraph.  The objective is the scalar `t`; all other scalar
constraints are affine, while each displayed cone uses affine real and
imaginary parts of a complex affine map. -/
def finiteSOCFeasible {ι δ : Type*} [Fintype δ] (s : Finset ι)
    (a : δ → (ℝ × ℝ) →ᵃ[ℝ] ℝ) (z : ι → (ℝ × ℝ) →ᵃ[ℝ] ℂ)
    (w : ℝ × ℝ) (t : ℝ) : Prop :=
  (∀ j, a j w ≤ 0) ∧
    ∀ i ∈ s, Real.sqrt ((z i w).re^2+(z i w).im^2) ≤ t

/-- The two real coordinates fed into each Lorentz cone are an affine map. -/
noncomputable def realModalCoordinates (z : (ℝ × ℝ) →ᵃ[ℝ] ℂ) :
    (ℝ × ℝ) →ᵃ[ℝ] (ℝ × ℝ) :=
  (Complex.reLm.prod Complex.imLm).toAffineMap.comp z

theorem realModalCoordinates_apply (z : (ℝ × ℝ) →ᵃ[ℝ] ℂ) (w : ℝ × ℝ) :
    realModalCoordinates z w = ((z w).re, (z w).im) := rfl

theorem finiteSOCFeasible_iff {ι δ : Type*} [Fintype δ]
    (s : Finset ι) (hne : s.Nonempty)
    (a : δ → (ℝ × ℝ) →ᵃ[ℝ] ℝ) (z : ι → (ℝ × ℝ) →ᵃ[ℝ] ℂ)
    (w : ℝ × ℝ) (t : ℝ) :
    finiteSOCFeasible s a z w t ↔
      (∀ j, a j w ≤ 0) ∧ finiteModalCost s hne z w ≤ t := by
  simp only [finiteSOCFeasible, finiteModalCost_le_iff, complex_norm_as_real_cone]

variable {n : Type*} [Fintype n] [DecidableEq n]

/-- All scalar constraints of the physical same-realization problem. -/
noncomputable def samePlantSampleLinear {ι κ : Type*}
    (C : ι → n → ℝ) (Kp Ti Td Tf umax : ℝ)
    (q00 q10 q01 : ι → ℝ → (n → ℝ) × ℝ × ℝ)
    (scenario : κ → ι) (H yl yu ul uu : κ → ℝ) :
    (Fin 5 ⊕ (κ × Fin 4)) → (ℝ × ℝ) →ᵃ[ℝ] ℝ :=
  sampledPolygonLinearConstraints Kp Td Tf umax
    (fun j => stepOutputSampleAffine (C (scenario j))
      (q00 (scenario j)) (q10 (scenario j)) (q01 (scenario j)) (H j))
    (fun j => stepCommandSampleAffine (C (scenario j)) Kp Ti Td Tf
      (q00 (scenario j)) (q10 (scenario j)) (q01 (scenario j)) (H j)) yl yu ul uu

omit [DecidableEq n] in
theorem samePlantSampleLinear_iff {ι κ : Type*}
    (C : ι → n → ℝ) (Kp Ti Td Tf umax : ℝ)
    (q00 q10 q01 : ι → ℝ → (n → ℝ) × ℝ × ℝ)
    (scenario : κ → ι) (H yl yu ul uu : κ → ℝ) (w : ℝ × ℝ) :
    (∀ j, samePlantSampleLinear C Kp Ti Td Tf umax q00 q10 q01 scenario
      H yl yu ul uu j w ≤ 0) ↔
    w ∈ admittedModalPolygon Kp Td Tf umax ∩
      physicalScenarioSampleBounds (C ∘ scenario) Kp Ti Td Tf
        (q00 ∘ scenario) (q10 ∘ scenario) (q01 ∘ scenario) H yl yu ul uu := by
  rw [physicalScenarioSampleBounds_eq]
  exact sampledPolygonLinearConstraints_iff Kp Td Tf umax _ _ yl yu ul uu w

-- Exact equivalence, rather than a relaxation, between the explicit finite
-- cones/halfspaces and the sampled physical minimax epigraph.
theorem same_plant_finite_soc_iff {ι κ : Type*} [Fintype κ]
    (s : Finset ι) (hne : s.Nonempty) (stepObjective : Bool)
    (A : ι → Matrix n n ℝ) (B C : ι → n → ℝ) (Kp Ti Td Tf umax : ℝ)
    (p : ι → ℂ) (q00 q10 q01 : ι → ℝ → (n → ℝ) × ℝ × ℝ)
    (scenario : κ → ι) (H yl yu ul uu : κ → ℝ) (w : ℝ × ℝ) (t : ℝ) :
    finiteSOCFeasible s
      (samePlantSampleLinear C Kp Ti Td Tf umax q00 q10 q01 scenario H yl yu ul uu)
      (fun i => samePlantModalAffine stepObjective (A i) (B i) (C i) Kp Ti Td Tf (p i)) w t ↔
    w ∈ admittedModalPolygon Kp Td Tf umax ∩
      physicalScenarioSampleBounds (C ∘ scenario) Kp Ti Td Tf
        (q00 ∘ scenario) (q10 ∘ scenario) (q01 ∘ scenario) H yl yu ul uu ∧
    finiteModalCost s hne
      (fun i => samePlantModalAffine stepObjective (A i) (B i) (C i) Kp Ti Td Tf (p i)) w ≤ t := by
  rw [finiteSOCFeasible_iff s hne, samePlantSampleLinear_iff]

-- Global conic optimizer on the actual paper polygon.  Every cone coefficient
-- is a residue of the same physical realization that supplies its samples.
theorem same_plant_finite_soc_optimizer {ι κ : Type*} [Fintype κ]
    (s : Finset ι) (hne : s.Nonempty) (stepObjective : Bool)
    (A : ι → Matrix n n ℝ) (B C : ι → n → ℝ) (Kp Ti Td Tf umax : ℝ)
    (hTi : Ti ≠ 0) (hTf : Tf ≠ 0) (p : ι → ℂ)
    (hzero : ∀ i ∈ s, feedbackDenominator (A i) (B i) (C i) Kp Ti Td Tf (p i) = 0)
    (hd : ∀ i ∈ s, deriv (feedbackDenominator (A i) (B i) (C i) Kp Ti Td Tf) (p i) ≠ 0)
    (hp : ∀ i ∈ s, p i ≠ 0)
    (q00 q10 q01 : ι → ℝ → (n → ℝ) × ℝ × ℝ)
    (h00 : ∀ i, StepLoopDynamics (A i) (B i) (C i) Kp Ti Td Tf 0 0 0 (q00 i))
    (h10 : ∀ i, StepLoopDynamics (A i) (B i) (C i) Kp Ti Td Tf 0 1 0 (q10 i))
    (h01 : ∀ i, StepLoopDynamics (A i) (B i) (C i) Kp Ti Td Tf 0 0 1 (q01 i))
    (scenario : κ → ι) (H yl yu ul uu : κ → ℝ)
    (hfeas : (admittedModalPolygon Kp Td Tf umax ∩
      physicalScenarioSampleBounds (C ∘ scenario) Kp Ti Td Tf
        (q00 ∘ scenario) (q10 ∘ scenario) (q01 ∘ scenario) H yl yu ul uu).Nonempty) :
    let a := samePlantSampleLinear C Kp Ti Td Tf umax q00 q10 q01 scenario H yl yu ul uu
    let z := fun i => samePlantModalAffine stepObjective (A i) (B i) (C i) Kp Ti Td Tf (p i)
    (∀ i ∈ s, ∀ w, HasSimpleResidue (fun v => if stepObjective then
        referenceResolvent (A i) (B i) (C i) Kp Ti Td Tf w v/v
      else referenceResolvent (A i) (B i) (C i) Kp Ti Td Tf w v) (p i) (z i w)) ∧
    ∃ w t, finiteSOCFeasible s a z w t ∧ t = finiteModalCost s hne z w ∧
      (∀ i, StepLoopDynamics (A i) (B i) (C i) Kp Ti Td Tf 0 w.1 w.2
        (stepAffineFamily (q00 i) (q10 i) (q01 i) w.1 w.2)) ∧
      (∀ i, stepCommand (C i) Kp Ti Td Tf w.1 w.2
        (stepAffineFamily (q00 i) (q10 i) (q01 i) w.1 w.2) 0 ≤ umax) ∧
      ∀ v u, finiteSOCFeasible s a z v u → t ≤ u := by
  dsimp only
  obtain ⟨hr, _, _, w, hw, hwd, hmin⟩ :=
    same_realization_constrained_modal_minimizer s hne stepObjective A B C Kp Ti Td Tf
      hTi hTf p hzero hd hp q00 q10 q01 h00 h10 h01 scenario H yl yu ul uu
      (admittedModalPolygon_compact Kp Td Tf umax)
      (admittedModalPolygon_convex Kp Td Tf umax) hfeas
  refine ⟨hr, w, _, ?_, rfl, hwd, ?_, ?_⟩
  · exact (same_plant_finite_soc_iff s hne stepObjective A B C Kp Ti Td Tf umax p
      q00 q10 q01 scenario H yl yu ul uu w _).2 ⟨hw, le_rfl⟩
  · intro i
    rw [stepCommand_zero_eq_polygon_jump (hwd i)]
    exact hw.1.2
  · intro v u hv
    obtain ⟨hvF, hvCost⟩ := (same_plant_finite_soc_iff s hne stepObjective A B C
      Kp Ti Td Tf umax p q00 q10 q01 scenario H yl yu ul uu v u).1 hv
    exact (hmin v hvF).trans hvCost

/-- A physical family built from three unconditional finite affine flows.
It needs neither a nonzero plant DC gain nor a stability certificate. -/
noncomputable def modalStepFamily (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf : ℝ) (w : ℝ × ℝ) : ℝ → (n → ℝ) × ℝ × ℝ :=
  stepAffineFamily (zeroDelayStepResponse A B C Kp Ti Td Tf 0 0)
    (zeroDelayStepResponse A B C Kp Ti Td Tf 1 0)
    (zeroDelayStepResponse A B C Kp Ti Td Tf 0 1) w.1 w.2

theorem modalStepFamily_dynamics (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf : ℝ) (w : ℝ × ℝ) :
    StepLoopDynamics A B C Kp Ti Td Tf 0 w.1 w.2
      (modalStepFamily A B C Kp Ti Td Tf w) :=
  stepLoopDynamics_affine_family
    (zeroDelayStepResponse_dynamics A B C Kp Ti Td Tf 0 0)
    (zeroDelayStepResponse_dynamics A B C Kp Ti Td Tf 1 0)
    (zeroDelayStepResponse_dynamics A B C Kp Ti Td Tf 0 1) w.1 w.2

/-- The canonical, fully physical finite conic problem.  Its only design
variables are the two weights and the common scalar epigraph bound. -/
noncomputable def modalFiniteSOC {ι κ : Type*} [Fintype κ]
    (s : Finset ι) (stepObjective : Bool)
    (A : ι → Matrix n n ℝ) (B C : ι → n → ℝ) (Kp Ti Td Tf umax : ℝ)
    (p : ι → ℂ) (scenario : κ → ι) (H yl yu ul uu : κ → ℝ)
    (w : ℝ × ℝ) (t : ℝ) : Prop :=
  finiteSOCFeasible s
    (samePlantSampleLinear C Kp Ti Td Tf umax
      (fun i => zeroDelayStepResponse (A i) (B i) (C i) Kp Ti Td Tf 0 0)
      (fun i => zeroDelayStepResponse (A i) (B i) (C i) Kp Ti Td Tf 1 0)
      (fun i => zeroDelayStepResponse (A i) (B i) (C i) Kp Ti Td Tf 0 1)
      scenario H yl yu ul uu)
    (fun i => samePlantModalAffine stepObjective (A i) (B i) (C i) Kp Ti Td Tf (p i)) w t

-- The canonical SOCP is exactly the actual sampled constraints and modal
-- epigraph.  In particular the sample bounds are not an independent oracle.
theorem modalFiniteSOC_iff {ι κ : Type*} [Fintype κ]
    (s : Finset ι) (hne : s.Nonempty) (stepObjective : Bool)
    (A : ι → Matrix n n ℝ) (B C : ι → n → ℝ) (Kp Ti Td Tf umax : ℝ)
    (p : ι → ℂ) (scenario : κ → ι) (H yl yu ul uu : κ → ℝ)
    (w : ℝ × ℝ) (t : ℝ) :
    modalFiniteSOC s stepObjective A B C Kp Ti Td Tf umax p scenario H yl yu ul uu w t ↔
    (w ∈ admittedModalPolygon Kp Td Tf umax ∧
      ∀ j, (yl j ≤ finitePlantOutput (C (scenario j))
          (modalStepFamily (A (scenario j)) (B (scenario j)) (C (scenario j)) Kp Ti Td Tf w (H j)).1 ∧
        finitePlantOutput (C (scenario j))
          (modalStepFamily (A (scenario j)) (B (scenario j)) (C (scenario j)) Kp Ti Td Tf w (H j)).1 ≤ yu j) ∧
        (ul j ≤ stepCommand (C (scenario j)) Kp Ti Td Tf w.1 w.2
          (modalStepFamily (A (scenario j)) (B (scenario j)) (C (scenario j)) Kp Ti Td Tf w) (H j) ∧
        stepCommand (C (scenario j)) Kp Ti Td Tf w.1 w.2
          (modalStepFamily (A (scenario j)) (B (scenario j)) (C (scenario j)) Kp Ti Td Tf w) (H j) ≤ uu j)) ∧
    finiteModalCost s hne
      (fun i => samePlantModalAffine stepObjective (A i) (B i) (C i) Kp Ti Td Tf (p i)) w ≤ t := by
  unfold modalFiniteSOC
  rw [same_plant_finite_soc_iff s hne]
  rfl

-- Final Proposition 10 endpoint for the paper's polygon and finite samples.
-- The physical responses are constructed, every selected residue is tied to
-- its own physical state resolvent, and the finite SOCP minimum is attained.
theorem modal_finite_soc_global_optimizer {ι κ : Type*} [Fintype κ]
    (s : Finset ι) (hne : s.Nonempty) (stepObjective : Bool)
    (A : ι → Matrix n n ℝ) (B C : ι → n → ℝ) (Kp Ti Td Tf umax : ℝ)
    (hTi : Ti ≠ 0) (hTf : Tf ≠ 0) (p : ι → ℂ)
    (hzero : ∀ i ∈ s, feedbackDenominator (A i) (B i) (C i) Kp Ti Td Tf (p i) = 0)
    (hd : ∀ i ∈ s, deriv (feedbackDenominator (A i) (B i) (C i) Kp Ti Td Tf) (p i) ≠ 0)
    (hp : ∀ i ∈ s, p i ≠ 0)
    (scenario : κ → ι) (H yl yu ul uu : κ → ℝ) (hH : ∀ j, 0 ≤ H j)
    (hfeas : ∃ w t,
      modalFiniteSOC s stepObjective A B C Kp Ti Td Tf umax p scenario H yl yu ul uu w t) :
    let z := fun i => samePlantModalAffine stepObjective (A i) (B i) (C i) Kp Ti Td Tf (p i)
    (∀ i ∈ s, ∀ w, HasSimpleResidue (fun v => if stepObjective then
        referenceResolvent (A i) (B i) (C i) Kp Ti Td Tf w v/v
      else referenceResolvent (A i) (B i) (C i) Kp Ti Td Tf w v) (p i) (z i w)) ∧
    ∃ w t,
      modalFiniteSOC s stepObjective A B C Kp Ti Td Tf umax p scenario H yl yu ul uu w t ∧
      t = finiteModalCost s hne z w ∧
      (∀ i, StepLoopDynamics (A i) (B i) (C i) Kp Ti Td Tf 0 w.1 w.2
        (modalStepFamily (A i) (B i) (C i) Kp Ti Td Tf w)) ∧
      (∀ i, stepCommand (C i) Kp Ti Td Tf w.1 w.2
        (modalStepFamily (A i) (B i) (C i) Kp Ti Td Tf w) 0 ≤ umax) ∧
      (∀ j, 0 ≤ H j ∧
        (yl j ≤ finitePlantOutput (C (scenario j))
          (modalStepFamily (A (scenario j)) (B (scenario j)) (C (scenario j)) Kp Ti Td Tf w (H j)).1 ∧
        finitePlantOutput (C (scenario j))
          (modalStepFamily (A (scenario j)) (B (scenario j)) (C (scenario j)) Kp Ti Td Tf w (H j)).1 ≤ yu j) ∧
        (ul j ≤ stepCommand (C (scenario j)) Kp Ti Td Tf w.1 w.2
          (modalStepFamily (A (scenario j)) (B (scenario j)) (C (scenario j)) Kp Ti Td Tf w) (H j) ∧
        stepCommand (C (scenario j)) Kp Ti Td Tf w.1 w.2
          (modalStepFamily (A (scenario j)) (B (scenario j)) (C (scenario j)) Kp Ti Td Tf w) (H j) ≤ uu j)) ∧
      ∀ v u, modalFiniteSOC s stepObjective A B C Kp Ti Td Tf umax p scenario
        H yl yu ul uu v u → t ≤ u := by
  obtain ⟨v, u, hv⟩ := hfeas
  have hvF := ((same_plant_finite_soc_iff s hne stepObjective A B C Kp Ti Td Tf umax p
    (fun i => zeroDelayStepResponse (A i) (B i) (C i) Kp Ti Td Tf 0 0)
    (fun i => zeroDelayStepResponse (A i) (B i) (C i) Kp Ti Td Tf 1 0)
    (fun i => zeroDelayStepResponse (A i) (B i) (C i) Kp Ti Td Tf 0 1)
    scenario H yl yu ul uu v u).1 hv).1
  obtain ⟨hr, w, t, hw, ht, hwd, hj, hm⟩ := same_plant_finite_soc_optimizer s hne
    stepObjective A B C Kp Ti Td Tf umax hTi hTf p hzero hd hp
    (fun i => zeroDelayStepResponse (A i) (B i) (C i) Kp Ti Td Tf 0 0)
    (fun i => zeroDelayStepResponse (A i) (B i) (C i) Kp Ti Td Tf 1 0)
    (fun i => zeroDelayStepResponse (A i) (B i) (C i) Kp Ti Td Tf 0 1)
    (fun i => zeroDelayStepResponse_dynamics (A i) (B i) (C i) Kp Ti Td Tf 0 0)
    (fun i => zeroDelayStepResponse_dynamics (A i) (B i) (C i) Kp Ti Td Tf 1 0)
    (fun i => zeroDelayStepResponse_dynamics (A i) (B i) (C i) Kp Ti Td Tf 0 1)
    scenario H yl yu ul uu ⟨v, hvF⟩
  refine ⟨hr, w, t, hw, ht, hwd, hj, ?_, hm⟩
  have hs := ((modalFiniteSOC_iff s hne stepObjective A B C Kp Ti Td Tf umax p
    scenario H yl yu ul uu w t).1 hw).1.2
  exact fun j => ⟨hH j, hs j⟩

end Article14.ModalRealization
