import Article14.ExactDelayRationalStability

/-!
# Full physical stability of the exact delayed example

The invertible change of all four state coordinates transports existence,
uniqueness, and the uniform history estimate.  Thus no internal storage is
discarded by an external transfer cancellation.
-/
namespace Article14.ExactDelay
open MeasureTheory Filter Set MIACE
open scoped Topology

theorem shared_stability_of_rational_history
    (hstable : ∃ η D : ℝ, 0 < η ∧ 0 ≤ D ∧
      ∀ h : ℝ → LoopState, ContinuousOn h (Icc (-(1/4:ℝ)) 0) →
        ∃ z, IsRationalStateSolution h z ∧
          (∀ other, IsRationalStateSolution h other → EqOn other z (Ici (-(1/4:ℝ)))) ∧
          ∀ H : ℝ, (∀ θ ∈ Icc (-(1/4:ℝ)) 0, ‖h θ‖ ≤ H) →
            ∀ t, 0 ≤ t → ‖z t‖ ≤ D*Real.exp (-η*t)*H) :
    IsRetardedSharedExponentiallyStable (finitePlantOutput plantC)
      (finitePlantDynamics plantA plantB) kp ti td tf (1/4) 0 0 := by
  obtain ⟨η, D, hη, hD, hs⟩ := hstable
  constructor
  · intro h hc
    obtain ⟨z, hz, hu, _⟩ := hs (fun t => stateEquiv (h t))
      (stateEquiv.continuous.comp_continuousOn hc)
    refine ⟨fun t => stateEquiv.symm (z t), ?_, ?_⟩
    · simpa only [ContinuousLinearEquiv.symm_apply_apply] using rational_solution_to_shared hz
    · intro other hother t ht
      have he := hu (fun s => stateEquiv (other s)) (shared_solution_to_rational hother) ht
      apply stateEquiv.injective
      simpa only [ContinuousLinearEquiv.apply_symm_apply] using he
  · let K : ℝ := ‖stateEquiv.symm.toContinuousLinearMap‖ * D *
      ‖stateEquiv.toContinuousLinearMap‖
    have hK : 0 ≤ K := by dsimp [K]; positivity
    refine ⟨1+K, η, by linarith, hη, ?_⟩
    intro h q H hH hq t ht
    have hH0 : 0 ≤ H := (norm_nonneg (h 0)).trans (hH 0 (by norm_num))
    have hc : ContinuousOn h (Icc (-(1/4:ℝ)) 0) := by
      apply (hq.1.mono Icc_subset_Ici_self).congr
      intro s hs
      exact (hq.2.1 s hs).symm
    obtain ⟨z, hz, hu, hd⟩ := hs (fun t => stateEquiv (h t))
      (stateEquiv.continuous.comp_continuousOn hc)
    have hhist : ∀ θ ∈ Icc (-(1/4:ℝ)) 0,
        ‖stateEquiv (h θ)‖ ≤ ‖stateEquiv.toContinuousLinearMap‖ * H := by
      intro θ hθ
      exact (stateEquiv.toContinuousLinearMap.le_opNorm (h θ)).trans
        (mul_le_mul_of_nonneg_left (hH θ hθ) (norm_nonneg _))
    have he : stateEquiv (q t) = z t :=
      hu (fun s => stateEquiv (q s)) (shared_solution_to_rational hq)
        (show t ∈ Ici (-(1/4:ℝ)) by change -(1/4:ℝ) ≤ t; linarith)
    calc
      ‖q t‖ = ‖stateEquiv.symm (stateEquiv (q t))‖ := by
        rw [ContinuousLinearEquiv.symm_apply_apply]
      _ ≤ ‖stateEquiv.symm.toContinuousLinearMap‖ * ‖stateEquiv (q t)‖ :=
        stateEquiv.symm.toContinuousLinearMap.le_opNorm _
      _ ≤ ‖stateEquiv.symm.toContinuousLinearMap‖ *
          (D*Real.exp (-η*t)*(‖stateEquiv.toContinuousLinearMap‖*H)) := by
        rw [he]
        exact mul_le_mul_of_nonneg_left (hd _ hhist t ht) (norm_nonneg _)
      _ = K*Real.exp (-η*t)*H := by dsimp [K]; ring
      _ ≤ (1+K)*Real.exp (-η*t)*H := by gcongr; linarith

-- The inherited resolvent construction and the complete state conjugacy now
-- prove actual shared-PIDF internal stability with no stability hypothesis.
theorem exact_shared_internal_stability :
    IsRetardedSharedExponentiallyStable (finitePlantOutput plantC)
      (finitePlantDynamics plantA plantB) kp ti td tf (1/4) 0 0 :=
  shared_stability_of_rational_history rational_full_history_stability

theorem exact_shared_internal_stability_all_weights (b c : ℝ) :
    IsRetardedSharedExponentiallyStable (finitePlantOutput plantC)
      (finitePlantDynamics plantA plantB) kp ti td tf (1/4) b c :=
  (retardedShared_exponentialStability_iff _ _ kp ti td tf (1/4) 0 0 b c).mp
    exact_shared_internal_stability

/-- The exact two-lag delayed physical plant/controller family, with its
all-history stability proved internally. -/
noncomputable def exampleData : StablePIDFData (Fin 2) :=
  plantDataOfStable exact_shared_internal_stability

end Article14.ExactDelay
