import Mathlib.Algebra.Polynomial.Eval.Degree
import MIACE.Algebra

/-!
# Coefficients of an arbitrary strictly proper rational plant

The denominator is normalized by its actual leading coefficient. These
identities connect the finite companion coefficients with the original
polynomial quotient; no realization or transfer equality is assumed.
-/
namespace Article14.RationalRealization
open Polynomial Finset

-- A degree bound, rather than a nonzero numerator, also covers the zero
-- polynomial correctly in the finite coefficient expansion.
theorem eval_eq_sum_fin_of_degree_lt (p : ℝ[X]) {N : ℕ}
    (hp : p.degree < (N : WithBot ℕ)) (x : ℝ) :
    p.eval x = ∑ i : Fin N, p.coeff i * x ^ (i : ℕ) := by
  rw [Polynomial.eval_eq_sum]
  exact (Polynomial.sum_fin (fun (i : ℕ) (a : ℝ) => a * x ^ i) (by simp) hp).symm

-- The leading monomial is separated from exactly N lower coefficients.
theorem eval_eq_leading_add_sum_fin (p : ℝ[X]) {N : ℕ}
    (hN : p.natDegree = N) (x : ℝ) :
    p.eval x = p.leadingCoeff * x^N + ∑ i : Fin N, p.coeff i * x^(i : ℕ) := by
  rw [Polynomial.eval_eq_sum_range, hN, Finset.sum_range_succ]
  rw [Fin.sum_univ_eq_sum_range (fun i => p.coeff i * x^i)]
  rw [← hN, Polynomial.coeff_natDegree]
  exact add_comm _ _

-- Dividing the actual denominator produces a monic companion polynomial.
theorem normalized_denominator_eval (den : ℝ[X]) (hden : den ≠ 0)
    {N : ℕ} (hN : den.natDegree = N) (x : ℝ) :
    den.eval x / den.leadingCoeff = x^N +
      ∑ i : Fin N, (den.coeff i / den.leadingCoeff) * x^(i : ℕ) := by
  have hl : den.leadingCoeff ≠ 0 := Polynomial.leadingCoeff_ne_zero.mpr hden
  rw [eval_eq_leading_add_sum_fin den hN, add_div, mul_div_cancel_left₀ _ hl]
  rw [Finset.sum_div]
  congr 1
  apply Finset.sum_congr rfl
  intro i _
  ring

-- Strict properness supplies the numerator's degree bound automatically.
theorem normalized_numerator_eval (num den : ℝ[X]) (hden : den ≠ 0)
    (hproper : num.degree < den.degree) {N : ℕ} (hN : den.natDegree = N)
    (x : ℝ) :
    num.eval x / den.leadingCoeff =
      ∑ i : Fin N, (num.coeff i / den.leadingCoeff) * x^(i : ℕ) := by
  have hn : num.degree < (N : WithBot ℕ) := by
    simpa only [Polynomial.degree_eq_natDegree hden, hN] using hproper
  rw [eval_eq_sum_fin_of_degree_lt num hn, Finset.sum_div]
  apply Finset.sum_congr rfl
  intro i _
  ring

-- A nonzero strictly proper numerator forces a positive denominator degree,
-- so a finite companion with N states exists with no zero-state exception.
theorem denominator_natDegree_pos (num den : ℝ[X]) (hnum : num ≠ 0)
    (hden : den ≠ 0) (hproper : num.degree < den.degree) :
    0 < den.natDegree := by
  rw [Polynomial.degree_eq_natDegree hnum, Polynomial.degree_eq_natDegree hden]
    at hproper
  have hn : num.natDegree < den.natDegree := WithBot.coe_lt_coe.mp hproper
  omega

-- Normalizing both polynomials leaves the actual rational transfer unchanged,
-- including points where Lean's totalized division has a zero denominator.
theorem normalized_quotient_eval (num den : ℝ[X]) (hden : den ≠ 0)
    (hproper : num.degree < den.degree) {N : ℕ} (hN : den.natDegree = N)
    (x : ℝ) :
    (∑ i : Fin N, (num.coeff i / den.leadingCoeff) * x^(i : ℕ)) /
      (x^N + ∑ i : Fin N, (den.coeff i / den.leadingCoeff) * x^(i : ℕ)) =
        num.eval x / den.eval x := by
  rw [← normalized_denominator_eval den hden hN,
    ← normalized_numerator_eval num den hden hproper hN]
  exact div_div_div_cancel_right₀ (Polynomial.leadingCoeff_ne_zero.mpr hden) _ _

end Article14.RationalRealization
