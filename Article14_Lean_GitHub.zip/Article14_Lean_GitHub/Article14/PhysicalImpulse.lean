import Article14.PhysicalStep
import Article14.PositiveKernel
import Article14.KernelMomentGeometry
import Article14.StepUniqueness
import MIACE.PIExplicit
import Mathlib.Analysis.Calculus.FDeriv.Measurable

/-!
# Ordinary impulse kernels of the physical delayed PIDF loop

The kernel is the actual plant output derivative, expressed through the
implemented differential equation.  Local absolute continuity supplies its
finite-time integral; internal exponential stability supplies its integrability,
unit mass, and moments.  No transfer or impulse identity is an assumption.
-/
namespace Article14
open MeasureTheory Filter Set MIACE
open scoped Topology
open PhysicalPlant PhysicalLaplace
variable {n : Type*} [Fintype n] [DecidableEq n]

/-- The causal ordinary output derivative of the implemented physical step.
The values at the isolated switching instants do not affect its integrals. -/
noncomputable def stepImpulse (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf L b c : ℝ) (q : ℝ → (n → ℝ) × ℝ × ℝ) (t : ℝ) : ℝ :=
  if t ≤ 0 then 0 else
    ∑ j, C j * ((∑ l, A j l * (q t).1 l) +
      B j * (if t ≤ L then 0 else stepCommand C Kp Ti Td Tf b c q (t-L)))

-- Finite linear combinations preserve precisely the local regularity used by
-- the physical state equations, without an extra smoothness assumption.
theorem finite_sum_locallyAC {ι : Type*} (s : Finset ι) (f : ι → ℝ → ℝ)
    (h : ∀ j ∈ s, ∀ T, 0 ≤ T → AbsolutelyContinuousOnInterval (f j) 0 T) :
    ∀ T, 0 ≤ T → AbsolutelyContinuousOnInterval (fun t => ∑ j ∈ s, f j t) 0 T := by
  classical
  intro T hT
  induction s using Finset.induction_on with
  | empty =>
    simp only [Finset.sum_empty]
    exact ContDiffOn.absolutelyContinuousOnInterval (by fun_prop)
  | @insert a s ha ih =>
    simp only [Finset.sum_insert ha]
    apply (h a (Finset.mem_insert_self a s) T hT).add
    exact ih (fun j hj => h j (Finset.mem_insert_of_mem hj))

-- The physical output is locally absolutely continuous because each plant
-- coordinate is; the strictly proper output has no direct feedthrough jump.
omit [DecidableEq n] in
theorem step_output_locallyAC
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q) :
    ∀ T, 0 ≤ T → AbsolutelyContinuousOnInterval
      (fun t => finitePlantOutput C (q t).1) 0 T := by
  exact finite_sum_locallyAC Finset.univ (fun j t => C j * (q t).1 j)
    (fun j _ T hT => (h.state_ac j T hT).const_mul (C j))

-- Derive the output derivative from all physical coordinate equations.
omit [DecidableEq n] in
theorem step_output_ode
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q) :
    ∀ᵐ t : ℝ, 0 < t → deriv (fun s => finitePlantOutput C (q s).1) t =
      stepImpulse A B C Kp Ti Td Tf L b c q t := by
  have hd := ae_all_iff.mpr (fun j => local_ac_ae_differentiable (h.state_ac j))
  have ho := ae_all_iff.mpr h.state_ode
  filter_upwards [hd, ho] with t ht ho hpos
  have hh := HasDerivAt.fun_sum (u := Finset.univ)
    (fun j _ => ((ht j hpos).hasDerivAt.const_mul (C j)))
  unfold finitePlantOutput
  rw [hh.deriv]
  simp only [stepImpulse, not_le.mpr hpos, ite_false]
  exact Finset.sum_congr rfl (fun j _ => by rw [ho j hpos])

-- The same concrete kernel is minus the actual tracking-error derivative.
omit [DecidableEq n] in
theorem step_error_ode
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q) :
    ∀ᵐ t : ℝ, 0 < t → deriv (fun s => 1-finitePlantOutput C (q s).1) t =
      -stepImpulse A B C Kp Ti Td Tf L b c q t := by
  filter_upwards [step_output_ode h,
    local_ac_ae_differentiable (step_output_locallyAC h)] with t ho hd ht
  have hh := (hd ht).hasDerivAt.const_sub 1
  rw [hh.deriv, ho ht]

-- The physical step is the integral of the ordinary kernel; this equality is
-- a consequence of the initial state and the fundamental theorem of calculus.
omit [DecidableEq n] in
theorem step_output_eq_impulse_integral
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q) (T : ℝ) (hT : 0 ≤ T) :
    finitePlantOutput C (q T).1 =
      ∫ t in 0..T, stepImpulse A B C Kp Ti Td Tf L b c q t := by
  have hh := (step_output_locallyAC h T hT).integral_deriv_eq_sub
  have he : (∫ t in 0..T, deriv (fun s => finitePlantOutput C (q s).1) t) =
      ∫ t in 0..T, stepImpulse A B C Kp Ti Td Tf L b c q t := by
    apply intervalIntegral.integral_congr_ae
    filter_upwards [step_output_ode h] with t ht htmem
    rw [uIoc_of_le hT] at htmem
    exact ht htmem.1
  rw [he] at hh
  simpa [h.initial, finitePlantOutput] using hh.symm

-- The ordinary kernel has zero prehistory, independently of any extension of
-- the physical state to negative times.
omit [DecidableEq n] in
theorem stepImpulse_causal (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf L b c : ℝ) (q : ℝ → (n → ℝ) × ℝ × ℝ) :
    MIACE.Causal (stepImpulse A B C Kp Ti Td Tf L b c q) := by
  exact Eventually.of_forall (fun t ht => by simp [stepImpulse, ht.le])


/-- The current-state contribution to the plant output derivative. -/
noncomputable def outputDerivativeObservation (A : Matrix n n ℝ) (C : n → ℝ) :
    ((n → ℝ) × ℝ × ℝ) →L[ℝ] ℝ :=
  (finiteOutputMap C).comp ((finiteStateMap A).comp
    (ContinuousLinearMap.fst ℝ (n → ℝ) (ℝ × ℝ)))

omit [DecidableEq n] in
theorem outputDerivativeObservation_apply (A : Matrix n n ℝ) (C : n → ℝ)
    (z : (n → ℝ) × ℝ × ℝ) :
    outputDerivativeObservation A C z = ∑ j, C j * (∑ l, A j l * z.1 l) := by
  simp [outputDerivativeObservation, finiteOutputMap, finiteStateMap_apply]

-- The physical impulse equation is centered using the verified equilibrium.
-- In particular the initial transport interval contributes the constant -1.
omit [DecidableEq n] in
theorem stepImpulse_centered
    (A : Matrix n n ℝ) (B C xInf : n → ℝ) (Kp Ti Td Tf k L b c : ℝ)
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0)
    (heq : ∀ j, (∑ l, A j l*xInf l)+B j/k=0)
    (hout : (∑ j, C j*xInf j) = 1)
    (q : ℝ → (n → ℝ) × ℝ × ℝ) (t : ℝ) (ht : 0 < t) :
    stepImpulse A B C Kp Ti Td Tf L b c q t =
      outputDerivativeObservation A C (q t-pidfEquilibrium xInf Ti k Kp b c) +
      ((∑ j, C j*B j)/k)*centeredDelay L
        (fun s => commandObservation C k Kp Ti Td Tf
          (q s-pidfEquilibrium xInf Ti k Kp b c)) t := by
  simp only [stepImpulse, not_le.mpr ht, ite_false]
  rw [outputDerivativeObservation_apply]
  simp only [pidfEquilibrium, Prod.fst_sub, Pi.sub_apply, mul_sub, Finset.sum_sub_distrib,
    centeredDelay]
  by_cases htL : t ≤ L
  · simp only [htL, ite_true, mul_zero, add_zero, mul_neg_one]
    have hh : (∑ j, C j * (∑ l, A j l*xInf l)) = -((∑ j, C j*B j)/k) := by
      calc
        _ = ∑ j, C j * (-(B j/k)) := Finset.sum_congr rfl (fun j _ => by rw [eq_neg_of_add_eq_zero_left (heq j)])
        _ = _ := by simp [mul_div_assoc, Finset.sum_div]
    rw [hh]
    ring
  · simp only [htL, ite_false]
    have hcmd := step_centered_command C xInf Kp Ti Td Tf k b c hTi hk hKp hout q (t-L)
    change commandObservation C k Kp Ti Td Tf (q (t-L)-(xInf, meanTime Ti k Kp b, c-1)) = _ at hcmd
    rw [hcmd]
    have hh : ∀ j, (∑ l, A j l*(q t).1 l)+B j*stepCommand C Kp Ti Td Tf b c q (t-L) =
        (∑ l, A j l*(q t).1 l)-(∑ l, A j l*xInf l)+
          B j/k*(k*stepCommand C Kp Ti Td Tf b c q (t-L)-1) := by
      intro j
      have hj := heq j
      field_simp at hj ⊢
      nlinarith
    simp_rw [hh]
    simp only [mul_add, Finset.sum_add_distrib, mul_sub, Finset.sum_sub_distrib]
    congr 1
    simp only [← mul_assoc, ← mul_div_assoc, ← Finset.sum_mul, ← Finset.sum_div]

-- Measurability follows from the actual derivative equation, even at a
-- transport switch where the ordinary derivative need not be continuous.
omit [DecidableEq n] in
theorem stepImpulse_aestronglyMeasurable
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q) :
    AEStronglyMeasurable (stepImpulse A B C Kp Ti Td Tf L b c q) halfLine := by
  apply (aestronglyMeasurable_deriv (fun t => finitePlantOutput C (q t).1) halfLine).congr
  filter_upwards [ae_restrict_of_ae (step_output_ode h), ae_restrict_mem measurableSet_Ioi] with t ho ht
  exact ho ht

-- A pure delay preserves exponential decay after including its finite
-- waiting pulse in the envelope constant.
theorem centeredDelay_exp_bound {v : ℝ → ℝ} {D α L : ℝ}
    (hD : 0 ≤ D) (hα : 0 < α)
    (hd : ∀ t, 0 ≤ t → |v t| ≤ D*Real.exp (-α*t)) :
    ∀ t, 0 ≤ t → |centeredDelay L v t| ≤
      (D+1)*Real.exp (α*L)*Real.exp (-α*t) := by
  intro t ht
  have hexp : Real.exp (α*L)*Real.exp (-α*t) = Real.exp (α*(L-t)) := by
    rw [← Real.exp_add]
    congr 1
    ring
  by_cases htL : t ≤ L
  · simp only [centeredDelay, htL, ite_true, abs_neg, abs_one]
    rw [mul_assoc, hexp]
    have hx : 1 ≤ Real.exp (α*(L-t)) := Real.one_le_exp (mul_nonneg hα.le (sub_nonneg.mpr htL))
    nlinarith
  · have ht' : 0 ≤ t-L := le_of_lt (sub_pos.mpr (lt_of_not_ge htL))
    simp only [centeredDelay, htL, ite_false]
    calc
      |v (t-L)| ≤ D*Real.exp (-α*(t-L)) := hd (t-L) ht'
      _ ≤ (D+1)*Real.exp (-α*(t-L)) := by gcongr; linarith
      _ = (D+1)*Real.exp (α*L)*Real.exp (-α*t) := by
        rw [mul_assoc, hexp]
        congr 2
        ring

-- The same internal stability assumption now gives exponential decay of the
-- actual ordinary impulse and the physical error, with a common rate.
omit [DecidableEq n] in
theorem stable_step_impulse_decay
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0) (hL : 0 ≤ L)
    (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c)
    (heq : ∀ j, (∑ l, A j l*xInf l)+B j/k=0)
    (hout : (∑ j, C j*xInf j) = 1) :
    ∃ Ce Cg β : ℝ, 0 < Ce ∧ 0 < Cg ∧ 0 < β ∧
      (∀ t, 0 ≤ t → |1-finitePlantOutput C (q t).1| ≤ Ce*Real.exp (-β*t)) ∧
      (∀ t, 0 ≤ t → |stepImpulse A B C Kp Ti Td Tf L b c q t| ≤ Cg*Real.exp (-β*t)) := by
  let z := fun t => q t-pidfEquilibrium xInf Ti k Kp b c
  have hc : ContinuousOn z (Ici 0) := h.continuous.sub continuousOn_const
  obtain ⟨D, β, hD, hβ, hd⟩ := retardedShared_stable_tail_decay
    (finitePlantOutput C) (finitePlantDynamics A B) Kp Ti Td Tf L b c z hL hs hc
    (centeredStep_after_delay h hTi hk hKp heq hout)
  obtain ⟨Ce, hCe, he⟩ := linear_observable_exp_decay z (errorObservation C) hD hd
  obtain ⟨Cv, hCv, hv⟩ := linear_observable_exp_decay z (commandObservation C k Kp Ti Td Tf) hD hd
  obtain ⟨Ca, hCa, ha⟩ := linear_observable_exp_decay z (outputDerivativeObservation A C) hD hd
  let R := |(∑ j, C j*B j)/k|
  let E := (Cv+1)*Real.exp (β*L)
  refine ⟨Ce, Ca+R*E, β, hCe, by dsimp [R, E]; positivity, hβ, ?_, ?_⟩
  · intro t ht
    simpa only [z, step_centered_error C xInf Ti k Kp b c hout] using he t ht
  · intro t ht
    by_cases ht0 : t=0
    · subst t
      simp only [stepImpulse, le_refl, ite_true, abs_zero, mul_zero, Real.exp_zero, mul_one]
      dsimp [R, E]
      positivity
    · have htpos : 0<t := lt_of_le_of_ne ht (Ne.symm ht0)
      rw [stepImpulse_centered A B C xInf Kp Ti Td Tf k L b c hTi hk hKp heq hout q t htpos]
      have hvd := centeredDelay_exp_bound (L := L) hCv.le hβ hv t ht
      change |centeredDelay L (fun s => commandObservation C k Kp Ti Td Tf (z s)) t| ≤ E*Real.exp (-β*t) at hvd
      calc
        _ ≤ |outputDerivativeObservation A C (z t)| +
          R*|centeredDelay L (fun s => commandObservation C k Kp Ti Td Tf (z s)) t| := by
            simpa only [abs_mul] using abs_add_le
              (outputDerivativeObservation A C (z t))
              (((∑ j, C j*B j)/k)*centeredDelay L
                (fun s => commandObservation C k Kp Ti Td Tf (z s)) t)
        _ ≤ Ca*Real.exp (-β*t)+R*(E*Real.exp (-β*t)) := by
          exact add_le_add (ha t ht) (mul_le_mul_of_nonneg_left hvd (abs_nonneg _))
        _ = (Ca+R*E)*Real.exp (-β*t) := by ring


-- The zero extension is exact, not merely an equality almost everywhere.
omit [DecidableEq n] in
theorem stepImpulse_eq_indicator (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf L b c : ℝ) (q : ℝ → (n → ℝ) × ℝ × ℝ) :
    (Ioi (0 : ℝ)).indicator (stepImpulse A B C Kp Ti Td Tf L b c q) =
      stepImpulse A B C Kp Ti Td Tf L b c q := by
  funext t
  by_cases ht : 0<t
  · simp [ht]
  · simp [ht, stepImpulse, le_of_not_gt ht]

-- The stable ordinary impulse belongs to L¹ on the physical half-line.
omit [DecidableEq n] in
theorem stable_step_impulse_integrable
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0) (hL : 0 ≤ L)
    (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c)
    (heq : ∀ j, (∑ l, A j l*xInf l)+B j/k=0)
    (hout : (∑ j, C j*xInf j) = 1) :
    Integrable (stepImpulse A B C Kp Ti Td Tf L b c q) halfLine := by
  obtain ⟨Ce, Cg, β, _, _, hβ, _, hg⟩ := stable_step_impulse_decay h hTi hk hKp hL hs heq hout
  simpa only [pow_zero, one_mul] using
    polynomial_weight_integrable (stepImpulse_aestronglyMeasurable h) hβ hg 0

-- The same kernel belongs to the ordinary whole-line L¹ space used by the
-- positivity and frequency-response theorems.
omit [DecidableEq n] in
theorem stable_step_impulse_integrable_full
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0) (hL : 0 ≤ L)
    (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c)
    (heq : ∀ j, (∑ l, A j l*xInf l)+B j/k=0)
    (hout : (∑ j, C j*xInf j) = 1) :
    Integrable (stepImpulse A B C Kp Ti Td Tf L b c q) := by
  have hi := (integrable_indicator_iff measurableSet_Ioi).2
    (stable_step_impulse_integrable h hTi hk hKp hL hs heq hout)
  rwa [stepImpulse_eq_indicator] at hi

-- All whole-line kernel moments agree with the physical positive-time moments.
omit [DecidableEq n] in
theorem stepImpulse_moment_full_eq (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf L b c : ℝ) (q : ℝ → (n → ℝ) × ℝ × ℝ) (m : ℕ) :
    (∫ t, t^m*stepImpulse A B C Kp Ti Td Tf L b c q t) =
      ∫ t, t^m*stepImpulse A B C Kp Ti Td Tf L b c q t ∂halfLine := by
  have he : (Ioi (0 : ℝ)).indicator
      (fun t => t^m*stepImpulse A B C Kp Ti Td Tf L b c q t) =
      (fun t => t^m*stepImpulse A B C Kp Ti Td Tf L b c q t) := by
    funext t
    by_cases ht : 0<t
    · simp [ht]
    · simp [ht, stepImpulse, le_of_not_gt ht]
  change _ = ∫ t in Ioi 0, t^m*stepImpulse A B C Kp Ti Td Tf L b c q t
  rw [← integral_indicator measurableSet_Ioi, he]

-- Local absolute continuity of the physical tracking error.
omit [DecidableEq n] in
theorem step_error_locallyAC
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q) :
    ∀ T, 0 ≤ T → AbsolutelyContinuousOnInterval
      (fun t => 1-finitePlantOutput C (q t).1) 0 T := by
  intro T hT
  exact (ContDiffOn.absolutelyContinuousOnInterval (by fun_prop :
    ContDiffOn ℝ 1 (fun _ : ℝ => (1 : ℝ)) (uIcc 0 T))).sub
    (step_output_locallyAC h T hT)

-- Unit mass is a theorem of the physical equations and internal stability.
omit [DecidableEq n] in
theorem stable_step_impulse_unit_mass
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0) (hL : 0 ≤ L)
    (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c)
    (heq : ∀ j, (∑ l, A j l*xInf l)+B j/k=0)
    (hout : (∑ j, C j*xInf j) = 1) :
    (∫ t, stepImpulse A B C Kp Ti Td Tf L b c q t ∂halfLine) = 1 := by
  obtain ⟨Ce, Cg, β, _, _, hβ, he, _⟩ := stable_step_impulse_decay h hTi hk hKp hL hs heq hout
  apply impulse_unit_mass (step_error_locallyAC h) (step_error_ode h)
    (stable_step_impulse_integrable h hTi hk hKp hL hs heq hout)
  · simpa only [pow_zero, one_mul] using polynomial_weight_tendsto_zero hβ he 0
  · simp [h.initial, finitePlantOutput]

-- First and second impulse moments follow from the same actual state, without
-- positivity assumptions: these are signed identities before optimization.
theorem stable_step_impulse_moments
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0) (hTf : 0 < Tf) (hL : 0 ≤ L)
    (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c)
    (heq : ∀ j, (∑ l, A j l*xInf l)+B j/k=0)
    (hout : (∑ j, C j*xInf j) = 1) (hA : (pencil A 0).det ≠ 0) :
    (∫ t, t*stepImpulse A B C Kp Ti Td Tf L b c q t ∂halfLine) = meanTime Ti k Kp b ∧
    (∫ t, t^2*stepImpulse A B C Kp Ti Td Tf L b c q t ∂halfLine) =
      2*secondErrorMoment Kp (Kp/Ti) (Kp*Td) k (residenceTime A C xInf+L)
        (meanTime Ti k Kp b) c := by
  obtain ⟨Ce, Cg, β, _, _, hβ, he, hg⟩ := stable_step_impulse_decay h hTi hk hKp hL hs heq hout
  have hh := first_and_second_moments_of_exp_decay (step_error_locallyAC h)
    (step_error_ode h) (stepImpulse_aestronglyMeasurable h) hβ he hg
  rw [(stable_step_transfer_and_area h hTi hk hKp hL hs heq hout hA).2] at hh
  rw [stable_step_first_error_moment h hTi hk hKp hTf hL hs heq hout hA] at hh
  exact hh

-- All polynomial moments are absolutely integrable, not only the moments
-- which occur in the explicit first- and second-moment formulas.
omit [DecidableEq n] in
theorem stable_step_impulse_weight_integrable
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0) (hL : 0 ≤ L)
    (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c)
    (heq : ∀ j, (∑ l, A j l*xInf l)+B j/k=0)
    (hout : (∑ j, C j*xInf j) = 1) (m : ℕ) :
    Integrable (fun t => t^m*stepImpulse A B C Kp Ti Td Tf L b c q t) halfLine := by
  obtain ⟨Ce, Cg, β, _, _, hβ, _, hg⟩ := stable_step_impulse_decay h hTi hk hKp hL hs heq hout
  exact polynomial_weight_integrable (stepImpulse_aestronglyMeasurable h) hβ hg m

-- The actual physical output is exactly the cumulative kernel used by all
-- positivity, no-overshoot, and settling-time results.
omit [DecidableEq n] in
theorem stable_step_output_eq_kernelStep
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0) (hL : 0 ≤ L)
    (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c)
    (heq : ∀ j, (∑ l, A j l*xInf l)+B j/k=0)
    (hout : (∑ j, C j*xInf j) = 1) (T : ℝ) (hT : 0 ≤ T) :
    finitePlantOutput C (q T).1 = kernelStep (stepImpulse A B C Kp Ti Td Tf L b c q) T := by
  let g := stepImpulse A B C Kp Ti Td Tf L b c q
  have hi := stable_step_impulse_integrable_full h hTi hk hKp hL hs heq hout
  have hz : kernelStep g 0 = 0 := causal_kernel_step_zero (stepImpulse_causal A B C Kp Ti Td Tf L b c q) le_rfl
  rw [step_output_eq_impulse_integral h T hT]
  have hh := (intervalIntegral.integral_Iic_sub_Iic (a := (0 : ℝ)) (b := T) hi.integrableOn hi.integrableOn).symm
  change (∫ t in 0..T, g t) = kernelStep g T-kernelStep g 0 at hh
  simpa only [hz, sub_zero] using hh


-- Positive-time positivity is equivalent to whole-line positivity for this
-- causal physical kernel.
omit [DecidableEq n] in
theorem stepImpulse_nonnegative_full
    (A : Matrix n n ℝ) (B C : n → ℝ) (Kp Ti Td Tf L b c : ℝ)
    (q : ℝ → (n → ℝ) × ℝ × ℝ)
    (hg : ∀ᵐ t ∂halfLine, 0 ≤ stepImpulse A B C Kp Ti Td Tf L b c q t) :
    ∀ᵐ t, 0 ≤ stepImpulse A B C Kp Ti Td Tf L b c q t := by
  rw [halfLine, ae_restrict_iff' measurableSet_Ioi] at hg
  filter_upwards [hg] with t ht
  by_cases hpos : 0<t
  · exact ht hpos
  · simp [stepImpulse, le_of_not_gt hpos]

-- The physical output is monotone if and only if its derived ordinary impulse
-- is nonnegative; both directions refer to the implemented response.
omit [DecidableEq n] in
theorem stable_step_monotone_iff
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0) (hL : 0 ≤ L)
    (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c)
    (heq : ∀ j, (∑ l, A j l*xInf l)+B j/k=0)
    (hout : (∑ j, C j*xInf j) = 1) :
    MonotoneOn (fun t => finitePlantOutput C (q t).1) (Ici 0) ↔
      ∀ᵐ t ∂halfLine, 0 ≤ stepImpulse A B C Kp Ti Td Tf L b c q t := by
  let g := stepImpulse A B C Kp Ti Td Tf L b c q
  have hi := stable_step_impulse_integrable_full h hTi hk hKp hL hs heq hout
  have hc := stepImpulse_causal A B C Kp Ti Td Tf L b c q
  have hy := stable_step_output_eq_kernelStep h hTi hk hKp hL hs heq hout
  constructor
  · intro hm
    have hm' : Monotone (kernelStep g) := by
      intro s t hst
      by_cases ht : t≤0
      · rw [causal_kernel_step_zero hc ht, causal_kernel_step_zero hc (hst.trans ht)]
      · have ht' : 0≤t := le_of_lt (lt_of_not_ge ht)
        rw [← hy t ht']
        by_cases hs' : s≤0
        · rw [causal_kernel_step_zero hc hs']
          have hh := hm (show (0:ℝ) ∈ Ici 0 from by simp) ht' ht'
          simpa [h.initial, finitePlantOutput] using hh
        · have hs0 : 0≤s := le_of_lt (lt_of_not_ge hs')
          rw [← hy s hs0]
          exact hm hs0 ht' hst
    exact ae_restrict_of_ae ((kernel_step_monotone_iff hi).1 hm')
  · intro hg s hs0 t ht0 hst
    change finitePlantOutput C (q s).1 ≤ finitePlantOutput C (q t).1
    rw [hy s hs0, hy t ht0]
    exact positive_kernel_step_monotone hi
      (stepImpulse_nonnegative_full A B C Kp Ti Td Tf L b c q hg) hst

-- The unit-mass nonnegative kernel gives no overshoot of the actual output.
omit [DecidableEq n] in
theorem stable_step_positive_output_bounds
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0) (hL : 0 ≤ L)
    (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c)
    (heq : ∀ j, (∑ l, A j l*xInf l)+B j/k=0)
    (hout : (∑ j, C j*xInf j) = 1)
    (hg : ∀ᵐ t ∂halfLine, 0 ≤ stepImpulse A B C Kp Ti Td Tf L b c q t)
    (t : ℝ) (ht : 0≤t) :
    0 ≤ finitePlantOutput C (q t).1 ∧ finitePlantOutput C (q t).1 ≤ 1 := by
  have hm : (∫ s, stepImpulse A B C Kp Ti Td Tf L b c q s) = 1 := by
    have he := stepImpulse_moment_full_eq A B C Kp Ti Td Tf L b c q 0
    simp only [pow_zero, one_mul] at he
    rw [he]
    exact stable_step_impulse_unit_mass h hTi hk hKp hL hs heq hout
  rw [stable_step_output_eq_kernelStep h hTi hk hKp hL hs heq hout t ht]
  exact positive_kernel_step_bounds
    (stable_step_impulse_integrable_full h hTi hk hKp hL hs heq hout)
    (stepImpulse_nonnegative_full A B C Kp Ti Td Tf L b c q hg) hm t

-- The frequency norm is exactly one for every physically admissible positive
-- kernel.  The lower bound is attained at zero frequency.
omit [DecidableEq n] in
theorem stable_step_positive_hinf
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0) (hL : 0 ≤ L)
    (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c)
    (heq : ∀ j, (∑ l, A j l*xInf l)+B j/k=0)
    (hout : (∑ j, C j*xInf j) = 1)
    (hg : ∀ᵐ t ∂halfLine, 0 ≤ stepImpulse A B C Kp Ti Td Tf L b c q t) :
    kernelHinf (stepImpulse A B C Kp Ti Td Tf L b c q) = 1 := by
  apply positive_kernel_hinf_eq_one
    (stable_step_impulse_integrable_full h hTi hk hKp hL hs heq hout)
    (stepImpulse_causal A B C Kp Ti Td Tf L b c q)
    (stepImpulse_nonnegative_full A B C Kp Ti Td Tf L b c q hg)
  have he := stepImpulse_moment_full_eq A B C Kp Ti Td Tf L b c q 0
  simp only [pow_zero, one_mul] at he
  rw [he]
  exact stable_step_impulse_unit_mass h hTi hk hKp hL hs heq hout

-- The actual no-overshoot IAE equals the derived impulse mean and the affine
-- weight formula.  Kernel positivity supplies error positivity automatically.
theorem stable_step_positive_iae
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0) (hL : 0 ≤ L)
    (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c)
    (heq : ∀ j, (∑ l, A j l*xInf l)+B j/k=0)
    (hout : (∑ j, C j*xInf j) = 1) (hA : (pencil A 0).det ≠ 0)
    (hg : ∀ᵐ t ∂halfLine, 0 ≤ stepImpulse A B C Kp Ti Td Tf L b c q t) :
    absArea (fun t => 1-finitePlantOutput C (q t).1) halfLine = meanTime Ti k Kp b := by
  rw [← (stable_step_transfer_and_area h hTi hk hKp hL hs heq hout hA).2]
  apply integral_congr_ae
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  exact abs_of_nonneg (sub_nonneg.mpr
    (stable_step_positive_output_bounds h hTi hk hKp hL hs heq hout hg t (le_of_lt ht)).2)


-- A zero-input transport history forces an exactly zero impulse before the
-- pure delay, as proved from the finite-dimensional plant ODE.
omit [DecidableEq n] in
theorem stepImpulse_zero_before_delay
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (t : ℝ) (htL : t ≤ L) :
    stepImpulse A B C Kp Ti Td Tf L b c q t = 0 := by
  by_cases ht : t≤0
  · simp [stepImpulse, ht]
  · have hx := step_state_zero_before_delay h t ⟨le_of_lt (lt_of_not_ge ht), htL⟩
    simp [stepImpulse, ht, htL, hx]

-- The strict delay bound now applies to the actual physical impulse, not to a
-- separately supplied density or a first-moment hypothesis.
theorem stable_step_positive_mean_gt_delay
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0) (hTf : 0 < Tf) (hL : 0 ≤ L)
    (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c)
    (heq : ∀ j, (∑ l, A j l*xInf l)+B j/k=0)
    (hout : (∑ j, C j*xInf j) = 1) (hA : (pencil A 0).det ≠ 0)
    (hg : ∀ᵐ t ∂halfLine, 0 ≤ stepImpulse A B C Kp Ti Td Tf L b c q t) :
    L < meanTime Ti k Kp b := by
  have hi := stable_step_impulse_integrable h hTi hk hKp hL hs heq hout
  have hfirst : Integrable (fun t => t*stepImpulse A B C Kp Ti Td Tf L b c q t) halfLine := by
    simpa only [pow_one] using stable_step_impulse_weight_integrable h hTi hk hKp hL hs heq hout 1
  have hm := stable_step_impulse_unit_mass h hTi hk hKp hL hs heq hout
  have hd : ∀ᵐ t ∂halfLine, t<L → stepImpulse A B C Kp Ti Td Tf L b c q t=0 :=
    Eventually.of_forall (fun t ht => stepImpulse_zero_before_delay h t ht.le)
  have hh := kernel_mean_strictly_above_delay hi hfirst hg hm L hd
  rwa [(stable_step_impulse_moments h hTi hk hKp hTf hL hs heq hout hA).1] at hh

-- For a physical nonnegative ordinary impulse, its variance is strictly
-- positive; this sharpens the algebraic second-weight necessary condition.
theorem stable_step_positive_variance_weight_bound
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (hTi : 0 < Ti) (hk : k ≠ 0) (hKp : 0 < Kp) (hTd : 0 < Td)
    (hTf : 0 < Tf) (hL : 0 ≤ L)
    (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c)
    (heq : ∀ j, (∑ l, A j l*xInf l)+B j/k=0)
    (hout : (∑ j, C j*xInf j) = 1) (hA : (pencil A 0).det ≠ 0)
    (hg : ∀ᵐ t ∂halfLine, 0 ≤ stepImpulse A B C Kp Ti Td Tf L b c q t) :
    1+((Kp/Ti)*(meanTime Ti k Kp b)^2/2-
      (Kp+1/k)*meanTime Ti k Kp b+(residenceTime A C xInf+L)/k)/(Kp*Td) < c := by
  have hfirst : Integrable (fun t => t*stepImpulse A B C Kp Ti Td Tf L b c q t) halfLine := by
    simpa only [pow_one] using stable_step_impulse_weight_integrable
      h hTi.ne' hk hKp.ne' hL hs heq hout 1
  have hm := stable_step_impulse_moments h hTi.ne' hk hKp.ne' hTf hL hs heq hout hA
  exact kernel_variance_weight_bound_strict
    (stable_step_impulse_integrable h hTi.ne' hk hKp.ne' hL hs heq hout)
    hfirst (stable_step_impulse_weight_integrable h hTi.ne' hk hKp.ne' hL hs heq hout 2)
    hg (stable_step_impulse_unit_mass h hTi.ne' hk hKp.ne' hL hs heq hout)
    Kp (Kp/Ti) (Kp*Td) k (residenceTime A C xInf+L) (meanTime Ti k Kp b) c
    (div_pos hKp hTi) (mul_pos hKp hTd) hm.1 hm.2

-- The physical ITAE formula needs only impulse positivity; nonnegativity of
-- the error follows from the proved unit-mass no-overshoot bound.
theorem stable_step_positive_itae
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0) (hTf : 0 < Tf) (hL : 0 ≤ L)
    (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c)
    (heq : ∀ j, (∑ l, A j l*xInf l)+B j/k=0)
    (hout : (∑ j, C j*xInf j) = 1) (hA : (pencil A 0).det ≠ 0)
    (hg : ∀ᵐ t ∂halfLine, 0 ≤ stepImpulse A B C Kp Ti Td Tf L b c q t) :
    (∫ t, t*|1-finitePlantOutput C (q t).1| ∂halfLine) =
      secondErrorMoment Kp (Kp/Ti) (Kp*Td) k (residenceTime A C xInf+L)
        (meanTime Ti k Kp b) c := by
  apply stable_step_itae h hTi hk hKp hTf hL hs heq hout hA
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  exact sub_nonneg.mpr
    (stable_step_positive_output_bounds h hTi hk hKp hL hs heq hout hg t (le_of_lt ht)).2

end Article14
