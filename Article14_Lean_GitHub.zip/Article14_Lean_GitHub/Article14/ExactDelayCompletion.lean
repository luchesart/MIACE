import Article14.ExactDelayStability
import Article14.ExactDelayOrdering

/-!
# The exact delayed physical example: final article statements

The data below are the actual two-lag plant and shared PIDF implementation.
Their internal stability is proved for every continuous full-state history;
none of the statements asks for a stability or input/output certificate.
Only the two reference weights vary along the displayed q-path.
-/
namespace Article14.ExactDelay
open MeasureTheory Filter Set MIACE
open scoped Topology

-- @article14 thm:exact-delay-example/physical_positive_family
/-- Every admitted q gives an actual monotone, nonovershooting step and a
nonnegative normalized command deviation, with reference H∞ norm one. -/
theorem exact_delay_physical_family {q : ℝ} (hq : q ∈ Icc (13/16:ℝ) 1) :
    pathWeights q ∈ Icc ((0:ℝ),0) (1,1) ∧
    Monotone (exampleData.output (pathWeights q)) ∧
    exampleData.output (pathWeights q) 0 = 0 ∧
    Tendsto (exampleData.output (pathWeights q)) atTop (𝓝 1) ∧
    (∀ t, 0 ≤ exampleData.output (pathWeights q) t ∧
      exampleData.output (pathWeights q) t ≤ 1) ∧
    (∀ t, 0 ≤ t → 0 ≤ exampleData.command (pathWeights q) t) ∧
    kernelHinf (exampleData.kernel (pathWeights q)) = 1 := by
  have hq0 : q ∈ Icc (0:ℝ) 1 := ⟨by linarith [hq.1],hq.2⟩
  have hw := weights_in_box hq
  refine ⟨⟨⟨hw.1.1,hw.2.1⟩,⟨hw.1.2,hw.2.2⟩⟩,
    physical_path_monotone exact_shared_internal_stability hq0,
    (physical_path_initial_and_limit exact_shared_internal_stability hq0).1,
    (physical_path_initial_and_limit exact_shared_internal_stability hq0).2,
    physical_path_output_bounds exact_shared_internal_stability hq0,
    physical_path_command_nonnegative exact_shared_internal_stability hq.1,
    physical_path_hinf exact_shared_internal_stability hq0⟩

-- @article14 thm:exact-delay-example/actual_absolute_areas
/-- Both absolute areas are evaluated on the implemented physical response. -/
theorem exact_delay_physical_areas {q : ℝ} (hq : q ∈ Icc (13/16:ℝ) 1) :
    exampleData.iae (pathWeights q) = 43/16-q ∧
      absArea (exampleData.command (pathWeights q)) halfLine = q-7/16 := by
  exact ⟨physical_path_iae exact_shared_internal_stability ⟨by linarith [hq.1],hq.2⟩,
    physical_path_command_area exact_shared_internal_stability hq.1⟩

-- @article14 thm:exact-delay-example/actual_reference_impulse
/-- The explicit positive resolvent kernel is the actual physical impulse,
and integrating it gives the physical output at every real time. -/
theorem exact_delay_reference_impulse {q : ℝ} (hq : q ∈ Icc (0:ℝ) 1) :
    exampleData.kernel (pathWeights q) =ᵐ[halfLine]
      referenceImpulse q canonicalResolvent ∧
    ∀ t, exampleData.output (pathWeights q) t =
      ∫ s in 0..t, referenceImpulse q canonicalResolvent s := by
  exact ⟨physical_kernel_eq_reference exact_shared_internal_stability hq,
    physical_output_eq_reference_integral exact_shared_internal_stability hq⟩

-- @article14 thm:exact-delay-example/actual_time_prefilter
/-- The scalar low-pass relation describes the actual physical output. -/
theorem exact_delay_time_prefilter (q t : ℝ) (ht : 0 ≤ t) :
    exampleData.output (pathWeights q) t =
      q*exampleData.output (pathWeights 1) t +
        (1-q)*lag 1 (exampleData.output (pathWeights 1)) t :=
  physical_path_prefilter exact_shared_internal_stability q t ht

-- @article14 thm:exact-delay-example/actual_pointwise_order
/-- Increasing q improves the actual output at every nonnegative time. -/
theorem exact_delay_pointwise_order {q₁ q₂ : ℝ} (hq : q₁ ≤ q₂)
    (t : ℝ) (ht : 0 ≤ t) :
    exampleData.output (pathWeights q₁) t ≤
      exampleData.output (pathWeights q₂) t :=
  physical_path_output_order exact_shared_internal_stability hq t ht

-- @article14 thm:exact-delay-example/global_physical_MIACE
/-- The physical q*(α) response attains the global MIACE lower bound,
including competitors outside the PIDF reference-weight family. -/
theorem exact_delay_global_miace {α : ℝ} (hα : α ∈ Icc (3:ℝ) 5) :
    miace α (exampleData.error (pathWeights (optimalQ α)))
      (exampleData.command (pathWeights (optimalQ α))) halfLine =
      (9/4)*Real.sqrt (α/(1+α)) ∧
    ∀ e' v' : ℝ → ℝ,
      TransferResponse e' v' (cascadeTransfer (rationalCascadeTimes (fun _ => 1)) 2) (1/4) →
      miace α (exampleData.error (pathWeights (optimalQ α)))
        (exampleData.command (pathWeights (optimalQ α))) halfLine ≤
        miace α e' v' halfLine :=
  physical_global_miace exact_shared_internal_stability hα

-- @article14 thm:exact-delay-example/global_full_box_IAE
/-- The q=1 endpoint attains 27/16 and minimizes actual IAE throughout the
whole weight box, even allowing competitors whose output overshoots. -/
theorem exact_delay_global_iae :
    pathWeights 1 = ((1:ℝ),1) ∧
    pathWeights 1 ∈ exampleData.feasible (Icc ((0:ℝ),0) (1,1)) ∧
    exampleData.iae (pathWeights 1) = 27/16 ∧
    ∀ w ∈ Icc ((0:ℝ),0) (1,1),
      exampleData.iae (pathWeights 1) ≤ exampleData.iae w := by
  exact ⟨Prod.ext endpoint_weights.1 endpoint_weights.2,
    (physical_endpoint_global_iae exact_shared_internal_stability).1,
    physical_endpoint_global_box_iae exact_shared_internal_stability⟩

end Article14.ExactDelay
