import Article14.DelayParameters
import Article14.PositiveKernel
import MIACE.AllOrdersCompletion

/-! Article 14, Theorem 18: reuse the previous article's ordinary resolvent,
actual delayed plant, and all-history rational-controller stability theorem.
The shared PIDF storage-coordinate equivalence is a separate obligation;
the rational realization is not silently identified with another state model. -/
namespace Article14.ExactDelay
open MIACE MeasureTheory Filter Set Polynomial
open scoped Topology Convolution

noncomputable def J : ℝ → ℝ := remainderJ (fun _ => 1) 0 (1 / 4)

-- Article 14, Theorem 18: the old construction uses precisely the displayed exponential kernel.
theorem J_formula (t : ℝ) : J t = E * Real.exp (-t) := by
  rw [J, equal_remainderJ]
  simp only [pow_zero, Nat.factorial_zero, Nat.cast_one, div_one, mul_one]
  rw [E, ← Real.exp_add]
  congr 1

theorem J_continuous : Continuous J := remainderJ_continuous _ 0 _

theorem J_nonneg (t : ℝ) : 0 ≤ J t := by
  rw [J_formula]
  exact mul_nonneg (Real.exp_nonneg _) (Real.exp_nonneg _)

-- Article 14, Theorem 18: actual integral moments, obtained from the previous exact remainder theorem.
theorem J_moment_zero : compactMoment J (1 / 4) 0 = E - 1 := by
  have h := remainderI_zero (fun _ => 1) 0 (1 / 4) (by intros; norm_num)
  norm_num [remainderI, rationalCascadeC] at h
  dsimp [J, E]
  linarith

theorem J_moment_one : compactMoment J (1 / 4) 1 = E - 5 / 4 := by
  have h := remainderI_derivative_zero (fun _ => 1) 0 (1 / 4) (by intros; norm_num)
  have h0 := J_moment_zero
  change compactMoment (remainderJ (fun _ => 1) 0 (1 / 4)) (1 / 4) 0 = E - 1 at h0
  norm_num [remainderI, remainderB] at h
  change compactMoment (remainderJ (fun _ => 1) 0 (1 / 4)) (1 / 4) 1 = E - 5 / 4
  linarith

theorem cascade_a : rationalCascadeA (fun _ => 1) 0 (1 / 4) (9 / 16) = a := by
  simp only [rationalCascadeA, zero_add, pow_one, neg_mul, one_mul]
  change 1 - 9 / 16 - compactMoment J (1 / 4) 1 = a
  rw [J_moment_one]
  dsimp [a, d]
  ring

theorem cascade_c : rationalCascadeC (fun _ => 1) 0 (1 / 4) = E := by
  simp only [rationalCascadeC, zero_add, pow_one, neg_mul, one_mul]
  change 1 - -compactMoment J (1 / 4) 0 = E
  rw [J_moment_zero]
  ring

theorem controller_polynomial :
    rationalCascadeQ (fun _ => 1) 0 (1 / 4) (9 / 16) = X * (C a * X + C d) := by
  rw [rationalCascadeQ, cascade_a, cascade_c]
  simp only [remainderB, one_div_one, map_one, one_mul, remainderI]
  change (X + 1) * (C a * X + C E) - C E = X * (C a * X + C d)
  have he : E = d - a := by dsimp [a]; ring
  rw [he, map_sub]
  ring

-- Article 14, Theorem 18: the actual complex delay identity includes every complex frequency.
theorem characteristic_factorization (s : ℂ) :
    s * ((a : ℂ) * s + d) + Complex.exp (-(1 / 4 : ℂ) * s) =
      (1 + s) * ((a : ℂ) * s + E - compactLaplace J (1 / 4) s) := by
  have h := rationalCascade_factorization (fun _ => 1) 0 (1 / 4) (9 / 16)
    (by intros; norm_num) s
  rw [controller_polynomial, cascade_a, cascade_c] at h
  simpa [remainderB, J, add_comm, sub_eq_add_neg] using h

-- Article 14, Theorem 18: this is the full old physical theorem at the q=1 endpoint.
theorem baseline_attainment : CascadeAttainment (fun _ => 1) 0 (1 / 4) 3 := by
  convert (paper_all_orders_attainment 0 (δ := (1 / 4 : ℝ))
    (by norm_num) (by norm_num)).2
  norm_num

theorem baseline_internal_stability :
    RationalInternallyStable (fun _ => 1) 0 (1 / 4) a E := by
  have h := baseline_attainment.1
  norm_num at h
  simpa only [cascade_a, cascade_c] using h

-- Article 14, Theorem 18: the exponential weighted tail is small enough for every q in the path.
theorem gamma_bound : E / a * (1 / 4) < 4 / 5 := by
  have ha : 0 < a := lt_trans (by norm_num) a_bounds.1
  have h : E / a < 16 / 5 := by
    apply (div_lt_iff₀ ha).mpr
    have he := exp_bounds.2
    dsimp [a, d]
    linarith
  linarith

theorem weighted_tail_bound :
    compactExpMoment (compactTail J (1 / 4)) (1 / 4) (E / a) < 3 / 28 := by
  have ha : 0 < a := lt_trans (by norm_num) a_bounds.1
  have hγ : 0 ≤ E / a := div_nonneg (Real.exp_nonneg _) ha.le
  have hb := compactTail_exp_bound J_continuous (by norm_num : (0 : ℝ) ≤ 1 / 4)
    hγ (fun t _ => J_nonneg t)
  have he : Real.exp (E / a * (1 / 4)) ≤ 3 :=
    (Real.exp_le_exp.mpr (gamma_bound.le.trans (by norm_num))).trans uniform_exp_bounds.2.le
  have hj : 0 ≤ compactMoment J (1 / 4) 1 := by
    rw [J_moment_one]
    linarith [exp_bounds.1]
  have hm := mul_le_mul_of_nonneg_right he hj
  rw [J_moment_one] at hb hm
  nlinarith [exp_bounds.2]

theorem command_margin {q : ℝ} (hq : 13 / 16 ≤ q) :
    15 / 56 < q - a - compactExpMoment (compactTail J (1 / 4)) (1 / 4) (E / a) := by
  linarith [a_bounds.2, weighted_tail_bound]

-- Article 14, Theorem 18: the extended command sign is a time-domain result for the actual resolvent.
theorem command_nonnegative {R : ℝ → ℝ}
    (hR : CompactResolventEvolution J (1 / 4) a E (-1) R)
    (hn : ∀ t, 0 ≤ t → 0 ≤ R t) {q : ℝ} (hq : 13 / 16 ≤ q) {t : ℝ} (ht : 0 ≤ t) :
    0 ≤ (q - a) * R t - (compactKernel (compactTail J (1 / 4)) (1 / 4) ⋆ causalize R) t := by
  have ha : 0 < a := lt_trans (by norm_num) a_bounds.1
  have hb := even_resolvent_tail_bound J_continuous (by norm_num) ha
    (fun t _ => J_nonneg t) hR hn ht
  have hm := mul_nonneg (show 0 ≤ q - a -
      compactExpMoment (compactTail J (1 / 4)) (1 / 4) (E / a) by
      linarith [command_margin hq]) (hn t ht)
  nlinarith

noncomputable def shapedCommand (q : ℝ) (R : ℝ → ℝ) : ℝ → ℝ :=
  cascadeCommand J (1 / 4) (1 + a - q) (-1) R

noncomputable def filteredResolvent (q : ℝ) (R : ℝ → ℝ) (t : ℝ) : ℝ :=
  q * R t + (1 - q) * lag 1 R t

-- Article 14, Theorem 18: linearity is applied only after checking actual signal integrability.
theorem half_laplace_linear {f g : ℝ → ℝ} (hf : Integrable f halfLine)
    (hg : Integrable g halfLine) (x y : ℝ) {p : ℝ} (hp : 0 ≤ p) :
    laplace (fun t => x * f t + y * g t) p = x * laplace f p + y * laplace g p := by
  unfold laplace
  have he : (fun t => Real.exp (-p*t)*(x*f t+y*g t)) =
      (fun t => x*(Real.exp (-p*t)*f t)+y*(Real.exp (-p*t)*g t)) := by
    funext t
    ring
  rw [he, integral_add ((laplace_integrable hf hp).const_mul x)
    ((laplace_integrable hg hp).const_mul y), integral_const_mul, integral_const_mul]

theorem filtered_resolvent_properties {R : ℝ → ℝ} (hc : Continuous R)
    (hi : Integrable (causalize R)) (hn : ∀ t, 0 ≤ t → 0 ≤ R t)
    (hm : (∫ t, R t ∂halfLine) = 1) {q : ℝ} (hq : q ∈ Icc (0 : ℝ) 1) :
    Continuous (filteredResolvent q R) ∧ Integrable (causalize (filteredResolvent q R)) ∧
    (∀ t, 0 ≤ t → 0 ≤ filteredResolvent q R t) ∧
    (∫ t, filteredResolvent q R t ∂halfLine) = 1 ∧
    ∀ p : ℝ, 0 ≤ p → (1 + p) * laplace (filteredResolvent q R) p =
      (1 + q * p) * laplace R p := by
  have hRh : Integrable R halfLine := by
    apply (hi.mono_measure Measure.restrict_le_self).congr
    exact representative_halfLine_ae (EventuallyEq.rfl (f := causalize R))
  have hli := lag_integrable hRh (by norm_num : (0 : ℝ) < 1)
  have hlinear (p : ℝ) (hp : 0 ≤ p) :
      laplace (filteredResolvent q R) p = q * laplace R p +
        (1-q) * (laplace R p / (1+p)) := by
    change laplace (fun t => q * R t + (1-q) * lag 1 R t) p = _
    rw [half_laplace_linear hRh hli q (1-q) hp,
      lag_laplace hRh (by norm_num) hp]
    simp
  refine ⟨(hc.const_mul q).add ((lag_continuous hc 1).const_mul (1-q)),
    causalize_integrable ((hRh.const_mul q).add (hli.const_mul (1-q))), ?_, ?_, ?_⟩
  · intro t ht
    have hl : 0 ≤ lag 1 R t := by
      unfold lag
      apply mul_nonneg (by positivity)
      exact intervalIntegral.integral_nonneg ht
        (fun s hs => mul_nonneg (Real.exp_nonneg _) (hn s hs.1))
    exact add_nonneg (mul_nonneg hq.1 (hn t ht)) (mul_nonneg (sub_nonneg.mpr hq.2) hl)
  · have hh := hlinear 0 (by norm_num)
    simp only [laplace, neg_zero, zero_mul, Real.exp_zero, one_mul] at hh
    rw [hm] at hh
    norm_num at hh
    linarith
  · intro p hp
    rw [hlinear p hp]
    have hd : 1 + p ≠ 0 := by linarith
    field_simp
    ring

-- Article 14, Theorem 18: one ordinary positive resolvent serves every reference weight.
theorem common_resolvent_exists :
    ∃ R : ℝ → ℝ, CompactResolventEvolution J (1 / 4) a E (-1) R ∧
      Integrable (causalize R) ∧ (∀ t, 0 ≤ t → 0 ≤ R t) ∧
      (∫ t, R t ∂halfLine) = 1 ∧
      ∀ p : ℝ, 0 ≤ p →
        (a*p + E - compactExpMoment J (1 / 4) (-p)) * laplace R p = 1 := by
  obtain ⟨ha, ha1, hpar⟩ := equal_uniform_conditions 0 (δ := (1 / 4 : ℝ))
    (by norm_num) (by norm_num)
  norm_num at ha ha1 hpar
  obtain ⟨R, hR, hi, _, hn, hm, hT, _⟩ :=
    rationalCascade_resolvent_and_command (fun _ => 1) 0 (U := (9 / 16 : ℝ))
      (by intros; norm_num) (by norm_num) ha ha1 (by simpa using hpar)
  rw [cascade_a, cascade_c] at hR hT
  refine ⟨R, ?_, hi, hn, hm, ?_⟩
  · simpa [J] using hR
  · intro p hp
    simpa [J, sub_eq_add_neg] using hT p hp

-- Article 14, Theorem 18: construct actual delayed two-lag plant signals for the entire q interval.
theorem continuum_signals {q : ℝ} (hq : q ∈ Icc (13 / 16 : ℝ) 1) :
    ∃ R v : ℝ → ℝ,
      v = causalize (shapedCommand q R) ∧ Integrable v ∧
      TransferResponse (rationalCascadeError (fun _ => 1) 0 (1 / 4) v) v
        (cascadeTransfer (rationalCascadeTimes (fun _ => 1)) 2) (1 / 4) ∧
      (∀ t, 0 ≤ t → 0 ≤ v t ∧
        0 ≤ rationalCascadeError (fun _ => 1) 0 (1 / 4) v t) ∧
      Monotone (fun t => 1 - rationalCascadeError (fun _ => 1) 0 (1 / 4) v t) ∧
      1 - rationalCascadeError (fun _ => 1) 0 (1 / 4) v 0 = 0 ∧
      Tendsto (fun t => 1 - rationalCascadeError (fun _ => 1) 0 (1 / 4) v t) atTop (𝓝 1) ∧
      absArea v halfLine = commandArea q ∧
      absArea (rationalCascadeError (fun _ => 1) 0 (1 / 4) v) halfLine = errorArea q ∧
      (∀ p : ℝ, 0 < p → (1 + q*p) * laplace R p = 1 + p * laplace v p) ∧
      ∀ p : ℝ, 0 ≤ p →
        (a*p + E - compactExpMoment J (1 / 4) (-p)) * laplace R p = 1 := by
  obtain ⟨R, hR, hi, hn, hm, hT⟩ := common_resolvent_exists
  let V := shapedCommand q R
  let v := causalize V
  obtain ⟨hVi, hVm⟩ := cascadeCommand_integral J_continuous
    (by norm_num : (0 : ℝ) ≤ 1 / 4) (1+a-q) (-1) hi hm
  change Integrable V halfLine at hVi
  have hv : Integrable v := causalize_integrable hVi
  have hVn (t : ℝ) (ht : 0 ≤ t) : 0 ≤ V t := by
    have hh := command_nonnegative hR hn hq.1 ht
    dsimp [V, shapedCommand, cascadeCommand]
    convert hh using 1 <;> ring
  have hvn (t : ℝ) (ht : 0 ≤ t) : 0 ≤ v t := by
    simpa [v, causalize, ht] using hVn t ht
  have heq : v =ᵐ[halfLine] V := representative_halfLine_ae (EventuallyEq.rfl (f := v))
  have htrans (p : ℝ) (hp : 0 < p) : (1+q*p)*laplace R p = 1+p*laplace v p := by
    rw [laplace_congr_halfLine heq]
    change (1+q*p)*laplace R p = 1+p*laplace (cascadeCommand J (1/4) (1+a-q) (-1) R) p
    rw [cascadeCommand_laplace J_continuous (by norm_num) (1+a-q) (-1) hi hp.le]
    have ht := hT p hp.le
    have htail := compactTail_exp_identity J_continuous (1/4) (-p)
    rw [J_moment_zero] at htail
    linear_combination ht - laplace R p * htail
  have hqp : q ∈ Icc (0 : ℝ) 1 := ⟨by linarith [hq.1], hq.2⟩
  obtain ⟨hQc, hQi, hQn, hQm, hQT⟩ := filtered_resolvent_properties hR.continuous hi hn hm hqp
  have hQtrans (p : ℝ) (hp : 0 < p) :
      (1+p)*laplace (filteredResolvent q R) p = 1+p*laplace v p := by
    rw [hQT p hp.le, htrans p hp]
  have hh := resolvent_cascade_output 1 (rationalCascadeTimes (fun _ => 1))
    (by norm_num : (0 : ℝ) ≤ 1 / 4)
    (rationalCascadeTimes_pos (fun _ => 1) 0 (by intros; norm_num)) rfl
    hQc hQi hQn hQm hv hvn hQtrans
  have hav : absArea v halfLine = commandArea q := by
    unfold absArea
    have he : (∫ t, |v t| ∂halfLine) = ∫ t, V t ∂halfLine := by
      apply integral_congr_ae
      filter_upwards [heq, ae_restrict_mem measurableSet_Ioi] with t ht ht0
      rw [ht, abs_of_nonneg (hVn t (show 0<t from ht0).le)]
    rw [he]
    change (∫ t, V t ∂halfLine) = _ at hVm ⊢
    rw [hVm, J_moment_one]
    dsimp [commandArea, a, d]
    ring
  refine ⟨R, v, rfl, hv, hh.1, ?_, hh.2.2.1, hh.2.2.2.1,
    hh.2.2.2.2.1, hav, ?_, htrans, hT⟩
  · intro t ht
    exact ⟨hvn t ht, hh.2.1 t ht⟩
  · have he := hh.2.2.2.2.2
    rw [rationalCascadeMean, hav] at he
    norm_num at he
    dsimp [rationalCascadeError, errorArea, commandArea] at he ⊢
    linarith

-- Article 14, Theorem 18: the optimum is global over all admissible plant responses,
-- not merely over the one-dimensional q path. The comparison is the previous MIACE theorem.
theorem continuum_global_miace {α : ℝ} (hα : α ∈ Icc (3 : ℝ) 5) :
    ∃ R v : ℝ → ℝ,
      v = causalize (shapedCommand (optimalQ α) R) ∧ Integrable v ∧
      TransferResponse (rationalCascadeError (fun _ => 1) 0 (1 / 4) v) v
        (cascadeTransfer (rationalCascadeTimes (fun _ => 1)) 2) (1 / 4) ∧
      (∀ t, 0 ≤ t → 0 ≤ v t ∧
        0 ≤ rationalCascadeError (fun _ => 1) 0 (1 / 4) v t) ∧
      Monotone (fun t => 1 - rationalCascadeError (fun _ => 1) 0 (1 / 4) v t) ∧
      absArea v halfLine = 9 / (4 * (1 + α)) ∧
      absArea (rationalCascadeError (fun _ => 1) 0 (1 / 4) v) halfLine =
        9 * α / (4 * (1 + α)) ∧
      miace α (rationalCascadeError (fun _ => 1) 0 (1 / 4) v) v halfLine =
        (9 / 4) * Real.sqrt (α / (1 + α)) ∧
      ∀ e' v' : ℝ → ℝ,
        TransferResponse e' v' (cascadeTransfer (rationalCascadeTimes (fun _ => 1)) 2) (1 / 4) →
        miace α (rationalCascadeError (fun _ => 1) 0 (1 / 4) v) v halfLine ≤
          miace α e' v' halfLine := by
  have hαp : 0 < α := by linarith [hα.1]
  obtain ⟨R, v, hdef, hvi, hP, hn, hmono, _, _, hva, hea, _⟩ :=
    continuum_signals (optimalQ_in_interval hα)
  have hbal : (∫ t, rationalCascadeError (fun _ => 1) 0 (1 / 4) v t ∂halfLine) +
      (∫ t, v t ∂halfLine) = 9 / 4 := by
    have hh := transfer_signed_balance hP
      (cascadeMean (rationalCascadeTimes (fun _ => 1)) 2)
      (cascadeTransfer_derivative _ _) (cascadeTransfer_zero _ _)
    norm_num [cascadeMean, Finset.sum_range_succ, rationalCascadeTimes] at hh
    exact hh
  rw [(optimal_areas hαp).2] at hva
  rw [(optimal_areas hαp).1] at hea
  have hcost : miace α (rationalCascadeError (fun _ => 1) 0 (1 / 4) v) v halfLine =
      (9 / 4) * minimum α := by
    apply (signal_miace_equality_iff hP.error_integrable hP.command_integrable
      α (9 / 4) hαp (by norm_num) hbal).mpr
    refine ⟨?_, ?_, ?_⟩
    · filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
      exact (hn t (show 0<t from ht).le).2
    · filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
      exact (hn t (show 0<t from ht).le).1
    · rw [hea, hva]
      ring
  refine ⟨R, v, hdef, hvi, hP, hn, hmono, hva, hea, hcost, ?_⟩
  intro e' v' hP'
  rw [hcost]
  apply signal_miace_lower_bound hP'.error_integrable hP'.command_integrable
    α (9 / 4) hαp (by norm_num)
  have hh := transfer_signed_balance hP'
    (cascadeMean (rationalCascadeTimes (fun _ => 1)) 2)
    (cascadeTransfer_derivative _ _) (cascadeTransfer_zero _ _)
  norm_num [cascadeMean, Finset.sum_range_succ, rationalCascadeTimes] at hh
  exact hh

-- Article 14, Theorem 18: real-axis factorization follows from the actual compact-kernel transform.
theorem real_characteristic_factorization (p : ℝ) :
    p * (a*p + d) + Real.exp (-(1/4)*p) =
      (1+p) * (a*p + E - compactExpMoment J (1/4) (-p)) := by
  have he := exact_delay_remainder_real (fun _ => 1) 0 (1/4) p
    (by intros; norm_num)
  norm_num [remainderI, remainderB, remainderTransform] at he
  have he' : Real.exp (-(1/4)*p) = E - (p+1)*compactExpMoment J (1/4) (-p) := by
    dsimp [E, J, compactExpMoment]
    simp only [neg_mul] at he ⊢
    linear_combination he
  rw [he']
  dsimp [a]
  ring

-- Article 14, Theorem 18: actual signals satisfy the fixed-feedback/varying-reference controller.
-- The denominator is the same p(ap+d) for every q, with the exact polynomial Cr numerator.
theorem reference_controller_equation {q : ℝ} {R v : ℝ → ℝ}
    (hP : TransferResponse (rationalCascadeError (fun _ => 1) 0 (1/4) v) v
      (cascadeTransfer (rationalCascadeTimes (fun _ => 1)) 2) (1/4))
    (htrans : ∀ p : ℝ, 0 < p → (1+q*p)*laplace R p = 1+p*laplace v p)
    (hInv : ∀ p : ℝ, 0 ≤ p →
      (a*p + E - compactExpMoment J (1/4) (-p))*laplace R p = 1)
    (p : ℝ) (hp : 0 < p) :
    p*(a*p+d)*laplace (fun t => 1+v t) p =
      (1+p)^2*laplace (rationalCascadeError (fun _ => 1) 0 (1/4) v) p -
        (1-q)*(1+p) := by
  have hp1 : 1+p ≠ 0 := by linarith
  have hfac := real_characteristic_factorization p
  have hres : (p*(a*p+d)+Real.exp (-(1/4)*p))*laplace R p = 1+p := by
    rw [hfac, mul_assoc, hInv p hp.le, mul_one]
  have hcmd := htrans p hp
  have herr := transfer_error_identity hP p hp
  have hc : cascadeTransfer (rationalCascadeTimes (fun _ => 1)) 2 p = 1/(1+p)^2 := by
    have hh := rationalCascadeTransfer (fun _ => 1) 0 p
    simpa [remainderB, pow_two, add_comm] using hh
  rw [hc] at herr
  have heq : p*(1+p)^2*laplace (rationalCascadeError (fun _ => 1) 0 (1/4) v) p =
      (1+p)^2-Real.exp (-(1/4)*p)*(1+p*laplace v p) := by
    field_simp [ne_of_gt hp, hp1] at herr ⊢
    nlinarith [herr]
  rw [(laplace_step_add hP.command_integrable hp).2]
  have hmain : (p*(a*p+d)+Real.exp (-(1/4)*p))*(1+p*laplace v p) =
      (1+p)*(1+q*p) := by
    linear_combination (1+q*p)*hres - (p*(a*p+d)+Real.exp (-(1/4)*p))*hcmd
  have hzero : p * ((a*p+d)*(1+p*laplace v p) -
      ((1+p)^2*laplace (rationalCascadeError (fun _ => 1) 0 (1/4) v) p - (1-q)*(1+p))) = 0 := by
    linear_combination hmain - heq
  have hz := (mul_eq_zero.mp hzero).resolve_left (ne_of_gt hp)
  field_simp [ne_of_gt hp]
  linear_combination hz

-- Article 14, Theorem 18: the constructed monotone continuum satisfies that controller identity.
theorem continuum_controller {q : ℝ} (hq : q ∈ Icc (13/16 : ℝ) 1) :
    ∃ R v : ℝ → ℝ,
      v = causalize (shapedCommand q R) ∧
      TransferResponse (rationalCascadeError (fun _ => 1) 0 (1/4) v) v
        (cascadeTransfer (rationalCascadeTimes (fun _ => 1)) 2) (1/4) ∧
      (∀ t, 0 ≤ t → 0 ≤ v t ∧ 0 ≤ rationalCascadeError (fun _ => 1) 0 (1/4) v t) ∧
      Monotone (fun t => 1-rationalCascadeError (fun _ => 1) 0 (1/4) v t) ∧
      absArea v halfLine = commandArea q ∧
      absArea (rationalCascadeError (fun _ => 1) 0 (1/4) v) halfLine = errorArea q ∧
      ∀ p : ℝ, 0 < p → p*(a*p+d)*laplace (fun t => 1+v t) p =
        (1+p)^2*laplace (rationalCascadeError (fun _ => 1) 0 (1/4) v) p - (1-q)*(1+p) := by
  obtain ⟨R,v,hdef,_,hP,hn,hm,_,_,hv,he,hT,hInv⟩ := continuum_signals hq
  exact ⟨R,v,hdef,hP,hn,hm,hv,he,reference_controller_equation hP hT hInv⟩

noncomputable def referenceImpulse (q : ℝ) (R : ℝ → ℝ) : ℝ → ℝ :=
  shift (1/4) (lagKernel 1 ⋆ causalize (filteredResolvent q R))

-- Article 14, Theorem 18: the actual delayed convolution impulse has norm exactly one.
theorem reference_impulse_properties {R : ℝ → ℝ} (hc : Continuous R)
    (hi : Integrable (causalize R)) (hn : ∀ t, 0 ≤ t → 0 ≤ R t)
    (hm : (∫ t, R t ∂halfLine) = 1) {q : ℝ} (hq : q ∈ Icc (0 : ℝ) 1) :
    Integrable (referenceImpulse q R) ∧ Causal (referenceImpulse q R) ∧
    (∀ t, 0 ≤ referenceImpulse q R t) ∧ (∫ t, referenceImpulse q R t) = 1 ∧
    Article14.kernelHinf (referenceImpulse q R) = 1 ∧
    ∀ p : ℝ, 0 ≤ p → (1+p)^2*laplace (referenceImpulse q R) p =
      Real.exp (-(1/4)*p)*(1+q*p)*laplace R p := by
  obtain ⟨_, hQi, hQn, hQm, hQT⟩ := filtered_resolvent_properties hc hi hn hm hq
  obtain ⟨hli, hln, hlm, hlc⟩ := lagKernel_properties (by norm_num : (0 : ℝ) < 1)
  have hQna : ∀ᵐ t, 0 ≤ causalize (filteredResolvent q R) t := by
    apply ae_of_all
    intro t
    by_cases ht : 0 ≤ t
    · simpa [causalize, ht] using hQn t ht
    · simp [causalize, ht]
  have hcn : ∀ t, 0 ≤ (lagKernel 1 ⋆ causalize (filteredResolvent q R)) t :=
    convolution_pointwise_nonneg (ae_of_all _ hln) hQna
  have hci := hli.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hQi
  have hcc : Causal (lagKernel 1 ⋆ causalize (filteredResolvent q R)) :=
    ae_of_all _ (convolution_causal hlc (causalize_causal _))
  have hgi : Integrable (referenceImpulse q R) := shift_integrable _ hci
  have hgc : Causal (referenceImpulse q R) := causal_shift hcc (by norm_num)
  have hgn : ∀ t, 0 ≤ referenceImpulse q R t := fun t => hcn (t-1/4)
  have hgm : (∫ t, referenceImpulse q R t) = 1 := by
    change (∫ t, (lagKernel 1 ⋆ causalize (filteredResolvent q R)) (t-1/4)) = 1
    rw [integral_sub_right_eq_self, integral_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hli hQi,
      hlm, causalize_integral, hQm]
    norm_num
  refine ⟨hgi, hgc, hgn, hgm,
    Article14.positive_kernel_hinf_eq_one hgi hgc (ae_of_all _ hgn) hgm, ?_⟩
  intro p hp
  unfold referenceImpulse
  rw [laplace_shift hcc (by norm_num),
    causal_convolution_laplace hli hQi hlc (causalize_causal _) hp,
    lagKernel_laplace (by norm_num) hp,
    laplace_congr_halfLine (representative_halfLine_ae
      (EventuallyEq.rfl (f := causalize (filteredResolvent q R))))]
  have hh := hQT p hp
  have hd : 1+p ≠ 0 := by linarith
  simp only [one_mul]
  field_simp
  linear_combination hh

-- Article 14, Theorem 18: no impulse hypotheses are assumed in this family-level certificate.
-- Its transform is the exact delayed closed-loop formula, with no rational delay approximation.
theorem continuum_impulse {q : ℝ} (hq : q ∈ Icc (13/16 : ℝ) 1) :
    ∃ R : ℝ → ℝ,
      Integrable (referenceImpulse q R) ∧ Causal (referenceImpulse q R) ∧
      (∀ t, 0 ≤ referenceImpulse q R t) ∧ (∫ t, referenceImpulse q R t) = 1 ∧
      Article14.kernelHinf (referenceImpulse q R) = 1 ∧
      ∀ p : ℝ, 0 ≤ p →
        (1+p)*(p*(a*p+d)+Real.exp (-(1/4)*p))*laplace (referenceImpulse q R) p =
          Real.exp (-(1/4)*p)*(1+q*p) := by
  obtain ⟨R,hR,hi,hn,hm,hT⟩ := common_resolvent_exists
  obtain ⟨hgi,hgc,hgn,hgm,hgnorm,hGT⟩ := reference_impulse_properties
    hR.continuous hi hn hm (show q ∈ Icc (0 : ℝ) 1 from ⟨by linarith [hq.1],hq.2⟩)
  refine ⟨R,hgi,hgc,hgn,hgm,hgnorm,?_⟩
  intro p hp
  rw [real_characteristic_factorization p]
  linear_combination (a*p+E-compactExpMoment J (1/4) (-p))*(hGT p hp) +
    Real.exp (-(1/4)*p)*(1+q*p)*(hT p hp)

end Article14.ExactDelay
