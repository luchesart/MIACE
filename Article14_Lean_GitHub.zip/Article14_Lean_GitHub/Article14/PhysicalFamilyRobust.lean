import Article14.PhysicalFamilyOptimization
import Article14.RobustKernelGeometry

/-!
# Robust optimization of actual delayed PIDF responses

Each family member consists solely of static plant/controller data and
internal stability. Its physical trajectory and ordinary impulse kernel have
already been constructed. This module imposes positivity for every such
member and optimizes the supremum of the actual tracking-error areas.
The plant family may be infinite and its members may have different state
dimensions. Only the common integral time and proportional gain are needed
for the shared affine mean-time objective.
-/

namespace Article14

open Set MeasureTheory MIACE
open scoped Topology

variable {ι : Type*} {n : ι → Type*}
variable [∀ θ, Fintype (n θ)] [∀ θ, DecidableEq (n θ)]

/-- Positivity of every actual physical impulse response at the same weights. -/
noncomputable def physicalRobustFeasible
    (D : ∀ θ, StablePIDFData (n θ)) (X : Set (ℝ × ℝ)) : Set (ℝ × ℝ) :=
  ⋂ θ, (D θ).feasible X

/-- The robust constraint is an all-time, all-plant requirement, expressed
with actual physical kernels rather than samples or an independent certificate. -/
theorem mem_physicalRobustFeasible_iff [Nonempty ι]
    (D : ∀ θ, StablePIDFData (n θ)) {X : Set (ℝ × ℝ)} {w : ℝ × ℝ} :
    w ∈ physicalRobustFeasible D X ↔
      w ∈ X ∧ ∀ θ, ∀ᵐ t ∂halfLine, 0 ≤ (D θ).kernel w t := by
  classical
  simp only [physicalRobustFeasible, mem_iInter, StablePIDFData.mem_feasible_iff]
  constructor
  · intro h
    exact ⟨(h (Classical.arbitrary ι)).1, fun θ => (h θ).2⟩
  · rintro ⟨hX, h⟩ θ
    exact ⟨hX, h θ⟩

theorem physicalRobustFeasible_closed
    (D : ∀ θ, StablePIDFData (n θ)) {X : Set (ℝ × ℝ)} (hX : IsClosed X) :
    IsClosed (physicalRobustFeasible D X) :=
  isClosed_iInter (fun θ => (D θ).feasible_closed hX)

theorem physicalRobustFeasible_convex
    (D : ∀ θ, StablePIDFData (n θ)) {X : Set (ℝ × ℝ)} (hX : Convex ℝ X) :
    Convex ℝ (physicalRobustFeasible D X) :=
  convex_iInter (fun θ => (D θ).feasible_convex hX)

/-- Compactness follows from the proved physical-kernel geometry of a
single member. No weight box and no compactness premise are imposed. -/
theorem physicalRobustFeasible_compact [Nonempty ι]
    (D : ∀ θ, StablePIDFData (n θ)) {X : Set (ℝ × ℝ)} (hX : IsClosed X) :
    IsCompact (physicalRobustFeasible D X) := by
  classical
  exact robust_intersection_compact (fun θ => (D θ).feasible X)
    (fun θ => (D θ).feasible_closed hX) (Classical.arbitrary ι)
    ((D (Classical.arbitrary ι)).feasible_compact hX)

/-- Supremum of actual tracking-error absolute areas over the plant family. -/
noncomputable def physicalRobustWorstIAE
    (D : ∀ θ, StablePIDFData (n θ)) (w : ℝ × ℝ) : ℝ :=
  ⨆ θ, absArea ((D θ).error w) halfLine

/-- A robust-feasible weight gives the actual physical mean identity for
each plant separately, with positivity supplied by robust membership. -/
theorem physicalRobust_member_iae
    (D : ∀ θ, StablePIDFData (n θ)) {X : Set (ℝ × ℝ)} {w : ℝ × ℝ}
    (hw : w ∈ physicalRobustFeasible D X) (θ : ι) :
    absArea ((D θ).error w) halfLine =
      meanTime (D θ).Ti (D θ).k (D θ).Kp w.1 := by
  have hθ : w ∈ (D θ).feasible X := mem_iInter.mp hw θ
  exact stable_step_positive_iae ((D θ).response_dynamics w)
    (D θ).Ti_pos.ne' (D θ).k_pos.ne' (D θ).Kp_pos.ne' (D θ).L_nonneg
    ((D θ).stable_weights w) (D θ).equilibrium (D θ).unit_output
    (D θ).nonsingular ((D θ).feasible_kernel_nonnegative hθ)

/-- The finite worst physical IAE has the common slope `-Ti` in `b`.
Boundedness is imposed on the gain offsets, not on an assumed response. -/
theorem physicalRobustWorstIAE_eq [Nonempty ι]
    (D : ∀ θ, StablePIDFData (n θ)) {X : Set (ℝ × ℝ)} {w : ℝ × ℝ}
    (hw : w ∈ physicalRobustFeasible D X) (Ti Kp : ℝ)
    (hTi : ∀ θ, (D θ).Ti = Ti) (hKp : ∀ θ, (D θ).Kp = Kp)
    (hbounded : BddAbove (range (fun θ => Ti * (1 + 1 / ((D θ).k * Kp))))) :
    physicalRobustWorstIAE D w =
      (⨆ θ, Ti * (1 + 1 / ((D θ).k * Kp))) - Ti * w.1 := by
  have he : physicalRobustWorstIAE D w = ⨆ θ, meanTime Ti (D θ).k Kp w.1 := by
    unfold physicalRobustWorstIAE
    congr 1
    funext θ
    rw [physicalRobust_member_iae D hw θ, hTi θ, hKp θ]
  rw [he]
  exact robust_physical_mean_sup (fun θ => (D θ).k) Ti Kp w.1 hbounded

/-- Exact order comparison: on the robust feasible set, the smaller worst
physical IAE is precisely the one with the larger proportional weight. -/
theorem physicalRobustWorstIAE_le_iff [Nonempty ι]
    (D : ∀ θ, StablePIDFData (n θ)) {X : Set (ℝ × ℝ)} {w z : ℝ × ℝ}
    (hw : w ∈ physicalRobustFeasible D X) (hz : z ∈ physicalRobustFeasible D X)
    (Ti Kp : ℝ) (hTi : ∀ θ, (D θ).Ti = Ti) (hKp : ∀ θ, (D θ).Kp = Kp)
    (hbounded : BddAbove (range (fun θ => Ti * (1 + 1 / ((D θ).k * Kp))))) :
    physicalRobustWorstIAE D w ≤ physicalRobustWorstIAE D z ↔ z.1 ≤ w.1 := by
  classical
  have hTi_pos : 0 < Ti := by
    rw [← hTi (Classical.arbitrary ι)]
    exact (D (Classical.arbitrary ι)).Ti_pos
  rw [physicalRobustWorstIAE_eq D hw Ti Kp hTi hKp hbounded,
    physicalRobustWorstIAE_eq D hz Ti Kp hTi hKp hbounded]
  exact (sub_le_sub_iff_left _).trans (mul_le_mul_iff_right₀ hTi_pos)

/-- The robust minimax optimum of the actual physical tracking IAE exists
and is attained at a largest feasible `b`. Internal stability, kernel
existence, affinity, independence, and unit mass are all derived upstream
from `StablePIDFData`, rather than assumed here as response certificates. -/
theorem physicalRobust_minimum_iae_exists [Nonempty ι]
    (D : ∀ θ, StablePIDFData (n θ)) {X : Set (ℝ × ℝ)}
    (hX : IsClosed X) (hne : (physicalRobustFeasible D X).Nonempty)
    (Ti Kp : ℝ) (hTi : ∀ θ, (D θ).Ti = Ti) (hKp : ∀ θ, (D θ).Kp = Kp)
    (hbounded : BddAbove (range (fun θ => Ti * (1 + 1 / ((D θ).k * Kp))))) :
    ∃ w ∈ physicalRobustFeasible D X,
      (∀ z ∈ physicalRobustFeasible D X, z.1 ≤ w.1) ∧
      (∀ z ∈ physicalRobustFeasible D X,
        physicalRobustWorstIAE D w ≤ physicalRobustWorstIAE D z) := by
  obtain ⟨w, hw, hmax⟩ := (physicalRobustFeasible_compact D hX).exists_isMaxOn
    hne continuous_fst.continuousOn
  exact ⟨w, hw, hmax, fun z hz =>
    (physicalRobustWorstIAE_le_iff D hw hz Ti Kp hTi hKp hbounded).mpr (hmax hz)⟩

/-- The robust paragraph following Theorem 14, specialized to one common
physical feedback controller across the entire plant family. The generalized
lemmas above allow more variation because only `Ti` and `Kp` enter the mean. -/
theorem physicalRobust_fixed_controller_result [Nonempty ι]
    (D : ∀ θ, StablePIDFData (n θ)) {X : Set (ℝ × ℝ)}
    (hX : IsClosed X) (hconv : Convex ℝ X)
    (hne : (physicalRobustFeasible D X).Nonempty)
    (Kp Ti Td Tf : ℝ)
    (hcontroller : ∀ θ, (D θ).Kp = Kp ∧ (D θ).Ti = Ti ∧
      (D θ).Td = Td ∧ (D θ).Tf = Tf)
    (hbounded : BddAbove (range (fun θ => Ti * (1 + 1 / ((D θ).k * Kp))))) :
    IsClosed (physicalRobustFeasible D X) ∧
    Convex ℝ (physicalRobustFeasible D X) ∧
    IsCompact (physicalRobustFeasible D X) ∧
    ∃ w ∈ physicalRobustFeasible D X,
      (∀ z ∈ physicalRobustFeasible D X, z.1 ≤ w.1) ∧
      (∀ z ∈ physicalRobustFeasible D X,
        physicalRobustWorstIAE D w ≤ physicalRobustWorstIAE D z) :=
  ⟨physicalRobustFeasible_closed D hX, physicalRobustFeasible_convex D hconv,
    physicalRobustFeasible_compact D hX,
    physicalRobust_minimum_iae_exists D hX hne Ti Kp
      (fun θ => (hcontroller θ).2.1) (fun θ => (hcontroller θ).1) hbounded⟩

end Article14
