import Article14.ModalRealizationCompatibility
import Article14.LinearSemigroupEvolution
import Article14.PiecewiseRegularity
import Mathlib.Analysis.Calculus.MeanValue

/-!
# Unconditional physical zero-delay step existence

An extra constant coordinate converts a finite affine differential equation
into a homogeneous one. Thus the actual modal-design basis trajectories exist
without equilibrium, nonzero DC gain, nonsingularity, or stability assumptions.
-/
namespace Article14.ModalRealization
open Set MeasureTheory Matrix

section AffineEvolution
variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

noncomputable def affineAugment (A : E →L[ℝ] E) (v : E) :
    (E × ℝ) →L[ℝ] (E × ℝ) :=
  ((A.comp (ContinuousLinearMap.fst ℝ E ℝ)) +
    (ContinuousLinearMap.snd ℝ E ℝ).smulRight v).prod 0

theorem affineAugment_apply (A : E →L[ℝ] E) (v : E) (z : E × ℝ) :
    affineAugment A v z = (A z.1 + z.2 • v, 0) := rfl

noncomputable def affineEvolution (A : E →L[ℝ] E) (v : E) (t : ℝ) : E :=
  (linearEvolution (affineAugment A v) (0,1) t).1

theorem affineEvolution_hasDerivAt (A : E →L[ℝ] E) (v : E) (t : ℝ) :
    HasDerivAt (affineEvolution A v) (A (affineEvolution A v t) + v) t := by
  let z := linearEvolution (affineAugment A v) (0,1)
  have hd (s : ℝ) := linearEvolution_hasDerivAt (affineAugment A v) (0,1) s
  have hc (s : ℝ) : HasDerivAt (fun r => (z r).2) 0 s := (hd s).snd
  have he (s : ℝ) : (z s).2 = 1 := by
    have hh := is_const_of_deriv_eq_zero (fun r => (hc r).differentiableAt)
      (fun r => (hc r).deriv) s 0
    simpa [z, linearEvolution_zero] using hh
  have hh : HasDerivAt (fun s => (z s).1) (A (z t).1 + (z t).2 • v) t :=
    (hd t).fst
  rw [he, one_smul] at hh
  exact hh

theorem affineEvolution_continuous (A : E →L[ℝ] E) (v : E) :
    Continuous (affineEvolution A v) :=
  (linearEvolution_continuous (affineAugment A v) (0,1)).fst

theorem affineEvolution_zero (A : E →L[ℝ] E) (v : E) :
    affineEvolution A v 0 = 0 := by simp [affineEvolution, linearEvolution_zero]
/-- Two actual affine trajectories with the same initial state coincide.
The proof applies homogeneous ODE uniqueness to their difference. -/
theorem affine_ode_unique (A : E →L[ℝ] E) (v : E) {x y : ℝ → E}
    (hx : ContinuousOn x (Ici 0)) (hy : ContinuousOn y (Ici 0))
    (hdx : ∀ t, 0 < t → HasDerivAt x (A (x t)+v) t)
    (hdy : ∀ t, 0 < t → HasDerivAt y (A (y t)+v) t)
    (hz : x 0 = y 0) : EqOn x y (Ici 0) := by
  have hd (t : ℝ) (ht : 0 < t) :
      HasDerivAt (fun s => x s-y s) (A (x t-y t)) t := by
    simpa only [map_sub, add_sub_add_right_eq_sub, Pi.sub_def] using (hdx t ht).sub (hdy t ht)
  have hh := linear_ode_unique A (y := fun _ => (0 : E)) (hx.sub hy) continuous_const.continuousOn hd
    (fun t _ => by simpa only [map_zero] using hasDerivAt_const t (0 : E))
    (by simp only [Pi.sub_apply, hz, sub_self])
  intro t ht
  exact sub_eq_zero.mp (hh ht)
end AffineEvolution

variable {n : Type*} [Fintype n] [DecidableEq n]

noncomputable def decodedStateMap :
    (n ⊕ Bool → ℝ) →L[ℝ] ((n → ℝ) × ℝ × ℝ) :=
  (ContinuousLinearMap.pi (fun j => ContinuousLinearMap.proj (.inl j))).prod
    ((ContinuousLinearMap.proj (.inr false)).prod (ContinuousLinearMap.proj (.inr true)))

theorem decodedStateMap_apply (z : n ⊕ Bool → ℝ) :
    decodedStateMap z = (fun j => z (.inl j), z (.inr false), z (.inr true)) := rfl

theorem decoded_encode (q : (n → ℝ) × ℝ × ℝ) :
    decodedStateMap (encodeState q.1 q.2.1 q.2.2) = q := by
  rcases q with ⟨x,i,f⟩
  rfl

theorem encode_decoded (z : n ⊕ Bool → ℝ) :
    encodeState (decodedStateMap z).1 (decodedStateMap z).2.1 (decodedStateMap z).2.2 = z := by
  ext j
  cases j with
  | inl j => rfl
  | inr j => cases j <;> rfl

/-- The actual all-real-time affine flow, restricted to nonnegative time for
physical use. The reference step begins from zero plant/controller state. -/
noncomputable def zeroDelayStepResponse (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf b c : ℝ) (t : ℝ) : (n → ℝ) × ℝ × ℝ :=
  decodedStateMap (affineEvolution (finiteStateMap (sharedMatrix A B C Kp Ti Td Tf))
    (referenceVector B Kp Td Tf b c) t)

theorem zeroDelayStepResponse_zero (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf b c : ℝ) : zeroDelayStepResponse A B C Kp Ti Td Tf b c 0 = 0 := by
  simp [zeroDelayStepResponse, affineEvolution_zero]

theorem zeroDelayStepResponse_continuous (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf b c : ℝ) : Continuous (zeroDelayStepResponse A B C Kp Ti Td Tf b c) :=
  decodedStateMap.continuous.comp (affineEvolution_continuous _ _)

theorem zeroDelayStepResponse_hasDerivAt (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf b c t : ℝ) :
    HasDerivAt (zeroDelayStepResponse A B C Kp Ti Td Tf b c)
      (sharedClosedLoopRhs (finitePlantOutput C) (finitePlantDynamics A B)
        Kp Ti Td Tf b c 1 (zeroDelayStepResponse A B C Kp Ti Td Tf b c t)) t := by
  let z := affineEvolution (finiteStateMap (sharedMatrix A B C Kp Ti Td Tf))
    (referenceVector B Kp Td Tf b c)
  have hd := decodedStateMap.hasFDerivAt.comp_hasDerivAt t
    (affineEvolution_hasDerivAt (finiteStateMap (sharedMatrix A B C Kp Ti Td Tf))
      (referenceVector B Kp Td Tf b c) t)
  have hm : finiteStateMap (sharedMatrix A B C Kp Ti Td Tf) (z t) =
      sharedMatrix A B C Kp Ti Td Tf *ᵥ z t := by
    ext j
    exact finiteStateMap_apply _ _ j
  change HasDerivAt (zeroDelayStepResponse A B C Kp Ti Td Tf b c)
    (decodedStateMap (finiteStateMap (sharedMatrix A B C Kp Ti Td Tf) (z t) +
      referenceVector B Kp Td Tf b c)) t at hd
  rw [hm] at hd
  have hf := sharedMatrix_matches_physical A B C Kp Ti Td Tf b c 1 (decodedStateMap (z t))
  rw [encode_decoded, one_smul] at hf
  rw [hf, decoded_encode] at hd
  exact hd

/-- The explicit finite affine flow satisfies every physical step equation,
including the absolute-continuity clauses, with zero transport delay. -/
theorem zeroDelayStepResponse_dynamics (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf b c : ℝ) :
    StepLoopDynamics A B C Kp Ti Td Tf 0 b c
      (zeroDelayStepResponse A B C Kp Ti Td Tf b c) := by
  let q := zeroDelayStepResponse A B C Kp Ti Td Tf b c
  let f := fun t => sharedClosedLoopRhs (finitePlantOutput C) (finitePlantDynamics A B)
    Kp Ti Td Tf b c 1 (q t)
  have hq : Continuous q := zeroDelayStepResponse_continuous A B C Kp Ti Td Tf b c
  have hf : Continuous f := by
    simp only [f, sharedClosedLoopRhs, sharedControllerRhs, finitePlantOutput]
    unfold finitePlantDynamics
    fun_prop
  have hd (t : ℝ) : HasDerivAt q (f t) t :=
    zeroDelayStepResponse_hasDerivAt A B C Kp Ti Td Tf b c t
  have hac (φ : ((n → ℝ) × ℝ × ℝ) →L[ℝ] ℝ) (T : ℝ) (hT : 0 ≤ T) :
      AbsolutelyContinuousOnInterval (fun t => φ (q t)) 0 T := by
    apply absolutelyContinuousOnInterval_of_piecewise_C1 (L := 0) (p' := fun _ => 0)
      (r := fun t => φ (f t)) le_rfl hT
    · exact (φ.continuous.comp hq).continuousOn
    · exact continuous_const.continuousOn
    · intro t ht
      exact (not_lt_of_ge ht.1.le ht.2).elim
    · exact (φ.continuous.comp hf).continuousOn
    · intro t _
      exact φ.hasFDerivAt.comp_hasDerivAt t (hd t)
  refine ⟨hq.continuousOn, ?_, ?_, ?_, zeroDelayStepResponse_zero A B C Kp Ti Td Tf b c,
    ?_, ?_, ?_, ?_⟩
  · intro j T hT
    exact hac (plantCoordinate j) T hT
  · exact hac integralCoordinate
  · exact hac filterCoordinate
  · intro j
    apply Filter.Eventually.of_forall
    intro t ht
    have hh := ((plantCoordinate j).hasFDerivAt.comp_hasDerivAt t (hd t)).deriv
    simpa [Function.comp_def, plantCoordinate, f, sharedClosedLoopRhs,
      finitePlantDynamics, stepCommand, not_le.mpr ht] using hh
  · apply Filter.Eventually.of_forall
    intro t _
    exact (integralCoordinate.hasFDerivAt.comp_hasDerivAt t (hd t)).deriv
  · apply Filter.Eventually.of_forall
    intro t _
    exact (filterCoordinate.hasFDerivAt.comp_hasDerivAt t (hd t)).deriv
  · intro t _
    simpa [retardedSharedRhs, sharedClosedLoopRhs, f, q] using hd t

/-- Proposition 10 needs no plant equilibrium to supply its three response
bases. In particular plants with a zero or pole at DC are covered. -/
theorem zeroDelay_step_exists (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf b c : ℝ) :
    ∃ q, StepLoopDynamics A B C Kp Ti Td Tf 0 b c q :=
  ⟨zeroDelayStepResponse A B C Kp Ti Td Tf b c,
    zeroDelayStepResponse_dynamics A B C Kp Ti Td Tf b c⟩

/-- Uniqueness of the complete physical zero-delay step response does not
need a nonzero plant DC gain or a stable closed-loop matrix. -/
theorem zeroDelay_step_unique
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf b c : ℝ}
    {q r : ℝ → (n → ℝ) × ℝ × ℝ}
    (hq : StepLoopDynamics A B C Kp Ti Td Tf 0 b c q)
    (hr : StepLoopDynamics A B C Kp Ti Td Tf 0 b c r) :
    EqOn q r (Ici 0) := by
  let M := finiteStateMap (sharedMatrix A B C Kp Ti Td Tf)
  have hm (z : n ⊕ Bool → ℝ) : M z = sharedMatrix A B C Kp Ti Td Tf *ᵥ z := by
    ext j
    exact finiteStateMap_apply _ _ j
  have hqd (t : ℝ) (ht : 0 < t) :
      HasDerivAt (fun s => encodedStateMap (q s))
        (M (encodedStateMap (q t)) + referenceVector B Kp Td Tf b c) t := by
    rw [hm]
    simpa only [encodedStateMap_apply] using encoded_actual_step_ode hq t ht
  have hrd (t : ℝ) (ht : 0 < t) :
      HasDerivAt (fun s => encodedStateMap (r s))
        (M (encodedStateMap (r t)) + referenceVector B Kp Td Tf b c) t := by
    rw [hm]
    simpa only [encodedStateMap_apply] using encoded_actual_step_ode hr t ht
  have he := affine_ode_unique M (referenceVector B Kp Td Tf b c)
    (encodedStateMap.continuous.comp_continuousOn hq.continuous)
    (encodedStateMap.continuous.comp_continuousOn hr.continuous) hqd hrd
    (by simp only [Function.comp_def, hq.initial, hr.initial])
  intro t ht
  have hh := congrArg decodedStateMap (he ht)
  simpa only [Function.comp_def, encodedStateMap_apply, decoded_encode] using hh

/-- The three constructed basis trajectories determine every actual physical
response at nonnegative time by exactly the affine formula used by the SOCP. -/
theorem zeroDelay_step_eq_affine_family
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (hq : StepLoopDynamics A B C Kp Ti Td Tf 0 b c q) :
    EqOn q
      (stepAffineFamily (zeroDelayStepResponse A B C Kp Ti Td Tf 0 0)
        (zeroDelayStepResponse A B C Kp Ti Td Tf 1 0)
        (zeroDelayStepResponse A B C Kp Ti Td Tf 0 1) b c) (Ici 0) :=
  zeroDelay_step_unique hq (stepLoopDynamics_affine_family
    (zeroDelayStepResponse_dynamics A B C Kp Ti Td Tf 0 0)
    (zeroDelayStepResponse_dynamics A B C Kp Ti Td Tf 1 0)
    (zeroDelayStepResponse_dynamics A B C Kp Ti Td Tf 0 1) b c)

end Article14.ModalRealization
