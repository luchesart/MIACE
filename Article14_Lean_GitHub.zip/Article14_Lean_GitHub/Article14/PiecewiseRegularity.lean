import Mathlib.MeasureTheory.Integral.IntervalIntegral.AbsolutelyContinuousFun
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus
import Mathlib.Analysis.Normed.Group.Bounded

/-!
# Absolute continuity across the first delay switch

The derivative of a delayed step response can jump when the input first reaches
the plant.  Continuous differentiability on each side, together with continuity
of the state itself, nevertheless gives absolute continuity on every finite
interval.  The lemmas below do not require a derivative at the switching time.
-/

namespace Article14

open Set MeasureTheory
open scoped NNReal

/-- The fundamental theorem of calculus gives a Lipschitz bound from a
continuous, bounded interior derivative; endpoint derivatives are unnecessary. -/
theorem lipschitzOnWith_of_continuous_derivative_Ioo
    {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]
    {q q' : ℝ → E} {a b : ℝ} {K : ℝ≥0}
    (hq : ContinuousOn q (Icc a b))
    (hq' : ContinuousOn q' (Icc a b))
    (hderiv : ∀ t ∈ Ioo a b, HasDerivAt q (q' t) t)
    (hbound : ∀ t ∈ Icc a b, ‖q' t‖ ≤ K) :
    LipschitzOnWith K q (Icc a b) := by
  rw [lipschitzOnWith_iff_dist_le_mul]
  intro x hx y hy
  have hsub : uIcc x y ⊆ Icc a b := uIcc_subset_Icc hx hy
  have hint : IntervalIntegrable q' volume x y :=
    (hq'.mono hsub).intervalIntegrable
  have heq : ∫ t in x..y, q' t = q y - q x := by
    apply intervalIntegral.integral_eq_sub_of_hasDeriv_right (hq.mono hsub) _ hint
    intro t ht
    apply (hderiv t ?_).hasDerivWithinAt
    exact ⟨lt_of_le_of_lt (le_min hx.1 hy.1) ht.1,
      lt_of_lt_of_le ht.2 (max_le hx.2 hy.2)⟩
  have hb := intervalIntegral.norm_integral_le_of_norm_le_const
    (fun t ht => hbound t (hsub (uIoc_subset_uIcc ht)))
  rw [heq] at hb
  simpa only [dist_eq_norm, Real.norm_eq_abs, norm_sub_rev, abs_sub_comm] using hb

/-- Two Lipschitz estimates with the same constant glue at a common endpoint. -/
theorem lipschitzOnWith_Icc_glue
    {E : Type*} [PseudoMetricSpace E] {q : ℝ → E} {a b c : ℝ} {K : ℝ≥0}
    (hac : a ≤ c) (hcb : c ≤ b)
    (hl : LipschitzOnWith K q (Icc a c))
    (hr : LipschitzOnWith K q (Icc c b)) :
    LipschitzOnWith K q (Icc a b) := by
  rw [lipschitzOnWith_iff_dist_le_mul] at hl hr ⊢
  have hcross : ∀ x ∈ Icc a c, ∀ y ∈ Icc c b,
      dist (q x) (q y) ≤ K * dist x y := by
    intro x hx y hy
    calc
      dist (q x) (q y) ≤ dist (q x) (q c) + dist (q c) (q y) := dist_triangle _ _ _
      _ ≤ K * dist x c + K * dist c y :=
        add_le_add (hl x hx c ⟨hac, le_rfl⟩) (hr c ⟨le_rfl, hcb⟩ y hy)
      _ = K * dist x y := by
        simp only [Real.dist_eq, abs_of_nonpos (sub_nonpos.mpr hx.2),
          abs_of_nonpos (sub_nonpos.mpr hy.1),
          abs_of_nonpos (sub_nonpos.mpr (hx.2.trans hy.1))]
        ring
  intro x hx y hy
  rcases le_total x c with hxc | hcx <;> rcases le_total y c with hyc | hcy
  · exact hl x ⟨hx.1, hxc⟩ y ⟨hy.1, hyc⟩
  · exact hcross x ⟨hx.1, hxc⟩ y ⟨hcy, hy.2⟩
  · simpa only [dist_comm] using hcross y ⟨hy.1, hyc⟩ x ⟨hcx, hx.2⟩
  · exact hr x ⟨hcx, hx.2⟩ y ⟨hcy, hy.2⟩

/-- A continuous trajectory with continuous derivatives on the two sides of a
single switch is absolutely continuous on every finite nonnegative interval. -/
theorem absolutelyContinuousOnInterval_of_piecewise_C1
    {q p' r : ℝ → ℝ} {L T : ℝ}
    (hL : 0 ≤ L) (hT : 0 ≤ T)
    (hq : ContinuousOn q (Ici 0))
    (hp : ContinuousOn p' (Icc 0 L))
    (hprefix : ∀ t ∈ Ioo 0 L, HasDerivAt q (p' t) t)
    (hr : ContinuousOn r (Ici L))
    (htail : ∀ t, L < t → HasDerivAt q (r t) t) :
    AbsolutelyContinuousOnInterval q 0 T := by
  obtain ⟨C, hC⟩ := isCompact_Icc.exists_bound_of_continuousOn hp
  obtain ⟨D, hD⟩ := isCompact_Icc.exists_bound_of_continuousOn
    (hr.mono (show Icc L (max L T) ⊆ Ici L from fun _ ht => ht.1))
  let K : ℝ≥0 := ⟨max 0 (max C D), le_max_left _ _⟩
  have hlip : LipschitzOnWith K q (Icc 0 L) := by
    apply lipschitzOnWith_of_continuous_derivative_Ioo (hq.mono fun _ ht => ht.1)
      hp hprefix
    intro t ht
    exact (hC t ht).trans ((le_max_left C D).trans (le_max_right 0 (max C D)))
  have hrip : LipschitzOnWith K q (Icc L (max L T)) := by
    apply lipschitzOnWith_of_continuous_derivative_Ioo
      (hq.mono fun _ ht => hL.trans ht.1)
      (hr.mono fun _ ht => ht.1) (fun t ht => htail t ht.1)
    intro t ht
    exact (hD t ht).trans ((le_max_right C D).trans (le_max_right 0 (max C D)))
  have hall := lipschitzOnWith_Icc_glue hL (le_max_left L T) hlip hrip
  rw [← uIcc_of_le (hL.trans (le_max_left L T))] at hall
  apply hall.absolutelyContinuousOnInterval.mono
  rw [uIcc_of_le hT, uIcc_of_le (hL.trans (le_max_left L T))]
  exact Icc_subset_Icc le_rfl (le_max_right L T)

end Article14
