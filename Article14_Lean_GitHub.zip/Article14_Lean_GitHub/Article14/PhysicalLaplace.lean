import MIACE.AnalyticBridge
import MIACE.DelayTransforms
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics
import Mathlib.Analysis.SpecialFunctions.Gaussian.GaussianIntegral

/-!
Physical Laplace identities for Article 14.  The inputs to the theorems are
ordinary time functions, their local absolute continuity, their actual
almost-everywhere differential equations, integrability, and endpoint limits.
Neither a transfer identity nor an area identity is postulated here.

The delay endpoint is assigned to the initial history.  A separate a.e. lemma
allows the alternative convention assigning the endpoint to the shifted input.
-/
namespace Article14.PhysicalLaplace

open MeasureTheory Filter Set MIACE
open scoped Topology

/-- The centered command seen after zero-input transport history. -/
noncomputable def centeredDelay (L : ℝ) (v : ℝ → ℝ) (t : ℝ) : ℝ :=
  if t ≤ L then -1 else v (t - L)

-- New bridge: the initial waiting interval contributes -1, not zero.
theorem centeredDelay_eq (L : ℝ) (v : ℝ → ℝ) :
    centeredDelay L v = fun t => -delayedError L (fun s => -v s) t := by
  funext t
  by_cases ht : t ≤ L <;> simp [centeredDelay, delayedError, ht]

-- New bridge: either convention at the single transport endpoint is valid a.e.
theorem centeredDelay_lt_ae (L : ℝ) (v : ℝ → ℝ) :
    centeredDelay L v =ᵐ[halfLine] (fun t => if t < L then -1 else v (t-L)) := by
  filter_upwards [ae_restrict_of_ae (volume.ae_ne L)] with t ht
  by_cases h : t < L
  · simp [centeredDelay, h, h.le]
  · have hlt : L < t := lt_of_le_of_ne (le_of_not_gt h) (Ne.symm ht)
    simp [centeredDelay, h, not_le.mpr hlt]

-- Reuse of the original MIACE transport integrability proof, with the correct sign.
theorem centeredDelay_integrable {L : ℝ} (hL : 0 ≤ L) {v : ℝ → ℝ}
    (hv : Integrable v halfLine) : Integrable (centeredDelay L v) halfLine := by
  rw [centeredDelay_eq]
  exact (delayedError_integrable L hL hv.neg).neg

-- New bridge: exact transform of the ordinary delayed centered command.
theorem centeredDelay_laplace {L p : ℝ} (hL : 0 ≤ L) {v : ℝ → ℝ}
    (hv : Integrable v halfLine) (hp : 0 < p) :
    laplace (centeredDelay L v) p =
      Real.exp (-L*p)*laplace v p + (Real.exp (-L*p)-1)/p := by
  have h := delayedError_laplace hv.neg hL hp
  have hn (f : ℝ → ℝ) : laplace (fun t => -f t) p = -laplace f p := by
    simp only [laplace, mul_neg, integral_neg]
  change laplace (delayedError L (fun t => -v t)) p =
    (1-Real.exp (-L*p))/p+Real.exp (-L*p)*laplace (fun t => -v t) p at h
  rw [hn] at h
  rw [centeredDelay_eq, hn, h]
  ring

-- New bridge: the signed waiting area is retained at zero frequency.
theorem centeredDelay_integral {L : ℝ} (hL : 0 ≤ L) {v : ℝ → ℝ}
    (hv : Integrable v halfLine) :
    (∫ t, centeredDelay L v t ∂halfLine) = (∫ t, v t ∂halfLine)-L := by
  rw [centeredDelay_eq, integral_neg]
  have hvn : Integrable (fun t => -v t) halfLine := hv.neg
  rw [integral_congr_ae (delayedError_split L (fun t => -v t)),
    integral_add (pulse_integrable 1 L) (delayTail_integrable L hL hvn),
    delayTail_integral L hL, integral_neg]
  have hp := pulse_area (1 : ℝ) L hL
  change (∫ t, pulse 1 L t ∂halfLine) = 1*L at hp
  simp only [one_mul] at hp
  rw [hp]
  ring

-- New bridge: affine asymptotes are transformed without claiming L¹ integrability
-- of the nonzero constant steady state itself.
theorem laplace_affine_add {z : ℝ → ℝ} (hz : Integrable z halfLine)
    (F : ℝ) {p : ℝ} (hp : 0 < p) :
    laplace (fun t => F+z t) p = F/p+laplace z p := by
  have hc : Integrable (fun t : ℝ => Real.exp (-p*t)) halfLine :=
    integrableOn_exp_mul_Ioi (by linarith : -p < 0) 0
  have hs := laplace_step p hp
  unfold laplace at hs ⊢
  simp only [mul_one] at hs
  simp_rw [mul_add, mul_comm (Real.exp _) F]
  rw [integral_add (hc.const_mul F) (laplace_integrable hz hp.le),
    integral_const_mul, hs]
  ring

-- Reuse of the existing ODE-to-Laplace theorem after centering at the steady state.
theorem laplace_affine_ode_identity {f g : ℝ → ℝ} {F : ℝ}
    (hac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval f 0 T)
    (hode : ∀ᵐ t : ℝ, 0 < t → deriv f t = g t)
    (hf : Integrable (fun t => f t-F) halfLine) (hg : Integrable g halfLine)
    (hlim : Tendsto f atTop (𝓝 F)) {p : ℝ} (hp : 0 < p) :
    laplace g p = p*laplace f p-f 0 := by
  have hac' : ∀ T : ℝ, 0 ≤ T →
      AbsolutelyContinuousOnInterval (fun t => f t-F) 0 T := by
    intro T hT
    apply (hac T hT).sub
    apply ContDiffOn.absolutelyContinuousOnInterval
    fun_prop
  have hode' : ∀ᵐ t : ℝ, 0 < t → deriv (fun s => f s-F) t = g t := by
    filter_upwards [hode] with t ht hpos
    rw [deriv_sub_const]
    exact ht hpos
  have hz : Tendsto (fun t => f t-F) atTop (𝓝 0) := by
    simpa using hlim.sub_const F
  have h := laplace_ode_identity hac' hode' hf hg hz p hp.le
  have ha := laplace_affine_add hf F hp
  have he : (fun t => F+(f t-F)) = f := by funext t; ring
  rw [he] at ha
  have hp0 : p ≠ 0 := ne_of_gt hp
  rw [ha]
  field_simp
  nlinarith [h]

-- New bridge: exponential state decay removes every polynomial boundary term.
theorem polynomial_weight_tendsto_zero {f : ℝ → ℝ} {C β : ℝ}
    (hβ : 0 < β)
    (hdecay : ∀ t, 0 ≤ t → |f t| ≤ C*Real.exp (-β*t)) (n : ℕ) :
    Tendsto (fun t => t^n*f t) atTop (𝓝 0) := by
  have hexp : Tendsto (fun t : ℝ => t^n*Real.exp (-β*t)) atTop (𝓝 0) := by
    simpa only [Real.rpow_natCast] using
      tendsto_rpow_mul_exp_neg_mul_atTop_nhds_zero (n : ℝ) β hβ
  have hbound : Tendsto (fun t : ℝ => C*(t^n*Real.exp (-β*t))) atTop (𝓝 0) := by
    simpa only [mul_zero] using hexp.const_mul C
  apply tendsto_zero_iff_norm_tendsto_zero.mpr
  apply squeeze_zero' (Eventually.of_forall (fun t => norm_nonneg _)) _ hbound
  filter_upwards [eventually_ge_atTop (0 : ℝ)] with t ht
  rw [norm_mul, Real.norm_of_nonneg (pow_nonneg ht n), Real.norm_eq_abs]
  calc
    t^n*|f t| ≤ t^n*(C*Real.exp (-β*t)) :=
      mul_le_mul_of_nonneg_left (hdecay t ht) (pow_nonneg ht n)
    _ = C*(t^n*Real.exp (-β*t)) := by ring

-- New bridge: the same physical exponential estimate supplies every ordinary moment.
theorem polynomial_weight_integrable {f : ℝ → ℝ}
    (hf : AEStronglyMeasurable f halfLine) {C β : ℝ}
    (hβ : 0 < β)
    (hdecay : ∀ t, 0 ≤ t → |f t| ≤ C*Real.exp (-β*t)) (n : ℕ) :
    Integrable (fun t => t^n*f t) halfLine := by
  have hexp : Integrable (fun t : ℝ => t^n*Real.exp (-β*t)) halfLine := by
    simpa only [IntegrableOn, halfLine, Real.rpow_natCast, Real.rpow_one] using
      (integrableOn_rpow_mul_exp_neg_mul_rpow
        (s := (n : ℝ)) (p := (1 : ℝ))
        (lt_of_lt_of_le (by norm_num : (-1 : ℝ) < 0) (Nat.cast_nonneg n))
        (by norm_num : (0 : ℝ) < 1) hβ)
  have hm : AEStronglyMeasurable (fun t : ℝ => t^n) halfLine :=
    (by fun_prop : Continuous (fun t : ℝ => t^n)).aestronglyMeasurable
  apply (hexp.const_mul C).mono' (hm.mul hf)
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  have ht0 : 0 ≤ t := le_of_lt (show 0 < t from ht)
  change ‖t^n*f t‖ ≤ C*(t^n*Real.exp (-β*t))
  rw [norm_mul, Real.norm_of_nonneg (pow_nonneg ht0 n), Real.norm_eq_abs]
  calc
    t^n*|f t| ≤ t^n*(C*Real.exp (-β*t)) :=
      mul_le_mul_of_nonneg_left (hdecay t ht0) (pow_nonneg ht0 n)
    _ = C*(t^n*Real.exp (-β*t)) := by ring

-- New bridge: infinite FTC needs integrability of the derivative, not of the state.
theorem integral_of_locallyAC {f g : ℝ → ℝ} {F : ℝ}
    (hac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval f 0 T)
    (hode : ∀ᵐ t : ℝ, 0 < t → deriv f t = g t)
    (hg : Integrable g halfLine) (hlim : Tendsto f atTop (𝓝 F)) :
    (∫ t, g t ∂halfLine) = F-f 0 := by
  have hfinite : ∀ T : ℝ, 0 ≤ T → (∫ t in 0..T, g t) = f T-f 0 := by
    intro T hT
    rw [← (hac T hT).integral_deriv_eq_sub]
    apply intervalIntegral.integral_congr_ae
    filter_upwards [hode] with t ht htmem
    rw [uIoc_of_le hT] at htmem
    exact (ht htmem.1).symm
  have hi := intervalIntegral_tendsto_integral_Ioi 0 hg tendsto_id
  have he : (fun T : ℝ => ∫ t in 0..T, g t) =ᶠ[atTop]
      (fun T => f T-f 0) := by
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with T hT
    exact hfinite T hT
  exact tendsto_nhds_unique hi ((hlim.sub_const (f 0)).congr' he.symm)

-- New bridge: the ordinary output impulse is obtained from the physical error ODE.
theorem impulse_laplace_of_error {e g : ℝ → ℝ}
    (hac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval e 0 T)
    (hode : ∀ᵐ t : ℝ, 0 < t → deriv e t = -g t)
    (he : Integrable e halfLine) (hg : Integrable g halfLine)
    (hlim : Tendsto e atTop (𝓝 0)) (hzero : e 0 = 1)
    {p : ℝ} (hp : 0 ≤ p) :
    laplace g p = 1-p*laplace e p := by
  have hh := laplace_ode_identity hac hode he hg.neg hlim p hp
  simp only [laplace, mul_neg, integral_neg] at hh
  rw [hzero] at hh
  change -(laplace g p) = p*laplace e p-1 at hh
  linarith

-- New bridge: unit impulse mass is concluded from the physical endpoints.
theorem impulse_unit_mass {e g : ℝ → ℝ}
    (hac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval e 0 T)
    (hode : ∀ᵐ t : ℝ, 0 < t → deriv e t = -g t)
    (hg : Integrable g halfLine)
    (hlim : Tendsto e atTop (𝓝 0)) (hzero : e 0 = 1) :
    (∫ t, g t ∂halfLine) = 1 := by
  have hh := integral_of_locallyAC hac hode hg.neg hlim
  rw [integral_neg, hzero] at hh
  linarith

-- New bridge: the actual first moment follows from e'=-g and its boundary term.
theorem first_moment_identity {e g : ℝ → ℝ}
    (hac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval e 0 T)
    (hode : ∀ᵐ t : ℝ, 0 < t → deriv e t = -g t)
    (he : Integrable e halfLine)
    (htg : Integrable (fun t => t*g t) halfLine)
    (hlim : Tendsto (fun t => t*e t) atTop (𝓝 0)) :
    (∫ t, t*g t ∂halfLine) = ∫ t, e t ∂halfLine := by
  have hfinite : ∀ T : ℝ, 0 ≤ T →
      (∫ t in 0..T, e t-t*g t) = T*e T := by
    intro T hT
    have ha : AbsolutelyContinuousOnInterval (fun t : ℝ => t) 0 T := by
      apply ContDiffOn.absolutelyContinuousOnInterval
      fun_prop
    have hi := (ha.mul (hac T hT)).integral_deriv_eq_sub
    have hsame : (∫ t in 0..T, deriv (fun s => s*e s) t) =
        ∫ t in 0..T, e t-t*g t := by
      apply intervalIntegral.integral_congr_ae
      filter_upwards [(hac T hT).ae_differentiableAt, hode] with t hd ho ht
      have hdf := (hd (uIoc_subset_uIcc ht)).hasDerivAt
      rw [uIoc_of_le hT] at ht
      rw [ho ht.1] at hdf
      have hh := (hasDerivAt_id t).mul hdf
      change HasDerivAt (fun s => s*e s) _ t at hh
      rw [hh.deriv]
      simp only [id_eq]
      ring
    change (∫ t in 0..T, deriv (fun s => s*e s) t) = T*e T-0*e 0 at hi
    rw [hsame] at hi
    simpa using hi
  have hi := intervalIntegral_tendsto_integral_Ioi 0 (he.sub htg) tendsto_id
  have heq : (fun T : ℝ => ∫ t in 0..T, e t-t*g t) =ᶠ[atTop]
      (fun T => T*e T) := by
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with T hT
    exact hfinite T hT
  have hz := tendsto_nhds_unique hi (hlim.congr' heq.symm)
  change (∫ t, e t-t*g t ∂halfLine) = 0 at hz
  rw [integral_sub he htg] at hz
  linarith

-- New bridge: under no overshoot, the physical IAE is the impulse mean.
theorem absolute_error_eq_first_moment {e g : ℝ → ℝ}
    (hac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval e 0 T)
    (hode : ∀ᵐ t : ℝ, 0 < t → deriv e t = -g t)
    (he : Integrable e halfLine)
    (htg : Integrable (fun t => t*g t) halfLine)
    (hlim : Tendsto (fun t => t*e t) atTop (𝓝 0))
    (hn : ∀ᵐ t ∂halfLine, 0 ≤ e t) :
    absArea e halfLine = ∫ t, t*g t ∂halfLine := by
  rw [first_moment_identity hac hode he htg hlim]
  apply integral_congr_ae
  filter_upwards [hn] with t ht
  exact abs_of_nonneg ht

-- New bridge: the second impulse moment is twice the time-weighted error area.
theorem second_moment_identity {e g : ℝ → ℝ}
    (hac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval e 0 T)
    (hode : ∀ᵐ t : ℝ, 0 < t → deriv e t = -g t)
    (hte : Integrable (fun t => t*e t) halfLine)
    (htg : Integrable (fun t => t^2*g t) halfLine)
    (hlim : Tendsto (fun t => t^2*e t) atTop (𝓝 0)) :
    (∫ t, t^2*g t ∂halfLine) = 2*(∫ t, t*e t ∂halfLine) := by
  have hfinite : ∀ T : ℝ, 0 ≤ T →
      (∫ t in 0..T, 2*(t*e t)-t^2*g t) = T^2*e T := by
    intro T hT
    have ha : AbsolutelyContinuousOnInterval (fun t : ℝ => t^2) 0 T := by
      apply ContDiffOn.absolutelyContinuousOnInterval
      fun_prop
    have hi := (ha.mul (hac T hT)).integral_deriv_eq_sub
    have hsame : (∫ t in 0..T, deriv (fun s => s^2*e s) t) =
        ∫ t in 0..T, 2*(t*e t)-t^2*g t := by
      apply intervalIntegral.integral_congr_ae
      filter_upwards [(hac T hT).ae_differentiableAt, hode] with t hd ho ht
      have hdf := (hd (uIoc_subset_uIcc ht)).hasDerivAt
      rw [uIoc_of_le hT] at ht
      rw [ho ht.1] at hdf
      have hh := ((hasDerivAt_id t).pow 2).mul hdf
      change HasDerivAt (fun s => s^2*e s) _ t at hh
      rw [hh.deriv]
      simp only [id_eq]
      norm_num
      ring
    change (∫ t in 0..T, deriv (fun s => s^2*e s) t) = T^2*e T-0^2*e 0 at hi
    rw [hsame] at hi
    simpa using hi
  have hint := (hte.const_mul 2).sub htg
  have hi := intervalIntegral_tendsto_integral_Ioi 0 hint tendsto_id
  have heq : (fun T : ℝ => ∫ t in 0..T, 2*(t*e t)-t^2*g t) =ᶠ[atTop]
      (fun T => T^2*e T) := by
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with T hT
    exact hfinite T hT
  have hz := tendsto_nhds_unique hi (hlim.congr' heq.symm)
  change (∫ t, 2*(t*e t)-t^2*g t ∂halfLine) = 0 at hz
  rw [integral_sub (hte.const_mul 2) htg, integral_const_mul] at hz
  linarith

-- New bridge: exponential physical signals discharge all moment and tail side conditions.
theorem first_and_second_moments_of_exp_decay {e g : ℝ → ℝ}
    (hac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval e 0 T)
    (hode : ∀ᵐ t : ℝ, 0 < t → deriv e t = -g t)
    (hg : AEStronglyMeasurable g halfLine) {Ce Cg β : ℝ} (hβ : 0 < β)
    (hedecay : ∀ t, 0 ≤ t → |e t| ≤ Ce*Real.exp (-β*t))
    (hgdecay : ∀ t, 0 ≤ t → |g t| ≤ Cg*Real.exp (-β*t)) :
    (∫ t, t*g t ∂halfLine) = (∫ t, e t ∂halfLine) ∧
      (∫ t, t^2*g t ∂halfLine) = 2*(∫ t, t*e t ∂halfLine) := by
  have he : AEStronglyMeasurable e halfLine :=
    (local_ac_continuous hac).aestronglyMeasurable measurableSet_Ioi
  have he0 : Integrable e halfLine := by
    simpa only [pow_zero, one_mul] using polynomial_weight_integrable he hβ hedecay 0
  have he1 : Integrable (fun t => t*e t) halfLine := by
    simpa only [pow_one] using polynomial_weight_integrable he hβ hedecay 1
  have hg1 : Integrable (fun t => t*g t) halfLine := by
    simpa only [pow_one] using polynomial_weight_integrable hg hβ hgdecay 1
  have hlim1 : Tendsto (fun t => t*e t) atTop (𝓝 0) := by
    simpa only [pow_one] using polynomial_weight_tendsto_zero hβ hedecay 1
  exact ⟨first_moment_identity hac hode he0 hg1 hlim1,
    second_moment_identity hac hode he1 (polynomial_weight_integrable hg hβ hgdecay 2)
      (polynomial_weight_tendsto_zero hβ hedecay 2)⟩

end Article14.PhysicalLaplace
