import Article14.ExactDelay
import Article14.PhysicalFamily
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic

/-! The exact two-lag plant in Theorem 18, with the first lag stored before
its output lag. All four physical plant/controller coordinates are retained. -/
namespace Article14.ExactDelay
open Matrix

noncomputable def plantA : Matrix (Fin 2) (Fin 2) ℝ := !![-1, 0; 1, -1]
noncomputable def plantB : Fin 2 → ℝ := ![1, 0]
noncomputable def plantC : Fin 2 → ℝ := ![0, 1]
noncomputable def plantEquilibrium : Fin 2 → ℝ := ![1, 1]

@[simp] theorem plant_output (x : Fin 2 → ℝ) :
    finitePlantOutput plantC x = x 1 := by
  simp [finitePlantOutput, plantC, Fin.sum_univ_two]

@[simp] theorem plant_dynamics_zero (x : Fin 2 → ℝ) (u : ℝ) :
    finitePlantDynamics plantA plantB x u 0 = -x 0 + u := by
  simp [finitePlantDynamics, plantA, plantB, Fin.sum_univ_two]

@[simp] theorem plant_dynamics_one (x : Fin 2 → ℝ) (u : ℝ) :
    finitePlantDynamics plantA plantB x u 1 = x 0 - x 1 := by
  simp [finitePlantDynamics, plantA, plantB, Fin.sum_univ_two, sub_eq_add_neg]

theorem plant_equilibrium (j : Fin 2) :
    (∑ l, plantA j l * plantEquilibrium l) + plantB j / 1 = 0 := by
  fin_cases j <;> norm_num [plantA, plantB, plantEquilibrium, Fin.sum_univ_two]

theorem plant_unit_output : (∑ j, plantC j * plantEquilibrium j) = 1 := by
  norm_num [plantC, plantEquilibrium, Fin.sum_univ_two]

theorem plant_nonsingular : (PhysicalPlant.pencil plantA 0).det ≠ 0 := by
  norm_num [PhysicalPlant.pencil, plantA, Matrix.det_fin_two]

/-- The factory accepts precisely the all-history stability conclusion. The
subsequent state-equivalence module proves that conclusion for this plant. -/
noncomputable def plantDataOfStable
    (h : IsRetardedSharedExponentiallyStable (finitePlantOutput plantC)
      (finitePlantDynamics plantA plantB) kp ti td tf (1 / 4) 0 0) :
    StablePIDFData (Fin 2) where
  A := plantA
  B := plantB
  C := plantC
  xInf := plantEquilibrium
  Kp := kp
  Ti := ti
  Td := td
  Tf := tf
  k := 1
  L := 1 / 4
  Kp_pos := parameters_positive.2.2.1
  Ti_pos := parameters_positive.2.1
  Td_pos := parameters_positive.2.2.2
  Tf_pos := parameters_positive.1
  k_pos := by norm_num
  L_nonneg := by norm_num
  equilibrium := plant_equilibrium
  unit_output := plant_unit_output
  nonsingular := plant_nonsingular
  stable := h

end Article14.ExactDelay
