import Article14.FamilyStability
import Article14.PIDFAlgebra
import Mathlib.LinearAlgebra.Matrix.Charpoly.Eigs
import Mathlib.Topology.Algebra.Module.FiniteDimension

/-!
# The actual four-state realization of the uncertain second-order family

The state is `(y, y', xI, xF)`. The first two coordinates realize
`T² y'' + v y' + y = K u`, and the last two are exactly the shared controller
states of the article. The full characteristic determinant is calculated
without cancelling modes and identified with the already proved quartic.
-/

namespace Article14.FamilyStability

open Matrix
open scoped Matrix

noncomputable def secondOrderOutput (x : Fin 2 → ℝ) : ℝ := x 0

noncomputable def secondOrderDynamics (K T v : ℝ) (x : Fin 2 → ℝ) (u : ℝ) :
    Fin 2 → ℝ := ![x 1, (-x 0-v*x 1+K*u)/T^2]

/-- Reorder the actual two plant and two shared controller states into four
scalar coordinates. No extra integrator or cancelled state is introduced. -/
noncomputable def familyStateEquiv :
    (Fin 4 → ℝ) ≃L[ℝ] ((Fin 2 → ℝ) × ℝ × ℝ) :=
  LinearEquiv.toContinuousLinearEquiv
    { toFun := fun x => (![x 0,x 1], x 2, x 3)
      invFun := fun z => ![z.1 0,z.1 1,z.2.1,z.2.2]
      left_inv := by intro x; ext j; fin_cases j <;> rfl
      right_inv := by
        intro z
        apply Prod.ext
        · ext j; fin_cases j <;> rfl
        · rfl
      map_add' := by
        intro x y
        apply Prod.ext
        · ext j; fin_cases j <;> rfl
        · rfl
      map_smul' := by
        intro m x
        apply Prod.ext
        · ext j; fin_cases j <;> rfl
        · rfl }

theorem familyStateEquiv_apply (x : Fin 4 → ℝ) :
    familyStateEquiv x = (![x 0,x 1], x 2, x 3) := rfl

theorem familyStateEquiv_symm_apply (z : (Fin 2 → ℝ) × ℝ × ℝ) :
    familyStateEquiv.symm z = ![z.1 0,z.1 1,z.2.1,z.2.2] := rfl

/-- Matrix of the actual homogeneous shared-state PIDF implementation,
where `k = K*Kp`. -/
noncomputable def familyStateMatrix (f i d k T v : ℝ) : Matrix (Fin 4) (Fin 4) ℝ :=
  !![0,1,0,0;
     -(1+k+k*d/f)/T^2,-v/T^2,k/(i*T^2),-k*d/(f*T^2);
     -1,0,0,0;
     -1/f,0,0,-1/f]

noncomputable def familyStateOperator (f i d k T v : ℝ) :
    (Fin 4 → ℝ) →L[ℝ] (Fin 4 → ℝ) :=
  (familyStateMatrix f i d k T v).mulVecLin.toContinuousLinearMap

theorem familyStateOperator_apply (f i d k T v : ℝ) (x : Fin 4 → ℝ) :
    familyStateOperator f i d k T v x = (familyStateMatrix f i d k T v).mulVec x := rfl

theorem family_state_equations (f i d K Kp T v b c : ℝ) (x : Fin 4 → ℝ) :
    familyStateEquiv ((familyStateMatrix f i d (K*Kp) T v).mulVec x) =
      sharedClosedLoopRhs secondOrderOutput (secondOrderDynamics K T v)
        Kp i d f b c 0 (familyStateEquiv x) := by
  apply Prod.ext
  · ext j
    fin_cases j <;>
      simp [familyStateEquiv_apply, familyStateMatrix, sharedClosedLoopRhs,
        sharedControllerRhs, secondOrderOutput, secondOrderDynamics,
        dotProduct, Fin.sum_univ_succ, div_eq_mul_inv]
    ring
  · apply Prod.ext <;>
      simp [familyStateEquiv_apply, familyStateMatrix, sharedClosedLoopRhs,
        sharedControllerRhs, secondOrderOutput, secondOrderDynamics,
        dotProduct, Fin.sum_univ_succ, div_eq_mul_inv]
    ring

theorem family_state_retarded_zero_delay (f i d K Kp T v b c : ℝ)
    (history : ℝ → (Fin 2 → ℝ) × ℝ × ℝ) :
    retardedSharedRhs secondOrderOutput (secondOrderDynamics K T v)
      Kp i d f 0 b c (fun _ => 0) history =
      familyStateEquiv ((familyStateMatrix f i d (K*Kp) T v).mulVec
        (familyStateEquiv.symm (history 0))) := by
  rw [family_state_equations f i d K Kp T v b c, familyStateEquiv.apply_symm_apply]
  simp [retardedSharedRhs, sharedClosedLoopRhs]

theorem family_state_operator_matches (f i d K Kp T v b c : ℝ)
    (z : (Fin 2 → ℝ) × ℝ × ℝ) :
    sharedClosedLoopRhs secondOrderOutput (secondOrderDynamics K T v) Kp i d f b c 0 z =
      familyStateEquiv (familyStateOperator f i d (K*Kp) T v (familyStateEquiv.symm z)) := by
  rw [familyStateOperator_apply, family_state_equations f i d K Kp T v b c,
    familyStateEquiv.apply_symm_apply]

noncomputable def familyStateSymbol (f i d k T v : ℝ) (p : ℂ) :
    Matrix (Fin 4) (Fin 4) ℂ :=
  p • (1 : Matrix (Fin 4) (Fin 4) ℂ) -
    (familyStateMatrix f i d k T v).map Complex.ofReal

/-- Full uncancelled physical determinant, with the positive leading scale
`f*T²` divided out to give the monic state characteristic polynomial. -/
theorem family_state_determinant (f i d k T v : ℝ)
    (hf : f ≠ 0) (hi : i ≠ 0) (hT : T ≠ 0) (p : ℂ) :
    (familyStateSymbol f i d k T v p).det =
      quarticEval (coeff4 f T) (coeff3 f T v) (coeff2 f d k v)
        (coeff1 f i k) (coeff0 i k) p / ((f : ℂ)*(T : ℂ)^2) := by
  have hfC : (f : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hf
  have hiC : (i : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hi
  have hTC : (T : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hT
  rw [Matrix.det_succ_row_zero]
  simp only [Fin.sum_univ_succ, Fin.val_zero, Fin.val_succ, Matrix.det_fin_three,
    Matrix.submatrix_apply, familyStateSymbol, familyStateMatrix, Matrix.sub_apply,
    Matrix.smul_apply, Matrix.map_apply, smul_eq_mul]
  norm_num [Fin.succAbove, Matrix.one_apply]
  simp only [quarticEval, coeff4, coeff3, coeff2, coeff1, coeff0, gamma]
  push_cast
  field_simp
  ring

theorem family_state_spectrum (f i d k kmin T Tmax v : ℝ)
    (hf : 0 < f) (hi : 0 < i) (hd : 0 < d) (hkmin : 0 < kmin)
    (hfi : f ≤ i) (hC : 0 < marginC f i d) (hk : kmin ≤ k)
    (hT : 0 < T) (hTmax : T ≤ Tmax) (hv : 0 ≤ v)
    (hbound : Tmax ^ 2 < i * marginC f i d * (1 + kmin * gamma f i))
    (p : ℂ) (hp : (familyStateSymbol f i d k T v p).det = 0) : p.re < 0 := by
  rw [family_state_determinant f i d k T v hf.ne' hi.ne' hT.ne'] at hp
  have hden : (f : ℂ)*(T : ℂ)^2 ≠ 0 :=
    mul_ne_zero (Complex.ofReal_ne_zero.mpr hf.ne')
      (pow_ne_zero _ (Complex.ofReal_ne_zero.mpr hT.ne'))
  exact family_quartic_root_re_neg f i d k kmin T Tmax v hf hi hd hkmin hfi hC hk
    hT hTmax hv hbound p ((div_eq_zero_iff).mp hp |>.resolve_right hden)

/-- The computed determinant is the genuine characteristic polynomial of
the complexified physical state matrix, evaluated at any complex point. -/
theorem family_state_charpoly_eval (f i d k T v : ℝ) (p : ℂ) :
    ((familyStateMatrix f i d k T v).map Complex.ofReal).charpoly.eval p =
      (familyStateSymbol f i d k T v p).det := by
  rw [Matrix.eval_charpoly]
  unfold familyStateSymbol
  congr 2
  ext a b
  by_cases h : a=b <;> simp [Matrix.scalar_apply, h]

/-- Every member of the actual matrix spectrum lies strictly in the left
half-plane under the article's family-wide sufficient condition. -/
theorem family_state_mem_spectrum_re_neg (f i d k kmin T Tmax v : ℝ)
    (hf : 0 < f) (hi : 0 < i) (hd : 0 < d) (hkmin : 0 < kmin)
    (hfi : f ≤ i) (hC : 0 < marginC f i d) (hk : kmin ≤ k)
    (hT : 0 < T) (hTmax : T ≤ Tmax) (hv : 0 ≤ v)
    (hbound : Tmax ^ 2 < i * marginC f i d * (1 + kmin * gamma f i))
    (p : ℂ) (hp : p ∈ spectrum ℂ ((familyStateMatrix f i d k T v).map Complex.ofReal)) :
    p.re < 0 := by
  have hroot := Matrix.mem_spectrum_iff_isRoot_charpoly.mp hp
  apply family_state_spectrum f i d k kmin T Tmax v hf hi hd hkmin hfi hC hk
    hT hTmax hv hbound p
  rw [← family_state_charpoly_eval]
  exact hroot

/-- Exact continuum spectrum result for the article's benchmark controller.
Only the stated lower gain and upper time-constant bounds are needed. -/
theorem benchmark_physical_matrix_spectrum (K T ζ : ℝ)
    (hK : (4/5 : ℝ) ≤ K) (hT : 0 < T) (hTmax : T ≤ 12) (hζ : 0 ≤ ζ)
    (p : ℂ)
    (hp : p ∈ spectrum ℂ ((familyStateMatrix (6/5) 10 5 (K*4) T (2*ζ*T)).map
      Complex.ofReal)) : p.re < 0 := by
  exact family_state_mem_spectrum_re_neg (6/5) 10 5 (K*4) (16/5) T 12 (2*ζ*T)
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
    (by norm_num [marginC]) (by linarith) hT hTmax (by positivity)
    (by norm_num [marginC, gamma]) p hp

end Article14.FamilyStability
