import Article14.PositiveKernel
import Article14.MIACEProjection

/-!
# The actual positive-command feasible set

The two positivity constraints are imposed on genuine L¹ functions.  The
command constraint is an additional closed convex condition on the original
positive-kernel feasible set.  Its compactness follows from the kernel map's
injectivity and unit mass; compactness of the resulting set is not assumed.
-/
namespace Article14
open MeasureTheory Filter Set MIACE
open scoped Topology

/-- Theorem 17's F₊: admissible weights, a nonnegative impulse kernel, and a
nonnegative centered command (extended by zero to negative time). -/
noncomputable def positiveCommandFeasible (X : Set (ℝ × ℝ))
    (g₀ : RealL1) (G : (ℝ × ℝ) →L[ℝ] RealL1)
    (v₀ : RealL1) (V : (ℝ × ℝ) →L[ℝ] RealL1) : Set (ℝ × ℝ) :=
  kernelFeasible (kernelFeasible X g₀ G) v₀ V

theorem mem_positiveCommandFeasible_iff {X : Set (ℝ × ℝ)}
    {g₀ : RealL1} {G : (ℝ × ℝ) →L[ℝ] RealL1}
    {v₀ : RealL1} {V : (ℝ × ℝ) →L[ℝ] RealL1} {w : ℝ × ℝ} :
    w ∈ positiveCommandFeasible X g₀ G v₀ V ↔
      w ∈ X ∧ (0 : RealL1) ≤ g₀ + G w ∧ (0 : RealL1) ≤ v₀ + V w := by
  change ((w ∈ X ∧ _) ∧ _) ↔ _
  exact and_assoc

-- Theorem 17: the added all-time sign constraint is closed in L¹.
theorem positiveCommandFeasible_closed {X : Set (ℝ × ℝ)} (hX : IsClosed X)
    (g₀ : RealL1) (G : (ℝ × ℝ) →L[ℝ] RealL1)
    (v₀ : RealL1) (V : (ℝ × ℝ) →L[ℝ] RealL1) :
    IsClosed (positiveCommandFeasible X g₀ G v₀ V) :=
  kernelFeasible_closed (kernelFeasible_closed hX g₀ G) v₀ V

-- Theorem 17: both genuine a.e. positivity constraints remain convex.
theorem positiveCommandFeasible_convex {X : Set (ℝ × ℝ)} (hX : Convex ℝ X)
    (g₀ : RealL1) (G : (ℝ × ℝ) →L[ℝ] RealL1)
    (v₀ : RealL1) (V : (ℝ × ℝ) →L[ℝ] RealL1) :
    Convex ℝ (positiveCommandFeasible X g₀ G v₀ V) :=
  kernelFeasible_convex (kernelFeasible_convex hX g₀ G) v₀ V

-- Theorem 17: F₊ is compact even when the engineering set X is unbounded.
theorem positiveCommandFeasible_compact {X : Set (ℝ × ℝ)} (hX : IsClosed X)
    (g₀ : RealL1) (G : (ℝ × ℝ) →L[ℝ] RealL1)
    (v₀ : RealL1) (V : (ℝ × ℝ) →L[ℝ] RealL1)
    (hG : Function.Injective G)
    (hmass : ∀ w ∈ kernelFeasible X g₀ G, (∫ t, (g₀ + G w) t) = 1) :
    IsCompact (positiveCommandFeasible X g₀ G v₀ V) := by
  exact (kernelFeasible_compact hX g₀ G hG hmass).of_isClosed_subset
    (positiveCommandFeasible_closed hX g₀ G v₀ V) (fun _ hw => hw.1)

-- Theorem 17: the endpoints exist because F₊ has the proved geometry.
theorem positiveCommandFeasible_projection_interval {X : Set (ℝ × ℝ)}
    (hX : IsClosed X) (hconv : Convex ℝ X)
    (g₀ : RealL1) (G : (ℝ × ℝ) →L[ℝ] RealL1)
    (v₀ : RealL1) (V : (ℝ × ℝ) →L[ℝ] RealL1)
    (hG : Function.Injective G)
    (hmass : ∀ w ∈ kernelFeasible X g₀ G, (∫ t, (g₀ + G w) t) = 1)
    (hne : (positiveCommandFeasible X g₀ G v₀ V).Nonempty) :
    ∃ lo hi : ℝ, lo ≤ hi ∧
      Prod.fst '' positiveCommandFeasible X g₀ G v₀ V = Icc lo hi :=
  compact_convex_projection_interval
    (positiveCommandFeasible_compact hX g₀ G v₀ V hG hmass)
    (positiveCommandFeasible_convex hconv g₀ G v₀ V) hne

-- Membership really means positivity of representatives, not a separate
-- finite collection of sampled inequalities.
theorem positiveCommandFeasible_signs {X : Set (ℝ × ℝ)}
    {g₀ : RealL1} {G : (ℝ × ℝ) →L[ℝ] RealL1}
    {v₀ : RealL1} {V : (ℝ × ℝ) →L[ℝ] RealL1}
    {w : ℝ × ℝ} (hw : w ∈ positiveCommandFeasible X g₀ G v₀ V) :
    (∀ᵐ t, 0 ≤ (g₀ + G w) t) ∧ (∀ᵐ t, 0 ≤ (v₀ + V w) t) := by
  exact ⟨(Lp.coeFn_nonneg _).mpr hw.1.2, (Lp.coeFn_nonneg _).mpr hw.2⟩

-- The actual step error is nonnegative because it is the tail of a
-- nonnegative unit-mass impulse kernel.  No error sign is assumed here.
theorem positiveCommandFeasible_error_nonnegative {X : Set (ℝ × ℝ)}
    {g₀ : RealL1} {G : (ℝ × ℝ) →L[ℝ] RealL1}
    {v₀ : RealL1} {V : (ℝ × ℝ) →L[ℝ] RealL1}
    {w : ℝ × ℝ} (hw : w ∈ positiveCommandFeasible X g₀ G v₀ V)
    (hmass : (∫ t, (g₀ + G w) t) = 1) (t : ℝ) :
    0 ≤ 1 - kernelStep (fun s => (g₀ + G w) s) t := by
  exact sub_nonneg.mpr (positive_kernel_step_bounds
    (L1.integrable_coeFn _) (positiveCommandFeasible_signs hw).1 hmass t).2

-- Assembly with actual physical signals.  Their transfer and mean identities
-- are supplied by the physical PIDF theorems; the TWO sign conditions are
-- now conclusions of the actual kernel/command feasible set.
theorem positiveMIACEFamily_of_positiveCommandFeasible
    {X : Set (ℝ × ℝ)} {g₀ : RealL1} {G : (ℝ × ℝ) →L[ℝ] RealL1}
    {v₀ : RealL1} {V : (ℝ × ℝ) →L[ℝ] RealL1}
    {e v : (ℝ × ℝ) → ℝ → ℝ} {H : ℝ → ℝ} {δ k Kp Ti : ℝ}
    (hmass : ∀ w ∈ kernelFeasible X g₀ G, (∫ t, (g₀ + G w) t) = 1)
    (he : ∀ w ∈ positiveCommandFeasible X g₀ G v₀ V,
      e w =ᵐ[halfLine] fun t => 1 - kernelStep (fun s => (g₀ + G w) s) t)
    (hv : ∀ w ∈ positiveCommandFeasible X g₀ G v₀ V,
      v w =ᵐ[halfLine] fun t => (v₀ + V w) t)
    (hresponse : ∀ w ∈ positiveCommandFeasible X g₀ G v₀ V,
      LocalTransferResponse (e w) (v w) H δ)
    (hmean : ∀ w ∈ positiveCommandFeasible X g₀ G v₀ V,
      (∫ t, e w t ∂halfLine) = trackingMean k Kp Ti w.1) :
    PositiveMIACEFamily (positiveCommandFeasible X g₀ G v₀ V) e v H δ k Kp Ti := by
  refine ⟨hresponse, ?_, ?_, hmean⟩
  · intro w hw
    filter_upwards [he w hw] with t ht
    rw [ht]
    exact positiveCommandFeasible_error_nonnegative hw (hmass w hw.1) t
  · intro w hw
    have hsign : ∀ᵐ t ∂halfLine, 0 ≤ (v₀ + V w) t :=
      ae_restrict_of_ae (positiveCommandFeasible_signs hw).2
    filter_upwards [hv w hw, hsign] with t ht hs
    simpa only [ht] using hs

-- The complete geometric reduction: the endpoints, the feasible clipped
-- weight, and the true signal-level minimum are all derived.  There is no
-- compactness, interval, or optimizer assumption about F₊.
theorem positiveCommandFeasible_miace_reduction
    {X : Set (ℝ × ℝ)} (hX : IsClosed X) (hconv : Convex ℝ X)
    (g₀ : RealL1) (G : (ℝ × ℝ) →L[ℝ] RealL1)
    (v₀ : RealL1) (V : (ℝ × ℝ) →L[ℝ] RealL1)
    (hG : Function.Injective G)
    (hmass : ∀ w ∈ kernelFeasible X g₀ G, (∫ t, (g₀ + G w) t) = 1)
    (hne : (positiveCommandFeasible X g₀ G v₀ V).Nonempty)
    {e v : (ℝ × ℝ) → ℝ → ℝ} {H : ℝ → ℝ} {δ k Kp Ti : ℝ}
    (h : PositiveMIACEFamily (positiveCommandFeasible X g₀ G v₀ V) e v H δ k Kp Ti)
    (μ α : ℝ) (hTi : 0 < Ti) (hα : 0 < α) (hΓ : 0 ≤ μ + δ)
    (hH : HasDerivAt H (-μ) 0) (h0 : H 0 = 1) :
    ∃ lo hi : ℝ, lo ≤ hi ∧
      (∀ b, (∃ c, (b, c) ∈ positiveCommandFeasible X g₀ G v₀ V) ↔ b ∈ Icc lo hi) ∧
      (∃ c, (clampedWeight lo hi (miaceTarget k Kp Ti (μ + δ) α), c) ∈
        positiveCommandFeasible X g₀ G v₀ V ∧
        ∀ w ∈ positiveCommandFeasible X g₀ G v₀ V,
          miace α (e (clampedWeight lo hi (miaceTarget k Kp Ti (μ + δ) α), c))
            (v (clampedWeight lo hi (miaceTarget k Kp Ti (μ + δ) α), c)) halfLine ≤
              miace α (e w) (v w) halfLine) ∧
      ((∃ w ∈ positiveCommandFeasible X g₀ G v₀ V,
        miace α (e w) (v w) halfLine = (μ + δ) * Real.sqrt (α / (1 + α))) ↔
          miaceTarget k Kp Ti (μ + δ) α ∈ Icc lo hi) :=
  positive_family_compact_convex_reduction h μ α hTi hα hΓ hH h0
    (positiveCommandFeasible_compact hX g₀ G v₀ V hG hmass)
    (positiveCommandFeasible_convex hconv g₀ G v₀ V) hne

-- The stronger fiber statement in Theorem 17: ALL feasible c values above
-- the clipped b have the same exact minimum, not just the selected witness.
theorem positiveCommandFeasible_every_clipped_fiber
    {X : Set (ℝ × ℝ)} (hX : IsClosed X) (hconv : Convex ℝ X)
    (g₀ : RealL1) (G : (ℝ × ℝ) →L[ℝ] RealL1)
    (v₀ : RealL1) (V : (ℝ × ℝ) →L[ℝ] RealL1)
    (hG : Function.Injective G)
    (hmass : ∀ w ∈ kernelFeasible X g₀ G, (∫ t, (g₀ + G w) t) = 1)
    (hne : (positiveCommandFeasible X g₀ G v₀ V).Nonempty)
    {e v : (ℝ × ℝ) → ℝ → ℝ} {H : ℝ → ℝ} {δ k Kp Ti : ℝ}
    (h : PositiveMIACEFamily (positiveCommandFeasible X g₀ G v₀ V) e v H δ k Kp Ti)
    (μ α : ℝ) (hTi : 0 < Ti) (hα : 0 < α)
    (hH : HasDerivAt H (-μ) 0) (h0 : H 0 = 1) :
    ∃ lo hi : ℝ, lo ≤ hi ∧
      Prod.fst '' positiveCommandFeasible X g₀ G v₀ V = Icc lo hi ∧
      ∀ wstar ∈ positiveCommandFeasible X g₀ G v₀ V,
        wstar.1 = clampedWeight lo hi (miaceTarget k Kp Ti (μ + δ) α) →
        (∀ w ∈ positiveCommandFeasible X g₀ G v₀ V,
          miace α (e wstar) (v wstar) halfLine ≤ miace α (e w) (v w) halfLine) ∧
        (miace α (e wstar) (v wstar) halfLine) ^ 2 =
          α * (μ + δ) ^ 2 / (1 + α) + (1 + α) * Ti ^ 2 *
            (clampedWeight lo hi (miaceTarget k Kp Ti (μ + δ) α) -
              miaceTarget k Kp Ti (μ + δ) α) ^ 2 := by
  obtain ⟨lo, hi, hlohi, himage⟩ := positiveCommandFeasible_projection_interval
    hX hconv g₀ G v₀ V hG hmass hne
  refine ⟨lo, hi, hlohi, himage, ?_⟩
  intro wstar hwstar hb
  constructor
  · intro w hw
    exact positive_family_miace_projection h μ α lo hi hTi hα hH h0
      (fun z hz => himage ▸ ⟨z, hz, rfl⟩) hwstar hb hw
  · rw [positive_family_cost_reduction h μ α hα hH h0 hwstar, hb]
    exact positiveCommandCostSq_completion k Kp Ti (μ + δ) α _ hTi hα

end Article14
