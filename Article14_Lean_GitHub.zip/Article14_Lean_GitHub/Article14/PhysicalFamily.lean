import Article14.StepAffineImpulse
import Article14.SignalL1

/-!
# The complete physical family at fixed feedback parameters

Only the finite plant, controller coefficients, physical equilibrium, and
same-loop internal stability are data. The actual step responses and ordinary
kernels are constructed. Their affine L¹ realization, unit mass, moment
identities, and independence are proved from those physical data.
-/
namespace Article14
open MeasureTheory Filter Set MIACE
open scoped Topology
open PhysicalPlant PhysicalLaplace

/-- Static physical data for the general fixed-feedback delayed PIDF result.
There is no response, transfer certificate, or affine-kernel premise here. -/
structure StablePIDFData (n : Type*) [Fintype n] [DecidableEq n] where
  A : Matrix n n ℝ
  B : n → ℝ
  C : n → ℝ
  xInf : n → ℝ
  Kp : ℝ
  Ti : ℝ
  Td : ℝ
  Tf : ℝ
  k : ℝ
  L : ℝ
  Kp_pos : 0 < Kp
  Ti_pos : 0 < Ti
  Td_pos : 0 < Td
  Tf_pos : 0 < Tf
  k_pos : 0 < k
  L_nonneg : 0 ≤ L
  equilibrium : ∀ j, (∑ l, A j l*xInf l)+B j/k=0
  unit_output : (∑ j, C j*xInf j) = 1
  nonsingular : (pencil A 0).det ≠ 0
  stable : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
    (finitePlantDynamics A B) Kp Ti Td Tf L 0 0

namespace StablePIDFData
variable {n : Type*} [Fintype n] [DecidableEq n]

-- The same full-history stability property holds at every reference weight.
theorem stable_weights (d : StablePIDFData n) (w : ℝ × ℝ) :
    IsRetardedSharedExponentiallyStable (finitePlantOutput d.C)
      (finitePlantDynamics d.A d.B) d.Kp d.Ti d.Td d.Tf d.L w.1 w.2 :=
  (retardedShared_exponentialStability_iff _ _ d.Kp d.Ti d.Td d.Tf d.L
    0 0 w.1 w.2).mp d.stable

-- Existence is inherited from the homogeneous history problem, not postulated.
theorem response_exists (d : StablePIDFData n) (w : ℝ × ℝ) :
    ∃ q : ℝ → (n → ℝ) × ℝ × ℝ,
      StepLoopDynamics d.A d.B d.C d.Kp d.Ti d.Td d.Tf d.L w.1 w.2 q ∧
      ∀ t ∈ Icc 0 d.L, q t = transportStep w.2 d.Tf t :=
  exists_stepLoopDynamics d.L_nonneg d.Ti_pos.ne' d.k_pos.ne' d.Kp_pos.ne'
    d.equilibrium d.unit_output (d.stable_weights w).1

noncomputable def chosenResponse (d : StablePIDFData n) (w : ℝ × ℝ) :
    ℝ → (n → ℝ) × ℝ × ℝ := Classical.choose (d.response_exists w)

theorem chosenResponse_dynamics (d : StablePIDFData n) (w : ℝ × ℝ) :
    StepLoopDynamics d.A d.B d.C d.Kp d.Ti d.Td d.Tf d.L w.1 w.2
      (d.chosenResponse w) := (Classical.choose_spec (d.response_exists w)).1

/-- Three actual physical responses determine the entire weight family. -/
noncomputable def response (d : StablePIDFData n) (w : ℝ × ℝ) :
    ℝ → (n → ℝ) × ℝ × ℝ :=
  stepAffineFamily (d.chosenResponse (0,0)) (d.chosenResponse (1,0))
    (d.chosenResponse (0,1)) w.1 w.2

theorem response_dynamics (d : StablePIDFData n) (w : ℝ × ℝ) :
    StepLoopDynamics d.A d.B d.C d.Kp d.Ti d.Td d.Tf d.L w.1 w.2
      (d.response w) :=
  stepLoopDynamics_affine_family (d.chosenResponse_dynamics (0,0))
    (d.chosenResponse_dynamics (1,0)) (d.chosenResponse_dynamics (0,1)) w.1 w.2

-- This family identifies every actual zero-history solution on physical time.
theorem response_unique (d : StablePIDFData n) (w : ℝ × ℝ)
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (hq : StepLoopDynamics d.A d.B d.C d.Kp d.Ti d.Td d.Tf d.L w.1 w.2 q) :
    EqOn q (d.response w) (Ici 0) :=
  stepLoopDynamics_unique d.Ti_pos.ne' d.k_pos.ne' d.Kp_pos.ne'
    d.equilibrium d.unit_output (d.stable_weights w).1 hq (d.response_dynamics w)

theorem response_prefix (d : StablePIDFData n) (w : ℝ × ℝ) :
    ∀ t ∈ Icc 0 d.L, d.response w t = transportStep w.2 d.Tf t :=
  stepLoopDynamics_transport_prefix (d.response_dynamics w)

theorem response_basis (d : StablePIDFData n) :
    d.response (0,0) = d.chosenResponse (0,0) ∧
    d.response (1,0) = d.chosenResponse (1,0) ∧
    d.response (0,1) = d.chosenResponse (0,1) :=
  stepAffineFamily_basis _ _ _

noncomputable def kernel (d : StablePIDFData n) (w : ℝ × ℝ) : ℝ → ℝ :=
  stepImpulse d.A d.B d.C d.Kp d.Ti d.Td d.Tf d.L w.1 w.2 (d.response w)

noncomputable def error (d : StablePIDFData n) (w : ℝ × ℝ) : ℝ → ℝ :=
  fun t => 1-finitePlantOutput d.C (d.response w t).1

noncomputable def command (d : StablePIDFData n) (w : ℝ × ℝ) : ℝ → ℝ :=
  fun t => d.k*stepCommand d.C d.Kp d.Ti d.Td d.Tf w.1 w.2 (d.response w) t-1

noncomputable def transfer (d : StablePIDFData n) : ℝ → ℝ :=
  normalizedTransfer d.A d.B d.C d.k

noncomputable def gamma (d : StablePIDFData n) : ℝ :=
  residenceTime d.A d.C d.xInf+d.L

-- Transfer and signed error area are both consequences of the physical loop.
theorem physical_transfer (d : StablePIDFData n) (w : ℝ × ℝ) :
    LocalTransferResponse (d.error w) (d.command w) d.transfer d.L ∧
    (∫ t, d.error w t ∂halfLine) = meanTime d.Ti d.k d.Kp w.1 :=
  stable_step_transfer_and_area (d.response_dynamics w) d.Ti_pos.ne' d.k_pos.ne'
    d.Kp_pos.ne' d.L_nonneg (d.stable_weights w) d.equilibrium d.unit_output d.nonsingular

theorem kernel_integrable (d : StablePIDFData n) (w : ℝ × ℝ) :
    Integrable (d.kernel w) halfLine :=
  stable_step_impulse_integrable (d.response_dynamics w) d.Ti_pos.ne' d.k_pos.ne'
    d.Kp_pos.ne' d.L_nonneg (d.stable_weights w) d.equilibrium d.unit_output

theorem kernel_integrable_full (d : StablePIDFData n) (w : ℝ × ℝ) :
    Integrable (d.kernel w) :=
  stable_step_impulse_integrable_full (d.response_dynamics w) d.Ti_pos.ne' d.k_pos.ne'
    d.Kp_pos.ne' d.L_nonneg (d.stable_weights w) d.equilibrium d.unit_output

theorem kernel_mass (d : StablePIDFData n) (w : ℝ × ℝ) :
    (∫ t, d.kernel w t ∂halfLine) = 1 :=
  stable_step_impulse_unit_mass (d.response_dynamics w) d.Ti_pos.ne' d.k_pos.ne'
    d.Kp_pos.ne' d.L_nonneg (d.stable_weights w) d.equilibrium d.unit_output

theorem kernel_moments (d : StablePIDFData n) (w : ℝ × ℝ) :
    (∫ t, t*d.kernel w t ∂halfLine) = meanTime d.Ti d.k d.Kp w.1 ∧
    (∫ t, t^2*d.kernel w t ∂halfLine) =
      2*secondErrorMoment d.Kp (d.Kp/d.Ti) (d.Kp*d.Td) d.k d.gamma
        (meanTime d.Ti d.k d.Kp w.1) w.2 :=
  stable_step_impulse_moments (d.response_dynamics w) d.Ti_pos.ne' d.k_pos.ne'
    d.Kp_pos.ne' d.Tf_pos d.L_nonneg (d.stable_weights w) d.equilibrium d.unit_output
    d.nonsingular

theorem kernel_weight_integrable (d : StablePIDFData n) (w : ℝ × ℝ) (m : ℕ) :
    Integrable (fun t => t^m*d.kernel w t) halfLine :=
  stable_step_impulse_weight_integrable (d.response_dynamics w) d.Ti_pos.ne' d.k_pos.ne'
    d.Kp_pos.ne' d.L_nonneg (d.stable_weights w) d.equilibrium d.unit_output m

theorem error_integrable (d : StablePIDFData n) (w : ℝ × ℝ) :
    Integrable (d.error w) halfLine := (d.physical_transfer w).1.error_integrable

theorem command_integrable (d : StablePIDFData n) (w : ℝ × ℝ) :
    Integrable (d.command w) halfLine := (d.physical_transfer w).1.command_integrable

-- The ordinary kernels have their actual affine dependence, pointwise.
theorem kernel_affine (d : StablePIDFData n) (w : ℝ × ℝ) (t : ℝ) :
    d.kernel w t = d.kernel (0,0) t + w.1*(d.kernel (1,0) t-d.kernel (0,0) t) +
      w.2*(d.kernel (0,1) t-d.kernel (0,0) t) :=
  stepLoopDynamics_impulse_affine d.Ti_pos.ne' d.k_pos.ne' d.Kp_pos.ne'
    d.equilibrium d.unit_output (d.stable_weights w).1 (d.response_dynamics w)
    (d.response_dynamics (0,0)) (d.response_dynamics (1,0))
    (d.response_dynamics (0,1)) t

theorem command_affine (d : StablePIDFData n) (w : ℝ × ℝ) (t : ℝ) :
    d.command w t = d.command (0,0) t + w.1*(d.command (1,0) t-d.command (0,0) t) +
      w.2*(d.command (0,1) t-d.command (0,0) t) := by
  unfold command
  rw [d.response_basis.1, d.response_basis.2.1, d.response_basis.2.2]
  exact stepAffineFamily_normalized_command d.C d.Kp d.Ti d.Td d.Tf d.k w.1 w.2
    (d.chosenResponse (0,0)) (d.chosenResponse (1,0)) (d.chosenResponse (0,1)) t

noncomputable def kernelL1 (d : StablePIDFData n) (w : ℝ × ℝ) : RealL1 :=
  signalL1 (d.kernel w) (d.kernel_integrable w)

noncomputable def commandL1 (d : StablePIDFData n) (w : ℝ × ℝ) : RealL1 :=
  signalL1 (d.command w) (d.command_integrable w)

noncomputable def kernelBase (d : StablePIDFData n) : RealL1 := d.kernelL1 (0,0)

noncomputable def kernelDirections (d : StablePIDFData n) : (ℝ × ℝ) →L[ℝ] RealL1 :=
  pairSpan (d.kernelL1 (1,0)-d.kernelL1 (0,0)) (d.kernelL1 (0,1)-d.kernelL1 (0,0))

noncomputable def commandBase (d : StablePIDFData n) : RealL1 := d.commandL1 (0,0)

noncomputable def commandDirections (d : StablePIDFData n) : (ℝ × ℝ) →L[ℝ] RealL1 :=
  pairSpan (d.commandL1 (1,0)-d.commandL1 (0,0)) (d.commandL1 (0,1)-d.commandL1 (0,0))

-- The finite-dimensional continuous affine map in L¹ is now constructed.
theorem kernelL1_eq (d : StablePIDFData n) (w : ℝ × ℝ) :
    d.kernelL1 w = d.kernelBase+d.kernelDirections w :=
  signalL1_affine_family d.kernel_integrable
    (fun w => Eventually.of_forall (d.kernel_affine w)) w

theorem commandL1_eq (d : StablePIDFData n) (w : ℝ × ℝ) :
    d.commandL1 w = d.commandBase+d.commandDirections w :=
  signalL1_affine_family d.command_integrable
    (fun w => Eventually.of_forall (d.command_affine w)) w

theorem kernelL1_coe (d : StablePIDFData n) (w : ℝ × ℝ) :
    d.kernelL1 w =ᵐ[halfLine] d.kernel w :=
  signalL1_coe_halfLine (d.kernel w) (d.kernel_integrable w)

theorem commandL1_coe (d : StablePIDFData n) (w : ℝ × ℝ) :
    d.commandL1 w =ᵐ[halfLine] d.command w :=
  signalL1_coe_halfLine (d.command w) (d.command_integrable w)

theorem kernel_mass_l1 (d : StablePIDFData n) (w : ℝ × ℝ) :
    (∫ t, d.kernelL1 w t) = 1 := by
  rw [kernelL1, signalL1_integral]
  exact d.kernel_mass w

-- Actual first and second moments identify both weights, proving independence.
theorem kernelL1_injective (d : StablePIDFData n) : Function.Injective d.kernelL1 := by
  apply kernel_family_injective_of_halfLine_moments d.kernelL1
    d.Ti d.k d.Kp d.Td d.gamma d.Ti_pos.ne' d.Kp_pos.ne' d.Td_pos.ne'
  · intro w
    rw [← (d.kernel_moments w).1]
    apply integral_congr_ae
    filter_upwards [d.kernelL1_coe w] with t ht
    rw [ht]
  · intro w
    rw [← (d.kernel_moments w).2]
    apply integral_congr_ae
    filter_upwards [d.kernelL1_coe w] with t ht
    rw [ht]

theorem kernelDirections_injective (d : StablePIDFData n) :
    Function.Injective d.kernelDirections := by
  intro w z h
  apply d.kernelL1_injective
  rw [d.kernelL1_eq, d.kernelL1_eq, h]

-- Convenient projections of the end-to-end physical transfer theorem.
theorem transfer_response (d : StablePIDFData n) (w : ℝ × ℝ) :
    LocalTransferResponse (d.error w) (d.command w) d.transfer d.L :=
  (d.physical_transfer w).1

theorem error_area (d : StablePIDFData n) (w : ℝ × ℝ) :
    (∫ t, d.error w t ∂halfLine) = meanTime d.Ti d.k d.Kp w.1 :=
  (d.physical_transfer w).2

theorem transfer_zero (d : StablePIDFData n) : d.transfer 0 = 1 :=
  normalizedTransfer_zero d.equilibrium d.unit_output d.nonsingular

theorem transfer_hasDerivAt_zero (d : StablePIDFData n) :
    HasDerivAt d.transfer (-(d.gamma-d.L)) 0 := by
  simpa only [transfer, gamma, add_sub_cancel_right] using
    normalizedTransfer_hasDerivAt_zero d.equilibrium d.unit_output d.nonsingular

theorem kernelL1_coe_halfLine (d : StablePIDFData n) (w : ℝ × ℝ) :
    d.kernelL1 w =ᵐ[halfLine] d.kernel w := d.kernelL1_coe w

theorem commandL1_coe_halfLine (d : StablePIDFData n) (w : ℝ × ℝ) :
    d.commandL1 w =ᵐ[halfLine] d.command w := d.commandL1_coe w

-- The causal kernel also identifies the full-line representative used by
-- cumulative kernels, whereas the command is deliberately only causalized.
theorem kernelL1_coe_full (d : StablePIDFData n) (w : ℝ × ℝ) :
    d.kernelL1 w =ᵐ[volume] d.kernel w := by
  apply (signalL1_coe (d.kernel w) (d.kernel_integrable w)).trans
  apply Eventually.of_forall
  intro t
  by_cases ht : 0 ≤ t
  · simp [causalize, ht]
  · simp [causalize, ht, kernel, stepImpulse, (lt_of_not_ge ht).le]

-- The L¹ cumulative kernel is exactly the physical output, on its entire
-- nonnegative time domain. It is not a separately supplied response map.
theorem kernelStep_eq_output_l1 (d : StablePIDFData n) (w : ℝ × ℝ)
    (t : ℝ) (ht : 0 ≤ t) :
    kernelStep (fun s => d.kernelL1 w s) t =
      finitePlantOutput d.C (d.response w t).1 := by
  rw [stable_step_output_eq_kernelStep (d.response_dynamics w)
    d.Ti_pos.ne' d.k_pos.ne' d.Kp_pos.ne' d.L_nonneg (d.stable_weights w)
    d.equilibrium d.unit_output t ht]
  apply integral_congr_ae
  exact ae_restrict_of_ae (d.kernelL1_coe_full w)

end StablePIDFData
end Article14
