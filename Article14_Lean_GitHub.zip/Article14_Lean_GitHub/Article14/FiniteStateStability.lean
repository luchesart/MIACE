import Mathlib.Analysis.Normed.Algebra.GelfandFormula
import Mathlib.Analysis.Normed.Algebra.MatrixExponential
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.SpecialFunctions.Exponential
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.Calculus.Deriv.Mul
import Mathlib.LinearAlgebra.Matrix.Charpoly.Eigs
import Mathlib.LinearAlgebra.Eigenspace.Minpoly
import Mathlib.Tactic

/-!
# Finite-dimensional spectral stability

The estimates in this file are derived from the spectrum.  No exponential
decay certificate is assumed: Gelfand's formula supplies a geometric bound
for a sufficiently small Euler step, which then bounds the exponential
series of the continuous-time generator.
-/
namespace Article14.FiniteStateStability
open Filter Set
open scoped Topology

theorem complex_euler_eventually_contracting (z : ℂ) (hz : z.re < 0) :
    ∀ᶠ h : ℝ in 𝓝[>] 0, ‖1+(h:ℂ)*z‖ < 1 := by
  have hc : ContinuousAt (fun h : ℝ => h*‖z‖^2+2*z.re) 0 := by fun_prop
  have he : ∀ᶠ h : ℝ in 𝓝 0, h*‖z‖^2+2*z.re < 0 :=
    hc.eventually (gt_mem_nhds (by linarith : (0:ℝ)*‖z‖^2+2*z.re < 0))
  filter_upwards [he.filter_mono nhdsWithin_le_nhds,
    self_mem_nhdsWithin] with h hh hp
  have hp' : 0 < h := hp
  apply (sq_lt_sq₀ (norm_nonneg _) zero_le_one).mp
  have heq : ‖1+(h:ℂ)*z‖^2 = 1+h*(h*‖z‖^2+2*z.re) := by
    simp only [← Complex.normSq_eq_norm_sq, Complex.normSq_apply,
      Complex.add_re, Complex.add_im, Complex.mul_re, Complex.mul_im,
      Complex.one_re, Complex.one_im, Complex.ofReal_re, Complex.ofReal_im]
    ring
  rw [heq]
  nlinarith [mul_neg_of_pos_of_neg hp' hh]

section Banach
variable {A : Type*} [NormedRing A] [NormedAlgebra ℂ A] [CompleteSpace A]

theorem powers_bound_of_spectralRadius_lt (B : A) {r : ℝ} (hr : 0 < r)
    (hsp : spectralRadius ℂ B < ENNReal.ofReal r) :
    ∃ C : ℝ, 0 < C ∧ ∀ n : ℕ, ‖B^n‖ ≤ C*r^n := by
  have hfinite : spectralRadius ℂ B ≠ ⊤ := ne_top_of_lt hsp
  have hlim := (ENNReal.continuousAt_toReal hfinite).tendsto.comp
    (spectrum.pow_norm_pow_one_div_tendsto_nhds_spectralRadius B)
  have hroot : Tendsto (fun n : ℕ => ‖B^n‖ ^ (1/(n:ℝ))) atTop
      (𝓝 (spectralRadius ℂ B).toReal) := by
    simpa only [Function.comp_def, ENNReal.toReal_ofReal (Real.rpow_nonneg (norm_nonneg _) _)]
      using hlim
  have hlt : (spectralRadius ℂ B).toReal < r := by
    have := (ENNReal.toReal_lt_toReal hfinite ENNReal.ofReal_ne_top).mpr hsp
    simpa only [ENNReal.toReal_ofReal hr.le] using this
  obtain ⟨N, hN⟩ := eventually_atTop.mp ((tendsto_order.mp hroot).2 r hlt)
  let C : ℝ := 1 + ∑ j ∈ Finset.range (N+1), ‖B^j‖/r^j
  have hsum : 0 ≤ ∑ j ∈ Finset.range (N+1), ‖B^j‖/r^j :=
    Finset.sum_nonneg (fun j _ => div_nonneg (norm_nonneg _) (pow_pos hr _).le)
  have hC : 1 ≤ C := by dsimp [C]; linarith
  refine ⟨C, lt_of_lt_of_le zero_lt_one hC, ?_⟩
  intro n
  by_cases hn : n < N+1
  · have hs : ‖B^n‖/r^n ≤ ∑ j ∈ Finset.range (N+1), ‖B^j‖/r^j :=
      Finset.single_le_sum (fun j _ => div_nonneg (norm_nonneg (B^j)) (pow_pos hr j).le)
        (Finset.mem_range.mpr hn)
    apply (div_le_iff₀ (pow_pos hr n)).mp
    dsimp [C]
    linarith
  · have hn0 : n ≠ 0 := by omega
    have hnN : N ≤ n := by omega
    have hpower := pow_le_pow_left₀ (Real.rpow_nonneg (norm_nonneg (B^n)) _)
      (hN n hnN).le n
    rw [one_div, Real.rpow_inv_natCast_pow (norm_nonneg _) hn0] at hpower
    exact hpower.trans (le_mul_of_one_le_left (pow_pos hr n).le hC)

omit [CompleteSpace A] in
theorem exp_norm_bound_of_powers_bound (B : A) {C r : ℝ}
    (_hr : 0 ≤ r) (hpow : ∀ n : ℕ, ‖B^n‖ ≤ C*r^n)
    (t : ℝ) (ht : 0 ≤ t) :
    ‖NormedSpace.exp ((t:ℂ) • B)‖ ≤ C * Real.exp (t*r) := by
  have hs : Summable (fun n : ℕ => (n.factorial:ℝ)⁻¹ * (t*r)^n) := by
    simpa only [smul_eq_mul] using
      (NormedSpace.expSeries_summable' (𝕂 := ℝ) (t*r))
  rw [NormedSpace.exp_eq_tsum ℂ]
  calc
    ‖∑' n : ℕ, (n.factorial⁻¹:ℂ) • ((t:ℂ) • B)^n‖ ≤
        ∑' n : ℕ, ‖(n.factorial⁻¹:ℂ) • ((t:ℂ) • B)^n‖ :=
      norm_tsum_le_tsum_norm (NormedSpace.norm_expSeries_summable' _)
    _ ≤ ∑' n : ℕ, C * ((n.factorial:ℝ)⁻¹ * (t*r)^n) := by
      apply Summable.tsum_le_tsum _ (NormedSpace.norm_expSeries_summable' _) (hs.mul_left C)
      intro n
      simp only [smul_pow, norm_smul, norm_inv, Complex.norm_natCast, norm_pow,
        Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg ht]
      calc
        _ ≤ (n.factorial:ℝ)⁻¹ * (t^n * (C*r^n)) := by
          gcongr
          exact hpow n
        _ = _ := by rw [mul_pow]; ring
    _ = C * Real.exp (t*r) := by
      rw [tsum_mul_left, Real.exp_eq_exp_ℝ, NormedSpace.exp_eq_tsum ℝ]
      rfl

theorem exists_contracting_euler_step [Nontrivial A] (a : A)
    (hfinite : (spectrum ℂ a).Finite)
    (hneg : ∀ z ∈ spectrum ℂ a, z.re < 0) :
    ∃ h : ℝ, 0 < h ∧ spectralRadius ℂ (1+(h:ℂ) • a) < 1 := by
  have he : ∀ᶠ h : ℝ in 𝓝[>] 0, ∀ z ∈ spectrum ℂ a,
      ‖1+(h:ℂ)*z‖ < 1 :=
    hfinite.eventually_all.mpr (fun z hz => complex_euler_eventually_contracting z (hneg z hz))
  have hpos : ∀ᶠ h : ℝ in 𝓝[>] 0, 0 < h := self_mem_nhdsWithin
  obtain ⟨h, hp, hh⟩ := (hpos.and he).exists
  refine ⟨h, hp, ?_⟩
  apply spectrum.spectralRadius_lt_of_forall_lt (r := 1)
  intro z hz
  have hm := spectrum.map_polynomial_aeval a (1+Polynomial.C (h:ℂ)*Polynomial.X)
  have hmap : Polynomial.aeval a (1+Polynomial.C (h:ℂ)*Polynomial.X) = 1+(h:ℂ) • a := by
    simp [Algebra.smul_def]
  rw [hmap] at hm
  rw [hm] at hz
  obtain ⟨w, hw, rfl⟩ := hz
  change ‖Polynomial.eval w (1+Polynomial.C (h:ℂ)*Polynomial.X)‖ < (1:ℝ)
  simpa using hh w hw

theorem exp_norm_decay_of_euler_powers [NormedAlgebra ℚ A] (a : A) {h r C : ℝ}
    (hh : 0 < h) (hr : 0 ≤ r)
    (hpow : ∀ n : ℕ, ‖(1+(h:ℂ) • a)^n‖ ≤ C*r^n)
    (t : ℝ) (ht : 0 ≤ t) :
    ‖NormedSpace.exp ((t:ℂ) • a)‖ ≤ C*Real.exp (-((1-r)/h)*t) := by
  let B : A := 1+(h:ℂ) • a
  let s : ℝ := t/h
  have hs : 0 ≤ s := div_nonneg ht hh.le
  have hmul : s*h = t := by
    dsimp [s]
    field_simp [hh.ne']
  have he : (t:ℂ) • a = ((-s:ℝ):ℂ) • (1:A)+(s:ℂ) • B := by
    dsimp [B]
    rw [smul_add, smul_smul]
    change t • a = (-s) • (1:A) + (s • (1:A)+(s*h) • a)
    rw [hmul, neg_smul]
    abel
  have hc : Commute (((-s:ℝ):ℂ) • (1:A)) ((s:ℂ) • B) := by
    rw [← Algebra.algebraMap_eq_smul_one]
    exact Algebra.commute_algebraMap_left _ _
  have hexp : NormedSpace.exp ((t:ℂ) • a) =
      Complex.exp ((-s:ℝ):ℂ) • NormedSpace.exp ((s:ℂ) • B) := by
    rw [he, NormedSpace.exp_add_of_commute hc,
      ← Algebra.algebraMap_eq_smul_one, ← NormedSpace.algebraMap_exp_comm,
      ← Complex.exp_eq_exp_ℂ, ← Algebra.smul_def]
  rw [hexp, norm_smul, Complex.norm_exp_ofReal]
  calc
    _ ≤ Real.exp (-s)*(C*Real.exp (s*r)) :=
      mul_le_mul_of_nonneg_left (exp_norm_bound_of_powers_bound B hr hpow s hs)
        (Real.exp_nonneg _)
    _ = C*Real.exp (-((1-r)/h)*t) := by
      rw [mul_left_comm, ← Real.exp_add]
      congr 2
      dsimp [s]
      ring

-- A finite strictly negative spectrum yields actual exponential decay of
-- the continuous-time semigroup, including nonnormal and repeated modes.
theorem exp_decay_of_finite_negative_spectrum [NormedAlgebra ℚ A] [Nontrivial A] (a : A)
    (hfinite : (spectrum ℂ a).Finite)
    (hneg : ∀ z ∈ spectrum ℂ a, z.re < 0) :
    ∃ M α : ℝ, 0 < M ∧ 0 < α ∧ ∀ t : ℝ, 0 ≤ t →
      ‖NormedSpace.exp ((t:ℂ) • a)‖ ≤ M*Real.exp (-α*t) := by
  obtain ⟨h, hh, hsp⟩ := exists_contracting_euler_step a hfinite hneg
  let B : A := 1+(h:ℂ) • a
  have hfiniteB : spectralRadius ℂ B ≠ ⊤ := ne_top_of_lt hsp
  have hrho : (spectralRadius ℂ B).toReal < 1 := by
    simpa only [ENNReal.toReal_one] using
      (ENNReal.toReal_lt_toReal hfiniteB ENNReal.one_ne_top).mpr hsp
  obtain ⟨r, hrrho, hr1⟩ := exists_between hrho
  have hr : 0 < r := lt_of_le_of_lt ENNReal.toReal_nonneg hrrho
  have hspr : spectralRadius ℂ B < ENNReal.ofReal r := by
    apply (ENNReal.toReal_lt_toReal hfiniteB ENNReal.ofReal_ne_top).mp
    simpa only [ENNReal.toReal_ofReal hr.le] using hrrho
  obtain ⟨M, hM, hpow⟩ := powers_bound_of_spectralRadius_lt B hr hspr
  refine ⟨M, (1-r)/h, hM, div_pos (sub_pos.mpr hr1) hh, ?_⟩
  exact exp_norm_decay_of_euler_powers a hh hr.le hpow

end Banach

section Matrix
open scoped Matrix.Norms.Operator
variable {n : Type*} [Fintype n] [DecidableEq n] [Nonempty n]

theorem complex_matrix_exp_decay (B : Matrix n n ℂ)
    (hneg : ∀ z ∈ spectrum ℂ B, z.re < 0) :
    ∃ M α : ℝ, 0 < M ∧ 0 < α ∧ ∀ t : ℝ, 0 ≤ t →
      ‖NormedSpace.exp ((t:ℂ) • B)‖ ≤ M*Real.exp (-α*t) :=
  exp_decay_of_finite_negative_spectrum B B.finite_spectrum hneg

end Matrix
end Article14.FiniteStateStability
