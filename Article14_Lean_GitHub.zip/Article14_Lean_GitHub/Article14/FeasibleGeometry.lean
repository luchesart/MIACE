import MIACE.ConvolutionL1
import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.Topology.Order.Compact
import Mathlib.Analysis.Convex.PathConnected

/-!
Article 14, Theorem 14(c): the finite-dimensional compactness argument in L¹.
The original MIACE space and its genuine almost-everywhere order are reused.
The transfer-to-kernel map and its injectivity must still be established for
the physical PIDF implementation; they are explicit hypotheses here.
-/
namespace Article14
open MeasureTheory Set
open scoped Topology

noncomputable def kernelFeasible (X : Set (ℝ × ℝ)) (g₀ : MIACE.RealL1)
    (L : (ℝ × ℝ) →L[ℝ] MIACE.RealL1) : Set (ℝ × ℝ) :=
  {x | x ∈ X ∧ (0 : MIACE.RealL1) ≤ g₀ + L x}

-- @article14 thm:delay-fastest/positive_L1_norm
theorem positive_L1_norm (g : MIACE.RealL1) (hg : (0 : MIACE.RealL1) ≤ g) :
    ‖g‖ = ∫ t, g t := by
  rw [L1.norm_eq_integral_norm]
  apply integral_congr_ae
  rw [← Lp.coeFn_nonneg] at hg
  filter_upwards [hg] with t ht
  exact Real.norm_of_nonneg ht

-- @article14 thm:delay-fastest/closed_feasible_set
theorem kernelFeasible_closed {X : Set (ℝ × ℝ)} (hX : IsClosed X)
    (g₀ : MIACE.RealL1) (L : (ℝ × ℝ) →L[ℝ] MIACE.RealL1) :
    IsClosed (kernelFeasible X g₀ L) := by
  have hc : Continuous (fun x : ℝ × ℝ => g₀ + L x) := continuous_const.add L.continuous
  exact hX.inter ((isClosed_Ici : IsClosed (Ici (0 : MIACE.RealL1))).preimage hc)

theorem positive_L1_smul {g : MIACE.RealL1} (hg : (0 : MIACE.RealL1) ≤ g)
    {a : ℝ} (ha : 0 ≤ a) : (0 : MIACE.RealL1) ≤ a • g := by
  rw [← Lp.coeFn_nonneg] at hg ⊢
  filter_upwards [hg, Lp.coeFn_smul a g] with t ht hs
  rw [hs]
  exact mul_nonneg ha ht

-- @article14 thm:delay-fastest/convex_feasible_set
theorem kernelFeasible_convex {X : Set (ℝ × ℝ)} (hX : Convex ℝ X)
    (g₀ : MIACE.RealL1) (L : (ℝ × ℝ) →L[ℝ] MIACE.RealL1) :
    Convex ℝ (kernelFeasible X g₀ L) := by
  intro x hx y hy a b ha hb hab
  refine ⟨hX hx.1 hy.1 ha hb hab, ?_⟩
  have hp := add_nonneg (positive_L1_smul hx.2 ha) (positive_L1_smul hy.2 hb)
  have he : g₀ + L (a • x + b • y) = a • (g₀ + L x) + b • (g₀ + L y) := by
    rw [map_add, map_smul, map_smul, smul_add, smul_add]
    have hs : a • g₀ + b • g₀ = g₀ := by rw [← add_smul, hab, one_smul]
    calc
      _ = (a • g₀ + b • g₀) + (a • L x + b • L y) := by rw [hs]
      _ = _ := by abel
  rw [he]
  exact hp

-- @article14 thm:delay-fastest/compactness_without_a_weight_box
theorem kernelFeasible_compact {X : Set (ℝ × ℝ)} (hX : IsClosed X)
    (g₀ : MIACE.RealL1) (L : (ℝ × ℝ) →L[ℝ] MIACE.RealL1)
    (hL : Function.Injective L)
    (hmass : ∀ x ∈ kernelFeasible X g₀ L, (∫ t, (g₀ + L x) t) = 1) :
    IsCompact (kernelFeasible X g₀ L) := by
  obtain ⟨K, _, hK⟩ := L.toLinearMap.injective_iff_antilipschitz.mp hL
  apply (isCompact_closedBall (0 : ℝ × ℝ) ((K : ℝ) * (1 + ‖g₀‖))).of_isClosed_subset
    (kernelFeasible_closed hX g₀ L)
  intro x hx
  rw [Metric.mem_closedBall, dist_zero_right]
  have hn : ‖g₀ + L x‖ = 1 := (positive_L1_norm _ hx.2).trans (hmass x hx)
  have hbound : ‖L x‖ ≤ 1 + ‖g₀‖ := by
    have ht := norm_sub_le (g₀ + L x) g₀
    simpa only [add_sub_cancel_left, hn] using ht
  exact (ZeroHomClass.bound_of_antilipschitz L hK x).trans
    (mul_le_mul_of_nonneg_left hbound K.coe_nonneg)

-- @article14 thm:delay-fastest/max_b_is_minimum_mean
theorem minimum_mean_exists {F : Set (ℝ × ℝ)} (hF : IsCompact F)
    (hne : F.Nonempty) (Ti offset : ℝ) (hTi : 0 < Ti) :
    ∃ x ∈ F, (∀ z ∈ F, z.1 ≤ x.1) ∧
      (∀ z ∈ F, Ti * (offset - x.1) ≤ Ti * (offset - z.1)) := by
  obtain ⟨x, hx, hmax⟩ := hF.exists_isMaxOn hne continuous_fst.continuousOn
  refine ⟨x, hx, hmax, ?_⟩
  intro z hz
  exact mul_le_mul_of_nonneg_left (sub_le_sub_left (hmax hz) offset) hTi.le

-- @article14 prop:delay-second-moment/unique_lexicographic_weights
theorem lexicographic_weights_exist {F : Set (ℝ × ℝ)} (hF : IsCompact F)
    (hne : F.Nonempty) :
    ∃ x ∈ F, (∀ z ∈ F, z.1 ≤ x.1) ∧
      (∀ z ∈ F, z.1 = x.1 → x.2 ≤ z.2) ∧
      (∀ z ∈ F, z.1 = x.1 → z.2 = x.2 → z = x) := by
  obtain ⟨x, hx, hmax⟩ := hF.exists_isMaxOn hne continuous_fst.continuousOn
  let V := F ∩ {z : ℝ × ℝ | z.1 = x.1}
  have hV : IsCompact V := hF.inter_right (isClosed_eq continuous_fst continuous_const)
  obtain ⟨w, hw, hmin⟩ := hV.exists_isMinOn ⟨x, hx, rfl⟩ continuous_snd.continuousOn
  refine ⟨w, hw.1, ?_, ?_, ?_⟩
  · intro z hz
    rw [hw.2]
    exact hmax hz
  · intro z hz he
    exact hmin ⟨hz, he.trans hw.2⟩
  · intro z _ hfst hsnd
    exact Prod.ext hfst hsnd

-- @article14 thm:delay-miace/projection_is_a_closed_interval
theorem compact_convex_projection_interval {F : Set (ℝ × ℝ)}
    (hF : IsCompact F) (hconv : Convex ℝ F) (hne : F.Nonempty) :
    ∃ lo hi : ℝ, lo ≤ hi ∧ Prod.fst '' F = Icc lo hi := by
  have hc : IsCompact (Prod.fst '' F) := hF.image continuous_fst
  have hn : (Prod.fst '' F).Nonempty := hne.image Prod.fst
  have hconn : IsConnected (Prod.fst '' F) :=
    ⟨hn, hconv.isPreconnected.image Prod.fst continuous_fst.continuousOn⟩
  have he := eq_Icc_of_connected_compact hconn hc
  refine ⟨sInf (Prod.fst '' F), sSup (Prod.fst '' F), ?_, he⟩
  rw [he] at hn
  exact nonempty_Icc.mp hn

end Article14
