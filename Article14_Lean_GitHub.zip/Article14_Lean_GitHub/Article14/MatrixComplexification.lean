import Mathlib.Analysis.Normed.Algebra.MatrixExponential
import Mathlib.Analysis.Normed.Module.FiniteDimension
import Mathlib.Analysis.Complex.Basic
import Mathlib.Tactic.Convert

/-!
# Exact transport of complex spectral bounds to real physical trajectories

The real coordinate space has its usual finite-product supremum norm.
The induced matrix norm agrees with the continuous-linear-map operator norm,
and entrywise complexification preserves it. No change of the physical state
norm or unproved equivalence of exponential bounds is hidden in this bridge.
-/
namespace Article14
open Matrix NormedSpace
open scoped Matrix.Norms.Operator
variable {n : Type*} [Fintype n] [DecidableEq n]

/-- A real matrix acts as the actual bounded linear state operator. -/
noncomputable def realMatrixOperatorHom :
    Matrix n n ℝ →+* ((n → ℝ) →L[ℝ] (n → ℝ)) where
  toFun M := (Matrix.mulVecLin M).toContinuousLinearMap
  map_one' := by ext x i; simp
  map_mul' M N := by ext x i; simp [Matrix.mulVec_mulVec]
  map_zero' := by ext x i; simp
  map_add' M N := by ext x i; simp

theorem realMatrixOperator_apply (M : Matrix n n ℝ) (x : n → ℝ) :
    realMatrixOperatorHom M x = M *ᵥ x := rfl

-- This is the induced norm equality, not a dimension-dependent estimate.
theorem realMatrixOperator_norm (M : Matrix n n ℝ) :
    ‖realMatrixOperatorHom M‖ = ‖M‖ :=
  (Matrix.linfty_opNorm_eq_opNorm M).symm

theorem realMatrixOperator_continuous :
    Continuous (realMatrixOperatorHom : Matrix n n ℝ → _) := by
  apply Isometry.continuous
  apply isometry_iff_dist_eq.mpr
  intro M N
  simp only [dist_eq_norm, ← map_sub, realMatrixOperator_norm]

/-- Entrywise inclusion is a ring map between the two matrix algebras. -/
noncomputable def complexifyMatrix : Matrix n n ℝ →+* Matrix n n ℂ :=
  (algebraMap ℝ ℂ).mapMatrix

theorem complexifyMatrix_continuous :
    Continuous (complexifyMatrix : Matrix n n ℝ → Matrix n n ℂ) := by
  change Continuous (fun (M : Matrix n n ℝ) i j => (M i j : ℂ))
  fun_prop

theorem complexifyMatrix_norm (M : Matrix n n ℝ) :
    ‖complexifyMatrix M‖ = ‖M‖ := by
  simp only [Matrix.linfty_opNorm_def, complexifyMatrix, RingHom.mapMatrix_apply,
    Matrix.map_apply, Complex.coe_algebraMap, Complex.nnnorm_real]

-- The exponential is transported by the continuous ring homomorphism.
theorem complexifyMatrix_exp (M : Matrix n n ℝ) :
    complexifyMatrix (NormedSpace.exp M) = NormedSpace.exp (complexifyMatrix M) :=
  NormedSpace.map_exp complexifyMatrix complexifyMatrix_continuous M

theorem realMatrixOperator_smul (t : ℝ) (M : Matrix n n ℝ) :
    realMatrixOperatorHom (t • M) = t • realMatrixOperatorHom M := by
  ext x i
  simp [realMatrixOperator_apply, Matrix.smul_mulVec]

theorem complexifyMatrix_smul (t : ℝ) (M : Matrix n n ℝ) :
    complexifyMatrix (t • M) = (t : ℂ) • complexifyMatrix M := by
  ext i j
  simp [complexifyMatrix, Matrix.smul_apply]

-- A complex spectral estimate now bounds the very same real solution operator.
theorem realMatrixOperator_exp_norm (M : Matrix n n ℝ) (t : ℝ) :
    ‖NormedSpace.exp (t • realMatrixOperatorHom M)‖ =
      ‖NormedSpace.exp ((t : ℂ) • complexifyMatrix M)‖ := by
  have he := NormedSpace.map_exp (realMatrixOperatorHom (n := n))
    realMatrixOperator_continuous (t • M)
  calc
    _ = ‖realMatrixOperatorHom (NormedSpace.exp (t • M))‖ := by
      rw [realMatrixOperator_smul] at he
      convert! congrArg norm he.symm using 1
    _ = ‖NormedSpace.exp (t • M)‖ := realMatrixOperator_norm _
    _ = ‖complexifyMatrix (NormedSpace.exp (t • M))‖ := (complexifyMatrix_norm _).symm
    _ = _ := by rw [complexifyMatrix_exp, complexifyMatrix_smul]

theorem realMatrixOperator_exp_bound (M : Matrix n n ℝ) (C α : ℝ)
    (hbound : ∀ t : ℝ, 0 ≤ t →
      ‖NormedSpace.exp ((t : ℂ) • complexifyMatrix M)‖ ≤ C * Real.exp (-α*t)) :
    ∀ t : ℝ, 0 ≤ t → ‖NormedSpace.exp (t • realMatrixOperatorHom M)‖ ≤
      C * Real.exp (-α*t) := by
  intro t ht
  rw [realMatrixOperator_exp_norm]
  exact hbound t ht

end Article14
