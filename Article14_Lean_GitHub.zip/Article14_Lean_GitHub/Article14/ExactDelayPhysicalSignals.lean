import Article14.ExactDelayPlant
import Article14.PhysicalFamilyMoments
import MIACE.LaplaceAE

/-!
# Identifying the exact delayed signals with the implemented PIDF response

All transform relations used for identification are derived from the actual
state equations.  Laplace uniqueness is then applied to integrable ordinary
signals.  The reference prefilter will therefore describe the same physical
loop, without introducing an extra implemented controller state.
-/
namespace Article14
open MeasureTheory Filter Set MIACE
open scoped Topology Convolution
open PhysicalPlant PhysicalLaplace

namespace StablePIDFData
variable {n : Type*} [Fintype n] [DecidableEq n]

/-- The integrable centered response is derived from the physical trajectory
and internal stability, at all nonnegative Laplace frequencies. -/
theorem centered_responses (D : StablePIDFData n) (w : ℝ × ℝ) :
    CenteredPlantResponse D.A D.B D.xInf D.k D.L
      (fun j t => (D.response w t).1 j-D.xInf j) (D.command w) ∧
    CenteredPIDFResponse (D.error w) (D.command w)
      (fun t => (D.response w t).2.1-meanTime D.Ti D.k D.Kp w.1)
      (fun t => (D.response w t).2.2-(w.2-1)) D.Kp D.Ti D.Td D.Tf D.k w.1 w.2 := by
  have h := D.response_dynamics w
  have hd := centeredLoopDynamics_of_step h D.Ti_pos.ne' D.k_pos.ne' D.Kp_pos.ne'
    D.equilibrium D.unit_output
  have hc : ContinuousOn (fun t => D.response w t-
      pidfEquilibrium D.xInf D.Ti D.k D.Kp w.1 w.2) (Ici 0) :=
    h.continuous.sub continuousOn_const
  have hr := stable_centeredLoop_responses hd D.L_nonneg hc (D.stable_weights w)
    (centeredStep_after_delay h D.Ti_pos.ne' D.k_pos.ne' D.Kp_pos.ne'
      D.equilibrium D.unit_output)
  simp only [step_centered_error D.C D.xInf D.Ti D.k D.Kp w.1 w.2 D.unit_output,
    step_centered_command D.C D.xInf D.Kp D.Ti D.Td D.Tf D.k w.1 w.2
      D.Ti_pos.ne' D.k_pos.ne' D.Kp_pos.ne' D.unit_output] at hr
  simp only [pidfEquilibrium, Prod.fst_sub, Prod.snd_sub, Pi.sub_apply] at hr
  exact hr

-- No near-origin restriction is needed for the actual controller equations.
theorem command_transform (D : StablePIDFData n) (w : ℝ × ℝ) (p : ℝ) (hp : 0 < p) :
    p * laplace (D.command w) p / D.k =
      (D.Kp/D.Ti + p*(D.Kp+(D.Kp*D.Td)*p/(1+D.Tf*p))) * laplace (D.error w) p -
        ((1-w.1)*D.Kp+1/D.k+(1-w.2)*(D.Kp*D.Td)*p/(1+D.Tf*p)) :=
  centeredPIDF_eliminated_laplace (D.centered_responses w).2
    D.Ti_pos.ne' D.k_pos.ne' D.Kp_pos.ne' D.Tf_pos p hp

-- An explicit algebraic resolvent row yields the global physical plant law.
theorem plant_transform_at (D : StablePIDFData n) (w : ℝ × ℝ)
    (p : ℝ) (hp : 0 < p) (R : n → ℝ) (hR : IsResolventRow D.A D.C R p) :
    laplace (fun t => 1-D.error w t) p =
      ((∑ j, R j*D.B j)/D.k)*Real.exp (-D.L*p)*
        laplace (fun t => 1+D.command w t) p := by
  have hh := physical_transfer_at (C := D.C) (D.centered_responses w).1 D.L_nonneg
    D.equilibrium D.unit_output hp hR
  have he : trackingError D.C (fun j t => (D.response w t).1 j-D.xInf j) = D.error w := by
    funext t
    simp only [trackingError, StablePIDFData.error, finitePlantOutput, mul_sub,
      Finset.sum_sub_distrib, D.unit_output]
    ring
  simpa only [he] using hh

-- The actual ordinary impulse is the negative error derivative, so its
-- transform follows by integration by parts with the physical initial value.
theorem kernel_transform (D : StablePIDFData n) (w : ℝ × ℝ) (p : ℝ) (hp : 0 ≤ p) :
    laplace (D.kernel w) p = 1-p*laplace (D.error w) p := by
  obtain ⟨Ce,Cg,β,_,_,hβ,he,_⟩ := stable_step_impulse_decay (D.response_dynamics w)
    D.Ti_pos.ne' D.k_pos.ne' D.Kp_pos.ne' D.L_nonneg (D.stable_weights w)
    D.equilibrium D.unit_output
  have he0 : D.error w 0 = 1 := by
    simp [StablePIDFData.error, (D.response_dynamics w).initial, finitePlantOutput]
  have hlim : Tendsto (D.error w) atTop (𝓝 0) := by
    change Tendsto (fun t => 1-finitePlantOutput D.C (D.response w t).1) atTop (𝓝 0)
    simpa only [pow_zero, one_mul, StablePIDFData.error] using polynomial_weight_tendsto_zero hβ he 0
  have hh := laplace_ode_identity (step_error_locallyAC (D.response_dynamics w))
    (step_error_ode (D.response_dynamics w)) (D.error_integrable w)
    (D.kernel_integrable w).neg hlim p hp
  change laplace (fun t => -D.kernel w t) p = p*laplace (D.error w) p-D.error w 0 at hh
  have hn : laplace (fun t => -D.kernel w t) p = -laplace (D.kernel w) p := by
    unfold laplace
    simp only [mul_neg, integral_neg]
  rw [hn, he0] at hh
  linarith

theorem output_continuous (D : StablePIDFData n) (w : ℝ × ℝ) :
    Continuous (D.output w) := by
  rw [D.output_eq_l1KernelStep]
  exact l1KernelStep_continuous _

theorem error_eq_output_deficit (D : StablePIDFData n) (w : ℝ × ℝ) :
    D.error w =ᵐ[halfLine] (fun t => 1-D.output w t) := by
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  simp only [StablePIDFData.error, StablePIDFData.output, ite_eq_left (le_of_lt (show 0 < t from ht))]

theorem output_deficit_integrable (D : StablePIDFData n) (w : ℝ × ℝ) :
    Integrable (fun t => 1-D.output w t) halfLine :=
  (D.error_integrable w).congr (D.error_eq_output_deficit w)

theorem command_continuousOn (D : StablePIDFData n) (w : ℝ × ℝ) :
    ContinuousOn (D.command w) (Ici 0) := by
  have hc := (commandObservation D.C D.k D.Kp D.Ti D.Td D.Tf).continuous.comp_continuousOn
    ((D.response_dynamics w).continuous.sub
      (continuousOn_const : ContinuousOn
        (fun _ : ℝ => pidfEquilibrium D.xInf D.Ti D.k D.Kp w.1 w.2) (Ici 0)))
  simp only [Function.comp_def,Pi.sub_apply,step_centered_command D.C D.xInf D.Kp D.Ti D.Td D.Tf
    D.k w.1 w.2 D.Ti_pos.ne' D.k_pos.ne' D.Kp_pos.ne' D.unit_output] at hc
  exact hc

end StablePIDFData
namespace ExactDelay

noncomputable def canonicalResolvent : ℝ → ℝ := Classical.choose common_resolvent_exists

theorem canonical_resolvent_properties :
    CompactResolventEvolution J (1/4) a E (-1) canonicalResolvent ∧
      Integrable (causalize canonicalResolvent) ∧
      (∀ t, 0 ≤ t → 0 ≤ canonicalResolvent t) ∧
      (∫ t, canonicalResolvent t ∂halfLine) = 1 ∧
      ∀ p : ℝ, 0 ≤ p →
        (a*p+E-compactExpMoment J (1/4) (-p))*laplace canonicalResolvent p = 1 :=
  Classical.choose_spec common_resolvent_exists

noncomputable def canonicalCommand (q : ℝ) : ℝ → ℝ :=
  causalize (shapedCommand q canonicalResolvent)

theorem canonical_command_integrable (q : ℝ) : Integrable (canonicalCommand q) := by
  apply causalize_integrable
  exact (cascadeCommand_integral J_continuous (by norm_num : (0:ℝ) ≤ 1/4)
    (1+a-q) (-1) canonical_resolvent_properties.2.1
    canonical_resolvent_properties.2.2.2.1).1

theorem canonical_command_nonnegative {q : ℝ} (hq : 13/16 ≤ q)
    (t : ℝ) (ht : 0 ≤ t) : 0 ≤ canonicalCommand q t := by
  have hh := command_nonnegative canonical_resolvent_properties.1
    canonical_resolvent_properties.2.2.1 hq ht
  change 0 ≤ (Ici 0).indicator (shapedCommand q canonicalResolvent) t
  rw [indicator_of_mem (show t ∈ Ici 0 from ht)]
  dsimp only [shapedCommand,cascadeCommand]
  convert hh using 1
  ring

theorem canonical_command_transform (q : ℝ) (p : ℝ) (hp : 0 < p) :
    1+p*laplace (canonicalCommand q) p = (1+q*p)*laplace canonicalResolvent p := by
  rw [laplace_congr_halfLine (representative_halfLine_ae
    (EventuallyEq.rfl (f := canonicalCommand q)))]
  change 1+p*laplace (cascadeCommand J (1/4) (1+a-q) (-1) canonicalResolvent) p = _
  rw [cascadeCommand_laplace J_continuous (by norm_num) (1+a-q) (-1)
    canonical_resolvent_properties.2.1 hp.le]
  have ht := canonical_resolvent_properties.2.2.2.2 p hp.le
  have htail := compactTail_exp_identity J_continuous (1/4) (-p)
  rw [J_moment_zero] at htail
  linear_combination -ht + laplace canonicalResolvent p*htail

-- These are scalar identities of the actual fixed PIDF coefficients.
theorem feedback_transform_factor (p : ℝ) (hp : 0 < p) :
    (a*p+d)*(kp/ti+p*(kp+(kp*td)*p/(1+tf*p))) = (1+p)^2 := by
  have h2 : 2-rho ≠ 0 := parameters_positive.2.1.ne'
  have hd : d ≠ 0 := by norm_num [d]
  have hf : 1+rho*p ≠ 0 := by nlinarith [rho_bounds.1]
  have ha : a = d*rho := by dsimp [rho]; field_simp
  rw [ha]
  dsimp only [kp,ti,td,tf]
  field_simp
  ring

theorem reference_boundary_factor (q p : ℝ) (hp : 0 < p) :
    (a*p+d)*((1-b q)*kp+1+(1-c q)*(kp*td)*p/(1+tf*p)) =
      a*p+d+(1-q)*(1+p) := by
  have h2 : 2-rho ≠ 0 := parameters_positive.2.1.ne'
  have h1 : 1-rho ≠ 0 := by linarith [rho_bounds.2]
  have hd : d ≠ 0 := by norm_num [d]
  have hf : 1+rho*p ≠ 0 := by nlinarith [rho_bounds.1]
  have ha : a = d*rho := by dsimp [rho]; field_simp
  rw [ha]
  dsimp only [kp,ti,td,tf,b,c]
  field_simp
  ring

-- An explicit row of the inverse two-lag pencil; no spectral assertion is
-- hidden in a signal assumption.
theorem plant_resolvent_row (p : ℝ) (hp : 0 < p) :
    IsResolventRow plantA plantC ![1/(1+p)^2,1/(1+p)] p := by
  intro x
  have hn : 1+p ≠ 0 := by linarith
  simp [plantA,plantC,Fin.sum_univ_two]
  field_simp
  ring

variable (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput plantC)
  (finitePlantDynamics plantA plantB) kp ti td tf (1/4) 0 0)

noncomputable def pathWeights (q : ℝ) : ℝ × ℝ := (b q,c q)

-- The implemented plant gives the two-lag transfer at every positive real
-- frequency; no rational approximation to its pure delay is used.
theorem physical_plant_transform (w : ℝ × ℝ) (p : ℝ) (hp : 0 < p) :
    (1+p)^2*(1-p*laplace ((plantDataOfStable hs).error w) p) =
      Real.exp (-(1/4)*p)*(1+p*laplace ((plantDataOfStable hs).command w) p) := by
  let D := plantDataOfStable hs
  have hh := D.plant_transform_at w p hp ![1/(1+p)^2,1/(1+p)] (plant_resolvent_row p hp)
  have hh' : laplace (fun t => 1-D.error w t) p =
      (1/(1+p)^2)*Real.exp (-(1/4)*p)*laplace (fun t => 1+D.command w t) p := by
    simpa [D,plantDataOfStable,plantB,Fin.sum_univ_two] using hh
  have hy : laplace (fun t => 1-D.error w t) p = 1/p-laplace (D.error w) p := by
    have ha := (laplace_step_add (D.error_integrable w).neg hp).2
    have hn : laplace (-D.error w) p = -laplace (D.error w) p := by
      unfold laplace
      simp only [Pi.neg_apply,mul_neg,integral_neg]
    simpa only [Pi.neg_apply,hn,sub_eq_add_neg] using ha
  rw [hy,(laplace_step_add (D.command_integrable w) hp).2] at hh'
  have hn : 1+p ≠ 0 := by linarith
  field_simp [hp.ne',hn] at hh'
  change (1+p)^2*(1-p*laplace (D.error w) p) =
    Real.exp (-(1/4)*p)*(1+p*laplace (D.command w) p)
  have he : Real.exp (-(p/4)) = Real.exp (-(1/4)*p) := by congr 1; ring
  rw [he] at hh'
  nlinarith [hh']

-- The actual physical PIDF state equations give the same fixed feedback
-- denominator and the path-dependent reference correction.
theorem physical_path_controller_transform (q p : ℝ) (hp : 0 < p) :
    (a*p+d)*(1+p*laplace ((plantDataOfStable hs).command (pathWeights q)) p) =
      (1+p)^2*laplace ((plantDataOfStable hs).error (pathWeights q)) p -
        (1-q)*(1+p) := by
  let D := plantDataOfStable hs
  have hh := D.command_transform (pathWeights q) p hp
  change p*laplace (D.command (pathWeights q)) p / 1 =
    (kp/ti+p*(kp+(kp*td)*p/(1+tf*p)))*laplace (D.error (pathWeights q)) p -
      ((1-b q)*kp+1/1+(1-c q)*(kp*td)*p/(1+tf*p)) at hh
  norm_num only [div_one] at hh
  have hfb := feedback_transform_factor p hp
  have hrf := reference_boundary_factor q p hp
  change (a*p+d)*(1+p*laplace (D.command (pathWeights q)) p) =
    (1+p)^2*laplace (D.error (pathWeights q)) p-(1-q)*(1+p)
  linear_combination (a*p+d)*hh + hfb*laplace (D.error (pathWeights q)) p - hrf

-- The positive real characteristic expression cannot vanish.
theorem real_characteristic_pos (p : ℝ) (hp : 0 < p) :
    0 < p*(a*p+d)+Real.exp (-(1/4)*p) := by
  have ha : 0 < a := lt_trans (by norm_num) a_bounds.1
  have hd : 0 < d := by norm_num [d]
  positivity

-- Identification with the ordinary resolvent is proved from both actual
-- physical subsystems.  This applies to every real reference parameter q.
theorem physical_command_resolvent_transform (q p : ℝ) (hp : 0 < p) :
    1+p*laplace ((plantDataOfStable hs).command (pathWeights q)) p =
      (1+q*p)*laplace canonicalResolvent p := by
  have hc := physical_path_controller_transform hs q p hp
  have hp' := physical_plant_transform hs (pathWeights q) p hp
  have hr : (p*(a*p+d)+Real.exp (-(1/4)*p))*laplace canonicalResolvent p = 1+p := by
    rw [real_characteristic_factorization p, mul_assoc,
      canonical_resolvent_properties.2.2.2.2 p hp.le, mul_one]
  have hh : (p*(a*p+d)+Real.exp (-(1/4)*p)) *
      (1+p*laplace ((plantDataOfStable hs).command (pathWeights q)) p) =
      (1+p)*(1+q*p) := by
    linear_combination p*hc - hp'
  apply mul_left_cancel₀ (real_characteristic_pos p hp).ne'
  linear_combination hh - (1+q*p)*hr

-- The physical centered command is identified as an ordinary L¹ signal.
theorem physical_command_eq_canonical (q : ℝ) :
    (plantDataOfStable hs).command (pathWeights q) =ᵐ[halfLine] canonicalCommand q := by
  have hi := (plantDataOfStable hs).command_integrable (pathWeights q)
  have he := laplace_injective_ae (causalize_integrable hi) (canonical_command_integrable q)
    (fun p hp => by
      rw [laplace_congr_halfLine (representative_halfLine_ae
        (EventuallyEq.rfl (f := causalize ((plantDataOfStable hs).command (pathWeights q)))))]
      have h1 := physical_command_resolvent_transform hs q p hp
      have h2 := canonical_command_transform q p hp
      exact (mul_left_cancel₀ hp.ne') (by linarith))
  exact (representative_halfLine_ae (EventuallyEq.rfl
    (f := causalize ((plantDataOfStable hs).command (pathWeights q))))).symm.trans he

-- The actual ordinary physical impulse equals the reference convolution.
theorem physical_kernel_eq_reference {q : ℝ} (hq : q ∈ Icc (0:ℝ) 1) :
    (plantDataOfStable hs).kernel (pathWeights q) =ᵐ[halfLine]
      referenceImpulse q canonicalResolvent := by
  obtain ⟨hi,_,_,_,_,hT⟩ := reference_impulse_properties canonical_resolvent_properties.1.continuous
    canonical_resolvent_properties.2.1 canonical_resolvent_properties.2.2.1
    canonical_resolvent_properties.2.2.2.1 hq
  apply laplace_injective_ae ((plantDataOfStable hs).kernel_integrable_full (pathWeights q)) hi
  intro p hp
  have hplant := physical_plant_transform hs (pathWeights q) p hp
  rw [physical_command_resolvent_transform hs q p hp] at hplant
  have hphysical := (plantDataOfStable hs).kernel_transform (pathWeights q) p hp.le
  apply mul_left_cancel₀ (pow_ne_zero 2 (show 1+p ≠ 0 by linarith))
  rw [hphysical]
  linear_combination hplant - hT p hp.le

-- Identification of cumulative outputs holds at every real time, because
-- both ordinary kernels are causal and equality is known almost everywhere.
theorem physical_output_eq_reference_step {q : ℝ} (hq : q ∈ Icc (0:ℝ) 1) :
    (plantDataOfStable hs).output (pathWeights q) =
      kernelStep (referenceImpulse q canonicalResolvent) := by
  let D := plantDataOfStable hs
  obtain ⟨_,hc,_,_,_,_⟩ := reference_impulse_properties canonical_resolvent_properties.1.continuous
    canonical_resolvent_properties.2.1 canonical_resolvent_properties.2.2.1
    canonical_resolvent_properties.2.2.2.1 hq
  have hpc : Causal (D.kernel (pathWeights q)) := stepImpulse_causal _ _ _ _ _ _ _ _ _ _ _
  have he : D.kernel (pathWeights q) =ᵐ[volume] referenceImpulse q canonicalResolvent :=
    (causalize_of_halfLine_eq hpc (physical_kernel_eq_reference hs hq)).trans (causalize_eq_ae hc)
  rw [D.output_eq_l1KernelStep, ← D.kernelL1_eq]
  funext t
  apply integral_congr_ae
  exact ae_restrict_of_ae ((D.kernelL1_coe_full (pathWeights q)).trans he)

theorem physical_path_kernel_nonnegative {q : ℝ} (hq : q ∈ Icc (0:ℝ) 1) :
    ∀ᵐ t ∂halfLine, 0 ≤ (plantDataOfStable hs).kernel (pathWeights q) t := by
  have hn := (reference_impulse_properties canonical_resolvent_properties.1.continuous
    canonical_resolvent_properties.2.1 canonical_resolvent_properties.2.2.1
    canonical_resolvent_properties.2.2.2.1 hq).2.2.1
  filter_upwards [physical_kernel_eq_reference hs hq] with t ht
  rw [ht]
  exact hn t

theorem physical_path_command_nonnegative_ae {q : ℝ} (hq : 13/16 ≤ q) :
    ∀ᵐ t ∂halfLine, 0 ≤ (plantDataOfStable hs).command (pathWeights q) t := by
  filter_upwards [physical_command_eq_canonical hs q,ae_restrict_mem measurableSet_Ioi] with t ht ht0
  rw [ht]
  exact canonical_command_nonnegative hq t (le_of_lt (show 0<t from ht0))

theorem physical_path_monotone {q : ℝ} (hq : q ∈ Icc (0:ℝ) 1) :
    Monotone ((plantDataOfStable hs).output (pathWeights q)) := by
  rw [physical_output_eq_reference_step hs hq]
  have hp := reference_impulse_properties canonical_resolvent_properties.1.continuous
    canonical_resolvent_properties.2.1 canonical_resolvent_properties.2.2.1
    canonical_resolvent_properties.2.2.2.1 hq
  exact positive_kernel_step_monotone hp.1 (ae_of_all _ hp.2.2.1)

theorem physical_path_output_bounds {q : ℝ} (hq : q ∈ Icc (0:ℝ) 1) (t : ℝ) :
    0 ≤ (plantDataOfStable hs).output (pathWeights q) t ∧
      (plantDataOfStable hs).output (pathWeights q) t ≤ 1 := by
  rw [physical_output_eq_reference_step hs hq]
  have hp := reference_impulse_properties canonical_resolvent_properties.1.continuous
    canonical_resolvent_properties.2.1 canonical_resolvent_properties.2.2.1
    canonical_resolvent_properties.2.2.2.1 hq
  exact positive_kernel_step_bounds hp.1 (ae_of_all _ hp.2.2.1) hp.2.2.2.1 t

theorem path_mean_formula (q : ℝ) : meanTime ti 1 kp (b q) = errorArea q := by
  have h2 : 2-rho ≠ 0 := parameters_positive.2.1.ne'
  have hd : d ≠ 0 := by norm_num [d]
  unfold meanTime ti kp b errorArea
  field_simp
  dsimp [d]
  ring

theorem physical_path_iae {q : ℝ} (hq : q ∈ Icc (0:ℝ) 1) :
    (plantDataOfStable hs).iae (pathWeights q) = errorArea q := by
  rw [(plantDataOfStable hs).iae_eq_mean _ (physical_path_kernel_nonnegative hs hq)]
  exact path_mean_formula q

theorem physical_path_command_area {q : ℝ} (hq : 13/16 ≤ q) :
    absArea ((plantDataOfStable hs).command (pathWeights q)) halfLine = commandArea q := by
  have he : (∫ t, (plantDataOfStable hs).command (pathWeights q) t ∂halfLine) =
      ∫ t, shapedCommand q canonicalResolvent t ∂halfLine := by
    apply integral_congr_ae
    exact (physical_command_eq_canonical hs q).trans
      (representative_halfLine_ae (EventuallyEq.rfl (f := canonicalCommand q)))
  have hc := (cascadeCommand_integral J_continuous (by norm_num : (0:ℝ) ≤ 1/4)
    (1+a-q) (-1) canonical_resolvent_properties.2.1
    canonical_resolvent_properties.2.2.2.1).2
  change (∫ t, shapedCommand q canonicalResolvent t ∂halfLine) = _ at hc
  rw [J_moment_one] at hc
  have ha : absArea ((plantDataOfStable hs).command (pathWeights q)) halfLine =
      ∫ t, (plantDataOfStable hs).command (pathWeights q) t ∂halfLine := by
    apply integral_congr_ae
    filter_upwards [physical_path_command_nonnegative_ae hs hq] with t ht
    exact abs_of_nonneg ht
  rw [ha,he,hc]
  dsimp [a,d,commandArea]
  ring

-- The physical endpoint is feasible in the entire admitted box, so the
-- previously proved global maximum-b reduction applies there.
theorem physical_endpoint_global_iae :
    pathWeights 1 ∈ (plantDataOfStable hs).feasible (Icc ((0:ℝ),0) (1,1)) ∧
      ∀ w ∈ (plantDataOfStable hs).feasible (Icc ((0:ℝ),0) (1,1)),
        (plantDataOfStable hs).iae (pathWeights 1) ≤ (plantDataOfStable hs).iae w := by
  let D := plantDataOfStable hs
  have hb : pathWeights 1 = ((1:ℝ),1) := Prod.ext endpoint_weights.1 endpoint_weights.2
  have hw : pathWeights 1 ∈ D.feasible (Icc ((0:ℝ),0) (1,1)) := by
    rw [D.mem_feasible_iff]
    exact ⟨by rw [hb]; constructor <;> constructor <;> norm_num,
      physical_path_kernel_nonnegative hs (by constructor <;> norm_num)⟩
  refine ⟨hw,(D.feasible_minimum_iae_iff_maximum_b hw).mpr ?_⟩
  intro w hw
  have hbox := ((D.mem_feasible_iff _ _).mp hw).1
  rw [hb]
  exact hbox.2.1

-- Positivity is needed only for the attaining endpoint.  Every other
-- weight in the full box satisfies IAE >= the signed error area, so the
-- same endpoint remains optimal even when its competitors overshoot.
theorem physical_endpoint_global_box_iae :
    (plantDataOfStable hs).iae (pathWeights 1) = 27/16 ∧
      ∀ w ∈ Icc ((0:ℝ),0) (1,1),
        (plantDataOfStable hs).iae (pathWeights 1) ≤ (plantDataOfStable hs).iae w := by
  let D := plantDataOfStable hs
  have hg := physical_path_kernel_nonnegative hs (by constructor <;> norm_num :
    (1:ℝ) ∈ Icc (0:ℝ) 1)
  have he : D.iae (pathWeights 1) = 27/16 := by
    rw [physical_path_iae hs (by constructor <;> norm_num)]
    norm_num [errorArea]
  refine ⟨he,?_⟩
  intro w hw
  have ha : (∫ t, D.error w t ∂halfLine) ≤ D.iae w :=
    integral_mono (D.error_integrable w) (D.error_integrable w).abs
      (fun t => le_abs_self _)
  rw [D.error_area w] at ha
  apply le_trans _ ha
  rw [D.iae_eq_mean _ hg]
  unfold meanTime
  apply mul_le_mul_of_nonneg_left _ D.Ti_pos.le
  have hb : (pathWeights 1).1 = 1 := endpoint_weights.1
  rw [hb]
  linarith [hw.2.1]

-- The physical command is continuous from the right at zero and on all
-- physical time, so its a.e. sign also holds at every nonnegative time.
theorem physical_path_command_nonnegative {q : ℝ} (hq : 13/16 ≤ q)
    (t : ℝ) (ht : 0 ≤ t) :
    0 ≤ (plantDataOfStable hs).command (pathWeights q) t := by
  let D := plantDataOfStable hs
  have hc : Continuous (fun t => D.command (pathWeights q) (max t 0)) :=
    (D.command_continuousOn _).comp_continuous (continuous_id.max continuous_const)
      (fun t => by change (0:ℝ) ≤ max t 0; exact le_max_right t 0)
  have hn : ∀ᵐ t ∂halfLine, (0:ℝ) ≤ D.command (pathWeights q) (max t 0) := by
    filter_upwards [physical_path_command_nonnegative_ae hs hq,
      ae_restrict_mem measurableSet_Ioi] with s hs hs0
    simpa only [max_eq_left (le_of_lt (show 0<s from hs0))] using hs
  simpa only [max_eq_left ht] using continuous_halfLine_bound continuous_const hc hn t ht

-- The norm refers to the actual physical ordinary impulse, now identified
-- with the positive unit-mass reference kernel.
theorem physical_path_hinf {q : ℝ} (hq : q ∈ Icc (0:ℝ) 1) :
    kernelHinf ((plantDataOfStable hs).kernel (pathWeights q)) = 1 := by
  let D := plantDataOfStable hs
  exact stable_step_positive_hinf (D.response_dynamics _) D.Ti_pos.ne' D.k_pos.ne'
    D.Kp_pos.ne' D.L_nonneg (D.stable_weights _) D.equilibrium D.unit_output
    (physical_path_kernel_nonnegative hs hq)

-- The global transform interface for the actual two-lag physical plant.
theorem physical_global_transfer (w : ℝ × ℝ) :
    TransferResponse ((plantDataOfStable hs).error w) ((plantDataOfStable hs).command w)
      (cascadeTransfer (rationalCascadeTimes (fun _ => 1)) 2) (1/4) := by
  let D := plantDataOfStable hs
  refine ⟨D.error_integrable w,D.command_integrable w,?_⟩
  intro p hp
  have h := D.plant_transform_at w p hp ![1/(1+p)^2,1/(1+p)] (plant_resolvent_row p hp)
  have hc : cascadeTransfer (rationalCascadeTimes (fun _ => 1)) 2 p = 1/(1+p)^2 := by
    simp [cascadeTransfer,rationalCascadeTimes,pow_two]
    ring
  rw [hc]
  simpa [D,plantDataOfStable,plantB,Fin.sum_univ_two] using h

-- Exact equality is attained by the physical path and is global among all
-- admissible ordinary responses of the same delayed two-lag plant.
theorem physical_global_miace {α : ℝ} (hα : α ∈ Icc (3:ℝ) 5) :
    miace α ((plantDataOfStable hs).error (pathWeights (optimalQ α)))
      ((plantDataOfStable hs).command (pathWeights (optimalQ α))) halfLine =
      (9/4)*Real.sqrt (α/(1+α)) ∧
    ∀ e' v' : ℝ → ℝ,
      TransferResponse e' v' (cascadeTransfer (rationalCascadeTimes (fun _ => 1)) 2) (1/4) →
      miace α ((plantDataOfStable hs).error (pathWeights (optimalQ α)))
        ((plantDataOfStable hs).command (pathWeights (optimalQ α))) halfLine ≤
        miace α e' v' halfLine := by
  let D := plantDataOfStable hs
  let q := optimalQ α
  have hqp := optimalQ_in_interval hα
  have hq : q ∈ Icc (0:ℝ) 1 := ⟨by dsimp [q]; linarith [hqp.1],hqp.2⟩
  have hαp : 0 < α := by linarith [hα.1]
  have hp := physical_global_transfer hs (pathWeights q)
  have hbal : (∫ t, D.error (pathWeights q) t ∂halfLine)+
      (∫ t, D.command (pathWeights q) t ∂halfLine) = 9/4 := by
    have hh := transfer_signed_balance hp
      (cascadeMean (rationalCascadeTimes (fun _ => 1)) 2)
      (cascadeTransfer_derivative _ _) (cascadeTransfer_zero _ _)
    norm_num [cascadeMean,Finset.sum_range_succ,rationalCascadeTimes] at hh
    exact hh
  have hea : absArea (D.error (pathWeights q)) halfLine = 9*α/(4*(1+α)) := by
    change D.iae (pathWeights q) = _
    rw [physical_path_iae hs hq]
    exact (optimal_areas hαp).1
  have hva : absArea (D.command (pathWeights q)) halfLine = 9/(4*(1+α)) := by
    rw [physical_path_command_area hs hqp.1]
    exact (optimal_areas hαp).2
  have he : ∀ᵐ t ∂halfLine, 0 ≤ D.error (pathWeights q) t := by
    filter_upwards [D.error_eq_output_deficit (pathWeights q)] with t ht
    rw [ht]
    exact sub_nonneg.mpr (physical_path_output_bounds hs hq t).2
  have hc : miace α (D.error (pathWeights q)) (D.command (pathWeights q)) halfLine =
      (9/4)*minimum α := by
    apply (signal_miace_equality_iff hp.error_integrable hp.command_integrable
      α (9/4) hαp (by norm_num) hbal).mpr
    refine ⟨he,physical_path_command_nonnegative_ae hs hqp.1,?_⟩
    rw [hea,hva]
    ring
  refine ⟨hc,?_⟩
  intro e' v' hp'
  rw [hc]
  apply signal_miace_lower_bound hp'.error_integrable hp'.command_integrable
    α (9/4) hαp (by norm_num)
  have hh := transfer_signed_balance hp'
    (cascadeMean (rationalCascadeTimes (fun _ => 1)) 2)
    (cascadeTransfer_derivative _ _) (cascadeTransfer_zero _ _)
  norm_num [cascadeMean,Finset.sum_range_succ,rationalCascadeTimes] at hh
  exact hh

-- The displayed reference impulse integrates to the very same physical
-- output, including every time within and after the transport interval.
theorem physical_output_eq_reference_integral {q : ℝ} (hq : q ∈ Icc (0:ℝ) 1)
    (t : ℝ) :
    (plantDataOfStable hs).output (pathWeights q) t =
      ∫ s in 0..t, referenceImpulse q canonicalResolvent s := by
  have hp := reference_impulse_properties canonical_resolvent_properties.1.continuous
    canonical_resolvent_properties.2.1 canonical_resolvent_properties.2.2.1
    canonical_resolvent_properties.2.2.2.1 hq
  have hz : kernelStep (referenceImpulse q canonicalResolvent) 0 = 0 :=
    causal_kernel_step_zero hp.2.1 le_rfl
  rw [physical_output_eq_reference_step hs hq]
  have hh := (intervalIntegral.integral_Iic_sub_Iic (a := (0:ℝ)) (b := t)
    hp.1.integrableOn hp.1.integrableOn).symm
  change (∫ s in 0..t, referenceImpulse q canonicalResolvent s) =
    kernelStep (referenceImpulse q canonicalResolvent) t -
      kernelStep (referenceImpulse q canonicalResolvent) 0 at hh
  simpa only [hz,sub_zero] using hh.symm

theorem physical_path_initial_and_limit {q : ℝ} (hq : q ∈ Icc (0:ℝ) 1) :
    (plantDataOfStable hs).output (pathWeights q) 0 = 0 ∧
    Tendsto ((plantDataOfStable hs).output (pathWeights q)) atTop (𝓝 1) := by
  rw [physical_output_eq_reference_step hs hq]
  have hp := reference_impulse_properties canonical_resolvent_properties.1.continuous
    canonical_resolvent_properties.2.1 canonical_resolvent_properties.2.2.1
    canonical_resolvent_properties.2.2.2.1 hq
  exact ⟨causal_kernel_step_zero hp.2.1 le_rfl,
    unit_mass_kernel_step_tendsto_one hp.1 hp.2.2.2.1⟩

end ExactDelay
end Article14
