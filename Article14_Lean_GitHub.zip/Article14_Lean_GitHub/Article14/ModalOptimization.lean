import Article14.FeasibleGeometry
import Mathlib.Analysis.Normed.Module.Convex
import Mathlib.Topology.Order.Lattice

/-! Article 14, Proposition 10: finite complex-affine norm minimax.
The finite-scenario modal maps are affine maps, not values from a numerical
optimizer. Compactness and convexity yield an actual attained global minimum.
Obtaining each affine map from a physical time response is a separate step.
-/
namespace Article14
open Set

noncomputable def finiteModalCost {ι : Type*} (s : Finset ι) (hne : s.Nonempty)
    (z : ι → (ℝ × ℝ) →ᵃ[ℝ] ℂ) (w : ℝ × ℝ) : ℝ :=
  s.sup' hne (fun i => ‖z i w‖)

-- @article14 prop:socp/complex_norm_is_the_cone_norm
theorem complex_norm_as_real_cone (z : ℂ) :
    ‖z‖ = Real.sqrt (z.re ^ 2 + z.im ^ 2) := by
  rw [Complex.norm_def, Complex.normSq_apply]
  congr 1
  ring

-- @article14 prop:socp/epigraph_equivalence
theorem finiteModalCost_le_iff {ι : Type*} (s : Finset ι) (hne : s.Nonempty)
    (z : ι → (ℝ × ℝ) →ᵃ[ℝ] ℂ) (w : ℝ × ℝ) (t : ℝ) :
    finiteModalCost s hne z w ≤ t ↔ ∀ i ∈ s, ‖z i w‖ ≤ t := by
  unfold finiteModalCost
  exact Finset.sup'_le_iff hne (fun i => ‖z i w‖)

-- @article14 prop:socp/continuous_finite_objective
theorem finiteModalCost_continuous {ι : Type*} (s : Finset ι) (hne : s.Nonempty)
    (z : ι → (ℝ × ℝ) →ᵃ[ℝ] ℂ) : Continuous (finiteModalCost s hne z) := by
  exact Continuous.finset_sup'_apply hne
    (fun i _ => (z i).continuous_of_finiteDimensional.norm)

-- @article14 prop:socp/convex_finite_objective
theorem finiteModalCost_convex {ι : Type*} (s : Finset ι) (hne : s.Nonempty)
    (z : ι → (ℝ × ℝ) →ᵃ[ℝ] ℂ) :
    ConvexOn ℝ univ (finiteModalCost s hne z) := by
  refine ⟨convex_univ, ?_⟩
  intro x _ y _ a b ha hb hab
  apply (finiteModalCost_le_iff s hne z _ _).mpr
  intro i hi
  have hz := ((convexOn_norm convex_univ).comp_affineMap (z i)).2
    (show x ∈ (z i) ⁻¹' univ from mem_univ _) (show y ∈ (z i) ⁻¹' univ from mem_univ _)
    ha hb hab
  have hx : ‖z i x‖ ≤ finiteModalCost s hne z x := Finset.le_sup' (fun j => ‖z j x‖) hi
  have hy : ‖z i y‖ ≤ finiteModalCost s hne z y := Finset.le_sup' (fun j => ‖z j y‖) hi
  exact hz.trans (add_le_add (mul_le_mul_of_nonneg_left hx ha)
    (mul_le_mul_of_nonneg_left hy hb))

-- @article14 prop:socp/attained_global_minimum
theorem finiteModalCost_minimizer {ι : Type*} (s : Finset ι) (hne : s.Nonempty)
    (z : ι → (ℝ × ℝ) →ᵃ[ℝ] ℂ) {X : Set (ℝ × ℝ)}
    (hX : IsCompact X) (hXne : X.Nonempty) :
    ∃ w ∈ X, ∀ v ∈ X, finiteModalCost s hne z w ≤ finiteModalCost s hne z v :=
  hX.exists_isMinOn hXne (finiteModalCost_continuous s hne z).continuousOn

-- @article14 prop:socp/additional_closed_constraints
theorem constrained_modal_minimizer {ι : Type*} (s : Finset ι) (hne : s.Nonempty)
    (z : ι → (ℝ × ℝ) →ᵃ[ℝ] ℂ) {X Y : Set (ℝ × ℝ)}
    (hX : IsCompact X) (hY : IsClosed Y) (hneXY : (X ∩ Y).Nonempty) :
    ∃ w ∈ X ∩ Y, ∀ v ∈ X ∩ Y,
      finiteModalCost s hne z w ≤ finiteModalCost s hne z v :=
  finiteModalCost_minimizer s hne z (hX.inter_right hY) hneXY

end Article14
