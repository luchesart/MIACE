import Article14.ExactDelayPlant
import Mathlib.Analysis.Normed.Operator.Banach

/-! An invertible change of all four state coordinates, including the
controller storage, between the shared PIDF realization and the internally
stable rational realization. The delay acts on the command in both systems. -/
namespace Article14.ExactDelay
open Set MeasureTheory Filter MIACE
open scoped Topology

abbrev LoopState := (Fin 2 → ℝ) × ℝ × ℝ

/-- Actual zero-reference command in the shared controller coordinates. -/
noncomputable def homogeneousCommand (z : LoopState) : ℝ :=
  (rho * z.2.1 - z.1 1 - (1-rho)^2 * z.2.2) / a

/-- The plant coordinates are unchanged; the controller coordinates become
(command, strictly proper controller-storage state). -/
noncomputable def toRationalState (z : LoopState) : LoopState :=
  (z.1, homogeneousCommand z, (1-rho)*z.2.1+(1-rho)^2*z.2.2)

noncomputable def fromRationalState (z : LoopState) : LoopState :=
  (z.1, a*z.2.1+z.2.2+z.1 1,
    (rho*z.2.2-rho*E*z.2.1-(1-rho)*z.1 1)/(1-rho)^2)

theorem rho_d : rho*d=a := by
  norm_num [rho, d]

theorem a_add_E : a+E=d := by unfold a; ring

theorem rho_ne_zero : rho ≠ 0 := rho_bounds.1.ne'
theorem a_ne_zero : a ≠ 0 := ne_of_gt (lt_trans (by norm_num) a_bounds.1)
theorem one_sub_rho_ne_zero : 1-rho ≠ 0 := by linarith [rho_bounds.2]

theorem homogeneousCommand_eq (z : LoopState) :
    (sharedControllerRhs kp ti td tf 0 0 0 (finitePlantOutput plantC z.1)
      z.2.1 z.2.2).2.2 = homogeneousCommand z := by
  have hr := rho_ne_zero
  have ht : 2-rho ≠ 0 := parameters_positive.2.1.ne'
  have ha := a_ne_zero
  have hd : d ≠ 0 := by norm_num [d]
  simp only [sharedControllerRhs, zero_mul, zero_sub, plant_output]
  dsimp [kp, ti, td, tf, homogeneousCommand]
  field_simp
  rw [rho_d]
  ring

theorem E_relation : E = (1-rho)*a/rho := by
  apply (eq_div_iff rho_ne_zero).mpr
  linear_combination rho * a_add_E + rho_d

theorem from_toRationalState (z : LoopState) :
    fromRationalState (toRationalState z) = z := by
  apply Prod.ext
  · rfl
  · apply Prod.ext
    · dsimp [fromRationalState, toRationalState, homogeneousCommand]
      field_simp [a_ne_zero]
      ring
    · dsimp [fromRationalState, toRationalState, homogeneousCommand]
      rw [E_relation]
      field_simp [a_ne_zero, one_sub_rho_ne_zero, rho_ne_zero]
      ring

theorem to_fromRationalState (z : LoopState) :
    toRationalState (fromRationalState z) = z := by
  apply Prod.ext
  · rfl
  · apply Prod.ext <;>
      dsimp [fromRationalState, toRationalState, homogeneousCommand] <;>
      rw [E_relation] <;>
      field_simp [a_ne_zero, one_sub_rho_ne_zero, rho_ne_zero] <;> ring

noncomputable def stateEquiv : LoopState ≃L[ℝ] LoopState :=
  LinearEquiv.toContinuousLinearEquivOfContinuous
    { toFun := toRationalState
      invFun := fromRationalState
      left_inv := from_toRationalState
      right_inv := to_fromRationalState
      map_add' := by
        intro z q
        apply Prod.ext
        · rfl
        · apply Prod.ext <;> dsimp [toRationalState, homogeneousCommand] <;> ring
      map_smul' := by
        intro s z
        apply Prod.ext
        · rfl
        · apply Prod.ext <;> dsimp [toRationalState, homogeneousCommand] <;> ring }
    (by change Continuous (fun z => toRationalState z)
        dsimp [toRationalState, homogeneousCommand]; fun_prop)

/-- The complete old rational vector field at n=0. Its delayed input is the
command coordinate, never a reduced transfer or an output-only state. -/
noncomputable def rationalStateRhs (now delayed : LoopState) : LoopState :=
  (![delayed.2.1-now.1 0, now.1 0-now.1 1],
    (-E*now.2.1+now.2.2-now.1 0)/a, E*now.2.1-now.2.2)

noncomputable def physicalStateRhs (now delayed : LoopState) : LoopState :=
  (finitePlantDynamics plantA plantB now.1 (homogeneousCommand delayed),
    -now.1 1, (-now.1 1-now.2.2)/rho)

theorem retardedSharedRhs_eq (h : ℝ → LoopState) :
    retardedSharedRhs (finitePlantOutput plantC) (finitePlantDynamics plantA plantB)
      kp ti td tf (1/4) 0 0 (fun _ => 0) h =
      physicalStateRhs (h 0) (h (-(1/4))) := by
  unfold retardedSharedRhs physicalStateRhs
  dsimp only
  rw [homogeneousCommand_eq]
  simp [sharedControllerRhs, tf]

theorem stateEquiv_conjugacy (now delayed : LoopState) :
    stateEquiv (physicalStateRhs now delayed) =
      rationalStateRhs (stateEquiv now) (stateEquiv delayed) := by
  change toRationalState (physicalStateRhs now delayed) =
    rationalStateRhs (toRationalState now) (toRationalState delayed)
  apply Prod.ext
  · ext j
    fin_cases j <;> simp [physicalStateRhs, toRationalState, rationalStateRhs]
    ring
  · apply Prod.ext
    · dsimp [toRationalState, homogeneousCommand, physicalStateRhs, rationalStateRhs]
      simp only [plant_dynamics_one]
      rw [E_relation]
      field_simp [a_ne_zero, rho_ne_zero]
      ring
    · dsimp [toRationalState, homogeneousCommand, physicalStateRhs, rationalStateRhs]
      rw [E_relation]
      field_simp [a_ne_zero, rho_ne_zero]
      ring

/-- Full histories of all four rational storage coordinates. -/
def IsRationalStateSolution (h z : ℝ → LoopState) : Prop :=
  ContinuousOn z (Ici (-(1/4 : ℝ))) ∧
  (∀ t ∈ Icc (-(1/4 : ℝ)) 0, z t = h t) ∧
  ∀ t, 0 < t → HasDerivAt z (rationalStateRhs (z t) (z (t-1/4))) t

theorem shared_solution_to_rational {h z : ℝ → LoopState}
    (hz : IsRetardedSharedSolution (finitePlantOutput plantC)
      (finitePlantDynamics plantA plantB) kp ti td tf (1/4) 0 0 h z) :
    IsRationalStateSolution (fun t => stateEquiv (h t))
      (fun t => stateEquiv (z t)) := by
  refine ⟨stateEquiv.continuous.comp_continuousOn hz.1, ?_, ?_⟩
  · intro t ht
    dsimp only
    rw [hz.2.1 t ht]
  · intro t ht
    have hd := stateEquiv.toContinuousLinearMap.hasFDerivAt.comp_hasDerivAt t (hz.2.2 t ht)
    simpa only [retardedSharedRhs_eq, add_zero, sub_eq_add_neg,
      ContinuousLinearEquiv.coe_coe, Function.comp_def, stateEquiv_conjugacy] using hd

theorem rational_solution_to_shared {h z : ℝ → LoopState}
    (hz : IsRationalStateSolution h z) :
    IsRetardedSharedSolution (finitePlantOutput plantC)
      (finitePlantDynamics plantA plantB) kp ti td tf (1/4) 0 0
      (fun t => stateEquiv.symm (h t)) (fun t => stateEquiv.symm (z t)) := by
  refine ⟨stateEquiv.symm.continuous.comp_continuousOn hz.1, ?_, ?_⟩
  · intro t ht
    dsimp only
    rw [hz.2.1 t ht]
  · intro t ht
    have hd := stateEquiv.symm.toContinuousLinearMap.hasFDerivAt.comp_hasDerivAt t (hz.2.2 t ht)
    have he : stateEquiv.symm (rationalStateRhs (z t) (z (t-1/4))) =
        retardedSharedRhs (finitePlantOutput plantC) (finitePlantDynamics plantA plantB)
          kp ti td tf (1/4) 0 0 (fun _ => 0)
          (fun θ => stateEquiv.symm (z (t+θ))) := by
      apply stateEquiv.injective
      simp only [ContinuousLinearEquiv.apply_symm_apply, retardedSharedRhs_eq,
        add_zero, stateEquiv_conjugacy]
      simp [sub_eq_add_neg]
    simpa only [ContinuousLinearEquiv.coe_coe, Function.comp_def, he] using hd

end Article14.ExactDelay
