import MIACE.Algebra
import Mathlib.Analysis.Calculus.Deriv.Basic

/-!
Article 14: exact PIDF coefficient geometry and shared-state algebra.

This module establishes the coefficient geometry and actual right-hand command
limits for claims 1--5.  The jump proofs use continuous zero-initial-state
responses and a strictly proper state-output map directly, rather than assuming
an initial-value theorem.  They do not prove existence of general closed-loop
solutions; the state trajectory is a given response.

The MIACE algebra import is reused unchanged.  Comments above each group give
the corresponding manuscript labels.
-/

namespace Article14

/-- The two controller derivatives and the implemented command, in that order. -/
noncomputable def sharedControllerRhs (Kp Ti Td Tf b c r y xI xF : ℝ) :
    ℝ × ℝ × ℝ :=
  (r - y, (c * r - y - xF) / Tf,
    Kp * (b * r - y + xI / Ti + Td / Tf * (c * r - y - xF)))

-- @paper-step prop:separation/shared-state-homogeneous-equations
theorem sharedController_homogeneous_independent
    (Kp Ti Td Tf b c b' c' y xI xF : ℝ) :
    sharedControllerRhs Kp Ti Td Tf b c 0 y xI xF =
      sharedControllerRhs Kp Ti Td Tf b' c' 0 y xI xF := by
  simp [sharedControllerRhs]

/-- The complete plant and shared-controller vector field; the plant is kept
abstract so the identity applies to every fixed state realization. -/
noncomputable def sharedClosedLoopRhs {X : Type*}
    (plantOutput : X → ℝ) (plantDynamics : X → ℝ → X)
    (Kp Ti Td Tf b c r : ℝ) (z : X × ℝ × ℝ) : X × ℝ × ℝ :=
  let ctrl := sharedControllerRhs Kp Ti Td Tf b c r (plantOutput z.1) z.2.1 z.2.2
  (plantDynamics z.1 ctrl.2.2, ctrl.1, ctrl.2.1)

-- @paper-step prop:separation/complete-shared-realization-homogeneous-field
theorem sharedClosedLoop_homogeneous_independent {X : Type*}
    (plantOutput : X → ℝ) (plantDynamics : X → ℝ → X)
    (Kp Ti Td Tf b c b' c' : ℝ) :
    sharedClosedLoopRhs plantOutput plantDynamics Kp Ti Td Tf b c 0 =
      sharedClosedLoopRhs plantOutput plantDynamics Kp Ti Td Tf b' c' 0 := by
  funext z
  simp [sharedClosedLoopRhs, sharedControllerRhs]

/-- Input-delay realization of `exp(-Ls) P₀(s)`: the rational plant receives
the command computed from the complete plant/controller state at time `-L`.
The controller itself uses the present plant output. -/
noncomputable def retardedSharedRhs {X : Type*}
    (plantOutput : X → ℝ) (plantDynamics : X → ℝ → X)
    (Kp Ti Td Tf L b c : ℝ) (referenceHistory : ℝ → ℝ)
    (stateHistory : ℝ → X × ℝ × ℝ) : X × ℝ × ℝ :=
  let zNow := stateHistory 0
  let zDelay := stateHistory (-L)
  let currentController := sharedControllerRhs Kp Ti Td Tf b c
    (referenceHistory 0) (plantOutput zNow.1) zNow.2.1 zNow.2.2
  let delayedController := sharedControllerRhs Kp Ti Td Tf b c
    (referenceHistory (-L)) (plantOutput zDelay.1) zDelay.2.1 zDelay.2.2
  (plantDynamics zNow.1 delayedController.2.2,
    currentController.1, currentController.2.1)

-- @paper-step prop:delay-hinf/actual-retarded-homogeneous-field
theorem retardedShared_homogeneous_independent {X : Type*}
    (plantOutput : X → ℝ) (plantDynamics : X → ℝ → X)
    (Kp Ti Td Tf L b c b' c' : ℝ) :
    retardedSharedRhs plantOutput plantDynamics Kp Ti Td Tf L b c (fun _ => 0) =
      retardedSharedRhs plantOutput plantDynamics Kp Ti Td Tf L b' c' (fun _ => 0) := by
  funext h
  simp [retardedSharedRhs, sharedControllerRhs]

/-- A classical zero-reference solution with its arbitrary complete history on
`[-L,0]`.  The differential equation is imposed for positive times, avoiding an
unnecessary differentiability assumption on the initial history at zero. -/
def IsRetardedSharedSolution {X : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X]
    (plantOutput : X → ℝ) (plantDynamics : X → ℝ → X)
    (Kp Ti Td Tf L b c : ℝ) (history trajectory : ℝ → X × ℝ × ℝ) : Prop :=
  ContinuousOn trajectory (Set.Ici (-L)) ∧
    (∀ t ∈ Set.Icc (-L) 0, trajectory t = history t) ∧
    ∀ t, 0 < t → HasDerivAt trajectory
      (retardedSharedRhs plantOutput plantDynamics Kp Ti Td Tf L b c
        (fun _ => 0) (fun θ => trajectory (t + θ))) t

-- @paper-step prop:delay-hinf/all-history-solution-equivalence
theorem retardedShared_solution_iff {X : Type*}
    [NormedAddCommGroup X] [NormedSpace ℝ X]
    (plantOutput : X → ℝ) (plantDynamics : X → ℝ → X)
    (Kp Ti Td Tf L b c b' c' : ℝ) (history trajectory : ℝ → X × ℝ × ℝ) :
    IsRetardedSharedSolution plantOutput plantDynamics Kp Ti Td Tf L b c
        history trajectory ↔
      IsRetardedSharedSolution plantOutput plantDynamics Kp Ti Td Tf L b' c'
        history trajectory := by
  unfold IsRetardedSharedSolution
  rw [retardedShared_homogeneous_independent plantOutput plantDynamics
    Kp Ti Td Tf L b c b' c']

-- @paper-step prop:delay-hinf/entire-solution-set-equality
theorem retardedShared_solutionSet_eq {X : Type*}
    [NormedAddCommGroup X] [NormedSpace ℝ X]
    (plantOutput : X → ℝ) (plantDynamics : X → ℝ → X)
    (Kp Ti Td Tf L b c b' c' : ℝ) (history : ℝ → X × ℝ × ℝ) :
    {z | IsRetardedSharedSolution plantOutput plantDynamics Kp Ti Td Tf L b c history z} =
      {z | IsRetardedSharedSolution plantOutput plantDynamics Kp Ti Td Tf L b' c' history z} := by
  ext z
  exact retardedShared_solution_iff plantOutput plantDynamics Kp Ti Td Tf L b c b' c' history z

/-- Uniform exponential decay for every complete initial history and every
classical solution.  `H` is any bound on the whole initial history, not merely
the state at time zero.  This is a stability property, not an assumed proof of
well-posedness; equality of the solution sets separately preserves existence. -/
def HasRetardedHistoryDecay {X : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X]
    (plantOutput : X → ℝ) (plantDynamics : X → ℝ → X)
    (Kp Ti Td Tf L b c M α : ℝ) : Prop :=
  ∀ (history trajectory : ℝ → X × ℝ × ℝ) (H : ℝ),
    (∀ θ ∈ Set.Icc (-L) 0, ‖history θ‖ ≤ H) →
    IsRetardedSharedSolution plantOutput plantDynamics Kp Ti Td Tf L b c history trajectory →
    ∀ t, 0 ≤ t → ‖trajectory t‖ ≤ M * Real.exp (-α * t) * H

-- @paper-step prop:delay-hinf/preservation-of-every-history-decay-estimate
theorem retardedShared_historyDecay_iff {X : Type*}
    [NormedAddCommGroup X] [NormedSpace ℝ X]
    (plantOutput : X → ℝ) (plantDynamics : X → ℝ → X)
    (Kp Ti Td Tf L b c b' c' M α : ℝ) :
    HasRetardedHistoryDecay plantOutput plantDynamics Kp Ti Td Tf L b c M α ↔
      HasRetardedHistoryDecay plantOutput plantDynamics Kp Ti Td Tf L b' c' M α := by
  unfold HasRetardedHistoryDecay
  simp only [retardedShared_solution_iff plantOutput plantDynamics Kp Ti Td Tf L b c b' c']

/-- Existence and uniqueness on the physical time domain for every continuous
initial history.  Values of a trajectory before `-L` are deliberately ignored. -/
def IsRetardedSharedWellPosed {X : Type*}
    [NormedAddCommGroup X] [NormedSpace ℝ X]
    (plantOutput : X → ℝ) (plantDynamics : X → ℝ → X)
    (Kp Ti Td Tf L b c : ℝ) : Prop :=
  ∀ history : ℝ → X × ℝ × ℝ, ContinuousOn history (Set.Icc (-L) 0) →
    ∃ trajectory, IsRetardedSharedSolution plantOutput plantDynamics Kp Ti Td Tf L b c
      history trajectory ∧
      ∀ other, IsRetardedSharedSolution plantOutput plantDynamics Kp Ti Td Tf L b c
        history other → Set.EqOn other trajectory (Set.Ici (-L))

-- @paper-step prop:delay-hinf/all-history-well-posedness-preserved
theorem retardedShared_wellPosed_iff {X : Type*}
    [NormedAddCommGroup X] [NormedSpace ℝ X]
    (plantOutput : X → ℝ) (plantDynamics : X → ℝ → X)
    (Kp Ti Td Tf L b c b' c' : ℝ) :
    IsRetardedSharedWellPosed plantOutput plantDynamics Kp Ti Td Tf L b c ↔
      IsRetardedSharedWellPosed plantOutput plantDynamics Kp Ti Td Tf L b' c' := by
  unfold IsRetardedSharedWellPosed
  simp only [retardedShared_solution_iff plantOutput plantDynamics Kp Ti Td Tf L b c b' c']

/-- Full initial-value well-posedness together with a uniform exponential bound
for every initial history and complete plant/controller state. -/
def IsRetardedSharedExponentiallyStable {X : Type*}
    [NormedAddCommGroup X] [NormedSpace ℝ X]
    (plantOutput : X → ℝ) (plantDynamics : X → ℝ → X)
    (Kp Ti Td Tf L b c : ℝ) : Prop :=
  IsRetardedSharedWellPosed plantOutput plantDynamics Kp Ti Td Tf L b c ∧
    ∃ M α : ℝ, 0 < M ∧ 0 < α ∧
      HasRetardedHistoryDecay plantOutput plantDynamics Kp Ti Td Tf L b c M α

-- @paper-step prop:delay-hinf/full-internal-exponential-stability-preserved
theorem retardedShared_exponentialStability_iff {X : Type*}
    [NormedAddCommGroup X] [NormedSpace ℝ X]
    (plantOutput : X → ℝ) (plantDynamics : X → ℝ → X)
    (Kp Ti Td Tf L b c b' c' : ℝ) :
    IsRetardedSharedExponentiallyStable plantOutput plantDynamics Kp Ti Td Tf L b c ↔
      IsRetardedSharedExponentiallyStable plantOutput plantDynamics Kp Ti Td Tf L b' c' := by
  unfold IsRetardedSharedExponentiallyStable
  rw [retardedShared_wellPosed_iff plantOutput plantDynamics Kp Ti Td Tf L b c b' c']
  simp only [retardedShared_historyDecay_iff plantOutput plantDynamics Kp Ti Td Tf L b c b' c']

-- @paper-step prop:separation/solving-external-feedback-equations
/-- Actual scalar frequency-domain feedback equations determine all channels.
No reference weight occurs in the coefficients of disturbance or noise. -/
theorem closedLoop_solution (P Cr Cy r d n y u : ℂ)
    (hden : 1 + P * Cy ≠ 0)
    (hy : y = P * (u + d)) (hu : u = Cr * r - Cy * (y + n)) :
    y = P * Cr / (1 + P * Cy) * r + P / (1 + P * Cy) * d -
        P * Cy / (1 + P * Cy) * n ∧
    u = Cr / (1 + P * Cy) * r - Cy * P / (1 + P * Cy) * d -
        Cy / (1 + P * Cy) * n := by
  constructor
  · field_simp [hden]
    linear_combination hy + P * hu
  · field_simp [hden]
    linear_combination hu - Cy * hy

/-- All six closed-loop coefficients, grouped as reference, disturbance, and
noise.  Their correctness follows from `closedLoop_solution` whenever the
feedback denominator is nonzero. -/
noncomputable def closedLoopTransfers (P Cr Cy : ℂ) :
    (ℂ × ℂ) × (ℂ × ℂ) × (ℂ × ℂ) :=
  ((P * Cr / (1 + P * Cy), Cr / (1 + P * Cy)),
    (P / (1 + P * Cy), -Cy * P / (1 + P * Cy)),
    (-P * Cy / (1 + P * Cy), -Cy / (1 + P * Cy)))

-- @paper-step prop:separation/implemented-external-channel-correctness
theorem closedLoopTransfers_correct (P Cr Cy r d n y u : ℂ)
    (hden : 1 + P * Cy ≠ 0)
    (hy : y = P * (u + d)) (hu : u = Cr * r - Cy * (y + n)) :
    y = (closedLoopTransfers P Cr Cy).1.1 * r +
        (closedLoopTransfers P Cr Cy).2.1.1 * d +
        (closedLoopTransfers P Cr Cy).2.2.1 * n ∧
    u = (closedLoopTransfers P Cr Cy).1.2 * r +
        (closedLoopTransfers P Cr Cy).2.1.2 * d +
        (closedLoopTransfers P Cr Cy).2.2.2 * n := by
  simpa [closedLoopTransfers, sub_eq_add_neg, neg_div, neg_mul] using
    closedLoop_solution P Cr Cy r d n y u hden hy hu

-- @paper-step prop:delay-hinf/feedback-frequency-channel-equality
theorem closedLoopTransfers_feedback_independent (P Cr Cr' Cy : ℂ) :
    (closedLoopTransfers P Cr Cy).2 = (closedLoopTransfers P Cr' Cy).2 := by
  rfl

-- @paper-step prop:delay-hinf/all-feedback-channel-norms-preserved
/-- Applies in particular to an H∞ norm whenever that functional is defined.
It does not assert that the reference-channel H∞ norm is independent of weights. -/
theorem closedLoopTransfers_feedback_functional_independent {Ω Y : Type*}
    (P Cr Cr' Cy : Ω → ℂ)
    (functional : (Ω → (ℂ × ℂ) × (ℂ × ℂ)) → Y) :
    functional (fun s => (closedLoopTransfers (P s) (Cr s) (Cy s)).2) =
      functional (fun s => (closedLoopTransfers (P s) (Cr' s) (Cy s)).2) := by
  rfl

/-- Coefficients of `s` and `s²` for the filtered-D placement. -/
noncomputable def dCoefficients (Ti Td Tf b c : ℝ) : ℝ × ℝ :=
  (Tf + b * Ti, Ti * (b * Tf + c * Td))

/-- Coefficients of `s` and `s²` for whole-output filtering. -/
noncomputable def oCoefficients (Ti Td b c : ℝ) : ℝ × ℝ :=
  (b * Ti, c * Ti * Td)

noncomputable def dWeights (Ti Td Tf σ π : ℝ) : ℝ × ℝ :=
  ((σ - Tf) / Ti, (π - Tf * (σ - Tf)) / (Ti * Td))

noncomputable def oWeights (Ti Td σ π : ℝ) : ℝ × ℝ :=
  (σ / Ti, π / (Ti * Td))

/-- The actual normalized quadratic polynomial, not a coefficient proxy. -/
noncomputable def referenceQuadratic (σ π : ℝ) : Polynomial ℝ :=
  1 + Polynomial.C σ * Polynomial.X + Polynomial.C π * Polynomial.X ^ 2

-- @paper-step thm:feasibility/quadratic-coefficient-equality
theorem referenceQuadratic_eq_iff (σ π σ' π' : ℝ) :
    referenceQuadratic σ π = referenceQuadratic σ' π' ↔ (σ, π) = (σ', π') := by
  constructor
  · intro h
    have h1 := congrArg (fun p : Polynomial ℝ => p.coeff 1) h
    have h2 := congrArg (fun p : Polynomial ℝ => p.coeff 2) h
    simp [referenceQuadratic, Polynomial.coeff_add, Polynomial.coeff_C_mul] at h1 h2
    exact Prod.ext h1 h2
  · intro h
    rcases Prod.mk.inj h with ⟨rfl, rfl⟩
    rfl

-- @paper-step thm:feasibility/D-common-denominator
theorem dController_commonDenominator (Kp Ti Td Tf b c s : ℂ)
    (hi : Ti ≠ 0) (hs : s ≠ 0) (hf : 1 + Tf * s ≠ 0) :
    Kp * (b + 1 / (Ti * s) + c * Td * s / (1 + Tf * s)) =
      Kp * (1 + (Tf + b * Ti) * s + Ti * (b * Tf + c * Td) * s ^ 2) /
        (Ti * s * (1 + Tf * s)) := by
  have hf' : 1 + s * Tf ≠ 0 := by simpa [mul_comm] using hf
  field_simp [hf']
  ring

-- @paper-step thm:feasibility/O-common-denominator
theorem oController_commonDenominator (Kp Ti Td Tf b c s : ℂ)
    (hi : Ti ≠ 0) (hs : s ≠ 0) (hf : 1 + Tf * s ≠ 0) :
    Kp / (1 + Tf * s) * (b + 1 / (Ti * s) + c * Td * s) =
      Kp * (1 + b * Ti * s + c * Ti * Td * s ^ 2) /
        (Ti * s * (1 + Tf * s)) := by
  field_simp
  ring

-- @paper-step thm:feasibility/D-inverse
theorem dCoefficients_dWeights (Ti Td Tf σ π : ℝ)
    (hi : Ti ≠ 0) (hd : Td ≠ 0) :
    dCoefficients Ti Td Tf (dWeights Ti Td Tf σ π).1
      (dWeights Ti Td Tf σ π).2 = (σ, π) := by
  apply Prod.ext <;> dsimp [dCoefficients, dWeights]
  · field_simp
    ring
  · field_simp
    ring

-- @paper-step thm:feasibility/D-uniqueness
theorem dCoefficients_eq_iff (Ti Td Tf b c σ π : ℝ)
    (hi : Ti ≠ 0) (hd : Td ≠ 0) :
    dCoefficients Ti Td Tf b c = (σ, π) ↔
      (b, c) = dWeights Ti Td Tf σ π := by
  constructor
  · intro h
    have hs := congrArg Prod.fst h
    have hp := congrArg Prod.snd h
    dsimp [dCoefficients] at hs hp
    apply Prod.ext
    · dsimp [dWeights]
      apply (eq_div_iff hi).2
      linarith
    · dsimp [dWeights]
      apply (eq_div_iff (mul_ne_zero hi hd)).2
      have hst := congrArg (fun z : ℝ => Tf * z) hs
      nlinarith
  · intro h
    have hb := congrArg Prod.fst h
    have hc := congrArg Prod.snd h
    dsimp only at hb hc
    rw [hb, hc]
    exact dCoefficients_dWeights Ti Td Tf σ π hi hd

-- @paper-step thm:feasibility/D-polynomial-assignment-unique-inverse
theorem dPolynomial_assignment_iff (Ti Td Tf b c σ π : ℝ)
    (hi : Ti ≠ 0) (hd : Td ≠ 0) :
    referenceQuadratic (Tf + b * Ti) (Ti * (b * Tf + c * Td)) =
        referenceQuadratic σ π ↔ (b, c) = dWeights Ti Td Tf σ π := by
  rw [referenceQuadratic_eq_iff]
  exact dCoefficients_eq_iff Ti Td Tf b c σ π hi hd

-- @paper-step thm:feasibility/O-inverse
theorem oCoefficients_oWeights (Ti Td σ π : ℝ)
    (hi : Ti ≠ 0) (hd : Td ≠ 0) :
    oCoefficients Ti Td (oWeights Ti Td σ π).1
      (oWeights Ti Td σ π).2 = (σ, π) := by
  apply Prod.ext <;> dsimp [oCoefficients, oWeights]
  · field_simp
  · field_simp

-- @paper-step thm:feasibility/O-uniqueness
theorem oCoefficients_eq_iff (Ti Td b c σ π : ℝ)
    (hi : Ti ≠ 0) (hd : Td ≠ 0) :
    oCoefficients Ti Td b c = (σ, π) ↔
      (b, c) = oWeights Ti Td σ π := by
  constructor
  · intro h
    have hs := congrArg Prod.fst h
    have hp := congrArg Prod.snd h
    dsimp [oCoefficients] at hs hp
    apply Prod.ext
    · dsimp [oWeights]
      exact (eq_div_iff hi).2 hs
    · dsimp [oWeights]
      apply (eq_div_iff (mul_ne_zero hi hd)).2
      nlinarith
  · intro h
    have hb := congrArg Prod.fst h
    have hc := congrArg Prod.snd h
    dsimp only at hb hc
    rw [hb, hc]
    exact oCoefficients_oWeights Ti Td σ π hi hd

-- @paper-step thm:feasibility/O-polynomial-assignment-unique-inverse
theorem oPolynomial_assignment_iff (Ti Td b c σ π : ℝ)
    (hi : Ti ≠ 0) (hd : Td ≠ 0) :
    referenceQuadratic (b * Ti) (c * Ti * Td) = referenceQuadratic σ π ↔
      (b, c) = oWeights Ti Td σ π := by
  rw [referenceQuadratic_eq_iff]
  exact oCoefficients_eq_iff Ti Td b c σ π hi hd

-- @paper-step thm:feasibility/D-box-inequalities
theorem dWeights_in_box_iff (Ti Td Tf σ π bl bu cl cu : ℝ)
    (hi : 0 < Ti) (hd : 0 < Td) :
    ((dWeights Ti Td Tf σ π).1 ∈ Set.Icc bl bu ∧
      (dWeights Ti Td Tf σ π).2 ∈ Set.Icc cl cu) ↔
    (Tf + Ti * bl ≤ σ ∧ σ ≤ Tf + Ti * bu) ∧
      (Ti * Td * cl + Tf * (σ - Tf) ≤ π ∧
        π ≤ Ti * Td * cu + Tf * (σ - Tf)) := by
  simp only [dWeights, Set.mem_Icc]
  rw [le_div_iff₀ hi, div_le_iff₀ hi,
    le_div_iff₀ (mul_pos hi hd), div_le_iff₀ (mul_pos hi hd)]
  constructor <;> rintro ⟨⟨h1, h2⟩, ⟨h3, h4⟩⟩ <;>
    constructor <;> constructor <;> nlinarith

-- @paper-step thm:feasibility/O-box-inequalities
theorem oWeights_in_box_iff (Ti Td σ π bl bu cl cu : ℝ)
    (hi : 0 < Ti) (hd : 0 < Td) :
    ((oWeights Ti Td σ π).1 ∈ Set.Icc bl bu ∧
      (oWeights Ti Td σ π).2 ∈ Set.Icc cl cu) ↔
    (Ti * bl ≤ σ ∧ σ ≤ Ti * bu) ∧
      (Ti * Td * cl ≤ π ∧ π ≤ Ti * Td * cu) := by
  simp only [oWeights, Set.mem_Icc]
  rw [le_div_iff₀ hi, div_le_iff₀ hi,
    le_div_iff₀ (mul_pos hi hd), div_le_iff₀ (mul_pos hi hd)]
  constructor <;> rintro ⟨⟨h1, h2⟩, ⟨h3, h4⟩⟩ <;>
    constructor <;> constructor <;> nlinarith

-- @paper-step thm:feasibility/D-existence-iff-parallelogram-inequalities
theorem dAssignment_exists_iff (Ti Td Tf σ π bl bu cl cu : ℝ)
    (hi : 0 < Ti) (hd : 0 < Td) :
    (∃ b ∈ Set.Icc bl bu, ∃ c ∈ Set.Icc cl cu,
      dCoefficients Ti Td Tf b c = (σ, π)) ↔
    (Tf + Ti * bl ≤ σ ∧ σ ≤ Tf + Ti * bu) ∧
      (Ti * Td * cl + Tf * (σ - Tf) ≤ π ∧
        π ≤ Ti * Td * cu + Tf * (σ - Tf)) := by
  rw [← dWeights_in_box_iff Ti Td Tf σ π bl bu cl cu hi hd]
  constructor
  · rintro ⟨b, hb, c, hc, heq⟩
    have hw := (dCoefficients_eq_iff Ti Td Tf b c σ π hi.ne' hd.ne').1 heq
    have hb' := congrArg Prod.fst hw
    have hc' := congrArg Prod.snd hw
    dsimp only at hb' hc'
    exact ⟨hb' ▸ hb, hc' ▸ hc⟩
  · rintro ⟨hb, hc⟩
    exact ⟨_, hb, _, hc, dCoefficients_dWeights Ti Td Tf σ π hi.ne' hd.ne'⟩

-- @paper-step thm:feasibility/O-existence-iff-rectangle-inequalities
theorem oAssignment_exists_iff (Ti Td σ π bl bu cl cu : ℝ)
    (hi : 0 < Ti) (hd : 0 < Td) :
    (∃ b ∈ Set.Icc bl bu, ∃ c ∈ Set.Icc cl cu,
      oCoefficients Ti Td b c = (σ, π)) ↔
    (Ti * bl ≤ σ ∧ σ ≤ Ti * bu) ∧
      (Ti * Td * cl ≤ π ∧ π ≤ Ti * Td * cu) := by
  rw [← oWeights_in_box_iff Ti Td σ π bl bu cl cu hi hd]
  constructor
  · rintro ⟨b, hb, c, hc, heq⟩
    have hw := (oCoefficients_eq_iff Ti Td b c σ π hi.ne' hd.ne').1 heq
    have hb' := congrArg Prod.fst hw
    have hc' := congrArg Prod.snd hw
    dsimp only at hb' hc'
    exact ⟨hb' ▸ hb, hc' ▸ hc⟩
  · rintro ⟨hb, hc⟩
    exact ⟨_, hb, _, hc, oCoefficients_oWeights Ti Td σ π hi.ne' hd.ne'⟩

-- @paper-step thm:feasibility/invertible-affine-map-determinant
theorem dCoefficient_determinant_pos (Ti Td : ℝ) (hi : 0 < Ti) (hd : 0 < Td) :
    0 < Ti * (Ti * Td) - 0 * (Ti * 1) := by
  simpa using mul_pos hi (mul_pos hi hd)

-- @paper-step thm:feasibility/measurement-only-factorization
theorem dNumerator_measurement_only (Ti Tf b s : ℝ) :
    1 + (Tf + b * Ti) * s + Ti * (b * Tf) * s ^ 2 =
      (1 + Tf * s) * (1 + b * Ti * s) := by ring

-- @paper-step thm:jump/shared-state-instantaneous-command
theorem sharedController_zeroState_command (Kp Ti Td Tf b c Δr : ℝ) :
    (sharedControllerRhs Kp Ti Td Tf b c Δr 0 0 0).2.2 =
      Kp * (b + c * Td / Tf) * Δr := by
  dsimp [sharedControllerRhs]
  ring

/-- Two shared states for whole-controller output filtering.  The second state
absorbs the proper remainder after the derivative feedthrough is split off. -/
noncomputable def outputFilteredControllerRhs (Kp Ti Td Tf b c r y xI xO : ℝ) :
    ℝ × ℝ × ℝ :=
  (r - y, (b * r - y + xI / Ti - Td / Tf * (c * r - y) - xO) / Tf,
    Kp * (Td / Tf * (c * r - y) + xO))

-- @paper-step thm:jump/output-filter-shared-realization-transfer-law
/-- Algebraic Laplace equations of this realization give the manuscript's
whole-output-filter controller; no independent duplicate integrator is used. -/
theorem outputFilteredController_laplace_law (Kp Ti Td Tf b c s r y xI xO : ℂ)
    (hi : Ti ≠ 0) (hf : Tf ≠ 0) (hs : s ≠ 0) (hfilter : 1 + Tf * s ≠ 0)
    (hI : xI = (r - y) / s)
    (hO : xO = (b * r - y + xI / Ti - Td / Tf * (c * r - y)) / (1 + Tf * s)) :
    Kp * (Td / Tf * (c * r - y) + xO) =
      Kp / (1 + Tf * s) *
        ((b + 1 / (Ti * s) + c * Td * s) * r -
          (1 + 1 / (Ti * s) + Td * s) * y) := by
  subst xO xI
  have hfilter' : 1 + s * Tf ≠ 0 := by simpa [mul_comm] using hfilter
  field_simp [hfilter']
  ring

-- @paper-step thm:jump/output-filter-zero-state-command
theorem outputFilteredController_zeroState_command (Kp Ti Td Tf b c Δr : ℝ) :
    (outputFilteredControllerRhs Kp Ti Td Tf b c Δr 0 0 0).2.2 =
      Kp * (c * Td / Tf) * Δr := by
  dsimp [outputFilteredControllerRhs]
  ring

/-- The physical D-placement command under a constant post-step reference and
the strictly proper plant output `y(t) = output (state(t).1)`. -/
noncomputable def dStepCommand {X : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X]
    (output : X →L[ℝ] ℝ) (Kp Ti Td Tf b c Δr : ℝ)
    (state : ℝ → X × ℝ × ℝ) (t : ℝ) : ℝ :=
  (sharedControllerRhs Kp Ti Td Tf b c Δr
    (output (state t).1) (state t).2.1 (state t).2.2).2.2

/-- The corresponding whole-output-filter command for its two shared states. -/
noncomputable def oStepCommand {X : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X]
    (output : X →L[ℝ] ℝ) (Kp Ti Td Tf b c Δr : ℝ)
    (state : ℝ → X × ℝ × ℝ) (t : ℝ) : ℝ :=
  (outputFilteredControllerRhs Kp Ti Td Tf b c Δr
    (output (state t).1) (state t).2.1 (state t).2.2).2.2

-- @paper-step thm:jump/D-actual-command-right-limit
theorem dStepCommand_rightLimit {X : Type*}
    [NormedAddCommGroup X] [NormedSpace ℝ X]
    (output : X →L[ℝ] ℝ) (Kp Ti Td Tf b c Δr : ℝ)
    (state : ℝ → X × ℝ × ℝ)
    (hcontinuous : ContinuousWithinAt state (Set.Ioi 0) 0) (hzero : state 0 = 0) :
    Filter.Tendsto (dStepCommand output Kp Ti Td Tf b c Δr state)
      (nhdsWithin 0 (Set.Ioi 0)) (nhds (Kp * (b + c * Td / Tf) * Δr)) := by
  have hstate : Filter.Tendsto state (nhdsWithin 0 (Set.Ioi 0)) (nhds 0) := by
    simpa [hzero] using hcontinuous.tendsto
  have hmap : Continuous (fun z : X × ℝ × ℝ =>
      (sharedControllerRhs Kp Ti Td Tf b c Δr (output z.1) z.2.1 z.2.2).2.2) := by
    dsimp [sharedControllerRhs]
    fun_prop
  have h := hmap.continuousAt.tendsto.comp hstate
  have hzeroCommand :
      (sharedControllerRhs Kp Ti Td Tf b c Δr (output (0 : X)) 0 0).2.2 =
        Kp * (b + c * Td / Tf) * Δr := by
    simpa using sharedController_zeroState_command Kp Ti Td Tf b c Δr
  change Filter.Tendsto (fun t => (sharedControllerRhs Kp Ti Td Tf b c Δr
    (output (state t).1) (state t).2.1 (state t).2.2).2.2) _ _
  simpa only [Function.comp_def, Prod.fst_zero, Prod.snd_zero,
    hzeroCommand] using h

-- @paper-step thm:jump/O-actual-command-right-limit
theorem oStepCommand_rightLimit {X : Type*}
    [NormedAddCommGroup X] [NormedSpace ℝ X]
    (output : X →L[ℝ] ℝ) (Kp Ti Td Tf b c Δr : ℝ)
    (state : ℝ → X × ℝ × ℝ)
    (hcontinuous : ContinuousWithinAt state (Set.Ioi 0) 0) (hzero : state 0 = 0) :
    Filter.Tendsto (oStepCommand output Kp Ti Td Tf b c Δr state)
      (nhdsWithin 0 (Set.Ioi 0)) (nhds (Kp * (c * Td / Tf) * Δr)) := by
  have hstate : Filter.Tendsto state (nhdsWithin 0 (Set.Ioi 0)) (nhds 0) := by
    simpa [hzero] using hcontinuous.tendsto
  have hmap : Continuous (fun z : X × ℝ × ℝ =>
      (outputFilteredControllerRhs Kp Ti Td Tf b c Δr (output z.1) z.2.1 z.2.2).2.2) := by
    dsimp [outputFilteredControllerRhs]
    fun_prop
  have h := hmap.continuousAt.tendsto.comp hstate
  have hzeroCommand :
      (outputFilteredControllerRhs Kp Ti Td Tf b c Δr (output (0 : X)) 0 0).2.2 =
        Kp * (c * Td / Tf) * Δr := by
    simpa using outputFilteredController_zeroState_command Kp Ti Td Tf b c Δr
  change Filter.Tendsto (fun t => (outputFilteredControllerRhs Kp Ti Td Tf b c Δr
    (output (state t).1) (state t).2.1 (state t).2.2).2.2) _ _
  simpa only [Function.comp_def, Prod.fst_zero, Prod.snd_zero,
    hzeroCommand] using h

-- @paper-step thm:jump/D-feedthrough-invariant
theorem dAssigned_feedthrough (Kp Ti Td Tf σ π Δr : ℝ)
    (hi : Ti ≠ 0) (hd : Td ≠ 0) (hf : Tf ≠ 0) :
    Kp * ((dWeights Ti Td Tf σ π).1 +
        (dWeights Ti Td Tf σ π).2 * Td / Tf) * Δr =
      Kp * π / (Ti * Tf) * Δr := by
  dsimp [dWeights]
  field_simp
  ring

-- @paper-step thm:jump/O-feedthrough-invariant
theorem oAssigned_feedthrough (Kp Ti Td Tf σ π Δr : ℝ)
    (hi : Ti ≠ 0) (hd : Td ≠ 0) (hf : Tf ≠ 0) :
    Kp * ((oWeights Ti Td σ π).2 * Td / Tf) * Δr =
      Kp * π / (Ti * Tf) * Δr := by
  dsimp [oWeights]
  field_simp

-- @paper-step thm:jump/D-exact-assignment-physical-limit
theorem dAssignedStepCommand_rightLimit {X : Type*}
    [NormedAddCommGroup X] [NormedSpace ℝ X]
    (output : X →L[ℝ] ℝ) (Kp Ti Td Tf σ π Δr : ℝ)
    (state : ℝ → X × ℝ × ℝ)
    (hi : Ti ≠ 0) (hd : Td ≠ 0) (hf : Tf ≠ 0)
    (hcontinuous : ContinuousWithinAt state (Set.Ioi 0) 0) (hzero : state 0 = 0) :
    Filter.Tendsto
      (dStepCommand output Kp Ti Td Tf (dWeights Ti Td Tf σ π).1
        (dWeights Ti Td Tf σ π).2 Δr state)
      (nhdsWithin 0 (Set.Ioi 0)) (nhds (Kp * π / (Ti * Tf) * Δr)) := by
  rw [← dAssigned_feedthrough Kp Ti Td Tf σ π Δr hi hd hf]
  exact dStepCommand_rightLimit output Kp Ti Td Tf _ _ Δr state hcontinuous hzero

-- @paper-step thm:jump/O-exact-assignment-physical-limit
theorem oAssignedStepCommand_rightLimit {X : Type*}
    [NormedAddCommGroup X] [NormedSpace ℝ X]
    (output : X →L[ℝ] ℝ) (Kp Ti Td Tf σ π Δr : ℝ)
    (state : ℝ → X × ℝ × ℝ)
    (hi : Ti ≠ 0) (hd : Td ≠ 0) (hf : Tf ≠ 0)
    (hcontinuous : ContinuousWithinAt state (Set.Ioi 0) 0) (hzero : state 0 = 0) :
    Filter.Tendsto
      (oStepCommand output Kp Ti Td Tf (oWeights Ti Td σ π).1
        (oWeights Ti Td σ π).2 Δr state)
      (nhdsWithin 0 (Set.Ioi 0)) (nhds (Kp * π / (Ti * Tf) * Δr)) := by
  rw [← oAssigned_feedthrough Kp Ti Td Tf σ π Δr hi hd hf]
  exact oStepCommand_rightLimit output Kp Ti Td Tf _ _ Δr state hcontinuous hzero

-- @paper-step cor:jump-feasible/exact-absolute-jump-bound
theorem assigned_jump_limit_iff (Kp Ti Tf π Δr umax : ℝ)
    (hk : 0 < Kp) (hi : 0 < Ti) (hf : 0 < Tf)
    (hp : 0 ≤ π) (hr : Δr ≠ 0) :
    |Kp * π / (Ti * Tf) * Δr| ≤ umax ↔
      π ≤ umax * Ti * Tf / (Kp * |Δr|) := by
  have hden : 0 < Ti * Tf := mul_pos hi hf
  have habs : 0 < |Δr| := abs_pos.mpr hr
  rw [abs_mul, abs_of_nonneg (by positivity : 0 ≤ Kp * π / (Ti * Tf))]
  rw [le_div_iff₀ (mul_pos hk habs)]
  constructor
  · intro h
    have h' := (mul_le_mul_iff_right₀ hden).2 h
    have heq : (Ti * Tf) * (Kp * π / (Ti * Tf) * |Δr|) = π * (Kp * |Δr|) := by
      field_simp
    rw [heq] at h'
    nlinarith
  · intro h
    apply (mul_le_mul_iff_right₀ hden).1
    have heq : (Ti * Tf) * (Kp * π / (Ti * Tf) * |Δr|) = π * (Kp * |Δr|) := by
      field_simp
    rw [heq]
    nlinarith

-- @paper-step cor:jump-feasible/D-physical-jump-bound-equivalence
theorem dAssignedStepCommand_jump_bound_iff {X : Type*}
    [NormedAddCommGroup X] [NormedSpace ℝ X]
    (output : X →L[ℝ] ℝ) (Kp Ti Td Tf σ π Δr umax J : ℝ)
    (state : ℝ → X × ℝ × ℝ)
    (hk : 0 < Kp) (hi : 0 < Ti) (hd : 0 < Td) (hf : 0 < Tf)
    (hp : 0 ≤ π) (hr : Δr ≠ 0)
    (hcontinuous : ContinuousWithinAt state (Set.Ioi 0) 0) (hzero : state 0 = 0)
    (hJ : Filter.Tendsto
      (dStepCommand output Kp Ti Td Tf (dWeights Ti Td Tf σ π).1
        (dWeights Ti Td Tf σ π).2 Δr state)
      (nhdsWithin 0 (Set.Ioi 0)) (nhds J)) :
    |J| ≤ umax ↔ π ≤ umax * Ti * Tf / (Kp * |Δr|) := by
  have hvalue : J = Kp * π / (Ti * Tf) * Δr :=
    tendsto_nhds_unique hJ
      (dAssignedStepCommand_rightLimit output Kp Ti Td Tf σ π Δr state
        hi.ne' hd.ne' hf.ne' hcontinuous hzero)
  rw [hvalue]
  exact assigned_jump_limit_iff Kp Ti Tf π Δr umax hk hi hf hp hr

-- @paper-step cor:jump-feasible/O-physical-jump-bound-equivalence
theorem oAssignedStepCommand_jump_bound_iff {X : Type*}
    [NormedAddCommGroup X] [NormedSpace ℝ X]
    (output : X →L[ℝ] ℝ) (Kp Ti Td Tf σ π Δr umax J : ℝ)
    (state : ℝ → X × ℝ × ℝ)
    (hk : 0 < Kp) (hi : 0 < Ti) (hd : 0 < Td) (hf : 0 < Tf)
    (hp : 0 ≤ π) (hr : Δr ≠ 0)
    (hcontinuous : ContinuousWithinAt state (Set.Ioi 0) 0) (hzero : state 0 = 0)
    (hJ : Filter.Tendsto
      (oStepCommand output Kp Ti Td Tf (oWeights Ti Td σ π).1
        (oWeights Ti Td σ π).2 Δr state)
      (nhdsWithin 0 (Set.Ioi 0)) (nhds J)) :
    |J| ≤ umax ↔ π ≤ umax * Ti * Tf / (Kp * |Δr|) := by
  have hvalue : J = Kp * π / (Ti * Tf) * Δr :=
    tendsto_nhds_unique hJ
      (oAssignedStepCommand_rightLimit output Kp Ti Td Tf σ π Δr state
        hi.ne' hd.ne' hf.ne' hcontinuous hzero)
  rw [hvalue]
  exact assigned_jump_limit_iff Kp Ti Tf π Δr umax hk hi hf hp hr

-- @paper-step cor:damping-floor/nonnegative-proportional-weight
theorem dAssignment_nonnegative_b_frequency_bound
    (Ti Tf ζ ω : ℝ) (hi : 0 < Ti) (hf : 0 < Tf) (hw : 0 < ω)
    (hb : 0 ≤ (2 * ζ / ω - Tf) / Ti) :
    ω ≤ 2 * ζ / Tf := by
  have h : 0 ≤ 2 * ζ / ω - Tf := by
    simpa using (le_div_iff₀ hi).1 hb
  have h' : Tf ≤ 2 * ζ / ω := by linarith
  have h'' := (le_div_iff₀ hw).1 h'
  apply (le_div_iff₀ hf).2
  nlinarith

-- @paper-step cor:damping-floor/frequency-lower-endpoint
theorem assigned_jump_frequency_lower_bound (Kp Ti Tf Δr umax ω : ℝ)
    (hk : 0 < Kp) (hi : 0 < Ti) (hf : 0 < Tf)
    (hr : Δr ≠ 0) (hu : 0 < umax) (hw : 0 < ω)
    (hjump : 1 / ω ^ 2 ≤ umax * Ti * Tf / (Kp * |Δr|)) :
    Real.sqrt (Kp * |Δr| / (umax * Ti * Tf)) ≤ ω := by
  have ha : 0 < Kp * |Δr| := mul_pos hk (abs_pos.mpr hr)
  have hu' : 0 < umax * Ti * Tf := by positivity
  have hw' : 0 < ω ^ 2 := sq_pos_of_pos hw
  have h1 := (div_le_div_iff₀ hw' ha).1 hjump
  have h2 : Kp * |Δr| / (umax * Ti * Tf) ≤ ω ^ 2 := by
    apply (div_le_iff₀ hu').2
    nlinarith
  exact (Real.sqrt_le_iff).2 ⟨hw.le, h2⟩

-- @paper-step cor:damping-floor/damping-lower-bound
theorem damping_floor_from_frequency_interval (Kp Ti Tf Δr umax ζ ω : ℝ)
    (hk : 0 < Kp) (hi : 0 < Ti) (hf : 0 < Tf)
    (hr : Δr ≠ 0) (hu : 0 < umax) (hw : 0 < ω)
    (hlo : Real.sqrt (Kp * |Δr| / (umax * Ti * Tf)) ≤ ω)
    (hup : ω ≤ 2 * ζ / Tf) :
    (1 / 2 : ℝ) * Real.sqrt (Kp * |Δr| * Tf / (umax * Ti)) ≤ ζ := by
  have hz : 0 < ζ := by
    have h := (le_div_iff₀ hf).1 hup
    nlinarith [mul_pos hw hf]
  have hA : 0 ≤ Kp * |Δr| / (umax * Ti * Tf) := by positivity
  have hsq := Real.sq_sqrt hA
  have hsnon := Real.sqrt_nonneg (Kp * |Δr| / (umax * Ti * Tf))
  have h1 : Tf * Real.sqrt (Kp * |Δr| / (umax * Ti * Tf)) ≤ 2 * ζ := by
    have h := (le_div_iff₀ hf).1 hup
    nlinarith
  have heq : Tf ^ 2 * (Kp * |Δr| / (umax * Ti * Tf)) =
      Kp * |Δr| * Tf / (umax * Ti) := by
    field_simp
  have h2 : Kp * |Δr| * Tf / (umax * Ti) ≤ (2 * ζ) ^ 2 := by
    rw [← heq, ← hsq]
    have hh := mul_self_le_mul_self (by positivity : 0 ≤ Tf *
      Real.sqrt (Kp * |Δr| / (umax * Ti * Tf))) h1
    nlinarith only [hh]
  have h3 : Real.sqrt (Kp * |Δr| * Tf / (umax * Ti)) ≤ 2 * ζ :=
    (Real.sqrt_le_iff).2 ⟨by positivity, h2⟩
  linarith

-- @paper-step cor:damping-floor/physical-command-consequence
theorem dAssignedStepCommand_damping_floor {X : Type*}
    [NormedAddCommGroup X] [NormedSpace ℝ X]
    (output : X →L[ℝ] ℝ) (Kp Ti Td Tf ζ ω Δr umax J : ℝ)
    (state : ℝ → X × ℝ × ℝ)
    (hk : 0 < Kp) (hi : 0 < Ti) (hd : 0 < Td) (hf : 0 < Tf)
    (hr : Δr ≠ 0) (hu : 0 < umax) (hw : 0 < ω)
    (hcontinuous : ContinuousWithinAt state (Set.Ioi 0) 0) (hzero : state 0 = 0)
    (hJ : Filter.Tendsto
      (dStepCommand output Kp Ti Td Tf (dWeights Ti Td Tf (2 * ζ / ω) (1 / ω ^ 2)).1
        (dWeights Ti Td Tf (2 * ζ / ω) (1 / ω ^ 2)).2 Δr state)
      (nhdsWithin 0 (Set.Ioi 0)) (nhds J))
    (hbound : |J| ≤ umax)
    (hb : 0 ≤ (dWeights Ti Td Tf (2 * ζ / ω) (1 / ω ^ 2)).1) :
    Real.sqrt (Kp * |Δr| / (umax * Ti * Tf)) ≤ ω ∧
      ω ≤ 2 * ζ / Tf ∧
      (1 / 2 : ℝ) * Real.sqrt (Kp * |Δr| * Tf / (umax * Ti)) ≤ ζ := by
  have hjump := (dAssignedStepCommand_jump_bound_iff output Kp Ti Td Tf
    (2 * ζ / ω) (1 / ω ^ 2) Δr umax J state hk hi hd hf
    (by positivity) hr hcontinuous hzero hJ).1 hbound
  have hlo := assigned_jump_frequency_lower_bound Kp Ti Tf Δr umax ω hk hi hf hr hu hw hjump
  have hup := dAssignment_nonnegative_b_frequency_bound Ti Tf ζ ω hi hf hw hb
  exact ⟨hlo, hup, damping_floor_from_frequency_interval
    Kp Ti Tf Δr umax ζ ω hk hi hf hr hu hw hlo hup⟩

-- @paper-step cor:damping-floor/sharpness-witness-for-nonnegative-weights
/-- The explicit witness at the common frequency endpoint.  The extra condition
`Tf * ω / 2 < 1` makes this positive-damping quadratic a complex target. -/
theorem damping_floor_sharp_witness (Kp Ti Td Tf Δr umax ω : ℝ)
    (hk : 0 < Kp) (hi : 0 < Ti) (hd : 0 < Td) (hf : 0 < Tf)
    (_hr : Δr ≠ 0) (hu : 0 < umax) (hw : 0 < ω)
    (hω : ω ^ 2 = Kp * |Δr| / (umax * Ti * Tf)) :
    0 < 1 / (Ti * Td * ω ^ 2) ∧
      dCoefficients Ti Td Tf 0 (1 / (Ti * Td * ω ^ 2)) =
        (2 * (Tf * ω / 2) / ω, 1 / ω ^ 2) ∧
      |Kp * (1 / ω ^ 2) / (Ti * Tf) * Δr| = umax := by
  have hw0 : ω ≠ 0 := hw.ne'
  have hi0 : Ti ≠ 0 := hi.ne'
  have hd0 : Td ≠ 0 := hd.ne'
  have hf0 : Tf ≠ 0 := hf.ne'
  have hu0 : umax ≠ 0 := hu.ne'
  refine ⟨by positivity, ?_, ?_⟩
  · apply Prod.ext <;> dsimp [dCoefficients]
    · field_simp
      ring
    · field_simp
      ring
  · rw [abs_mul, abs_of_nonneg (by positivity : 0 ≤ Kp * (1 / ω ^ 2) / (Ti * Tf))]
    have hh := (eq_div_iff (by positivity : umax * Ti * Tf ≠ 0)).1 hω
    field_simp
    nlinarith

-- @paper-step cor:damping-floor/sharp-witness-attains-the-square-root-floor
theorem sharp_witness_damping_eq_floor (Kp Ti Tf Δr umax ω : ℝ)
    (hi : 0 < Ti) (hf : 0 < Tf) (hu : 0 < umax) (hw : 0 < ω)
    (hω : ω ^ 2 = Kp * |Δr| / (umax * Ti * Tf)) :
    Tf * ω / 2 = (1 / 2 : ℝ) * Real.sqrt (Kp * |Δr| * Tf / (umax * Ti)) := by
  have heq : Kp * |Δr| * Tf / (umax * Ti) = (Tf * ω) ^ 2 := by
    have hh := (eq_div_iff (by positivity : umax * Ti * Tf ≠ 0)).1 hω
    apply (div_eq_iff (by positivity : umax * Ti ≠ 0)).2
    have hh' := congrArg (fun z : ℝ => z * Tf) hh
    nlinarith only [hh']
  rw [heq, Real.sqrt_sq_eq_abs, abs_of_pos (mul_pos hf hw)]
  ring

-- @paper-step cor:damping-floor/sharp-witness-is-complex-below-unit-damping
theorem sharp_witness_complex (Tf ω : ℝ) (hf : 0 < Tf) (hw : 0 < ω)
    (hz : Tf * ω / 2 < 1) :
    0 < Tf * ω / 2 ∧ (2 * (Tf * ω / 2) / ω) ^ 2 < 4 * (1 / ω ^ 2) := by
  constructor
  · positivity
  · have hz0 : 0 < Tf * ω / 2 := by positivity
    have hsq : (Tf * ω / 2) ^ 2 < 1 := by nlinarith
    have hi : (2 * (Tf * ω / 2) / ω) ^ 2 * ω ^ 2 = 4 * (Tf * ω / 2) ^ 2 := by
      field_simp
      ring
    have hrhs : 4 * (1 / ω ^ 2) * ω ^ 2 = 4 := by field_simp
    apply (mul_lt_mul_iff_left₀ (by positivity : 0 < ω ^ 2)).1
    nlinarith only [hi, hrhs, hsq]

end Article14
