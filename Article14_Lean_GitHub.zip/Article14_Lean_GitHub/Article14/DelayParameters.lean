import MIACE.Algebra
import Mathlib.Analysis.Complex.Exponential

/-! Exact arithmetic for Article 14, Theorem 18. These declarations are
coefficient and objective identities; no dynamical conclusion is inferred
from a transfer numerator alone. The physical baseline is reused separately
in `Article14.ExactDelay`. -/
namespace Article14.ExactDelay

noncomputable def E : ℝ := Real.exp (1 / 4)
noncomputable def d : ℝ := 27 / 16
noncomputable def a : ℝ := d - E
noncomputable def rho : ℝ := a / d
noncomputable def tf : ℝ := rho
noncomputable def ti : ℝ := 2 - rho
noncomputable def kp : ℝ := (2 - rho) / d
noncomputable def td : ℝ := (1 - rho)^2 / (2 - rho)
noncomputable def b (q : ℝ) : ℝ := (1 + q - rho) / (2 - rho)
noncomputable def c (q : ℝ) : ℝ := (q - rho) / (1 - rho)
noncomputable def errorArea (q : ℝ) : ℝ := 43 / 16 - q
noncomputable def commandArea (q : ℝ) : ℝ := q - 7 / 16
noncomputable def optimalQ (α : ℝ) : ℝ := 43 / 16 - 9 * α / (4 * (1 + α))

-- Article 14, Theorem 18: the constants are bounded by a certified Taylor remainder.
theorem exp_bounds : (5 / 4 : ℝ) < E ∧ E < 9 / 7 := by
  have hl := Real.add_one_lt_exp (x := (1 / 4 : ℝ)) (by norm_num)
  have hu := Real.exp_bound (x := (1 / 4 : ℝ)) (by norm_num) (n := 4) (by norm_num)
  norm_num [Finset.sum_range_succ, Nat.factorial] at hu
  dsimp [E]
  constructor
  · linarith
  · linarith [(abs_le.mp hu).2]

-- Article 14, Theorem 18: all four fixed PIDF parameters are strictly positive.
theorem a_bounds : (45 / 112 : ℝ) < a ∧ a < 7 / 16 := by
  obtain ⟨hl, hu⟩ := exp_bounds
  dsimp [a, d]
  constructor <;> linarith

theorem rho_bounds : 0 < rho ∧ rho < 13 / 16 := by
  obtain ⟨hl, hu⟩ := a_bounds
  dsimp [rho, d]
  constructor <;> linarith

theorem parameters_positive : 0 < tf ∧ 0 < ti ∧ 0 < kp ∧ 0 < td := by
  obtain ⟨hl, hu⟩ := rho_bounds
  dsimp [tf, ti, kp, td, d]
  refine ⟨hl, by linarith, by linarith, ?_⟩
  exact div_pos (sq_pos_of_pos (by linarith)) (by linarith)

theorem integral_gain : kp / ti = 1 / d := by
  have ht : ti ≠ 0 := ne_of_gt parameters_positive.2.1
  dsimp [kp, ti] at ht ⊢
  field_simp

-- Article 14, Theorem 18: the complete reference path lies in the admitted box.
theorem weights_in_box {q : ℝ} (hq : q ∈ Set.Icc (13 / 16 : ℝ) 1) :
    b q ∈ Set.Icc (0 : ℝ) 1 ∧ c q ∈ Set.Icc (0 : ℝ) 1 := by
  obtain ⟨hr0, hr1⟩ := rho_bounds
  have h2 : 0 < 2 - rho := by linarith
  have h1 : 0 < 1 - rho := by linarith
  constructor
  · constructor
    · exact div_nonneg (by linarith [hq.1]) h2.le
    · exact (div_le_one h2).mpr (by linarith [hq.2])
  · constructor
    · exact div_nonneg (by linarith [hq.1]) h1.le
    · exact (div_le_one h1).mpr (by linarith [hq.2])

theorem endpoint_weights : b 1 = 1 ∧ c 1 = 1 := by
  obtain ⟨_, hr⟩ := rho_bounds
  have h2 : 2 - rho ≠ 0 := by linarith
  have h1 : 1 - rho ≠ 0 := by linarith
  constructor
  · norm_num [b, h2]
  · simp [c, h1]

-- Article 14, Theorem 18: both numerator coefficients follow from the same b,c weights.
theorem reference_coefficients (q : ℝ) :
    tf + b q * ti = 1 + q ∧ ti * (b q * tf + c q * td) = q := by
  obtain ⟨_, hr⟩ := rho_bounds
  have h2 : 2 - rho ≠ 0 := by linarith
  have h1 : 1 - rho ≠ 0 := by linarith
  dsimp [tf, ti, td, b, c]
  constructor <;> field_simp <;> ring

theorem feedback_coefficients :
    ti + tf = 2 ∧ ti * (tf + td) = 1 := by
  obtain ⟨_, hr⟩ := rho_bounds
  have h2 : 2 - rho ≠ 0 := by linarith
  dsimp [tf, ti, td]
  constructor
  · ring
  · field_simp
    ring

theorem denominator_scale (s : ℝ) :
    ti * s * (1 + tf * s) / kp = s * (a * s + d) := by
  have hd : d ≠ 0 := by norm_num [d]
  have ht : 2 - rho ≠ 0 := ne_of_gt parameters_positive.2.1
  dsimp [ti, tf, kp]
  field_simp
  dsimp [rho]
  field_simp
  ring

theorem reference_numerator (q s : ℝ) :
    1 + (tf + b q * ti) * s + ti * (b q * tf + c q * td) * s^2 =
      (1 + s) * (1 + q * s) := by
  rw [(reference_coefficients q).1, (reference_coefficients q).2]
  ring

theorem prefilter_identity (q s : ℝ) (hs : 1 + s ≠ 0) :
    (1 + q * s) / (1 + s) = q + (1 - q) / (1 + s) := by
  field_simp
  ring

-- Article 14, Theorem 18: these exact area formulas satisfy the plant's signed-area balance.
theorem area_balance (q : ℝ) : errorArea q + commandArea q = 9 / 4 := by
  dsimp [errorArea, commandArea]
  ring

theorem area_positive {q : ℝ} (hq : q ∈ Set.Icc (13 / 16 : ℝ) 1) :
    0 < errorArea q ∧ 0 < commandArea q := by
  dsimp [errorArea, commandArea]
  constructor <;> linarith [hq.1, hq.2]

-- Article 14, Theorem 18: alpha in [3,5] maps exactly into the certified q interval.
theorem optimalQ_in_interval {α : ℝ} (hα : α ∈ Set.Icc (3 : ℝ) 5) :
    optimalQ α ∈ Set.Icc (13 / 16 : ℝ) 1 := by
  have hd : 0 < 4 * (1 + α) := by linarith [hα.1]
  have hlo : 9 * α / (4 * (1 + α)) ≤ 15 / 8 := by
    apply (div_le_iff₀ hd).mpr
    linarith [hα.2]
  have hhi : (27 / 16 : ℝ) ≤ 9 * α / (4 * (1 + α)) := by
    apply (le_div_iff₀ hd).mpr
    linarith [hα.1]
  dsimp [optimalQ]
  exact ⟨by linarith, by linarith⟩

theorem optimal_areas {α : ℝ} (hα : 0 < α) :
    errorArea (optimalQ α) = 9 * α / (4 * (1 + α)) ∧
    commandArea (optimalQ α) = 9 / (4 * (1 + α)) := by
  have hd : 1 + α ≠ 0 := by linarith
  dsimp [errorArea, commandArea, optimalQ]
  constructor
  · ring
  · field_simp
    ring

-- Article 14, Theorem 18: the old MIACE exact decomposition is reused, not reproved.
theorem optimal_cost_square {α : ℝ} (hα : 0 < α) :
    MIACE.costSq α (errorArea (optimalQ α)) (commandArea (optimalQ α)) =
      MIACE.baseSq α (9 / 4) := by
  apply (MIACE.cost_eq_iff α (9 / 4) _ _ 0 hα (by norm_num) (by norm_num)
    (by simpa using area_balance (optimalQ α))).mpr
  refine ⟨rfl, ?_⟩
  rw [(optimal_areas hα).1, (optimal_areas hα).2]
  ring

theorem optimal_cost_le {α : ℝ} (hα : 0 < α) (q : ℝ) :
    MIACE.costSq α (errorArea (optimalQ α)) (commandArea (optimalQ α)) ≤
      MIACE.costSq α (errorArea q) (commandArea q) := by
  rw [optimal_cost_square hα]
  exact MIACE.cost_lower_bound α (9 / 4) _ _ 0 hα (by norm_num) (by norm_num)
    (by simpa using area_balance q)

-- Article 14, Theorem 18: the exact ten percent IAE reduction and higher alpha=5 cost.
theorem endpoint_tradeoff :
    optimalQ 3 = 1 ∧ optimalQ 5 = 13 / 16 ∧
    errorArea (13 / 16) = 15 / 8 ∧ commandArea (13 / 16) = 3 / 8 ∧
    errorArea 1 = 27 / 16 ∧ commandArea 1 = 9 / 16 ∧
    errorArea 1 = (9 / 10) * errorArea (13 / 16) ∧
    MIACE.costSq 5 (errorArea (13 / 16)) (commandArea (13 / 16)) <
      MIACE.costSq 5 (errorArea 1) (commandArea 1) := by
  norm_num [optimalQ, errorArea, commandArea, MIACE.costSq]

-- Article 14, Theorem 18: pointwise ordering for the actual positive-filter decomposition.
theorem output_order {q₁ q₂ y z : ℝ} (hq : q₁ ≤ q₂) (hz : z ≤ y) :
    q₁ * y + (1 - q₁) * z ≤ q₂ * y + (1 - q₂) * z := by
  nlinarith [mul_nonneg (sub_nonneg.mpr hq) (sub_nonneg.mpr hz)]

end Article14.ExactDelay
