import Article14.FamilyStateMatrix
import Article14.LinearSemigroupEvolution
import Article14.FiniteStateStability
import Article14.MatrixComplexification

/-!
# Internal stability of the actual second-order shared PIDF family

The implemented four-state equations are transported through a proved
continuous state isomorphism. This preserves the full initial-state problem,
including existence and uniqueness for every initial history.
-/

namespace Article14.FamilyStability

open scoped Matrix.Norms.Operator

/-- The implemented finite-dimensional shared loop is well posed for every
initial state, independently of whether its feedback matrix is stable. -/
theorem family_shared_wellPosed (f i d K Kp T v b c : ℝ) :
    IsRetardedSharedWellPosed secondOrderOutput (secondOrderDynamics K T v)
      Kp i d f 0 b c :=
  zeroDelay_shared_wellPosed_of_linear secondOrderOutput (secondOrderDynamics K T v)
    Kp i d f b c (familyStateEquiv.conjContinuousAlgEquiv
      (familyStateOperator f i d (K*Kp) T v))
    (family_state_operator_matches f i d K Kp T v b c)

/-- An operator exponential estimate in the actual four scalar coordinates
implies the article's complete all-history internal-stability predicate. -/
theorem family_shared_stable_of_operator_bound (f i d K Kp T v b c : ℝ)
    {M α : ℝ} (hM : 0 < M) (hα : 0 < α)
    (hbound : ∀ t : ℝ, 0 ≤ t →
      ‖NormedSpace.exp (t • familyStateOperator f i d (K*Kp) T v)‖ ≤
        M * Real.exp (-α*t)) :
    IsRetardedSharedExponentiallyStable secondOrderOutput (secondOrderDynamics K T v)
      Kp i d f 0 b c :=
  zeroDelay_shared_stable_of_coordinate_exp_bound secondOrderOutput (secondOrderDynamics K T v)
    Kp i d f b c (familyStateOperator f i d (K*Kp) T v) familyStateEquiv
    (family_state_operator_matches f i d K Kp T v b c) hM hα hbound

/-- Proposition 12 for the actual shared-state implementation. The
coefficient inequality implies the full matrix spectrum is negative, which
implies an exponential estimate, which in turn proves all-history internal
exponential stability. No stability or decay conclusion is assumed. -/
theorem family_shared_internal_stability (f i d K Kp kmin T Tmax v b c : ℝ)
    (hf : 0 < f) (hi : 0 < i) (hd : 0 < d) (hkmin : 0 < kmin)
    (hfi : f ≤ i) (hC : 0 < marginC f i d) (hk : kmin ≤ K*Kp)
    (hT : 0 < T) (hTmax : T ≤ Tmax) (hv : 0 ≤ v)
    (hbound : Tmax ^ 2 < i * marginC f i d * (1 + kmin * gamma f i)) :
    IsRetardedSharedExponentiallyStable secondOrderOutput (secondOrderDynamics K T v)
      Kp i d f 0 b c := by
  have hneg : ∀ p ∈ spectrum ℂ
      (complexifyMatrix (familyStateMatrix f i d (K*Kp) T v)), p.re < 0 := by
    intro p hp
    exact family_state_mem_spectrum_re_neg f i d (K*Kp) kmin T Tmax v
      hf hi hd hkmin hfi hC hk hT hTmax hv hbound p hp
  obtain ⟨M, α, hM, hα, hdecay⟩ := FiniteStateStability.complex_matrix_exp_decay
    (complexifyMatrix (familyStateMatrix f i d (K*Kp) T v)) hneg
  apply family_shared_stable_of_operator_bound f i d K Kp T v b c hM hα
  exact realMatrixOperator_exp_bound _ M α hdecay

/-- Exact continuum internal-stability conclusion for the benchmark
controller. No grid, root solver, or sampled decay estimate enters the proof. -/
theorem benchmark_shared_internal_stability (K T ζ b c : ℝ)
    (hK : (4/5 : ℝ) ≤ K) (hT : 0 < T) (hTmax : T ≤ 12) (hζ : 0 ≤ ζ) :
    IsRetardedSharedExponentiallyStable secondOrderOutput (secondOrderDynamics K T (2*ζ*T))
      4 10 5 (6/5) 0 b c := by
  exact family_shared_internal_stability (6/5) 10 5 K 4 (16/5) T 12 (2*ζ*T) b c
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
    (by norm_num [marginC]) (by linarith) hT hTmax (by positivity)
    (by norm_num [marginC, gamma])

end Article14.FamilyStability
