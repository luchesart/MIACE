import MIACE.Transfer

/-!
# Article 14: the local DC bridge to the MIACE area theorem

This file reuses the actual integral and dominated-convergence proofs of the
companion MIACE article.  The only new plant interface is a zero-state transfer
identity valid near DC, rather than at every positive real Laplace frequency.
This permits rational plant poles away from zero.  The physical finite-state realization now supplies this interface in
`PhysicalPlant` and `PhysicalStep`, using centered locally absolutely continuous
states and a resolvent near DC. No analytic-continuation premise is needed.
-/
namespace Article14
open MeasureTheory Filter Set MIACE
open scoped Topology

/-- The zero-state relation is required only on a right neighbourhood of DC.
The two integrability fields concern ordinary, actual time signals. -/
structure LocalTransferResponse (e v H : ℝ → ℝ) (δ : ℝ) : Prop where
  error_integrable : Integrable e halfLine
  command_integrable : Integrable v halfLine
  zero_state : ∀ᶠ p in 𝓝[>] (0 : ℝ),
    laplace (fun t => 1 - e t) p =
      H p * Real.exp (-δ * p) * laplace (fun t => 1 + v t) p

/-- Reciprocal of the delayed plant, where H is normalized to unit DC gain. -/
noncomputable def inverseDelayedPlant (H : ℝ → ℝ) (k δ : ℝ) (p : ℝ) : ℝ :=
  1 / (k * (H p * Real.exp (-δ * p)))

-- Article 14, Propositions 15 and 17: the reciprocal delayed plant has the
-- expected DC value; this links the two local-transfer interfaces explicitly.
theorem inverseDelayedPlant_zero {H : ℝ → ℝ} (k δ : ℝ) (h0 : H 0 = 1) :
    inverseDelayedPlant H k δ 0 = 1 / k := by
  simp [inverseDelayedPlant, h0]

-- Article 14, Propositions 15 and 17: exact first derivative of the inverse
-- delayed plant, using the same Γ = μ + δ as the signed-area balance.
theorem inverseDelayedPlant_derivative {H : ℝ → ℝ} (k μ δ : ℝ)
    (hk : k ≠ 0) (hH : HasDerivAt H (-μ) 0) (h0 : H 0 = 1) :
    HasDerivAt (inverseDelayedPlant H k δ) ((μ + δ) / k) 0 := by
  have hd := (hasDerivAt_const (0 : ℝ) (1 : ℝ)).div
    ((transfer_delay_derivative μ δ hH h0).const_mul k) (by simpa [h0] using hk)
  convert hd using 1
  · rfl
  · simp only [h0, mul_zero, Real.exp_zero, mul_one, zero_mul, sub_neg_eq_add,
      zero_add, mul_neg]
    field_simp

-- Article 14, Theorem 17: the old global transfer semantics supplies the new
-- local interface without any additional condition.
theorem localTransfer_of_transfer {e v H : ℝ → ℝ} {δ : ℝ}
    (h : TransferResponse e v H δ) : LocalTransferResponse e v H δ := by
  refine ⟨h.error_integrable, h.command_integrable, ?_⟩
  filter_upwards [self_mem_nhdsWithin] with p hp
  exact h.zero_state p hp

-- Article 14, Theorem 17: clearing a denominator near DC is sound whenever
-- it is continuous and nonzero there.  This does not assert that a physical
-- delay equation has already supplied the cleared identity.
theorem localTransfer_of_cleared_identity {e v A B : ℝ → ℝ} {δ : ℝ}
    (he : Integrable e halfLine) (hv : Integrable v halfLine)
    (hA : ContinuousAt A 0) (hA0 : A 0 ≠ 0)
    (hzero : ∀ᶠ p in 𝓝[>] (0 : ℝ),
      A p * laplace (fun t => 1 - e t) p =
        B p * Real.exp (-δ * p) * laplace (fun t => 1 + v t) p) :
    LocalTransferResponse e v (fun p => B p / A p) δ := by
  refine ⟨he, hv, ?_⟩
  have hne : ∀ᶠ p in 𝓝[>] (0 : ℝ), A p ≠ 0 :=
    (hA.eventually_ne hA0).filter_mono nhdsWithin_le_nhds
  filter_upwards [hzero, hne] with p hp hAp
  apply (mul_left_cancel₀ hAp)
  calc
    A p * laplace (fun t => 1 - e t) p =
        B p * Real.exp (-δ * p) * laplace (fun t => 1 + v t) p := hp
    _ = A p * ((B p / A p) * Real.exp (-δ * p) *
        laplace (fun t => 1 + v t) p) := by field_simp

-- Article 14, Theorem 17: derive the centered identity from the step and
-- command transforms; no signed-area balance is assumed.
theorem local_transfer_error_identity {e v H : ℝ → ℝ} {δ : ℝ}
    (h : LocalTransferResponse e v H δ) :
    ∀ᶠ p in 𝓝[>] (0 : ℝ),
      laplace e p = (1 - H p * Real.exp (-δ * p)) / p -
        H p * Real.exp (-δ * p) * laplace v p := by
  filter_upwards [h.zero_state, self_mem_nhdsWithin] with p hz hp
  have hp' : 0 < p := hp
  have hconst : Integrable (fun t : ℝ => Real.exp (-p * t)) halfLine :=
    integrableOn_exp_mul_Ioi (by linarith : -p < 0) 0
  have he := laplace_integrable h.error_integrable hp'.le
  have hv := laplace_integrable h.command_integrable hp'.le
  have hy : laplace (fun t => 1 - e t) p = 1 / p - laplace e p := by
    unfold laplace
    simp_rw [mul_sub, mul_one]
    rw [integral_sub hconst he]
    have hs := laplace_step p hp'
    simpa [laplace] using
      congrArg (fun a => a - ∫ t, Real.exp (-p * t) * e t ∂halfLine) hs
  have hw : laplace (fun t => 1 + v t) p = 1 / p + laplace v p := by
    unfold laplace
    simp_rw [mul_add, mul_one]
    rw [integral_add hconst hv]
    have hs := laplace_step p hp'
    simpa [laplace] using
      congrArg (fun a => a + ∫ t, Real.exp (-p * t) * v t ∂halfLine) hs
  rw [hy, hw] at hz
  calc
    laplace e p = 1 / p - H p * Real.exp (-δ * p) *
        (1 / p + laplace v p) := by linarith
    _ = _ := by ring

-- Article 14, Theorem 17: the signed balance is a conclusion of local
-- transfer semantics, differentiability at DC and dominated convergence.
theorem local_transfer_signed_balance {e v H : ℝ → ℝ} {δ : ℝ}
    (h : LocalTransferResponse e v H δ) (μ : ℝ)
    (hH : HasDerivAt H (-μ) 0) (h0 : H 0 = 1) :
    (∫ t, e t ∂halfLine) + (∫ t, v t ∂halfLine) = μ + δ := by
  have hd := transfer_delay_derivative μ δ hH h0
  have hs : Tendsto (fun p => (1 - H p * Real.exp (-δ * p)) / p)
      (𝓝[>] (0 : ℝ)) (𝓝 (μ + δ)) := by
    have hh := hd.tendsto_slope_zero_right.neg
    convert hh using 1
    · funext p
      simp [h0, smul_eq_mul]
      ring
    · simp
  have hprod : Tendsto (fun p => H p * Real.exp (-δ * p))
      (𝓝[>] (0 : ℝ)) (𝓝 1) := by
    simpa [h0] using hd.continuousAt.tendsto.mono_left
      (nhdsWithin_le_nhds : 𝓝[>] (0 : ℝ) ≤ 𝓝 0)
  have hr := hs.sub (hprod.mul (laplace_tendsto_zero h.command_integrable))
  have heq : laplace e =ᶠ[𝓝[>] (0 : ℝ)]
      (fun p => (1 - H p * Real.exp (-δ * p)) / p -
        H p * Real.exp (-δ * p) * laplace v p) := local_transfer_error_identity h
  have hi := tendsto_nhds_unique (laplace_tendsto_zero h.error_integrable)
    (hr.congr' heq.symm)
  linarith

-- Article 14, Theorem 17: exact integral gap.  All absolute/negative areas
-- refer to the supplied signals; the old signal_excess proof is reused.
theorem local_transfer_miace_gap {e v H : ℝ → ℝ} {δ : ℝ}
    (h : LocalTransferResponse e v H δ) (α μ : ℝ) (hα : 0 < α)
    (hH : HasDerivAt H (-μ) 0) (h0 : H 0 = 1) :
    (miace α e v halfLine) ^ 2 - α * (μ + δ) ^ 2 / (1 + α) =
      4 * α / (1 + α) * (negArea e halfLine + negArea v halfLine) *
        (μ + δ + (negArea e halfLine + negArea v halfLine)) +
      (absArea e halfLine - α * absArea v halfLine) ^ 2 / (1 + α) := by
  rw [miace_square α e v halfLine hα]
  have hi := signal_excess h.error_integrable h.command_integrable α (μ + δ) hα
    (local_transfer_signed_balance h μ hH h0)
  convert hi using 1
  unfold baseSq
  ring

-- Article 14, Theorem 17: the universal MIACE lower bound for local plant
-- semantics, including plants whose poles need not lie in the left half-plane.
theorem local_transfer_miace_lower_bound {e v H : ℝ → ℝ} {δ : ℝ}
    (h : LocalTransferResponse e v H δ) (α μ : ℝ) (hα : 0 < α)
    (hΓ : 0 ≤ μ + δ) (hH : HasDerivAt H (-μ) 0) (h0 : H 0 = 1) :
    (μ + δ) * Real.sqrt (α / (1 + α)) ≤ miace α e v halfLine :=
  signal_miace_lower_bound h.error_integrable h.command_integrable α (μ + δ)
    hα hΓ (local_transfer_signed_balance h μ hH h0)

-- Article 14, Theorem 17: equality requires BOTH actual error and command
-- positivity, as well as the optimal area ratio; monotone output alone is
-- not silently substituted for command positivity.
theorem local_transfer_miace_equality_iff {e v H : ℝ → ℝ} {δ : ℝ}
    (h : LocalTransferResponse e v H δ) (α μ : ℝ) (hα : 0 < α)
    (hΓ : 0 < μ + δ) (hH : HasDerivAt H (-μ) 0) (h0 : H 0 = 1) :
    miace α e v halfLine = (μ + δ) * Real.sqrt (α / (1 + α)) ↔
      (∀ᵐ t ∂halfLine, 0 ≤ e t) ∧ (∀ᵐ t ∂halfLine, 0 ≤ v t) ∧
      absArea e halfLine = α * absArea v halfLine :=
  signal_miace_equality_iff h.error_integrable h.command_integrable α (μ + δ)
    hα hΓ (local_transfer_signed_balance h μ hH h0)

end Article14
