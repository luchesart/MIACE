import Article14.SettlingOptimization

/-!
# Settling of actual affine L¹ kernel families

The kernel is an element of the real L¹ space used by the physical
construction.  Its step response is the actual cumulative integral.  In
particular the optimization below does not assume continuity of settling
time itself.
-/
namespace Article14
open MeasureTheory Filter Set MIACE
open scoped Topology

/-- Cumulative output of an actual L¹ kernel. -/
noncomputable def l1KernelStep (g : RealL1) : ℝ → ℝ :=
  kernelStep (fun t => g t)

theorem l1KernelStep_add (g h : RealL1) (t : ℝ) :
    l1KernelStep (g + h) t = l1KernelStep g t + l1KernelStep h t := by
  unfold l1KernelStep kernelStep
  rw [integral_congr_ae (ae_restrict_of_ae (Lp.coeFn_add g h))]
  exact integral_add (L1.integrable_coeFn g).integrableOn
    (L1.integrable_coeFn h).integrableOn

theorem l1KernelStep_smul (a : ℝ) (g : RealL1) (t : ℝ) :
    l1KernelStep (a • g) t = a * l1KernelStep g t := by
  unfold l1KernelStep kernelStep
  rw [integral_congr_ae (ae_restrict_of_ae (Lp.coeFn_smul a g))]
  exact integral_const_mul a _

theorem l1KernelStep_linear_directions (g₀ : RealL1)
    (G : (ℝ × ℝ) →L[ℝ] RealL1) (w : ℝ × ℝ) (t : ℝ) :
    l1KernelStep (g₀ + G w) t = l1KernelStep g₀ t +
      w.1 * l1KernelStep (G (1,0)) t + w.2 * l1KernelStep (G (0,1)) t := by
  have hw : w = w.1 • (1,0) + w.2 • (0,1) := by ext <;> simp
  have hG : G w = w.1 • G (1,0) + w.2 • G (0,1) := by
    conv_lhs => rw [hw, map_add, map_smul, map_smul]
  rw [hG, l1KernelStep_add, l1KernelStep_add, l1KernelStep_smul, l1KernelStep_smul]
  ring

theorem l1KernelStep_continuous (g : RealL1) : Continuous (l1KernelStep g) :=
  kernel_step_continuous (L1.integrable_coeFn g)

-- Joint continuity is proved from the finite-dimensional affine structure.
theorem l1KernelStep_joint_continuous (g₀ : RealL1)
    (G : (ℝ × ℝ) →L[ℝ] RealL1) :
    Continuous (fun p : (ℝ × ℝ) × ℝ => l1KernelStep (g₀ + G p.1) p.2) := by
  simp_rw [l1KernelStep_linear_directions]
  exact (((l1KernelStep_continuous g₀).comp continuous_snd).add
    (continuous_fst.fst.mul
      ((l1KernelStep_continuous (G (1,0))).comp continuous_snd))).add
    (continuous_fst.snd.mul
      ((l1KernelStep_continuous (G (0,1))).comp continuous_snd))

-- The horizon constraint remains an exact halfspace in the original weights.
theorem l1KernelStep_horizon_convex (g₀ : RealL1)
    (G : (ℝ × ℝ) →L[ℝ] RealL1) (H threshold : ℝ) :
    Convex ℝ {w : ℝ × ℝ | threshold ≤ l1KernelStep (g₀ + G w) H} := by
  intro x hx y hy a b ha hb hab
  have he : l1KernelStep (g₀ + G (a • x + b • y)) H =
      a * l1KernelStep (g₀ + G x) H + b * l1KernelStep (g₀ + G y) H := by
    simp only [l1KernelStep_linear_directions, Prod.fst_add, Prod.smul_fst,
      Prod.snd_add, Prod.smul_snd, smul_eq_mul]
    calc
      _ = (a+b) * l1KernelStep g₀ H +
          (a*x.1+b*y.1)*l1KernelStep (G (1,0)) H +
          (a*x.2+b*y.2)*l1KernelStep (G (0,1)) H := by rw [hab, one_mul]
      _ = _ := by ring
  change threshold ≤ _
  rw [he]
  calc
    threshold = a*threshold+b*threshold := by rw [← add_mul, hab, one_mul]
    _ ≤ _ := add_le_add (mul_le_mul_of_nonneg_left hx ha)
      (mul_le_mul_of_nonneg_left hy hb)

theorem l1KernelStep_horizon_closed (g₀ : RealL1)
    (G : (ℝ × ℝ) →L[ℝ] RealL1) (H threshold : ℝ) :
    IsClosed {w : ℝ × ℝ | threshold ≤ l1KernelStep (g₀ + G w) H} := by
  exact isClosed_le continuous_const
    ((l1KernelStep_joint_continuous g₀ G).comp (continuous_id.prodMk continuous_const))

-- This directly applies to physical kernelBase + kernelDirections w.
theorem l1_kernel_minimum_settlingTime_exists
    {X : Set (ℝ × ℝ)} (hX : IsClosed X)
    (g₀ : RealL1) (G : (ℝ × ℝ) →L[ℝ] RealL1) (hG : Function.Injective G)
    (hmass : ∀ w ∈ kernelFeasible X g₀ G, (∫ t, (g₀ + G w) t) = 1)
    (hne : (kernelFeasible X g₀ G).Nonempty) {ε : ℝ} (hε : 0 < ε) :
    ∃ w ∈ kernelFeasible X g₀ G,
      0 ≤ settlingTime (l1KernelStep (g₀ + G w)) ε ∧
      SettledBy (l1KernelStep (g₀ + G w)) ε
        (settlingTime (l1KernelStep (g₀ + G w)) ε) ∧
      ∀ z ∈ kernelFeasible X g₀ G,
        settlingTime (l1KernelStep (g₀ + G w)) ε ≤
          settlingTime (l1KernelStep (g₀ + G z)) ε := by
  apply minimum_settlingTime_exists (kernelFeasible_compact hX g₀ G hG hmass)
    hne (fun w => l1KernelStep (g₀ + G w)) (l1KernelStep_joint_continuous g₀ G)
    ?_ ?_ ?_ hε
  · intro w hw
    exact positive_kernel_step_monotone (L1.integrable_coeFn _)
      ((Lp.coeFn_nonneg _).mpr hw.2)
  · intro w hw t
    exact (positive_kernel_step_bounds (L1.integrable_coeFn _)
      ((Lp.coeFn_nonneg _).mpr hw.2) (hmass w hw) t).2
  · intro w hw
    exact unit_mass_kernel_step_tendsto_one (L1.integrable_coeFn _) (hmass w hw)

theorem l1_kernel_settlingTime_le_iff {X : Set (ℝ × ℝ)}
    {g₀ : RealL1} {G : (ℝ × ℝ) →L[ℝ] RealL1}
    {w : ℝ × ℝ} (hw : w ∈ kernelFeasible X g₀ G)
    (hmass : (∫ t, (g₀ + G w) t) = 1)
    {ε : ℝ} (hε : 0 < ε) {H : ℝ} (hH : 0 ≤ H) :
    settlingTime (l1KernelStep (g₀ + G w)) ε ≤ H ↔
      1 - ε ≤ l1KernelStep g₀ H + w.1 * l1KernelStep (G (1,0)) H +
        w.2 * l1KernelStep (G (0,1)) H := by
  rw [settlingTime_le_iff (l1KernelStep_continuous _)
    (positive_kernel_step_monotone (L1.integrable_coeFn _) ((Lp.coeFn_nonneg _).mpr hw.2))
    (fun t => (positive_kernel_step_bounds (L1.integrable_coeFn _)
      ((Lp.coeFn_nonneg _).mpr hw.2) hmass t).2)
    (unit_mass_kernel_step_tendsto_one (L1.integrable_coeFn _) hmass) hε hH]
  rw [l1KernelStep_linear_directions]

theorem l1_kernel_settlingTime_quasiconvex {X : Set (ℝ × ℝ)}
    (hX : Convex ℝ X) (g₀ : RealL1) (G : (ℝ × ℝ) →L[ℝ] RealL1)
    (hmass : ∀ w ∈ kernelFeasible X g₀ G, (∫ t, (g₀ + G w) t) = 1)
    {ε : ℝ} (hε : 0 < ε) :
    QuasiconvexOn ℝ (kernelFeasible X g₀ G)
      (fun w => settlingTime (l1KernelStep (g₀ + G w)) ε) := by
  intro H
  by_cases hH : 0 ≤ H
  · have he : {w ∈ kernelFeasible X g₀ G |
        settlingTime (l1KernelStep (g₀ + G w)) ε ≤ H} =
        kernelFeasible X g₀ G ∩ {w | 1 - ε ≤ l1KernelStep (g₀ + G w) H} := by
      ext w
      by_cases hw : w ∈ kernelFeasible X g₀ G
      · simp only [mem_ofPred_eq, mem_inter_iff, hw, true_and]
        rw [l1_kernel_settlingTime_le_iff hw (hmass w hw) hε hH,
          l1KernelStep_linear_directions]
      · simp only [mem_ofPred_eq, mem_inter_iff, hw, false_and]
    rw [he]
    exact (kernelFeasible_convex hX g₀ G).inter (l1KernelStep_horizon_convex g₀ G H (1-ε))
  · have he : {w ∈ kernelFeasible X g₀ G |
        settlingTime (l1KernelStep (g₀ + G w)) ε ≤ H} = ∅ := by
      apply Set.eq_empty_iff_forall_notMem.mpr
      intro w hw
      have ha := settlingTime_attained (l1KernelStep_continuous (g₀ + G w))
        (positive_kernel_step_monotone (L1.integrable_coeFn _) ((Lp.coeFn_nonneg _).mpr hw.1.2))
        (fun t => (positive_kernel_step_bounds (L1.integrable_coeFn _)
          ((Lp.coeFn_nonneg _).mpr hw.1.2) (hmass w hw.1) t).2)
        (unit_mass_kernel_step_tendsto_one (L1.integrable_coeFn _) (hmass w hw.1)) hε
      exact hH (ha.1.trans hw.2)
    rw [he]
    exact convex_empty

end Article14
