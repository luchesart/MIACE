import Article14.PIDFAlgebra
import Mathlib.FieldTheory.RatFunc.Basic
import Mathlib.Algebra.Polynomial.Div
import Mathlib.Algebra.Polynomial.Degree.IsMonicOfDegree
import Mathlib.Analysis.Complex.Polynomial.Basic

/-!
# Article 14: cancellation in the actual reduced rational transfer

`referenceRational R N q h` is the fraction `(R*N)/(q*h)` in `RatFunc ℝ`.
Cancellation is expressed by coprimality of the selected factor `q` and the
canonical reduced denominator. Thus the criterion below is not merely a
coefficient identity and does not assert deletion of an internal state.
-/

namespace Article14
open Polynomial

noncomputable def referenceRational (R N q h : Polynomial ℝ) : RatFunc ℝ :=
  algebraMap (Polynomial ℝ) (RatFunc ℝ) (R*N) /
    algebraMap (Polynomial ℝ) (RatFunc ℝ) (q*h)

/-- None of the selected complex roots remains a root of the canonical reduced
denominator. For a reduced rational transfer this says that the selected poles
are absent from that external channel. -/
def NoSelectedReferencePoles (R N q h : Polynomial ℝ) : Prop :=
  ∀ z : ℂ, aeval z q=0 → aeval z (referenceRational R N q h).denom≠0

theorem noSelectedReferencePoles_iff_coprime (R N q h : Polynomial ℝ) :
    NoSelectedReferencePoles R N q h ↔ IsCoprime q (referenceRational R N q h).denom := by
  rw [Polynomial.isCoprime_iff_aeval_ne_zero_of_isAlgClosed ℝ ℂ q
    (referenceRational R N q h).denom]
  constructor
  · intro hn z
    by_cases hz : aeval z q=0
    · exact Or.inr (hn z hz)
    · exact Or.inl hz
  · intro hn z hz
    exact (hn z).resolve_left (by simpa using hz)

-- Removing the complete selected factor from the canonical reduced
-- denominator is exactly divisibility of the reference numerator.
theorem reduced_denominator_coprime_iff (R N q h : Polynomial ℝ)
    (hq : q≠0) (hh : h≠0) (hR : IsCoprime q R) (hqh : IsCoprime q h) :
    IsCoprime q (referenceRational R N q h).denom ↔ q∣N := by
  let T := referenceRational R N q h
  change IsCoprime q T.denom ↔ q∣N
  constructor
  · intro hc
    have hcross : T.num*(q*h)=(R*N)*T.denom :=
      (RatFunc.num_mul_eq_mul_denom_iff (mul_ne_zero hq hh)).mpr rfl
    have hdiv : q∣(R*N)*T.denom := by
      rw [←hcross]
      exact dvd_mul_of_dvd_right (dvd_mul_right q h) T.num
    exact hR.dvd_of_dvd_mul_left (hc.dvd_of_dvd_mul_right hdiv)
  · rintro ⟨m, hN⟩
    have hT : T=algebraMap (Polynomial ℝ) (RatFunc ℝ) (R*m) /
        algebraMap (Polynomial ℝ) (RatFunc ℝ) h := by
      dsimp [T, referenceRational]
      rw [hN, show R*(q*m)=q*(R*m) by ring]
      simp only [map_mul]
      exact mul_div_mul_left _ _ (RatFunc.algebraMap_ne_zero hq)
    apply hqh.of_isCoprime_of_dvd_right
    rw [hT]
    exact RatFunc.denom_div_dvd _ _

theorem normalized_divisibility_iff (N q : Polynomial ℝ) (hq : q.Monic)
    (hdeg : N.natDegree≤q.natDegree) (hN0 : N.eval 0=1) (hq0 : q.eval 0≠0) :
    q∣N ↔ N=C (1/q.eval 0)*q := by
  constructor
  · intro hdiv
    have hfactor := Polynomial.eq_leadingCoeff_mul_of_monic_of_dvd_of_natDegree_le
      hq hdiv hdeg
    have hzero := congrArg (Polynomial.eval 0) hfactor
    simp only [eval_mul, eval_C, hN0] at hzero
    have hlead : N.leadingCoeff=1/q.eval 0 := (eq_div_iff hq0).mpr hzero.symm
    simpa only [hlead] using hfactor
  · intro h
    rw [h]
    exact dvd_mul_left q (C (1/q.eval 0))

-- Article 14, Theorem 6: actual reduced-denominator cancellation iff the
-- normalized quadratic is assigned. Monicity and the degree bound generalize
-- the statement to any selected monic factor of the same maximal degree.
-- @paper-step thm:cancellation/reduced-transfer-normalized-factor-iff
theorem paper_reference_cancellation (R N q h : Polynomial ℝ)
    (hq : q.Monic) (hh : h≠0) (hR : IsCoprime q R) (hqh : IsCoprime q h)
    (hdeg : N.natDegree≤q.natDegree) (hN0 : N.eval 0=1) (hq0 : q.eval 0≠0) :
    IsCoprime q (referenceRational R N q h).denom ↔ N=C (1/q.eval 0)*q := by
  rw [reduced_denominator_coprime_iff R N q h hq.ne_zero hh hR hqh]
  exact normalized_divisibility_iff N q hq hdeg hN0 hq0

noncomputable def selectedQuadratic (a1 a0 : ℝ) : Polynomial ℝ :=
  X^2+C a1*X+C a0

theorem selectedQuadratic_monic_degree (a1 a0 : ℝ) :
    (selectedQuadratic a1 a0).Monic ∧ (selectedQuadratic a1 a0).natDegree=2 := by
  have h := Polynomial.isMonicOfDegree_add_add_two a1 a0
  exact ⟨h.monic, h.natDegree_eq⟩

theorem referenceQuadratic_degree_le_two (σ π : ℝ) :
    (referenceQuadratic σ π).natDegree≤2 := by
  unfold referenceQuadratic
  apply natDegree_add_le_of_degree_le
  · apply natDegree_add_le_of_degree_le
    · simp
    · exact (natDegree_C_mul_le _ _).trans (by simp)
  · exact (natDegree_C_mul_le _ _).trans (by simp)

theorem selectedQuadratic_normalization (a1 a0 : ℝ) (ha0 : a0≠0) :
    C (1/a0)*selectedQuadratic a1 a0=referenceQuadratic (a1/a0) (1/a0) := by
  have hc : C (1/a0)*C a0=(1 : Polynomial ℝ) := by
    rw [←C_mul]
    simp [ha0]
  have hl : C (1/a0)*C a1=C (a1/a0) := by
    rw [←C_mul]
    congr 1
    ring
  calc
    C (1/a0)*selectedQuadratic a1 a0=
        C (1/a0)*X^2+(C (1/a0)*C a1)*X+C (1/a0)*C a0 := by
      unfold selectedQuadratic
      ring
    _ = referenceQuadratic (a1/a0) (1/a0) := by
      rw [hc, hl]
      unfold referenceQuadratic
      ring

-- Actual reduced rational transfer of the filtered-D reference numerator.
-- This instantiates the general cancellation criterion at degree two.
-- @paper-step thm:cancellation/actual-PIDF-quadratic-cancellation
theorem dReference_cancellation_iff (R h : Polynomial ℝ)
    (Ti Td Tf b c a1 a0 : ℝ) (hh : h≠0) (ha0 : a0≠0)
    (hR : IsCoprime (selectedQuadratic a1 a0) R)
    (hqh : IsCoprime (selectedQuadratic a1 a0) h) :
    IsCoprime (selectedQuadratic a1 a0)
      (referenceRational R (referenceQuadratic (Tf+b*Ti) (Ti*(b*Tf+c*Td)))
        (selectedQuadratic a1 a0) h).denom ↔
      referenceQuadratic (Tf+b*Ti) (Ti*(b*Tf+c*Td))=
        referenceQuadratic (a1/a0) (1/a0) := by
  have hq := selectedQuadratic_monic_degree a1 a0
  rw [paper_reference_cancellation R _ _ h hq.1 hh hR hqh]
  · have hq0 : (selectedQuadratic a1 a0).eval 0=a0 := by simp [selectedQuadratic]
    rw [hq0, selectedQuadratic_normalization a1 a0 ha0]
  · rw [hq.2]
    exact referenceQuadratic_degree_le_two _ _
  · simp [referenceQuadratic]
  · simpa [selectedQuadratic] using ha0

-- @paper-step thm:cancellation/complex-roots-absent-iff-normalized-quadratic
theorem paper_exact_reference_cancellation (R h : Polynomial ℝ)
    (Ti Td Tf b c a1 a0 : ℝ) (hh : h≠0) (ha0 : 0<a0)
    (hcop : IsCoprime (selectedQuadratic a1 a0) (R*h)) :
    NoSelectedReferencePoles R
        (referenceQuadratic (Tf+b*Ti) (Ti*(b*Tf+c*Td)))
        (selectedQuadratic a1 a0) h ↔
      referenceQuadratic (Tf+b*Ti) (Ti*(b*Tf+c*Td))=
        referenceQuadratic (a1/a0) (1/a0) := by
  rw [noSelectedReferencePoles_iff_coprime]
  exact dReference_cancellation_iff R h Ti Td Tf b c a1 a0 hh ha0.ne'
    hcop.of_mul_right_left hcop.of_mul_right_right

-- @paper-step thm:cancellation/bounded-weight-feasibility-iff
theorem paper_exact_cancellation_feasibility (R h : Polynomial ℝ)
    (Ti Td Tf a1 a0 bl bu cl cu : ℝ) (hh : h≠0) (ha0 : 0<a0)
    (hi : 0<Ti) (hd : 0<Td)
    (hcop : IsCoprime (selectedQuadratic a1 a0) (R*h)) :
    (∃ b ∈ Set.Icc bl bu, ∃ c ∈ Set.Icc cl cu,
      NoSelectedReferencePoles R
        (referenceQuadratic (Tf+b*Ti) (Ti*(b*Tf+c*Td)))
        (selectedQuadratic a1 a0) h) ↔
      (Tf+Ti*bl≤a1/a0 ∧ a1/a0≤Tf+Ti*bu) ∧
      (Ti*Td*cl+Tf*(a1/a0-Tf)≤1/a0 ∧
        1/a0≤Ti*Td*cu+Tf*(a1/a0-Tf)) := by
  have hpoint (b c : ℝ) : NoSelectedReferencePoles R
      (referenceQuadratic (Tf+b*Ti) (Ti*(b*Tf+c*Td)))
      (selectedQuadratic a1 a0) h ↔
      dCoefficients Ti Td Tf b c=(a1/a0,1/a0) := by
    rw [paper_exact_reference_cancellation R h Ti Td Tf b c a1 a0 hh ha0 hcop]
    exact referenceQuadratic_eq_iff _ _ _ _
  simp_rw [hpoint]
  exact dAssignment_exists_iff Ti Td Tf (a1/a0) (1/a0) bl bu cl cu hi hd

end Article14
