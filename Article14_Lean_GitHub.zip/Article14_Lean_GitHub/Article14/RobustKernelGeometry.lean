import Article14.FeasibleGeometry
import Article14.TrackingMoments

/-!
# Robust positivity and worst mean time

The robust extension following Theorem 14 requires positivity for every
member of a declared plant family. Arbitrary intersections preserve closedness
and convexity. One compact member already bounds the entire intersection.
For a nonempty plant family with finite supremum of the gain-dependent
offsets, the worst mean time is an affine decreasing function of `b`.
-/

namespace Article14

open Set MeasureTheory
open scoped Topology

/-- A closed intersection contained in one compact member is compact.
The family index need not be finite. -/
theorem robust_intersection_compact {ι : Type*} (F : ι → Set (ℝ × ℝ))
    (hclosed : ∀ θ, IsClosed (F θ)) (θ₀ : ι) (hcompact : IsCompact (F θ₀)) :
    IsCompact (⋂ θ, F θ) :=
  hcompact.of_isClosed_subset (isClosed_iInter hclosed) (iInter_subset F θ₀)

/-- Actual robust positivity is membership in every member's genuine L¹
positive-kernel feasible set. -/
noncomputable def robustKernelFeasible {ι : Type*} (X : Set (ℝ × ℝ))
    (g₀ : ι → MIACE.RealL1)
    (G : ι → (ℝ × ℝ) →L[ℝ] MIACE.RealL1) : Set (ℝ × ℝ) :=
  ⋂ θ, kernelFeasible X (g₀ θ) (G θ)

theorem mem_robustKernelFeasible_iff {ι : Type*} {X : Set (ℝ × ℝ)}
    {g₀ : ι → MIACE.RealL1} {G : ι → (ℝ × ℝ) →L[ℝ] MIACE.RealL1}
    {w : ℝ × ℝ} :
    w ∈ robustKernelFeasible X g₀ G ↔ ∀ θ, w ∈ kernelFeasible X (g₀ θ) (G θ) :=
  mem_iInter

theorem robustKernelFeasible_closed {ι : Type*} {X : Set (ℝ × ℝ)}
    (hX : IsClosed X) (g₀ : ι → MIACE.RealL1)
    (G : ι → (ℝ × ℝ) →L[ℝ] MIACE.RealL1) :
    IsClosed (robustKernelFeasible X g₀ G) :=
  isClosed_iInter (fun θ => kernelFeasible_closed hX (g₀ θ) (G θ))

theorem robustKernelFeasible_convex {ι : Type*} {X : Set (ℝ × ℝ)}
    (hX : Convex ℝ X) (g₀ : ι → MIACE.RealL1)
    (G : ι → (ℝ × ℝ) →L[ℝ] MIACE.RealL1) :
    Convex ℝ (robustKernelFeasible X g₀ G) :=
  convex_iInter (fun θ => kernelFeasible_convex hX (g₀ θ) (G θ))

/-- Compactness of the robust feasible set follows from a single injective
member with unit kernel mass, without a bounded engineering set `X`. -/
theorem robustKernelFeasible_compact {ι : Type*} {X : Set (ℝ × ℝ)}
    (hX : IsClosed X) (g₀ : ι → MIACE.RealL1)
    (G : ι → (ℝ × ℝ) →L[ℝ] MIACE.RealL1) (θ₀ : ι)
    (hG : Function.Injective (G θ₀))
    (hmass : ∀ w ∈ kernelFeasible X (g₀ θ₀) (G θ₀),
      (∫ t, (g₀ θ₀ + G θ₀ w) t) = 1) :
    IsCompact (robustKernelFeasible X g₀ G) :=
  robust_intersection_compact _ (fun θ => kernelFeasible_closed hX (g₀ θ) (G θ))
    θ₀ (kernelFeasible_compact hX (g₀ θ₀) (G θ₀) hG hmass)

/-- The supremum is a real number only under the bounded-offset hypothesis
used in the subsequent theorems. -/
noncomputable def robustWorstMean {ι : Type*} (offset : ι → ℝ) (Ti b : ℝ) : ℝ :=
  ⨆ θ, offset θ - Ti * b

/-- Translation by the common reference-weight term commutes with a finite
supremum over a nonempty, possibly infinite plant family. -/
theorem robustWorstMean_eq {ι : Type*} [Nonempty ι] (offset : ι → ℝ)
    (hbounded : BddAbove (range offset)) (Ti b : ℝ) :
    robustWorstMean offset Ti b = (⨆ θ, offset θ) - Ti * b := by
  have hshift : BddAbove (range (fun θ => offset θ - Ti * b)) := by
    obtain ⟨M, hM⟩ := hbounded
    refine ⟨M - Ti * b, ?_⟩
    rintro _ ⟨θ, rfl⟩
    exact sub_le_sub_right (hM (mem_range_self θ)) _
  apply le_antisymm
  · exact ciSup_le (fun θ => sub_le_sub_right (le_ciSup hbounded θ) _)
  · have h : (⨆ θ, offset θ) ≤ robustWorstMean offset Ti b + Ti * b := by
      apply ciSup_le
      intro θ
      have hθ := le_ciSup hshift θ
      change offset θ - Ti * b ≤ robustWorstMean offset Ti b at hθ
      linarith
    linarith

/-- Increasing `b` decreases the worst mean time for a fixed positive `Ti`. -/
theorem robustWorstMean_antitone {ι : Type*} [Nonempty ι] (offset : ι → ℝ)
    (hbounded : BddAbove (range offset)) {Ti : ℝ} (hTi : 0 ≤ Ti) :
    Antitone (robustWorstMean offset Ti) := by
  intro b₁ b₂ hb
  rw [robustWorstMean_eq offset hbounded, robustWorstMean_eq offset hbounded]
  exact sub_le_sub_left (mul_le_mul_of_nonneg_left hb hTi) _

/-- Strict positivity of `Ti` makes minimizing the worst mean exactly
equivalent to maximizing `b`, not merely a sufficient choice. -/
theorem robustWorstMean_le_iff {ι : Type*} [Nonempty ι] (offset : ι → ℝ)
    (hbounded : BddAbove (range offset)) {Ti b₁ b₂ : ℝ} (hTi : 0 < Ti) :
    robustWorstMean offset Ti b₁ ≤ robustWorstMean offset Ti b₂ ↔ b₂ ≤ b₁ := by
  rw [robustWorstMean_eq offset hbounded, robustWorstMean_eq offset hbounded]
  exact (sub_le_sub_iff_left _).trans (mul_le_mul_iff_right₀ hTi)

/-- Compact robust feasibility gives a largest feasible `b` and therefore
attains the smallest worst mean time. -/
theorem robust_minimum_worstMean_exists {ι : Type*} [Nonempty ι]
    {F : Set (ℝ × ℝ)} (hF : IsCompact F) (hne : F.Nonempty)
    (offset : ι → ℝ) (hbounded : BddAbove (range offset))
    {Ti : ℝ} (hTi : 0 < Ti) :
    ∃ w ∈ F, (∀ z ∈ F, z.1 ≤ w.1) ∧
      (∀ z ∈ F, robustWorstMean offset Ti w.1 ≤ robustWorstMean offset Ti z.1) := by
  obtain ⟨w, hw, hmax⟩ := hF.exists_isMaxOn hne continuous_fst.continuousOn
  exact ⟨w, hw, hmax, fun z hz =>
    robustWorstMean_antitone offset hbounded hTi.le (hmax hz)⟩

/-- The physical PIDF mean has precisely the common-slope form needed by
the robust minimax reduction. -/
theorem meanTime_eq_gain_offset (Ti k Kp b : ℝ) :
    meanTime Ti k Kp b = Ti * (1 + 1 / (k * Kp)) - Ti * b := by
  unfold meanTime
  ring

/-- Family version expressed directly with the physical tracking mean. -/
theorem robust_physical_mean_sup {ι : Type*} [Nonempty ι]
    (k : ι → ℝ) (Ti Kp b : ℝ)
    (hbounded : BddAbove (range (fun θ => Ti * (1 + 1 / (k θ * Kp))))) :
    (⨆ θ, meanTime Ti (k θ) Kp b) =
      (⨆ θ, Ti * (1 + 1 / (k θ * Kp))) - Ti * b := by
  simp_rw [meanTime_eq_gain_offset]
  exact robustWorstMean_eq _ hbounded Ti b

/-- Full robust positive-kernel optimization wrapper: positivity is enforced
for every plant and compactness is proved from one actual kernel map. -/
theorem robustKernelFeasible_minimum_worstMean_exists {ι : Type*} [Nonempty ι]
    {X : Set (ℝ × ℝ)} (hX : IsClosed X)
    (g₀ : ι → MIACE.RealL1) (G : ι → (ℝ × ℝ) →L[ℝ] MIACE.RealL1)
    (θ₀ : ι) (hG : Function.Injective (G θ₀))
    (hmass : ∀ w ∈ kernelFeasible X (g₀ θ₀) (G θ₀),
      (∫ t, (g₀ θ₀ + G θ₀ w) t) = 1)
    (hne : (robustKernelFeasible X g₀ G).Nonempty)
    (offset : ι → ℝ) (hbounded : BddAbove (range offset))
    {Ti : ℝ} (hTi : 0 < Ti) :
    ∃ w ∈ robustKernelFeasible X g₀ G,
      (∀ z ∈ robustKernelFeasible X g₀ G, z.1 ≤ w.1) ∧
      (∀ z ∈ robustKernelFeasible X g₀ G,
        robustWorstMean offset Ti w.1 ≤ robustWorstMean offset Ti z.1) :=
  robust_minimum_worstMean_exists
    (robustKernelFeasible_compact hX g₀ G θ₀ hG hmass) hne offset hbounded hTi

/-- The article's gain-dependent offset, with `Ki = Kp / Ti`. -/
theorem gain_offset_eq_integral_gain {Ti k Kp : ℝ}
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0) :
    Ti * (1 + 1 / (k * Kp)) = (k⁻¹ + Kp) / (Kp / Ti) := by
  field_simp
  ring

/-- The attained robust optimum stated entirely in terms of the physical
tracking mean, with positivity imposed for every plant in the family. -/
theorem robustKernelFeasible_minimum_physical_mean_exists {ι : Type*} [Nonempty ι]
    {X : Set (ℝ × ℝ)} (hX : IsClosed X)
    (g₀ : ι → MIACE.RealL1) (G : ι → (ℝ × ℝ) →L[ℝ] MIACE.RealL1)
    (θ₀ : ι) (hG : Function.Injective (G θ₀))
    (hmass : ∀ w ∈ kernelFeasible X (g₀ θ₀) (G θ₀),
      (∫ t, (g₀ θ₀ + G θ₀ w) t) = 1)
    (hne : (robustKernelFeasible X g₀ G).Nonempty)
    (k : ι → ℝ) (Ti Kp : ℝ) (hTi : 0 < Ti)
    (hbounded : BddAbove (range (fun θ => Ti * (1 + 1 / (k θ * Kp))))) :
    ∃ w ∈ robustKernelFeasible X g₀ G,
      (∀ z ∈ robustKernelFeasible X g₀ G, z.1 ≤ w.1) ∧
      (∀ z ∈ robustKernelFeasible X g₀ G,
        (⨆ θ, meanTime Ti (k θ) Kp w.1) ≤ (⨆ θ, meanTime Ti (k θ) Kp z.1)) := by
  obtain ⟨w, hw, hmax, hmin⟩ := robustKernelFeasible_minimum_worstMean_exists
    hX g₀ G θ₀ hG hmass hne (fun θ => Ti * (1 + 1 / (k θ * Kp))) hbounded hTi
  refine ⟨w, hw, hmax, ?_⟩
  intro z hz
  simpa only [robustWorstMean, meanTime_eq_gain_offset] using hmin z hz

end Article14
