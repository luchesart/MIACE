import Article14.PIDFAlgebra
import Article14.LaplaceMoments
import Article14.MIACEBridge
import MIACE.AnalyticBridge

/-!
# The physical shared-D PIDF controller and its exact error transform

The controller's integrator equilibrium depends on the proportional reference
weight: it is `meanTime Ti k Kp b`, not `Ti / (k*Kp)`.  Centering about this
actual equilibrium makes the controller equations homogeneous; the weights
remain in its zero-state initial conditions.  All Laplace identities below
are conclusions of ordinary, locally absolutely continuous signal equations.
-/
namespace Article14
open MeasureTheory Filter Set MIACE
open scoped Topology

-- Article 14, Theorems 14 and 17: direct algebra of the implemented shared-D
-- controller, with unit reference and the actual steady-state offsets.
theorem sharedController_step_centered (Kp Ti Td Tf k b c e i f : ℝ)
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0) :
    let ctrl := sharedControllerRhs Kp Ti Td Tf b c 1 (1-e)
      (i + meanTime Ti k Kp b) (f + (c-1))
    ctrl.1 = e ∧ ctrl.2.1 = (e-f)/Tf ∧
      k * ctrl.2.2 - 1 = k*Kp*(e + i/Ti + Td/Tf*(e-f)) := by
  dsimp only [sharedControllerRhs, meanTime]
  constructor
  · ring
  constructor
  · congr 1; ring
  · field_simp
    ring

/-- Actual centered controller equations, regularity and zero-state values.
No transform or integral-area identity is assumed. -/
structure CenteredPIDFDynamics (e v i f : ℝ → ℝ)
    (Kp Ti Td Tf k b c : ℝ) : Prop where
  ac_i : ∀ T, 0 ≤ T → AbsolutelyContinuousOnInterval i 0 T
  ac_f : ∀ T, 0 ≤ T → AbsolutelyContinuousOnInterval f 0 T
  ode_i : ∀ᵐ t : ℝ, 0 < t → deriv i t = e t
  ode_f : ∀ᵐ t : ℝ, 0 < t → deriv f t = (e t-f t)/Tf
  initial_i : i 0 = -meanTime Ti k Kp b
  initial_f : f 0 = 1-c
  command : ∀ᵐ t ∂halfLine,
    v t = k*Kp*(e t + i t/Ti + Td/Tf*(e t-f t))

/-- Integrability and convergence are kept explicit so that exponential
stability can supply them independently of the controller algebra. -/
structure CenteredPIDFResponse (e v i f : ℝ → ℝ)
    (Kp Ti Td Tf k b c : ℝ) : Prop extends
    CenteredPIDFDynamics e v i f Kp Ti Td Tf k b c where
  error_integrable : Integrable e halfLine
  command_integrable : Integrable v halfLine
  integrator_integrable : Integrable i halfLine
  filter_integrable : Integrable f halfLine
  integrator_limit : Tendsto i atTop (𝓝 0)
  filter_limit : Tendsto f atTop (𝓝 0)

-- Article 14, Theorems 14 and 17: instantiate the centered equations from
-- the implemented, uncentered unit-step controller with both states zero
-- initially.  This is the bridge from the physical RHS, not a definition of
-- the response through the transfer identity one wishes to prove.
theorem centeredPIDFDynamics_of_step {y u I F : ℝ → ℝ}
    (Kp Ti Td Tf k b c : ℝ) (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0)
    (hIac : ∀ T, 0 ≤ T → AbsolutelyContinuousOnInterval I 0 T)
    (hFac : ∀ T, 0 ≤ T → AbsolutelyContinuousOnInterval F 0 T)
    (hIode : ∀ᵐ t : ℝ, 0 < t → deriv I t =
      (sharedControllerRhs Kp Ti Td Tf b c 1 (y t) (I t) (F t)).1)
    (hFode : ∀ᵐ t : ℝ, 0 < t → deriv F t =
      (sharedControllerRhs Kp Ti Td Tf b c 1 (y t) (I t) (F t)).2.1)
    (hI0 : I 0 = 0) (hF0 : F 0 = 0)
    (hu : ∀ᵐ t ∂halfLine, u t =
      (sharedControllerRhs Kp Ti Td Tf b c 1 (y t) (I t) (F t)).2.2) :
    CenteredPIDFDynamics (fun t => 1-y t) (fun t => k*u t-1)
      (fun t => I t-meanTime Ti k Kp b) (fun t => F t-(c-1))
      Kp Ti Td Tf k b c := by
  constructor
  · intro T hT
    exact (hIac T hT).sub (ContDiffOn.absolutelyContinuousOnInterval (by fun_prop))
  · intro T hT
    exact (hFac T hT).sub (ContDiffOn.absolutelyContinuousOnInterval (by fun_prop))
  · filter_upwards [hIode] with t ht hpos
    simpa [deriv_sub_const, sharedControllerRhs] using ht hpos
  · filter_upwards [hFode] with t ht hpos
    rw [deriv_sub_const, ht hpos]
    dsimp [sharedControllerRhs]
    congr 1
    ring
  · simp [hI0]
  · simp [hF0]
  · filter_upwards [hu] with t ht
    rw [ht]
    have hh := (sharedController_step_centered Kp Ti Td Tf k b c
      (1-y t) (I t-meanTime Ti k Kp b) (F t-(c-1)) hTi hk hKp).2.2
    simpa only [sub_sub_cancel, sub_add_cancel] using hh

-- Article 14, Theorem 14: the area is already determined by the physical
-- integrator equation and its zero-state boundary condition, without a
-- transfer-function assumption or an open-loop stability assumption.
theorem centeredPIDF_error_area {e v i f : ℝ → ℝ} {Kp Ti Td Tf k b c : ℝ}
    (h : CenteredPIDFResponse e v i f Kp Ti Td Tf k b c) :
    (∫ t, e t ∂halfLine) = meanTime Ti k Kp b := by
  have hh := laplace_ode_identity h.ac_i h.ode_i h.integrator_integrable
    h.error_integrable h.integrator_limit 0 (le_refl 0)
  simpa [laplace, h.initial_i] using hh

-- Article 14, Theorem 14: actual nonnegative error makes its absolute area
-- equal to the integrator equilibrium, not merely to a formal DC coefficient.
theorem centeredPIDF_absolute_error_area {e v i f : ℝ → ℝ}
    {Kp Ti Td Tf k b c : ℝ}
    (h : CenteredPIDFResponse e v i f Kp Ti Td Tf k b c)
    (he : ∀ᵐ t ∂halfLine, 0 ≤ e t) :
    absArea e halfLine = meanTime Ti k Kp b := by
  rw [absolute_area_identity h.error_integrable,
    (negative_area_zero_iff h.error_integrable).mpr he,
    centeredPIDF_error_area h]
  ring

-- The two transform equations are obtained by integration by parts on
-- actual locally absolutely continuous centered states.
theorem centeredPIDF_state_laplace {e v i f : ℝ → ℝ}
    {Kp Ti Td Tf k b c : ℝ}
    (h : CenteredPIDFResponse e v i f Kp Ti Td Tf k b c)
    (p : ℝ) (hp : 0 ≤ p) :
    laplace e p = p * laplace i p + meanTime Ti k Kp b ∧
    (laplace e p-laplace f p)/Tf = p*laplace f p-(1-c) := by
  constructor
  · simpa [h.initial_i] using laplace_ode_identity h.ac_i h.ode_i
      h.integrator_integrable h.error_integrable h.integrator_limit p hp
  · have hh := laplace_ode_identity h.ac_f h.ode_f h.filter_integrable
      ((h.error_integrable.sub h.filter_integrable).div_const Tf) h.filter_limit p hp
    have hlin : laplace (fun t => (e t-f t)/Tf) p =
        (laplace e p-laplace f p)/Tf := by
      unfold laplace
      simp_rw [← mul_div_assoc, mul_sub]
      rw [integral_div, integral_sub
        (laplace_integrable h.error_integrable hp)
        (laplace_integrable h.filter_integrable hp)]
    rw [hlin, h.initial_f] at hh
    exact hh

-- Article 14, Proposition 15: the actual normalized command has the
-- controller's Laplace relation, with centered-state terms still explicit.
theorem centeredPIDF_command_laplace {e v i f : ℝ → ℝ}
    {Kp Ti Td Tf k b c : ℝ}
    (h : CenteredPIDFResponse e v i f Kp Ti Td Tf k b c)
    (p : ℝ) (hp : 0 ≤ p) :
    laplace v p = k*Kp*(laplace e p + laplace i p/Ti +
      Td/Tf*(laplace e p-laplace f p)) := by
  have he := laplace_integrable h.error_integrable hp
  have hi := laplace_integrable h.integrator_integrable hp
  have hf := laplace_integrable h.filter_integrable hp
  unfold laplace
  calc
    (∫ t, Real.exp (-p*t)*v t ∂halfLine) =
        ∫ t, (k*Kp) * ((Real.exp (-p*t)*e t +
          (Real.exp (-p*t)*i t)/Ti) +
          (Td/Tf)*(Real.exp (-p*t)*e t-Real.exp (-p*t)*f t)) ∂halfLine := by
      apply integral_congr_ae
      filter_upwards [h.command] with t ht
      rw [ht]
      ring
    _ = _ := by
      have hei : Integrable (fun t => Real.exp (-p*t)*e t +
          (Real.exp (-p*t)*i t)/Ti) halfLine := he.add (hi.div_const Ti)
      have hef : Integrable (fun t => (Td/Tf) *
          (Real.exp (-p*t)*e t-Real.exp (-p*t)*f t)) halfLine :=
        (he.sub hf).const_mul (Td/Tf)
      rw [integral_const_mul, integral_add hei hef, integral_add he (hi.div_const Ti),
        integral_div, integral_const_mul, integral_sub he hf]

-- Article 14, Proposition 15: eliminate the actual integrator and derivative
-- filter transforms.  The zero-state reference weights survive as the two
-- boundary terms in the numerator.
theorem centeredPIDF_eliminated_laplace {e v i f : ℝ → ℝ}
    {Kp Ti Td Tf k b c : ℝ}
    (h : CenteredPIDFResponse e v i f Kp Ti Td Tf k b c)
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0) (hTf : 0 < Tf)
    (p : ℝ) (hp : 0 < p) :
    p * laplace v p / k =
      (Kp/Ti + p*(Kp + (Kp*Td)*p/(1+Tf*p))) * laplace e p -
        ((1-b)*Kp + 1/k + (1-c)*(Kp*Td)*p/(1+Tf*p)) := by
  obtain ⟨hi, hf⟩ := centeredPIDF_state_laplace h p hp.le
  have hv := centeredPIDF_command_laplace h p hp.le
  have hp0 : p ≠ 0 := ne_of_gt hp
  have hTf0 : Tf ≠ 0 := ne_of_gt hTf
  have hd : 1+Tf*p ≠ 0 := ne_of_gt (by positivity)
  have hii : laplace i p = (laplace e p-meanTime Ti k Kp b)/p := by
    apply (eq_div_iff hp0).mpr
    linarith
  have hff : laplace f p = (laplace e p+Tf*(1-c))/(1+Tf*p) := by
    apply (eq_div_iff hd).mpr
    have hh := (div_eq_iff hTf0).mp hf
    nlinarith
  rw [hv, hii, hff]
  unfold meanTime
  field_simp
  ring

-- This inverse-plant identity follows from the physical zero-state relation.
-- It is used only where the normalized plant is nonzero near the origin.
theorem local_transfer_inverse_command {e v H : ℝ → ℝ} {k δ : ℝ}
    (h : LocalTransferResponse e v H δ) (hH : ContinuousAt H 0)
    (hH0 : H 0 = 1) (hk : k ≠ 0) :
    ∀ᶠ p in 𝓝[>] (0 : ℝ),
      p * laplace v p / k =
        inverseDelayedPlant H k δ p * (1-p*laplace e p)-1/k := by
  have hne : ∀ᶠ p in 𝓝[>] (0 : ℝ), H p ≠ 0 :=
    (hH.eventually_ne (by rw [hH0]; norm_num)).filter_mono nhdsWithin_le_nhds
  filter_upwards [local_transfer_error_identity h, hne, self_mem_nhdsWithin]
    with p he hHp hp
  have hp0 : p ≠ 0 := ne_of_gt (show 0 < p from hp)
  have hd : H p * Real.exp (-δ*p) ≠ 0 := mul_ne_zero hHp (Real.exp_ne_zero _)
  have hcleared : p * laplace e p =
      1-H p*Real.exp (-δ*p)-p*(H p*Real.exp (-δ*p))*laplace v p := by
    rw [he]
    field_simp
  unfold inverseDelayedPlant
  field_simp
  simp only [neg_mul, mul_comm δ p] at hcleared
  nlinarith

-- Article 14, Proposition 15: physical controller dynamics and an actual
-- physical local plant relation yield the previously conditional cleared
-- error transform.  The denominator is nonzero on a right neighbourhood of
-- zero because its DC value is Kp/Ti.
theorem centeredPIDF_local_clearedError {e v i f H : ℝ → ℝ}
    {Kp Ti Td Tf k b c δ : ℝ}
    (h : CenteredPIDFResponse e v i f Kp Ti Td Tf k b c)
    (hplant : LocalTransferResponse e v H δ)
    (hH : ContinuousAt H 0) (hH0 : H 0 = 1)
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0) (hTf : 0 < Tf) :
    laplace e =ᶠ[𝓝[>] (0 : ℝ)]
      clearedError (inverseDelayedPlant H k δ) Kp (Kp/Ti) (Kp*Td) Tf b c := by
  let Q := inverseDelayedPlant H k δ
  have hQ : ContinuousAt Q 0 := by
    change ContinuousAt (fun p : ℝ => 1/(k*(H p*Real.exp (-δ*p)))) 0
    fun_prop (disch := simpa [hH0] using hk)
  let D := fun p : ℝ => Kp/Ti + p*(Q p+Kp+(Kp*Td)*p/(1+Tf*p))
  have hD : ContinuousAt D 0 := by
    dsimp [D]
    fun_prop (disch := norm_num)
  have hD0 : D 0 ≠ 0 := by simpa [D] using div_ne_zero hKp hTi
  have hne : ∀ᶠ p in 𝓝[>] (0 : ℝ), D p ≠ 0 :=
    (hD.eventually_ne hD0).filter_mono nhdsWithin_le_nhds
  filter_upwards [local_transfer_inverse_command hplant hH hH0 hk,
    hne, self_mem_nhdsWithin] with p hp hDp hp0
  have hc := centeredPIDF_eliminated_laplace h hTi hk hKp hTf p hp0
  change laplace e p =
    (Q p+(1-b)*Kp+(1-c)*(Kp*Td)*p/(1+Tf*p))/D p
  apply (eq_div_iff hDp).mpr
  dsimp [D]
  change p*laplace v p/k = Q p*(1-p*laplace e p)-1/k at hp
  nlinarith

-- Article 14, Proposition 15: composing the derived physical controller
-- transform with the inherited differentiation-under-the-integral theorem
-- gives the actual first error moment, with Γ = μ + δ.
theorem centeredPIDF_first_error_moment {e v i f H : ℝ → ℝ}
    {Kp Ti Td Tf k b c δ μ C β : ℝ}
    (h : CenteredPIDFResponse e v i f Kp Ti Td Tf k b c)
    (hplant : LocalTransferResponse e v H δ)
    (hH : HasDerivAt H (-μ) 0) (hH0 : H 0 = 1)
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0) (hTf : 0 < Tf)
    (he : ContinuousOn e (Ici 0)) (hC : 0 ≤ C) (hβ : 0 < β)
    (hdecay : ∀ t, 0 ≤ t → |e t| ≤ C*Real.exp (-β*t)) :
    (∫ t, t*e t ∂halfLine) =
      secondErrorMoment Kp (Kp/Ti) (Kp*Td) k (μ+δ) (meanTime Ti k Kp b) c := by
  have hQ0 := inverseDelayedPlant_zero k δ hH0
  have hm := clearedError_mean (inverseDelayedPlant H k δ) Kp Ti (Kp*Td)
    Tf b c k hQ0 hk hKp
  rw [clearedError_zero _ _ _ _ _ _ _ _ hQ0] at hm
  -- Extend constantly to negative time only to invoke the inherited theorem;
  -- every physical hypothesis and conclusion concerns nonnegative time.
  let ePlus := fun t : ℝ => e (max t 0)
  have hPlusEq : ∀ t, 0 ≤ t → ePlus t = e t := by
    intro t ht
    simp [ePlus, max_eq_left ht]
  have hPlusCont : Continuous ePlus :=
    he.comp_continuous (continuous_id.max continuous_const) (fun t => le_max_right t 0)
  have hLap : laplace ePlus = laplace e := by
    funext p
    apply integral_congr_ae
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    rw [hPlusEq t (le_of_lt ht)]
  have hMoment : (∫ t, t*ePlus t ∂halfLine) = (∫ t, t*e t ∂halfLine) := by
    apply integral_congr_ae
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    rw [hPlusEq t (le_of_lt ht)]
  have hPlusDecay : ∀ t, 0 ≤ t → |ePlus t| ≤ C*Real.exp (-β*t) := by
    intro t ht
    rw [hPlusEq t ht]
    exact hdecay t ht
  have hTransfer := centeredPIDF_local_clearedError h hplant hH.continuousAt
    hH0 hTi hk hKp hTf
  have ht := tracking_error_first_moment hPlusCont hC hβ hPlusDecay Kp (Kp/Ti) (Kp*Td)
    Tf b c k (μ+δ) (inverseDelayedPlant_derivative k μ δ hk hH hH0) hQ0
    (div_ne_zero hKp hTi) (by simpa only [hLap] using hTransfer)
  simpa only [hm, hMoment] using ht

-- Article 14, Proposition 15: positivity turns that actual first moment
-- into ITAE, preserving the explicit physical hypotheses of the preceding
-- theorem rather than assuming an error-transform certificate.
theorem centeredPIDF_itae {e v i f H : ℝ → ℝ}
    {Kp Ti Td Tf k b c δ μ C β : ℝ}
    (h : CenteredPIDFResponse e v i f Kp Ti Td Tf k b c)
    (hplant : LocalTransferResponse e v H δ)
    (hH : HasDerivAt H (-μ) 0) (hH0 : H 0 = 1)
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0) (hTf : 0 < Tf)
    (he : ContinuousOn e (Ici 0)) (hC : 0 ≤ C) (hβ : 0 < β)
    (hdecay : ∀ t, 0 ≤ t → |e t| ≤ C*Real.exp (-β*t))
    (hn : ∀ᵐ t ∂halfLine, 0 ≤ e t) :
    (∫ t, t*|e t| ∂halfLine) =
      secondErrorMoment Kp (Kp/Ti) (Kp*Td) k (μ+δ) (meanTime Ti k Kp b) c := by
  calc
    (∫ t, t*|e t| ∂halfLine) = (∫ t, t*e t ∂halfLine) := by
      apply integral_congr_ae
      filter_upwards [hn] with t ht
      rw [abs_of_nonneg ht]
    _ = _ := centeredPIDF_first_error_moment h hplant hH hH0 hTi hk hKp hTf
      he hC hβ hdecay

-- Article 14, Theorem 17: command area follows from the actual integrator
-- area and the inherited local plant DC balance.
theorem centeredPIDF_command_area {e v i f H : ℝ → ℝ}
    {Kp Ti Td Tf k b c δ μ : ℝ}
    (h : CenteredPIDFResponse e v i f Kp Ti Td Tf k b c)
    (hplant : LocalTransferResponse e v H δ)
    (hH : HasDerivAt H (-μ) 0) (hH0 : H 0 = 1) :
    (∫ t, v t ∂halfLine) = μ+δ-meanTime Ti k Kp b := by
  have hp := local_transfer_signed_balance hplant μ hH hH0
  rw [centeredPIDF_error_area h] at hp
  linarith

-- Article 14, Theorem 17: on the two-signal nonnegative set, MIACE is the
-- stated one-dimensional quadratic objective in the proportional weight.
theorem centeredPIDF_nonnegative_miace {e v i f H : ℝ → ℝ}
    {Kp Ti Td Tf k b c δ μ : ℝ}
    (h : CenteredPIDFResponse e v i f Kp Ti Td Tf k b c)
    (hplant : LocalTransferResponse e v H δ)
    (hH : HasDerivAt H (-μ) 0) (hH0 : H 0 = 1)
    (he : ∀ᵐ t ∂halfLine, 0 ≤ e t) (hv : ∀ᵐ t ∂halfLine, 0 ≤ v t)
    (α : ℝ) :
    miace α e v halfLine = Real.sqrt ((meanTime Ti k Kp b)^2 +
      α*(μ+δ-meanTime Ti k Kp b)^2) := by
  have hA : absArea v halfLine = μ+δ-meanTime Ti k Kp b := by
    rw [absolute_area_identity h.command_integrable,
      (negative_area_zero_iff h.command_integrable).mpr hv,
      centeredPIDF_command_area h hplant hH hH0]
    ring
  rw [miace, centeredPIDF_absolute_error_area h he, hA]
  rfl

end Article14
