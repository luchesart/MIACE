import Mathlib.LinearAlgebra.Matrix.Charpoly.Coeff
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Topology.Separation.Basic
import Mathlib.Analysis.Complex.Basic

/-!
# Punctured-neighborhood regularity of finite matrix pencils

A selected closed-loop pole may also be an open-loop pole. The surrounding
resolvents are nevertheless defined off the center in a sufficiently small
neighborhood: the monic characteristic polynomial has only finitely many roots.
-/
namespace Article14
open Filter Set
open scoped Topology

-- This includes the case that the determinant vanishes at the center itself.
theorem matrix_pencil_eventually_ne_zero {n : Type*} [Fintype n] [DecidableEq n]
    (M : Matrix n n ℂ) (p : ℂ) :
    ∀ᶠ z in 𝓝[≠] p, (Matrix.scalar n z-M).det ≠ 0 := by
  have h := (Polynomial.eventually_eval_ne_zero_cofinite M.charpoly_monic.ne_zero).filter_mono
    (nhdsNE_le_cofinite p)
  simpa only [Matrix.eval_charpoly] using h

end Article14
