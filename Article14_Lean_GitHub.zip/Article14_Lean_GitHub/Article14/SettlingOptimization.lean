import Article14.PositiveKernel
import Article14.FeasibleGeometry
import Mathlib.MeasureTheory.Integral.DominatedConvergence
import Mathlib.Topology.Order.Monotone
import Mathlib.Analysis.Convex.Quasiconvex

/-!
Article 14, Proposition 16.  Settling time is the infimum of actual
nonnegative all-future settling horizons.  Its attainment and the existence
of an optimal weight are proved, rather than included in its definition.
-/

namespace Article14
open MeasureTheory Set Filter
open scoped Topology

def settlingHorizons (y : ℝ → ℝ) (ε : ℝ) : Set ℝ :=
  {H | 0 ≤ H ∧ SettledBy y ε H}

noncomputable def settlingTime (y : ℝ → ℝ) (ε : ℝ) : ℝ :=
  sInf (settlingHorizons y ε)

-- NEW: The all-future definition reduces to the horizon value by monotonicity.
theorem settledBy_iff_of_monotone {y : ℝ → ℝ}
    (hm : Monotone y) (hu : ∀ t, y t ≤ 1) (ε H : ℝ) :
    SettledBy y ε H ↔ 1 - ε ≤ y H := by
  constructor
  · intro h
    have hh := h H le_rfl
    rw [abs_of_nonneg (sub_nonneg.mpr (hu H))] at hh
    linarith
  · intro hh t ht
    rw [abs_of_nonneg (sub_nonneg.mpr (hu t))]
    have hmt := hm ht
    linarith

theorem settlingHorizons_bddBelow (y : ℝ → ℝ) (ε : ℝ) :
    BddBelow (settlingHorizons y ε) := ⟨0, fun _ h => h.1⟩

-- NEW: A positive tolerance and unit final limit produce a finite feasible horizon.
theorem settlingHorizons_nonempty {y : ℝ → ℝ}
    (hm : Monotone y) (hu : ∀ t, y t ≤ 1)
    (hlim : Tendsto y atTop (𝓝 1)) {ε : ℝ} (hε : 0 < ε) :
    (settlingHorizons y ε).Nonempty := by
  have hev : ∀ᶠ t in atTop, 1 - ε < y t :=
    (tendsto_order.mp hlim).1 (1 - ε) (by linarith)
  obtain ⟨H, hH, hY⟩ := ((eventually_ge_atTop (0 : ℝ)).and hev).exists
  exact ⟨H, hH, (settledBy_iff_of_monotone hm hu ε H).2 hY.le⟩

-- NEW: Continuity closes the possible gap at the infimum horizon.
theorem settlingHorizons_closed {y : ℝ → ℝ} (hc : Continuous y)
    (hm : Monotone y) (hu : ∀ t, y t ≤ 1) (ε : ℝ) :
    IsClosed (settlingHorizons y ε) := by
  have he : settlingHorizons y ε = Ici 0 ∩ {H | 1 - ε ≤ y H} := by
    ext H
    simp only [settlingHorizons, mem_ofPred_eq, mem_inter_iff, mem_Ici,
      settledBy_iff_of_monotone hm hu]
  rw [he]
  exact isClosed_Ici.inter (isClosed_le continuous_const hc)

theorem settlingTime_attained {y : ℝ → ℝ} (hc : Continuous y)
    (hm : Monotone y) (hu : ∀ t, y t ≤ 1)
    (hlim : Tendsto y atTop (𝓝 1)) {ε : ℝ} (hε : 0 < ε) :
    0 ≤ settlingTime y ε ∧ SettledBy y ε (settlingTime y ε) :=
  (settlingHorizons_closed hc hm hu ε).csInf_mem
    (settlingHorizons_nonempty hm hu hlim hε) (settlingHorizons_bddBelow y ε)

-- NEW: This relates the actual infimum settling time to the finite horizon test.
theorem settlingTime_le_iff {y : ℝ → ℝ} (hc : Continuous y)
    (hm : Monotone y) (hu : ∀ t, y t ≤ 1)
    (hlim : Tendsto y atTop (𝓝 1)) {ε : ℝ} (hε : 0 < ε)
    {H : ℝ} (hH : 0 ≤ H) :
    settlingTime y ε ≤ H ↔ 1 - ε ≤ y H := by
  have ha := settlingTime_attained hc hm hu hlim hε
  constructor
  · intro ht
    exact ((settledBy_iff_of_monotone hm hu ε _).1 ha.2).trans (hm ht)
  · intro ht
    exact csInf_le (settlingHorizons_bddBelow y ε)
      ⟨hH, (settledBy_iff_of_monotone hm hu ε H).2 ht⟩

-- NEW: Compactness is used on actual weight/horizon pairs.  No continuity of
-- the settling-time function itself is assumed (it need not be continuous).
theorem minimum_settlingTime_exists {F : Set (ℝ × ℝ)}
    (hF : IsCompact F) (hne : F.Nonempty) (Y : (ℝ × ℝ) → ℝ → ℝ)
    (hc : Continuous (fun p : (ℝ × ℝ) × ℝ => Y p.1 p.2))
    (hm : ∀ w ∈ F, Monotone (Y w))
    (hu : ∀ w ∈ F, ∀ t, Y w t ≤ 1)
    (hlim : ∀ w ∈ F, Tendsto (Y w) atTop (𝓝 1))
    {ε : ℝ} (hε : 0 < ε) :
    ∃ w ∈ F, (0 ≤ settlingTime (Y w) ε) ∧
      SettledBy (Y w) ε (settlingTime (Y w) ε) ∧
      ∀ z ∈ F, settlingTime (Y w) ε ≤ settlingTime (Y z) ε := by
  have hcw (w : ℝ × ℝ) : Continuous (Y w) :=
    hc.comp (continuous_const.prodMk continuous_id)
  obtain ⟨w0, hw0⟩ := hne
  obtain ⟨H0, hH0, hs0⟩ := settlingHorizons_nonempty (hm w0 hw0)
    (hu w0 hw0) (hlim w0 hw0) hε
  have hY0 := (settledBy_iff_of_monotone (hm w0 hw0) (hu w0 hw0) ε H0).1 hs0
  let K : Set ((ℝ × ℝ) × ℝ) :=
    (F ×ˢ Icc 0 H0) ∩ {p | 1 - ε ≤ Y p.1 p.2}
  have hK : IsCompact K := (hF.prod isCompact_Icc).inter_right
    (isClosed_le continuous_const hc)
  have hneK : K.Nonempty := ⟨(w0, H0), ⟨hw0, hH0, le_rfl⟩, hY0⟩
  obtain ⟨p, hp, hmin⟩ := hK.exists_isMinOn hneK continuous_snd.continuousOn
  have hpF : p.1 ∈ F := hp.1.1
  have hp0 : 0 ≤ p.2 := hp.1.2.1
  have hpH : p.2 ≤ H0 := hp.1.2.2
  have hpY : 1 - ε ≤ Y p.1 p.2 := hp.2
  have hglobal : ∀ z ∈ F, ∀ H, 0 ≤ H → SettledBy (Y z) ε H → p.2 ≤ H := by
    intro z hz H hH hs
    by_cases hH0' : H ≤ H0
    · exact hmin (show (z, H) ∈ K from
        ⟨⟨hz, hH, hH0'⟩, (settledBy_iff_of_monotone (hm z hz) (hu z hz) ε H).1 hs⟩)
    · exact hpH.trans (le_of_lt (lt_of_not_ge hH0'))
  have hpA := settlingTime_attained (hcw p.1) (hm p.1 hpF)
    (hu p.1 hpF) (hlim p.1 hpF) hε
  have hpEq : settlingTime (Y p.1) ε = p.2 := by
    apply le_antisymm
    · exact (settlingTime_le_iff (hcw p.1) (hm p.1 hpF)
        (hu p.1 hpF) (hlim p.1 hpF) hε hp0).2 hpY
    · exact hglobal p.1 hpF _ hpA.1 hpA.2
  refine ⟨p.1, hpF, hpA.1, hpA.2, ?_⟩
  intro z hz
  rw [hpEq]
  have hzA := settlingTime_attained (hcw z) (hm z hz) (hu z hz) (hlim z hz) hε
  exact hglobal z hz _ hzA.1 hzA.2

-- NEW: Integrable ordinary kernels supply the continuity hypothesis above.
theorem kernel_step_continuous {g : ℝ → ℝ} (hi : Integrable g) :
    Continuous (kernelStep g) := by
  have he : kernelStep g = fun t => (∫ u in (0 : ℝ)..t, g u) + kernelStep g 0 := by
    funext t
    have hh := intervalIntegral.integral_Iic_sub_Iic
      (hi.integrableOn : IntegrableOn g (Iic (0 : ℝ)))
      (hi.integrableOn : IntegrableOn g (Iic t))
    change kernelStep g t = _
    change kernelStep g t - kernelStep g 0 = _ at hh
    linarith
  rw [he]
  exact (hi.continuous_primitive 0).add continuous_const

theorem affine_kernel_step_joint_continuous {g0 gb gc : ℝ → ℝ}
    (h0 : Integrable g0) (hb : Integrable gb) (hc : Integrable gc) :
    Continuous (fun p : (ℝ × ℝ) × ℝ =>
      kernelStep (affineKernel g0 gb gc p.1) p.2) := by
  simp_rw [kernelStep_affine g0 gb gc h0 hb hc]
  exact ((kernel_step_continuous h0).comp continuous_snd).add
    ((continuous_fst.fst.mul ((kernel_step_continuous hb).comp continuous_snd))) |>.add
      (continuous_fst.snd.mul ((kernel_step_continuous hc).comp continuous_snd))

-- NEW: Proposition 16 for the actual affine family of ordinary impulse kernels.
theorem affine_kernel_minimum_settlingTime_exists {g0 gb gc : ℝ → ℝ}
    (h0 : Integrable g0) (hb : Integrable gb) (hc : Integrable gc)
    {F : Set (ℝ × ℝ)} (hF : IsCompact F) (hne : F.Nonempty)
    (hpos : F ⊆ positiveWeights g0 gb gc)
    (hmass : ∀ w ∈ F, (∫ t, affineKernel g0 gb gc w t) = 1)
    {ε : ℝ} (hε : 0 < ε) :
    ∃ w ∈ F, (0 ≤ settlingTime (kernelStep (affineKernel g0 gb gc w)) ε) ∧
      SettledBy (kernelStep (affineKernel g0 gb gc w)) ε
        (settlingTime (kernelStep (affineKernel g0 gb gc w)) ε) ∧
      ∀ z ∈ F, settlingTime (kernelStep (affineKernel g0 gb gc w)) ε ≤
        settlingTime (kernelStep (affineKernel g0 gb gc z)) ε := by
  apply minimum_settlingTime_exists hF hne
    (fun w => kernelStep (affineKernel g0 gb gc w))
    (affine_kernel_step_joint_continuous h0 hb hc) ?_ ?_ ?_ hε
  · intro w hw
    exact positive_kernel_step_monotone (affineKernel_integrable h0 hb hc w) (hpos hw)
  · intro w hw t
    exact (positive_kernel_step_bounds (affineKernel_integrable h0 hb hc w)
      (hpos hw) (hmass w hw) t).2
  · intro w hw
    exact unit_mass_kernel_step_tendsto_one (affineKernel_integrable h0 hb hc w) (hmass w hw)

-- NEW: The quasiconvex objective is the genuine infimum settling time.
theorem affine_kernel_settlingTime_quasiconvex {g0 gb gc : ℝ → ℝ}
    (h0 : Integrable g0) (hb : Integrable gb) (hc : Integrable gc)
    {F : Set (ℝ × ℝ)} (hF : Convex ℝ F)
    (hpos : F ⊆ positiveWeights g0 gb gc)
    (hmass : ∀ w ∈ F, (∫ t, affineKernel g0 gb gc w t) = 1)
    {ε : ℝ} (hε : 0 < ε) :
    QuasiconvexOn ℝ F (fun w => settlingTime (kernelStep (affineKernel g0 gb gc w)) ε) := by
  have hint (w : ℝ × ℝ) := affineKernel_integrable h0 hb hc w
  have hmon (w : ℝ × ℝ) (hw : w ∈ F) := positive_kernel_step_monotone (hint w) (hpos hw)
  have hup (w : ℝ × ℝ) (hw : w ∈ F) (t : ℝ) :=
    (positive_kernel_step_bounds (hint w) (hpos hw) (hmass w hw) t).2
  have hlim (w : ℝ × ℝ) (hw : w ∈ F) :=
    unit_mass_kernel_step_tendsto_one (hint w) (hmass w hw)
  intro H
  by_cases hH : 0 ≤ H
  · have he : {w ∈ F | settlingTime (kernelStep (affineKernel g0 gb gc w)) ε ≤ H} =
        F ∩ {w | 1 - ε ≤ kernelStep (affineKernel g0 gb gc w) H} := by
      ext w
      by_cases hw : w ∈ F
      · simp only [mem_ofPred_eq, mem_inter_iff, hw, true_and]
        exact settlingTime_le_iff (kernel_step_continuous (hint w))
          (hmon w hw) (hup w hw) (hlim w hw) hε hH
      · simp only [mem_ofPred_eq, mem_inter_iff, hw, false_and]
    rw [he]
    exact hF.inter (horizonWeights_convex g0 gb gc h0 hb hc H (1 - ε))
  · have he : {w ∈ F | settlingTime (kernelStep (affineKernel g0 gb gc w)) ε ≤ H} = ∅ := by
      apply Set.eq_empty_iff_forall_notMem.mpr
      intro w hw
      have ha := settlingTime_attained (kernel_step_continuous (hint w))
        (hmon w hw.1) (hup w hw.1) (hlim w hw.1) hε
      exact hH (ha.1.trans hw.2)
    rw [he]
    exact convex_empty

theorem affine_kernel_settlingTime_le_iff {g0 gb gc : ℝ → ℝ}
    (h0 : Integrable g0) (hb : Integrable gb) (hc : Integrable gc)
    (w : ℝ × ℝ) (hpos : w ∈ positiveWeights g0 gb gc)
    (hmass : (∫ t, affineKernel g0 gb gc w t) = 1)
    {ε : ℝ} (hε : 0 < ε) {H : ℝ} (hH : 0 ≤ H) :
    settlingTime (kernelStep (affineKernel g0 gb gc w)) ε ≤ H ↔
      1 - ε ≤ kernelStep g0 H + w.1 * kernelStep gb H + w.2 * kernelStep gc H := by
  have hi := affineKernel_integrable h0 hb hc w
  rw [settlingTime_le_iff (kernel_step_continuous hi)
      (positive_kernel_step_monotone hi hpos)
      (fun t => (positive_kernel_step_bounds hi hpos hmass t).2)
      (unit_mass_kernel_step_tendsto_one hi hmass) hε hH,
    kernelStep_affine g0 gb gc h0 hb hc]

end Article14
