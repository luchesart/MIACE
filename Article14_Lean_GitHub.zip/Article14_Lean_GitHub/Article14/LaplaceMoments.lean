import Article14.TrackingMoments

/-!
# Article 14: actual error moments from the local transfer derivative

The first moment is an ordinary improper Lebesgue integral, not a coefficient
defined to equal a formal power series.  Exponential decay at any positive
rate supplies integrability and domination for differentiation under the
Laplace integral.  Equality of the error transform with the cleared PIDF
transfer is needed only to the right of zero.
-/
namespace Article14
open MeasureTheory Filter Set MIACE
open scoped Topology

-- Article 14, Proposition 15: arbitrary positive exponential decay implies
-- integrability of the actual tracking-error signal.
theorem error_integrable_of_exp_decay {e : ℝ → ℝ} (he : Continuous e)
    {C β : ℝ} (hβ : 0 < β)
    (hdecay : ∀ t, 0 ≤ t → |e t| ≤ C * Real.exp (-β * t)) :
    Integrable e halfLine := by
  have hi := (integrableOn_exp_mul_Ioi (by linarith : -β < 0) 0).const_mul C
  apply hi.mono' he.aestronglyMeasurable
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  exact hdecay t (le_of_lt (show 0 < t from ht))

-- Article 14, Proposition 15: the actual time-weighted error is integrable.
-- The exponential-polynomial estimate is reused from the MIACE article.
theorem error_first_moment_integrable {e : ℝ → ℝ} (he : Continuous e)
    {C β : ℝ} (hC : 0 ≤ C) (hβ : 0 < β)
    (hdecay : ∀ t, 0 ≤ t → |e t| ≤ C * Real.exp (-β * t)) :
    Integrable (fun t => t * e t) halfLine := by
  have hi := (integrableOn_exp_mul_Ioi
    (by linarith : -(β / 2) < 0) 0).const_mul (C * (2 / β))
  apply hi.mono' (by apply Continuous.aestronglyMeasurable; fun_prop)
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  have ht0 : 0 ≤ t := le_of_lt (show 0 < t from ht)
  rw [norm_mul, Real.norm_of_nonneg ht0, Real.norm_eq_abs]
  calc
    t * |e t| ≤ t * (C * Real.exp (-β * t)) :=
      mul_le_mul_of_nonneg_left (hdecay t ht0) ht0
    _ ≤ C * (2 / β) * Real.exp (-(β / 2) * t) := by
      have hb := mul_le_mul_of_nonneg_left (linear_exp_bound hβ ht0) hC
      nlinarith

-- Article 14, Proposition 15: genuine differentiation of the real Laplace
-- integral at DC, with its derivative equal to minus the first error moment.
theorem error_laplace_derivative_at_zero {e : ℝ → ℝ} (he : Continuous e)
    {C β : ℝ} (hC : 0 ≤ C) (hβ : 0 < β)
    (hdecay : ∀ t, 0 ≤ t → |e t| ≤ C * Real.exp (-β * t)) :
    HasDerivAt (laplace e) (-(∫ t, t * e t ∂halfLine)) 0 := by
  let a := β / 2
  have ha : 0 < a := by dsimp [a]; linarith
  let B := fun t : ℝ => C * (2 / a) * Real.exp (-(a / 2) * t)
  have hB : Integrable B halfLine :=
    (integrableOn_exp_mul_Ioi (by linarith : -(a / 2) < 0) 0).const_mul (C * (2 / a))
  have h0 : Integrable (fun t : ℝ => Real.exp (-(0 : ℝ) * t) * e t) halfLine := by
    simpa using error_integrable_of_exp_decay he hβ hdecay
  have hd : HasDerivAt (laplace e)
      (∫ t, -t * (Real.exp (-(0 : ℝ) * t) * e t) ∂halfLine) 0 := by
    apply (hasDerivAt_integral_of_dominated_loc_of_deriv_le
      (μ := halfLine) (F := fun q t => Real.exp (-q * t) * e t)
      (F' := fun q t => -t * (Real.exp (-q * t) * e t))
      (s := Metric.ball (0 : ℝ) a) (bound := B) (Metric.ball_mem_nhds 0 ha)
      (Eventually.of_forall (fun q => by apply Continuous.aestronglyMeasurable; fun_prop))
      h0 (by apply Continuous.aestronglyMeasurable; fun_prop) ?_ hB ?_).2
    · filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht q hq
      have ht0 : 0 ≤ t := (show 0 < t from ht).le
      have hqabs : |q| < a := by simpa only [Metric.mem_ball, Real.dist_eq, sub_zero] using hq
      have hqa : a ≤ q + β := by dsimp [a] at *; linarith [(abs_lt.mp hqabs).1]
      rw [norm_mul, norm_neg, Real.norm_of_nonneg ht0, norm_mul,
        Real.norm_of_nonneg (Real.exp_nonneg _), Real.norm_eq_abs]
      calc
        t * (Real.exp (-q * t) * |e t|) ≤
            t * (Real.exp (-q * t) * (C * Real.exp (-β * t))) :=
          mul_le_mul_of_nonneg_left
            (mul_le_mul_of_nonneg_left (hdecay t ht0) (Real.exp_nonneg _)) ht0
        _ = t * (C * Real.exp (-(q + β) * t)) := by
          rw [mul_left_comm (Real.exp _) C, ← Real.exp_add]
          congr 3
          ring
        _ ≤ t * (C * Real.exp (-a * t)) := mul_le_mul_of_nonneg_left
          (mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (by nlinarith)) hC) ht0
        _ ≤ B t := by
          have hh := mul_le_mul_of_nonneg_left (linear_exp_bound ha ht0) hC
          dsimp [B]
          nlinarith
    · apply Eventually.of_forall
      intro t q _
      convert (((hasDerivAt_id q).neg.mul_const t).exp).mul_const (e t) using 1
      · rfl
      · dsimp
        ring
  simpa only [neg_zero, zero_mul, Real.exp_zero, one_mul, neg_mul, integral_neg] using hd

-- Article 14, Proposition 15: derive the time-weighted signed error from
-- the local physical error-transfer relation and its exact quotient derivative.
-- No equality to a derivative or a moment is assumed as a certificate field.
theorem tracking_error_first_moment {e Q : ℝ → ℝ} (he : Continuous e)
    {C β : ℝ} (hC : 0 ≤ C) (hβ : 0 < β)
    (hdecay : ∀ t, 0 ≤ t → |e t| ≤ C * Real.exp (-β * t))
    (Kp Ki Kd Tf b c k Γ : ℝ)
    (hQ : HasDerivAt Q (Γ / k) 0) (hQ0 : Q 0 = 1 / k) (hKi : Ki ≠ 0)
    (htransfer : laplace e =ᶠ[𝓝[>] (0 : ℝ)] clearedError Q Kp Ki Kd Tf b c) :
    (∫ t, t * e t ∂halfLine) =
      secondErrorMoment Kp Ki Kd k Γ ((1 / k + (1 - b) * Kp) / Ki) c := by
  have hlap := error_laplace_derivative_at_zero he hC hβ hdecay
  have hclear := clearedError_derivative Kp Ki Kd Tf b c k Γ hQ hQ0 hKi
  have hEq0 : laplace e 0 = clearedError Q Kp Ki Kd Tf b c 0 :=
    tendsto_nhds_unique
      (hlap.continuousAt.tendsto.mono_left nhdsWithin_le_nhds)
      ((hclear.continuousAt.tendsto.mono_left nhdsWithin_le_nhds).congr' htransfer.symm)
  have hwithin : HasDerivWithinAt (clearedError Q Kp Ki Kd Tf b c)
      (-(∫ t, t * e t ∂halfLine)) (Ioi 0) 0 :=
    hlap.hasDerivWithinAt.congr_of_eventuallyEq htransfer.symm hEq0.symm
  have hd1 := hwithin.derivWithin (uniqueDiffWithinAt_Ioi (0 : ℝ))
  have hd2 := hclear.hasDerivWithinAt.derivWithin (uniqueDiffWithinAt_Ioi (0 : ℝ))
  linarith

-- Article 14, Proposition 15: under no overshoot the time-weighted absolute
-- error (ITAE) is exactly the formula derived from the plant/controller data.
theorem tracking_itae {e Q : ℝ → ℝ} (he : Continuous e)
    {C β : ℝ} (hC : 0 ≤ C) (hβ : 0 < β)
    (hdecay : ∀ t, 0 ≤ t → |e t| ≤ C * Real.exp (-β * t))
    (hn : ∀ᵐ t ∂halfLine, 0 ≤ e t) (Kp Ki Kd Tf b c k Γ : ℝ)
    (hQ : HasDerivAt Q (Γ / k) 0) (hQ0 : Q 0 = 1 / k) (hKi : Ki ≠ 0)
    (htransfer : laplace e =ᶠ[𝓝[>] (0 : ℝ)] clearedError Q Kp Ki Kd Tf b c) :
    (∫ t, t * |e t| ∂halfLine) =
      secondErrorMoment Kp Ki Kd k Γ ((1 / k + (1 - b) * Kp) / Ki) c := by
  calc
    (∫ t, t * |e t| ∂halfLine) = (∫ t, t * e t ∂halfLine) := by
      apply integral_congr_ae
      filter_upwards [hn] with t ht
      rw [abs_of_nonneg ht]
    _ = _ := tracking_error_first_moment he hC hβ hdecay Kp Ki Kd Tf b c k Γ
      hQ hQ0 hKi htransfer

end Article14
