import Article14.PhysicalFamily
import Mathlib.LinearAlgebra.Matrix.NonsingularInverse

/-!
# A concrete realization of a strictly proper real rational plant

The companion matrix, input column, and output row are constructed from
polynomial coefficients. The resolvent identity and the physical DC equilibrium
are proved by the finite coordinate equations, not supplied as certificates.
-/
namespace Article14.RationalRealization
open Matrix Finset
open Article14.PhysicalPlant
open scoped Matrix

variable {n : ℕ}

/-- The monic denominator evaluated at a real frequency. -/
noncomputable def denominatorValue (a : Fin (n+1) → ℝ) (s : ℝ) : ℝ :=
  s^(n+1)+∑ j, a j*s^(j:ℕ)

/-- A strictly lower-degree numerator evaluated at a real frequency. -/
noncomputable def numeratorValue (b : Fin (n+1) → ℝ) (s : ℝ) : ℝ :=
  ∑ j, b j*s^(j:ℕ)

/-- The ordinary controllable companion state matrix. -/
noncomputable def companion (a : Fin (n+1) → ℝ) : Matrix (Fin (n+1)) (Fin (n+1)) ℝ :=
  fun i => Fin.lastCases (fun j => -a j)
    (fun i j => if j=i.succ then 1 else 0) i

/-- The input enters the last derivative coordinate. -/
noncomputable def inputVector (n : ℕ) : Fin (n+1) → ℝ :=
  fun i => if i=Fin.last n then 1 else 0

/-- The monomial state vector of the companion pencil. -/
noncomputable def monomialVector (n : ℕ) (s : ℝ) : Fin (n+1) → ℝ :=
  fun j => s^(j:ℕ)

theorem companion_mulVec_castSucc (a : Fin (n+1) → ℝ)
    (x : Fin (n+1) → ℝ) (i : Fin n) :
    (companion a *ᵥ x) i.castSucc = x i.succ := by
  simp [companion, mulVec, dotProduct]

theorem companion_mulVec_last (a : Fin (n+1) → ℝ)
    (x : Fin (n+1) → ℝ) :
    (companion a *ᵥ x) (Fin.last n) = -(∑ j, a j*x j) := by
  simp [companion, mulVec, dotProduct, Finset.sum_neg_distrib]

theorem companion_pencil_mulVec (a : Fin (n+1) → ℝ) (s : ℝ)
    (x : Fin (n+1) → ℝ) :
    pencil (companion a) s *ᵥ x = s • x - companion a *ᵥ x := by
  simp [pencil, sub_mulVec, smul_mulVec]

-- The shift equations determine every homogeneous coordinate from x₀.
theorem vector_eq_monomial_of_recurrence {x : Fin (n+1) → ℝ} {s : ℝ}
    (h : ∀ i : Fin n, x i.succ = s*x i.castSucc) :
    ∀ j, x j = s^(j:ℕ)*x 0 := by
  intro j
  induction j using Fin.induction with
  | zero => simp
  | succ j ih =>
    rw [h j, ih]
    simp only [Fin.val_succ, Fin.val_castSucc, pow_succ]
    ring

-- A zero pencil vector is zero whenever the denominator is nonzero.
theorem companion_pencil_kernel_eq_zero (a : Fin (n+1) → ℝ) (s : ℝ)
    (hs : denominatorValue a s ≠ 0) {x : Fin (n+1) → ℝ}
    (hx : pencil (companion a) s *ᵥ x = 0) : x = 0 := by
  have hrec : ∀ i : Fin n, x i.succ = s*x i.castSucc := by
    intro i
    have hh := congrFun hx i.castSucc
    rw [companion_pencil_mulVec] at hh
    simp only [Pi.sub_apply, Pi.smul_apply, smul_eq_mul,
      companion_mulVec_castSucc, Pi.zero_apply] at hh
    linarith
  have hv := vector_eq_monomial_of_recurrence hrec
  have hl := congrFun hx (Fin.last n)
  rw [companion_pencil_mulVec] at hl
  simp only [Pi.sub_apply, Pi.smul_apply, smul_eq_mul, companion_mulVec_last,
    Pi.zero_apply, sub_neg_eq_add] at hl
  have hm : denominatorValue a s*x 0 = 0 := by
    have hsum : (∑ j, a j*x j) = (∑ j, a j*s^(j:ℕ))*x 0 := by
      rw [Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro j hj
      rw [hv j]
      ring
    rw [hv (Fin.last n), hsum] at hl
    simp only [Fin.val_last] at hl
    unfold denominatorValue
    rw [pow_succ]
    convert hl using 1
    ring
  have hz : x 0=0 := (mul_eq_zero.mp hm).resolve_left hs
  ext j
  rw [hv, hz, mul_zero]
  rfl

-- Nonsingularity is derived from those coordinate equations.
theorem companion_pencil_det_ne_zero (a : Fin (n+1) → ℝ) (s : ℝ)
    (hs : denominatorValue a s ≠ 0) : (pencil (companion a) s).det ≠ 0 := by
  apply IsUnit.ne_zero
  apply (Matrix.isUnit_iff_isUnit_det _).mp
  apply Matrix.mulVec_injective_iff_isUnit.mp
  intro x y hxy
  apply sub_eq_zero.mp
  apply companion_pencil_kernel_eq_zero a s hs
  rw [mulVec_sub, hxy, sub_self]

-- The unscaled resolvent column is calculated without taking a matrix inverse.
theorem companion_pencil_monomial (a : Fin (n+1) → ℝ) (s : ℝ) :
    pencil (companion a) s *ᵥ monomialVector n s =
      denominatorValue a s • inputVector n := by
  ext i
  induction i using Fin.lastCases with
  | last =>
    rw [companion_pencil_mulVec]
    simp only [Pi.sub_apply, Pi.smul_apply, smul_eq_mul, companion_mulVec_last,
      inputVector, ite_true, mul_one, monomialVector, Fin.val_last, denominatorValue]
    rw [pow_succ]
    ring
  | cast i =>
    rw [companion_pencil_mulVec]
    simp [Pi.sub_apply, Pi.smul_apply, smul_eq_mul, companion_mulVec_castSucc,
      inputVector, monomialVector, Fin.castSucc_ne_last, pow_succ, mul_comm]

/-- The exact forced resolvent state, for a non-pole real frequency. -/
noncomputable def resolventState (a : Fin (n+1) → ℝ) (s : ℝ) : Fin (n+1) → ℝ :=
  (denominatorValue a s)⁻¹ • monomialVector n s

theorem companion_pencil_resolventState (a : Fin (n+1) → ℝ) (s : ℝ)
    (hs : denominatorValue a s ≠ 0) :
    pencil (companion a) s *ᵥ resolventState a s = inputVector n := by
  rw [resolventState, mulVec_smul, companion_pencil_monomial, smul_smul,
    inv_mul_cancel₀ hs, one_smul]

theorem companion_inverse_input (a : Fin (n+1) → ℝ) (s : ℝ)
    (hs : denominatorValue a s ≠ 0) :
    (pencil (companion a) s)⁻¹ *ᵥ inputVector n = resolventState a s := by
  rw [← companion_pencil_resolventState a s hs, mulVec_mulVec,
    nonsing_inv_mul _ (isUnit_iff_ne_zero.mpr (companion_pencil_det_ne_zero a s hs)),
    one_mulVec]

-- The actual inverse-pencil transfer is exactly the requested rational ratio.
theorem companion_transfer (a b : Fin (n+1) → ℝ) (s : ℝ)
    (hs : denominatorValue a s ≠ 0) :
    ((b ᵥ* (pencil (companion a) s)⁻¹) ⬝ᵥ inputVector n) =
      numeratorValue b s / denominatorValue a s := by
  rw [← dotProduct_mulVec, companion_inverse_input a s hs]
  simp only [dotProduct, resolventState, Pi.smul_apply, smul_eq_mul,
    monomialVector, numeratorValue, div_eq_mul_inv]
  rw [Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro j hj
  ring

-- The coefficient form identifies the DC value without a spectral assumption.
theorem denominatorValue_zero (a : Fin (n+1) → ℝ) : denominatorValue a 0 = a 0 := by
  simp [denominatorValue, Fin.sum_univ_succ]

theorem numeratorValue_zero (b : Fin (n+1) → ℝ) : numeratorValue b 0 = b 0 := by
  simp [numeratorValue, Fin.sum_univ_succ]

/-- The equilibrium is constructed from the actual DC forced resolvent. -/
noncomputable def equilibriumState (a : Fin (n+1) → ℝ) (k : ℝ) : Fin (n+1) → ℝ :=
  k⁻¹ • resolventState a 0

-- The physical plant equilibrium equation needs no separately supplied state.
theorem companion_equilibrium (a : Fin (n+1) → ℝ) (k : ℝ)
    (h0 : denominatorValue a 0 ≠ 0) :
    ∀ j, (∑ l, companion a j l*equilibriumState a k l)+inputVector n j/k=0 := by
  have hp := companion_pencil_resolventState a 0 h0
  rw [companion_pencil_mulVec] at hp
  simp only [zero_smul, zero_sub] at hp
  have ha : companion a *ᵥ resolventState a 0 = -inputVector n := neg_eq_iff_eq_neg.mp hp
  intro j
  have hh := congrFun (show companion a *ᵥ equilibriumState a k =
      k⁻¹ • (-inputVector n) by rw [equilibriumState, mulVec_smul, ha]) j
  have hh' : (∑ l, companion a j l*equilibriumState a k l) = -(inputVector n j)/k := by
    simpa only [mulVec, dotProduct, Pi.smul_apply, smul_eq_mul, Pi.neg_apply,
      div_eq_mul_inv, mul_comm] using hh
  rw [hh']
  ring

-- The output of the constructed equilibrium is the rational DC gain divided
-- by the normalization gain. It is one for the plant's own static gain.
theorem companion_equilibrium_output (a b : Fin (n+1) → ℝ) (k : ℝ) :
    (∑ j, b j*equilibriumState a k j) =
      (numeratorValue b 0 / denominatorValue a 0)/k := by
  simp only [equilibriumState, resolventState, Pi.smul_apply, smul_eq_mul,
    monomialVector, numeratorValue, div_eq_mul_inv]
  rw [Finset.sum_mul, Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro j hj
  ring

theorem companion_unit_output (a b : Fin (n+1) → ℝ)
    (hk : numeratorValue b 0 / denominatorValue a 0 ≠ 0) :
    (∑ j, b j*equilibriumState a (numeratorValue b 0 / denominatorValue a 0) j)=1 := by
  rw [companion_equilibrium_output, div_self hk]

-- The normalized transfer used by the full physical family is the rational
-- numerator/denominator divided by its static gain, at every non-pole point.
theorem companion_normalizedTransfer (a b : Fin (n+1) → ℝ) (k s : ℝ)
    (hs : denominatorValue a s ≠ 0) :
    normalizedTransfer (companion a) (inputVector n) b k s =
      (numeratorValue b s / denominatorValue a s)/k := by
  exact congrArg (fun x : ℝ => x/k) (companion_transfer a b s hs)

/-- A complete static physical model is assembled from rational coefficients.
The internal stability assumption refers to this implemented companion plant
and the shared controller, precisely as in the article. All equilibrium and
DC-regularity fields are derived above. -/
noncomputable def companionData (a b : Fin (n+1) → ℝ)
    (Kp Ti Td Tf L : ℝ)
    (hKp : 0<Kp) (hTi : 0<Ti) (hTd : 0<Td) (hTf : 0<Tf) (hL : 0≤L)
    (h0 : denominatorValue a 0 ≠ 0)
    (hk : 0 < numeratorValue b 0 / denominatorValue a 0)
    (hs : Article14.IsRetardedSharedExponentiallyStable (Article14.finitePlantOutput b)
      (Article14.finitePlantDynamics (companion a) (inputVector n))
      Kp Ti Td Tf L 0 0) : Article14.StablePIDFData (Fin (n+1)) where
  A := companion a
  B := inputVector n
  C := b
  xInf := equilibriumState a (numeratorValue b 0 / denominatorValue a 0)
  Kp := Kp
  Ti := Ti
  Td := Td
  Tf := Tf
  k := numeratorValue b 0 / denominatorValue a 0
  L := L
  Kp_pos := hKp
  Ti_pos := hTi
  Td_pos := hTd
  Tf_pos := hTf
  k_pos := hk
  L_nonneg := hL
  equilibrium := companion_equilibrium a _ h0
  unit_output := companion_unit_output a b hk.ne'
  nonsingular := companion_pencil_det_ne_zero a 0 h0
  stable := hs

end Article14.RationalRealization
