import Mathlib.Analysis.Complex.Trigonometric
import Mathlib.Analysis.Calculus.Deriv.Slope
import Mathlib.Analysis.SpecialFunctions.ImproperIntegrals
import Mathlib.Tactic

/-!
# Article 14: pole mismatch and modal envelopes

The normalized reference polynomial is evaluated at the actual complex pole.
The disk bound includes an attaining displacement, rather than only a triangle
inequality. Residue-limit results below use the derivative of the actual local
denominator. Modal envelopes are statements about the explicitly specified
conjugate-pair contribution; they are not bounds on the complete transient.
-/

namespace Article14
open Complex Filter Set MeasureTheory
open scoped Topology

noncomputable def nominalFactor (p z : ℂ) : ℂ :=
  (z-p)*(z-star p)/((‖p‖^2 : ℝ) : ℂ)

noncomputable def diskRadius (p : ℂ) (ε : ℝ) : ℝ :=
  ε*(2*|p.im|+ε)/‖p‖^2

-- Article 14, Theorem 7: the exact displacement identity.
theorem nominalFactor_displacement (p e : ℂ) :
    nominalFactor p (p+e) = e*((2 : ℂ)*I*(p.im : ℂ)+e)/((‖p‖^2 : ℝ) : ℂ) := by
  have hconj : p-star p = (2 : ℂ)*I*(p.im : ℂ) := by
    apply Complex.ext <;> simp <;> ring
  unfold nominalFactor
  rw [show p+e-p=e by ring, show p+e-star p=(p-star p)+e by ring, hconj]

theorem norm_twice_imaginary (p : ℂ) :
    ‖(2 : ℂ)*I*(p.im : ℂ)‖ = 2*|p.im| := by
  simp [Complex.norm_real]

theorem norm_real_mul_I (x : ℝ) : ‖(x : ℂ)*I‖=|x| := by simp

theorem norm_real_square (x : ℝ) : ‖((x^2 : ℝ) : ℂ)‖=x^2 := by
  rw [Complex.norm_real, Real.norm_of_nonneg (sq_nonneg _)]

theorem diskRadius_nonneg (p : ℂ) {ε : ℝ} (hε : 0≤ε) :
    0≤diskRadius p ε := by
  unfold diskRadius
  positivity

-- Article 14, Theorem 7: this uses the true complex modulus.
theorem nominalFactor_disk_bound (p e : ℂ) {ε : ℝ} (he : ‖e‖≤ε) :
    ‖nominalFactor p (p+e)‖ ≤ diskRadius p ε := by
  have hε : 0≤ε := (norm_nonneg e).trans he
  rw [nominalFactor_displacement, norm_div, norm_mul]
  have hden : ‖((‖p‖^2 : ℝ) : ℂ)‖=‖p‖^2 := by
    rw [Complex.norm_real, Real.norm_of_nonneg (sq_nonneg _)]
  rw [hden]
  unfold diskRadius
  apply div_le_div_of_nonneg_right _ (sq_nonneg _)
  apply mul_le_mul he _ (norm_nonneg _) hε
  calc
    ‖(2 : ℂ)*I*(p.im : ℂ)+e‖ ≤ ‖(2 : ℂ)*I*(p.im : ℂ)‖+‖e‖ := norm_add_le _ _
    _ ≤ 2*|p.im|+ε := by rw [norm_twice_imaginary]; linarith

-- The two extremal directions make sharpness valid even for a real nominal pole.
theorem nominalFactor_disk_attained (p : ℂ) {ε : ℝ} (hε : 0≤ε) :
    ∃ e : ℂ, ‖e‖=ε ∧ ‖nominalFactor p (p+e)‖=diskRadius p ε := by
  by_cases him : 0≤p.im
  · refine ⟨(ε : ℂ)*I, ?_, ?_⟩
    · simp [Complex.norm_real, abs_of_nonneg hε]
    · rw [nominalFactor_displacement, norm_div, norm_mul]
      have hsum : (2 : ℂ)*I*(p.im : ℂ)+(ε : ℂ)*I=((2*p.im+ε : ℝ) : ℂ)*I := by
        push_cast
        ring
      rw [hsum]
      rw [norm_real_mul_I, norm_real_mul_I, norm_real_square,
        abs_of_nonneg hε, abs_of_nonneg (by positivity : 0≤2*p.im+ε)]
      simp [diskRadius, abs_of_nonneg him]
  · have him' : p.im≤0 := le_of_not_ge him
    refine ⟨-(ε : ℂ)*I, ?_, ?_⟩
    · simp [Complex.norm_real, abs_of_nonneg hε]
    · rw [nominalFactor_displacement, norm_div, norm_mul]
      have hsum : (2 : ℂ)*I*(p.im : ℂ)+(-(ε : ℂ)*I)=((2*p.im-ε : ℝ) : ℂ)*I := by
        push_cast
        ring
      rw [hsum]
      have hs : 2*p.im-ε≤0 := by linarith
      rw [norm_real_mul_I, norm_real_square, abs_of_nonpos hs]
      simp only [norm_mul, norm_neg, Complex.norm_I, mul_one, Complex.norm_real,
        Real.norm_eq_abs, abs_of_nonneg hε]
      simp only [diskRadius, abs_of_nonpos him']
      ring

-- Full mathematical content of Article 14, Theorem 7, including sharpness.
-- @paper-step thm:disk-bound/full_statement
theorem paper_tight_disk_mismatch (p : ℂ) (_hp : p≠0) (ε : ℝ) (hε : 0≤ε) :
    (∀ e : ℂ, ‖e‖≤ε →
      nominalFactor p (p+e)=e*((2 : ℂ)*I*(p.im : ℂ)+e)/((‖p‖^2 : ℝ) : ℂ) ∧
      ‖nominalFactor p (p+e)‖≤diskRadius p ε) ∧
    ∃ e : ℂ, ‖e‖=ε ∧ ‖nominalFactor p (p+e)‖=diskRadius p ε := by
  exact ⟨fun e he => ⟨nominalFactor_displacement p e, nominalFactor_disk_bound p e he⟩,
    nominalFactor_disk_attained p hε⟩

-- A genuine local limit specifies the simple-pole coefficient. It also permits
-- coefficient zero, when the reference numerator cancels that pole.
def HasSimpleResidue (T : ℂ → ℂ) (p r : ℂ) : Prop :=
  Tendsto (fun z => (z-p)*T z) (𝓝[≠] p) (𝓝 r)

theorem HasSimpleResidue.unique {T : ℂ → ℂ} {p r₁ r₂ : ℂ}
    (h₁ : HasSimpleResidue T p r₁) (h₂ : HasSimpleResidue T p r₂) : r₁=r₂ :=
  tendsto_nhds_unique h₁ h₂

theorem nominalFactor_continuous (p : ℂ) : Continuous (nominalFactor p) := by
  unfold nominalFactor
  fun_prop

-- Article 14, equation (simple-pole residue): derive the coefficient from
-- the derivative of the actual denominator, not from a named algebraic proxy.
theorem simple_residue_of_derivative {A D : ℂ → ℂ} {p d : ℂ}
    (hA : ContinuousAt A p) (hD : HasDerivAt D d p)
    (hz : D p=0) (hd : d≠0) :
    HasSimpleResidue (fun z => A z/D z) p (A p/d) := by
  have hs : Tendsto (fun z => D z/(z-p)) (𝓝[≠] p) (𝓝 d) := by
    have heq : slope D p = fun z => D z/(z-p) := by
      funext z
      rw [slope_def_field, hz, sub_zero]
    rw [←heq]
    exact hD.tendsto_slope
  have hlim := (hA.tendsto.mono_left nhdsWithin_le_nhds).div hs hd
  change Tendsto (fun z => A z/(D z/(z-p))) (𝓝[≠] p) (𝓝 (A p/d)) at hlim
  unfold HasSimpleResidue
  convert hlim using 1
  funext z
  simp only [div_div_eq_mul_div]
  ring

theorem simple_step_residue {A D : ℂ → ℂ} {p d : ℂ}
    (hA : ContinuousAt A p) (hD : HasDerivAt D d p)
    (hz : D p=0) (hd : d≠0) (hp : p≠0) :
    HasSimpleResidue (fun z => (A z/D z)/z) p ((A p/d)/p) := by
  have hnum : ContinuousAt (fun z => A z/z) p := hA.div continuousAt_id hp
  have h := simple_residue_of_derivative hnum hD hz hd
  have heq : (fun z => (A z/D z)/z)=(fun z => (A z/z)/D z) := by
    funext z
    ring
  rw [heq]
  convert h using 1
  ring

theorem residue_disk_bound (p e w : ℂ) {ε M : ℝ}
    (he : ‖e‖≤ε) (hw : ‖w‖≤M) :
    ‖w*nominalFactor p (p+e)‖ ≤ M*diskRadius p ε := by
  have hε : 0≤ε := (norm_nonneg e).trans he
  rw [norm_mul]
  exact mul_le_mul hw (nominalFactor_disk_bound p e he) (norm_nonneg _)
    ((norm_nonneg w).trans hw)

-- Pointwise version of Article 14, Corollary 8. Uniform application to a
-- scenario family only adds universal quantification. Compactness and pole
-- separation are not needed once the stated prefactor bound is supplied.
theorem paper_residue_bound {H D : ℂ → ℂ} {p phat d : ℂ} {ε M : ℝ}
    (hH : ContinuousAt H p) (hD : HasDerivAt D d p)
    (hz : D p=0) (hd : d≠0) (he : ‖p-phat‖≤ε)
    (hw : ‖H p/d‖≤M) :
    HasSimpleResidue (fun z => H z*nominalFactor phat z/D z) p
      (H p*nominalFactor phat p/d) ∧
    ‖H p*nominalFactor phat p/d‖≤M*diskRadius phat ε := by
  refine ⟨simple_residue_of_derivative
    (hH.mul (nominalFactor_continuous phat).continuousAt) hD hz hd, ?_⟩
  have h := residue_disk_bound phat (p-phat) (H p/d) he hw
  convert h using 1
  congr 1
  rw [show phat+(p-phat)=p by ring]
  ring

-- @paper-step cor:residue-bound/full_statement
theorem paper_uniform_residue_bound {Θ : Type*}
    (H D : Θ → ℂ → ℂ) (p d : Θ → ℂ) (phat : ℂ) (ε M : ℝ)
    (hH : ∀ θ, ContinuousAt (H θ) (p θ))
    (hD : ∀ θ, HasDerivAt (D θ) (d θ) (p θ))
    (hz : ∀ θ, D θ (p θ)=0) (hd : ∀ θ, d θ≠0)
    (he : ∀ θ, ‖p θ-phat‖≤ε) (hw : ∀ θ, ‖H θ (p θ)/d θ‖≤M) :
    ∀ θ, HasSimpleResidue (fun z => H θ z*nominalFactor phat z/D θ z) (p θ)
      (H θ (p θ)*nominalFactor phat (p θ)/d θ) ∧
      ‖H θ (p θ)*nominalFactor phat (p θ)/d θ‖≤M*diskRadius phat ε := by
  intro θ
  exact paper_residue_bound (hH θ) (hD θ) (hz θ) (hd θ) (he θ) (hw θ)

noncomputable def conjugatePair (a p : ℂ) (t : ℝ) : ℂ :=
  a*Complex.exp (p*(t : ℂ)) + star a*Complex.exp (star p*(t : ℂ))

theorem modal_laplace_integrand (a p s : ℂ) (t : ℝ) :
    Complex.exp (-s*(t : ℂ))*(a*Complex.exp (p*(t : ℂ))) =
      a*Complex.exp ((p-s)*(t : ℂ)) := by
  calc
    Complex.exp (-s*(t : ℂ))*(a*Complex.exp (p*(t : ℂ))) =
      a*(Complex.exp (-s*(t : ℂ))*Complex.exp (p*(t : ℂ))) := by ring
    _ = a*Complex.exp (-s*(t : ℂ)+p*(t : ℂ)) := by rw [Complex.exp_add]
    _ = a*Complex.exp ((p-s)*(t : ℂ)) := by (congr 2; ring)

theorem modal_laplace_integrable (a p s : ℂ) (hs : p.re<s.re) :
    IntegrableOn (fun t : ℝ => Complex.exp (-s*(t : ℂ))*(a*Complex.exp (p*(t : ℂ))))
      (Ioi 0) := by
  simp_rw [modal_laplace_integrand]
  exact (integrableOn_exp_mul_complex_Ioi (by simpa using sub_neg.mpr hs) 0).const_mul a

-- This integral bridge identifies the exponential mode with its actual
-- Laplace simple-fraction term; the word "mode" is not just a definition.
theorem modal_laplace (a p s : ℂ) (hs : p.re<s.re) :
    (∫ t : ℝ in Ioi 0, Complex.exp (-s*(t : ℂ))*(a*Complex.exp (p*(t : ℂ)))) =
      a/(s-p) := by
  simp_rw [modal_laplace_integrand]
  rw [integral_const_mul,
    integral_exp_mul_complex_Ioi (by simpa using sub_neg.mpr hs) 0]
  simp only [Complex.ofReal_zero, mul_zero, Complex.exp_zero]
  have hne : p-s≠0 := by
    intro h
    have hr := congrArg Complex.re h
    simp at hr
    linarith
  have hne' : s-p≠0 := by
    intro h
    apply hne
    linear_combination -h
  field_simp [hne, hne']
  ring

theorem conjugatePair_laplace (a p s : ℂ) (hs : p.re<s.re) :
    (∫ t : ℝ in Ioi 0, Complex.exp (-s*(t : ℂ))*conjugatePair a p t) =
      a/(s-p)+star a/(s-star p) := by
  have hs' : (star p).re<s.re := by simpa using hs
  simp_rw [conjugatePair, mul_add]
  rw [integral_add (modal_laplace_integrable a p s hs)
    (modal_laplace_integrable (star a) (star p) s hs'),
    modal_laplace a p s hs, modal_laplace (star a) (star p) s hs']

theorem conjugatePair_eq_real (a p : ℂ) (t : ℝ) :
    conjugatePair a p t = ((2*(a*Complex.exp (p*(t : ℂ))).re : ℝ) : ℂ) := by
  have he : Complex.exp (star p*(t : ℂ))=star (Complex.exp (p*(t : ℂ))) := by
    have harg : star p*(t : ℂ)=star (p*(t : ℂ)) := by simp
    rw [harg]
    exact Complex.exp_conj _
  unfold conjugatePair
  rw [he, ←star_mul]
  apply Complex.ext <;> simp <;> ring

-- Article 14, conjugate-pair envelope. This estimate retains the true pole.
theorem conjugatePair_envelope (a p : ℂ) (t : ℝ) :
    ‖conjugatePair a p t‖ ≤ 2*‖a‖*Real.exp (p.re*t) := by
  unfold conjugatePair
  calc
    ‖a*Complex.exp (p*(t : ℂ)) + star a*Complex.exp (star p*(t : ℂ))‖
      ≤ ‖a*Complex.exp (p*(t : ℂ))‖ + ‖star a*Complex.exp (star p*(t : ℂ))‖ :=
        norm_add_le _ _
    _ = 2*‖a‖*Real.exp (p.re*t) := by
      simp [Complex.norm_exp]
      ring

theorem conjugatePair_uniform_envelope {r p : ℂ} {R m α t : ℝ}
    (hr : ‖r‖≤R) (hm : 0<m) (hp : m≤‖p‖)
    (hα : α≤-p.re) (ht : 0≤t) :
    ‖conjugatePair (r/p) p t‖ ≤ (2*R/m)*Real.exp (-α*t) := by
  have hR : 0≤R := (norm_nonneg r).trans hr
  have ha : ‖r/p‖≤R/m := by
    rw [norm_div]
    exact div_le_div₀ hR hr hm hp
  have he : Real.exp (p.re*t)≤Real.exp (-α*t) := by
    apply Real.exp_le_exp.mpr
    nlinarith
  calc
    ‖conjugatePair (r/p) p t‖ ≤ 2*‖r/p‖*Real.exp (p.re*t) := conjugatePair_envelope _ _ _
    _ ≤ 2*(R/m)*Real.exp (-α*t) :=
      mul_le_mul (mul_le_mul_of_nonneg_left ha (by norm_num)) he
        (Real.exp_nonneg _) (by positivity)
    _ = (2*R/m)*Real.exp (-α*t) := by ring

-- Article 14, Corollary 9: the actual step-transfer residue and its modal
-- envelope are obtained together. This does not assert that this single pair
-- is the entire transient, nor impose a finite modal expansion on a delay.
-- @paper-step cor:step-mismatch/full_selected_pair_statement
theorem paper_step_mismatch {H D : ℂ → ℂ} {p phat d : ℂ} {ε M m α : ℝ}
    (hH : ContinuousAt H p) (hD : HasDerivAt D d p)
    (hz : D p=0) (hd : d≠0) (he : ‖p-phat‖≤ε)
    (hw : ‖H p/d‖≤M) (hm : 0<m) (hp : m≤‖p‖) (hα : α≤-p.re) :
    let r := H p*nominalFactor phat p/d
    HasSimpleResidue (fun z => (H z*nominalFactor phat z/D z)/z) p (r/p) ∧
      ∀ t : ℝ, 0≤t → ‖conjugatePair (r/p) p t‖ ≤
        (2*M/m)*diskRadius phat ε*Real.exp (-α*t) := by
  dsimp only
  have hpne : p≠0 := norm_pos_iff.mp (lt_of_lt_of_le hm hp)
  refine ⟨simple_step_residue
    (hH.mul (nominalFactor_continuous phat).continuousAt) hD hz hd hpne, ?_⟩
  intro t ht
  have hr := (paper_residue_bound hH hD hz hd he hw).2
  have hb := conjugatePair_uniform_envelope hr hm hp hα ht
  convert hb using 1
  ring

end Article14
