import Article14.RationalMinimality

/-!
# Any implemented minimal rational realization supplies the physical family

Minimality and the reduced plant quotient force the state characteristic
polynomial to be a nonzero scalar multiple of the plant denominator. Thus
absence of a plant pole at DC implies nonsingularity of the actual state
matrix. Its equilibrium is then constructed, with unit output proved from the
actual DC transfer. No choice of a different implementation is required.
-/
namespace Article14.RationalRealization
open Polynomial Matrix Finset Filter
open Article14.PhysicalPlant
open scoped Matrix

variable {m : Type*} [Fintype m] [DecidableEq m]

-- Exact minimal dimension removes every extra characteristic factor.
theorem characteristic_eq_constant_mul_den (P : RationalPlant) (A : Matrix m m ℝ)
    (B C₀ : m → ℝ) (hr : Realizes P A B C₀)
    (hdim : Fintype.card m=P.den.natDegree) :
    ∃ c : ℝ, c≠0 ∧ A.charpoly=Polynomial.C c*P.den := by
  obtain ⟨q, hq⟩ := reduced_denominator_dvd_charpoly P A B C₀ hr
  have hqn : q≠0 := by
    intro hz
    apply A.charpoly_monic.ne_zero
    simp [hq, hz]
  have hdeg : q.natDegree=0 := by
    have hd := congrArg Polynomial.natDegree hq
    rw [Matrix.charpoly_natDegree_eq_dim, Polynomial.natDegree_mul P.den_ne_zero hqn,
      hdim] at hd
    omega
  have hc : q.coeff 0 ≠ 0 := by
    intro hz
    apply hqn
    rw [Polynomial.eq_C_of_natDegree_eq_zero hdeg, hz, Polynomial.C_0]
  refine ⟨q.coeff 0, hc, ?_⟩
  rw [hq, Polynomial.eq_C_of_natDegree_eq_zero hdeg, mul_comm]
  simp

theorem minimal_pencil_nonsingular_zero (P : RationalPlant) (A : Matrix m m ℝ)
    (B C₀ : m → ℝ) (hr : Realizes P A B C₀)
    (hdim : Fintype.card m=P.den.natDegree) : (pencil A 0).det≠0 := by
  obtain ⟨c, hc, he⟩ := characteristic_eq_constant_mul_den P A B C₀ hr hdim
  rw [← charpoly_eval_pencil, he, Polynomial.eval_mul, Polynomial.eval_C]
  exact mul_ne_zero hc P.no_pole_zero

/-- Minimality compares the actual transfer with all finite matrix
realizations; every finite number of competitor states is covered. -/
def IsMinimalRealization (P : RationalPlant) (A : Matrix m m ℝ) (B C₀ : m → ℝ) : Prop :=
  Realizes P A B C₀ ∧ ∀ (N : ℕ) (A' : Matrix (Fin N) (Fin N) ℝ)
    (B' C' : Fin N → ℝ), Realizes P A' B' C' → Fintype.card m≤N

-- The separately proved companion lower bound identifies the exact dimension
-- of every implementation satisfying the article's minimality hypothesis.
theorem minimal_dimension_eq (P : RationalPlant) (A : Matrix m m ℝ) (B C₀ : m → ℝ)
    (hm : IsMinimalRealization P A B C₀) : Fintype.card m=P.den.natDegree := by
  apply le_antisymm
  · have hh := hm.2 (P.order+1) P.stateMatrix P.input P.output P.companion_realizes
    simpa only [← P.degree_eq_order_succ] using hh
  · exact realization_dimension_lower_bound P A B C₀ hm.1

theorem RationalPlant.companion_isMinimalRealization (P : RationalPlant) :
    IsMinimalRealization P P.stateMatrix P.input P.output := by
  refine ⟨P.companion_realizes, ?_⟩
  intro N A B C₀ hr
  simpa only [Fintype.card_fin] using P.companion_minimal_dimension A B C₀ hr

/-- The DC equilibrium of the given implemented state matrix. -/
noncomputable def realizedEquilibrium (A : Matrix m m ℝ) (B : m → ℝ) (k : ℝ) : m → ℝ :=
  k⁻¹ • ((pencil A 0)⁻¹ *ᵥ B)

theorem realizedEquilibrium_equation (A : Matrix m m ℝ) (B : m → ℝ) (k : ℝ)
    (hA : (pencil A 0).det ≠ 0) :
    ∀ j, (∑ l, A j l*realizedEquilibrium A B k l)+B j/k=0 := by
  have hp : pencil A 0 *ᵥ ((pencil A 0)⁻¹ *ᵥ B) = B := by
    rw [mulVec_mulVec, mul_nonsing_inv _ (isUnit_iff_ne_zero.mpr hA), one_mulVec]
  have ha : A *ᵥ ((pencil A 0)⁻¹ *ᵥ B) = -B := by
    simp only [pencil, zero_smul, zero_sub, neg_mulVec] at hp
    simpa only [pencil, zero_smul, zero_sub] using neg_eq_iff_eq_neg.mp hp
  intro j
  have hh := congrFun (show A *ᵥ realizedEquilibrium A B k = k⁻¹ • (-B) by
    rw [realizedEquilibrium, mulVec_smul, ha]) j
  have hh' : (∑ l, A j l*realizedEquilibrium A B k l) = -B j/k := by
    simpa only [mulVec, dotProduct, Pi.smul_apply, smul_eq_mul, Pi.neg_apply,
      div_eq_mul_inv, mul_comm] using hh
  rw [hh']
  ring

theorem realizedEquilibrium_unit_output (P : RationalPlant) (A : Matrix m m ℝ)
    (B C₀ : m → ℝ) (hr : Realizes P A B C₀) (hA : (pencil A 0).det≠0) :
    (∑ j, C₀ j*realizedEquilibrium A B P.dcGain j)=1 := by
  have hd : A.charpoly.eval 0≠0 := by rw [charpoly_eval_pencil]; exact hA
  have ht := hr 0 P.no_pole_zero hd
  change C₀ ⬝ᵥ (P.dcGain⁻¹ • ((pencil A 0)⁻¹ *ᵥ B)) = 1
  rw [dotProduct_smul, dotProduct_mulVec, ht]
  change P.dcGain⁻¹*P.dcGain=1
  exact inv_mul_cancel₀ P.positive_dc.ne'

/-- The article's arbitrary implemented minimal plant and its internally
stable shared PIDF loop yield all physical data required by Theorems 14–17.
DC invertibility and the equilibrium are conclusions, not extra hypotheses. -/
noncomputable def minimalStableFamily (P : RationalPlant) (A : Matrix m m ℝ) (B C₀ : m → ℝ)
    (hm : IsMinimalRealization P A B C₀) (Kp Ti Td Tf L : ℝ)
    (hKp : 0<Kp) (hTi : 0<Ti) (hTd : 0<Td) (hTf : 0<Tf) (hL : 0≤L)
    (hs : Article14.IsRetardedSharedExponentiallyStable (Article14.finitePlantOutput C₀)
      (Article14.finitePlantDynamics A B) Kp Ti Td Tf L 0 0) : Article14.StablePIDFData m where
  A := A
  B := B
  C := C₀
  xInf := realizedEquilibrium A B P.dcGain
  Kp := Kp
  Ti := Ti
  Td := Td
  Tf := Tf
  k := P.dcGain
  L := L
  Kp_pos := hKp
  Ti_pos := hTi
  Td_pos := hTd
  Tf_pos := hTf
  k_pos := P.positive_dc
  L_nonneg := hL
  equilibrium := realizedEquilibrium_equation A B P.dcGain
    (minimal_pencil_nonsingular_zero P A B C₀ hm.1 (minimal_dimension_eq P A B C₀ hm))
  unit_output := realizedEquilibrium_unit_output P A B C₀ hm.1
    (minimal_pencil_nonsingular_zero P A B C₀ hm.1 (minimal_dimension_eq P A B C₀ hm))
  nonsingular := minimal_pencil_nonsingular_zero P A B C₀ hm.1
    (minimal_dimension_eq P A B C₀ hm)
  stable := hs

-- The same DC derivative identification holds for the given minimal
-- implementation, so the MIACE parameter uses the manuscript's P₀'(0).
theorem minimal_realization_residenceTime (P : RationalPlant) (A : Matrix m m ℝ)
    (B C₀ : m → ℝ) (hm : IsMinimalRealization P A B C₀) :
    residenceTime A C₀ (realizedEquilibrium A B P.dcGain) =
      -(deriv P.transfer 0)/P.dcGain := by
  have hA := minimal_pencil_nonsingular_zero P A B C₀ hm.1
    (minimal_dimension_eq P A B C₀ hm)
  have hchar : A.charpoly.eval 0≠0 := by rw [charpoly_eval_pencil]; exact hA
  have hr := P.transfer_hasDerivAt_zero
  have hn : HasDerivAt (normalizedTransfer A B C₀ P.dcGain)
      ((deriv P.transfer 0)/P.dcGain) 0 := by
    rw [hr.deriv]
    apply (hr.div_const P.dcGain).congr_of_eventuallyEq
    filter_upwards [P.den.continuous.continuousAt.eventually_ne P.no_pole_zero,
      A.charpoly.continuous.continuousAt.eventually_ne hchar] with s hd hc
    exact congrArg (fun x : ℝ => x/P.dcGain) (hm.1 s hd hc)
  have hd := normalizedTransfer_hasDerivAt_zero
    (realizedEquilibrium_equation A B P.dcGain hA)
    (realizedEquilibrium_unit_output P A B C₀ hm.1 hA) hA
  have hh := hd.unique hn
  rw [neg_div]
  linarith

theorem minimalStableFamily_gamma (P : RationalPlant) (A : Matrix m m ℝ) (B C₀ : m → ℝ)
    (hm : IsMinimalRealization P A B C₀) (Kp Ti Td Tf L : ℝ)
    (hKp : 0<Kp) (hTi : 0<Ti) (hTd : 0<Td) (hTf : 0<Tf) (hL : 0≤L)
    (hs : Article14.IsRetardedSharedExponentiallyStable (Article14.finitePlantOutput C₀)
      (Article14.finitePlantDynamics A B) Kp Ti Td Tf L 0 0) :
    (minimalStableFamily P A B C₀ hm Kp Ti Td Tf L hKp hTi hTd hTf hL hs).gamma =
      L-(deriv P.transfer 0)/P.dcGain := by
  change residenceTime A C₀ (realizedEquilibrium A B P.dcGain)+L = _
  rw [minimal_realization_residenceTime P A B C₀ hm]
  ring

-- No extra poles remain in a minimal realization of the reduced quotient.
theorem minimal_charpoly_ne_zero (P : RationalPlant) (A : Matrix m m ℝ) (B C₀ : m → ℝ)
    (hm : IsMinimalRealization P A B C₀) (s : ℝ) (hs : P.den.eval s≠0) :
    A.charpoly.eval s≠0 := by
  obtain ⟨c, hc, he⟩ := characteristic_eq_constant_mul_den P A B C₀ hm.1
    (minimal_dimension_eq P A B C₀ hm)
  rw [he, Polynomial.eval_mul, Polynomial.eval_C]
  exact mul_ne_zero hc hs

theorem minimal_normalized_transfer (P : RationalPlant) (A : Matrix m m ℝ) (B C₀ : m → ℝ)
    (hm : IsMinimalRealization P A B C₀) (s : ℝ) (hs : P.den.eval s≠0) :
    normalizedTransfer A B C₀ P.dcGain s=P.transfer s/P.dcGain :=
  congrArg (fun x : ℝ => x/P.dcGain) (hm.1 s hs (minimal_charpoly_ne_zero P A B C₀ hm s hs))

end Article14.RationalRealization
