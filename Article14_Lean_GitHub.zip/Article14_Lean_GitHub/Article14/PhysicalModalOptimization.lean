import Article14.ModalOptimization
import Article14.ModalBounds
import Article14.StepUniqueness

/-!
# Physical finite-scenario modal optimization

The residue maps below evaluate the actual PIDF reference polynomial and use
the derivative of the actual selected denominator.  Fixed-time response maps
come from the physical step equations and their uniqueness.  The admitted
polygon, sampled response slabs, cone epigraph, and attained minimum are then
instances of the existing finite convex optimization theorem.
-/
namespace Article14
open Set Filter MeasureTheory
open scoped Topology

/-- The affine map with two real design weights and a real or complex target. -/
noncomputable def twoWeightAffine {E : Type*} [AddCommGroup E] [Module ℝ E]
    (z₀ zb zc : E) : (ℝ × ℝ) →ᵃ[ℝ] E :=
  AffineMap.const ℝ (ℝ × ℝ) z₀ +
    ((LinearMap.fst ℝ ℝ ℝ).smulRight zb).toAffineMap +
    ((LinearMap.snd ℝ ℝ ℝ).smulRight zc).toAffineMap

theorem twoWeightAffine_apply {E : Type*} [AddCommGroup E] [Module ℝ E]
    (z₀ zb zc : E) (w : ℝ × ℝ) :
    twoWeightAffine z₀ zb zc w = z₀ + w.1 • zb + w.2 • zc := rfl

/-- Evaluation of the existing physical normalized reference polynomial. -/
noncomputable def pidfReferenceValue (Ti Td Tf : ℝ) (w : ℝ × ℝ) (z : ℂ) : ℂ :=
  (referenceQuadratic (Tf+w.1*Ti) (Ti*(w.1*Tf+w.2*Td))).eval₂
    (algebraMap ℝ ℂ) z

-- Expanding the implemented polynomial gives precisely the three scenario
-- coefficients printed before Proposition 10.
theorem pidfReferenceValue_affine (Ti Td Tf : ℝ) (w : ℝ × ℝ) (z : ℂ) :
    pidfReferenceValue Ti Td Tf w z =
      (1+(Tf:ℂ)*z) + (w.1:ℂ)*((Ti:ℂ)*z+(Ti:ℂ)*(Tf:ℂ)*z^2) +
        (w.2:ℂ)*((Ti:ℂ)*(Td:ℂ)*z^2) := by
  simp only [pidfReferenceValue, referenceQuadratic, Polynomial.eval₂_add,
    Polynomial.eval₂_one, Polynomial.eval₂_mul, Polynomial.eval₂_C,
    Polynomial.eval₂_X, Polynomial.eval₂_pow, map_add, map_mul, Complex.coe_algebraMap]
  ring

/-- The concrete transfer-residue affine map at a selected simple pole. -/
noncomputable def pidfResidueAffine (Kp Ti Td Tf : ℝ) (Bpole d p : ℂ) :
    (ℝ × ℝ) →ᵃ[ℝ] ℂ :=
  twoWeightAffine ((Kp:ℂ)*Bpole/d*(1+(Tf:ℂ)*p))
    ((Kp:ℂ)*Bpole/d*((Ti:ℂ)*p+(Ti:ℂ)*(Tf:ℂ)*p^2))
    ((Kp:ℂ)*Bpole/d*((Ti:ℂ)*(Td:ℂ)*p^2))

/-- The concrete unit-step modal amplitude includes the pole divisor. -/
noncomputable def pidfStepAmplitudeAffine (Kp Ti Td Tf : ℝ) (Bpole d p : ℂ) :
    (ℝ × ℝ) →ᵃ[ℝ] ℂ :=
  twoWeightAffine (((Kp:ℂ)*Bpole/d*(1+(Tf:ℂ)*p))/p)
    (((Kp:ℂ)*Bpole/d*((Ti:ℂ)*p+(Ti:ℂ)*(Tf:ℂ)*p^2))/p)
    (((Kp:ℂ)*Bpole/d*((Ti:ℂ)*(Td:ℂ)*p^2))/p)

theorem pidfResidueAffine_apply (Kp Ti Td Tf : ℝ) (Bpole d p : ℂ) (w : ℝ × ℝ) :
    pidfResidueAffine Kp Ti Td Tf Bpole d p w =
      (Kp:ℂ)*Bpole*pidfReferenceValue Ti Td Tf w p/d := by
  rw [pidfReferenceValue_affine]
  simp only [pidfResidueAffine, twoWeightAffine_apply, Complex.real_smul]
  ring

theorem pidfStepAmplitudeAffine_apply (Kp Ti Td Tf : ℝ) (Bpole d p : ℂ) (w : ℝ × ℝ) :
    pidfStepAmplitudeAffine Kp Ti Td Tf Bpole d p w =
      pidfResidueAffine Kp Ti Td Tf Bpole d p w/p := by
  simp only [pidfStepAmplitudeAffine, pidfResidueAffine, twoWeightAffine_apply,
    Complex.real_smul]
  ring

-- These are genuine punctured-neighborhood residues of the declared transfer;
-- a zero numerator is allowed and gives a cancelled external mode.
theorem pidf_modal_residue_and_step_amplitude
    (Kp Ti Td Tf : ℝ) {B Δ : ℂ → ℂ} {p d : ℂ}
    (hB : ContinuousAt B p) (hΔ : HasDerivAt Δ d p)
    (hzero : Δ p = 0) (hd : d ≠ 0) (hp : p ≠ 0) (w : ℝ × ℝ) :
    HasSimpleResidue (fun z => (Kp:ℂ)*B z*pidfReferenceValue Ti Td Tf w z/Δ z)
      p (pidfResidueAffine Kp Ti Td Tf (B p) d p w) ∧
    HasSimpleResidue (fun z => ((Kp:ℂ)*B z*pidfReferenceValue Ti Td Tf w z/Δ z)/z)
      p (pidfStepAmplitudeAffine Kp Ti Td Tf (B p) d p w) := by
  have hN : ContinuousAt (fun z => (Kp:ℂ)*B z*pidfReferenceValue Ti Td Tf w z) p := by
    simp_rw [pidfReferenceValue_affine]
    fun_prop
  rw [pidfStepAmplitudeAffine_apply, pidfResidueAffine_apply]
  exact ⟨simple_residue_of_derivative hN hΔ hzero hd,
    simple_step_residue hN hΔ hzero hd hp⟩

/-- Compact conventional weight box with the physical initial-command limit. -/
def admittedModalPolygon (Kp Td Tf umax : ℝ) : Set (ℝ × ℝ) :=
  Icc (0,0) (1,1) ∩ {w | Kp*(w.1+(Td/Tf)*w.2) ≤ umax}

-- Both the engineering box and the initial-jump halfspace are closed.
theorem admittedModalPolygon_compact (Kp Td Tf umax : ℝ) :
    IsCompact (admittedModalPolygon Kp Td Tf umax) := by
  apply isCompact_Icc.inter_right
  exact isClosed_le (by fun_prop) continuous_const

-- The actual admitted engineering region is convex, not merely bounded.
theorem admittedModalPolygon_convex (Kp Td Tf umax : ℝ) :
    Convex ℝ (admittedModalPolygon Kp Td Tf umax) := by
  have hb : Convex ℝ (Icc ((0:ℝ), (0:ℝ)) (1,1)) := by
    simpa only [Icc_prod_eq] using (convex_Icc (0:ℝ) 1).prod (convex_Icc (0:ℝ) 1)
  apply hb.inter
  have he : {w : ℝ × ℝ | Kp*(w.1+(Td/Tf)*w.2) ≤ umax} =
      (twoWeightAffine (0:ℝ) Kp (Kp*(Td/Tf))) ⁻¹' Iic umax := by
    ext w
    simp only [mem_ofPred_eq, mem_preimage, mem_Iic, twoWeightAffine_apply,
      smul_eq_mul, zero_add]
    have hh : Kp * (w.1 + Td / Tf * w.2) = w.1 * Kp + w.2 * (Kp * (Td / Tf)) := by ring
    rw [hh]
  rw [he]
  exact (convex_Iic umax).affine_preimage _


-- A nonnegative admitted command bound gives a concrete feasible box point.
theorem admittedModalPolygon_nonempty (Kp Td Tf umax : ℝ) (hu : 0≤umax) :
    (admittedModalPolygon Kp Td Tf umax).Nonempty := by
  refine ⟨(0,0), ?_⟩
  simp [admittedModalPolygon, hu]

/-- A finite collection of two-sided affine engineering bounds. -/
def affineSampleSlabs {ι : Type*} (f : ι → (ℝ × ℝ) →ᵃ[ℝ] ℝ)
    (lower upper : ι → ℝ) : Set (ℝ × ℝ) :=
  {w | ∀ i, lower i ≤ f i w ∧ f i w ≤ upper i}

theorem affineSampleSlabs_closed {ι : Type*} (f : ι → (ℝ × ℝ) →ᵃ[ℝ] ℝ)
    (lower upper : ι → ℝ) : IsClosed (affineSampleSlabs f lower upper) := by
  have he : affineSampleSlabs f lower upper = ⋂ i, (f i) ⁻¹' Icc (lower i) (upper i) := by
    ext w
    simp [affineSampleSlabs]
  rw [he]
  exact isClosed_iInter (fun i => isClosed_Icc.preimage (f i).continuous_of_finiteDimensional)

theorem affineSampleSlabs_convex {ι : Type*} (f : ι → (ℝ × ℝ) →ᵃ[ℝ] ℝ)
    (lower upper : ι → ℝ) : Convex ℝ (affineSampleSlabs f lower upper) := by
  have he : affineSampleSlabs f lower upper = ⋂ i, (f i) ⁻¹' Icc (lower i) (upper i) := by
    ext w
    simp [affineSampleSlabs]
  rw [he]
  exact convex_iInter (fun i => (convex_Icc (lower i) (upper i)).affine_preimage (f i))

variable {n : Type*} [Fintype n]

/-- The actual fixed-time output map obtained from the three basis responses. -/
noncomputable def stepOutputSampleAffine (C : n → ℝ)
    (q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ) (H : ℝ) : (ℝ × ℝ) →ᵃ[ℝ] ℝ :=
  twoWeightAffine (finitePlantOutput C (q00 H).1)
    (finitePlantOutput C (q10 H).1-finitePlantOutput C (q00 H).1)
    (finitePlantOutput C (q01 H).1-finitePlantOutput C (q00 H).1)

/-- The actual fixed-time command includes its affine reference feedthrough. -/
noncomputable def stepCommandSampleAffine (C : n → ℝ) (Kp Ti Td Tf : ℝ)
    (q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ) (H : ℝ) : (ℝ × ℝ) →ᵃ[ℝ] ℝ :=
  twoWeightAffine (stepCommand C Kp Ti Td Tf 0 0 q00 H)
    (stepCommand C Kp Ti Td Tf 1 0 q10 H-stepCommand C Kp Ti Td Tf 0 0 q00 H)
    (stepCommand C Kp Ti Td Tf 0 1 q01 H-stepCommand C Kp Ti Td Tf 0 0 q00 H)

-- Neither physical sample-affinity result assumes a matrix exponential or
-- a supplied affine response: the physical equations proved these maps.
theorem stepOutputSampleAffine_apply (C : n → ℝ)
    (q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ) (H : ℝ) (w : ℝ × ℝ) :
    stepOutputSampleAffine C q00 q10 q01 H w =
      finitePlantOutput C (stepAffineFamily q00 q10 q01 w.1 w.2 H).1 := by
  simpa only [stepOutputSampleAffine, twoWeightAffine_apply, smul_eq_mul] using
    (stepAffineFamily_output C q00 q10 q01 w.1 w.2 H).symm

theorem stepCommandSampleAffine_apply (C : n → ℝ) (Kp Ti Td Tf : ℝ)
    (q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ) (H : ℝ) (w : ℝ × ℝ) :
    stepCommandSampleAffine C Kp Ti Td Tf q00 q10 q01 H w =
      stepCommand C Kp Ti Td Tf w.1 w.2 (stepAffineFamily q00 q10 q01 w.1 w.2) H := by
  simpa only [stepCommandSampleAffine, twoWeightAffine_apply, smul_eq_mul] using
    (stepAffineFamily_command C Kp Ti Td Tf w.1 w.2 q00 q10 q01 H).symm

-- Uniqueness identifies the same affine maps for every actual response,
-- independently of which three basis trajectories were initially selected.
theorem actual_step_samples_affine
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf L b c : ℝ}
    {q q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ}
    (hwp : IsRetardedSharedWellPosed (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L b c)
    (hq : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (h00 : StepLoopDynamics A B C Kp Ti Td Tf L 0 0 q00)
    (h10 : StepLoopDynamics A B C Kp Ti Td Tf L 1 0 q10)
    (h01 : StepLoopDynamics A B C Kp Ti Td Tf L 0 1 q01)
    (H : ℝ) (hH : 0≤H) :
    finitePlantOutput C (q H).1 = stepOutputSampleAffine C q00 q10 q01 H (b,c) ∧
    stepCommand C Kp Ti Td Tf b c q H =
      stepCommandSampleAffine C Kp Ti Td Tf q00 q10 q01 H (b,c) := by
  have hh := stepLoopDynamics_eq_affine_family_of_wellPosed hwp hq h00 h10 h01 hH
  constructor
  · rw [stepOutputSampleAffine_apply, hh]
  · rw [stepCommandSampleAffine_apply]
    simp only [stepCommand, hh]

-- The initial command constraint in the polygon is the actual implemented
-- zero-state feedthrough, including the proper derivative-filter contribution.
theorem stepCommand_zero_eq_polygon_jump
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q) :
    stepCommand C Kp Ti Td Tf b c q 0 = Kp*(b+(Td/Tf)*c) := by
  simp [stepCommand, sharedControllerRhs, h.initial, finitePlantOutput]

/-- The finite output and command limits written directly on the actual
physical affine family; no independent affine-map hypothesis occurs. -/
def physicalSampleBounds {ι : Type*} (C : n → ℝ) (Kp Ti Td Tf : ℝ)
    (q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ) (H yl yu ul uu : ι → ℝ) :
    Set (ℝ × ℝ) :=
  {w | ∀ i,
    (yl i ≤ finitePlantOutput C (stepAffineFamily q00 q10 q01 w.1 w.2 (H i)).1 ∧
      finitePlantOutput C (stepAffineFamily q00 q10 q01 w.1 w.2 (H i)).1 ≤ yu i) ∧
    (ul i ≤ stepCommand C Kp Ti Td Tf w.1 w.2 (stepAffineFamily q00 q10 q01 w.1 w.2) (H i) ∧
      stepCommand C Kp Ti Td Tf w.1 w.2 (stepAffineFamily q00 q10 q01 w.1 w.2) (H i) ≤ uu i)}

-- Two-sided sampled physical constraints are exactly affine slabs.
theorem physicalSampleBounds_eq {ι : Type*} (C : n → ℝ) (Kp Ti Td Tf : ℝ)
    (q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ) (H yl yu ul uu : ι → ℝ) :
    physicalSampleBounds C Kp Ti Td Tf q00 q10 q01 H yl yu ul uu =
      affineSampleSlabs (fun i => stepOutputSampleAffine C q00 q10 q01 (H i)) yl yu ∩
      affineSampleSlabs (fun i => stepCommandSampleAffine C Kp Ti Td Tf q00 q10 q01 (H i)) ul uu := by
  ext w
  simp only [physicalSampleBounds, affineSampleSlabs, mem_ofPred_eq, mem_inter_iff,
    stepOutputSampleAffine_apply, stepCommandSampleAffine_apply]
  exact forall_and

theorem physicalSampleBounds_closed {ι : Type*} (C : n → ℝ) (Kp Ti Td Tf : ℝ)
    (q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ) (H yl yu ul uu : ι → ℝ) :
    IsClosed (physicalSampleBounds C Kp Ti Td Tf q00 q10 q01 H yl yu ul uu) := by
  rw [physicalSampleBounds_eq]
  exact (affineSampleSlabs_closed _ _ _).inter (affineSampleSlabs_closed _ _ _)

theorem physicalSampleBounds_convex {ι : Type*} (C : n → ℝ) (Kp Ti Td Tf : ℝ)
    (q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ) (H yl yu ul uu : ι → ℝ) :
    Convex ℝ (physicalSampleBounds C Kp Ti Td Tf q00 q10 q01 H yl yu ul uu) := by
  rw [physicalSampleBounds_eq]
  exact (affineSampleSlabs_convex _ _ _).inter (affineSampleSlabs_convex _ _ _)


/-- Selection of either declared physical modal objective. -/
noncomputable def declaredModalAffine (stepObjective : Bool) (Kp Ti Td Tf : ℝ)
    (Bpole d p : ℂ) : (ℝ × ℝ) →ᵃ[ℝ] ℂ :=
  if stepObjective then pidfStepAmplitudeAffine Kp Ti Td Tf Bpole d p
    else pidfResidueAffine Kp Ti Td Tf Bpole d p

-- Separating real and imaginary parts gives exactly the finite cone epigraph
-- for either of the declared concrete PIDF modal objectives.
theorem physical_modal_cone_epigraph {ι : Type*} (s : Finset ι) (hne : s.Nonempty)
    (stepObjective : Bool) (Kp Ti Td Tf : ℝ) (Bpole d p : ι → ℂ)
    (w : ℝ × ℝ) (t : ℝ) :
    finiteModalCost s hne (fun i => declaredModalAffine stepObjective Kp Ti Td Tf
      (Bpole i) (d i) (p i)) w ≤ t ↔
    ∀ i ∈ s, Real.sqrt
      ((declaredModalAffine stepObjective Kp Ti Td Tf (Bpole i) (d i) (p i) w).re^2+
       (declaredModalAffine stepObjective Kp Ti Td Tf (Bpole i) (d i) (p i) w).im^2) ≤ t := by
  rw [finiteModalCost_le_iff]
  simp only [complex_norm_as_real_cone]

/-- Each sample may belong to a different declared physical scenario. -/
def physicalScenarioSampleBounds {κ : Type*} (C : κ → n → ℝ) (Kp Ti Td Tf : ℝ)
    (q00 q10 q01 : κ → ℝ → (n → ℝ) × ℝ × ℝ) (H yl yu ul uu : κ → ℝ) :
    Set (ℝ × ℝ) :=
  {w | ∀ i,
    (yl i ≤ finitePlantOutput (C i) (stepAffineFamily (q00 i) (q10 i) (q01 i) w.1 w.2 (H i)).1 ∧
      finitePlantOutput (C i) (stepAffineFamily (q00 i) (q10 i) (q01 i) w.1 w.2 (H i)).1 ≤ yu i) ∧
    (ul i ≤ stepCommand (C i) Kp Ti Td Tf w.1 w.2 (stepAffineFamily (q00 i) (q10 i) (q01 i) w.1 w.2) (H i) ∧
      stepCommand (C i) Kp Ti Td Tf w.1 w.2 (stepAffineFamily (q00 i) (q10 i) (q01 i) w.1 w.2) (H i) ≤ uu i)}

theorem physicalScenarioSampleBounds_eq {κ : Type*} (C : κ → n → ℝ) (Kp Ti Td Tf : ℝ)
    (q00 q10 q01 : κ → ℝ → (n → ℝ) × ℝ × ℝ) (H yl yu ul uu : κ → ℝ) :
    physicalScenarioSampleBounds C Kp Ti Td Tf q00 q10 q01 H yl yu ul uu =
      affineSampleSlabs (fun i => stepOutputSampleAffine (C i) (q00 i) (q10 i) (q01 i) (H i)) yl yu ∩
      affineSampleSlabs (fun i => stepCommandSampleAffine (C i) Kp Ti Td Tf (q00 i) (q10 i) (q01 i) (H i)) ul uu := by
  ext w
  simp only [physicalScenarioSampleBounds, affineSampleSlabs, mem_ofPred_eq, mem_inter_iff,
    stepOutputSampleAffine_apply, stepCommandSampleAffine_apply]
  exact forall_and

theorem physicalScenarioSampleBounds_closed {κ : Type*} (C : κ → n → ℝ) (Kp Ti Td Tf : ℝ)
    (q00 q10 q01 : κ → ℝ → (n → ℝ) × ℝ × ℝ) (H yl yu ul uu : κ → ℝ) :
    IsClosed (physicalScenarioSampleBounds C Kp Ti Td Tf q00 q10 q01 H yl yu ul uu) := by
  rw [physicalScenarioSampleBounds_eq]
  exact (affineSampleSlabs_closed _ _ _).inter (affineSampleSlabs_closed _ _ _)

theorem physicalScenarioSampleBounds_convex {κ : Type*} (C : κ → n → ℝ) (Kp Ti Td Tf : ℝ)
    (q00 q10 q01 : κ → ℝ → (n → ℝ) × ℝ × ℝ) (H yl yu ul uu : κ → ℝ) :
    Convex ℝ (physicalScenarioSampleBounds C Kp Ti Td Tf q00 q10 q01 H yl yu ul uu) := by
  rw [physicalScenarioSampleBounds_eq]
  exact (affineSampleSlabs_convex _ _ _).inter (affineSampleSlabs_convex _ _ _)

-- Proposition 10: concrete physical residue or step-amplitude optimization on
-- the admitted polygon, with arbitrary finite scenario/time output and command
-- bounds.  The optimizer is an actual trajectory of every declared scenario.
theorem physical_modal_design_minimizer {ι κ : Type*}
    (s : Finset ι) (hne : s.Nonempty) (stepObjective : Bool)
    (A : κ → Matrix n n ℝ) (B C : κ → n → ℝ)
    (Kp Ti Td Tf umax : ℝ) (L H yl yu ul uu : κ → ℝ)
    (q00 q10 q01 : κ → ℝ → (n → ℝ) × ℝ × ℝ)
    (h00 : ∀ i, StepLoopDynamics (A i) (B i) (C i) Kp Ti Td Tf (L i) 0 0 (q00 i))
    (h10 : ∀ i, StepLoopDynamics (A i) (B i) (C i) Kp Ti Td Tf (L i) 1 0 (q10 i))
    (h01 : ∀ i, StepLoopDynamics (A i) (B i) (C i) Kp Ti Td Tf (L i) 0 1 (q01 i))
    (Bpole d p : ι → ℂ)
    (hfeas : (admittedModalPolygon Kp Td Tf umax ∩
      physicalScenarioSampleBounds C Kp Ti Td Tf q00 q10 q01 H yl yu ul uu).Nonempty) :
    let X := admittedModalPolygon Kp Td Tf umax ∩
      physicalScenarioSampleBounds C Kp Ti Td Tf q00 q10 q01 H yl yu ul uu
    let z := fun i => declaredModalAffine stepObjective Kp Ti Td Tf (Bpole i) (d i) (p i)
    Convex ℝ X ∧ IsCompact X ∧
    ∃ w ∈ X,
      (∀ i, StepLoopDynamics (A i) (B i) (C i) Kp Ti Td Tf (L i) w.1 w.2
        (stepAffineFamily (q00 i) (q10 i) (q01 i) w.1 w.2)) ∧
      ∀ v ∈ X, finiteModalCost s hne z w ≤ finiteModalCost s hne z v := by
  dsimp only
  have hc := physicalScenarioSampleBounds_closed C Kp Ti Td Tf q00 q10 q01 H yl yu ul uu
  refine ⟨(admittedModalPolygon_convex Kp Td Tf umax).inter
    (physicalScenarioSampleBounds_convex C Kp Ti Td Tf q00 q10 q01 H yl yu ul uu),
    (admittedModalPolygon_compact Kp Td Tf umax).inter_right hc, ?_⟩
  obtain ⟨w, hw, hm⟩ := constrained_modal_minimizer s hne
    (fun i => declaredModalAffine stepObjective Kp Ti Td Tf (Bpole i) (d i) (p i))
    (admittedModalPolygon_compact Kp Td Tf umax) hc hfeas
  exact ⟨w, hw, fun i => stepLoopDynamics_affine_family (h00 i) (h10 i) (h01 i) w.1 w.2, hm⟩

-- The minimized epigraph variable is attained by exactly the same physical
-- design, so eliminating it did not change the optimization problem.
theorem physical_modal_epigraph_minimizer {ι : Type*} (s : Finset ι) (hne : s.Nonempty)
    (stepObjective : Bool) (Kp Ti Td Tf : ℝ) (Bpole d p : ι → ℂ)
    {X : Set (ℝ × ℝ)} (hX : IsCompact X) (hXne : X.Nonempty) :
    ∃ w ∈ X, ∃ t : ℝ,
      (∀ i ∈ s, Real.sqrt
        ((declaredModalAffine stepObjective Kp Ti Td Tf (Bpole i) (d i) (p i) w).re^2+
         (declaredModalAffine stepObjective Kp Ti Td Tf (Bpole i) (d i) (p i) w).im^2) ≤ t) ∧
      ∀ v ∈ X, ∀ u : ℝ,
        (∀ i ∈ s, Real.sqrt
          ((declaredModalAffine stepObjective Kp Ti Td Tf (Bpole i) (d i) (p i) v).re^2+
           (declaredModalAffine stepObjective Kp Ti Td Tf (Bpole i) (d i) (p i) v).im^2) ≤ u) → t≤u := by
  let z := fun i => declaredModalAffine stepObjective Kp Ti Td Tf (Bpole i) (d i) (p i)
  obtain ⟨w, hw, hm⟩ := finiteModalCost_minimizer s hne z hX hXne
  refine ⟨w, hw, finiteModalCost s hne z w, ?_, ?_⟩
  · exact (physical_modal_cone_epigraph s hne stepObjective Kp Ti Td Tf Bpole d p w _).1 le_rfl
  · intro v hv u hu
    exact (hm v hv).trans ((physical_modal_cone_epigraph s hne stepObjective Kp Ti Td Tf Bpole d p v u).2 hu)


-- Convexity and continuity are instantiated for the concrete physical modal
-- maps, for both transfer-residue and unit-step-amplitude design.
theorem physical_modal_cost_convex {ι : Type*} (s : Finset ι) (hne : s.Nonempty)
    (stepObjective : Bool) (Kp Ti Td Tf : ℝ) (Bpole d p : ι → ℂ) :
    ConvexOn ℝ univ (finiteModalCost s hne
      (fun i => declaredModalAffine stepObjective Kp Ti Td Tf (Bpole i) (d i) (p i))) :=
  finiteModalCost_convex s hne _

theorem physical_modal_cost_continuous {ι : Type*} (s : Finset ι) (hne : s.Nonempty)
    (stepObjective : Bool) (Kp Ti Td Tf : ℝ) (Bpole d p : ι → ℂ) :
    Continuous (finiteModalCost s hne
      (fun i => declaredModalAffine stepObjective Kp Ti Td Tf (Bpole i) (d i) (p i))) :=
  finiteModalCost_continuous s hne _

-- The same result allows any compact admitted polygon, retaining the actual
-- sampled response constraints rather than assuming an affine interface.
theorem physical_modal_minimizer_on_compact_polygon {ι κ : Type*}
    (s : Finset ι) (hne : s.Nonempty) (stepObjective : Bool)
    (A : κ → Matrix n n ℝ) (B C : κ → n → ℝ)
    (Kp Ti Td Tf : ℝ) (L H yl yu ul uu : κ → ℝ)
    (q00 q10 q01 : κ → ℝ → (n → ℝ) × ℝ × ℝ)
    (h00 : ∀ i, StepLoopDynamics (A i) (B i) (C i) Kp Ti Td Tf (L i) 0 0 (q00 i))
    (h10 : ∀ i, StepLoopDynamics (A i) (B i) (C i) Kp Ti Td Tf (L i) 1 0 (q10 i))
    (h01 : ∀ i, StepLoopDynamics (A i) (B i) (C i) Kp Ti Td Tf (L i) 0 1 (q01 i))
    (Bpole d p : ι → ℂ) {X : Set (ℝ × ℝ)} (hX : IsCompact X) (hXc : Convex ℝ X)
    (hfeas : (X ∩ physicalScenarioSampleBounds C Kp Ti Td Tf q00 q10 q01 H yl yu ul uu).Nonempty) :
    let F := X ∩ physicalScenarioSampleBounds C Kp Ti Td Tf q00 q10 q01 H yl yu ul uu
    let z := fun i => declaredModalAffine stepObjective Kp Ti Td Tf (Bpole i) (d i) (p i)
    Convex ℝ F ∧ IsCompact F ∧ ∃ w ∈ F,
      (∀ i, StepLoopDynamics (A i) (B i) (C i) Kp Ti Td Tf (L i) w.1 w.2
        (stepAffineFamily (q00 i) (q10 i) (q01 i) w.1 w.2)) ∧
      ∀ v ∈ F, finiteModalCost s hne z w ≤ finiteModalCost s hne z v := by
  dsimp only
  have hc := physicalScenarioSampleBounds_closed C Kp Ti Td Tf q00 q10 q01 H yl yu ul uu
  refine ⟨hXc.inter (physicalScenarioSampleBounds_convex C Kp Ti Td Tf q00 q10 q01 H yl yu ul uu),
    hX.inter_right hc, ?_⟩
  obtain ⟨w, hw, hm⟩ := constrained_modal_minimizer s hne
    (fun i => declaredModalAffine stepObjective Kp Ti Td Tf (Bpole i) (d i) (p i)) hX hc hfeas
  exact ⟨w, hw, fun i => stepLoopDynamics_affine_family (h00 i) (h10 i) (h01 i) w.1 w.2, hm⟩

end Article14
