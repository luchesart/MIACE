import Article14.PiecewiseRegularity
import Mathlib.Topology.Piecewise

/-!
# From actual absolutely continuous evolution to classical retarded solutions

The inherited resolvent construction states its ODE almost everywhere.
Continuity of the actual delayed right-hand side upgrades it to the classical
equation at every positive time. Compatible histories glue continuously at zero.
-/
namespace Article14
open MeasureTheory Set Filter
open scoped Topology

-- The integral equation is derived from the AC trajectory and its a.e. ODE.
theorem locallyAC_integral_eq_of_ae_ode {f g : ℝ → ℝ}
    (hac : ∀ T, 0 ≤ T → AbsolutelyContinuousOnInterval f 0 T)
    (hode : ∀ᵐ t, 0 < t → HasDerivAt f (g t) t)
    (T : ℝ) (hT : 0 ≤ T) :
    f T = f 0 + ∫ t in 0..T, g t := by
  have he : (∫ t in 0..T, deriv f t) = ∫ t in 0..T, g t := by
    apply intervalIntegral.integral_congr_ae
    filter_upwards [hode] with t ht hmem
    rw [uIoc_of_le hT] at hmem
    exact (ht hmem.1).deriv
  rw [(hac T hT).integral_deriv_eq_sub] at he
  linarith

-- Continuity supplies the derivative at every t>0, not merely a.e. in time.
theorem locallyAC_hasDerivAt_of_continuous_rhs {f g : ℝ → ℝ}
    (hac : ∀ T, 0 ≤ T → AbsolutelyContinuousOnInterval f 0 T)
    (hg : ContinuousOn g (Ici 0))
    (hode : ∀ᵐ t, 0 < t → HasDerivAt f (g t) t)
    (t : ℝ) (ht : 0 < t) : HasDerivAt f (g t) t := by
  have hgc : ContinuousAt g t := hg.continuousAt (Ici_mem_nhds ht)
  have hi : IntervalIntegrable g volume 0 t := by
    apply ContinuousOn.intervalIntegrable
    rw [uIcc_of_le ht.le]
    exact hg.mono (fun _ hx => hx.1)
  have hd := (intervalIntegral.integral_hasDerivAt_right hi
    (ContinuousOn.stronglyMeasurableAtFilter isOpen_Ioi
      (hg.mono Ioi_subset_Ici_self) t ht) hgc).const_add (f 0)
  apply hd.congr_of_eventuallyEq
  filter_upwards [Ioi_mem_nhds ht] with s hs
  exact locallyAC_integral_eq_of_ae_ode hac hode s hs.le

-- A compatible zero-time value is exactly the condition needed to join an
-- arbitrary admissible history to its constructed future solution.
theorem continuousOn_history_splice {E : Type*} [TopologicalSpace E]
    {h f : ℝ → E} {L : ℝ}
    (hh : ContinuousOn h (Icc (-L) 0))
    (hf : ContinuousOn f (Ici 0)) (hzero : f 0 = h 0) :
    ContinuousOn (fun t => if t ≤ 0 then h t else f t) (Ici (-L)) := by
  apply ContinuousOn.if
  · intro t ht
    have hz : t = 0 := by
      simpa only [show {a : ℝ | a ≤ 0} = Iic 0 from rfl,
        frontier_Iic, mem_singleton_iff] using ht.2
    subst t
    exact hzero.symm
  · have hc : closure {t : ℝ | t ≤ 0} = Iic 0 := isClosed_Iic.closure_eq
    rw [hc]
    exact hh.mono (fun _ ht => ⟨ht.1, ht.2⟩)
  · have hc : closure {t : ℝ | ¬t ≤ 0} = Ici 0 := by
      simp only [not_le, show {t : ℝ | 0 < t} = Ioi 0 from rfl, closure_Ioi]
    rw [hc]
    exact hf.mono (fun _ ht => ht.2)

end Article14
