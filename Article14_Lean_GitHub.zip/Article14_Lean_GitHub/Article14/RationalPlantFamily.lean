import Article14.RationalRealization
import Article14.RationalCoefficientNormalization

/-!
# From the article's rational plant class to the physical family

A reduced strictly proper polynomial quotient with no DC pole and positive
static gain supplies its own finite companion realization and equilibrium.
The only dynamic hypothesis remaining in the family constructor is the
article's internal stability of the actual shared-state feedback loop.
-/
namespace Article14.RationalRealization
open Polynomial Matrix Finset
open Article14.PhysicalPlant
open scoped Matrix Topology
open Filter

/-- The polynomial data in the general-plant hypotheses of Article 14. -/
structure RationalPlant where
  num : ℝ[X]
  den : ℝ[X]
  proper : num.degree < den.degree
  reduced : IsCoprime num den
  no_pole_zero : den.eval 0 ≠ 0
  positive_dc : 0 < num.eval 0 / den.eval 0

namespace RationalPlant

theorem den_ne_zero (P : RationalPlant) : P.den ≠ 0 := by
  intro h
  exact P.no_pole_zero (by simp [h])

theorem num_ne_zero (P : RationalPlant) : P.num ≠ 0 := by
  intro h
  have hp := P.positive_dc
  simp [h] at hp

theorem degree_positive (P : RationalPlant) : 0 < P.den.natDegree :=
  denominator_natDegree_pos P.num P.den P.num_ne_zero P.den_ne_zero P.proper

/-- The number of shift rows; the actual state dimension is `order + 1`. -/
def order (P : RationalPlant) : ℕ := P.den.natDegree-1

theorem degree_eq_order_succ (P : RationalPlant) : P.den.natDegree=P.order+1 := by
  have hp := P.degree_positive
  unfold order
  omega

noncomputable def denominatorCoefficients (P : RationalPlant) : Fin (P.order+1) → ℝ :=
  fun j => P.den.coeff j/P.den.leadingCoeff

noncomputable def numeratorCoefficients (P : RationalPlant) : Fin (P.order+1) → ℝ :=
  fun j => P.num.coeff j/P.den.leadingCoeff

noncomputable def stateMatrix (P : RationalPlant) :
    Matrix (Fin (P.order+1)) (Fin (P.order+1)) ℝ := companion P.denominatorCoefficients

noncomputable def input (P : RationalPlant) : Fin (P.order+1) → ℝ := inputVector P.order

noncomputable def output (P : RationalPlant) : Fin (P.order+1) → ℝ := P.numeratorCoefficients

noncomputable def dcGain (P : RationalPlant) : ℝ := P.num.eval 0/P.den.eval 0

noncomputable def equilibrium (P : RationalPlant) : Fin (P.order+1) → ℝ :=
  equilibriumState P.denominatorCoefficients P.dcGain

theorem denominator_eval (P : RationalPlant) (s : ℝ) :
    denominatorValue P.denominatorCoefficients s = P.den.eval s/P.den.leadingCoeff :=
  (normalized_denominator_eval P.den P.den_ne_zero P.degree_eq_order_succ s).symm

theorem numerator_eval (P : RationalPlant) (s : ℝ) :
    numeratorValue P.numeratorCoefficients s = P.num.eval s/P.den.leadingCoeff :=
  (normalized_numerator_eval P.num P.den P.den_ne_zero P.proper P.degree_eq_order_succ s).symm

theorem quotient_eval (P : RationalPlant) (s : ℝ) :
    numeratorValue P.numeratorCoefficients s / denominatorValue P.denominatorCoefficients s =
      P.num.eval s/P.den.eval s :=
  normalized_quotient_eval P.num P.den P.den_ne_zero P.proper P.degree_eq_order_succ s

theorem denominator_ne_zero (P : RationalPlant) (s : ℝ) (hs : P.den.eval s ≠ 0) :
    denominatorValue P.denominatorCoefficients s ≠ 0 := by
  rw [P.denominator_eval]
  exact div_ne_zero hs (Polynomial.leadingCoeff_ne_zero.mpr P.den_ne_zero)

theorem pencil_nonsingular (P : RationalPlant) (s : ℝ) (hs : P.den.eval s ≠ 0) :
    (pencil P.stateMatrix s).det ≠ 0 :=
  companion_pencil_det_ne_zero P.denominatorCoefficients s (P.denominator_ne_zero s hs)

-- This is the actual inverse-matrix transfer, equal to the original quotient.
theorem transfer_eq (P : RationalPlant) (s : ℝ) (hs : P.den.eval s ≠ 0) :
    ((P.output ᵥ* (pencil P.stateMatrix s)⁻¹) ⬝ᵥ P.input) = P.num.eval s/P.den.eval s := by
  change ((P.numeratorCoefficients ᵥ* (pencil (companion P.denominatorCoefficients) s)⁻¹)
    ⬝ᵥ inputVector P.order) = _
  rw [companion_transfer P.denominatorCoefficients P.numeratorCoefficients s
    (P.denominator_ne_zero s hs), P.quotient_eval]

theorem normalized_transfer_eq (P : RationalPlant) (s : ℝ) (hs : P.den.eval s ≠ 0) :
    normalizedTransfer P.stateMatrix P.input P.output P.dcGain s =
      (P.num.eval s/P.den.eval s)/P.dcGain :=
  congrArg (fun x : ℝ => x/P.dcGain) (P.transfer_eq s hs)

theorem equilibrium_equation (P : RationalPlant) :
    ∀ j, (∑ l, P.stateMatrix j l*P.equilibrium l)+P.input j/P.dcGain=0 :=
  companion_equilibrium P.denominatorCoefficients P.dcGain
    (P.denominator_ne_zero 0 P.no_pole_zero)

theorem unit_output (P : RationalPlant) : (∑ j, P.output j*P.equilibrium j)=1 := by
  change (∑ j, P.numeratorCoefficients j*equilibriumState P.denominatorCoefficients P.dcGain j)=1
  rw [companion_equilibrium_output P.denominatorCoefficients P.numeratorCoefficients P.dcGain,
    P.quotient_eval]
  exact div_self P.positive_dc.ne'

/-- The complete family for the article's polynomial-quotient plant, with all
static realization obligations discharged by the preceding construction. -/
noncomputable def stableFamily (P : RationalPlant) (Kp Ti Td Tf L : ℝ)
    (hKp : 0<Kp) (hTi : 0<Ti) (hTd : 0<Td) (hTf : 0<Tf) (hL : 0≤L)
    (hs : Article14.IsRetardedSharedExponentiallyStable (Article14.finitePlantOutput P.output)
      (Article14.finitePlantDynamics P.stateMatrix P.input) Kp Ti Td Tf L 0 0) :
    Article14.StablePIDFData (Fin (P.order+1)) where
  A := P.stateMatrix
  B := P.input
  C := P.output
  xInf := P.equilibrium
  Kp := Kp
  Ti := Ti
  Td := Td
  Tf := Tf
  k := P.dcGain
  L := L
  Kp_pos := hKp
  Ti_pos := hTi
  Td_pos := hTd
  Tf_pos := hTf
  k_pos := P.positive_dc
  L_nonneg := hL
  equilibrium := P.equilibrium_equation
  unit_output := P.unit_output
  nonsingular := P.pencil_nonsingular 0 P.no_pole_zero
  stable := hs

/-- The original real rational function, before normalization by DC gain. -/
noncomputable def transfer (P : RationalPlant) (s : ℝ) : ℝ := P.num.eval s/P.den.eval s

theorem transfer_hasDerivAt_zero (P : RationalPlant) :
    HasDerivAt P.transfer
      ((P.num.derivative.eval 0*P.den.eval 0-P.num.eval 0*P.den.derivative.eval 0)/
        (P.den.eval 0)^2) 0 :=
  (P.num.hasDerivAt 0).div (P.den.hasDerivAt 0) P.no_pole_zero

-- The state-space DC moment has the exact rational-function meaning used
-- in Γ = L − P₀'(0)/k in the manuscript.
theorem residenceTime_eq_rational_derivative (P : RationalPlant) :
    residenceTime P.stateMatrix P.output P.equilibrium =
      -(deriv P.transfer 0)/P.dcGain := by
  have hr := P.transfer_hasDerivAt_zero
  have hn : HasDerivAt (normalizedTransfer P.stateMatrix P.input P.output P.dcGain)
      ((deriv P.transfer 0)/P.dcGain) 0 := by
    rw [hr.deriv]
    apply (hr.div_const P.dcGain).congr_of_eventuallyEq
    filter_upwards [P.den.continuous.continuousAt.eventually_ne P.no_pole_zero]
      with s hs
    exact P.normalized_transfer_eq s hs
  have hm := normalizedTransfer_hasDerivAt_zero P.equilibrium_equation
    P.unit_output (P.pencil_nonsingular 0 P.no_pole_zero)
  have hh := hm.unique hn
  rw [neg_div]
  linarith

theorem stableFamily_gamma (P : RationalPlant) (Kp Ti Td Tf L : ℝ)
    (hKp : 0<Kp) (hTi : 0<Ti) (hTd : 0<Td) (hTf : 0<Tf) (hL : 0≤L)
    (hs : Article14.IsRetardedSharedExponentiallyStable (Article14.finitePlantOutput P.output)
      (Article14.finitePlantDynamics P.stateMatrix P.input) Kp Ti Td Tf L 0 0) :
    (P.stableFamily Kp Ti Td Tf L hKp hTi hTd hTf hL hs).gamma =
      L-(deriv P.transfer 0)/P.dcGain := by
  change residenceTime P.stateMatrix P.output P.equilibrium+L = _
  rw [P.residenceTime_eq_rational_derivative]
  ring

end RationalPlant
end Article14.RationalRealization
