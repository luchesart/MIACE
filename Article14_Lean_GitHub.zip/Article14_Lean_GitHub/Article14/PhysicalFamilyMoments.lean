import Article14.PhysicalFamilyOptimization
import Article14.KernelMomentGeometry

/-!
# Actual moment and lexicographic performance of the stable physical family

All objectives in this file are Lebesgue integrals of the response selected by
`StablePIDFData.response`.  Kernel positivity supplies nonnegative tracking
error, and the physical state equations supply the moment formulas.  In
particular neither the ITAE formula nor injectivity of the objective pair is
assumed in the optimization theorem.
-/
namespace Article14
open MeasureTheory Filter Set MIACE
open PhysicalPlant PhysicalLaplace
open scoped Topology
variable {n : Type*} [Fintype n] [DecidableEq n]
namespace StablePIDFData

/-- Integral absolute tracking error of the actual zero-history step. -/
noncomputable def iae (d : StablePIDFData n) (w : ℝ × ℝ) : ℝ :=
  ∫ t, |d.error w t| ∂halfLine

/-- Integral time-weighted absolute tracking error of the same actual step. -/
noncomputable def itae (d : StablePIDFData n) (w : ℝ × ℝ) : ℝ :=
  ∫ t, t * |d.error w t| ∂halfLine

-- @article14 thm:delay-fastest/physical_family_IAE
/-- The positive impulse condition makes the actual IAE equal its mean. -/
theorem iae_eq_mean (d : StablePIDFData n) (w : ℝ × ℝ)
    (hg : ∀ᵐ t ∂halfLine, 0 ≤ d.kernel w t) :
    d.iae w = meanTime d.Ti d.k d.Kp w.1 := by
  exact stable_step_positive_iae (d.response_dynamics w) d.Ti_pos.ne'
    d.k_pos.ne' d.Kp_pos.ne' d.L_nonneg (d.stable_weights w)
    d.equilibrium d.unit_output d.nonsingular hg

-- @article14 prop:delay-second-moment/physical_signed_time_error_formula
/-- The signed time-error identity already holds before any positivity
constraint is imposed. -/
theorem signed_time_error_eq_second_error_moment (d : StablePIDFData n) (w : ℝ × ℝ) :
    (∫ t, t * d.error w t ∂halfLine) =
      secondErrorMoment d.Kp (d.Kp / d.Ti) (d.Kp * d.Td) d.k d.gamma
        (meanTime d.Ti d.k d.Kp w.1) w.2 := by
  exact stable_step_first_error_moment (d.response_dynamics w) d.Ti_pos.ne'
    d.k_pos.ne' d.Kp_pos.ne' d.Tf_pos d.L_nonneg (d.stable_weights w)
    d.equilibrium d.unit_output d.nonsingular

-- @article14 prop:delay-second-moment/physical_signed_time_error_half_impulse_moment
theorem signed_time_error_eq_half_second_impulse_moment
    (d : StablePIDFData n) (w : ℝ × ℝ) :
    (∫ t, t * d.error w t ∂halfLine) =
      (1 / 2 : ℝ) * (∫ t, t ^ 2 * d.kernel w t ∂halfLine) := by
  rw [d.signed_time_error_eq_second_error_moment w, (d.kernel_moments w).2]
  ring

-- @article14 prop:delay-second-moment/physical_family_ITAE
/-- The physical ITAE is exactly half the physical second impulse moment. -/
theorem itae_eq_second_error_moment (d : StablePIDFData n) (w : ℝ × ℝ)
    (hg : ∀ᵐ t ∂halfLine, 0 ≤ d.kernel w t) :
    d.itae w = secondErrorMoment d.Kp (d.Kp / d.Ti) (d.Kp * d.Td) d.k d.gamma
      (meanTime d.Ti d.k d.Kp w.1) w.2 := by
  exact stable_step_positive_itae (d.response_dynamics w) d.Ti_pos.ne'
    d.k_pos.ne' d.Kp_pos.ne' d.Tf_pos d.L_nonneg (d.stable_weights w)
    d.equilibrium d.unit_output d.nonsingular hg

-- @article14 prop:delay-second-moment/physical_ITAE_half_second_impulse_moment
theorem itae_eq_half_second_impulse_moment (d : StablePIDFData n) (w : ℝ × ℝ)
    (hg : ∀ᵐ t ∂halfLine, 0 ≤ d.kernel w t) :
    d.itae w = (1 / 2 : ℝ) * (∫ t, t ^ 2 * d.kernel w t ∂halfLine) := by
  rw [d.itae_eq_second_error_moment w hg, (d.kernel_moments w).2]
  ring

-- @article14 prop:delay-second-moment/physical_family_strict_variance
theorem positive_kernel_strict_variance (d : StablePIDFData n) (w : ℝ × ℝ)
    (hg : ∀ᵐ t ∂halfLine, 0 ≤ d.kernel w t) :
    (meanTime d.Ti d.k d.Kp w.1) ^ 2 <
      2 * secondErrorMoment d.Kp (d.Kp / d.Ti) (d.Kp * d.Td) d.k d.gamma
        (meanTime d.Ti d.k d.Kp w.1) w.2 := by
  have hfirst : Integrable (fun t => t * d.kernel w t) halfLine := by
    simpa only [pow_one] using d.kernel_weight_integrable w 1
  have hh := kernel_variance_pos (d.kernel_integrable w) hfirst
    (d.kernel_weight_integrable w 2) hg (d.kernel_mass w)
  rwa [(d.kernel_moments w).1, (d.kernel_moments w).2] at hh

-- @article14 prop:delay-second-moment/strict_bound_between_actual_performance_integrals
theorem iae_sq_lt_twice_itae (d : StablePIDFData n) (w : ℝ × ℝ)
    (hg : ∀ᵐ t ∂halfLine, 0 ≤ d.kernel w t) :
    (d.iae w) ^ 2 < 2 * d.itae w := by
  rw [d.iae_eq_mean w hg, d.itae_eq_second_error_moment w hg]
  exact d.positive_kernel_strict_variance w hg

-- @article14 prop:delay-second-moment/physical_family_derivative_weight_bound
theorem positive_kernel_strict_c_bound (d : StablePIDFData n) (w : ℝ × ℝ)
    (hg : ∀ᵐ t ∂halfLine, 0 ≤ d.kernel w t) :
    1 + ((d.Kp / d.Ti) * (meanTime d.Ti d.k d.Kp w.1)^2 / 2 -
      (d.Kp + 1 / d.k) * meanTime d.Ti d.k d.Kp w.1 + d.gamma / d.k) /
        (d.Kp * d.Td) < w.2 := by
  exact stable_step_positive_variance_weight_bound (d.response_dynamics w)
    d.Ti_pos d.k_pos.ne' d.Kp_pos d.Td_pos d.Tf_pos d.L_nonneg
    (d.stable_weights w) d.equilibrium d.unit_output d.nonsingular hg

-- @article14 thm:delay-fastest/physical_family_strict_delay_bound
theorem positive_kernel_mean_gt_delay (d : StablePIDFData n) (w : ℝ × ℝ)
    (hg : ∀ᵐ t ∂halfLine, 0 ≤ d.kernel w t) :
    d.L < meanTime d.Ti d.k d.Kp w.1 := by
  exact stable_step_positive_mean_gt_delay (d.response_dynamics w) d.Ti_pos.ne'
    d.k_pos.ne' d.Kp_pos.ne' d.Tf_pos d.L_nonneg (d.stable_weights w)
    d.equilibrium d.unit_output d.nonsingular hg

-- @article14 thm:delay-fastest/physical_IAE_order_is_reversed_b_order
theorem iae_le_iff (d : StablePIDFData n) {w z : ℝ × ℝ}
    (hw : ∀ᵐ t ∂halfLine, 0 ≤ d.kernel w t)
    (hz : ∀ᵐ t ∂halfLine, 0 ≤ d.kernel z t) :
    d.iae w ≤ d.iae z ↔ z.1 ≤ w.1 := by
  rw [d.iae_eq_mean w hw, d.iae_eq_mean z hz]
  unfold meanTime
  rw [mul_le_mul_iff_right₀ d.Ti_pos]
  constructor <;> intro h <;> linarith

-- @article14 prop:delay-second-moment/physical_ITAE_order_on_fixed_b
theorem itae_le_iff_of_same_b (d : StablePIDFData n) {w z : ℝ × ℝ}
    (hw : ∀ᵐ t ∂halfLine, 0 ≤ d.kernel w t)
    (hz : ∀ᵐ t ∂halfLine, 0 ≤ d.kernel z t) (hb : w.1 = z.1) :
    d.itae w ≤ d.itae z ↔ w.2 ≤ z.2 := by
  rw [d.itae_eq_second_error_moment w hw, d.itae_eq_second_error_moment z hz, hb]
  exact (secondErrorMoment_strictMono d.Kp (d.Kp / d.Ti) (d.Kp * d.Td) d.k d.gamma
    (meanTime d.Ti d.k d.Kp z.1) (div_pos d.Kp_pos d.Ti_pos)
    (mul_pos d.Kp_pos d.Td_pos)).le_iff_le

-- @article14 prop:delay-second-moment/actual_objective_pair_identifies_weights
theorem weights_eq_of_iae_itae (d : StablePIDFData n) {w z : ℝ × ℝ}
    (hw : ∀ᵐ t ∂halfLine, 0 ≤ d.kernel w t)
    (hz : ∀ᵐ t ∂halfLine, 0 ≤ d.kernel z t)
    (hiae : d.iae w = d.iae z) (hitae : d.itae w = d.itae z) : w = z := by
  have hb : w.1 = z.1 := le_antisymm
    ((d.iae_le_iff hz hw).mp hiae.ge) ((d.iae_le_iff hw hz).mp hiae.le)
  apply Prod.ext hb
  exact le_antisymm ((d.itae_le_iff_of_same_b hw hz hb).mp hitae.le)
    ((d.itae_le_iff_of_same_b hz hw hb.symm).mp hitae.ge)

-- @article14 prop:delay-second-moment/actual_lexicographic_optimality
/-- The unique largest-b/smallest-c choice is the unique lexicographic
minimizer of the two actual physical performance integrals.  This assembly
works for any compact positive-kernel engineering set. -/
theorem lexicographic_performance_optimizer (d : StablePIDFData n)
    {F : Set (ℝ × ℝ)} (hF : IsCompact F) (hne : F.Nonempty)
    (hpositive : ∀ w ∈ F, ∀ᵐ t ∂halfLine, 0 ≤ d.kernel w t) :
    ∃ w ∈ F,
      (∀ z ∈ F, d.iae w ≤ d.iae z) ∧
      (∀ z ∈ F, d.iae z = d.iae w → d.itae w ≤ d.itae z) ∧
      (∀ z ∈ F, d.iae z = d.iae w → d.itae z = d.itae w → z = w) := by
  obtain ⟨w, hw, hbmax, hcmin, _⟩ := lexicographic_weights_exist hF hne
  refine ⟨w, hw, ?_, ?_, ?_⟩
  · intro z hz
    exact (d.iae_le_iff (hpositive w hw) (hpositive z hz)).mpr (hbmax z hz)
  · intro z hz he
    have hb : z.1 = w.1 := meanTime_injective d.Ti d.k d.Kp d.Ti_pos.ne' (by
      simpa only [d.iae_eq_mean z (hpositive z hz), d.iae_eq_mean w (hpositive w hw)] using he)
    exact (d.itae_le_iff_of_same_b (hpositive w hw) (hpositive z hz) hb.symm).mpr
      (hcmin z hz hb)
  · intro z hz he hte
    exact d.weights_eq_of_iae_itae (hpositive z hz) (hpositive w hw) he hte

-- @article14 prop:delay-second-moment/unique_actual_lexicographic_optimizer
/-- Uniqueness is for the actual IAE/ITAE optimization problem, not merely
for a separately specified pair of algebraic coordinates. -/
theorem unique_lexicographic_performance_optimizer (d : StablePIDFData n)
    {F : Set (ℝ × ℝ)} (hF : IsCompact F) (hne : F.Nonempty)
    (hpositive : ∀ w ∈ F, ∀ᵐ t ∂halfLine, 0 ≤ d.kernel w t) :
    ∃! w, w ∈ F ∧
      (∀ z ∈ F, d.iae w ≤ d.iae z) ∧
      (∀ z ∈ F, d.iae z = d.iae w → d.itae w ≤ d.itae z) := by
  obtain ⟨w, hw, hmin, hsecondary, huniq⟩ :=
    d.lexicographic_performance_optimizer hF hne hpositive
  refine ⟨w, ⟨hw, hmin, hsecondary⟩, ?_⟩
  intro z hz
  have he : d.iae z = d.iae w := le_antisymm (hz.2.1 w hw) (hmin z hz.1)
  apply huniq z hz.1 he
  exact le_antisymm (hz.2.2 w hw he.symm) (hsecondary z hz.1 he)

-- @article14 thm:delay-fastest/physical_feasible_IAE_minimization_is_max_b
/-- The physical fastest-mean problem is exactly largest feasible b. -/
theorem feasible_minimum_iae_iff_maximum_b (d : StablePIDFData n)
    {X : Set (ℝ × ℝ)} {w : ℝ × ℝ} (hw : w ∈ d.feasible X) :
    (∀ z ∈ d.feasible X, d.iae w ≤ d.iae z) ↔
      (∀ z ∈ d.feasible X, z.1 ≤ w.1) := by
  constructor
  · intro h z hz
    exact (d.iae_le_iff (d.feasible_kernel_nonnegative hw)
      (d.feasible_kernel_nonnegative hz)).mp (h z hz)
  · intro h z hz
    exact (d.iae_le_iff (d.feasible_kernel_nonnegative hw)
      (d.feasible_kernel_nonnegative hz)).mpr (h z hz)

-- @article14 prop:delay-second-moment/physical_feasible_unique_lexicographic_optimizer
/-- The complete physical version of Proposition 15: only the static stable
PIDF data, a closed engineering set, and nonempty feasibility are inputs.
Existence, compactness, and both objective identities have already been proved. -/
theorem feasible_unique_lexicographic_performance_optimizer (d : StablePIDFData n)
    {X : Set (ℝ × ℝ)} (hX : IsClosed X) (hne : (d.feasible X).Nonempty) :
    ∃! w, w ∈ d.feasible X ∧
      (∀ z ∈ d.feasible X, d.iae w ≤ d.iae z) ∧
      (∀ z ∈ d.feasible X, d.iae z = d.iae w → d.itae w ≤ d.itae z) := by
  exact d.unique_lexicographic_performance_optimizer (d.feasible_compact hX) hne
    (fun _ hw => d.feasible_kernel_nonnegative hw)

end StablePIDFData
end Article14
