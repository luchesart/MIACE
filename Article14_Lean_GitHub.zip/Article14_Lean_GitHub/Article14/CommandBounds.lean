import Mathlib.Analysis.Calculus.MeanValue
import Mathlib.Tactic

/-! Article 14, Proposition 11: a bound throughout a genuine time interval.
The command is a real function; its derivative bound is required everywhere
on the interval, rather than inferred from samples. The proposition in the
paper is conditional on exactly this bound. -/
namespace Article14
open Set

-- @article14 prop:time-tightening/nearest_endpoint_certificate
theorem tightened_endpoints_of_lipschitz {u : ℝ → ℝ} {a b L umax : ℝ}
    (hab : a ≤ b) (hL : 0 ≤ L)
    (hLip : ∀ x ∈ Icc a b, ∀ y ∈ Icc a b,
      |u y - u x| ≤ L * |y - x|)
    (ha : |u a| ≤ umax - (b - a) * L / 2)
    (hb : |u b| ≤ umax - (b - a) * L / 2) :
    ∀ t ∈ Icc a b, |u t| ≤ umax := by
  intro t ht
  by_cases hnear : t ≤ (a + b) / 2
  · have hl := hLip a ⟨le_rfl, hab⟩ t ht
    rw [abs_of_nonneg (sub_nonneg.mpr ht.1)] at hl
    have htri : |u t| ≤ |u t - u a| + |u a| := by
      simpa using abs_add_le (u t - u a) (u a)
    have hd : L * (t - a) ≤ L * ((b - a) / 2) :=
      mul_le_mul_of_nonneg_left (by linarith) hL
    nlinarith
  · have hl := hLip b ⟨hab, le_rfl⟩ t ht
    rw [abs_of_nonpos (sub_nonpos.mpr ht.2)] at hl
    have htri : |u t| ≤ |u t - u b| + |u b| := by
      simpa using abs_add_le (u t - u b) (u b)
    have hd : L * (b - t) ≤ L * ((b - a) / 2) :=
      mul_le_mul_of_nonneg_left (by linarith) hL
    nlinarith

-- @article14 prop:time-tightening/full_statement
theorem command_bound_throughout_interval {u du : ℝ → ℝ} {a b L umax : ℝ}
    (hab : a ≤ b) (hL : 0 ≤ L)
    (hd : ∀ t ∈ Icc a b, HasDerivWithinAt u (du t) (Icc a b) t)
    (hbound : ∀ t ∈ Icc a b, |du t| ≤ L)
    (ha : |u a| ≤ umax - (b - a) * L / 2)
    (hb : |u b| ≤ umax - (b - a) * L / 2) :
    ∀ t ∈ Icc a b, |u t| ≤ umax := by
  apply tightened_endpoints_of_lipschitz hab hL ?_ ha hb
  intro x hx y hy
  simpa only [Real.norm_eq_abs] using
    Convex.norm_image_sub_le_of_norm_hasDerivWithin_le hd
      (by simpa only [Real.norm_eq_abs] using hbound) (convex_Icc a b) hx hy

end Article14
