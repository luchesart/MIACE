import MIACE.ComplexKernel
import Mathlib.Analysis.Convex.Basic
import Mathlib.MeasureTheory.Integral.IntegralEqImproper
import Mathlib.MeasureTheory.Integral.IntervalIntegral.LebesgueDifferentiationThm
import Mathlib.Analysis.Calculus.Deriv.Slope

/-!
Article 14, Theorem 14(a),(c) and Proposition 16: analytic consequences of
an actual nonnegative ordinary impulse kernel.  The frequency response is
the original MIACE complex Laplace integral, not an abstract prescribed norm.
The physical controller-to-kernel bridge and compactness are separate obligations.
-/

namespace Article14

open MeasureTheory Set Filter

/-- The actual frequency magnitudes of an ordinary impulse response. -/
noncomputable def frequencyMagnitudes (g : ℝ → ℝ) : Set ℝ :=
  Set.range (fun ω : ℝ => ‖MIACE.complexLaplace g (Complex.I * (ω : ℂ))‖)

/-- Boundary-frequency definition of the scalar stable transfer H-infinity norm. -/
noncomputable def kernelHinf (g : ℝ → ℝ) : ℝ := sSup (frequencyMagnitudes g)

-- NEW: The zero-frequency value is proved from the Bochner integral itself.
theorem complexLaplace_zero (g : ℝ → ℝ) :
    MIACE.complexLaplace g 0 = Complex.ofReal (∫ t, g t) := by
  simp [MIACE.complexLaplace, integral_complex_ofReal]

-- NEW: Reuse the Article 13 complex half-plane estimate at exponential weight zero.
theorem positive_kernel_frequency_bound {g : ℝ → ℝ}
    (hi : Integrable g) (hc : MIACE.Causal g)
    (hn : ∀ᵐ t, 0 ≤ g t) (hm : (∫ t, g t) = 1) (ω : ℝ) :
    ‖MIACE.complexLaplace g (Complex.I * (ω : ℂ))‖ ≤ 1 := by
  have hw : Integrable (MIACE.expWeight 0 g) := by
    simpa only [MIACE.expWeight_zero] using hi
  have h := MIACE.complex_laplace_norm_le hc hn hw
    (p := Complex.I * (ω : ℂ)) (by simp)
  simpa only [MIACE.expWeight_zero, hm] using h

-- NEW: The bound is attained at DC, so this proves a supremum, not merely an upper bound.
theorem positive_kernel_frequency_isLUB {g : ℝ → ℝ}
    (hi : Integrable g) (hc : MIACE.Causal g)
    (hn : ∀ᵐ t, 0 ≤ g t) (hm : (∫ t, g t) = 1) :
    IsLUB (frequencyMagnitudes g) 1 := by
  have hz : ‖MIACE.complexLaplace g (Complex.I * ((0 : ℝ) : ℂ))‖ = 1 := by
    rw [show Complex.I * ((0 : ℝ) : ℂ) = 0 by simp, complexLaplace_zero, hm]
    simp
  constructor
  · rintro x ⟨ω, rfl⟩
    exact positive_kernel_frequency_bound hi hc hn hm ω
  · intro x hx
    exact hx ⟨0, hz⟩

-- NEW: Exact positive unit-mass H-infinity identity used in Theorem 14(a).
theorem positive_kernel_hinf_eq_one {g : ℝ → ℝ}
    (hi : Integrable g) (hc : MIACE.Causal g)
    (hn : ∀ᵐ t, 0 ≤ g t) (hm : (∫ t, g t) = 1) :
    kernelHinf g = 1 := by
  exact (positive_kernel_frequency_isLUB hi hc hn hm).csSup_eq
    ⟨‖MIACE.complexLaplace g (Complex.I * ((0 : ℝ) : ℂ))‖, 0, rfl⟩

/-- Cumulative step output; for a causal kernel this integrates only its past input. -/
noncomputable def kernelStep (g : ℝ → ℝ) (t : ℝ) : ℝ := ∫ u in Iic t, g u

-- NEW: Causality gives the zero initial output, including the endpoint t = 0.
theorem causal_kernel_step_zero {g : ℝ → ℝ} (hc : MIACE.Causal g)
    {t : ℝ} (ht : t ≤ 0) : kernelStep g t = 0 := by
  unfold kernelStep
  rw [integral_Iic_eq_integral_Iio]
  apply integral_eq_zero_of_ae
  change ∀ᵐ u ∂volume.restrict (Iio t), g u = 0
  rw [ae_restrict_iff' measurableSet_Iio]
  filter_upwards [hc] with u hu hut
  exact hu (lt_of_lt_of_le hut ht)

-- NEW: The total mass is the actual limiting step output.
theorem kernel_step_tendsto_mass {g : ℝ → ℝ} (hi : Integrable g) :
    Tendsto (kernelStep g) atTop (nhds (∫ t, g t)) := by
  exact (aecover_Iic (μ := (volume : Measure ℝ))
    (tendsto_id : Tendsto (fun t : ℝ => t) atTop atTop)).integral_tendsto_of_countably_generated hi

theorem unit_mass_kernel_step_tendsto_one {g : ℝ → ℝ}
    (hi : Integrable g) (hm : (∫ t, g t) = 1) :
    Tendsto (kernelStep g) atTop (nhds 1) := by
  simpa only [hm] using kernel_step_tendsto_mass hi

-- NEW: Positivity gives monotonicity of the actual integral step response.
theorem positive_kernel_step_monotone {g : ℝ → ℝ}
    (hi : Integrable g) (hn : ∀ᵐ t, 0 ≤ g t) : Monotone (kernelStep g) := by
  intro s t hst
  exact setIntegral_mono_set hi.integrableOn (ae_restrict_of_ae hn)
    (Filter.Eventually.of_forall (fun u hu => le_trans hu hst))

-- NEW: The converse uses the Lebesgue fundamental theorem and nonnegative
-- derivatives of monotone functions; positivity is not assumed in this direction.
theorem kernel_step_monotone_iff {g : ℝ → ℝ} (hi : Integrable g) :
    Monotone (kernelStep g) ↔ ∀ᵐ t, 0 ≤ g t := by
  constructor
  · intro hmono
    have he (t : ℝ) : (∫ u in (0 : ℝ)..t, g u) =
        kernelStep g t - kernelStep g 0 :=
      (intervalIntegral.integral_Iic_sub_Iic hi.integrableOn hi.integrableOn).symm
    have hm : Monotone (fun t : ℝ => ∫ u in (0 : ℝ)..t, g u) := by
      intro s t hst
      dsimp only
      rw [he s, he t]
      exact sub_le_sub_right (hmono hst) _
    filter_upwards [LocallyIntegrable.ae_hasDerivAt_integral hi.locallyIntegrable] with t ht
    exact (ht 0).nonneg_of_monotone hm
  · exact positive_kernel_step_monotone hi

-- NEW: Unit mass gives the exact no-overshoot bounds.
theorem positive_kernel_step_bounds {g : ℝ → ℝ}
    (hi : Integrable g) (hn : ∀ᵐ t, 0 ≤ g t)
    (hm : (∫ t, g t) = 1) (t : ℝ) :
    0 ≤ kernelStep g t ∧ kernelStep g t ≤ 1 := by
  constructor
  · exact setIntegral_nonneg_of_ae hn
  · simpa only [hm, kernelStep] using setIntegral_le_integral (s := Iic t) hi hn

/-- All-future settling in the absolute error band about the unit reference. -/
def SettledBy (y : ℝ → ℝ) (ε H : ℝ) : Prop :=
  ∀ t, H ≤ t → |1 - y t| ≤ ε

-- NEW: Proposition 16's all-future condition reduces to one horizon inequality.
theorem positive_kernel_settledBy_iff {g : ℝ → ℝ}
    (hi : Integrable g) (hn : ∀ᵐ t, 0 ≤ g t)
    (hm : (∫ t, g t) = 1) (ε H : ℝ) :
    SettledBy (kernelStep g) ε H ↔ 1 - ε ≤ kernelStep g H := by
  have hb := positive_kernel_step_bounds hi hn hm
  have hmono := positive_kernel_step_monotone hi hn
  constructor
  · intro h
    have hh := h H le_rfl
    rw [abs_of_nonneg (sub_nonneg.mpr (hb H).2)] at hh
    linarith
  · intro h t ht
    rw [abs_of_nonneg (sub_nonneg.mpr (hb t).2)]
    have hh := hmono ht
    linarith

/-- The three actual, weight-independent impulse-response basis functions. -/
def affineKernel (g0 gb gc : ℝ → ℝ) (w : ℝ × ℝ) (t : ℝ) : ℝ :=
  g0 t + w.1 * gb t + w.2 * gc t

theorem affineKernel_integrable {g0 gb gc : ℝ → ℝ}
    (h0 : Integrable g0) (hb : Integrable gb) (hc : Integrable gc)
    (w : ℝ × ℝ) : Integrable (affineKernel g0 gb gc w) :=
  (h0.add (hb.const_mul w.1)).add (hc.const_mul w.2)

theorem affineKernel_causal {g0 gb gc : ℝ → ℝ}
    (h0 : MIACE.Causal g0) (hb : MIACE.Causal gb) (hc : MIACE.Causal gc)
    (w : ℝ × ℝ) : MIACE.Causal (affineKernel g0 gb gc w) := by
  filter_upwards [h0, hb, hc] with t ht0 htb htc hneg
  simp [affineKernel, ht0 hneg, htb hneg, htc hneg]

/-- The all-time almost-everywhere positivity constraints. -/
def positiveWeights (g0 gb gc : ℝ → ℝ) : Set (ℝ × ℝ) :=
  {w | ∀ᵐ t, 0 ≤ affineKernel g0 gb gc w t}

-- NEW: The continuum of sign constraints is genuinely convex, with a.e. quantifiers retained.
theorem positiveWeights_convex (g0 gb gc : ℝ → ℝ) :
    Convex ℝ (positiveWeights g0 gb gc) := by
  intro x hx y hy a b ha hb hab
  change (∀ᵐ t, 0 ≤ affineKernel g0 gb gc (a • x + b • y) t)
  change (∀ᵐ t, 0 ≤ affineKernel g0 gb gc x t) at hx
  change (∀ᵐ t, 0 ≤ affineKernel g0 gb gc y t) at hy
  filter_upwards [hx, hy] with t hxt hyt
  change 0 ≤ g0 t + (a * x.1 + b * y.1) * gb t +
    (a * x.2 + b * y.2) * gc t
  calc
    0 ≤ a * affineKernel g0 gb gc x t + b * affineKernel g0 gb gc y t :=
      add_nonneg (mul_nonneg ha hxt) (mul_nonneg hb hyt)
    _ = (a + b) * g0 t + (a * x.1 + b * y.1) * gb t +
        (a * x.2 + b * y.2) * gc t := by simp only [affineKernel]; ring
    _ = _ := by rw [hab, one_mul]

-- NEW: Engineering constraints may be any convex set, including unbounded sets.
theorem feasibleWeights_convex (g0 gb gc : ℝ → ℝ)
    {X : Set (ℝ × ℝ)} (hX : Convex ℝ X) :
    Convex ℝ (X ∩ positiveWeights g0 gb gc) :=
  hX.inter (positiveWeights_convex g0 gb gc)

-- NEW: The horizon output depends affinely on the two weights through actual integrals.
theorem kernelStep_affine (g0 gb gc : ℝ → ℝ)
    (h0 : Integrable g0) (hb : Integrable gb) (hc : Integrable gc)
    (w : ℝ × ℝ) (H : ℝ) :
    kernelStep (affineKernel g0 gb gc w) H =
      kernelStep g0 H + w.1 * kernelStep gb H + w.2 * kernelStep gc H := by
  unfold kernelStep affineKernel
  have hsum : IntegrableOn (fun u => g0 u + w.1 * gb u) (Iic H) :=
    h0.integrableOn.add (hb.const_mul w.1).integrableOn
  rw [integral_add hsum
      (hc.const_mul w.2).integrableOn,
    integral_add h0.integrableOn (hb.const_mul w.1).integrableOn,
    integral_const_mul, integral_const_mul]

-- NEW: The fixed-horizon test is a closed halfspace in the original weights.
theorem horizonWeights_closed (g0 gb gc : ℝ → ℝ)
    (h0 : Integrable g0) (hb : Integrable gb) (hc : Integrable gc)
    (H threshold : ℝ) :
    IsClosed {w : ℝ × ℝ | threshold ≤ kernelStep (affineKernel g0 gb gc w) H} := by
  have hcont : Continuous (fun w : ℝ × ℝ => kernelStep (affineKernel g0 gb gc w) H) := by
    simp_rw [kernelStep_affine g0 gb gc h0 hb hc]
    fun_prop
  exact isClosed_le continuous_const hcont

theorem horizonWeights_convex (g0 gb gc : ℝ → ℝ)
    (h0 : Integrable g0) (hb : Integrable gb) (hc : Integrable gc)
    (H threshold : ℝ) :
    Convex ℝ {w : ℝ × ℝ | threshold ≤ kernelStep (affineKernel g0 gb gc w) H} := by
  intro x hx y hy a b ha hb' hab
  change threshold ≤ kernelStep (affineKernel g0 gb gc (a • x + b • y)) H
  have hcomb : kernelStep (affineKernel g0 gb gc (a • x + b • y)) H =
      a * kernelStep (affineKernel g0 gb gc x) H +
      b * kernelStep (affineKernel g0 gb gc y) H := by
    simp only [kernelStep_affine g0 gb gc h0 hb hc, Prod.fst_add, Prod.smul_fst,
      Prod.snd_add, Prod.smul_snd, smul_eq_mul]
    calc
      _ = (a + b) * kernelStep g0 H +
          (a * x.1 + b * y.1) * kernelStep gb H +
          (a * x.2 + b * y.2) * kernelStep gc H := by rw [hab, one_mul]
      _ = _ := by ring
  rw [hcomb]
  calc
    threshold = a * threshold + b * threshold := by rw [← add_mul, hab, one_mul]
    _ ≤ _ := add_le_add (mul_le_mul_of_nonneg_left hx ha)
      (mul_le_mul_of_nonneg_left hy hb')

-- NEW: Combine the actual all-time band criterion with its affine horizon formula.
theorem affine_kernel_settledBy_iff (g0 gb gc : ℝ → ℝ)
    (h0 : Integrable g0) (hb : Integrable gb) (hc : Integrable gc)
    (w : ℝ × ℝ) (hn : w ∈ positiveWeights g0 gb gc)
    (hm : (∫ t, affineKernel g0 gb gc w t) = 1) (ε H : ℝ) :
    SettledBy (kernelStep (affineKernel g0 gb gc w)) ε H ↔
      1 - ε ≤ kernelStep g0 H + w.1 * kernelStep gb H + w.2 * kernelStep gc H := by
  rw [positive_kernel_settledBy_iff (affineKernel_integrable h0 hb hc w) hn hm,
    kernelStep_affine g0 gb gc h0 hb hc]

end Article14
