import Article14.PIDFAlgebra
import Article14.LaplaceMoments
import Article14.PhysicalCentering
import Mathlib.Analysis.Calculus.Deriv.Shift
import Mathlib.Topology.Order.Compact

/-!
# From all-history internal stability to physical response estimates

A continuous centered step trajectory satisfies the homogeneous delayed
equations after the first delay interval.  Translating that interval supplies
a complete initial history for the stability property already formalized in
`PIDFAlgebra`.  Compactness bounds the initial interval; the resulting estimate
holds from time zero.  In particular, exponential decay of the response is a
conclusion here, rather than an assumption about its transfer function.
-/

namespace Article14
open Set Filter MeasureTheory MIACE
open scoped Topology

-- @paper-step thm:delay-fastest/physical-tail-is-history-solution
/-- The centered response after the input switch is an actual homogeneous
history solution.  Its differential equation is required only for `t > L`. -/
theorem retardedShared_shifted_solution {X : Type*}
    [NormedAddCommGroup X] [NormedSpace ℝ X]
    (plantOutput : X → ℝ) (plantDynamics : X → ℝ → X)
    (Kp Ti Td Tf L b c : ℝ) (z : ℝ → X × ℝ × ℝ)
    (hcont : ContinuousOn z (Ici 0))
    (hode : ∀ t, L < t → HasDerivAt z
      (retardedSharedRhs plantOutput plantDynamics Kp Ti Td Tf L b c
        (fun _ => 0) (fun θ => z (t + θ))) t) :
    IsRetardedSharedSolution plantOutput plantDynamics Kp Ti Td Tf L b c
      (fun t => z (t + L)) (fun t => z (t + L)) := by
  refine ⟨?_, fun _ _ => rfl, ?_⟩
  · apply hcont.comp (continuous_id.add continuous_const).continuousOn
    intro t ht
    change 0 ≤ t + L
    change -L ≤ t at ht
    linarith
  · intro t ht
    have hd := (hode (t + L) (by linarith)).comp_add_const t L
    convert hd using 1
    simp only [add_comm, add_left_comm]

-- @paper-step thm:delay-fastest/internal-stability-implies-response-decay
/-- All-history exponential stability gives a global exponential estimate for
every continuous centered trajectory satisfying the physical homogeneous
equations after the delay.  No bound on that trajectory is assumed. -/
theorem retardedShared_stable_tail_decay {X : Type*}
    [NormedAddCommGroup X] [NormedSpace ℝ X]
    (plantOutput : X → ℝ) (plantDynamics : X → ℝ → X)
    (Kp Ti Td Tf L b c : ℝ) (z : ℝ → X × ℝ × ℝ)
    (hL : 0 ≤ L)
    (hstable : IsRetardedSharedExponentiallyStable plantOutput plantDynamics
      Kp Ti Td Tf L b c)
    (hcont : ContinuousOn z (Ici 0))
    (hode : ∀ t, L < t → HasDerivAt z
      (retardedSharedRhs plantOutput plantDynamics Kp Ti Td Tf L b c
        (fun _ => 0) (fun θ => z (t + θ))) t) :
    ∃ C α : ℝ, 0 < C ∧ 0 < α ∧
      ∀ t, 0 ≤ t → ‖z t‖ ≤ C * Real.exp (-α * t) := by
  obtain ⟨M, α, hM, hα, hdecay⟩ := hstable.2
  obtain ⟨s, hs, hmax⟩ := isCompact_Icc.exists_isMaxOn
    (show (Icc (0 : ℝ) L).Nonempty from ⟨0, le_rfl, hL⟩)
    (hcont.norm.mono (fun _ ht => ht.1))
  let H := ‖z s‖ + 1
  have hH : 0 < H := by dsimp [H]; positivity
  have hbound : ∀ t ∈ Icc 0 L, ‖z t‖ ≤ H := by
    intro t ht
    exact (hmax ht).trans (by dsimp [H]; linarith)
  have hhistory : ∀ θ ∈ Icc (-L) 0, ‖z (θ + L)‖ ≤ H := by
    intro θ hθ
    apply hbound
    constructor <;> linarith [hθ.1, hθ.2]
  have hsolution := retardedShared_shifted_solution plantOutput plantDynamics
    Kp Ti Td Tf L b c z hcont hode
  have htail := hdecay (fun t => z (t + L)) (fun t => z (t + L)) H
    hhistory hsolution
  let M' := max M 1
  have hM' : 0 < M' := lt_of_lt_of_le zero_lt_one (le_max_right M 1)
  have hM'M : M ≤ M' := le_max_left M 1
  have hM'1 : 1 ≤ M' := le_max_right M 1
  refine ⟨M' * H * Real.exp (α * L), α, by positivity, hα, ?_⟩
  intro t ht
  have hexp : Real.exp (α * (L - t)) =
      Real.exp (α * L) * Real.exp (-α * t) := by
    rw [← Real.exp_add]
    congr 1
    ring
  by_cases htL : t ≤ L
  · calc
      ‖z t‖ ≤ H := hbound t ⟨ht, htL⟩
      _ ≤ M' * H := by nlinarith
      _ ≤ M' * H * Real.exp (α * (L - t)) := by
        have he : 1 ≤ Real.exp (α * (L - t)) :=
          Real.one_le_exp (mul_nonneg hα.le (sub_nonneg.mpr htL))
        exact le_mul_of_one_le_right (by positivity) he
      _ = M' * H * Real.exp (α * L) * Real.exp (-α * t) := by rw [hexp]; ring
  · have htl : 0 ≤ t - L := by linarith
    have he := htail (t - L) htl
    simp only [sub_add_cancel] at he
    calc
      ‖z t‖ ≤ M * Real.exp (-α * (t - L)) * H := he
      _ ≤ M' * Real.exp (-α * (t - L)) * H := by gcongr
      _ = M' * H * Real.exp (α * L) * Real.exp (-α * t) := by
        have hx : -α * (t - L) = α * (L - t) := by ring
        rw [hx, hexp]
        ring

-- @paper-step thm:delay-fastest/raw-physical-step-implies-decay
/-- The actual unit-step equations and the plant equilibrium imply decay of
the centered complete state.  The homogeneous equation used by stability is
proved by affine translation, rather than requested as an extra assumption. -/
theorem stable_actual_step_decay {X : Type*}
    [NormedAddCommGroup X] [NormedSpace ℝ X]
    (A : X →L[ℝ] X) (B : ℝ →L[ℝ] X) (C : X →L[ℝ] ℝ)
    (Kp Ti Td Tf L k b c : ℝ) (xe : X)
    (hk : k ≠ 0) (hKp : Kp ≠ 0) (hTi : Ti ≠ 0) (hL : 0 ≤ L)
    (heq : A xe + B (1 / k) = 0) (hout : C xe = 1)
    (hstable : IsRetardedSharedExponentiallyStable C (linearPlantDynamics A B)
      Kp Ti Td Tf L b c)
    (q : ℝ → X × ℝ × ℝ) (hq : ContinuousOn q (Ici 0))
    (hode : ∀ t, L < t → HasDerivAt q
      (retardedSharedRhs C (linearPlantDynamics A B) Kp Ti Td Tf L b c
        (fun _ => 1) (fun θ => q (t + θ))) t) :
    ∃ D α : ℝ, 0 < D ∧ 0 < α ∧ ∀ t, 0 ≤ t →
      ‖q t - pidfEquilibrium xe Ti k Kp b c‖ ≤ D * Real.exp (-α * t) := by
  apply retardedShared_stable_tail_decay C (linearPlantDynamics A B)
    Kp Ti Td Tf L b c (fun t => q t - pidfEquilibrium xe Ti k Kp b c)
    hL hstable (hq.sub continuousOn_const)
  intro t ht
  exact centeredTrajectory_hasDerivAt A B C Kp Ti Td Tf L k b c xe
    hk hKp hTi heq hout q t (hode t ht)

-- @paper-step thm:delay-fastest/stable-linear-signal-decay
/-- Every continuous linear observation of the complete centered state inherits
the derived exponential estimate.  This includes tracking error and command. -/
theorem linear_observable_exp_decay {E : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    (z : ℝ → E) (ℓ : E →L[ℝ] ℝ) {C α : ℝ} (hC : 0 < C)
    (hdecay : ∀ t, 0 ≤ t → ‖z t‖ ≤ C * Real.exp (-α * t)) :
    ∃ D : ℝ, 0 < D ∧
      ∀ t, 0 ≤ t → |ℓ (z t)| ≤ D * Real.exp (-α * t) := by
  refine ⟨(‖ℓ‖ + 1) * C, by positivity, ?_⟩
  intro t ht
  calc
    |ℓ (z t)| = ‖ℓ (z t)‖ := (Real.norm_eq_abs _).symm
    _ ≤ ‖ℓ‖ * ‖z t‖ := ℓ.le_opNorm (z t)
    _ ≤ ‖ℓ‖ * (C * Real.exp (-α * t)) := by
      exact mul_le_mul_of_nonneg_left (hdecay t ht) (norm_nonneg _)
    _ ≤ (‖ℓ‖ + 1) * C * Real.exp (-α * t) := by
      nlinarith [Real.exp_pos (-α * t)]

-- @paper-step thm:delay-fastest/stable-linear-signal-integrability
/-- The signal is integrable on the physical positive half-line; its extension
to negative times need not be continuous. -/
theorem integrable_of_continuousOn_exp_decay {e : ℝ → ℝ}
    (he : ContinuousOn e (Ici 0)) {C α : ℝ} (hα : 0 < α)
    (hdecay : ∀ t, 0 ≤ t → |e t| ≤ C * Real.exp (-α * t)) :
    Integrable e halfLine := by
  have hi := (integrableOn_exp_mul_Ioi (by linarith : -α < 0) 0).const_mul C
  apply hi.mono' ((he.mono Ioi_subset_Ici_self).aestronglyMeasurable measurableSet_Ioi)
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  exact hdecay t (le_of_lt (show 0 < t from ht))

-- @paper-step thm:delay-fastest/stable-state-limit
/-- Exponential decay gives convergence of the full centered state, including
every plant and controller coordinate. -/
theorem tendsto_zero_of_norm_exp_decay {E : Type*} [NormedAddCommGroup E]
    {z : ℝ → E} {C α : ℝ} (hα : 0 < α)
    (hdecay : ∀ t, 0 ≤ t → ‖z t‖ ≤ C * Real.exp (-α * t)) :
    Tendsto z atTop (𝓝 0) := by
  have he : Tendsto (fun t : ℝ => C * Real.exp (-α * t)) atTop (𝓝 0) := by
    have hh := Real.tendsto_exp_neg_atTop_nhds_zero.comp
      (tendsto_id.const_mul_atTop hα)
    simpa [neg_mul] using hh.const_mul C
  apply squeeze_zero_norm' _ he
  filter_upwards [eventually_ge_atTop (0 : ℝ)] with t ht
  exact hdecay t ht

-- @paper-step thm:delay-fastest/stable-observables-admissible
/-- All analytic admissibility conditions for a scalar linear observation
follow from the state estimate: continuity on physical time, integrability,
decay to zero, and a positive exponential envelope. -/
theorem linear_observable_admissible {E : Type*}
    [NormedAddCommGroup E] [NormedSpace ℝ E]
    (z : ℝ → E) (ℓ : E →L[ℝ] ℝ)
    (hz : ContinuousOn z (Ici 0)) {C α : ℝ} (hC : 0 < C) (hα : 0 < α)
    (hdecay : ∀ t, 0 ≤ t → ‖z t‖ ≤ C * Real.exp (-α * t)) :
    ContinuousOn (fun t => ℓ (z t)) (Ici 0) ∧
    Integrable (fun t => ℓ (z t)) halfLine ∧
    Tendsto (fun t => ℓ (z t)) atTop (𝓝 0) ∧
    ∃ D : ℝ, 0 < D ∧
      ∀ t, 0 ≤ t → |ℓ (z t)| ≤ D * Real.exp (-α * t) := by
  have hc := ℓ.continuous.comp_continuousOn hz
  obtain ⟨D, hD, hd⟩ := linear_observable_exp_decay z ℓ hC hdecay
  refine ⟨hc, integrable_of_continuousOn_exp_decay hc hα hd, ?_, D, hD, hd⟩
  have hl := tendsto_zero_of_norm_exp_decay hα hdecay
  simpa only [Function.comp_def, map_zero] using ℓ.continuous.continuousAt.tendsto.comp hl

/-- A constant extension to negative times preserves every physical signal
value. It permits direct reuse of the existing full-line continuity APIs. -/
noncomputable def nonnegativeTimeExtension (e : ℝ → ℝ) (t : ℝ) : ℝ :=
  e (max t 0)

theorem nonnegativeTimeExtension_continuous {e : ℝ → ℝ}
    (he : ContinuousOn e (Ici 0)) : Continuous (nonnegativeTimeExtension e) := by
  exact he.comp_continuous (continuous_id.max continuous_const) (fun t => le_max_right t 0)

theorem nonnegativeTimeExtension_ae (e : ℝ → ℝ) :
    nonnegativeTimeExtension e =ᵐ[halfLine] e := by
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  exact congrArg e (max_eq_left (le_of_lt (show 0 < t from ht)))

theorem nonnegativeTimeExtension_laplace (e : ℝ → ℝ) :
    laplace (nonnegativeTimeExtension e) = laplace e := by
  funext p
  exact laplace_congr_halfLine (nonnegativeTimeExtension_ae e) p

-- @paper-step prop:delay-second-moment/physical-halfline-moment-integrability
/-- The first time-weighted moment requires continuity only on physical time. -/
theorem error_first_moment_integrable_on_halfLine {e : ℝ → ℝ}
    (he : ContinuousOn e (Ici 0)) {C β : ℝ} (hC : 0 ≤ C) (hβ : 0 < β)
    (hdecay : ∀ t, 0 ≤ t → |e t| ≤ C * Real.exp (-β * t)) :
    Integrable (fun t => t * e t) halfLine := by
  have hd : ∀ t, 0 ≤ t → |nonnegativeTimeExtension e t| ≤ C * Real.exp (-β * t) := by
    intro t ht
    simpa only [nonnegativeTimeExtension, max_eq_left ht] using hdecay t ht
  have hi := error_first_moment_integrable (nonnegativeTimeExtension_continuous he) hC hβ hd
  apply hi.congr
  filter_upwards [nonnegativeTimeExtension_ae e] with t ht
  rw [ht]

-- @paper-step prop:delay-second-moment/physical-halfline-laplace-derivative
/-- Differentiation under the actual positive-time Laplace integral is valid
without assumptions on the signal's negative-time extension. -/
theorem error_laplace_derivative_at_zero_on_halfLine {e : ℝ → ℝ}
    (he : ContinuousOn e (Ici 0)) {C β : ℝ} (hC : 0 ≤ C) (hβ : 0 < β)
    (hdecay : ∀ t, 0 ≤ t → |e t| ≤ C * Real.exp (-β * t)) :
    HasDerivAt (laplace e) (-(∫ t, t * e t ∂halfLine)) 0 := by
  have hd : ∀ t, 0 ≤ t → |nonnegativeTimeExtension e t| ≤ C * Real.exp (-β * t) := by
    intro t ht
    simpa only [nonnegativeTimeExtension, max_eq_left ht] using hdecay t ht
  have hdLap := error_laplace_derivative_at_zero (nonnegativeTimeExtension_continuous he)
    hC hβ hd
  have hmoment : (∫ t, t * nonnegativeTimeExtension e t ∂halfLine) =
      ∫ t, t * e t ∂halfLine := by
    apply integral_congr_ae
    filter_upwards [nonnegativeTimeExtension_ae e] with t ht
    rw [ht]
  rwa [nonnegativeTimeExtension_laplace, hmoment] at hdLap

-- @paper-step prop:delay-second-moment/physical-halfline-signed-moment
/-- The previously proved exact signed moment formula applies to actual
physical signals continuous only for nonnegative time. -/
theorem tracking_error_first_moment_on_halfLine {e Q : ℝ → ℝ}
    (he : ContinuousOn e (Ici 0)) {C β : ℝ} (hC : 0 ≤ C) (hβ : 0 < β)
    (hdecay : ∀ t, 0 ≤ t → |e t| ≤ C * Real.exp (-β * t))
    (Kp Ki Kd Tf b c k Γ : ℝ)
    (hQ : HasDerivAt Q (Γ / k) 0) (hQ0 : Q 0 = 1 / k) (hKi : Ki ≠ 0)
    (htransfer : laplace e =ᶠ[𝓝[>] (0 : ℝ)] clearedError Q Kp Ki Kd Tf b c) :
    (∫ t, t * e t ∂halfLine) =
      secondErrorMoment Kp Ki Kd k Γ ((1 / k + (1 - b) * Kp) / Ki) c := by
  have hd : ∀ t, 0 ≤ t → |nonnegativeTimeExtension e t| ≤ C * Real.exp (-β * t) := by
    intro t ht
    simpa only [nonnegativeTimeExtension, max_eq_left ht] using hdecay t ht
  have htr : laplace (nonnegativeTimeExtension e) =ᶠ[𝓝[>] (0 : ℝ)]
      clearedError Q Kp Ki Kd Tf b c := by
    rwa [nonnegativeTimeExtension_laplace]
  have hmoment := tracking_error_first_moment (nonnegativeTimeExtension_continuous he)
    hC hβ hd Kp Ki Kd Tf b c k Γ hQ hQ0 hKi htr
  calc
    (∫ t, t * e t ∂halfLine) = (∫ t, t * nonnegativeTimeExtension e t ∂halfLine) := by
      apply integral_congr_ae
      filter_upwards [nonnegativeTimeExtension_ae e] with t ht
      rw [ht]
    _ = _ := hmoment

-- @paper-step prop:delay-second-moment/physical-halfline-itae
/-- Under nonnegative tracking error, the actual ITAE equals the PIDF moment
formula using only continuity and exponential decay on physical time. -/
theorem tracking_itae_on_halfLine {e Q : ℝ → ℝ}
    (he : ContinuousOn e (Ici 0)) {C β : ℝ} (hC : 0 ≤ C) (hβ : 0 < β)
    (hdecay : ∀ t, 0 ≤ t → |e t| ≤ C * Real.exp (-β * t))
    (hn : ∀ᵐ t ∂halfLine, 0 ≤ e t) (Kp Ki Kd Tf b c k Γ : ℝ)
    (hQ : HasDerivAt Q (Γ / k) 0) (hQ0 : Q 0 = 1 / k) (hKi : Ki ≠ 0)
    (htransfer : laplace e =ᶠ[𝓝[>] (0 : ℝ)] clearedError Q Kp Ki Kd Tf b c) :
    (∫ t, t * |e t| ∂halfLine) =
      secondErrorMoment Kp Ki Kd k Γ ((1 / k + (1 - b) * Kp) / Ki) c := by
  calc
    (∫ t, t * |e t| ∂halfLine) = (∫ t, t * e t ∂halfLine) := by
      apply integral_congr_ae
      filter_upwards [hn] with t ht
      rw [abs_of_nonneg ht]
    _ = _ := tracking_error_first_moment_on_halfLine he hC hβ hdecay
      Kp Ki Kd Tf b c k Γ hQ hQ0 hKi htransfer

end Article14
