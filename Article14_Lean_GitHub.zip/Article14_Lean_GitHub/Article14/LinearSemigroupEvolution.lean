import Article14.PIDFAlgebra
import Mathlib.Analysis.SpecialFunctions.Exponential
import Mathlib.Analysis.Calculus.Deriv.Mul
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus

/-!
# Actual initial-value evolution of a bounded linear autonomous ODE

The exponential solution exists for every initial state. Every continuous
classical trajectory on nonnegative time equals it, even though no derivative
at time zero is assumed. An operator exponential bound therefore controls all
actual solutions, not just a selected exponential formula.
-/

namespace Article14

open Set MeasureTheory NormedSpace
open scoped Topology

variable {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E] [CompleteSpace E]

noncomputable def linearEvolution (A : E →L[ℝ] E) (x₀ : E) (t : ℝ) : E :=
  (exp (t • A)) x₀

theorem linearEvolution_hasDerivAt (A : E →L[ℝ] E) (x₀ : E) (t : ℝ) :
    HasDerivAt (linearEvolution A x₀) (A (linearEvolution A x₀ t)) t := by
  change HasDerivAt (fun y : ℝ => (exp (y • A)) x₀) (A ((exp (t • A)) x₀)) t
  have h := (hasDerivAt_exp_smul_const' A t).clm_apply (hasDerivAt_const t x₀)
  simpa only [mul_apply_eq_comp, map_zero, add_zero] using h

theorem linearEvolution_continuous (A : E →L[ℝ] E) (x₀ : E) :
    Continuous (linearEvolution A x₀) :=
  continuous_iff_continuousAt.mpr (fun t => (linearEvolution_hasDerivAt A x₀ t).continuousAt)

omit [CompleteSpace E] in
theorem linearEvolution_zero (A : E →L[ℝ] E) (x₀ : E) :
    linearEvolution A x₀ 0 = x₀ := by simp [linearEvolution]

/-- Multiplying an actual homogeneous trajectory by the inverse exponential
makes its derivative zero at every positive time. -/
theorem linear_ode_inverse_evolution_derivative
    (A : E →L[ℝ] E) {x : ℝ → E} {t : ℝ}
    (hx : HasDerivAt x (A (x t)) t) :
    HasDerivAt (fun s => (exp (s • (-A))) (x s)) 0 t := by
  have h := (hasDerivAt_exp_smul_const (-A) t).clm_apply hx
  simpa [mul_apply_eq_comp] using h

/-- No differentiability condition at the initial endpoint is needed. -/
theorem linear_ode_eq_evolution
    (A : E →L[ℝ] E) {x : ℝ → E}
    (hc : ContinuousOn x (Ici 0))
    (hd : ∀ t, 0 < t → HasDerivAt x (A (x t)) t)
    (t : ℝ) (ht : 0 ≤ t) : x t = linearEvolution A (x 0) t := by
  let : NormedAlgebra ℚ (E →L[ℝ] E) := .restrictScalars ℚ ℝ (E →L[ℝ] E)
  let y : ℝ → E := fun s => (exp (s • (-A))) (x s)
  have hyc : ContinuousOn y (Ici 0) := by
    apply ContinuousOn.clm_apply _ hc
    exact (continuous_iff_continuousAt.mpr (fun s =>
      (hasDerivAt_exp_smul_const (-A) s).continuousAt)).continuousOn
  have hyd : ∀ s ∈ Ioo 0 t, HasDerivAt y 0 s :=
    fun s hs => linear_ode_inverse_evolution_derivative A (hd s hs.1)
  have hftc := intervalIntegral.integral_eq_sub_of_hasDerivAt_of_le ht
    (hyc.mono (fun _ hs => hs.1)) hyd (intervalIntegrable_const :
      IntervalIntegrable (fun _ : ℝ => (0 : E)) volume 0 t)
  have heq : y t = x 0 := by
    simpa [y, sub_eq_zero] using hftc.symm
  have hinv : exp (t • A) * exp (t • (-A)) = (1 : E →L[ℝ] E) := by
    rw [smul_neg, ← exp_add_of_commute (Commute.refl (t • A)).neg_right]
    simp
  have hh := congrArg (fun z => (exp (t • A)) z) heq
  change (exp (t • A)) ((exp (t • (-A))) (x t)) = _ at hh
  rw [← mul_apply_eq_comp, hinv] at hh
  exact hh

theorem linear_ode_unique
    (A : E →L[ℝ] E) {x y : ℝ → E}
    (hx : ContinuousOn x (Ici 0)) (hy : ContinuousOn y (Ici 0))
    (hdx : ∀ t, 0 < t → HasDerivAt x (A (x t)) t)
    (hdy : ∀ t, 0 < t → HasDerivAt y (A (y t)) t)
    (hzero : x 0 = y 0) : EqOn x y (Ici 0) := by
  intro t ht
  rw [linear_ode_eq_evolution A hx hdx t ht,
    linear_ode_eq_evolution A hy hdy t ht, hzero]

/-- A proved exponential estimate on the operator yields the same estimate
for every actual solution and every bound on its initial state. -/
theorem linear_ode_decay_of_exp_bound
    (A : E →L[ℝ] E) {M α H : ℝ}
    (hbound : ∀ t, 0 ≤ t → ‖exp (t • A)‖ ≤ M * Real.exp (-α*t))
    {x : ℝ → E} (hc : ContinuousOn x (Ici 0))
    (hd : ∀ t, 0 < t → HasDerivAt x (A (x t)) t)
    (hzero : ‖x 0‖ ≤ H) (t : ℝ) (ht : 0 ≤ t) :
    ‖x t‖ ≤ M * Real.exp (-α*t) * H := by
  rw [linear_ode_eq_evolution A hc hd t ht, linearEvolution]
  exact (ContinuousLinearMap.le_opNorm _ _).trans
    (mul_le_mul (hbound t ht) hzero (norm_nonneg _) ((norm_nonneg _).trans (hbound t ht)))

variable {X : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X] [CompleteSpace X]

omit [CompleteSpace X] in
/-- At zero delay the shared state equation is the ordinary homogeneous
vector field. This identity retains all plant and controller states. -/
theorem retardedShared_zero_delay_eq_linear
    (plantOutput : X → ℝ) (plantDynamics : X → ℝ → X)
    (Kp Ti Td Tf b c : ℝ) (A : (X × ℝ × ℝ) →L[ℝ] (X × ℝ × ℝ))
    (hA : ∀ z, sharedClosedLoopRhs plantOutput plantDynamics Kp Ti Td Tf b c 0 z = A z)
    (history : ℝ → X × ℝ × ℝ) :
    retardedSharedRhs plantOutput plantDynamics Kp Ti Td Tf 0 b c
      (fun _ => 0) history = A (history 0) := by
  simpa only [retardedSharedRhs, neg_zero, sharedClosedLoopRhs] using hA (history 0)

omit [CompleteSpace X] in
theorem zeroDelay_shared_solution_iff_linear
    (plantOutput : X → ℝ) (plantDynamics : X → ℝ → X)
    (Kp Ti Td Tf b c : ℝ) (A : (X × ℝ × ℝ) →L[ℝ] (X × ℝ × ℝ))
    (hA : ∀ z, sharedClosedLoopRhs plantOutput plantDynamics Kp Ti Td Tf b c 0 z = A z)
    (history trajectory : ℝ → X × ℝ × ℝ) :
    IsRetardedSharedSolution plantOutput plantDynamics Kp Ti Td Tf 0 b c history trajectory ↔
      ContinuousOn trajectory (Ici 0) ∧ trajectory 0 = history 0 ∧
      ∀ t, 0 < t → HasDerivAt trajectory (A (trajectory t)) t := by
  simp only [IsRetardedSharedSolution, neg_zero, Icc_self, mem_singleton_iff,
    forall_eq, retardedShared_zero_delay_eq_linear _ _ _ _ _ _ _ _ A hA, add_zero]

/-- Every initial history at zero delay has a unique actual solution.
The exponential construction proves existence; no well-posedness assumption
is hidden in the matrix formulation. -/
theorem zeroDelay_shared_wellPosed_of_linear
    (plantOutput : X → ℝ) (plantDynamics : X → ℝ → X)
    (Kp Ti Td Tf b c : ℝ) (A : (X × ℝ × ℝ) →L[ℝ] (X × ℝ × ℝ))
    (hA : ∀ z, sharedClosedLoopRhs plantOutput plantDynamics Kp Ti Td Tf b c 0 z = A z) :
    IsRetardedSharedWellPosed plantOutput plantDynamics Kp Ti Td Tf 0 b c := by
  intro history _
  refine ⟨linearEvolution A (history 0), ?_, ?_⟩
  · apply (zeroDelay_shared_solution_iff_linear _ _ _ _ _ _ _ _ A hA _ _).mpr
    exact ⟨(linearEvolution_continuous A _).continuousOn, linearEvolution_zero A _,
      fun t _ => linearEvolution_hasDerivAt A _ t⟩
  · intro other ho
    obtain ⟨hc, hz, hd⟩ :=
      (zeroDelay_shared_solution_iff_linear _ _ _ _ _ _ _ _ A hA _ _).mp ho
    intro t ht
    rw [neg_zero] at ht
    rw [linear_ode_eq_evolution A hc hd t ht, hz]

/-- The actual all-history internal-stability predicate follows from an
operator exponential bound on the complete physical state matrix. -/
theorem zeroDelay_shared_stable_of_exp_bound
    (plantOutput : X → ℝ) (plantDynamics : X → ℝ → X)
    (Kp Ti Td Tf b c : ℝ) (A : (X × ℝ × ℝ) →L[ℝ] (X × ℝ × ℝ))
    (hA : ∀ z, sharedClosedLoopRhs plantOutput plantDynamics Kp Ti Td Tf b c 0 z = A z)
    {M α : ℝ} (hM : 0 < M) (hα : 0 < α)
    (hbound : ∀ t, 0 ≤ t → ‖exp (t • A)‖ ≤ M * Real.exp (-α*t)) :
    IsRetardedSharedExponentiallyStable plantOutput plantDynamics Kp Ti Td Tf 0 b c := by
  refine ⟨zeroDelay_shared_wellPosed_of_linear _ _ _ _ _ _ _ _ A hA,
    M, α, hM, hα, ?_⟩
  intro history trajectory H hh hs t ht
  obtain ⟨hc, hz, hd⟩ :=
    (zeroDelay_shared_solution_iff_linear _ _ _ _ _ _ _ _ A hA _ _).mp hs
  apply linear_ode_decay_of_exp_bound A hbound hc hd _ t ht
  rw [hz]
  exact hh 0 (by simp)

omit [CompleteSpace X] in
/-- A continuous change of complete state coordinates commutes with the
operator exponential. -/
theorem exp_conjugate_state_map (A : E →L[ℝ] E)
    (e : E ≃L[ℝ] (X × ℝ × ℝ)) (t : ℝ) :
    exp (t • e.conjContinuousAlgEquiv A) =
      e.conjContinuousAlgEquiv (exp (t • A)) := by
  let : NormedAlgebra ℚ (E →L[ℝ] E) := .restrictScalars ℚ ℝ (E →L[ℝ] E)
  let : NormedAlgebra ℚ ((X × ℝ × ℝ) →L[ℝ] (X × ℝ × ℝ)) :=
    .restrictScalars ℚ ℝ ((X × ℝ × ℝ) →L[ℝ] (X × ℝ × ℝ))
  rw [NormedSpace.map_exp e.conjContinuousAlgEquiv e.conjContinuousAlgEquiv.continuous,
    map_smul]

omit [CompleteSpace X] in
/-- Exponential decay is invariant under a continuous linear state
isomorphism, with an explicit history-independent multiplicative constant. -/
theorem conjugate_state_exp_bound (A : E →L[ℝ] E)
    (e : E ≃L[ℝ] (X × ℝ × ℝ)) {M α : ℝ} (hM : 0 < M)
    (hbound : ∀ t, 0 ≤ t → ‖exp (t • A)‖ ≤ M * Real.exp (-α*t))
    (t : ℝ) (ht : 0 ≤ t) :
    ‖exp (t • e.conjContinuousAlgEquiv A)‖ ≤
      ((‖e.toContinuousLinearMap‖+1)*M*(‖e.symm.toContinuousLinearMap‖+1)) *
        Real.exp (-α*t) := by
  rw [exp_conjugate_state_map, ContinuousLinearEquiv.conjContinuousAlgEquiv_apply]
  calc
    ‖e.toContinuousLinearMap.comp ((exp (t • A)).comp e.symm.toContinuousLinearMap)‖
      ≤ ‖e.toContinuousLinearMap‖ *
        (‖exp (t • A)‖ * ‖e.symm.toContinuousLinearMap‖) :=
          (ContinuousLinearMap.opNorm_comp_le _ _).trans
            (mul_le_mul_of_nonneg_left (ContinuousLinearMap.opNorm_comp_le _ _) (norm_nonneg _))
    _ ≤ (‖e.toContinuousLinearMap‖+1) *
        ((M*Real.exp (-α*t))*(‖e.symm.toContinuousLinearMap‖+1)) := by
      gcongr
      · exact le_add_of_nonneg_right zero_le_one
      · exact hbound t ht
      · exact le_add_of_nonneg_right zero_le_one
    _ = _ := by ring

/-- A matrix exponential estimate in any faithful finite set of state
coordinates establishes well-posedness and decay of the actual shared loop. -/
theorem zeroDelay_shared_stable_of_coordinate_exp_bound
    (plantOutput : X → ℝ) (plantDynamics : X → ℝ → X)
    (Kp Ti Td Tf b c : ℝ) (A : E →L[ℝ] E) (e : E ≃L[ℝ] (X × ℝ × ℝ))
    (hA : ∀ z, sharedClosedLoopRhs plantOutput plantDynamics Kp Ti Td Tf b c 0 z =
      e (A (e.symm z)))
    {M α : ℝ} (hM : 0 < M) (hα : 0 < α)
    (hbound : ∀ t, 0 ≤ t → ‖exp (t • A)‖ ≤ M * Real.exp (-α*t)) :
    IsRetardedSharedExponentiallyStable plantOutput plantDynamics Kp Ti Td Tf 0 b c := by
  apply zeroDelay_shared_stable_of_exp_bound plantOutput plantDynamics Kp Ti Td Tf b c
    (e.conjContinuousAlgEquiv A) hA
    (M := (‖e.toContinuousLinearMap‖+1)*M*(‖e.symm.toContinuousLinearMap‖+1))
    (by positivity) hα
  exact conjugate_state_exp_bound A e hM hbound

end Article14
