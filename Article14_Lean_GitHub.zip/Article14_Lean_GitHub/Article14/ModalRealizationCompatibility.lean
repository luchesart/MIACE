import Article14.PhysicalModalOptimization
import Mathlib.LinearAlgebra.Matrix.Charpoly.Basic
import Mathlib.Topology.Algebra.Polynomial
import Article14.MatrixPencilRegularity
import Mathlib.Analysis.Calculus.Deriv.Inverse
import Mathlib.Analysis.Calculus.Deriv.Polynomial

/-!
# Modal transfer of the same physical shared-D realization

The full state matrix is built from the actual finite plant A,B,C and the
implemented controller gains.  Its resolvent, the plant adjugate numerator,
and the cleared feedback denominator are therefore parts of one realization.
-/
namespace Article14.ModalRealization
open Matrix Set Filter
open scoped Topology Matrix

variable {n : Type*} [Fintype n] [DecidableEq n]
variable {K : Type*} [Field K]

/-- Plant coordinates plus the integrator (`false`) and filter (`true`). -/
def encodeState (x : n → K) (i f : K) : n ⊕ Bool → K :=
  Sum.elim x (fun b => if b then f else i)

def stateOutput (C : n → K) (q : n ⊕ Bool → K) : K := ∑ j, C j*q (.inl j)

def stateCommand (C : n → K) (kp ti td tf b c r : K) (q : n ⊕ Bool → K) : K :=
  kp*(b*r-stateOutput C q+q (.inr false)/ti+
    td/tf*(c*r-stateOutput C q-q (.inr true)))

/-- The homogeneous command coefficients in the implemented shared-D state. -/
def commandRow (C : n → K) (kp ti td tf : K) : n ⊕ Bool → K :=
  Sum.elim (fun j => -kp*(1+td/tf)*C j)
    (fun b => if b then -kp*(td/tf) else kp/ti)

/-- The complete physical closed-loop state matrix, with no weight dependence. -/
def sharedMatrix (A : Matrix n n K) (B C : n → K) (kp ti td tf : K) :
    Matrix (n ⊕ Bool) (n ⊕ Bool) K :=
  fun i j => match i with
  | .inl l => (match j with | .inl m => A l m | .inr _ => 0) +
      B l*commandRow C kp ti td tf j
  | .inr false => match j with | .inl m => -C m | .inr _ => 0
  | .inr true => match j with | .inl m => -C m/tf
                                | .inr false => 0 | .inr true => -1/tf

/-- The physical reference forcing vector includes command feedthrough. -/
def referenceVector (B : n → K) (kp td tf b c : K) : n ⊕ Bool → K :=
  Sum.elim (fun j => B j*(kp*(b+td/tf*c))) (fun flag => if flag then c/tf else 1)

omit [DecidableEq n] in
theorem commandRow_dot (C : n → K) (kp ti td tf : K) (q : n ⊕ Bool → K) :
    commandRow C kp ti td tf ⬝ᵥ q = stateCommand C kp ti td tf 0 0 0 q := by
  simp only [dotProduct, Fintype.sum_sum_type, Fintype.sum_bool, commandRow,
    Sum.elim_inl, Sum.elim_inr, Bool.false_eq_true, ite_false, ite_true,
    stateCommand, stateOutput, zero_mul]
  have hh (a : K) : (∑ j, a*C j*q (.inl j)) = a*(∑ j, C j*q (.inl j)) := by
    simp [mul_assoc, Finset.mul_sum]
  rw [hh]
  ring

-- This identity identifies the matrix with the entire implemented physical
-- vector field, including the reference forcing and both controller states.
omit [DecidableEq n] in
theorem sharedMatrix_forced_components (A : Matrix n n K) (B C : n → K)
    (kp ti td tf b c r : K) (q : n ⊕ Bool → K) :
    sharedMatrix A B C kp ti td tf *ᵥ q + r • referenceVector B kp td tf b c =
      encodeState
        (fun j => (∑ l, A j l*q (.inl l)) + B j*stateCommand C kp ti td tf b c r q)
        (r-stateOutput C q) ((c*r-stateOutput C q-q (.inr true))/tf) := by
  ext j
  cases j with
  | inl j =>
    simp only [mulVec, dotProduct, sharedMatrix, encodeState, referenceVector,
      Fintype.sum_sum_type, Fintype.sum_bool, Sum.elim_inl, Sum.elim_inr,
      commandRow, Bool.false_eq_true, ite_false, ite_true,
      Pi.add_apply, Pi.smul_apply, smul_eq_mul]
    simp only [add_mul, Finset.sum_add_distrib, zero_add]
    simp only [stateCommand, stateOutput]
    have hh (a : K) : (∑ l, a*C l*q (.inl l)) = a*(∑ l, C l*q (.inl l)) := by
      simp [mul_assoc, Finset.mul_sum]
    simp_rw [← mul_assoc]
    rw [hh]
    ring
  | inr flag =>
    cases flag <;>
      simp only [mulVec, dotProduct, sharedMatrix, encodeState, referenceVector,
        Fintype.sum_sum_type, Fintype.sum_bool, Sum.elim_inr,
        Bool.false_eq_true, ite_false, ite_true, Pi.add_apply, Pi.smul_apply,
        smul_eq_mul, zero_mul, Finset.sum_const_zero, add_zero,
        stateOutput, neg_mul, Finset.sum_neg_distrib]
    · ring
    · simp only [div_mul_eq_mul_div, ← Finset.sum_div, neg_mul, Finset.sum_neg_distrib]
      ring

-- The real specialization is the very same vector field used by the
-- StepLoopDynamics trajectories in the sampled engineering constraints.
omit [DecidableEq n] in
theorem sharedMatrix_matches_physical (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf b c r : ℝ) (q : (n → ℝ) × ℝ × ℝ) :
    sharedMatrix A B C Kp Ti Td Tf *ᵥ encodeState q.1 q.2.1 q.2.2 +
      r • referenceVector B Kp Td Tf b c =
    encodeState
      (sharedClosedLoopRhs (finitePlantOutput C) (finitePlantDynamics A B)
        Kp Ti Td Tf b c r q).1
      (sharedClosedLoopRhs (finitePlantOutput C) (finitePlantDynamics A B)
        Kp Ti Td Tf b c r q).2.1
      (sharedClosedLoopRhs (finitePlantOutput C) (finitePlantDynamics A B)
        Kp Ti Td Tf b c r q).2.2 := by
  rw [sharedMatrix_forced_components]
  rfl


/-- Resolvent pencil, valid for both the plant and complete controller state. -/
noncomputable def statePencil (A : Matrix n n K) (z : K) : Matrix n n K := z • 1 - A

-- A nonsingular full-state pencil solves precisely its frequency balance.
theorem inverse_pencil_balance (A : Matrix n n K) (r : n → K) (z : K)
    (hz : (statePencil A z).det ≠ 0) :
    z • ((statePencil A z)⁻¹ *ᵥ r) =
      A *ᵥ ((statePencil A z)⁻¹ *ᵥ r) + r := by
  have hh : statePencil A z *ᵥ ((statePencil A z)⁻¹ *ᵥ r) = r := by
    rw [mulVec_mulVec, mul_nonsing_inv _ (isUnit_iff_ne_zero.mpr hz), one_mulVec]
  simp only [statePencil, sub_mulVec, smul_mulVec, one_mulVec] at hh
  exact (sub_eq_iff_eq_add.mp hh).trans (add_comm _ _)

/-- Entrywise complexification of the very same physical state matrix. -/
noncomputable def complexMatrix (A : Matrix n n ℝ) : Matrix n n ℂ :=
  A.map (algebraMap ℝ ℂ)
noncomputable def complexVector (B : n → ℝ) : n → ℂ := fun j => (B j:ℂ)

-- Complexification commutes with the physical matrix construction, including
-- its finite filter and integral gains.
omit [Fintype n] [DecidableEq n] in
theorem sharedMatrix_complexification (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf : ℝ) :
    sharedMatrix (complexMatrix A) (complexVector B) (complexVector C)
      (Kp:ℂ) (Ti:ℂ) (Td:ℂ) (Tf:ℂ) =
      complexMatrix (sharedMatrix A B C Kp Ti Td Tf) := by
  ext i j
  cases i with
  | inl i =>
    cases j with
    | inl j => simp [sharedMatrix, commandRow, complexMatrix, complexVector, Complex.coe_algebraMap]
    | inr j => cases j <;> simp [sharedMatrix, commandRow, complexMatrix, complexVector, Complex.coe_algebraMap]
  | inr i =>
    cases i <;> cases j with
    | inl j => simp [sharedMatrix, complexMatrix, complexVector, Complex.coe_algebraMap]
    | inr j => cases j <;> simp [sharedMatrix, complexMatrix, Complex.coe_algebraMap]

/-- Numerator computed from the actual plant's adjugate, without an independent
polynomial certificate. -/
noncomputable def plantNumerator (A : Matrix n n ℝ) (B C : n → ℝ) (z : ℂ) : ℂ :=
  complexVector C ⬝ᵥ ((statePencil (complexMatrix A) z).adjugate *ᵥ complexVector B)

noncomputable def plantDenominator (A : Matrix n n ℝ) (z : ℂ) : ℂ :=
  (statePencil (complexMatrix A) z).det

/-- The complete closed-loop denominator obtained by clearing the implemented
integrator and derivative-filter denominators. -/
noncomputable def feedbackDenominator (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf : ℝ) (z : ℂ) : ℂ :=
  (Ti:ℂ)*z*(1+(Tf:ℂ)*z)*plantDenominator A z +
    (Kp:ℂ)*plantNumerator A B C z*pidfReferenceValue Ti Td Tf (1,1) z

/-- The frequency response of the complete physical state resolvent. -/
noncomputable def referenceResolvent (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf : ℝ) (w : ℝ × ℝ) (z : ℂ) : ℂ :=
  stateOutput (complexVector C)
    ((statePencil (sharedMatrix (complexMatrix A) (complexVector B) (complexVector C)
      (Kp:ℂ) (Ti:ℂ) (Td:ℂ) (Tf:ℂ)) z)⁻¹ *ᵥ
      referenceVector (complexVector B) (Kp:ℂ) (Td:ℂ) (Tf:ℂ) (w.1:ℂ) (w.2:ℂ))

-- Adjugate multiplication extracts the scalar plant balance without requiring
-- the plant pencil to be nonsingular at the frequency in question.
theorem adjugate_plant_balance (A : Matrix n n K) (B C x : n → K) (u z : K)
    (h : ∀ j, z*x j = (∑ l, A j l*x l)+B j*u) :
    (statePencil A z).det*(C ⬝ᵥ x) =
      (C ⬝ᵥ ((statePencil A z).adjugate *ᵥ B))*u := by
  have hp : statePencil A z *ᵥ x = u • B := by
    change (z • (1 : Matrix n n K) - A) *ᵥ x = u • B
    rw [sub_mulVec, smul_mulVec, one_mulVec]
    ext j
    simp only [Pi.sub_apply, Pi.smul_apply, smul_eq_mul, mulVec, dotProduct]
    linear_combination h j
  have ha := congrArg (fun v => (statePencil A z).adjugate *ᵥ v) hp
  rw [mulVec_mulVec, adjugate_mul, smul_mulVec, one_mulVec, mulVec_smul] at ha
  have hc := congrArg (fun v => C ⬝ᵥ v) ha
  simpa only [dotProduct_smul, smul_eq_mul, mul_comm] using hc

-- Frequency-domain elimination of the actual integral/filter states.  This
-- identity is polynomial in z, so no division by z or by 1+Tf*z is needed.
theorem controller_cleared_balance (kp ti td tf b c z y i f u : K)
    (hti : ti ≠ 0) (htf : tf ≠ 0)
    (hi : z*i = 1-y) (hf : z*f = (c-y-f)/tf)
    (hu : u = kp*(b-y+i/ti+td/tf*(c-y-f))) :
    ti*z*(1+tf*z)*u = kp*
      ((1+(tf+b*ti)*z+ti*(b*tf+c*td)*z^2) -
        (1+(tf+ti)*z+ti*(tf+td)*z^2)*y) := by
  have hf' : tf*z*f = c-y-f := by
    have hh := (eq_div_iff htf).mp hf
    linear_combination hh
  have huf : u = kp*(b-y+i/ti+td*z*f) := by
    rw [hu, ← hf']
    field_simp
  have hbase : ti*z*u = kp*(ti*z*(b-y)+(1-y)+ti*td*z^2*f) := by
    rw [huf]
    field_simp
    linear_combination kp*hi
  linear_combination (1+tf*z)*hbase + (kp*ti*td*z^2)*hf'


-- The normalized quadratic appears unchanged when evaluated in the actual
-- complex state equations.
theorem pidfReferenceValue_direct (Ti Td Tf : ℝ) (w : ℝ × ℝ) (z : ℂ) :
    pidfReferenceValue Ti Td Tf w z =
      1+((Tf:ℂ)+(w.1:ℂ)*(Ti:ℂ))*z+
        (Ti:ℂ)*((w.1:ℂ)*(Tf:ℂ)+(w.2:ℂ)*(Td:ℂ))*z^2 := by
  rw [pidfReferenceValue_affine]
  ring

-- Elimination starts with the full implemented state resolvent, not with an
-- independently supplied polynomial transfer representation.
theorem referenceResolvent_cleared (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf : ℝ) (w : ℝ × ℝ) (z : ℂ)
    (hTi : Ti ≠ 0) (hTf : Tf ≠ 0)
    (hz : (statePencil (sharedMatrix (complexMatrix A) (complexVector B) (complexVector C)
      (Kp:ℂ) (Ti:ℂ) (Td:ℂ) (Tf:ℂ)) z).det ≠ 0) :
    feedbackDenominator A B C Kp Ti Td Tf z * referenceResolvent A B C Kp Ti Td Tf w z =
      (Kp:ℂ)*plantNumerator A B C z*pidfReferenceValue Ti Td Tf w z := by
  let M := sharedMatrix (complexMatrix A) (complexVector B) (complexVector C)
    (Kp:ℂ) (Ti:ℂ) (Td:ℂ) (Tf:ℂ)
  let r := referenceVector (complexVector B) (Kp:ℂ) (Td:ℂ) (Tf:ℂ) (w.1:ℂ) (w.2:ℂ)
  let q := (statePencil M z)⁻¹ *ᵥ r
  let y := stateOutput (complexVector C) q
  let u := stateCommand (complexVector C) (Kp:ℂ) (Ti:ℂ) (Td:ℂ) (Tf:ℂ) (w.1:ℂ) (w.2:ℂ) 1 q
  have hq : z • q = encodeState
      (fun j => (∑ l, complexMatrix A j l*q (.inl l))+complexVector B j*u)
      (1-y) (((w.2:ℂ)-y-q (.inr true))/(Tf:ℂ)) := by
    have hh := inverse_pencil_balance M r z hz
    have hf := sharedMatrix_forced_components (complexMatrix A) (complexVector B) (complexVector C)
      (Kp:ℂ) (Ti:ℂ) (Td:ℂ) (Tf:ℂ) (w.1:ℂ) (w.2:ℂ) 1 q
    simp only [one_smul, mul_one] at hf
    exact hh.trans hf
  have hx : ∀ j, z*q (.inl j) =
      (∑ l, complexMatrix A j l*q (.inl l))+complexVector B j*u := by
    intro j
    exact congrFun hq (.inl j)
  have hi : z*q (.inr false) = 1-y := congrFun hq (.inr false)
  have hf : z*q (.inr true) = ((w.2:ℂ)-y-q (.inr true))/(Tf:ℂ) :=
    congrFun hq (.inr true)
  have hp := adjugate_plant_balance (complexMatrix A) (complexVector B) (complexVector C)
    (fun j => q (.inl j)) u z hx
  change plantDenominator A z*y = plantNumerator A B C z*u at hp
  have hc := controller_cleared_balance (Kp:ℂ) (Ti:ℂ) (Td:ℂ) (Tf:ℂ)
    (w.1:ℂ) (w.2:ℂ) z y (q (.inr false)) (q (.inr true)) u
    (Complex.ofReal_ne_zero.mpr hTi) (Complex.ofReal_ne_zero.mpr hTf) hi hf
    (by simp only [u, stateCommand, mul_one]; rfl)
  change feedbackDenominator A B C Kp Ti Td Tf z*y = _
  unfold feedbackDenominator
  simp only [pidfReferenceValue_direct, Complex.ofReal_one, one_mul]
  linear_combination ((Ti:ℂ)*z*(1+(Tf:ℂ)*z))*hp + plantNumerator A B C z*hc

-- The concrete B and Delta used in the modal maps are now forced by A,B,C.
theorem referenceResolvent_eq (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf : ℝ) (w : ℝ × ℝ) (z : ℂ)
    (hTi : Ti ≠ 0) (hTf : Tf ≠ 0)
    (hz : (statePencil (sharedMatrix (complexMatrix A) (complexVector B) (complexVector C)
      (Kp:ℂ) (Ti:ℂ) (Td:ℂ) (Tf:ℂ)) z).det ≠ 0)
    (hΔ : feedbackDenominator A B C Kp Ti Td Tf z ≠ 0) :
    referenceResolvent A B C Kp Ti Td Tf w z =
      (Kp:ℂ)*plantNumerator A B C z*pidfReferenceValue Ti Td Tf w z /
        feedbackDenominator A B C Kp Ti Td Tf z := by
  apply (eq_div_iff hΔ).2
  simpa only [mul_comm] using referenceResolvent_cleared A B C Kp Ti Td Tf w z hTi hTf hz


/-- The adjugate numerator is a concrete polynomial of the plant realization. -/
noncomputable def plantNumeratorPolynomial (A : Matrix n n ℝ) (B C : n → ℝ) : Polynomial ℂ :=
  (fun j => Polynomial.C (C j:ℂ)) ⬝ᵥ
    ((complexMatrix A).charmatrix.adjugate *ᵥ (fun j => Polynomial.C (B j:ℂ)))

theorem eval_charmatrix (A : Matrix n n ℂ) (z : ℂ) :
    (Polynomial.evalRingHom z).mapMatrix A.charmatrix = statePencil A z := by
  ext i j
  by_cases hij : i=j
  · subst j
    simp [statePencil, Matrix.charmatrix, Matrix.scalar_apply]
  · simp [statePencil, Matrix.charmatrix, Matrix.scalar_apply, hij]

theorem plantNumeratorPolynomial_eval (A : Matrix n n ℝ) (B C : n → ℝ) (z : ℂ) :
    (plantNumeratorPolynomial A B C).eval z = plantNumerator A B C z := by
  have ha := (Polynomial.evalRingHom z).map_adjugate (complexMatrix A).charmatrix
  rw [eval_charmatrix] at ha
  have he (i j : n) :
      ((complexMatrix A).charmatrix.adjugate i j).eval z =
        (statePencil (complexMatrix A) z).adjugate i j := congrFun (congrFun ha i) j
  simp only [plantNumeratorPolynomial, plantNumerator, dotProduct, mulVec,
    Polynomial.eval_finsetSum, Polynomial.eval_mul, Polynomial.eval_C, he, complexVector]

theorem plantNumerator_differentiable (A : Matrix n n ℝ) (B C : n → ℝ) :
    Differentiable ℂ (plantNumerator A B C) := by
  have he : plantNumerator A B C = fun z => (plantNumeratorPolynomial A B C).eval z := by
    funext z
    exact (plantNumeratorPolynomial_eval A B C z).symm
  rw [he]
  exact (plantNumeratorPolynomial A B C).differentiable

theorem feedbackDenominator_differentiable (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf : ℝ) : Differentiable ℂ (feedbackDenominator A B C Kp Ti Td Tf) := by
  have hp : plantDenominator A = fun z => (complexMatrix A).charpoly.eval z := by
    funext z
    simp [plantDenominator, Matrix.eval_charpoly, statePencil, Matrix.scalar_apply,
      Matrix.smul_one_eq_diagonal]
  have hP : Differentiable ℂ (plantDenominator A) := by
    rw [hp]
    exact (complexMatrix A).charpoly.differentiable
  have hN := plantNumerator_differentiable A B C
  unfold feedbackDenominator
  simp_rw [pidfReferenceValue_direct]
  fun_prop

-- Every punctured neighborhood of a simple selected root contains only regular
-- full-state frequencies after possibly shrinking it.  Open-loop poles are
-- harmless because only the full-state characteristic polynomial is used.
theorem referenceResolvent_eventually_eq (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf : ℝ) (w : ℝ × ℝ) (p : ℂ)
    (hTi : Ti ≠ 0) (hTf : Tf ≠ 0)
    (hd : deriv (feedbackDenominator A B C Kp Ti Td Tf) p ≠ 0) :
    referenceResolvent A B C Kp Ti Td Tf w =ᶠ[𝓝[≠] p]
      (fun z => (Kp:ℂ)*plantNumerator A B C z*pidfReferenceValue Ti Td Tf w z /
        feedbackDenominator A B C Kp Ti Td Tf z) := by
  have hM := matrix_pencil_eventually_ne_zero
    (sharedMatrix (complexMatrix A) (complexVector B) (complexVector C)
      (Kp:ℂ) (Ti:ℂ) (Td:ℂ) (Tf:ℂ)) p
  have hD := (feedbackDenominator_differentiable A B C Kp Ti Td Tf p).hasDerivAt.eventually_ne (c := 0) hd
  filter_upwards [hM, hD] with z hz hΔ
  apply referenceResolvent_eq A B C Kp Ti Td Tf w z hTi hTf _ hΔ
  simpa only [statePencil, Matrix.scalar_apply, Matrix.smul_one_eq_diagonal] using hz

-- The modal coefficients are now residues of the full shared-state resolvent
-- belonging to the same A,B,C as the time-domain response constraints.
theorem same_realization_modal_residues (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf : ℝ) (w : ℝ × ℝ) (p : ℂ)
    (hTi : Ti ≠ 0) (hTf : Tf ≠ 0)
    (hzero : feedbackDenominator A B C Kp Ti Td Tf p = 0)
    (hd : deriv (feedbackDenominator A B C Kp Ti Td Tf) p ≠ 0) (hp : p ≠ 0) :
    let d := deriv (feedbackDenominator A B C Kp Ti Td Tf) p
    HasSimpleResidue (referenceResolvent A B C Kp Ti Td Tf w) p
      (pidfResidueAffine Kp Ti Td Tf (plantNumerator A B C p) d p w) ∧
    HasSimpleResidue (fun z => referenceResolvent A B C Kp Ti Td Tf w z/z) p
      (pidfStepAmplitudeAffine Kp Ti Td Tf (plantNumerator A B C p) d p w) := by
  dsimp only
  have hh := pidf_modal_residue_and_step_amplitude Kp Ti Td Tf
    (plantNumerator_differentiable A B C p).continuousAt
    (feedbackDenominator_differentiable A B C Kp Ti Td Tf p).hasDerivAt
    hzero hd hp w
  have he := referenceResolvent_eventually_eq A B C Kp Ti Td Tf w p hTi hTf hd
  constructor
  · apply hh.1.congr'
    filter_upwards [he] with z hz
    rw [hz]
  · apply hh.2.congr'
    filter_upwards [he] with z hz
    rw [hz]


/-- Coordinate encoding as a continuous linear map, preserving derivatives of
actual physical state trajectories. -/
noncomputable def encodedStateMap : ((n → ℝ) × ℝ × ℝ) →L[ℝ] (n ⊕ Bool → ℝ) :=
  ContinuousLinearMap.pi (fun j => match j with
    | .inl l => plantCoordinate l
    | .inr false => integralCoordinate
    | .inr true => filterCoordinate)

omit [Fintype n] [DecidableEq n] in
theorem encodedStateMap_apply (q : (n → ℝ) × ℝ × ℝ) :
    encodedStateMap q = encodeState q.1 q.2.1 q.2.2 := by
  ext j
  cases j with
  | inl j => simp [encodedStateMap, encodeState, plantCoordinate]
  | inr j => cases j <;> simp [encodedStateMap, encodeState, integralCoordinate, filterCoordinate]

-- Every actual zero-delay step trajectory used in the sampled constraints
-- satisfies this same matrix ODE.  This closes the time/frequency realization
-- identification rather than merely comparing two transfer formulas.
omit [DecidableEq n] in
theorem encoded_actual_step_ode
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf 0 b c q) (t : ℝ) (ht : 0<t) :
    HasDerivAt (fun s => encodeState (q s).1 (q s).2.1 (q s).2.2)
      (sharedMatrix A B C Kp Ti Td Tf *ᵥ encodeState (q t).1 (q t).2.1 (q t).2.2 +
        referenceVector B Kp Td Tf b c) t := by
  have hd := h.after_delay t ht
  have hr : retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf 0 b c (fun _ => 1) (fun θ => q (t+θ)) =
      sharedClosedLoopRhs (finitePlantOutput C) (finitePlantDynamics A B)
        Kp Ti Td Tf b c 1 (q t) := by
    simp [retardedSharedRhs, sharedClosedLoopRhs]
  rw [hr] at hd
  have hh := encodedStateMap.hasFDerivAt.comp_hasDerivAt t hd
  have hf := sharedMatrix_matches_physical A B C Kp Ti Td Tf b c 1 (q t)
  simp only [one_smul] at hf
  simp only [Function.comp_def, encodedStateMap_apply] at hh
  rw [← hf] at hh
  exact hh

/-- Modal maps whose numerator and denominator are generated from the same
physical scenario.  There is no independent Bpole or derivative certificate. -/
noncomputable def samePlantModalAffine (stepObjective : Bool)
    (A : Matrix n n ℝ) (B C : n → ℝ) (Kp Ti Td Tf : ℝ) (p : ℂ) :
    (ℝ × ℝ) →ᵃ[ℝ] ℂ :=
  declaredModalAffine stepObjective Kp Ti Td Tf (plantNumerator A B C p)
    (deriv (feedbackDenominator A B C Kp Ti Td Tf) p) p

-- Both optimization modes are actual modal coefficients of the physical
-- state resolvent, with the selected pole verified against its own Delta.
theorem samePlantModalAffine_is_residue (stepObjective : Bool)
    (A : Matrix n n ℝ) (B C : n → ℝ) (Kp Ti Td Tf : ℝ) (p : ℂ)
    (hTi : Ti ≠ 0) (hTf : Tf ≠ 0)
    (hzero : feedbackDenominator A B C Kp Ti Td Tf p = 0)
    (hd : deriv (feedbackDenominator A B C Kp Ti Td Tf) p ≠ 0)
    (hp : p ≠ 0) (w : ℝ × ℝ) :
    HasSimpleResidue (fun z => if stepObjective then
        referenceResolvent A B C Kp Ti Td Tf w z/z
      else referenceResolvent A B C Kp Ti Td Tf w z) p
      (samePlantModalAffine stepObjective A B C Kp Ti Td Tf p w) := by
  have hh := same_realization_modal_residues A B C Kp Ti Td Tf w p hTi hTf hzero hd hp
  cases stepObjective
  · exact hh.1
  · exact hh.2

-- Complete compatibility version of Proposition 10: the modal objective and
-- every sampled output/command constraint use the same declared A,B,C family.
-- Existing physical basis trajectories can be supplied by StepExistence.
theorem same_realization_constrained_modal_minimizer {ι κ : Type*}
    (s : Finset ι) (hne : s.Nonempty) (stepObjective : Bool)
    (A : ι → Matrix n n ℝ) (B C : ι → n → ℝ) (Kp Ti Td Tf : ℝ)
    (hTi : Ti ≠ 0) (hTf : Tf ≠ 0) (p : ι → ℂ)
    (hzero : ∀ i ∈ s, feedbackDenominator (A i) (B i) (C i) Kp Ti Td Tf (p i) = 0)
    (hd : ∀ i ∈ s, deriv (feedbackDenominator (A i) (B i) (C i) Kp Ti Td Tf) (p i) ≠ 0)
    (hp : ∀ i ∈ s, p i ≠ 0)
    (q00 q10 q01 : ι → ℝ → (n → ℝ) × ℝ × ℝ)
    (h00 : ∀ i, StepLoopDynamics (A i) (B i) (C i) Kp Ti Td Tf 0 0 0 (q00 i))
    (h10 : ∀ i, StepLoopDynamics (A i) (B i) (C i) Kp Ti Td Tf 0 1 0 (q10 i))
    (h01 : ∀ i, StepLoopDynamics (A i) (B i) (C i) Kp Ti Td Tf 0 0 1 (q01 i))
    (scenario : κ → ι) (H yl yu ul uu : κ → ℝ)
    {X : Set (ℝ × ℝ)} (hX : IsCompact X) (hXc : Convex ℝ X)
    (hfeas : (X ∩ physicalScenarioSampleBounds (C ∘ scenario) Kp Ti Td Tf
      (q00 ∘ scenario) (q10 ∘ scenario) (q01 ∘ scenario) H yl yu ul uu).Nonempty) :
    let F := X ∩ physicalScenarioSampleBounds (C ∘ scenario) Kp Ti Td Tf
      (q00 ∘ scenario) (q10 ∘ scenario) (q01 ∘ scenario) H yl yu ul uu
    let z := fun i => samePlantModalAffine stepObjective (A i) (B i) (C i) Kp Ti Td Tf (p i)
    (∀ i ∈ s, ∀ w, HasSimpleResidue (fun a => if stepObjective then
        referenceResolvent (A i) (B i) (C i) Kp Ti Td Tf w a/a
      else referenceResolvent (A i) (B i) (C i) Kp Ti Td Tf w a) (p i) (z i w)) ∧
    Convex ℝ F ∧ IsCompact F ∧ ∃ w ∈ F,
      (∀ i, StepLoopDynamics (A i) (B i) (C i) Kp Ti Td Tf 0 w.1 w.2
        (stepAffineFamily (q00 i) (q10 i) (q01 i) w.1 w.2)) ∧
      ∀ v ∈ F, finiteModalCost s hne z w ≤ finiteModalCost s hne z v := by
  dsimp only
  refine ⟨fun i hi w => samePlantModalAffine_is_residue stepObjective (A i) (B i) (C i)
    Kp Ti Td Tf (p i) hTi hTf (hzero i hi) (hd i hi) (hp i hi) w, ?_⟩
  obtain ⟨hconv, hcompact, w, hw, _, hm⟩ :=
    physical_modal_minimizer_on_compact_polygon s hne stepObjective
      (A ∘ scenario) (B ∘ scenario) (C ∘ scenario) Kp Ti Td Tf
      (fun _ => 0) H yl yu ul uu (q00 ∘ scenario) (q10 ∘ scenario) (q01 ∘ scenario)
      (fun j => h00 (scenario j)) (fun j => h10 (scenario j)) (fun j => h01 (scenario j))
      (fun i => plantNumerator (A i) (B i) (C i) (p i))
      (fun i => deriv (feedbackDenominator (A i) (B i) (C i) Kp Ti Td Tf) (p i)) p
      hX hXc hfeas
  exact ⟨hconv, hcompact, w, hw,
    fun i => stepLoopDynamics_affine_family (h00 i) (h10 i) (h01 i) w.1 w.2, hm⟩

end Article14.ModalRealization
