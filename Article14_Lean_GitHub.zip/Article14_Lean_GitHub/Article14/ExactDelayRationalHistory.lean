import Article14.ExactDelayStateEquivalence
import Article14.ACClassical

/-! The inherited rational resolvent is converted into a classical solution
for every complete history. No state coordinate or compatible history is
omitted in this conversion. -/
namespace Article14.ExactDelay
open Set MeasureTheory Filter MIACE
open scoped Topology

noncomputable def fullRationalHistory (h : ℝ → LoopState) : RationalHistory where
  commandInitial := (h 0).2.1
  controllerInitial := fun _ => (h 0).2.2
  plantInitial := fun _ => (h 0).1 0
  outputInitial := (h 0).1 1
  past := fun t => (h t).2.1

noncomputable def rationalFuture (h : ℝ → LoopState) (w : ℝ → ℝ) (t : ℝ) : LoopState :=
  (![rationalBState (fun _ => 1) (1/4) (fullRationalHistory h) w 0 t,
    rationalOutput (fun _ => 1) 0 (1/4) (fullRationalHistory h) w t],
    w t, rationalIState (fun _ => 1) (1/4) (fullRationalHistory h) w 0 t)

noncomputable def rationalTrajectory (h : ℝ → LoopState) (w : ℝ → ℝ) (t : ℝ) : LoopState :=
  if t ≤ 0 then h t else rationalFuture h w t

theorem fullRationalHistory_bound {h : ℝ → LoopState} {H : ℝ}
    (hc : ContinuousOn h (Icc (-(1/4 : ℝ)) 0))
    (hb : ∀ t ∈ Icc (-(1/4 : ℝ)) 0, ‖h t‖ ≤ H) :
    RationalHistoryBound 0 (1/4) (fullRationalHistory h) H := by
  have h0 := hb 0 (by norm_num)
  have hnon : 0 ≤ H := (norm_nonneg _).trans h0
  have hp := (norm_prod_le_iff.mp h0)
  have hq := norm_prod_le_iff.mp hp.2
  refine ⟨hnon, ?_, ?_, ?_, ?_, hc.snd.fst, ?_⟩
  · simpa [fullRationalHistory] using hq.1
  · intro j hj
    simpa [fullRationalHistory] using hq.2
  · intro j hj
    exact (norm_le_pi_norm (h 0).1 0).trans hp.1
  · exact (norm_le_pi_norm (h 0).1 1).trans hp.1
  · intro t ht
    exact (norm_fst_le (h t).2).trans (norm_snd_le (h t)) |>.trans (hb t ht)

-- The old history input is integrable because it is a continuous history on
-- a finite interval; no assumption at infinity is inserted.
theorem fullRationalHistory_input_integrable {h : ℝ → LoopState}
    (hc : ContinuousOn h (Icc (-(1/4 : ℝ)) 0)) :
    Integrable (historyInput (1/4) (fullRationalHistory h).past) := by
  obtain ⟨M,hM⟩ := rational_history_bound_exists 0 (1/4) (fullRationalHistory h) hc.snd.fst
  exact weightedControl_unweighted
    (historyInput_control_on (by norm_num) (show (0 : ℝ) ≤ 0 by rfl)
      hM.nonneg hM.continuous hM.past)
    (historyInput_causal _ _) (by rfl)

theorem rationalFuture_initial {h : ℝ → LoopState} {w : ℝ → ℝ}
    (hw : w 0 = (h 0).2.1) : rationalFuture h w 0 = h 0 := by
  apply Prod.ext
  · ext j
    fin_cases j <;> simp [rationalFuture, rationalBState, rationalOutput,
      serialState, lagState, lag, fullRationalHistory]
  · apply Prod.ext
    · exact hw
    · simp [rationalFuture, rationalIState, remainderFilter, lagState, lag,
        fullRationalHistory]

theorem rationalFuture_continuous {h : ℝ → LoopState} {w : ℝ → ℝ}
    (hc : ContinuousOn h (Icc (-(1/4 : ℝ)) 0)) (hw : Continuous w) :
    Continuous (rationalFuture h w) := by
  have hi := fullRationalHistory_input_integrable hc
  have hdel : LocallyIntegrable (rationalDelayed (1/4) (fullRationalHistory h) w) volume :=
    hi.locallyIntegrable.add (scalarDelay_shift_local hw (1/4))
  have hB := (serialState_evolution hdel (fun _ => 1) (fullRationalHistory h).plantInitial 0).1
  have hY := (lagState_evolution hB.locallyIntegrable 1 (fullRationalHistory h).outputInitial).1
  have hI := remainderFilter_local hw.locallyIntegrable (fun _ => 1) (1/4)
    (fullRationalHistory h).controllerInitial 0
  apply Continuous.prodMk
  · apply continuous_pi
    intro j
    fin_cases j
    · simpa [rationalFuture, rationalBState] using hB
    · simpa [rationalFuture, rationalOutput, rationalBState] using hY
  · exact hw.prodMk hI

theorem rationalTrajectory_nonnegative {h : ℝ → LoopState} {w : ℝ → ℝ}
    (hw : w 0 = (h 0).2.1) {t : ℝ} (ht : 0 ≤ t) :
    rationalTrajectory h w t = rationalFuture h w t := by
  rcases ht.eq_or_lt with rfl | ht
  · simpa [rationalTrajectory] using (rationalFuture_initial hw).symm
  · simp [rationalTrajectory, not_le.mpr ht]

theorem rationalTrajectory_continuous {h : ℝ → LoopState} {w : ℝ → ℝ}
    (hc : ContinuousOn h (Icc (-(1/4 : ℝ)) 0)) (hw : Continuous w)
    (h0 : w 0 = (h 0).2.1) :
    ContinuousOn (rationalTrajectory h w) (Ici (-(1/4 : ℝ))) :=
  continuousOn_history_splice hc (rationalFuture_continuous hc hw).continuousOn
    (rationalFuture_initial h0)

theorem rationalDelayed_trajectory {h : ℝ → LoopState} {w : ℝ → ℝ}
    (hw : w 0 = (h 0).2.1) {t : ℝ} (ht : 0 ≤ t) :
    rationalDelayed (1/4) (fullRationalHistory h) w t =
      (rationalTrajectory h w (t-1/4)).2.1 := by
  by_cases htd : t < 1/4
  · have hneg : ¬0 ≤ t-1/4 := by linarith
    have hn : t-1/4 ≤ 0 := by linarith
    simp only [rationalDelayed, historyInput, fullRationalHistory, shift, causalize,
      rationalTrajectory, indicator_of_mem (show t ∈ Ico (0 : ℝ) (1/4) from ⟨ht, htd⟩),
      indicator_of_notMem (show t-1/4 ∉ Ici (0 : ℝ) from hneg), ite_eq_left hn, add_zero]
  · have ht0 : 0 ≤ t-1/4 := by linarith
    rw [rationalTrajectory_nonnegative hw ht0]
    simp only [rationalDelayed, historyInput, rationalFuture, shift, causalize,
      indicator_of_notMem (show t ∉ Ico (0 : ℝ) (1/4) from fun hh => htd hh.2),
      indicator_of_mem (show t-1/4 ∈ Ici (0 : ℝ) from ht0), zero_add]

theorem rationalFuture_lag_evolutions {h : ℝ → LoopState} {w : ℝ → ℝ}
    (hc : ContinuousOn h (Icc (-(1/4 : ℝ)) 0)) (hw : Continuous w) :
    LagEvolution 1 (h 0).2.2 (fun t => E*w t) (fun t => (rationalFuture h w t).2.2) ∧
    LagEvolution 1 ((h 0).1 0) (rationalDelayed (1/4) (fullRationalHistory h) w)
      (fun t => (rationalFuture h w t).1 0) ∧
    LagEvolution 1 ((h 0).1 1) (fun t => (rationalFuture h w t).1 0)
      (fun t => (rationalFuture h w t).1 1) := by
  have hi := fullRationalHistory_input_integrable hc
  have hdel : LocallyIntegrable (rationalDelayed (1/4) (fullRationalHistory h) w) volume :=
    hi.locallyIntegrable.add (scalarDelay_shift_local hw (1/4))
  have hB := lagState_evolution hdel 1 ((h 0).1 0)
  have hY := lagState_evolution hB.1.locallyIntegrable 1 ((h 0).1 1)
  have hI := lagState_evolution (hw.const_mul E).locallyIntegrable 1 (h 0).2.2
  simpa [rationalFuture, rationalIState, rationalBState, rationalOutput,
    serialState, remainderFilter, remainderFeed, fullRationalHistory, E] using
    And.intro hI.2 (And.intro hB.2 hY.2)

-- The apparent switch in historyInput+shift disappears for compatible
-- initial command values, so the delayed input is continuous through t=L.
theorem rationalDelayed_continuousOn {h : ℝ → LoopState} {w : ℝ → ℝ}
    (hc : ContinuousOn h (Icc (-(1/4 : ℝ)) 0)) (hw : Continuous w)
    (h0 : w 0 = (h 0).2.1) :
    ContinuousOn (rationalDelayed (1/4) (fullRationalHistory h) w) (Ici 0) := by
  have hh := (rationalTrajectory_continuous hc hw h0).snd.fst.comp
    (continuous_id.sub continuous_const).continuousOn
    (show MapsTo (fun t : ℝ => t-1/4) (Ici 0) (Ici (-(1/4 : ℝ))) from
      fun t ht => by change 0 ≤ t at ht; change -(1/4 : ℝ) ≤ t-1/4; linarith)
  exact hh.congr (fun t ht => rationalDelayed_trajectory h0 ht)

theorem rationalTrajectory_solution {h : ℝ → LoopState} {w : ℝ → ℝ}
    (hc : ContinuousOn h (Icc (-(1/4 : ℝ)) 0))
    (hw : RationalHistoryEvolution (fun _ => 1) 0 (1/4) a E (fullRationalHistory h) w) :
    IsRationalStateSolution h (rationalTrajectory h w) := by
  have h0 : w 0 = (h 0).2.1 := hw.initial
  have hf := rationalFuture_continuous hc hw.continuous
  have hl := rationalFuture_lag_evolutions hc hw.continuous
  have hdel := rationalDelayed_continuousOn hc hw.continuous h0
  have hwode : ∀ᵐ t : ℝ, 0<t → HasDerivAt w
      ((-E*w t+(rationalFuture h w t).2.2-(rationalFuture h w t).1 0)/a) t := by
    simpa [rationalFuture] using hw.ode
  have hwclass := locallyAC_hasDerivAt_of_continuous_rhs hw.ac
    (((hw.continuous.const_mul (-E)).add hf.snd.snd).sub
      ((continuous_apply 0).comp hf.fst) |>.div_const a).continuousOn hwode
  have hIclass := locallyAC_hasDerivAt_of_continuous_rhs hl.1.ac
    (((hw.continuous.const_mul E).sub hf.snd.snd).div_const 1).continuousOn hl.1.ode
  have hXclass := locallyAC_hasDerivAt_of_continuous_rhs hl.2.1.ac
    ((hdel.sub (((continuous_apply 0).comp hf.fst).continuousOn)).div_const 1) hl.2.1.ode
  have hYclass := locallyAC_hasDerivAt_of_continuous_rhs hl.2.2.ac
    (((continuous_apply 0).comp hf.fst).sub ((continuous_apply 1).comp hf.fst)
      |>.div_const 1).continuousOn hl.2.2.ode
  refine ⟨rationalTrajectory_continuous hc hw.continuous h0, ?_, ?_⟩
  · intro t ht
    simp only [rationalTrajectory, ite_eq_left ht.2]
  · intro t ht
    have hplant : HasDerivAt (fun s => (rationalFuture h w s).1)
        (![(rationalTrajectory h w (t-1/4)).2.1-(rationalFuture h w t).1 0,
          (rationalFuture h w t).1 0-(rationalFuture h w t).1 1]) t := by
      apply hasDerivAt_pi.mpr
      intro j
      fin_cases j
      · have hx := hXclass t ht
        change HasDerivAt (fun s => (rationalFuture h w s).1 0)
          ((rationalDelayed (1/4) (fullRationalHistory h) w t-
            (rationalFuture h w t).1 0)/1) t at hx
        rw [div_one, rationalDelayed_trajectory h0 ht.le] at hx
        simpa using hx
      · simpa using hYclass t ht
    have hd := hplant.prodMk ((hwclass t ht).prodMk (hIclass t ht))
    have he : rationalTrajectory h w =ᶠ[𝓝 t] rationalFuture h w := by
      filter_upwards [Ioi_mem_nhds ht] with s hs
      exact rationalTrajectory_nonnegative h0 hs.le
    have hd' := hd.congr_of_eventuallyEq he
    simpa only [rationalTrajectory_nonnegative h0 ht.le, rationalStateRhs,
      rationalFuture, Matrix.cons_val_zero, Matrix.cons_val_one,
      Matrix.head_cons, div_one, Pi.add_apply, Pi.sub_apply, Function.comp_def] using hd'

/-- The old uniform estimate controls every coordinate of the same complete
state. The product and finite-function norms are maximum norms. -/
theorem rationalTrajectory_decay {h : ℝ → LoopState} {w : ℝ → ℝ} {η D : ℝ}
    (hc : ContinuousOn h (Icc (-(1/4 : ℝ)) 0))
    (hw : RationalHistoryEvolution (fun _ => 1) 0 (1/4) a E (fullRationalHistory h) w)
    (hd : RationalInternalControl (fun _ => 1) 0 (1/4) (fullRationalHistory h) w η D)
    (t : ℝ) (ht : 0 ≤ t) :
    ‖rationalTrajectory h w t‖ ≤ D * Real.exp (-η*t) := by
  have hp := rational_internal_pointwise (fun _ => 1) 0 (fullRationalHistory h)
    (fullRationalHistory_input_integrable hc) hw hd
  have hnon : 0 ≤ D*Real.exp (-η*t) := (abs_nonneg (w t)).trans (hp.1 t ht)
  rw [rationalTrajectory_nonnegative hw.initial ht]
  apply norm_prod_le_iff.mpr
  constructor
  · apply (pi_norm_le_iff_of_nonneg hnon).mpr
    intro j
    fin_cases j
    · simpa [rationalFuture, Real.norm_eq_abs] using hp.2.2.1 0 (by omega) t ht
    · simpa [rationalFuture, Real.norm_eq_abs] using hp.2.2.2.1 t ht
  · apply norm_prod_le_iff.mpr
    constructor
    · simpa [rationalFuture, Real.norm_eq_abs] using hp.1 t ht
    · simpa [rationalFuture, Real.norm_eq_abs] using hp.2.1 0 (by omega) t ht

end Article14.ExactDelay
