import Article14.StepAffine
import Article14.StepUniqueness
import Article14.PhysicalImpulse

/-!+# Affinity of physical impulse kernels

The ordinary kernel is defined by the actual delayed plant equation.  Its
affine dependence on the two reference weights follows from the constructed
physical trajectory family, including the causal and initial-delay branches.
-/
namespace Article14
open MeasureTheory Filter Set MIACE
open scoped Topology
variable {n : Type*} [Fintype n]

theorem stepAffineFamily_impulse (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf L b c : ℝ) (q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ) (t : ℝ) :
    stepImpulse A B C Kp Ti Td Tf L b c (stepAffineFamily q00 q10 q01 b c) t =
      stepImpulse A B C Kp Ti Td Tf L 0 0 q00 t +
        b*(stepImpulse A B C Kp Ti Td Tf L 1 0 q10 t-
          stepImpulse A B C Kp Ti Td Tf L 0 0 q00 t) +
        c*(stepImpulse A B C Kp Ti Td Tf L 0 1 q01 t-
          stepImpulse A B C Kp Ti Td Tf L 0 0 q00 t) := by
  by_cases ht : t ≤ 0
  · simp [stepImpulse, ht]
  · simp only [stepImpulse, ht, ite_false]
    simp only [← Finset.sum_sub_distrib, Finset.mul_sum, ← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro j hj
    rw [stepAffineFamily_stateField]
    by_cases hw : t ≤ L
    · simp only [hw, ite_true, mul_zero, add_zero]
      ring
    · simp only [hw, ite_false, stepAffineFamily_command]
      ring

/-- The causal kernel depends only on the nonnegative-time trajectory; no
values from an arbitrary extension into negative time can change it. -/
theorem stepImpulse_congr_of_eqOn (A : Matrix n n ℝ) (B C : n → ℝ)
    (Kp Ti Td Tf L b c : ℝ) {q r : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : EqOn q r (Ici 0)) :
    stepImpulse A B C Kp Ti Td Tf L b c q =
      stepImpulse A B C Kp Ti Td Tf L b c r := by
  funext t
  by_cases ht : t ≤ 0
  · simp [stepImpulse, ht]
  · simp only [stepImpulse, ht, ite_false]
    rw [h (show t ∈ Ici 0 from (not_le.mp ht).le)]
    by_cases hd : t ≤ L
    · simp only [hd, ite_true]
    · simp only [hd, ite_false, stepCommand]
      rw [h (show t-L ∈ Ici 0 from (sub_pos.mpr (not_le.mp hd)).le)]

/-- The actual ordinary impulse response at arbitrary reference weights is
the affine combination of three physical basis kernels.  Existence and
uniqueness, rather than an affine-family premise, identify its trajectory. -/
theorem stepLoopDynamics_impulse_affine
    {A : Matrix n n ℝ} {B C xe : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ}
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0)
    (heq : ∀ j, (∑ l, A j l*xe l)+B j/k=0)
    (hout : (∑ j, C j*xe j) = 1)
    (hwp : IsRetardedSharedWellPosed (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L b c)
    (hq : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (h00 : StepLoopDynamics A B C Kp Ti Td Tf L 0 0 q00)
    (h10 : StepLoopDynamics A B C Kp Ti Td Tf L 1 0 q10)
    (h01 : StepLoopDynamics A B C Kp Ti Td Tf L 0 1 q01) (t : ℝ) :
    stepImpulse A B C Kp Ti Td Tf L b c q t =
      stepImpulse A B C Kp Ti Td Tf L 0 0 q00 t +
        b*(stepImpulse A B C Kp Ti Td Tf L 1 0 q10 t-
          stepImpulse A B C Kp Ti Td Tf L 0 0 q00 t) +
        c*(stepImpulse A B C Kp Ti Td Tf L 0 1 q01 t-
          stepImpulse A B C Kp Ti Td Tf L 0 0 q00 t) := by
  rw [stepImpulse_congr_of_eqOn A B C Kp Ti Td Tf L b c
    (stepLoopDynamics_eq_affine_family hTi hk hKp heq hout hwp hq h00 h10 h01)]
  exact stepAffineFamily_impulse A B C Kp Ti Td Tf L b c q00 q10 q01 t

end Article14
