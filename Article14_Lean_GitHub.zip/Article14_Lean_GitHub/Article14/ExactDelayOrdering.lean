import Article14.ExactDelayPhysicalSignals

/-!
# The physical q-prefilter identity and pointwise ordering

The identity is obtained from the two physical Laplace balances and uniqueness
for actual integrable error signals.  The low-pass state below describes the
response and is not an additional implemented PIDF state.
-/
namespace Article14.ExactDelay
open MeasureTheory Filter Set MIACE
open scoped Topology Convolution

variable (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput plantC)
  (finitePlantDynamics plantA plantB) kp ti td tf (1/4) 0 0)

-- The q-path error transform is an identity of the actual physical signals.
theorem physical_error_prefilter_transform (q p : ℝ) (hp : 0 < p) :
    laplace ((plantDataOfStable hs).error (pathWeights q)) p =
      q*laplace ((plantDataOfStable hs).error (pathWeights 1)) p +
        (1-q)*(1+laplace ((plantDataOfStable hs).error (pathWeights 1)) p)/(1+p) := by
  have hq := physical_plant_transform hs (pathWeights q) p hp
  have h1 := physical_plant_transform hs (pathWeights 1) p hp
  rw [physical_command_resolvent_transform hs q p hp] at hq
  rw [physical_command_resolvent_transform hs 1 p hp] at h1
  have hn : 1+p ≠ 0 := by linarith
  have hr : (1+p)*(1-p*laplace ((plantDataOfStable hs).error (pathWeights q)) p) =
      (1+q*p)*(1-p*laplace ((plantDataOfStable hs).error (pathWeights 1)) p) := by
    apply mul_left_cancel₀ (pow_ne_zero 2 hn)
    linear_combination (1+p)*hq - (1+q*p)*h1
  have hz : p*((1+p)*laplace ((plantDataOfStable hs).error (pathWeights q)) p -
      ((1+q*p)*laplace ((plantDataOfStable hs).error (pathWeights 1)) p+(1-q))) = 0 := by
    linear_combination -hr
  have he := (mul_eq_zero.mp hz).resolve_left hp.ne'
  field_simp
  linear_combination he

-- This is the article's y_q = q*y_1 + (1-q)*z, for the implemented loop.
theorem physical_path_prefilter (q : ℝ) (t : ℝ) (ht : 0 ≤ t) :
    (plantDataOfStable hs).output (pathWeights q) t =
      q*(plantDataOfStable hs).output (pathWeights 1) t +
        (1-q)*lag 1 ((plantDataOfStable hs).output (pathWeights 1)) t := by
  let D := plantDataOfStable hs
  let e1 : ℝ → ℝ := fun t => 1-D.output (pathWeights 1) t
  let ez : ℝ → ℝ := fun t => 1-lag 1 (D.output (pathWeights 1)) t
  have hi1 : Integrable e1 halfLine := D.output_deficit_integrable _
  have hiz : Integrable ez halfLine := lag_deficit_integrable
    (D.output_continuous _).locallyIntegrable hi1 (by norm_num)
  have heq : ∀ s, 0 ≤ s → 1-D.output (pathWeights q) s = q*e1 s+(1-q)*ez s := by
    apply laplace_injective_continuous (D.output_deficit_integrable _)
      ((hi1.const_mul q).add (hiz.const_mul (1-q)))
      (continuous_const.sub (D.output_continuous _))
      (((continuous_const.sub (D.output_continuous _)).const_mul q).add
        ((continuous_const.sub (lag_continuous (D.output_continuous _) 1)).const_mul (1-q)))
    intro p hp
    change laplace (fun t => 1-D.output (pathWeights q) t) p =
      laplace (fun t => q*e1 t+(1-q)*ez t) p
    rw [half_laplace_linear hi1 hiz q (1-q) hp.le]
    have hz : laplace ez p = (1+laplace e1 p)/(1+p) := by
      simpa [ez,e1] using lag_deficit_transform
        (D.output_continuous _).locallyIntegrable hi1 (by norm_num : (0:ℝ)<1) hp.le
    rw [hz]
    have hq : laplace (fun t => 1-D.output (pathWeights q) t) p =
        laplace (D.error (pathWeights q)) p :=
      laplace_congr_halfLine (D.error_eq_output_deficit _).symm p
    have h1 : laplace e1 p = laplace (D.error (pathWeights 1)) p :=
      laplace_congr_halfLine (D.error_eq_output_deficit _).symm p
    rw [hq,h1,physical_error_prefilter_transform hs q p hp]
    ring
  have hh := heq t ht
  dsimp only [e1,ez] at hh
  change D.output (pathWeights q) t = q*D.output (pathWeights 1) t+
    (1-q)*lag 1 (D.output (pathWeights 1)) t
  linarith

-- A positive lag remains below its nonnegative nondecreasing input; hence
-- increasing q improves the actual output at every nonnegative time.
theorem physical_path_output_order {q₁ q₂ : ℝ} (hq : q₁ ≤ q₂)
    (t : ℝ) (ht : 0 ≤ t) :
    (plantDataOfStable hs).output (pathWeights q₁) t ≤
      (plantDataOfStable hs).output (pathWeights q₂) t := by
  let D := plantDataOfStable hs
  have h1 : (1:ℝ) ∈ Icc (0:ℝ) 1 := by constructor <;> norm_num
  have hb := lag_order_bounds (D.output_continuous (pathWeights 1)).continuousOn
    (fun s _ => (physical_path_output_bounds hs h1 s).1)
    ((physical_path_monotone hs h1).monotoneOn _) 1 t (by norm_num) ht
  rw [physical_path_prefilter hs q₁ t ht,physical_path_prefilter hs q₂ t ht]
  exact output_order hq hb.2

end Article14.ExactDelay
