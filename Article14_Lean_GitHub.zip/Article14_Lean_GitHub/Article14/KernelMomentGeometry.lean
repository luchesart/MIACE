import Article14.TrackingMoments
import Article14.FeasibleGeometry

/-!
The ordinary impulse kernel, rather than a formal transfer expansion, controls
variance and parameter identifiability.  The first two results hold for any
measure; the L¹ specialization uses the inherited whole-line `MIACE.RealL1`.
No positivity is needed for identifiability.  Positivity and unit mass are
needed for variance, exactly as for a probability density.
-/
namespace Article14
open MeasureTheory Filter Set MIACE

-- @article14 prop:delay-second-moment/actual_kernel_variance_identity
/-- Expanding the square under a genuine Lebesgue integral. -/
theorem kernel_centered_second_moment {μ : Measure ℝ} {g : ℝ → ℝ}
    (hg : Integrable g μ) (hfirst : Integrable (fun t => t * g t) μ)
    (hsecond : Integrable (fun t => t ^ 2 * g t) μ) (m : ℝ) :
    (∫ t, (t - m) ^ 2 * g t ∂μ) =
      (∫ t, t ^ 2 * g t ∂μ) - 2 * m * (∫ t, t * g t ∂μ) +
        m ^ 2 * (∫ t, g t ∂μ) := by
  have he : (fun t => (t - m) ^ 2 * g t) =
      (fun t => (t ^ 2 * g t - (2 * m) * (t * g t)) + m ^ 2 * g t) := by
    funext t
    ring
  have hsub : Integrable (fun t => t ^ 2 * g t - (2 * m) * (t * g t)) μ :=
    hsecond.sub (hfirst.const_mul (2 * m))
  rw [he, integral_add hsub (hg.const_mul (m ^ 2)),
    integral_sub hsecond (hfirst.const_mul (2 * m)), integral_const_mul,
    integral_const_mul]

-- @article14 prop:delay-second-moment/nonnegative_actual_kernel_variance
/-- A nonnegative ordinary unit-mass kernel has nonnegative variance. -/
theorem kernel_variance_nonneg {μ : Measure ℝ} {g : ℝ → ℝ}
    (hg : Integrable g μ) (hfirst : Integrable (fun t => t * g t) μ)
    (hsecond : Integrable (fun t => t ^ 2 * g t) μ)
    (hn : ∀ᵐ t ∂μ, 0 ≤ g t) (hmass : (∫ t, g t ∂μ) = 1) :
    (∫ t, t * g t ∂μ) ^ 2 ≤ ∫ t, t ^ 2 * g t ∂μ := by
  have hp : 0 ≤ ∫ t, (t - (∫ s, s * g s ∂μ)) ^ 2 * g t ∂μ := by
    apply integral_nonneg_of_ae
    filter_upwards [hn] with t ht
    exact mul_nonneg (sq_nonneg _) ht
  rw [kernel_centered_second_moment hg hfirst hsecond, hmass] at hp
  nlinarith

-- @article14 prop:delay-second-moment/variance_bound_from_actual_moments
/-- The PIDF weight bound follows from the actual first and second moments. -/
theorem kernel_variance_weight_bound {μ : Measure ℝ} {g : ℝ → ℝ}
    (hg : Integrable g μ) (hfirst : Integrable (fun t => t * g t) μ)
    (hsecond : Integrable (fun t => t ^ 2 * g t) μ)
    (hn : ∀ᵐ t ∂μ, 0 ≤ g t) (hmass : (∫ t, g t ∂μ) = 1)
    (Kp Ki Kd k Γ m c : ℝ) (hKi : 0 < Ki) (hKd : 0 < Kd)
    (hm : (∫ t, t * g t ∂μ) = m)
    (hm2 : (∫ t, t ^ 2 * g t ∂μ) = 2 * secondErrorMoment Kp Ki Kd k Γ m c) :
    1 + (Ki * m ^ 2 / 2 - (Kp + 1 / k) * m + Γ / k) / Kd ≤ c := by
  apply variance_weight_bound Kp Ki Kd k Γ m c hKi hKd
  simpa only [hm, hm2] using kernel_variance_nonneg hg hfirst hsecond hn hmass

-- @article14 thm:delay-fastest/mean_identifies_proportional_weight
theorem meanTime_injective (Ti k Kp : ℝ) (hTi : Ti ≠ 0) :
    Function.Injective (meanTime Ti k Kp) := by
  intro b d h
  unfold meanTime at h
  have he := mul_left_cancel₀ hTi h
  linarith

-- @article14 thm:delay-fastest/second_moment_identifies_derivative_weight
theorem secondErrorMoment_injective (Kp Ki Kd k Γ m : ℝ)
    (hKi : Ki ≠ 0) (hKd : Kd ≠ 0) :
    Function.Injective (secondErrorMoment Kp Ki Kd k Γ m) := by
  intro c d h
  unfold secondErrorMoment at h
  have he := congrArg (fun x : ℝ => x * Ki) h
  simp only [div_mul_cancel₀ _ hKi] at he
  have hm : (1 - c) * Kd = (1 - d) * Kd := by linarith
  have he' := mul_right_cancel₀ hKd hm
  linarith

-- @article14 thm:delay-fastest/two_moments_identify_both_weights
/-- Equality of both physical moment formulas identifies both setpoint weights. -/
theorem weights_eq_of_moment_formulas (Ti k Kp Td Γ : ℝ)
    (hTi : Ti ≠ 0) (hKp : Kp ≠ 0) (hTd : Td ≠ 0) {w z : ℝ × ℝ}
    (hm : meanTime Ti k Kp w.1 = meanTime Ti k Kp z.1)
    (hm2 : 2 * secondErrorMoment Kp (Kp / Ti) (Kp * Td) k Γ
        (meanTime Ti k Kp w.1) w.2 =
      2 * secondErrorMoment Kp (Kp / Ti) (Kp * Td) k Γ
        (meanTime Ti k Kp z.1) z.2) : w = z := by
  have hb := meanTime_injective Ti k Kp hTi hm
  apply Prod.ext hb
  apply secondErrorMoment_injective Kp (Kp / Ti) (Kp * Td) k Γ
    (meanTime Ti k Kp w.1) (div_ne_zero hKp hTi) (mul_ne_zero hKp hTd)
  rw [← hb] at hm2
  linarith

-- @article14 thm:delay-fastest/kernel_ae_equality_identifies_weights
/-- This is the kernel identifiability statement before taking the L¹ quotient. -/
theorem weights_eq_of_kernel_moments {μ : Measure ℝ} {g h : ℝ → ℝ}
    (Ti k Kp Td Γ : ℝ) (hTi : Ti ≠ 0) (hKp : Kp ≠ 0) (hTd : Td ≠ 0)
    {w z : ℝ × ℝ} (heq : g =ᵐ[μ] h)
    (hmw : (∫ t, t * g t ∂μ) = meanTime Ti k Kp w.1)
    (hmz : (∫ t, t * h t ∂μ) = meanTime Ti k Kp z.1)
    (hm2w : (∫ t, t ^ 2 * g t ∂μ) =
      2 * secondErrorMoment Kp (Kp / Ti) (Kp * Td) k Γ
        (meanTime Ti k Kp w.1) w.2)
    (hm2z : (∫ t, t ^ 2 * h t ∂μ) =
      2 * secondErrorMoment Kp (Kp / Ti) (Kp * Td) k Γ
        (meanTime Ti k Kp z.1) z.2) : w = z := by
  apply weights_eq_of_moment_formulas Ti k Kp Td Γ hTi hKp hTd
  · rw [← hmw, ← hmz]
    apply integral_congr_ae
    filter_upwards [heq] with t ht
    rw [ht]
  · rw [← hm2w, ← hm2z]
    apply integral_congr_ae
    filter_upwards [heq] with t ht
    rw [ht]

-- @article14 thm:delay-fastest/actual_L1_kernel_family_injective
/-- First and second moment identities establish injectivity of the actual
kernel family in the inherited L¹ space; no Laplace uniqueness assumption is
needed.  Moments here are on the whole line, as is `MIACE.RealL1`. -/
theorem kernel_family_injective_of_moments (g : (ℝ × ℝ) → RealL1)
    (Ti k Kp Td Γ : ℝ) (hTi : Ti ≠ 0) (hKp : Kp ≠ 0) (hTd : Td ≠ 0)
    (hm : ∀ w, (∫ t, t * g w t) = meanTime Ti k Kp w.1)
    (hm2 : ∀ w, (∫ t, t ^ 2 * g w t) =
      2 * secondErrorMoment Kp (Kp / Ti) (Kp * Td) k Γ
        (meanTime Ti k Kp w.1) w.2) : Function.Injective g := by
  intro w z h
  apply weights_eq_of_moment_formulas Ti k Kp Td Γ hTi hKp hTd
  · rw [← hm w, ← hm z, h]
  · rw [← hm2 w, ← hm2 z, h]

-- @article14 thm:delay-fastest/affine_kernel_direction_injective
/-- Affine-kernel identifiability supplies the linear injectivity required by
`kernelFeasible_compact`. -/
theorem affine_kernel_direction_injective_of_moments (g₀ : RealL1)
    (L : (ℝ × ℝ) →L[ℝ] RealL1) (Ti k Kp Td Γ : ℝ)
    (hTi : Ti ≠ 0) (hKp : Kp ≠ 0) (hTd : Td ≠ 0)
    (hm : ∀ w, (∫ t, t * (g₀ + L w) t) = meanTime Ti k Kp w.1)
    (hm2 : ∀ w, (∫ t, t ^ 2 * (g₀ + L w) t) =
      2 * secondErrorMoment Kp (Kp / Ti) (Kp * Td) k Γ
        (meanTime Ti k Kp w.1) w.2) : Function.Injective L := by
  intro w z h
  apply kernel_family_injective_of_moments (fun w => g₀ + L w)
    Ti k Kp Td Γ hTi hKp hTd hm hm2
  exact congrArg (fun u => g₀ + u) h

-- @article14 thm:delay-fastest/strict_mean_above_pure_delay
/-- An ordinary nonnegative unit-mass density supported after a pure delay
cannot place all of its mass at the delay point.  Thus its mean strictly
exceeds that delay.  This also applies to `halfLine`, which has no atoms. -/
theorem kernel_mean_strictly_above_delay {μ : Measure ℝ} [NullSingletonClass μ]
    {g : ℝ → ℝ} (hg : Integrable g μ)
    (hfirst : Integrable (fun t => t * g t) μ)
    (hn : ∀ᵐ t ∂μ, 0 ≤ g t) (hmass : (∫ t, g t ∂μ) = 1)
    (L : ℝ) (hdelay : ∀ᵐ t ∂μ, t < L → g t = 0) :
    L < ∫ t, t * g t ∂μ := by
  have hshift : Integrable (fun t => (t - L) * g t) μ := by
    have he : (fun t => (t - L) * g t) = (fun t => t * g t - L * g t) := by
      funext t
      ring
    rw [he]
    exact hfirst.sub (hg.const_mul L)
  have hshift_nonneg : ∀ᵐ t ∂μ, 0 ≤ (t - L) * g t := by
    filter_upwards [hn, hdelay] with t ht hd
    by_cases h : t < L
    · rw [hd h, mul_zero]
    · exact mul_nonneg (sub_nonneg.mpr (le_of_not_gt h)) ht
  have hshift_pos : 0 < ∫ t, (t - L) * g t ∂μ := by
    apply lt_of_le_of_ne (integral_nonneg_of_ae hshift_nonneg)
    intro hzero
    have hz := (integral_eq_zero_iff_of_nonneg_ae hshift_nonneg hshift).mp hzero.symm
    have hgzero : g =ᵐ[μ] 0 := by
      filter_upwards [hz, μ.ae_ne L] with t ht hne
      have hmul : (t - L) * g t = 0 := ht
      exact (mul_eq_zero.mp hmul).resolve_left (sub_ne_zero.mpr hne)
    have hmasszero : (∫ t, g t ∂μ) = 0 := by
      rw [integral_congr_ae hgzero]
      simp
    linarith
  have he : (fun t => (t - L) * g t) = (fun t => t * g t - L * g t) := by
    funext t
    ring
  rw [he, integral_sub hfirst (hg.const_mul L), integral_const_mul, hmass] at hshift_pos
  linarith

-- @article14 prop:delay-second-moment/strict_variance_for_ordinary_kernels
/-- A unit-mass ordinary density on an atomless measure cannot concentrate at
its mean.  In this setting the variance is strictly positive. -/
theorem kernel_variance_pos {μ : Measure ℝ} [NullSingletonClass μ] {g : ℝ → ℝ}
    (hg : Integrable g μ) (hfirst : Integrable (fun t => t * g t) μ)
    (hsecond : Integrable (fun t => t ^ 2 * g t) μ)
    (hn : ∀ᵐ t ∂μ, 0 ≤ g t) (hmass : (∫ t, g t ∂μ) = 1) :
    (∫ t, t * g t ∂μ) ^ 2 < ∫ t, t ^ 2 * g t ∂μ := by
  let m : ℝ := ∫ t, t * g t ∂μ
  have hsq : Integrable (fun t => (t - m) ^ 2 * g t) μ := by
    have he : (fun t => (t - m) ^ 2 * g t) =
        (fun t => (t ^ 2 * g t - (2 * m) * (t * g t)) + m ^ 2 * g t) := by
      funext t
      ring
    rw [he]
    exact (hsecond.sub (hfirst.const_mul (2 * m))).add (hg.const_mul (m ^ 2))
  have hsq_nonneg : ∀ᵐ t ∂μ, 0 ≤ (t - m) ^ 2 * g t := by
    filter_upwards [hn] with t ht
    exact mul_nonneg (sq_nonneg _) ht
  have hp : 0 < ∫ t, (t - m) ^ 2 * g t ∂μ := by
    apply lt_of_le_of_ne (integral_nonneg_of_ae hsq_nonneg)
    intro hzero
    have hz := (integral_eq_zero_iff_of_nonneg_ae hsq_nonneg hsq).mp hzero.symm
    have hgzero : g =ᵐ[μ] 0 := by
      filter_upwards [hz, μ.ae_ne m] with t ht hne
      have hmul : (t - m) ^ 2 * g t = 0 := ht
      exact (mul_eq_zero.mp hmul).resolve_left (pow_ne_zero _ (sub_ne_zero.mpr hne))
    have hmasszero : (∫ t, g t ∂μ) = 0 := by
      rw [integral_congr_ae hgzero]
      simp
    linarith
  rw [kernel_centered_second_moment hg hfirst hsecond, hmass] at hp
  dsimp [m] at hp
  nlinarith

-- @article14 prop:delay-second-moment/strict_variance_weight_bound
/-- The atomless-density refinement makes the necessary derivative-weight
bound strict.  Equality would require a Dirac impulse, not an ordinary kernel. -/
theorem kernel_variance_weight_bound_strict {μ : Measure ℝ} [NullSingletonClass μ]
    {g : ℝ → ℝ} (hg : Integrable g μ)
    (hfirst : Integrable (fun t => t * g t) μ)
    (hsecond : Integrable (fun t => t ^ 2 * g t) μ)
    (hn : ∀ᵐ t ∂μ, 0 ≤ g t) (hmass : (∫ t, g t ∂μ) = 1)
    (Kp Ki Kd k Γ m c : ℝ) (hKi : 0 < Ki) (hKd : 0 < Kd)
    (hm : (∫ t, t * g t ∂μ) = m)
    (hm2 : (∫ t, t ^ 2 * g t ∂μ) = 2 * secondErrorMoment Kp Ki Kd k Γ m c) :
    1 + (Ki * m ^ 2 / 2 - (Kp + 1 / k) * m + Γ / k) / Kd < c := by
  have hv := kernel_variance_pos hg hfirst hsecond hn hmass
  rw [hm, hm2] at hv
  unfold secondErrorMoment at hv
  have h := (lt_div_iff₀ hKi).mp
    (show m ^ 2 / 2 < ((Kp + 1 / k) * m - (1 - c) * Kd - Γ / k) / Ki by
      linarith)
  rw [← lt_sub_iff_add_lt', div_lt_iff₀ hKd]
  nlinarith

-- @article14 thm:delay-fastest/halfLine_L1_kernel_family_injective
/-- The same L¹ identifiability argument can use causal half-line moments
without first converting them to whole-line moments. -/
theorem kernel_family_injective_of_halfLine_moments (g : (ℝ × ℝ) → RealL1)
    (Ti k Kp Td Γ : ℝ) (hTi : Ti ≠ 0) (hKp : Kp ≠ 0) (hTd : Td ≠ 0)
    (hm : ∀ w, (∫ t, t * g w t ∂halfLine) = meanTime Ti k Kp w.1)
    (hm2 : ∀ w, (∫ t, t ^ 2 * g w t ∂halfLine) =
      2 * secondErrorMoment Kp (Kp / Ti) (Kp * Td) k Γ
        (meanTime Ti k Kp w.1) w.2) : Function.Injective g := by
  intro w z h
  apply weights_eq_of_moment_formulas Ti k Kp Td Γ hTi hKp hTd
  · rw [← hm w, ← hm z, h]
  · rw [← hm2 w, ← hm2 z, h]

end Article14
