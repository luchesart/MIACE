import Article14.PhysicalLaplace
import Article14.MIACEBridge
import Mathlib.Topology.Instances.Matrix

/-!
# Physical input-delay realization and its local transfer identity

The state equation is an ordinary finite-dimensional realization with a pure
input delay and zero input history.  Centering at the unit-output equilibrium
keeps all functions used by the integration-by-parts theorem integrable.
The frequency-domain relation is derived from the component differential
equations.  It is not a field of the physical response structure.
-/
namespace Article14.PhysicalPlant

open MeasureTheory Filter Set MIACE Matrix
open Article14.PhysicalLaplace
open scoped Topology Matrix

variable {n : Type*} [Fintype n] [DecidableEq n]

/-- Output error of a state centered at a unit-output equilibrium. -/
noncomputable def trackingError (C : n → ℝ) (z : n → ℝ → ℝ) (t : ℝ) : ℝ :=
  -(∑ i, C i * z i t)

/-- Actual centered equations; all fields concern states and time signals. -/
structure CenteredPlantResponse (A : Matrix n n ℝ) (B xInf : n → ℝ)
    (k L : ℝ) (z : n → ℝ → ℝ) (v : ℝ → ℝ) : Prop where
  state_ac : ∀ i T, 0 ≤ T → AbsolutelyContinuousOnInterval (z i) 0 T
  state_integrable : ∀ i, Integrable (z i) halfLine
  state_limit : ∀ i, Tendsto (z i) atTop (𝓝 0)
  state_initial : ∀ i, z i 0 = -xInf i
  state_ode : ∀ i, ∀ᵐ t : ℝ, 0 < t →
    deriv (z i) t = (∑ j, A i j * z j t) + B i / k * centeredDelay L v t
  command_integrable : Integrable v halfLine

-- Finite-dimensional output maps preserve ordinary signal integrability.
omit [DecidableEq n] in
theorem finite_output_integrable (C : n → ℝ) {z : n → ℝ → ℝ}
    (hz : ∀ i, Integrable (z i) halfLine) :
    Integrable (fun t => ∑ i, C i * z i t) halfLine := by
  exact integrable_finsetSum Finset.univ (fun i _ => (hz i).const_mul (C i))

-- Laplace transforms commute with a finite physical output map.
omit [DecidableEq n] in
theorem finite_output_laplace (C : n → ℝ) {z : n → ℝ → ℝ}
    (hz : ∀ i, Integrable (z i) halfLine) {p : ℝ} (hp : 0 ≤ p) :
    laplace (fun t => ∑ i, C i * z i t) p = ∑ i, C i * laplace (z i) p := by
  unfold laplace
  simp_rw [Finset.mul_sum, ← mul_assoc, mul_comm (Real.exp _) (C _), mul_assoc]
  rw [integral_finsetSum Finset.univ
    (fun i _ => (laplace_integrable (hz i) hp).const_mul (C i))]
  simp only [integral_const_mul]

-- Integration by parts in each actual state equation gives its Laplace balance.
omit [DecidableEq n] in
theorem centered_state_laplace {A : Matrix n n ℝ} {B xInf : n → ℝ}
    {k L : ℝ} {z : n → ℝ → ℝ} {v : ℝ → ℝ}
    (h : CenteredPlantResponse A B xInf k L z v) (hL : 0 ≤ L)
    (i : n) {p : ℝ} (hp : 0 ≤ p) :
    p * laplace (z i) p + xInf i =
      (∑ j, A i j * laplace (z j) p) + B i / k * laplace (centeredDelay L v) p := by
  have hd := centeredDelay_integrable hL h.command_integrable
  have hs := finite_output_integrable (A i) h.state_integrable
  have hi := laplace_ode_identity (h.state_ac i) (h.state_ode i)
    (h.state_integrable i) (hs.add (hd.const_mul (B i / k))) (h.state_limit i) p hp
  have hr : laplace (fun t => (∑ j, A i j * z j t) + B i / k * centeredDelay L v t) p =
      (∑ j, A i j * laplace (z j) p) + B i / k * laplace (centeredDelay L v) p := by
    unfold laplace
    simp_rw [mul_add]
    rw [integral_add (laplace_integrable hs hp)
      (laplace_integrable (hd.const_mul (B i / k)) hp)]
    rw [show (fun t => Real.exp (-p*t) * (B i / k * centeredDelay L v t)) =
      (fun t => B i / k * (Real.exp (-p*t) * centeredDelay L v t)) by
        funext t; ring, integral_const_mul]
    rw [← laplace, finite_output_laplace (A i) h.state_integrable hp]
    rfl
  rw [hr, h.state_initial i] at hi
  linarith

/-- The resolvent pencil of the undelayed strictly proper state realization. -/
noncomputable def pencil (A : Matrix n n ℝ) (p : ℝ) : Matrix n n ℝ := p • 1 - A

/-- An algebraic left resolvent row; it refers to arbitrary finite vectors. -/
def IsResolventRow (A : Matrix n n ℝ) (C R : n → ℝ) (p : ℝ) : Prop :=
  ∀ w : n → ℝ, (∑ j, C j * w j) =
    ∑ i, R i * (p * w i - ∑ j, A i j * w j)

/-- The usual undelayed transfer function divided by the static gain. -/
noncomputable def normalizedTransfer (A : Matrix n n ℝ) (B C : n → ℝ)
    (k p : ℝ) : ℝ := ((C ᵥ* (pencil A p)⁻¹) ⬝ᵥ B) / k

-- A nonsingular pencil supplies the row identity purely by matrix algebra.
theorem inverse_isResolventRow (A : Matrix n n ℝ) (C : n → ℝ) (p : ℝ)
    (hp : (pencil A p).det ≠ 0) :
    IsResolventRow A C (C ᵥ* (pencil A p)⁻¹) p := by
  intro w
  have hr : (C ᵥ* (pencil A p)⁻¹) ᵥ* pencil A p = C := by
    rw [vecMul_vecMul, nonsing_inv_mul _ (isUnit_iff_ne_zero.mpr hp), vecMul_one]
  have hm : (pencil A p) *ᵥ w = fun i => p * w i - ∑ j, A i j * w j := by
    simp only [pencil, sub_mulVec, smul_mulVec, one_mulVec]
    rfl
  have hh := dotProduct_mulVec (C ᵥ* (pencil A p)⁻¹) (pencil A p) w
  rw [hm, hr] at hh
  exact hh.symm

-- The only spectral requirement is nonsingularity at DC.  Unstable poles away
-- from DC cause no difficulty because no global positive-frequency identity is used.
theorem pencil_eventually_nonsingular (A : Matrix n n ℝ)
    (hA : (pencil A 0).det ≠ 0) :
    ∀ᶠ p in 𝓝[>] (0 : ℝ), (pencil A p).det ≠ 0 := by
  have hc : Continuous (fun p : ℝ => (pencil A p).det) := by
    apply Continuous.matrix_det
    unfold pencil
    fun_prop
  exact (hc.continuousAt.eventually_ne hA).filter_mono nhdsWithin_le_nhds

-- Restoring the equilibrium term produces the ordinary zero-initial-state
-- resolvent balance, including the delayed command's initial waiting interval.
omit [DecidableEq n] in
theorem raw_state_laplace_balance {A : Matrix n n ℝ} {B xInf : n → ℝ}
    {k L : ℝ} {z : n → ℝ → ℝ} {v : ℝ → ℝ}
    (h : CenteredPlantResponse A B xInf k L z v) (hL : 0 ≤ L)
    (heq : ∀ i, (∑ j, A i j * xInf j) + B i / k = 0)
    (i : n) {p : ℝ} (hp : 0 < p) :
    p * (laplace (z i) p + xInf i / p) -
      (∑ j, A i j * (laplace (z j) p + xInf j / p)) =
    B i / k * (laplace (centeredDelay L v) p + 1 / p) := by
  have hb := centered_state_laplace h hL i hp.le
  have he : (∑ j, A i j * xInf j) = -(B i / k) := by linarith [heq i]
  have hh : p * laplace (z i) p + xInf i -
      (∑ j, A i j * laplace (z j) p) =
      B i / k * laplace (centeredDelay L v) p := by linarith
  calc
    _ = (p * laplace (z i) p + xInf i -
        (∑ j, A i j * laplace (z j) p)) - (∑ j, A i j * xInf j) / p := by
      simp_rw [mul_add, Finset.sum_add_distrib, ← mul_div_assoc]
      rw [← Finset.sum_div]
      field_simp [ne_of_gt hp]
      ring
    _ = _ := by rw [hh, he]; ring

-- This pointwise transfer theorem is derived from actual differential
-- equations and a purely algebraic resolvent row, not from a transfer axiom.
omit [DecidableEq n] in
theorem physical_transfer_at {A : Matrix n n ℝ} {B C xInf R : n → ℝ}
    {k L : ℝ} {z : n → ℝ → ℝ} {v : ℝ → ℝ}
    (h : CenteredPlantResponse A B xInf k L z v) (hL : 0 ≤ L)
    (heq : ∀ i, (∑ j, A i j * xInf j) + B i / k = 0)
    (hout : (∑ j, C j * xInf j) = 1) {p : ℝ} (hp : 0 < p)
    (hR : IsResolventRow A C R p) :
    laplace (fun t => 1 - trackingError C z t) p =
      ((∑ i, R i * B i) / k) * Real.exp (-L * p) *
        laplace (fun t => 1 + v t) p := by
  let X : n → ℝ := fun i => laplace (z i) p + xInf i / p
  have hx : (∑ j, C j * X j) = (∑ j, C j * laplace (z j) p) + 1 / p := by
    dsimp [X]
    simp_rw [mul_add, Finset.sum_add_distrib, ← mul_div_assoc]
    rw [← Finset.sum_div, hout]
  have hb : (∑ j, C j * X j) =
      ((∑ i, R i * B i) / k) * (laplace (centeredDelay L v) p + 1 / p) := by
    rw [hR X]
    have hterms : (fun i => R i * (p * X i - ∑ j, A i j * X j)) =
        (fun i => R i * (B i / k * (laplace (centeredDelay L v) p + 1 / p))) := by
      funext i
      rw [raw_state_laplace_balance h hL heq i hp]
    rw [hterms]
    simp only [← mul_assoc, ← Finset.sum_mul, ← mul_div_assoc, ← Finset.sum_div]
  have hy : laplace (fun t => 1 - trackingError C z t) p =
      1 / p + (∑ j, C j * laplace (z j) p) := by
    simp only [trackingError, sub_neg_eq_add]
    rw [laplace_affine_add (finite_output_integrable C h.state_integrable) 1 hp,
      finite_output_laplace C h.state_integrable hp.le]
  have hv := laplace_affine_add h.command_integrable 1 hp
  rw [hy, hv, centeredDelay_laplace hL h.command_integrable hp] at *
  rw [hx] at hb
  calc
    _ = ((∑ i, R i * B i) / k) *
        (Real.exp (-L*p)*laplace v p + (Real.exp (-L*p)-1)/p + 1/p) := by linarith
    _ = _ := by ring

-- Main bridge: the actual delayed finite-state realization supplies precisely
-- the local signal interface reused by the MIACE theorems.  A pole away from
-- zero is permitted, since the inverse is used only near DC.
theorem localTransfer_of_centered_plant {A : Matrix n n ℝ} {B C xInf : n → ℝ}
    {k L : ℝ} {z : n → ℝ → ℝ} {v : ℝ → ℝ}
    (h : CenteredPlantResponse A B xInf k L z v) (hL : 0 ≤ L)
    (heq : ∀ i, (∑ j, A i j * xInf j) + B i / k = 0)
    (hout : (∑ j, C j * xInf j) = 1)
    (hA : (pencil A 0).det ≠ 0) :
    LocalTransferResponse (trackingError C z) v (normalizedTransfer A B C k) L := by
  refine ⟨(finite_output_integrable C h.state_integrable).neg, h.command_integrable, ?_⟩
  filter_upwards [pencil_eventually_nonsingular A hA, self_mem_nhdsWithin] with p hdet hp
  exact physical_transfer_at h hL heq hout hp (inverse_isResolventRow A C p hdet)

-- Unit DC normalization is a consequence of the actual equilibrium equations.
theorem normalizedTransfer_zero {A : Matrix n n ℝ} {B C xInf : n → ℝ} {k : ℝ}
    (heq : ∀ i, (∑ j, A i j * xInf j) + B i / k = 0)
    (hout : (∑ j, C j * xInf j) = 1)
    (hA : (pencil A 0).det ≠ 0) : normalizedTransfer A B C k 0 = 1 := by
  have hrow := inverse_isResolventRow A C 0 hA xInf
  have he : ∀ i, (0 : ℝ) * xInf i - ∑ j, A i j * xInf j = B i / k := by
    intro i
    linarith [heq i]
  simp_rw [he] at hrow
  rw [hout] at hrow
  unfold normalizedTransfer dotProduct
  simpa only [← mul_div_assoc, ← Finset.sum_div] using hrow.symm

-- The resolvent is continuous around DC whenever the undelayed realization
-- has no zero eigenvalue.  No open-loop stability assumption is needed.
theorem normalizedTransfer_continuousAt_zero {A : Matrix n n ℝ} (B C : n → ℝ) (k : ℝ)
    (hA : (pencil A 0).det ≠ 0) :
    ContinuousAt (normalizedTransfer A B C k) 0 := by
  have hp : Continuous (pencil A) := by unfold pencil; fun_prop
  have hi : ContinuousAt (fun p => (pencil A p)⁻¹) 0 := by
    apply (continuousAt_matrix_inv (pencil A 0) ?_).comp hp.continuousAt
    simpa only [Ring.inverse_eq_inv'] using continuousAt_inv₀ hA
  change ContinuousAt (fun p => (∑ i, (∑ j, C j * (pencil A p)⁻¹ j i) * B i) / k) 0
  apply ContinuousAt.div_const
  apply tendsto_finsetSum Finset.univ
  intro i _
  apply ContinuousAt.mul_const
  apply tendsto_finsetSum Finset.univ
  intro j _
  exact (((continuous_apply i).continuousAt.comp
    ((continuous_apply j).continuousAt.comp hi))).const_mul (C j)

/-- The undelayed contribution to the signed-area balance, computed from the
finite-dimensional realization and its unit-output equilibrium. -/
noncomputable def residenceTime (A : Matrix n n ℝ) (C xInf : n → ℝ) : ℝ :=
  (C ᵥ* (pencil A 0)⁻¹) ⬝ᵥ xInf

-- Resolvent/equilibrium algebra gives a first-order difference quotient
-- without differentiating the matrix inverse itself.
theorem normalizedTransfer_equilibrium_identity {A : Matrix n n ℝ}
    {B C xInf : n → ℝ} {k : ℝ}
    (heq : ∀ i, (∑ j, A i j * xInf j) + B i / k = 0)
    (hout : (∑ j, C j * xInf j) = 1) {p : ℝ}
    (hp : (pencil A p).det ≠ 0) :
    normalizedTransfer A B C k p =
      1 - p * ((C ᵥ* (pencil A p)⁻¹) ⬝ᵥ xInf) := by
  have hr := inverse_isResolventRow A C p hp xInf
  have he : ∀ i, p * xInf i - ∑ j, A i j * xInf j = p * xInf i + B i / k := by
    intro i
    linarith [heq i]
  simp_rw [he] at hr
  rw [hout] at hr
  have hh : (∑ i, (C ᵥ* (pencil A p)⁻¹) i * (p * xInf i + B i / k)) =
      p * ((C ᵥ* (pencil A p)⁻¹) ⬝ᵥ xInf) + normalizedTransfer A B C k p := by
    unfold normalizedTransfer dotProduct
    simp_rw [mul_add, Finset.sum_add_distrib, ← mul_div_assoc]
    rw [← Finset.sum_div, Finset.mul_sum]
    congr 1
    apply Finset.sum_congr rfl
    intro i _
    ring
  rw [hh] at hr
  linarith

-- The physical derivative at DC is proved from the equilibrium identity and
-- continuity of the inverse pencil on a full neighbourhood of zero.
theorem normalizedTransfer_hasDerivAt_zero {A : Matrix n n ℝ}
    {B C xInf : n → ℝ} {k : ℝ}
    (heq : ∀ i, (∑ j, A i j * xInf j) + B i / k = 0)
    (hout : (∑ j, C j * xInf j) = 1)
    (hA : (pencil A 0).det ≠ 0) :
    HasDerivAt (normalizedTransfer A B C k) (-residenceTime A C xInf) 0 := by
  have hp : Continuous (pencil A) := by unfold pencil; fun_prop
  have hi : ContinuousAt (fun p => (pencil A p)⁻¹) 0 := by
    apply (continuousAt_matrix_inv (pencil A 0) ?_).comp hp.continuousAt
    simpa only [Ring.inverse_eq_inv'] using continuousAt_inv₀ hA
  have hc : ContinuousAt (fun p => (C ᵥ* (pencil A p)⁻¹) ⬝ᵥ xInf) 0 := by
    change ContinuousAt (fun p => ∑ i, (∑ j, C j * (pencil A p)⁻¹ j i) * xInf i) 0
    apply tendsto_finsetSum Finset.univ
    intro i _
    apply ContinuousAt.mul_const
    apply tendsto_finsetSum Finset.univ
    intro j _
    exact (((continuous_apply i).continuousAt.comp
    ((continuous_apply j).continuousAt.comp hi))).const_mul (C j)
  have hns : ∀ᶠ p in 𝓝[≠] (0 : ℝ), (pencil A p).det ≠ 0 :=
    (hp.matrix_det.continuousAt.eventually_ne hA).filter_mono nhdsWithin_le_nhds
  apply hasDerivAt_iff_tendsto_slope.mpr
  apply (hc.neg.tendsto.mono_left nhdsWithin_le_nhds).congr'
  filter_upwards [hns, self_mem_nhdsWithin] with p hdet hp0
  have hne : p ≠ 0 := hp0
  simp only [slope, sub_zero, smul_eq_mul,
    normalizedTransfer_zero heq hout hA,
    normalizedTransfer_equilibrium_identity heq hout hdet, Pi.neg_apply, vsub_eq_sub]
  field_simp
  ring

end Article14.PhysicalPlant
