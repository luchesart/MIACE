import Article14.PhysicalStep
import Article14.PiecewiseRegularity

/-!
# Existence of the forced zero-history PIDF step response

A unit-step trajectory is constructed from the homogeneous all-history
well-posedness property. During the transport interval the plant is at zero;
the controller integral and filter states are obtained explicitly. This
continuous initial segment supplies the history of a translated homogeneous
solution. No forced solution is included among the assumptions.
-/
namespace Article14
open MeasureTheory Filter Set MIACE
open scoped Topology
open PhysicalPlant PhysicalLaplace
variable {n : Type*} [Fintype n] [DecidableEq n]

/-- The actual controller and plant states before the first input arrives. -/
noncomputable def transportStep (c Tf : ℝ) (t : ℝ) : (n → ℝ) × ℝ × ℝ :=
  (0, t, c * (1 - Real.exp (-t / Tf)))

omit [Fintype n] [DecidableEq n] in
theorem transportStep_continuous (c Tf : ℝ) :
    Continuous (transportStep (n := n) c Tf) := by
  unfold transportStep
  fun_prop

omit [Fintype n] [DecidableEq n] in
theorem transportStep_zero (c Tf : ℝ) : transportStep (n := n) c Tf 0 = 0 := by
  simp [transportStep]

omit [DecidableEq n] in
theorem transportStep_hasDerivAt (c Tf t : ℝ) :
    HasDerivAt (transportStep (n := n) c Tf)
      (0, 1, c / Tf * Real.exp (-t / Tf)) t := by
  have he : HasDerivAt (fun s : ℝ => Real.exp (-s / Tf))
      (Real.exp (-t / Tf) * (-1 / Tf)) t :=
    (((hasDerivAt_id t).neg.div_const Tf).exp)
  have hf := ((hasDerivAt_const t (1 : ℝ)).sub he).const_mul c
  have hf' : HasDerivAt (fun s : ℝ => c * (1 - Real.exp (-s / Tf)))
      (c / Tf * Real.exp (-t / Tf)) t := by
    convert hf using 1
    ring
  exact (hasDerivAt_const t (0 : n → ℝ)).prodMk ((hasDerivAt_id t).prodMk hf')

/-- Translate a homogeneous solution back into the physical state after
shifting the origin of time to the end of the transport interval. -/
noncomputable def uncenterShift (z : ℝ → (n → ℝ) × ℝ × ℝ)
    (xe : n → ℝ) (Ti k Kp L b c : ℝ) (t : ℝ) : (n → ℝ) × ℝ × ℝ :=
  z (t-L) + pidfEquilibrium xe Ti k Kp b c

omit [DecidableEq n] in
theorem uncenterShift_after_delay
    {A : Matrix n n ℝ} {B C xe : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {z hist : ℝ → (n → ℝ) × ℝ × ℝ}
    (hz : IsRetardedSharedSolution (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L b c hist z)
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0)
    (heq : ∀ j, (∑ l, A j l*xe l)+B j/k=0)
    (hout : (∑ j, C j*xe j) = 1) :
    ∀ t, L < t → HasDerivAt (uncenterShift z xe Ti k Kp L b c)
      (retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
        Kp Ti Td Tf L b c (fun _ => 1)
        (fun θ => uncenterShift z xe Ti k Kp L b c (t+θ))) t := by
  have heq' : finiteStateMap A xe + finiteInputMap B (1/k) = 0 := by
    ext j
    simpa [finiteStateMap_apply, finiteInputMap_apply, div_eq_mul_inv] using heq j
  have hout' : finiteOutputMap C xe = 1 := by
    simpa [finiteOutputMap_eq, finitePlantOutput] using hout
  intro t ht
  have hd := ((hz.2.2 (t-L) (sub_pos.mpr ht)).scomp t
    ((hasDerivAt_id t).sub_const L)).add_const (pidfEquilibrium xe Ti k Kp b c)
  simp only [one_smul] at hd
  have hr := retardedShared_equilibrium_translation (finiteStateMap A) (finiteInputMap B)
    (finiteOutputMap C) Kp Ti Td Tf L k b c xe hk hKp hTi heq' hout'
    (fun θ => z (t-L+θ))
  simp only [finiteOutputMap_eq, finiteLinearPlantDynamics_eq] at hr
  convert hd using 1
  · rfl
  · rw [← hr]
    congr 1
    funext θ
    dsimp [uncenterShift]
    congr 2
    ring

omit [DecidableEq n] in
theorem exists_step_core
    {A : Matrix n n ℝ} {B C xe : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    (_hL : 0 ≤ L) (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0)
    (heq : ∀ j, (∑ l, A j l*xe l)+B j/k=0)
    (hout : (∑ j, C j*xe j) = 1)
    (hwp : IsRetardedSharedWellPosed (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L b c) :
    ∃ q : ℝ → (n → ℝ) × ℝ × ℝ,
      ContinuousOn q (Ici 0) ∧
      (∀ t ∈ Icc 0 L, q t = transportStep c Tf t) ∧
      (∀ t, L < t → HasDerivAt q
        (retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
          Kp Ti Td Tf L b c (fun _ => 1) (fun θ => q (t+θ))) t) := by
  let hist : ℝ → (n → ℝ) × ℝ × ℝ := fun θ =>
    transportStep c Tf (L+θ) - pidfEquilibrium xe Ti k Kp b c
  have hh : Continuous hist := by
    exact ((transportStep_continuous c Tf).comp (continuous_const.add continuous_id)).sub
      continuous_const
  obtain ⟨z, hz, _⟩ := hwp hist hh.continuousOn
  refine ⟨uncenterShift z xe Ti k Kp L b c, ?_, ?_, ?_⟩
  · exact (hz.1.comp (continuous_id.sub continuous_const).continuousOn
      (by intro t ht; change -L ≤ t-L; change 0 ≤ t at ht; linarith)).add continuousOn_const
  · intro t ht
    rw [uncenterShift, hz.2.1 (t-L) (by constructor <;> linarith [ht.1, ht.2])]
    dsimp [hist]
    rw [show L+(t-L)=t by ring, sub_add_cancel]
  · exact uncenterShift_after_delay hz hTi hk hKp heq hout

omit [DecidableEq n] in
theorem step_tail_continuous
    (A : Matrix n n ℝ) (B C : n → ℝ) (Kp Ti Td Tf L b c : ℝ)
    {q : ℝ → (n → ℝ) × ℝ × ℝ} (hL : 0 ≤ L)
    (hc : ContinuousOn q (Ici 0)) :
    ContinuousOn (fun t => retardedSharedRhs (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c
      (fun _ => 1) (fun θ => q (t+θ))) (Ici L) := by
  have hn : ContinuousOn q (Ici L) := hc.mono (Ici_subset_Ici.mpr hL)
  have hd : ContinuousOn (fun t => q (t + -L)) (Ici L) := by
    apply hc.comp (continuous_id.add continuous_const).continuousOn
    intro t ht
    change 0 ≤ t + -L
    change L ≤ t at ht
    linarith
  have ho : Continuous (finitePlantOutput C) := by
    rw [← finiteOutputMap_eq]
    exact (finiteOutputMap C).continuous
  have hp : Continuous (fun p : (n → ℝ) × ℝ => finitePlantDynamics A B p.1 p.2) := by
    rw [← finiteLinearPlantDynamics_eq]
    unfold linearPlantDynamics
    fun_prop
  have hctrl : Continuous (fun p : ℝ × ℝ × ℝ =>
      sharedControllerRhs Kp Ti Td Tf b c 1 p.1 p.2.1 p.2.2) := by
    unfold sharedControllerRhs
    fun_prop
  have cn := hctrl.comp_continuousOn ((ho.comp_continuousOn hn.fst).prodMk hn.snd)
  have cd := hctrl.comp_continuousOn ((ho.comp_continuousOn hd.fst).prodMk hd.snd)
  simpa only [retardedSharedRhs, add_zero, Function.comp_apply] using
    (hp.comp_continuousOn (hn.fst.prodMk cd.snd.snd)).prodMk (cn.fst.prodMk cn.snd.fst)

omit [DecidableEq n] in
theorem step_prefix_hasDerivAt
    {Tf L c : ℝ} {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (hp : ∀ t ∈ Icc 0 L, q t = transportStep c Tf t)
    {t : ℝ} (ht : t ∈ Ioo 0 L) :
    HasDerivAt q (0, 1, c / Tf * Real.exp (-t / Tf)) t := by
  apply (transportStep_hasDerivAt c Tf t).congr_of_eventuallyEq
  filter_upwards [Ioo_mem_nhds ht.1 ht.2] with s hs
  exact hp s ⟨hs.1.le, hs.2.le⟩

/- Each actual state coordinate is locally absolutely continuous; the only
possible corner is the first arrival time of the delayed unit-step input. -/
omit [DecidableEq n] in
theorem step_core_coordinate_ac
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (hL : 0 ≤ L) (hc : ContinuousOn q (Ici 0))
    (hp : ∀ t ∈ Icc 0 L, q t = transportStep c Tf t)
    (hd : ∀ t, L < t → HasDerivAt q
      (retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
        Kp Ti Td Tf L b c (fun _ => 1) (fun θ => q (t+θ))) t)
    (obs : ((n → ℝ) × ℝ × ℝ) →L[ℝ] ℝ) (T : ℝ) (hT : 0 ≤ T) :
    AbsolutelyContinuousOnInterval (fun t => obs (q t)) 0 T := by
  apply absolutelyContinuousOnInterval_of_piecewise_C1 hL hT
    (obs.continuous.comp_continuousOn hc)
    (p' := fun t => obs (0, 1, c / Tf * Real.exp (-t / Tf)))
    (r := fun t => obs (retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L b c (fun _ => 1) (fun θ => q (t+θ))))
  · exact (obs.continuous.comp (by fun_prop)).continuousOn
  · intro t ht
    exact obs.hasFDerivAt.comp_hasDerivAt t (step_prefix_hasDerivAt hp ht)
  · exact obs.continuous.comp_continuousOn
      (step_tail_continuous A B C Kp Ti Td Tf L b c hL hc)
  · intro t ht
    exact obs.hasFDerivAt.comp_hasDerivAt t (hd t ht)

/- The constructed continuous trajectory with its explicit transport
interval satisfies every raw physical equation, including local AC regularity. -/
omit [DecidableEq n] in
theorem stepLoopDynamics_of_core
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (hL : 0 ≤ L) (hc : ContinuousOn q (Ici 0))
    (hp : ∀ t ∈ Icc 0 L, q t = transportStep c Tf t)
    (hd : ∀ t, L < t → HasDerivAt q
      (retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
        Kp Ti Td Tf L b c (fun _ => 1) (fun θ => q (t+θ))) t) :
    StepLoopDynamics A B C Kp Ti Td Tf L b c q := by
  have hne : ∀ᵐ t : ℝ, t ≠ L := by simp [ae_iff]
  refine ⟨hc, ?_, ?_, ?_, ?_, ?_, ?_, ?_, hd⟩
  · intro j T hT
    exact step_core_coordinate_ac hL hc hp hd (plantCoordinate j) T hT
  · intro T hT
    exact step_core_coordinate_ac hL hc hp hd integralCoordinate T hT
  · intro T hT
    exact step_core_coordinate_ac hL hc hp hd filterCoordinate T hT
  · rw [hp 0 ⟨le_rfl, hL⟩, transportStep_zero]
  · intro j
    filter_upwards [hne] with t ht hpos
    by_cases hbefore : t < L
    · have hdt := ((plantCoordinate j).hasFDerivAt.comp_hasDerivAt t
        (step_prefix_hasDerivAt hp ⟨hpos, hbefore⟩)).deriv
      simpa [Function.comp_def, plantCoordinate, hp t ⟨hpos.le, hbefore.le⟩, transportStep,
        hbefore.le] using hdt
    · have hafter : L < t := lt_of_le_of_ne (le_of_not_gt hbefore) ht.symm
      have hdt := ((plantCoordinate j).hasFDerivAt.comp_hasDerivAt t (hd t hafter)).deriv
      simpa [Function.comp_def, plantCoordinate, retardedSharedRhs, finitePlantDynamics,
        stepCommand, sub_eq_add_neg, not_le.mpr hafter] using hdt
  · filter_upwards [hne] with t ht hpos
    by_cases hbefore : t < L
    · have hdt := (integralCoordinate.hasFDerivAt.comp_hasDerivAt t
        (step_prefix_hasDerivAt hp ⟨hpos, hbefore⟩)).deriv
      simpa [Function.comp_def, integralCoordinate, hp t ⟨hpos.le, hbefore.le⟩, transportStep,
        sharedControllerRhs, finitePlantOutput] using hdt
    · have hafter : L < t := lt_of_le_of_ne (le_of_not_gt hbefore) ht.symm
      have hdt := (integralCoordinate.hasFDerivAt.comp_hasDerivAt t (hd t hafter)).deriv
      simpa [Function.comp_def, integralCoordinate, retardedSharedRhs] using hdt
  · filter_upwards [hne] with t ht hpos
    by_cases hbefore : t < L
    · have hdt := (filterCoordinate.hasFDerivAt.comp_hasDerivAt t
        (step_prefix_hasDerivAt hp ⟨hpos, hbefore⟩)).deriv
      simp only [filterCoordinate, ContinuousLinearMap.coe_comp,
        Function.comp_def, ContinuousLinearMap.coe_snd'] at hdt
      rw [hdt, hp t ⟨hpos.le, hbefore.le⟩]
      simp only [transportStep, finitePlantOutput, sharedControllerRhs,
        Pi.zero_apply, mul_zero, Finset.sum_const_zero, mul_one, sub_zero]
      ring
    · have hafter : L < t := lt_of_le_of_ne (le_of_not_gt hbefore) ht.symm
      have hdt := (filterCoordinate.hasFDerivAt.comp_hasDerivAt t (hd t hafter)).deriv
      simpa [Function.comp_def, filterCoordinate, retardedSharedRhs] using hdt

/- Existence of the actual zero-history forced step response follows from
homogeneous all-history well-posedness and the verified physical equilibrium. -/
omit [DecidableEq n] in
theorem exists_stepLoopDynamics
    {A : Matrix n n ℝ} {B C xe : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    (hL : 0 ≤ L) (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0)
    (heq : ∀ j, (∑ l, A j l*xe l)+B j/k=0)
    (hout : (∑ j, C j*xe j) = 1)
    (hwp : IsRetardedSharedWellPosed (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L b c) :
    ∃ q : ℝ → (n → ℝ) × ℝ × ℝ,
      StepLoopDynamics A B C Kp Ti Td Tf L b c q ∧
      ∀ t ∈ Icc 0 L, q t = transportStep c Tf t := by
  obtain ⟨q, hc, hp, hd⟩ := exists_step_core hL hTi hk hKp heq hout hwp
  exact ⟨q, stepLoopDynamics_of_core hL hc hp hd, hp⟩

-- Uniqueness is inherited from the actual homogeneous initial-history problem.
-- The prefix condition identifies the complete physical history at time L.
omit [DecidableEq n] in
theorem stepLoopDynamics_unique_of_prefix
    {A : Matrix n n ℝ} {B C xe : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q r : ℝ → (n → ℝ) × ℝ × ℝ}
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0)
    (heq : ∀ j, (∑ l, A j l*xe l)+B j/k=0)
    (hout : (∑ j, C j*xe j) = 1)
    (hwp : IsRetardedSharedWellPosed (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L b c)
    (hq : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (hr : StepLoopDynamics A B C Kp Ti Td Tf L b c r)
    (hp : EqOn q r (Icc 0 L)) : EqOn q r (Ici 0) := by
  let eq := pidfEquilibrium xe Ti k Kp b c
  let qshift := fun t => q (t+L)-eq
  let rshift := fun t => r (t+L)-eq
  have hqshift : IsRetardedSharedSolution (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L b c qshift qshift :=
    retardedShared_shifted_solution _ _ Kp Ti Td Tf L b c (fun t => q t-eq)
      (hq.continuous.sub continuousOn_const) (centeredStep_after_delay hq hTi hk hKp heq hout)
  have hrshift : IsRetardedSharedSolution (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L b c rshift rshift :=
    retardedShared_shifted_solution _ _ Kp Ti Td Tf L b c (fun t => r t-eq)
      (hr.continuous.sub continuousOn_const) (centeredStep_after_delay hr hTi hk hKp heq hout)
  have hrshift' : IsRetardedSharedSolution (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L b c qshift rshift := by
    refine ⟨hrshift.1, ?_, hrshift.2.2⟩
    intro t ht
    change r (t+L)-eq = q (t+L)-eq
    rw [hp (by constructor <;> linarith [ht.1, ht.2])]
  obtain ⟨z, _, huniq⟩ := hwp qshift (hqshift.1.mono (fun _ ht => ht.1))
  have hequal : EqOn qshift rshift (Ici (-L)) :=
    (huniq qshift hqshift).trans (huniq rshift hrshift').symm
  intro t ht
  have hx := hequal (show t-L ∈ Ici (-L) by change -L ≤ t-L; change 0 ≤ t at ht; linarith)
  simpa only [qshift, rshift, sub_add_cancel, sub_left_inj] using hx

end Article14
