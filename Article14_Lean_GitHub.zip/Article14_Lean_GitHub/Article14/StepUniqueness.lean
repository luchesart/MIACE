import Article14.StepAffine
import Article14.StepExistence
import Mathlib.Analysis.ODE.Gronwall

/-!+# The initial transport interval of every physical response

Local absolute continuity and the actual differential equations force the
initial plant state to remain zero until the command reaches the plant.
This supplies the initial history needed for uniqueness of the subsequent
homogeneous delayed equation.
-/
namespace Article14
open MeasureTheory Filter Set MIACE
open scoped Topology
variable {n : Type*} [Fintype n]

/-- A finite linear homogeneous ODE with zero initial state has only the zero
locally absolutely continuous solution.  The classical Grönwall theorem is
applied to the integral primitive, whose differentiability is derived by FTC. -/
theorem locallyAC_finite_linear_zero (A : Matrix n n ℝ) {x : ℝ → n → ℝ} {L : ℝ}
    (hx : ContinuousOn x (Ici 0))
    (hac : ∀ j T, 0 ≤ T → AbsolutelyContinuousOnInterval (fun t => x t j) 0 T)
    (hzero : x 0 = 0)
    (hode : ∀ j, ∀ᵐ t : ℝ, t ∈ Ioc 0 L →
      deriv (fun s => x s j) t = ∑ l, A j l*x t l) :
    ∀ t ∈ Icc 0 L, x t = 0 := by
  let f : ℝ → n → ℝ := fun t => finiteStateMap A (x (max t 0))
  have hf : Continuous f := (finiteStateMap A).continuous.comp
    (hx.comp_continuous (continuous_id.max continuous_const) (fun t => le_max_right t 0))
  let G : ℝ → n → ℝ := fun t j => ∫ s in 0..t, f s j
  have hdG : ∀ t, HasDerivAt G (f t) t := by
    intro t
    apply hasDerivAt_pi.mpr
    intro j
    exact ((continuous_apply j).comp hf).integral_hasStrictDerivAt 0 t |>.hasDerivAt
  have hG : Continuous G := continuous_iff_continuousAt.mpr
    (fun t => (hdG t).continuousAt)
  have heq : ∀ t ∈ Icc 0 L, x t = G t := by
    intro t ht
    ext j
    have hh := (hac j t ht.1).integral_deriv_eq_sub
    have hi : (∫ s in 0..t, deriv (fun z => x z j) s) = ∫ s in 0..t, f s j := by
      apply intervalIntegral.integral_congr_ae
      filter_upwards [hode j] with s hs hst
      rw [uIoc_of_le ht.1] at hst
      rw [hs ⟨hst.1, hst.2.trans ht.2⟩]
      simp only [f, max_eq_left hst.1.le, finiteStateMap_apply]
    rw [hi, hzero, Pi.zero_apply, sub_zero] at hh
    exact hh.symm
  have hGzero : G 0 = 0 := by ext j; simp [G]
  have hbound : ∀ t ∈ Ico 0 L, ‖f t‖ ≤ ‖finiteStateMap A‖*‖G t‖ := by
    intro t ht
    simpa only [f, max_eq_left ht.1, heq t ⟨ht.1, ht.2.le⟩] using
      (finiteStateMap A).le_opNorm (G t)
  have hGzeroAll := eq_zero_of_abs_deriv_le_mul_abs_self_of_eq_zero_right
    hG.continuousOn (fun t _ => (hdG t).hasDerivWithinAt) hGzero hbound
  intro t ht
  rw [heq t ht]
  exact hGzeroAll t ht

/-- The actual zero-history plant cannot move before its delayed input arrives. -/
theorem step_state_zero_before_delay
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q) :
    ∀ t ∈ Icc 0 L, (q t).1 = 0 := by
  apply locallyAC_finite_linear_zero A h.continuous.fst h.state_ac
    (by simp [h.initial])
  intro j
  filter_upwards [h.state_ode j] with t ht htmem
  simpa only [htmem.2, ite_true, mul_zero, add_zero] using ht htmem.1

theorem step_integral_before_delay
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q) :
    ∀ t ∈ Icc 0 L, (q t).2.1 = t := by
  intro t ht
  have hh := (h.integral_ac t ht.1).integral_deriv_eq_sub
  have hi : (∫ s in 0..t, deriv (fun z => (q z).2.1) s) = ∫ s in 0..t, (1 : ℝ) := by
    apply intervalIntegral.integral_congr_ae
    filter_upwards [h.integral_ode] with s hs hst
    rw [uIoc_of_le ht.1] at hst
    rw [hs hst.1]
    simp [sharedControllerRhs, step_state_zero_before_delay h s ⟨hst.1.le, hst.2.trans ht.2⟩,
      finitePlantOutput]
  simpa [hi, h.initial] using hh.symm

theorem step_filter_before_delay
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q) :
    ∀ t ∈ Icc 0 L, (q t).2.2 = c*(1-Real.exp (-t/Tf)) := by
  let x : ℝ → Unit → ℝ := fun t _ => (q t).2.2-c*(1-Real.exp (-t/Tf))
  have hcont : ContinuousOn x (Ici 0) := by
    apply continuousOn_pi.mpr
    intro j
    exact h.continuous.snd.snd.sub (by fun_prop)
  have hac : ∀ j T, 0 ≤ T → AbsolutelyContinuousOnInterval (fun t => x t j) 0 T := by
    intro j T hT
    exact (h.filter_ac T hT).sub (ContDiffOn.absolutelyContinuousOnInterval (by fun_prop))
  have hz : x 0 = 0 := by ext j; simp [x, h.initial]
  have hode : ∀ j, ∀ᵐ t : ℝ, t ∈ Ioc 0 L →
      deriv (fun s => x s j) t = ∑ l : Unit, (-1/Tf)*x t l := by
    intro j
    filter_upwards [h.filter_ode, local_ac_ae_differentiable h.filter_ac]
      with t ho hd ht
    have he := (transportStep_hasDerivAt (n := Unit) c Tf t).snd.snd
    have hdif := (hd ht.1).hasDerivAt.sub he
    change HasDerivAt (fun s => x s j) _ t at hdif
    rw [hdif.deriv, ho ht.1]
    simp only [sharedControllerRhs, step_state_zero_before_delay h t ⟨ht.1.le, ht.2⟩,
      finitePlantOutput, Pi.zero_apply, mul_zero, Finset.sum_const_zero,
      mul_one, sub_zero, Fintype.sum_unique, x]
    ring
  have hzero := locallyAC_finite_linear_zero (fun _ _ : Unit => -1/Tf) hcont hac hz hode
  intro t ht
  have hh := congrFun (hzero t ht) ()
  simpa only [x, Pi.zero_apply, sub_eq_zero] using hh

/-- Every physical solution has the explicit transport prefix, derived from
its zero initial state and its almost-everywhere differential equations. -/
theorem stepLoopDynamics_transport_prefix
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : StepLoopDynamics A B C Kp Ti Td Tf L b c q) :
    ∀ t ∈ Icc 0 L, q t = transportStep c Tf t := by
  intro t ht
  exact Prod.ext (step_state_zero_before_delay h t ht)
    (Prod.ext (step_integral_before_delay h t ht) (step_filter_before_delay h t ht))

-- Equal references cancel in every actual shared-controller equation.
theorem sharedController_step_difference (Kp Ti Td Tf b c y i f Y I F : ℝ) :
    sharedControllerRhs Kp Ti Td Tf b c 1 y i f -
      sharedControllerRhs Kp Ti Td Tf b c 1 Y I F =
    sharedControllerRhs Kp Ti Td Tf b c 0 (y-Y) (i-I) (f-F) := by
  ext <;> simp only [sharedControllerRhs, Prod.fst_sub, Prod.snd_sub] <;> ring

-- This identity requires linearity only, not a plant DC gain or equilibrium.
theorem retardedShared_step_difference
    (A : Matrix n n ℝ) (B C : n → ℝ) (Kp Ti Td Tf L b c : ℝ)
    (q r : ℝ → (n → ℝ) × ℝ × ℝ) :
    retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L b c (fun _ => 1) q -
      retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L b c (fun _ => 1) r =
    retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L b c (fun _ => 0) (fun t => q t-r t) := by
  simp only [retardedSharedRhs, Prod.fst_sub, Prod.snd_sub]
  have hout (t : ℝ) : finitePlantOutput C ((q t).1-(r t).1) =
      finitePlantOutput C (q t).1-finitePlantOutput C (r t).1 := by
    rw [← finiteOutputMap_eq C]
    exact map_sub _ _ _
  rw [hout 0, hout (-L), ← sharedController_step_difference,
    ← sharedController_step_difference]
  apply Prod.ext
  · rw [← finiteLinearPlantDynamics_eq]
    simp only [linearPlantDynamics, map_sub, Prod.snd_sub, Prod.fst_sub]
    abel
  · rfl

/-- Uniqueness of physical step trajectories needs only homogeneous
well-posedness.  The plant may have an origin pole or zero DC gain; no
equilibrium or inverse plant matrix is used. -/
theorem stepLoopDynamics_unique_of_wellPosed
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf L b c : ℝ}
    {q r : ℝ → (n → ℝ) × ℝ × ℝ}
    (hwp : IsRetardedSharedWellPosed (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L b c)
    (hq : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (hr : StepLoopDynamics A B C Kp Ti Td Tf L b c r) : EqOn q r (Ici 0) := by
  let z := fun t => q t-r t
  have hz : ContinuousOn z (Ici 0) := hq.continuous.sub hr.continuous
  have hd : ∀ t, L<t → HasDerivAt z
      (retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
        Kp Ti Td Tf L b c (fun _ => 0) (fun θ => z (t+θ))) t := by
    intro t ht
    have hh := (hq.after_delay t ht).sub (hr.after_delay t ht)
    rwa [retardedShared_step_difference] at hh
  have hs := retardedShared_shifted_solution _ _ Kp Ti Td Tf L b c z hz hd
  have hs' : IsRetardedSharedSolution (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L b c (fun _ => 0) (fun t => z (t+L)) := by
    refine ⟨hs.1, ?_, hs.2.2⟩
    intro t ht
    dsimp [z]
    have hmem : t+L ∈ Icc 0 L := by constructor <;> linarith [ht.1,ht.2]
    rw [stepLoopDynamics_transport_prefix hq (t+L) hmem,
      stepLoopDynamics_transport_prefix hr (t+L) hmem, sub_self]
  have hzero : IsRetardedSharedSolution (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L b c (fun _ => 0) (fun _ => 0) := by
    refine ⟨continuousOn_const, fun _ _ => rfl, ?_⟩
    intro t ht
    convert hasDerivAt_const t (0 : (n → ℝ) × ℝ × ℝ) using 1
    ext j <;> simp [retardedSharedRhs, sharedControllerRhs, finitePlantOutput,
      finitePlantDynamics]
  obtain ⟨u, _, huniq⟩ := hwp (fun _ => 0) continuousOn_const
  have hequal := (huniq (fun t => z (t+L)) hs').trans (huniq (fun _ => 0) hzero).symm
  intro t ht
  have hh := hequal (show t-L ∈ Ici (-L) by change -L ≤ t-L; change 0 ≤ t at ht; linarith)
  simpa only [sub_add_cancel, z, sub_eq_zero] using hh

theorem stepLoopDynamics_eq_affine_family_of_wellPosed
    {A : Matrix n n ℝ} {B C : n → ℝ} {Kp Ti Td Tf L b c : ℝ}
    {q q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ}
    (hwp : IsRetardedSharedWellPosed (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L b c)
    (hq : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (h00 : StepLoopDynamics A B C Kp Ti Td Tf L 0 0 q00)
    (h10 : StepLoopDynamics A B C Kp Ti Td Tf L 1 0 q10)
    (h01 : StepLoopDynamics A B C Kp Ti Td Tf L 0 1 q01) :
    EqOn q (stepAffineFamily q00 q10 q01 b c) (Ici 0) :=
  stepLoopDynamics_unique_of_wellPosed hwp hq (stepLoopDynamics_affine_family h00 h10 h01 b c)

/-- Uniqueness among arbitrary physical step responses follows from the
homogeneous well-posedness property; equality of their prefix is a conclusion. -/
theorem stepLoopDynamics_unique
    {A : Matrix n n ℝ} {B C xe : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q r : ℝ → (n → ℝ) × ℝ × ℝ}
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0)
    (heq : ∀ j, (∑ l, A j l*xe l)+B j/k=0)
    (hout : (∑ j, C j*xe j) = 1)
    (hwp : IsRetardedSharedWellPosed (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L b c)
    (hq : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (hr : StepLoopDynamics A B C Kp Ti Td Tf L b c r) : EqOn q r (Ici 0) := by
  apply stepLoopDynamics_unique_of_prefix hTi hk hKp heq hout hwp hq hr
  intro t ht
  rw [stepLoopDynamics_transport_prefix hq t ht, stepLoopDynamics_transport_prefix hr t ht]

/-- The affine construction equals every actual physical step response on
nonnegative time, so it is independent of the choice of the three solutions. -/
theorem stepLoopDynamics_eq_affine_family
    {A : Matrix n n ℝ} {B C xe : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q q00 q10 q01 : ℝ → (n → ℝ) × ℝ × ℝ}
    (hTi : Ti ≠ 0) (hk : k ≠ 0) (hKp : Kp ≠ 0)
    (heq : ∀ j, (∑ l, A j l*xe l)+B j/k=0)
    (hout : (∑ j, C j*xe j) = 1)
    (hwp : IsRetardedSharedWellPosed (finitePlantOutput C) (finitePlantDynamics A B)
      Kp Ti Td Tf L b c)
    (hq : StepLoopDynamics A B C Kp Ti Td Tf L b c q)
    (h00 : StepLoopDynamics A B C Kp Ti Td Tf L 0 0 q00)
    (h10 : StepLoopDynamics A B C Kp Ti Td Tf L 1 0 q10)
    (h01 : StepLoopDynamics A B C Kp Ti Td Tf L 0 1 q01) :
    EqOn q (stepAffineFamily q00 q10 q01 b c) (Ici 0) :=
  stepLoopDynamics_unique hTi hk hKp heq hout hwp hq
    (stepLoopDynamics_affine_family h00 h10 h01 b c)

end Article14
