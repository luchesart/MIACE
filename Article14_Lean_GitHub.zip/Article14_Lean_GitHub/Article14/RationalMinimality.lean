import Article14.RationalPlantFamily
import Mathlib.LinearAlgebra.Matrix.Charpoly.Coeff
import Mathlib.Algebra.Polynomial.Roots

/-!
# Minimal state dimension of the constructed rational realization

For every competing finite state realization, the adjugate formula supplies
an actual polynomial transfer numerator and the characteristic denominator.
Coprimeness of the plant quotient forces its denominator to divide that
characteristic polynomial. Its degree is therefore a lower bound for every
state dimension. The constructed companion attains that lower bound.
-/
namespace Article14.RationalRealization
open Polynomial Matrix Finset Filter
open Article14.PhysicalPlant
open scoped Matrix

variable {m : Type*} [Fintype m] [DecidableEq m]

/-- The genuine polynomial numerator from the plant's characteristic matrix. -/
noncomputable def adjugateNumerator (A : Matrix m m ℝ) (B C₀ : m → ℝ) : ℝ[X] :=
  (fun i => Polynomial.C (C₀ i)) ⬝ᵥ
    (A.charmatrix.adjugate *ᵥ (fun i => Polynomial.C (B i)))

theorem charmatrix_eval (A : Matrix m m ℝ) (s : ℝ) :
    A.charmatrix.map (Polynomial.evalRingHom s) = pencil A s := by
  ext i j
  by_cases h : i=j
  · subst j
    simp [Matrix.charmatrix, pencil, Matrix.smul_one_eq_diagonal]
  · simp [Matrix.charmatrix, pencil, Matrix.smul_one_eq_diagonal, h]

theorem charpoly_eval_pencil (A : Matrix m m ℝ) (s : ℝ) :
    A.charpoly.eval s = (pencil A s).det := by
  rw [Matrix.eval_charpoly]
  simp only [pencil, Matrix.scalar_apply, Matrix.smul_one_eq_diagonal]

theorem adjugateNumerator_eval (A : Matrix m m ℝ) (B C₀ : m → ℝ) (s : ℝ) :
    (adjugateNumerator A B C₀).eval s = C₀ ⬝ᵥ ((pencil A s).adjugate *ᵥ B) := by
  let f : ℝ[X] →+* ℝ := Polynomial.evalRingHom s
  have he : f.mapMatrix A.charmatrix.adjugate = (pencil A s).adjugate := by
    rw [RingHom.map_adjugate]
    exact congrArg Matrix.adjugate (charmatrix_eval A s)
  change f ((fun i => Polynomial.C (C₀ i)) ⬝ᵥ
    (A.charmatrix.adjugate *ᵥ (fun i => Polynomial.C (B i)))) = _
  rw [RingHom.map_dotProduct]
  have hc : f ∘ (fun i => Polynomial.C (C₀ i)) = C₀ := by funext i; simp [f]
  have hb : f ∘ (fun i => Polynomial.C (B i)) = B := by funext i; simp [f]
  rw [hc]
  have hv : f ∘ (A.charmatrix.adjugate *ᵥ (fun i => Polynomial.C (B i))) =
      (pencil A s).adjugate *ᵥ B := by
    funext i
    rw [Function.comp_apply, RingHom.map_mulVec]
    rw [hb]
    exact congrArg (fun M : Matrix m m ℝ => (M *ᵥ B) i) he
  rw [hv]

-- The polynomial fraction is derived from the actual matrix inverse, including
-- totalized values at singular frequencies. No transfer certificate is assumed.
theorem matrix_transfer_adjugate_fraction (A : Matrix m m ℝ) (B C₀ : m → ℝ) (s : ℝ) :
    ((C₀ ᵥ* (pencil A s)⁻¹) ⬝ᵥ B) =
      (adjugateNumerator A B C₀).eval s / A.charpoly.eval s := by
  rw [← dotProduct_mulVec, Matrix.inv_def, Ring.inverse_eq_inv',
    Matrix.smul_mulVec, dotProduct_smul, adjugateNumerator_eval, charpoly_eval_pencil]
  simp only [smul_eq_mul, div_eq_mul_inv, mul_comm]

/-- A competing realization means equality of its actual inverse-pencil
input-output transfer at non-pole real frequencies. This premise is used only
to compare arbitrary realizations; the companion satisfies it by construction. -/
def Realizes (P : RationalPlant) (A : Matrix m m ℝ) (B C₀ : m → ℝ) : Prop :=
  ∀ s, P.den.eval s ≠ 0 → A.charpoly.eval s ≠ 0 →
    ((C₀ ᵥ* (pencil A s)⁻¹) ⬝ᵥ B) = P.num.eval s/P.den.eval s

-- Equality of the actual transfer on the complement of finitely many poles
-- gives the polynomial cross-product identity.
theorem realization_polynomial_identity (P : RationalPlant) (A : Matrix m m ℝ)
    (B C₀ : m → ℝ) (h : Realizes P A B C₀) :
    P.num*A.charpoly = adjugateNumerator A B C₀*P.den := by
  apply Polynomial.eq_of_infinite_eval_eq
  apply Filter.frequently_cofinite_iff_infinite.mp
  apply Filter.Eventually.frequently
  filter_upwards [Polynomial.eventually_eval_ne_zero_cofinite P.den_ne_zero,
    Polynomial.eventually_eval_ne_zero_cofinite A.charpoly_monic.ne_zero] with s hd ha
  have hh := h s hd ha
  rw [matrix_transfer_adjugate_fraction A B C₀ s] at hh
  simp only [Polynomial.eval_mul]
  exact ((div_eq_div_iff ha hd).mp hh).symm

-- Reducedness forbids hiding a lower-degree denominator inside another state
-- realization: every realization's characteristic polynomial contains it.
theorem reduced_denominator_dvd_charpoly (P : RationalPlant) (A : Matrix m m ℝ)
    (B C₀ : m → ℝ) (h : Realizes P A B C₀) : P.den ∣ A.charpoly := by
  apply P.reduced.symm.dvd_of_dvd_mul_left
  refine ⟨adjugateNumerator A B C₀, ?_⟩
  rw [realization_polynomial_identity P A B C₀ h]
  ring

-- This lower bound applies to every finite state space, with no reachability
-- or observability certificate included among its assumptions.
theorem realization_dimension_lower_bound (P : RationalPlant) (A : Matrix m m ℝ)
    (B C₀ : m → ℝ) (h : Realizes P A B C₀) : P.den.natDegree ≤ Fintype.card m := by
  have hd := Polynomial.natDegree_le_of_dvd (reduced_denominator_dvd_charpoly P A B C₀ h)
    A.charpoly_monic.ne_zero
  simpa only [Matrix.charpoly_natDegree_eq_dim] using hd

namespace RationalPlant

theorem companion_realizes (P : RationalPlant) : Realizes P P.stateMatrix P.input P.output := by
  intro s hs _
  exact P.transfer_eq s hs

theorem companion_dimension (P : RationalPlant) :
    Fintype.card (Fin (P.order+1)) = P.den.natDegree := by
  simp only [Fintype.card_fin, ← P.degree_eq_order_succ]

-- The constructed companion is a minimal realization in the literal sense
-- that no finite realization of this transfer has fewer state coordinates.
theorem companion_minimal_dimension (P : RationalPlant) (A : Matrix m m ℝ)
    (B C₀ : m → ℝ) (h : Realizes P A B C₀) :
    Fintype.card (Fin (P.order+1)) ≤ Fintype.card m := by
  rw [P.companion_dimension]
  exact realization_dimension_lower_bound P A B C₀ h

end RationalPlant
end Article14.RationalRealization
