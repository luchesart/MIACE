import Article14.PhysicalFamily
import Article14.PositiveCommandGeometry
import Article14.L1Settling

/-!
# Optimization over the physical delayed PIDF family

All signals, kernels, affine maps, their independence, and their mass are
constructed by `StablePIDFData`.  The remaining hypotheses here are the
engineering constraint set, its stated geometric properties, and nonemptiness
when a minimizer is requested.
-/
namespace Article14
open MeasureTheory Filter Set MIACE
open scoped Topology

namespace StablePIDFData
variable {n : Type*} [Fintype n] [DecidableEq n]

/-- The original positive-impulse feasible set of Theorem 14. -/
noncomputable def feasible (d : StablePIDFData n) (X : Set (ℝ × ℝ)) : Set (ℝ × ℝ) :=
  kernelFeasible X d.kernelBase d.kernelDirections

/-- Theorem 17's additional positive centered-command constraint. -/
noncomputable def positiveFeasible (d : StablePIDFData n)
    (X : Set (ℝ × ℝ)) : Set (ℝ × ℝ) :=
  positiveCommandFeasible X d.kernelBase d.kernelDirections
    d.commandBase d.commandDirections

theorem mem_feasible_iff (d : StablePIDFData n) (X : Set (ℝ × ℝ)) (w : ℝ × ℝ) :
    w ∈ d.feasible X ↔ w ∈ X ∧ ∀ᵐ t ∂halfLine, 0 ≤ d.kernel w t := by
  change (w ∈ X ∧ (0 : RealL1) ≤ d.kernelBase+d.kernelDirections w) ↔ _
  rw [← d.kernelL1_eq, kernelL1, signalL1_nonnegative_iff]

theorem feasible_kernel_nonnegative (d : StablePIDFData n) {X : Set (ℝ × ℝ)}
    {w : ℝ × ℝ} (hw : w ∈ d.feasible X) : ∀ᵐ t ∂halfLine, 0 ≤ d.kernel w t :=
  ((d.mem_feasible_iff X w).mp hw).2

theorem mem_positiveFeasible_iff (d : StablePIDFData n)
    (X : Set (ℝ × ℝ)) (w : ℝ × ℝ) :
    w ∈ d.positiveFeasible X ↔
      w ∈ d.feasible X ∧ ∀ᵐ t ∂halfLine, 0 ≤ d.command w t := by
  change (w ∈ d.feasible X ∧ (0 : RealL1) ≤
    d.commandBase+d.commandDirections w) ↔ _
  rw [← d.commandL1_eq, commandL1, signalL1_nonnegative_iff]

theorem positiveFeasible_subset (d : StablePIDFData n) (X : Set (ℝ × ℝ)) :
    d.positiveFeasible X ⊆ d.feasible X := fun _ hw => hw.1

theorem feasible_closed (d : StablePIDFData n) {X : Set (ℝ × ℝ)} (hX : IsClosed X) :
    IsClosed (d.feasible X) := kernelFeasible_closed hX _ _

theorem feasible_convex (d : StablePIDFData n) {X : Set (ℝ × ℝ)} (hX : Convex ℝ X) :
    Convex ℝ (d.feasible X) := kernelFeasible_convex hX _ _

theorem feasible_compact (d : StablePIDFData n) {X : Set (ℝ × ℝ)} (hX : IsClosed X) :
    IsCompact (d.feasible X) := by
  apply kernelFeasible_compact hX d.kernelBase d.kernelDirections d.kernelDirections_injective
  intro w _
  rw [← d.kernelL1_eq]
  exact d.kernel_mass_l1 w

theorem positiveFeasible_closed (d : StablePIDFData n)
    {X : Set (ℝ × ℝ)} (hX : IsClosed X) : IsClosed (d.positiveFeasible X) :=
  positiveCommandFeasible_closed hX _ _ _ _

theorem positiveFeasible_convex (d : StablePIDFData n)
    {X : Set (ℝ × ℝ)} (hX : Convex ℝ X) : Convex ℝ (d.positiveFeasible X) :=
  positiveCommandFeasible_convex hX _ _ _ _

theorem positiveFeasible_compact (d : StablePIDFData n)
    {X : Set (ℝ × ℝ)} (hX : IsClosed X) : IsCompact (d.positiveFeasible X) :=
  (d.feasible_compact hX).of_isClosed_subset
    (d.positiveFeasible_closed hX) (d.positiveFeasible_subset X)

theorem positiveFeasible_projection_interval (d : StablePIDFData n)
    {X : Set (ℝ × ℝ)} (hX : IsClosed X) (hconv : Convex ℝ X)
    (hne : (d.positiveFeasible X).Nonempty) :
    ∃ lo hi : ℝ, lo ≤ hi ∧ Prod.fst '' d.positiveFeasible X = Icc lo hi :=
  compact_convex_projection_interval (d.positiveFeasible_compact hX)
    (d.positiveFeasible_convex hconv) hne

-- Both signs now come from physical feasibility; the transfer and signed
-- area come from the very same constructed physical trajectory.
theorem positiveMIACEFamily (d : StablePIDFData n) (X : Set (ℝ × ℝ)) :
    PositiveMIACEFamily (d.positiveFeasible X) d.error d.command
      d.transfer d.L d.k d.Kp d.Ti := by
  refine ⟨fun w _ => (d.physical_transfer w).1, ?_, ?_, ?_⟩
  · intro w hw
    have hg : (0 : RealL1) ≤ d.kernelL1 w := by
      rw [d.kernelL1_eq]
      exact hw.1.2
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    have hb := (positive_kernel_step_bounds (L1.integrable_coeFn (d.kernelL1 w))
      ((Lp.coeFn_nonneg _).mpr hg) (d.kernel_mass_l1 w) t).2
    rw [d.kernelStep_eq_output_l1 w t (le_of_lt ht)] at hb
    exact sub_nonneg.mpr hb
  · intro w hw
    exact ((d.mem_positiveFeasible_iff X w).mp hw).2
  · intro w _
    rw [(d.physical_transfer w).2]
    unfold meanTime trackingMean
    ring

-- Theorem 17 with only physical plant/controller data and closed convex X.
-- The feasible interval and a true MIACE minimizer are derived conclusions.
theorem physical_miace_reduction (d : StablePIDFData n)
    {X : Set (ℝ × ℝ)} (hX : IsClosed X) (hconv : Convex ℝ X)
    (hne : (d.positiveFeasible X).Nonempty) (α : ℝ) (hα : 0 < α)
    (hΓ : 0 ≤ d.gamma) :
    ∃ lo hi : ℝ, lo ≤ hi ∧
      (∀ b, (∃ c, (b,c) ∈ d.positiveFeasible X) ↔ b ∈ Icc lo hi) ∧
      (∃ c, (clampedWeight lo hi (miaceTarget d.k d.Kp d.Ti d.gamma α), c) ∈
        d.positiveFeasible X ∧
        ∀ w ∈ d.positiveFeasible X,
          miace α (d.error (clampedWeight lo hi (miaceTarget d.k d.Kp d.Ti d.gamma α), c))
            (d.command (clampedWeight lo hi (miaceTarget d.k d.Kp d.Ti d.gamma α), c))
            halfLine ≤ miace α (d.error w) (d.command w) halfLine) ∧
      ((∃ w ∈ d.positiveFeasible X,
        miace α (d.error w) (d.command w) halfLine = d.gamma*Real.sqrt (α/(1+α))) ↔
        miaceTarget d.k d.Kp d.Ti d.gamma α ∈ Icc lo hi) := by
  have h := positive_family_compact_convex_reduction (d.positiveMIACEFamily X)
    (d.gamma-d.L) α d.Ti_pos hα (by simpa using hΓ)
    d.transfer_hasDerivAt_zero d.transfer_zero
    (d.positiveFeasible_compact hX) (d.positiveFeasible_convex hconv) hne
  simpa only [sub_add_cancel] using h

-- Every feasible derivative weight over the projected proportional weight
-- gives the same exact minimum of the actual MIACE functional.
theorem physical_miace_every_clipped_fiber (d : StablePIDFData n)
    {X : Set (ℝ × ℝ)} (hX : IsClosed X) (hconv : Convex ℝ X)
    (hne : (d.positiveFeasible X).Nonempty) (α : ℝ) (hα : 0 < α) :
    ∃ lo hi : ℝ, lo ≤ hi ∧ Prod.fst '' d.positiveFeasible X = Icc lo hi ∧
      ∀ wstar ∈ d.positiveFeasible X,
        wstar.1 = clampedWeight lo hi (miaceTarget d.k d.Kp d.Ti d.gamma α) →
        (∀ w ∈ d.positiveFeasible X,
          miace α (d.error wstar) (d.command wstar) halfLine ≤
            miace α (d.error w) (d.command w) halfLine) ∧
        (miace α (d.error wstar) (d.command wstar) halfLine)^2 =
          α*d.gamma^2/(1+α)+(1+α)*d.Ti^2 *
            (clampedWeight lo hi (miaceTarget d.k d.Kp d.Ti d.gamma α)-
              miaceTarget d.k d.Kp d.Ti d.gamma α)^2 := by
  have h := positiveCommandFeasible_every_clipped_fiber hX hconv
    d.kernelBase d.kernelDirections d.commandBase d.commandDirections
    d.kernelDirections_injective (fun w _ => by
      rw [← d.kernelL1_eq]; exact d.kernel_mass_l1 w) hne
    (d.positiveMIACEFamily X) (d.gamma-d.L) α d.Ti_pos hα
    d.transfer_hasDerivAt_zero d.transfer_zero
  simpa only [positiveFeasible, sub_add_cancel] using h

-- The exact gap identity holds for every physical weight pair, including
-- responses with negative error or negative centered command.
theorem physical_miace_gap (d : StablePIDFData n) (w : ℝ × ℝ)
    (α : ℝ) (hα : 0 < α) :
    (miace α (d.error w) (d.command w) halfLine)^2-α*d.gamma^2/(1+α) =
      4*α/(1+α)*(negArea (d.error w) halfLine+negArea (d.command w) halfLine) *
        (d.gamma+(negArea (d.error w) halfLine+negArea (d.command w) halfLine)) +
      (absArea (d.error w) halfLine-α*absArea (d.command w) halfLine)^2/(1+α) := by
  simpa only [sub_add_cancel] using local_transfer_miace_gap
    (d.transfer_response w) α (d.gamma-d.L) hα
    d.transfer_hasDerivAt_zero d.transfer_zero

theorem physical_signed_areas (d : StablePIDFData n) (w : ℝ × ℝ) :
    (∫ t, d.error w t ∂halfLine) = meanTime d.Ti d.k d.Kp w.1 ∧
    (∫ t, d.command w t ∂halfLine) = d.gamma-meanTime d.Ti d.k d.Kp w.1 := by
  refine ⟨d.error_area w, ?_⟩
  have hb := local_transfer_signed_balance (d.transfer_response w) (d.gamma-d.L)
    d.transfer_hasDerivAt_zero d.transfer_zero
  rw [d.error_area, sub_add_cancel] at hb
  linarith

/-- The causal physical step output. Its ordinary impulse integral is proved
below, and agrees with the actual plant state at every nonnegative time. -/
noncomputable def output (d : StablePIDFData n) (w : ℝ × ℝ) (t : ℝ) : ℝ :=
  if 0 ≤ t then finitePlantOutput d.C (d.response w t).1 else 0

theorem kernelL1_causal (d : StablePIDFData n) (w : ℝ × ℝ) :
    Causal (fun t => d.kernelL1 w t) := by
  filter_upwards [signalL1_coe (d.kernel w) (d.kernel_integrable w)] with t ht hneg
  change signalL1 (d.kernel w) (d.kernel_integrable w) t = 0
  rw [ht]
  simp [causalize, not_le.mpr hneg]

theorem output_eq_l1KernelStep (d : StablePIDFData n) (w : ℝ × ℝ) :
    d.output w = l1KernelStep (d.kernelBase+d.kernelDirections w) := by
  rw [← d.kernelL1_eq]
  funext t
  by_cases ht : 0 ≤ t
  · simpa only [output, ite_eq_left ht, l1KernelStep] using
      (d.kernelStep_eq_output_l1 w t ht).symm
  · have hz := causal_kernel_step_zero (d.kernelL1_causal w) (le_of_not_ge ht)
    simpa only [output, ite_eq_right ht, l1KernelStep] using hz.symm

-- Theorem 14(a): positivity is equivalent to monotonicity of the physical
-- step output, with both directions proved for the constructed kernel.
theorem physical_output_monotone_iff (d : StablePIDFData n) (w : ℝ × ℝ) :
    Monotone (d.output w) ↔ ∀ᵐ t ∂halfLine, 0 ≤ d.kernel w t := by
  rw [d.output_eq_l1KernelStep, ← d.kernelL1_eq]
  change Monotone (kernelStep (fun t => d.kernelL1 w t)) ↔ _
  rw [kernel_step_monotone_iff (L1.integrable_coeFn (d.kernelL1 w))]
  change (0 : ℝ → ℝ) ≤ᵐ[volume] (d.kernelL1 w : ℝ → ℝ) ↔ _
  rw [Lp.coeFn_nonneg, kernelL1, signalL1_nonnegative_iff]

theorem physical_output_bounds (d : StablePIDFData n)
    {X : Set (ℝ × ℝ)} {w : ℝ × ℝ} (hw : w ∈ d.feasible X) (t : ℝ) :
    0 ≤ d.output w t ∧ d.output w t ≤ 1 := by
  rw [d.output_eq_l1KernelStep]
  exact positive_kernel_step_bounds (L1.integrable_coeFn _)
    ((Lp.coeFn_nonneg _).mpr hw.2)
    (by rw [← d.kernelL1_eq]; exact d.kernel_mass_l1 w) t

theorem physical_output_initial (d : StablePIDFData n) (w : ℝ × ℝ) :
    d.output w 0 = 0 := by
  rw [d.output_eq_l1KernelStep, ← d.kernelL1_eq]
  exact causal_kernel_step_zero (d.kernelL1_causal w) le_rfl

theorem physical_output_final (d : StablePIDFData n) (w : ℝ × ℝ) :
    Tendsto (d.output w) atTop (𝓝 1) := by
  rw [d.output_eq_l1KernelStep, ← d.kernelL1_eq]
  exact unit_mass_kernel_step_tendsto_one (L1.integrable_coeFn _) (d.kernel_mass_l1 w)

-- The exact norm is taken from the genuine impulse response's complex
-- Laplace integral; it is equal to one throughout the feasible family.
theorem physical_hinf_eq_one (d : StablePIDFData n)
    {X : Set (ℝ × ℝ)} {w : ℝ × ℝ} (hw : w ∈ d.feasible X) :
    kernelHinf (d.kernel w) = 1 := by
  have hg : (0 : RealL1) ≤ d.kernelL1 w := by rw [d.kernelL1_eq]; exact hw.2
  have hn : ∀ᵐ t, 0 ≤ d.kernel w t := by
    filter_upwards [(Lp.coeFn_nonneg _).mpr hg, d.kernelL1_coe_full w] with t ht he
    rwa [← he]
  have hc : Causal (d.kernel w) := by
    filter_upwards [d.kernelL1_causal w, d.kernelL1_coe_full w] with t ht he hneg
    rw [← he]
    exact ht hneg
  have hm : (∫ t, d.kernel w t) = 1 := by
    rw [← integral_congr_ae (d.kernelL1_coe_full w)]
    exact d.kernel_mass_l1 w
  exact positive_kernel_hinf_eq_one (d.kernel_integrable_full w) hc hn hm

-- Proposition 16: a true all-future settling-time optimum exists in the
-- actual physical family; no continuity assumption about settling time.
theorem physical_minimum_settlingTime_exists (d : StablePIDFData n)
    {X : Set (ℝ × ℝ)} (hX : IsClosed X) (hne : (d.feasible X).Nonempty)
    {ε : ℝ} (hε : 0 < ε) :
    ∃ w ∈ d.feasible X, 0 ≤ settlingTime (d.output w) ε ∧
      SettledBy (d.output w) ε (settlingTime (d.output w) ε) ∧
      ∀ z ∈ d.feasible X, settlingTime (d.output w) ε ≤ settlingTime (d.output z) ε := by
  simpa only [d.output_eq_l1KernelStep, feasible] using
    l1_kernel_minimum_settlingTime_exists hX d.kernelBase d.kernelDirections
      d.kernelDirections_injective (fun w _ => by
        rw [← d.kernelL1_eq]; exact d.kernel_mass_l1 w) hne hε

theorem physical_settlingTime_quasiconvex (d : StablePIDFData n)
    {X : Set (ℝ × ℝ)} (hconv : Convex ℝ X) {ε : ℝ} (hε : 0 < ε) :
    QuasiconvexOn ℝ (d.feasible X) (fun w => settlingTime (d.output w) ε) := by
  simpa only [d.output_eq_l1KernelStep, feasible] using
    l1_kernel_settlingTime_quasiconvex hconv d.kernelBase d.kernelDirections
      (fun w _ => by rw [← d.kernelL1_eq]; exact d.kernel_mass_l1 w) hε

-- A finite horizon test is exact for the physical all-future criterion.
theorem physical_settlingTime_le_iff (d : StablePIDFData n)
    {X : Set (ℝ × ℝ)} {w : ℝ × ℝ} (hw : w ∈ d.feasible X)
    {ε : ℝ} (hε : 0 < ε) {H : ℝ} (hH : 0 ≤ H) :
    settlingTime (d.output w) ε ≤ H ↔
      1-ε ≤ l1KernelStep d.kernelBase H +
        w.1*l1KernelStep (d.kernelDirections (1,0)) H +
        w.2*l1KernelStep (d.kernelDirections (0,1)) H := by
  rw [d.output_eq_l1KernelStep]
  exact l1_kernel_settlingTime_le_iff hw
    (by rw [← d.kernelL1_eq]; exact d.kernel_mass_l1 w) hε hH

end StablePIDFData
end Article14
