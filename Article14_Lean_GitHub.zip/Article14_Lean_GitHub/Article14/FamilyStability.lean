import Mathlib.Tactic
import Mathlib.Basic.Complex.Basic

/-!
Article 14, Proposition 12 (`prop:continuum-stability`): the quartic
characteristic polynomial and its strict Hurwitz determinants throughout the
parameter family.  The implemented four-state semigroup is not identified
with a polynomial merely by these coefficient calculations.
-/

namespace Article14.FamilyStability

noncomputable def gamma (f i : ℝ) : ℝ := 1 + f / i
noncomputable def marginC (f i d : ℝ) : ℝ := d - f ^ 2 / i
noncomputable def coeff4 (f T : ℝ) : ℝ := f * T ^ 2
noncomputable def coeff3 (f T v : ℝ) : ℝ := T ^ 2 + v * f
noncomputable def coeff2 (f d k v : ℝ) : ℝ := v + f + k * (f + d)
noncomputable def coeff1 (f i k : ℝ) : ℝ := 1 + k * gamma f i
noncomputable def coeff0 (i k : ℝ) : ℝ := k / i
noncomputable def hurwitz2 (a4 a3 a2 a1 : ℝ) : ℝ := a3 * a2 - a4 * a1
noncomputable def hurwitz3 (a4 a3 a2 a1 a0 : ℝ) : ℝ :=
  a3 * a2 * a1 - a4 * a1 ^ 2 - a3 ^ 2 * a0

-- @paper-step prop:continuum-stability/second-determinant-expansion
theorem hurwitz2_expansion (f i d k T v : ℝ) :
    hurwitz2 (coeff4 f T) (coeff3 f T v) (coeff2 f d k v) (coeff1 f i k) =
      T ^ 2 * (v + k * marginC f i d) + v * f * (v + f + k * (f + d)) := by
  unfold hurwitz2 coeff4 coeff3 coeff2 coeff1 gamma marginC
  ring

-- @paper-step prop:continuum-stability/third-determinant-expansion
theorem hurwitz3_expansion (f i d k T v : ℝ) :
    hurwitz3 (coeff4 f T) (coeff3 f T v) (coeff2 f d k v)
      (coeff1 f i k) (coeff0 i k) =
      f * (1 + k) * v ^ 2 +
      (T ^ 2 * (1 + k * (1 - f / i)) +
        f * (f + k * (f + d)) * (1 + k * gamma f i)) * v +
      k * T ^ 2 * (marginC f i d * (1 + k * gamma f i) - T ^ 2 / i) := by
  unfold hurwitz3 coeff4 coeff3 coeff2 coeff1 coeff0 gamma marginC
  ring

-- @paper-step prop:continuum-stability/positive-coefficients
theorem coefficients_pos (f i d k T v : ℝ)
    (hf : 0 < f) (hi : 0 < i) (hd : 0 < d) (hk : 0 < k)
    (hT : 0 < T) (hv : 0 ≤ v) :
    0 < coeff4 f T ∧ 0 < coeff3 f T v ∧ 0 < coeff2 f d k v ∧
      0 < coeff1 f i k ∧ 0 < coeff0 i k := by
  dsimp [coeff4, coeff3, coeff2, coeff1, coeff0, gamma]
  have hTT : 0 < T ^ 2 := sq_pos_of_pos hT
  have hfi : 0 < f / i := div_pos hf hi
  constructor
  · positivity
  constructor
  · positivity
  constructor
  · positivity
  constructor <;> positivity

-- @paper-step prop:continuum-stability/strict-second-determinant
theorem family_hurwitz2_pos (f i d k T v : ℝ)
    (hf : 0 < f) (hd : 0 < d) (hk : 0 < k) (hT : 0 < T)
    (hv : 0 ≤ v) (hC : 0 < marginC f i d) :
    0 < hurwitz2 (coeff4 f T) (coeff3 f T v) (coeff2 f d k v) (coeff1 f i k) := by
  rw [hurwitz2_expansion]
  have hTT : 0 < T ^ 2 := sq_pos_of_pos hT
  have hfirst : 0 < T ^ 2 * (v + k * marginC f i d) := by positivity
  have hsecond : 0 ≤ v * f * (v + f + k * (f + d)) := by positivity
  exact add_pos_of_pos_of_nonneg hfirst hsecond

-- @paper-step prop:continuum-stability/whole-family-margin
theorem family_margin_pos (f i d k kmin T Tmax : ℝ)
    (hf : 0 < f) (hi : 0 < i) (hC : 0 < marginC f i d)
    (hk : kmin ≤ k) (hT : 0 < T) (hTmax : T ≤ Tmax)
    (hbound : Tmax ^ 2 < i * marginC f i d * (1 + kmin * gamma f i)) :
    0 < marginC f i d * (1 + k * gamma f i) - T ^ 2 / i := by
  have hgamma : 0 < gamma f i := by dsimp [gamma]; positivity
  have hTmax0 : 0 ≤ Tmax := le_trans hT.le hTmax
  have hsq : T ^ 2 ≤ Tmax ^ 2 := sq_le_sq₀ hT.le hTmax0 |>.2 hTmax
  have hkmon : 1 + kmin * gamma f i ≤ 1 + k * gamma f i :=
    by linarith [mul_le_mul_of_nonneg_right hk hgamma.le]
  have hright := mul_le_mul_of_nonneg_left hkmon (mul_pos hi hC).le
  have hstrict : T ^ 2 < i * (marginC f i d * (1 + k * gamma f i)) := by
    nlinarith [lt_of_le_of_lt hsq hbound]
  have hdiv : T ^ 2 / i < marginC f i d * (1 + k * gamma f i) :=
    (div_lt_iff₀ hi).2 (by nlinarith [hstrict])
  linarith

-- @paper-step prop:continuum-stability/strict-third-determinant
theorem family_hurwitz3_pos (f i d k kmin T Tmax v : ℝ)
    (hf : 0 < f) (hi : 0 < i) (hd : 0 < d) (hkmin : 0 < kmin)
    (hfi : f ≤ i) (hC : 0 < marginC f i d) (hk : kmin ≤ k)
    (hT : 0 < T) (hTmax : T ≤ Tmax) (hv : 0 ≤ v)
    (hbound : Tmax ^ 2 < i * marginC f i d * (1 + kmin * gamma f i)) :
    0 < hurwitz3 (coeff4 f T) (coeff3 f T v) (coeff2 f d k v)
      (coeff1 f i k) (coeff0 i k) := by
  rw [hurwitz3_expansion]
  have hk0 : 0 < k := lt_of_lt_of_le hkmin hk
  have hTT : 0 < T ^ 2 := sq_pos_of_pos hT
  have hgamma : 0 < gamma f i := by dsimp [gamma]; positivity
  have hfi' : 0 ≤ 1 - f / i := by
    have : f / i ≤ 1 := (div_le_one hi).2 hfi
    linarith
  have hmargin := family_margin_pos f i d k kmin T Tmax hf hi hC hk hT hTmax hbound
  have hfirst : 0 ≤ f * (1 + k) * v ^ 2 := by positivity
  have hsecond : 0 ≤ (T ^ 2 * (1 + k * (1 - f / i)) +
      f * (f + k * (f + d)) * (1 + k * gamma f i)) * v := by positivity
  have hlast : 0 < k * T ^ 2 * (marginC f i d * (1 + k * gamma f i) - T ^ 2 / i) :=
    mul_pos (mul_pos hk0 hTT) hmargin
  linarith

-- @paper-step prop:continuum-stability/benchmark-exact-margin
theorem benchmark_exact_margin :
    marginC (6 / 5) 10 5 = (607 / 125 : ℝ) ∧
    gamma (6 / 5) 10 = (28 / 25 : ℝ) ∧
    (10 : ℝ) * marginC (6 / 5) 10 5 * (1 + (16 / 5) * gamma (6 / 5) 10) -
      12 ^ 2 = 245622 / 3125 ∧
    (12 : ℝ) ^ 2 < 10 * marginC (6 / 5) 10 5 * (1 + (16 / 5) * gamma (6 / 5) 10) := by
  norm_num [marginC, gamma]

-- The following argument proves the root statement directly.  It is an
-- alternative to invoking the paper's cited quartic Routh--Hurwitz criterion.
noncomputable def quarticEval (a b c d e : ℝ) (z : ℂ) : ℂ :=
  a * z ^ 4 + b * z ^ 3 + c * z ^ 2 + d * z + e

noncomputable def shifted3 (a b x : ℝ) : ℝ := 4 * a * x + b
noncomputable def shifted2 (a b c x : ℝ) : ℝ := 6 * a * x ^ 2 + 3 * b * x + c
noncomputable def shifted1 (a b c d x : ℝ) : ℝ :=
  4 * a * x ^ 3 + 3 * b * x ^ 2 + 2 * c * x + d
noncomputable def shifted0 (a b c d e x : ℝ) : ℝ :=
  a * x ^ 4 + b * x ^ 3 + c * x ^ 2 + d * x + e

-- @paper-step prop:continuum-stability/direct-quartic-root-criterion
theorem auxiliary_discriminant_pos (a b c d e : ℝ)
    (ha : 0 < a) (hb : 0 < b) (hd : 0 < d)
    (hH : 0 < hurwitz3 a b c d e) :
    0 < c ^ 2 + b * d - 4 * a * e := by
  have hident : b ^ 2 * (c ^ 2 + b * d - 4 * a * e) =
      (b * c - 2 * a * d) ^ 2 + b ^ 3 * d + 4 * a * hurwitz3 a b c d e := by
    unfold hurwitz3
    ring
  have hprod : 0 < b ^ 2 * (c ^ 2 + b * d - 4 * a * e) := by
    rw [hident]
    positivity
  exact (mul_pos_iff.mp hprod).elim (fun h => h.2) (fun h => False.elim (by nlinarith [sq_nonneg b]))

theorem shifted_hurwitz3_expansion (a b c d e x : ℝ) :
    hurwitz3 a (shifted3 a b x) (shifted2 a b c x)
      (shifted1 a b c d x) (shifted0 a b c d e x) =
    hurwitz3 a b c d e +
      2 * b * (c ^ 2 + b * d - 4 * a * e) * x +
      4 * (a * (c ^ 2 + b * d - 4 * a * e) + 2 * b ^ 2 * c) * x ^ 2 +
      8 * b * (4 * a * c + b ^ 2) * x ^ 3 +
      16 * a * (2 * a * c + 3 * b ^ 2) * x ^ 4 +
      96 * a ^ 2 * b * x ^ 5 + 64 * a ^ 3 * x ^ 6 := by
  unfold hurwitz3 shifted3 shifted2 shifted1 shifted0
  ring

theorem shifted_hurwitz3_pos (a b c d e x : ℝ)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (hd : 0 < d)
    (hx : 0 ≤ x) (hH : 0 < hurwitz3 a b c d e) :
    0 < hurwitz3 a (shifted3 a b x) (shifted2 a b c x)
      (shifted1 a b c d x) (shifted0 a b c d e x) := by
  rw [shifted_hurwitz3_expansion]
  have hdelta := auxiliary_discriminant_pos a b c d e ha hb hd hH
  positivity

theorem quartic_re_eq_shifted (a b c d e : ℝ) (z : ℂ) :
    (quarticEval a b c d e z).re =
      shifted0 a b c d e z.re - shifted2 a b c z.re * z.im ^ 2 + a * z.im ^ 4 := by
  simp only [quarticEval, shifted0, shifted2, pow_succ, pow_zero,
    Complex.add_re, Complex.mul_re, Complex.mul_im, Complex.ofReal_re,
    Complex.ofReal_im, Complex.one_re, Complex.one_im]
  ring

theorem quartic_im_eq_shifted (a b c d e : ℝ) (z : ℂ) :
    (quarticEval a b c d e z).im =
      z.im * (shifted1 a b c d z.re - shifted3 a b z.re * z.im ^ 2) := by
  simp only [quarticEval, shifted1, shifted3, pow_succ, pow_zero,
    Complex.add_im, Complex.mul_re, Complex.mul_im, Complex.ofReal_re,
    Complex.ofReal_im, Complex.one_re, Complex.one_im]
  ring

theorem hurwitz3_zero_of_imaginary_root (a b c d e y : ℝ)
    (hr : e - c * y ^ 2 + a * y ^ 4 = 0)
    (hi : d - b * y ^ 2 = 0) : hurwitz3 a b c d e = 0 := by
  unfold hurwitz3
  linear_combination -b ^ 2 * hr + (b * c - a * (d + b * y ^ 2)) * hi

-- @paper-step prop:continuum-stability/all-quartic-roots-strict-left-halfplane
theorem quartic_root_re_neg (a b c d e : ℝ)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (hd : 0 < d) (he : 0 < e)
    (hH : 0 < hurwitz3 a b c d e) (z : ℂ) (hz : quarticEval a b c d e z = 0) :
    z.re < 0 := by
  by_contra hneg
  have hx : 0 ≤ z.re := le_of_not_gt hneg
  have hr : shifted0 a b c d e z.re - shifted2 a b c z.re * z.im ^ 2 + a * z.im ^ 4 = 0 := by
    rw [← quartic_re_eq_shifted, hz]
    rfl
  have hi : z.im * (shifted1 a b c d z.re - shifted3 a b z.re * z.im ^ 2) = 0 := by
    rw [← quartic_im_eq_shifted, hz]
    rfl
  by_cases hy : z.im = 0
  · have hzero : shifted0 a b c d e z.re = 0 := by simpa [hy] using hr
    have hpositive : 0 < shifted0 a b c d e z.re := by
      unfold shifted0
      positivity
    linarith
  · have hi' := (mul_eq_zero.mp hi).resolve_left hy
    have hzero := hurwitz3_zero_of_imaginary_root a (shifted3 a b z.re)
      (shifted2 a b c z.re) (shifted1 a b c d z.re) (shifted0 a b c d e z.re)
      z.im hr hi'
    have hpositive := shifted_hurwitz3_pos a b c d e z.re ha hb hc hd hx hH
    linarith

-- @paper-step prop:continuum-stability/family-polynomial-Hurwitz
theorem family_quartic_root_re_neg (f i d k kmin T Tmax v : ℝ)
    (hf : 0 < f) (hi : 0 < i) (hd : 0 < d) (hkmin : 0 < kmin)
    (hfi : f ≤ i) (hC : 0 < marginC f i d) (hk : kmin ≤ k)
    (hT : 0 < T) (hTmax : T ≤ Tmax) (hv : 0 ≤ v)
    (hbound : Tmax ^ 2 < i * marginC f i d * (1 + kmin * gamma f i))
    (z : ℂ) (hz : quarticEval (coeff4 f T) (coeff3 f T v) (coeff2 f d k v)
      (coeff1 f i k) (coeff0 i k) z = 0) : z.re < 0 := by
  obtain ⟨h4,h3,h2,h1,h0⟩ := coefficients_pos f i d k T v hf hi hd
    (lt_of_lt_of_le hkmin hk) hT hv
  exact quartic_root_re_neg _ _ _ _ _ h4 h3 h2 h1 h0
    (family_hurwitz3_pos f i d k kmin T Tmax v hf hi hd hkmin hfi hC hk hT hTmax hv hbound) z hz

-- @paper-step prop:continuum-stability/characteristic-polynomial-expansion
theorem characteristic_expression (f i d k T v : ℝ) (hi : i ≠ 0) (z : ℂ) :
    (((T : ℂ) ^ 2 * z ^ 2 + (v : ℂ) * z + 1) *
       (i : ℂ) * z * (1 + (f : ℂ) * z) +
      (k : ℂ) * (1 + ((i : ℂ) + f) * z + (i : ℂ) * ((f : ℂ) + d) * z ^ 2)) /
        (i : ℂ) =
    quarticEval (coeff4 f T) (coeff3 f T v) (coeff2 f d k v)
      (coeff1 f i k) (coeff0 i k) z := by
  have hiC : (i : ℂ) ≠ 0 := by exact_mod_cast hi
  simp only [quarticEval, coeff4, coeff3, coeff2, coeff1, coeff0, gamma,
    Complex.ofReal_add, Complex.ofReal_mul, Complex.ofReal_div,
    Complex.ofReal_pow, Complex.ofReal_one]
  field_simp [hiC]
  ring

-- @paper-step prop:continuum-stability/benchmark-full-continuum-root-bound
theorem benchmark_family_root_re_neg (k T v : ℝ)
    (hk : (16 / 5 : ℝ) ≤ k) (hT : 0 < T) (hTmax : T ≤ 12) (hv : 0 ≤ v)
    (z : ℂ) (hz : quarticEval (coeff4 (6 / 5) T) (coeff3 (6 / 5) T v)
      (coeff2 (6 / 5) 5 k v) (coeff1 (6 / 5) 10 k) (coeff0 10 k) z = 0) :
    z.re < 0 := by
  apply family_quartic_root_re_neg (6 / 5) 10 5 k (16 / 5) T 12 v
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
    (by norm_num [marginC]) hk hT hTmax hv
    (by norm_num [marginC, gamma]) z hz

end Article14.FamilyStability


