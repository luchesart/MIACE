import Article14.MIACEBridge
import Article14.TrackingMoments
import Article14.FeasibleGeometry

/-!
# Article 14: exact MIACE projection within a positive-command family

The scalar projection is proved from real inequalities.  Its signal-level
application uses actual integrable signals, the local plant relation proved in
`MIACEBridge`, positivity of BOTH signals, and the tracking-area identity.
The existence and interval shape of the feasible projection are exposed
explicitly; they are not encoded as a pre-assumed optimum.
-/
namespace Article14
open MeasureTheory Filter Set MIACE
open scoped Topology

noncomputable def clampedWeight (lo hi target : ℝ) : ℝ :=
  min hi (max lo target)

noncomputable def trackingMean (k Kp Ti b : ℝ) : ℝ :=
  Ti * (1 + 1 / (k * Kp) - b)

noncomputable def miaceTarget (k Kp Ti Γ α : ℝ) : ℝ :=
  1 + 1 / (k * Kp) - α * Γ / ((1 + α) * Ti)

noncomputable def positiveCommandCostSq (k Kp Ti Γ α b : ℝ) : ℝ :=
  (trackingMean k Kp Ti b) ^ 2 + α * (Γ - trackingMean k Kp Ti b) ^ 2

-- Article 14, Theorem 17: clipping really lands in the feasible interval.
theorem clampedWeight_mem {lo hi : ℝ} (h : lo ≤ hi) (target : ℝ) :
    clampedWeight lo hi target ∈ Icc lo hi := by
  constructor
  · exact le_min h (le_max_left _ _)
  · exact min_le_left _ _

-- Article 14, Theorem 17: the clamp has the least squared distance to the
-- desired weight among every point of the interval, including both endpoints.
theorem clampedWeight_nearest {lo hi target b : ℝ} (hb : b ∈ Icc lo hi) :
    (clampedWeight lo hi target - target) ^ 2 ≤ (b - target) ^ 2 := by
  by_cases hlo : target ≤ lo
  · have hhi : lo ≤ hi := hb.1.trans hb.2
    rw [clampedWeight, max_eq_left hlo, min_eq_right hhi]
    exact (sq_le_sq₀ (sub_nonneg.mpr hlo)
      (sub_nonneg.mpr (hlo.trans hb.1))).mpr (sub_le_sub_right hb.1 target)
  · by_cases hhi : hi ≤ target
    · have hlo' : lo ≤ target := (hb.1.trans hb.2).trans hhi
      rw [clampedWeight, max_eq_right hlo', min_eq_left hhi]
      have hi' : 0 ≤ target - hi := sub_nonneg.mpr hhi
      have hb' : 0 ≤ target - b := sub_nonneg.mpr (hb.2.trans hhi)
      have hs := (sq_le_sq₀ hi' hb').mpr (sub_le_sub_left hb.2 target)
      nlinarith
    · have hlo' : lo ≤ target := (lt_of_not_ge hlo).le
      have hhi' : target ≤ hi := (lt_of_not_ge hhi).le
      rw [clampedWeight, max_eq_right hlo', min_eq_right hhi']
      simp only [sub_self, zero_pow (by decide : 2 ≠ 0)]
      exact sq_nonneg _

-- Article 14, Theorem 17: the target is unchanged exactly when feasible.
theorem clampedWeight_eq_self_iff {lo hi target : ℝ} (h : lo ≤ hi) :
    clampedWeight lo hi target = target ↔ target ∈ Icc lo hi := by
  constructor
  · intro heq
    rw [← heq]
    exact clampedWeight_mem h target
  · intro ht
    rw [clampedWeight, max_eq_right ht.1, min_eq_right ht.2]

-- Article 14, Theorem 17: complete the square in b, retaining the exact
-- fixed-feedback tracking mean rather than introducing a new area variable.
theorem positiveCommandCostSq_completion (k Kp Ti Γ α b : ℝ)
    (hTi : 0 < Ti) (hα : 0 < α) :
    positiveCommandCostSq k Kp Ti Γ α b =
      α * Γ ^ 2 / (1 + α) +
        (1 + α) * Ti ^ 2 * (b - miaceTarget k Kp Ti Γ α) ^ 2 := by
  have h1 : 1 + α ≠ 0 := ne_of_gt (by linarith)
  unfold positiveCommandCostSq trackingMean miaceTarget
  field_simp [hTi.ne', h1]
  ring

-- Article 14, Theorem 17: the exact scalar constrained minimum.
theorem positiveCommandCostSq_projection (k Kp Ti Γ α lo hi b : ℝ)
    (hTi : 0 < Ti) (hα : 0 < α) (hb : b ∈ Icc lo hi) :
    positiveCommandCostSq k Kp Ti Γ α
        (clampedWeight lo hi (miaceTarget k Kp Ti Γ α)) ≤
      positiveCommandCostSq k Kp Ti Γ α b := by
  rw [positiveCommandCostSq_completion k Kp Ti Γ α _ hTi hα,
    positiveCommandCostSq_completion k Kp Ti Γ α _ hTi hα]
  have hc : 0 ≤ (1 + α) * Ti ^ 2 :=
    mul_nonneg (by linarith) (sq_nonneg Ti)
  have hm := mul_le_mul_of_nonneg_left
    (clampedWeight_nearest (target := miaceTarget k Kp Ti Γ α) hb) hc
  linarith

-- Article 14, Theorem 17: equality in the universal squared bound identifies
-- one b value, even though more than one feasible c may lie above it.
theorem positiveCommandCostSq_eq_bound_iff (k Kp Ti Γ α b : ℝ)
    (hTi : 0 < Ti) (hα : 0 < α) :
    positiveCommandCostSq k Kp Ti Γ α b = α * Γ ^ 2 / (1 + α) ↔
      b = miaceTarget k Kp Ti Γ α := by
  rw [positiveCommandCostSq_completion k Kp Ti Γ α b hTi hα]
  have hc : 0 < (1 + α) * Ti ^ 2 := mul_pos (by linarith) (sq_pos_of_pos hTi)
  constructor
  · intro h
    have hz : (b - miaceTarget k Kp Ti Γ α) ^ 2 = 0 :=
      (mul_eq_zero.mp (by linarith : (1 + α) * Ti ^ 2 *
        (b - miaceTarget k Kp Ti Γ α) ^ 2 = 0)).resolve_left hc.ne'
    exact sub_eq_zero.mp (sq_eq_zero_iff.mp hz)
  · intro h
    simp [h]

-- Article 14, Theorem 17: the universal squared bound is attainable on an
-- interval exactly when the desired (unclipped) weight belongs to it.
theorem positiveCommandCostSq_attainable_iff (k Kp Ti Γ α lo hi : ℝ)
    (hTi : 0 < Ti) (hα : 0 < α) :
    (∃ b ∈ Icc lo hi,
      positiveCommandCostSq k Kp Ti Γ α b = α * Γ ^ 2 / (1 + α)) ↔
        miaceTarget k Kp Ti Γ α ∈ Icc lo hi := by
  constructor
  · rintro ⟨b, hb, heq⟩
    rwa [(positiveCommandCostSq_eq_bound_iff k Kp Ti Γ α b hTi hα).mp heq] at hb
  · intro ht
    exact ⟨_, ht, (positiveCommandCostSq_eq_bound_iff k Kp Ti Γ α _ hTi hα).mpr rfl⟩

-- Article 14, Theorem 17: reduction of ACTUAL signal integrals to the scalar
-- cost.  The signed command area follows from the local transfer theorem;
-- no command-area formula or quadratic cost is postulated.
theorem nonnegative_signal_cost_reduction {e v H : ℝ → ℝ} {δ : ℝ}
    (h : LocalTransferResponse e v H δ) (k Kp Ti b μ α : ℝ)
    (hα : 0 < α) (hH : HasDerivAt H (-μ) 0) (h0 : H 0 = 1)
    (he : ∀ᵐ t ∂halfLine, 0 ≤ e t) (hv : ∀ᵐ t ∂halfLine, 0 ≤ v t)
    (hm : (∫ t, e t ∂halfLine) = trackingMean k Kp Ti b) :
    (miace α e v halfLine) ^ 2 = positiveCommandCostSq k Kp Ti (μ + δ) α b := by
  have hb := local_transfer_signed_balance h μ hH h0
  have hae : absArea e halfLine = trackingMean k Kp Ti b := by
    rw [absolute_area_identity h.error_integrable,
      (negative_area_zero_iff h.error_integrable).mpr he, hm]
    ring
  have hav : absArea v halfLine = μ + δ - trackingMean k Kp Ti b := by
    rw [absolute_area_identity h.command_integrable,
      (negative_area_zero_iff h.command_integrable).mpr hv]
    linarith
  rw [miace_square α e v halfLine hα, hae, hav]
  rfl

/-- An explicit interface to the monotone, nonnegative-command part of the
fixed-feedback family.  In particular, the error-area identity is a separate
Article 14, Theorem 14 obligation, while the command area is derived below. -/
structure PositiveMIACEFamily (F : Set (ℝ × ℝ))
    (e v : (ℝ × ℝ) → ℝ → ℝ) (H : ℝ → ℝ) (δ k Kp Ti : ℝ) : Prop where
  response : ∀ w ∈ F, LocalTransferResponse (e w) (v w) H δ
  error_nonnegative : ∀ w ∈ F, ∀ᵐ t ∂halfLine, 0 ≤ e w t
  command_nonnegative : ∀ w ∈ F, ∀ᵐ t ∂halfLine, 0 ≤ v w t
  error_area : ∀ w ∈ F, (∫ t, e w t ∂halfLine) = trackingMean k Kp Ti w.1

-- Article 14, Theorems 14 and 17: the family interface follows from its
-- ACTUAL two local transfer relations.  In particular, the mean-area formula
-- is proved by dominated convergence rather than assumed in this constructor.
theorem positiveMIACEFamily_of_local_transfers {F : Set (ℝ × ℝ)}
    {e v : (ℝ × ℝ) → ℝ → ℝ} {H Q : ℝ → ℝ} {δ k Kp Ti Kd Tf : ℝ}
    (hk : k ≠ 0) (hKp : Kp ≠ 0) (hTi : Ti ≠ 0)
    (hQ : ContinuousAt Q 0) (hQ0 : Q 0 = 1 / k)
    (hresponse : ∀ w ∈ F, LocalTransferResponse (e w) (v w) H δ)
    (he : ∀ w ∈ F, ∀ᵐ t ∂halfLine, 0 ≤ e w t)
    (hv : ∀ w ∈ F, ∀ᵐ t ∂halfLine, 0 ≤ v w t)
    (herror : ∀ w ∈ F, laplace (e w) =ᶠ[𝓝[>] (0 : ℝ)]
      clearedError Q Kp (Kp / Ti) Kd Tf w.1 w.2) :
    PositiveMIACEFamily F e v H δ k Kp Ti := by
  refine ⟨hresponse, he, hv, ?_⟩
  intro w hw
  rw [tracking_error_integral (hresponse w hw).error_integrable
    Kp (Kp / Ti) Kd Tf w.1 w.2 k hQ hQ0 (div_ne_zero hKp hTi) (herror w hw)]
  unfold trackingMean
  field_simp
  ring

-- Article 14, Theorem 17: the reduction is independent of c for each
-- genuinely feasible pair; c still determines feasibility of the signals.
theorem positive_family_cost_reduction {F : Set (ℝ × ℝ)}
    {e v : (ℝ × ℝ) → ℝ → ℝ} {H : ℝ → ℝ} {δ k Kp Ti : ℝ}
    (h : PositiveMIACEFamily F e v H δ k Kp Ti) (μ α : ℝ)
    (hα : 0 < α) (hH : HasDerivAt H (-μ) 0) (h0 : H 0 = 1)
    {w : ℝ × ℝ} (hw : w ∈ F) :
    (miace α (e w) (v w) halfLine) ^ 2 =
      positiveCommandCostSq k Kp Ti (μ + δ) α w.1 :=
  nonnegative_signal_cost_reduction (h.response w hw) k Kp Ti w.1 μ α hα hH h0
    (h.error_nonnegative w hw) (h.command_nonnegative w hw) (h.error_area w hw)

-- Article 14, Theorem 17: every feasible c above the clipped b attains
-- the constrained minimum of the actual square-root MIACE signal functional.
theorem positive_family_miace_projection {F : Set (ℝ × ℝ)}
    {e v : (ℝ × ℝ) → ℝ → ℝ} {H : ℝ → ℝ} {δ k Kp Ti : ℝ}
    (h : PositiveMIACEFamily F e v H δ k Kp Ti) (μ α lo hi : ℝ)
    (hTi : 0 < Ti) (hα : 0 < α) (hH : HasDerivAt H (-μ) 0) (h0 : H 0 = 1)
    (hinterval : ∀ w ∈ F, w.1 ∈ Icc lo hi)
    {wstar : ℝ × ℝ} (hwstar : wstar ∈ F)
    (hb : wstar.1 = clampedWeight lo hi (miaceTarget k Kp Ti (μ + δ) α))
    {w : ℝ × ℝ} (hw : w ∈ F) :
    miace α (e wstar) (v wstar) halfLine ≤ miace α (e w) (v w) halfLine := by
  apply (sq_le_sq₀ (Real.sqrt_nonneg _) (Real.sqrt_nonneg _)).mp
  change (miace α (e wstar) (v wstar) halfLine) ^ 2 ≤
    (miace α (e w) (v w) halfLine) ^ 2
  rw [positive_family_cost_reduction h μ α hα hH h0 hwstar,
    positive_family_cost_reduction h μ α hα hH h0 hw, hb]
  exact positiveCommandCostSq_projection k Kp Ti (μ + δ) α lo hi w.1
    hTi hα (hinterval w hw)

-- Article 14, Theorem 17: once compact-convex feasibility has supplied its
-- exact interval projection, that projection contains a true MIACE minimizer.
theorem positive_family_miace_minimizer_exists {F : Set (ℝ × ℝ)}
    {e v : (ℝ × ℝ) → ℝ → ℝ} {H : ℝ → ℝ} {δ k Kp Ti : ℝ}
    (h : PositiveMIACEFamily F e v H δ k Kp Ti) (μ α lo hi : ℝ)
    (hTi : 0 < Ti) (hα : 0 < α) (hH : HasDerivAt H (-μ) 0) (h0 : H 0 = 1)
    (hlohi : lo ≤ hi)
    (hprojection : ∀ b, (∃ c, (b, c) ∈ F) ↔ b ∈ Icc lo hi) :
    ∃ c, (clampedWeight lo hi (miaceTarget k Kp Ti (μ + δ) α), c) ∈ F ∧
      ∀ w ∈ F,
        miace α (e (clampedWeight lo hi (miaceTarget k Kp Ti (μ + δ) α), c))
          (v (clampedWeight lo hi (miaceTarget k Kp Ti (μ + δ) α), c)) halfLine ≤
            miace α (e w) (v w) halfLine := by
  obtain ⟨c, hc⟩ := (hprojection _).mpr
    (clampedWeight_mem hlohi (miaceTarget k Kp Ti (μ + δ) α))
  refine ⟨c, hc, ?_⟩
  intro w hw
  exact positive_family_miace_projection h μ α lo hi hTi hα hH h0
    (fun w hw => (hprojection w.1).mp ⟨w.2, hw⟩) hc rfl hw

-- Article 14, Theorem 17: exact attainability of the universal MIACE bound
-- in the actual signal family is equivalent to feasibility of the target b.
theorem positive_family_bound_attainable_iff {F : Set (ℝ × ℝ)}
    {e v : (ℝ × ℝ) → ℝ → ℝ} {H : ℝ → ℝ} {δ k Kp Ti : ℝ}
    (h : PositiveMIACEFamily F e v H δ k Kp Ti) (μ α lo hi : ℝ)
    (hTi : 0 < Ti) (hα : 0 < α) (hΓ : 0 ≤ μ + δ)
    (hH : HasDerivAt H (-μ) 0) (h0 : H 0 = 1)
    (hprojection : ∀ b, (∃ c, (b, c) ∈ F) ↔ b ∈ Icc lo hi) :
    (∃ w ∈ F, miace α (e w) (v w) halfLine =
      (μ + δ) * Real.sqrt (α / (1 + α))) ↔
        miaceTarget k Kp Ti (μ + δ) α ∈ Icc lo hi := by
  have hratio : 0 ≤ α / (1 + α) := div_nonneg hα.le (by linarith)
  constructor
  · rintro ⟨w, hw, heq⟩
    have hs : positiveCommandCostSq k Kp Ti (μ + δ) α w.1 =
        α * (μ + δ) ^ 2 / (1 + α) := by
      rw [← positive_family_cost_reduction h μ α hα hH h0 hw, heq,
        mul_pow, Real.sq_sqrt hratio]
      ring
    have htarget := (positiveCommandCostSq_eq_bound_iff k Kp Ti (μ + δ) α w.1
      hTi hα).mp hs
    have hb : w.1 ∈ Icc lo hi := (hprojection w.1).mp ⟨w.2, hw⟩
    rwa [htarget] at hb
  · intro hb
    obtain ⟨c, hc⟩ := (hprojection _).mpr hb
    refine ⟨(miaceTarget k Kp Ti (μ + δ) α, c), hc, ?_⟩
    apply (sq_eq_sq₀ (Real.sqrt_nonneg _)
      (mul_nonneg hΓ (Real.sqrt_nonneg _))).mp
    change (miace α (e (miaceTarget k Kp Ti (μ + δ) α, c))
      (v (miaceTarget k Kp Ti (μ + δ) α, c)) halfLine) ^ 2 = _
    rw [positive_family_cost_reduction h μ α hα hH h0 hc]
    have hs := (positiveCommandCostSq_eq_bound_iff k Kp Ti (μ + δ) α
      (miaceTarget k Kp Ti (μ + δ) α) hTi hα).mpr rfl
    rw [hs, mul_pow, Real.sq_sqrt hratio]
    ring

-- Article 14, Theorem 17: compactness, convexity and nonemptiness now DERIVE
-- the interval projection used by the optimizer.  No endpoints or interval
-- representation are assumed by this assembled signal-level theorem.
theorem positive_family_compact_convex_reduction {F : Set (ℝ × ℝ)}
    {e v : (ℝ × ℝ) → ℝ → ℝ} {H : ℝ → ℝ} {δ k Kp Ti : ℝ}
    (h : PositiveMIACEFamily F e v H δ k Kp Ti) (μ α : ℝ)
    (hTi : 0 < Ti) (hα : 0 < α) (hΓ : 0 ≤ μ + δ)
    (hH : HasDerivAt H (-μ) 0) (h0 : H 0 = 1)
    (hF : IsCompact F) (hconv : Convex ℝ F) (hne : F.Nonempty) :
    ∃ lo hi : ℝ, lo ≤ hi ∧
      (∀ b, (∃ c, (b, c) ∈ F) ↔ b ∈ Icc lo hi) ∧
      (∃ c, (clampedWeight lo hi (miaceTarget k Kp Ti (μ + δ) α), c) ∈ F ∧
        ∀ w ∈ F,
          miace α (e (clampedWeight lo hi (miaceTarget k Kp Ti (μ + δ) α), c))
            (v (clampedWeight lo hi (miaceTarget k Kp Ti (μ + δ) α), c)) halfLine ≤
              miace α (e w) (v w) halfLine) ∧
      ((∃ w ∈ F, miace α (e w) (v w) halfLine =
        (μ + δ) * Real.sqrt (α / (1 + α))) ↔
          miaceTarget k Kp Ti (μ + δ) α ∈ Icc lo hi) := by
  obtain ⟨lo, hi, hlohi, himage⟩ := compact_convex_projection_interval hF hconv hne
  have hprojection (b : ℝ) : (∃ c, (b, c) ∈ F) ↔ b ∈ Icc lo hi := by
    rw [← himage]
    constructor
    · rintro ⟨c, hc⟩
      exact ⟨(b, c), hc, rfl⟩
    · rintro ⟨w, hw, hwb⟩
      refine ⟨w.2, ?_⟩
      simpa only [← hwb] using hw
  exact ⟨lo, hi, hlohi, hprojection,
    positive_family_miace_minimizer_exists h μ α lo hi hTi hα hH h0 hlohi hprojection,
    positive_family_bound_attainable_iff h μ α lo hi hTi hα hΓ hH h0 hprojection⟩

end Article14
