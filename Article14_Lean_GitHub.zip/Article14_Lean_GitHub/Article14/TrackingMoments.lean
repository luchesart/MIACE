import MIACE.Transfer
import MIACE.HalfPlaneLaplace

/-!
Article 14, Theorems 14 and 17, and Proposition 15: exact DC and first
derivative of the cleared step-error transfer, and the actual integral
tracking error obtained by the inherited dominated-convergence theorem.
Q is the inverse delayed plant near DC. No expansion in informal O(s) is used.
-/
namespace Article14
open MeasureTheory Filter Set MIACE
open scoped Topology

noncomputable def meanTime (Ti k Kp b : ℝ) : ℝ :=
  Ti * (1 - b + 1 / (k * Kp))

noncomputable def clearedError (Q : ℝ → ℝ) (Kp Ki Kd Tf b c : ℝ) (s : ℝ) : ℝ :=
  (Q s + (1 - b) * Kp + (1 - c) * Kd * s / (1 + Tf * s)) /
    (Ki + s * (Q s + Kp + Kd * s / (1 + Tf * s)))

noncomputable def secondErrorMoment (Kp Ki Kd k Γ m c : ℝ) : ℝ :=
  ((Kp + 1 / k) * m - (1 - c) * Kd - Γ / k) / Ki

-- @article14 thm:delay-fastest/exact_origin_value
theorem clearedError_zero (Q : ℝ → ℝ) (Kp Ki Kd Tf b c k : ℝ)
    (hQ : Q 0 = 1 / k) :
    clearedError Q Kp Ki Kd Tf b c 0 = (1 / k + (1 - b) * Kp) / Ki := by
  simp [clearedError, hQ]

-- @article14 thm:delay-fastest/mean_formula_in_PIDF_parameters
theorem clearedError_mean (Q : ℝ → ℝ) (Kp Ti Kd Tf b c k : ℝ)
    (hQ : Q 0 = 1 / k) (hk : k ≠ 0) (hp : Kp ≠ 0) :
    clearedError Q Kp (Kp / Ti) Kd Tf b c 0 = meanTime Ti k Kp b := by
  rw [clearedError_zero Q Kp (Kp / Ti) Kd Tf b c k hQ]
  unfold meanTime
  field_simp
  <;> ring

-- @article14 prop:delay-second-moment/exact_derivative_at_origin
theorem clearedError_derivative {Q : ℝ → ℝ} (Kp Ki Kd Tf b c k Γ : ℝ)
    (hQ : HasDerivAt Q (Γ / k) 0) (hQ0 : Q 0 = 1 / k) (hKi : Ki ≠ 0) :
    HasDerivAt (clearedError Q Kp Ki Kd Tf b c)
      (-secondErrorMoment Kp Ki Kd k Γ ((1 / k + (1 - b) * Kp) / Ki) c) 0 := by
  have hf : HasDerivAt (fun s : ℝ => s / (1 + Tf * s)) 1 0 := by
    convert (hasDerivAt_id (0 : ℝ)).div
      ((hasDerivAt_const (0 : ℝ) (1 : ℝ)).add
        ((hasDerivAt_id (0 : ℝ)).const_mul Tf)) (by norm_num) using 1
    · rfl
    · norm_num
  have hn := (hQ.add_const ((1 - b) * Kp)).add (hf.const_mul ((1 - c) * Kd))
  have hd := ((hasDerivAt_id (0 : ℝ)).mul
    ((hQ.add_const Kp).add (hf.const_mul Kd))).const_add Ki
  have hh := hn.div hd (by simpa using hKi)
  convert hh using 1
  · funext s
    dsimp only [clearedError, Pi.add_apply, Pi.mul_apply, Pi.div_apply, id_eq]
    congr 1 <;> ring
  · simp only [Pi.add_apply, Pi.mul_apply, Pi.div_apply, id_eq,
      hQ0, mul_zero, zero_mul, add_zero, zero_div, mul_one, one_mul]
    unfold secondErrorMoment
    field_simp
    <;> ring

-- @article14 thm:delay-fastest/integral_area_from_local_error_transfer
theorem tracking_error_integral {e Q : ℝ → ℝ} (he : Integrable e halfLine)
    (Kp Ki Kd Tf b c k : ℝ) (hQ : ContinuousAt Q 0) (hQ0 : Q 0 = 1 / k)
    (hKi : Ki ≠ 0)
    (htransfer : laplace e =ᶠ[𝓝[>] (0 : ℝ)] clearedError Q Kp Ki Kd Tf b c) :
    (∫ t, e t ∂halfLine) = (1 / k + (1 - b) * Kp) / Ki := by
  have hc : ContinuousAt (clearedError Q Kp Ki Kd Tf b c) 0 := by
    unfold clearedError
    fun_prop (disch := norm_num [hKi])
  have ht := hc.tendsto.mono_left
    (nhdsWithin_le_nhds : 𝓝[>] (0 : ℝ) ≤ 𝓝 0)
  have hu := tendsto_nhds_unique (laplace_tendsto_zero he) (ht.congr' htransfer.symm)
  exact hu.trans (clearedError_zero Q Kp Ki Kd Tf b c k hQ0)

-- @article14 thm:delay-fastest/absolute_error_when_no_overshoot
theorem tracking_absolute_area {e Q : ℝ → ℝ} (he : Integrable e halfLine)
    (hn : ∀ᵐ t ∂halfLine, 0 ≤ e t) (Kp Ki Kd Tf b c k : ℝ)
    (hQ : ContinuousAt Q 0) (hQ0 : Q 0 = 1 / k) (hKi : Ki ≠ 0)
    (htransfer : laplace e =ᶠ[𝓝[>] (0 : ℝ)] clearedError Q Kp Ki Kd Tf b c) :
    absArea e halfLine = (1 / k + (1 - b) * Kp) / Ki := by
  rw [absolute_area_identity he, (negative_area_zero_iff he).mpr hn,
    tracking_error_integral he Kp Ki Kd Tf b c k hQ hQ0 hKi htransfer]
  ring

-- @article14 prop:delay-second-moment/strict_secondary_objective
theorem secondErrorMoment_strictMono (Kp Ki Kd k Γ m : ℝ)
    (hKi : 0 < Ki) (hKd : 0 < Kd) :
    StrictMono (secondErrorMoment Kp Ki Kd k Γ m) := by
  intro c d hcd
  unfold secondErrorMoment
  apply (div_lt_div_iff_of_pos_right hKi).mpr
  nlinarith

-- @article14 prop:delay-second-moment/variance_bound_rearrangement
theorem variance_weight_bound (Kp Ki Kd k Γ m c : ℝ)
    (hKi : 0 < Ki) (hKd : 0 < Kd)
    (hvariance : m ^ 2 ≤ 2 * secondErrorMoment Kp Ki Kd k Γ m c) :
    1 + (Ki * m ^ 2 / 2 - (Kp + 1 / k) * m + Γ / k) / Kd ≤ c := by
  unfold secondErrorMoment at hvariance
  have h := (le_div_iff₀ hKi).mp
    (show m ^ 2 / 2 ≤ ((Kp + 1 / k) * m - (1 - c) * Kd - Γ / k) / Ki by
      linarith)
  rw [← le_sub_iff_add_le', div_le_iff₀ hKd]
  nlinarith

end Article14
