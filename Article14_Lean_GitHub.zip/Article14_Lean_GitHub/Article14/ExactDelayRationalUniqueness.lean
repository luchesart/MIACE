import Article14.ExactDelayRationalHistory

/-! Uniqueness of the complete four-state rational retarded dynamics.
The inherited finite-dimensional retarded Gronwall theorem applies to the
coordinate differences; no decay or integrability at infinity is required. -/
namespace Article14.ExactDelay
open Set MeasureTheory Filter MIACE
open scoped Topology

noncomputable def rationalCoordinateMap (j : Fin 4) : LoopState →L[ℝ] ℝ :=
  ![plantCoordinate (n := Fin 2) 0, plantCoordinate (n := Fin 2) 1,
    integralCoordinate (n := Fin 2), filterCoordinate (n := Fin 2)] j

noncomputable def clampedCoordinate (z : ℝ → LoopState) (j : Fin 4) (t : ℝ) : ℝ :=
  rationalCoordinateMap j (z (max 0 t))

theorem rational_coordinates_injective :
    Function.Injective (fun z : LoopState => fun j : Fin 4 => rationalCoordinateMap j z) := by
  intro z q he
  apply Prod.ext
  · ext j
    fin_cases j
    · exact congrFun he 0
    · exact congrFun he 1
  · exact Prod.ext (congrFun he 2) (congrFun he 3)

theorem rational_rhs_continuousOn {h z : ℝ → LoopState}
    (hz : IsRationalStateSolution h z) :
    ContinuousOn (fun t => rationalStateRhs (z t) (z (t-1/4))) (Ici 0) := by
  have hc : ContinuousOn z (Ici 0) := hz.1.mono (fun t ht => by
    change 0 ≤ t at ht; change -(1/4:ℝ) ≤ t; linarith)
  have hd : ContinuousOn (fun t => z (t-1/4)) (Ici 0) :=
    hz.1.comp (continuous_id.sub continuous_const).continuousOn
      (fun t ht => by change 0 ≤ t at ht; change -(1/4:ℝ) ≤ t-1/4; linarith)
  have hx := (continuous_apply 0).comp_continuousOn hc.fst
  have hy := (continuous_apply 1).comp_continuousOn hc.fst
  apply ContinuousOn.prodMk
  · apply continuousOn_pi.mpr
    intro j
    fin_cases j
    · exact hd.snd.fst.sub hx
    · exact hx.sub hy
  · exact (((hc.snd.fst.const_mul (-E)).add hc.snd.snd).sub hx |>.div_const a).prodMk
      ((hc.snd.fst.const_mul E).sub hc.snd.snd)

theorem clampedCoordinate_continuous {h z : ℝ → LoopState}
    (hz : IsRationalStateSolution h z) (j : Fin 4) :
    Continuous (clampedCoordinate z j) := by
  apply (rationalCoordinateMap j).continuous.comp
  apply hz.1.comp_continuous (continuous_const.max continuous_id)
  intro t
  change -(1/4:ℝ) ≤ max 0 t
  exact le_trans (by norm_num) (le_max_left _ _)

theorem clampedCoordinate_hasDerivAt {h z : ℝ → LoopState}
    (hz : IsRationalStateSolution h z) (j : Fin 4) {t : ℝ} (ht : 0 < t) :
    HasDerivAt (clampedCoordinate z j)
      (rationalCoordinateMap j (rationalStateRhs (z t) (z (t-1/4)))) t := by
  have hd := (rationalCoordinateMap j).hasFDerivAt.comp_hasDerivAt t (hz.2.2 t ht)
  apply hd.congr_of_eventuallyEq
  filter_upwards [Ioi_mem_nhds ht] with s hs
  simp [clampedCoordinate, max_eq_right (show 0 ≤ s from le_of_lt hs)]

theorem clampedCoordinate_ac {h z : ℝ → LoopState}
    (hz : IsRationalStateSolution h z) (j : Fin 4) (T : ℝ) (hT : 0 ≤ T) :
    AbsolutelyContinuousOnInterval (clampedCoordinate z j) 0 T := by
  apply absolutelyContinuousOnInterval_of_piecewise_C1 (L := 0) le_rfl hT
    (clampedCoordinate_continuous hz j).continuousOn
    (p' := fun _ => 0) continuous_const.continuousOn
  · intro t ht
    exact False.elim (not_lt_of_ge ht.1.le ht.2)
  · exact (rationalCoordinateMap j).continuous.comp_continuousOn
      (rational_rhs_continuousOn hz)
  · intro t ht
    exact clampedCoordinate_hasDerivAt hz j ht

theorem rational_difference_clamp {h z q : ℝ → LoopState}
    (hz : IsRationalStateSolution h z) (hq : IsRationalStateSolution h q)
    (j : Fin 4) {t : ℝ} (ht : -(1/4:ℝ) ≤ t) :
    rationalCoordinateMap j (z t)-rationalCoordinateMap j (q t) =
      clampedCoordinate z j (max 0 t)-clampedCoordinate q j (max 0 t) := by
  by_cases hp : 0 ≤ t
  · simp [clampedCoordinate, max_eq_right hp]
  · have hle : t ≤ 0 := le_of_not_ge hp
    simp only [clampedCoordinate, max_eq_left hle, max_self,
      hz.2.1 t ⟨ht, hle⟩, hq.2.1 t ⟨ht, hle⟩,
      hz.2.1 0 (by norm_num), hq.2.1 0 (by norm_num), sub_self]

theorem rationalStateSolution_unique {h z q : ℝ → LoopState}
    (hz : IsRationalStateSolution h z) (hq : IsRationalStateSolution h q) :
    EqOn z q (Ici (-(1/4:ℝ))) := by
  let x : Fin 4 → ℝ → ℝ := fun j t => clampedCoordinate z j t-clampedCoordinate q j t
  let f : ℝ → ℝ := fun t => ∑ j, |x j t|
  let L : Fin 4 → ℝ := ![2, 2, |-E/a|+|1/a|+|-(1/a)|, |E|+1]
  have hf (t : ℝ) : 0 ≤ f t := Finset.sum_nonneg (fun j _ => abs_nonneg _)
  have hb (j : Fin 4) (t : ℝ) : |x j t| ≤ f t :=
    Finset.single_le_sum (fun j _ => abs_nonneg (x j t)) (Finset.mem_univ j)
  have hnow (j : Fin 4) (t : ℝ) : |x j t| ≤ f t+f (max 0 (t-1/4)) :=
    (hb j t).trans (le_add_of_nonneg_right (hf _))
  have hdel (j : Fin 4) (t : ℝ) : |x j (max 0 (t-1/4))| ≤ f t+f (max 0 (t-1/4)) :=
    (hb j _).trans (le_add_of_nonneg_left (hf _))
  have hzbound (t : ℝ) : |(0:ℝ)| ≤ f t+f (max 0 (t-1/4)) := by
    rw [abs_zero]; exact add_nonneg (hf _) (hf _)
  have hzero (j : Fin 4) : x j 0 = 0 := by
    dsimp [x, clampedCoordinate]
    rw [max_self, hz.2.1 0 (by norm_num), hq.2.1 0 (by norm_num), sub_self]
  have hL (j : Fin 4) : 0 ≤ L j := by fin_cases j <;> dsimp [L] <;> positivity
  have hder (j : Fin 4) : ∀ᵐ t : ℝ, 0<t → |deriv (x j) t| ≤
      L j*(f t+f (max 0 (t-1/4))) := by
    apply ae_of_all
    intro t ht
    have hd := ((clampedCoordinate_hasDerivAt hz j ht).sub
      (clampedCoordinate_hasDerivAt hq j ht)).deriv
    change deriv (x j) t = _ at hd
    rw [hd]
    have hn (k : Fin 4) : rationalCoordinateMap k (z t)-rationalCoordinateMap k (q t) =
        x k t := by
      simpa only [max_eq_right ht.le] using
        rational_difference_clamp hz hq k (show -(1/4:ℝ) ≤ t by linarith)
    have hd2 : (z (t-1/4)).2.1-(q (t-1/4)).2.1 = x 2 (max 0 (t-1/4)) :=
      rational_difference_clamp hz hq 2 (show -(1/4:ℝ) ≤ t-1/4 by linarith)
    have hn0 : (z t).1 0-(q t).1 0 = x 0 t := hn 0
    have hn1 : (z t).1 1-(q t).1 1 = x 1 t := hn 1
    have hn2 : (z t).2.1-(q t).2.1 = x 2 t := hn 2
    have hn3 : (z t).2.2-(q t).2.2 = x 3 t := hn 3
    fin_cases j
    · change |((z (t-1/4)).2.1-(z t).1 0)-
        ((q (t-1/4)).2.1-(q t).1 0)| ≤ 2*(f t+f (max 0 (t-1/4)))
      have he : ((z (t-1/4)).2.1-(z t).1 0)-((q (t-1/4)).2.1-(q t).1 0) =
          1*x 2 (max 0 (t-1/4))+(-1)*x 0 t+0*0 := by linear_combination hd2-hn0
      rw [he]
      simpa only [abs_one, abs_neg, abs_zero, add_zero, one_add_one_eq_two] using
        linear_three_bound 1 (-1) 0 _ _ 0 _ (hdel 2 t) (hnow 0 t) (hzbound t)
    · change |((z t).1 0-(z t).1 1)-((q t).1 0-(q t).1 1)| ≤
        2*(f t+f (max 0 (t-1/4)))
      have he : ((z t).1 0-(z t).1 1)-((q t).1 0-(q t).1 1) =
          1*x 0 t+(-1)*x 1 t+0*0 := by linear_combination hn0-hn1
      rw [he]
      simpa only [abs_one, abs_neg, abs_zero, add_zero, one_add_one_eq_two] using
        linear_three_bound 1 (-1) 0 _ _ 0 _ (hnow 0 t) (hnow 1 t) (hzbound t)
    · change |(-E*(z t).2.1+(z t).2.2-(z t).1 0)/a-
        (-E*(q t).2.1+(q t).2.2-(q t).1 0)/a| ≤ _
      have he : (-E*(z t).2.1+(z t).2.2-(z t).1 0)/a-
          (-E*(q t).2.1+(q t).2.2-(q t).1 0)/a =
          (-E/a)*x 2 t+(1/a)*x 3 t+(-(1/a))*x 0 t := by
        linear_combination (-E/a)*hn2+(1/a)*hn3-(1/a)*hn0
      rw [he]
      exact linear_three_bound (-E/a) (1/a) (-(1/a)) _ _ _ _
        (hnow 2 t) (hnow 3 t) (hnow 0 t)
    · change |(E*(z t).2.1-(z t).2.2)-(E*(q t).2.1-(q t).2.2)| ≤ _
      have he : (E*(z t).2.1-(z t).2.2)-(E*(q t).2.1-(q t).2.2) =
          E*x 2 t+(-1)*x 3 t+0*0 := by linear_combination E*hn2-hn3
      rw [he]
      simpa [L] using
        linear_three_bound E (-1) 0 _ _ 0 _ (hnow 2 t) (hnow 3 t) (hzbound t)
  have hEq := finite_retarded_zero
    (fun j => (clampedCoordinate_continuous hz j).sub (clampedCoordinate_continuous hq j))
    (fun j T hT => (clampedCoordinate_ac hz j T hT).sub (clampedCoordinate_ac hq j T hT))
    hzero (by norm_num : (0:ℝ) ≤ 1/4) L hL hder
  intro t ht
  by_cases hp : 0 ≤ t
  · apply rational_coordinates_injective
    funext j
    have hj : x j t = 0 := hEq t hp j
    simpa only [x, clampedCoordinate, max_eq_right hp, sub_eq_zero] using hj
  · exact (hz.2.1 t ⟨ht, le_of_not_ge hp⟩).trans (hq.2.1 t ⟨ht, le_of_not_ge hp⟩).symm

end Article14.ExactDelay
