import Article14.PIDFAlgebra
import Article14.TrackingMoments

/-!
# Physical equilibrium translation for the shared-D delayed PIDF realization

For a linear plant, the post-step equilibrium is translated to the origin in
all plant and controller states.  Once the delayed reference has also reached
one, the resulting equation is exactly the previously defined homogeneous
retarded equation.  This is an equality of actual vector fields, not an
assumption about a transfer function or a decay rate.
-/
namespace Article14
open MeasureTheory Filter Set MIACE
open scoped Topology

noncomputable def linearPlantDynamics {X : Type*}
    [NormedAddCommGroup X] [NormedSpace ℝ X]
    (A : X →L[ℝ] X) (B : ℝ →L[ℝ] X) (x : X) (u : ℝ) : X :=
  A x + B u

noncomputable def pidfEquilibrium {X : Type*}
    (xe : X) (Ti k Kp b c : ℝ) : X × ℝ × ℝ :=
  (xe, meanTime Ti k Kp b, c - 1)

-- Article 14, Theorems 14–17: both physical controller derivatives and the
-- command are translated together; the equilibrium integral depends on b.
theorem sharedController_equilibrium_translation
    (Kp Ti Td Tf k b c y i f : ℝ)
    (hk : k ≠ 0) (hKp : Kp ≠ 0) (hTi : Ti ≠ 0) :
    sharedControllerRhs Kp Ti Td Tf b c 1 (y + 1)
      (i + meanTime Ti k Kp b) (f + (c - 1)) =
    let h := sharedControllerRhs Kp Ti Td Tf b c 0 y i f
    (h.1, h.2.1, h.2.2 + 1 / k) := by
  simp only [sharedControllerRhs, meanTime]
  ext <;> dsimp
  · ring
  · ring
  · field_simp
    ring

-- Article 14, Theorems 14–17: complete affine translation of the delayed
-- physical vector field. The same state shift is applied to the whole history.
theorem retardedShared_equilibrium_translation {X : Type*}
    [NormedAddCommGroup X] [NormedSpace ℝ X]
    (A : X →L[ℝ] X) (B : ℝ →L[ℝ] X) (C : X →L[ℝ] ℝ)
    (Kp Ti Td Tf L k b c : ℝ) (xe : X)
    (hk : k ≠ 0) (hKp : Kp ≠ 0) (hTi : Ti ≠ 0)
    (heq : A xe + B (1 / k) = 0) (hout : C xe = 1)
    (h : ℝ → X × ℝ × ℝ) :
    retardedSharedRhs C (linearPlantDynamics A B) Kp Ti Td Tf L b c
      (fun _ => 1) (fun θ => h θ + pidfEquilibrium xe Ti k Kp b c) =
    retardedSharedRhs C (linearPlantDynamics A B) Kp Ti Td Tf L b c
      (fun _ => 0) h := by
  simp only [retardedSharedRhs, pidfEquilibrium, Prod.fst_add, Prod.snd_add,
    map_add, hout]
  rw [sharedController_equilibrium_translation Kp Ti Td Tf k b c _ _ _ hk hKp hTi,
    sharedController_equilibrium_translation Kp Ti Td Tf k b c _ _ _ hk hKp hTi]
  simp only [linearPlantDynamics, map_add]
  congr 1
  calc
    A (h 0).1 + A xe + (B (sharedControllerRhs Kp Ti Td Tf b c 0
        (C (h (-L)).1) (h (-L)).2.1 (h (-L)).2.2).2.2 + B (1 / k)) =
      (A (h 0).1 + B (sharedControllerRhs Kp Ti Td Tf b c 0
        (C (h (-L)).1) (h (-L)).2.1 (h (-L)).2.2).2.2) +
        (A xe + B (1 / k)) := by abel
    _ = _ := by rw [heq, add_zero]

-- Article 14, Theorems 14–17: the centered trajectory really satisfies the
-- homogeneous equation whenever the actual post-delay step equation does.
theorem centeredTrajectory_hasDerivAt {X : Type*}
    [NormedAddCommGroup X] [NormedSpace ℝ X]
    (A : X →L[ℝ] X) (B : ℝ →L[ℝ] X) (C : X →L[ℝ] ℝ)
    (Kp Ti Td Tf L k b c : ℝ) (xe : X)
    (hk : k ≠ 0) (hKp : Kp ≠ 0) (hTi : Ti ≠ 0)
    (heq : A xe + B (1 / k) = 0) (hout : C xe = 1)
    (q : ℝ → X × ℝ × ℝ) (t : ℝ)
    (hode : HasDerivAt q
      (retardedSharedRhs C (linearPlantDynamics A B) Kp Ti Td Tf L b c
        (fun _ => 1) (fun θ => q (t + θ))) t) :
    HasDerivAt (fun s => q s - pidfEquilibrium xe Ti k Kp b c)
      (retardedSharedRhs C (linearPlantDynamics A B) Kp Ti Td Tf L b c
        (fun _ => 0) (fun θ => q (t + θ) - pidfEquilibrium xe Ti k Kp b c)) t := by
  have hr := retardedShared_equilibrium_translation A B C Kp Ti Td Tf L k b c xe
    hk hKp hTi heq hout (fun θ => q (t + θ) - pidfEquilibrium xe Ti k Kp b c)
  simp only [sub_add_cancel] at hr
  rw [← hr]
  exact hode.sub_const _

end Article14
