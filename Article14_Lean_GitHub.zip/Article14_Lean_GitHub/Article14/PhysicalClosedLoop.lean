import Article14.PhysicalPlant
import Article14.PhysicalPIDF
import Article14.PhysicalStability
import Article14.PhysicalCentering
import Article14.MIACEProjection

/-!
# One physical state trajectory supplies the signal hypotheses

This module composes the state, controller and plant results.  All analytic
integrability and convergence conditions are derived from one exponentially
stable complete state trajectory.  Only the actual differential equations,
initial conditions, and regularity of that trajectory are supplied.
-/
namespace Article14
open MeasureTheory Filter Set MIACE
open scoped Topology
open PhysicalPlant PhysicalLaplace

variable {n : Type*} [Fintype n] [DecidableEq n]

/-- Coordinate observation of the complete centered physical state. -/
noncomputable def plantCoordinate (j : n) : ((n → ℝ) × ℝ × ℝ) →L[ℝ] ℝ :=
  (ContinuousLinearMap.proj j).comp (ContinuousLinearMap.fst ℝ (n → ℝ) (ℝ × ℝ))

noncomputable def integralCoordinate : ((n → ℝ) × ℝ × ℝ) →L[ℝ] ℝ :=
  (ContinuousLinearMap.fst ℝ ℝ ℝ).comp
    (ContinuousLinearMap.snd ℝ (n → ℝ) (ℝ × ℝ))

noncomputable def filterCoordinate : ((n → ℝ) × ℝ × ℝ) →L[ℝ] ℝ :=
  (ContinuousLinearMap.snd ℝ ℝ ℝ).comp
    (ContinuousLinearMap.snd ℝ (n → ℝ) (ℝ × ℝ))

noncomputable def errorObservation (C : n → ℝ) : ((n → ℝ) × ℝ × ℝ) →L[ℝ] ℝ :=
  -(∑ j, C j • plantCoordinate j)

noncomputable def commandObservation (C : n → ℝ) (k Kp Ti Td Tf : ℝ) :
    ((n → ℝ) × ℝ × ℝ) →L[ℝ] ℝ :=
  (k*Kp) • (errorObservation C + (1/Ti) • integralCoordinate +
    (Td/Tf) • (errorObservation C - filterCoordinate))

-- These maps are the actual centered error and normalized command, not free
-- choices of an observation unrelated to the plant/controller coordinates.
omit [DecidableEq n] in
theorem errorObservation_apply (C : n → ℝ) (q : (n → ℝ) × ℝ × ℝ) :
    errorObservation C q = -(∑ j, C j * q.1 j) := by
  simp [errorObservation, plantCoordinate]

omit [DecidableEq n] in
theorem commandObservation_apply (C : n → ℝ) (k Kp Ti Td Tf : ℝ)
    (q : (n → ℝ) × ℝ × ℝ) :
    commandObservation C k Kp Ti Td Tf q = k*Kp*
      (errorObservation C q + q.2.1/Ti + Td/Tf*(errorObservation C q-q.2.2)) := by
  simp [commandObservation, integralCoordinate, filterCoordinate, div_eq_mul_inv]
  ring

/-- Actual centered physical equations and initial data.  The command and
error are fixed observations of the same complete state.  In particular no
signal transform, integral, limit, or decay estimate is a field. -/
structure CenteredLoopDynamics (A : Matrix n n ℝ) (B C xInf : n → ℝ)
    (Kp Ti Td Tf k L b c : ℝ) (q : ℝ → (n → ℝ) × ℝ × ℝ) : Prop where
  state_ac : ∀ j T, 0 ≤ T → AbsolutelyContinuousOnInterval (fun t => (q t).1 j) 0 T
  state_initial : ∀ j, (q 0).1 j = -xInf j
  state_ode : ∀ j, ∀ᵐ t : ℝ, 0 < t →
    deriv (fun s => (q s).1 j) t = (∑ l, A j l * (q t).1 l) + B j / k *
      centeredDelay L (fun s => commandObservation C k Kp Ti Td Tf (q s)) t
  controller : CenteredPIDFDynamics
    (fun t => errorObservation C (q t))
    (fun t => commandObservation C k Kp Ti Td Tf (q t))
    (fun t => (q t).2.1) (fun t => (q t).2.2) Kp Ti Td Tf k b c

-- Article 14, Theorems 14–17: a single state estimate supplies every L¹ and
-- limiting hypothesis required by the plant and controller transform proofs.
omit [DecidableEq n] in
theorem centeredLoop_responses_of_decay
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : CenteredLoopDynamics A B C xInf Kp Ti Td Tf k L b c q)
    (hq : ContinuousOn q (Ici 0)) {D α : ℝ} (hD : 0 < D) (hα : 0 < α)
    (hd : ∀ t, 0 ≤ t → ‖q t‖ ≤ D * Real.exp (-α*t)) :
    CenteredPlantResponse A B xInf k L (fun j t => (q t).1 j)
      (fun t => commandObservation C k Kp Ti Td Tf (q t)) ∧
    CenteredPIDFResponse (fun t => errorObservation C (q t))
      (fun t => commandObservation C k Kp Ti Td Tf (q t))
      (fun t => (q t).2.1) (fun t => (q t).2.2) Kp Ti Td Tf k b c := by
  have hx := fun j => linear_observable_admissible q (plantCoordinate j) hq hD hα hd
  have he := linear_observable_admissible q (errorObservation C) hq hD hα hd
  have hv := linear_observable_admissible q (commandObservation C k Kp Ti Td Tf) hq hD hα hd
  have hi := linear_observable_admissible q (integralCoordinate (n := n)) hq hD hα hd
  have hf := linear_observable_admissible q (filterCoordinate (n := n)) hq hD hα hd
  constructor
  · exact ⟨h.state_ac, fun j => (hx j).2.1, fun j => (hx j).2.2.1,
      h.state_initial, h.state_ode, hv.2.1⟩
  · exact ⟨h.controller, he.2.1, hv.2.1, hi.2.1, hf.2.1, hi.2.2.1, hf.2.2.1⟩

/-- The strictly proper output map of the same finite plant. -/
noncomputable def finitePlantOutput (C : n → ℝ) (x : n → ℝ) : ℝ := ∑ j, C j*x j

/-- The actual undelayed state equation used inside the delayed realization. -/
noncomputable def finitePlantDynamics (A : Matrix n n ℝ) (B : n → ℝ)
    (x : n → ℝ) (u : ℝ) : n → ℝ := fun j => (∑ l, A j l*x l) + B j*u

-- Article 14, Theorems 14–17: the existing all-history stability predicate
-- supplies the analytic hypotheses for the very same finite plant. The
-- after-delay equation is a physical differential equation, not a transform.
omit [DecidableEq n] in
theorem stable_centeredLoop_responses
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : CenteredLoopDynamics A B C xInf Kp Ti Td Tf k L b c q)
    (hL : 0 ≤ L) (hq : ContinuousOn q (Ici 0))
    (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c)
    (hode : ∀ t, L < t → HasDerivAt q
      (retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
        Kp Ti Td Tf L b c (fun _ => 0) (fun θ => q (t+θ))) t) :
    CenteredPlantResponse A B xInf k L (fun j t => (q t).1 j)
      (fun t => commandObservation C k Kp Ti Td Tf (q t)) ∧
    CenteredPIDFResponse (fun t => errorObservation C (q t))
      (fun t => commandObservation C k Kp Ti Td Tf (q t))
      (fun t => (q t).2.1) (fun t => (q t).2.2) Kp Ti Td Tf k b c := by
  obtain ⟨D, α, hD, hα, hd⟩ := retardedShared_stable_tail_decay
    (finitePlantOutput C) (finitePlantDynamics A B) Kp Ti Td Tf L b c q hL hs hq hode
  exact centeredLoop_responses_of_decay h hq hD hα hd

-- Article 14, Theorems 14–17: the derived plant interface and actual error
-- area are now simultaneous conclusions from one stable physical trajectory.
theorem stable_centeredLoop_transfer_and_area
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : CenteredLoopDynamics A B C xInf Kp Ti Td Tf k L b c q)
    (hL : 0 ≤ L) (hq : ContinuousOn q (Ici 0))
    (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c)
    (hode : ∀ t, L < t → HasDerivAt q
      (retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
        Kp Ti Td Tf L b c (fun _ => 0) (fun θ => q (t+θ))) t)
    (heq : ∀ j, (∑ l, A j l*xInf l) + B j/k = 0)
    (hout : (∑ j, C j*xInf j) = 1) (hA : (pencil A 0).det ≠ 0) :
    LocalTransferResponse (fun t => errorObservation C (q t))
      (fun t => commandObservation C k Kp Ti Td Tf (q t))
      (normalizedTransfer A B C k) L ∧
    (∫ t, errorObservation C (q t) ∂halfLine) = meanTime Ti k Kp b := by
  obtain ⟨hp, hc⟩ := stable_centeredLoop_responses h hL hq hs hode
  constructor
  · have ht := localTransfer_of_centered_plant (C := C) hp hL heq hout hA
    change LocalTransferResponse (fun t => -(∑ j, C j * (q t).1 j)) _ _ _ at ht
    simpa only [errorObservation_apply] using ht
  · exact centeredPIDF_error_area hc

-- Article 14, Theorems 14–17: the complete local signal result, with both
-- signed areas and the actual PIDF error transform derived from the state.
theorem stable_centeredLoop_signal_identities
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : CenteredLoopDynamics A B C xInf Kp Ti Td Tf k L b c q)
    (hL : 0 ≤ L) (hq : ContinuousOn q (Ici 0))
    (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c)
    (hode : ∀ t, L < t → HasDerivAt q
      (retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
        Kp Ti Td Tf L b c (fun _ => 0) (fun θ => q (t+θ))) t)
    (heq : ∀ j, (∑ l, A j l*xInf l) + B j/k = 0)
    (hout : (∑ j, C j*xInf j) = 1) (hA : (pencil A 0).det ≠ 0)
    (hk : k ≠ 0) (hKp : Kp ≠ 0) (hTi : Ti ≠ 0) (hTf : 0 < Tf) :
    let e := fun t => errorObservation C (q t)
    let v := fun t => commandObservation C k Kp Ti Td Tf (q t)
    (∫ t, e t ∂halfLine) = meanTime Ti k Kp b ∧
    (∫ t, v t ∂halfLine) = residenceTime A C xInf + L - meanTime Ti k Kp b ∧
    laplace e =ᶠ[𝓝[>] (0 : ℝ)]
      clearedError (inverseDelayedPlant (normalizedTransfer A B C k) k L)
        Kp (Kp/Ti) (Kp*Td) Tf b c := by
  obtain ⟨_, hc⟩ := stable_centeredLoop_responses h hL hq hs hode
  obtain ⟨hp, hm⟩ := stable_centeredLoop_transfer_and_area h hL hq hs hode heq hout hA
  have hd := normalizedTransfer_hasDerivAt_zero heq hout hA
  have h0 := normalizedTransfer_zero heq hout hA
  exact ⟨hm, centeredPIDF_command_area hc hp hd h0,
    centeredPIDF_local_clearedError hc hp hd.continuousAt h0 hTi hk hKp hTf⟩

-- Article 14, Theorem 17: the universal MIACE estimate now starts from the
-- actual finite-state delayed PIDF trajectory. Γ is computed from A,C,x∞,L.
theorem stable_centeredLoop_miace_bound
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : CenteredLoopDynamics A B C xInf Kp Ti Td Tf k L b c q)
    (hL : 0 ≤ L) (hq : ContinuousOn q (Ici 0))
    (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c)
    (hode : ∀ t, L < t → HasDerivAt q
      (retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
        Kp Ti Td Tf L b c (fun _ => 0) (fun θ => q (t+θ))) t)
    (heq : ∀ j, (∑ l, A j l*xInf l) + B j/k = 0)
    (hout : (∑ j, C j*xInf j) = 1) (hA : (pencil A 0).det ≠ 0)
    (α : ℝ) (hα : 0 < α) (hΓ : 0 ≤ residenceTime A C xInf + L) :
    (residenceTime A C xInf + L) * Real.sqrt (α/(1+α)) ≤
      miace α (fun t => errorObservation C (q t))
        (fun t => commandObservation C k Kp Ti Td Tf (q t)) halfLine := by
  obtain ⟨hp, _⟩ := stable_centeredLoop_transfer_and_area h hL hq hs hode heq hout hA
  exact local_transfer_miace_lower_bound hp α (residenceTime A C xInf) hα hΓ
    (normalizedTransfer_hasDerivAt_zero heq hout hA) (normalizedTransfer_zero heq hout hA)

-- Article 14, Proposition 15: this actual time moment requires no separate
-- exponential-envelope or transform hypothesis; internal stability supplies both.
theorem stable_centeredLoop_first_error_moment
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : CenteredLoopDynamics A B C xInf Kp Ti Td Tf k L b c q)
    (hL : 0 ≤ L) (hq : ContinuousOn q (Ici 0))
    (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c)
    (hode : ∀ t, L < t → HasDerivAt q
      (retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
        Kp Ti Td Tf L b c (fun _ => 0) (fun θ => q (t+θ))) t)
    (heq : ∀ j, (∑ l, A j l*xInf l) + B j/k = 0)
    (hout : (∑ j, C j*xInf j) = 1) (hA : (pencil A 0).det ≠ 0)
    (hk : k ≠ 0) (hKp : Kp ≠ 0) (hTi : Ti ≠ 0) (hTf : 0 < Tf) :
    (∫ t, t * errorObservation C (q t) ∂halfLine) =
      secondErrorMoment Kp (Kp/Ti) (Kp*Td) k (residenceTime A C xInf + L)
        (meanTime Ti k Kp b) c := by
  obtain ⟨D, β, hD, hβ, hd⟩ := retardedShared_stable_tail_decay
    (finitePlantOutput C) (finitePlantDynamics A B) Kp Ti Td Tf L b c q hL hs hq hode
  obtain ⟨_, hc⟩ := centeredLoop_responses_of_decay h hq hD hβ hd
  obtain ⟨hp, _⟩ := stable_centeredLoop_transfer_and_area h hL hq hs hode heq hout hA
  obtain ⟨he, _, _, E, hE, hedecay⟩ := linear_observable_admissible q
    (errorObservation C) hq hD hβ hd
  exact centeredPIDF_first_error_moment hc hp
    (normalizedTransfer_hasDerivAt_zero heq hout hA) (normalizedTransfer_zero heq hout hA)
    hTi hk hKp hTf he hE.le hβ hedecay

-- Article 14, Theorem 17: on actual nonnegative error/command signals the
-- fixed-feedback physical response has the exact scalar MIACE objective.
theorem stable_centeredLoop_nonnegative_miace
    {A : Matrix n n ℝ} {B C xInf : n → ℝ} {Kp Ti Td Tf k L b c : ℝ}
    {q : ℝ → (n → ℝ) × ℝ × ℝ}
    (h : CenteredLoopDynamics A B C xInf Kp Ti Td Tf k L b c q)
    (hL : 0 ≤ L) (hq : ContinuousOn q (Ici 0))
    (hs : IsRetardedSharedExponentiallyStable (finitePlantOutput C)
      (finitePlantDynamics A B) Kp Ti Td Tf L b c)
    (hode : ∀ t, L < t → HasDerivAt q
      (retardedSharedRhs (finitePlantOutput C) (finitePlantDynamics A B)
        Kp Ti Td Tf L b c (fun _ => 0) (fun θ => q (t+θ))) t)
    (heq : ∀ j, (∑ l, A j l*xInf l) + B j/k = 0)
    (hout : (∑ j, C j*xInf j) = 1) (hA : (pencil A 0).det ≠ 0)
    (he : ∀ᵐ t ∂halfLine, 0 ≤ errorObservation C (q t))
    (hv : ∀ᵐ t ∂halfLine, 0 ≤ commandObservation C k Kp Ti Td Tf (q t)) (α : ℝ) :
    miace α (fun t => errorObservation C (q t))
      (fun t => commandObservation C k Kp Ti Td Tf (q t)) halfLine =
    Real.sqrt ((meanTime Ti k Kp b)^2 +
      α*(residenceTime A C xInf + L - meanTime Ti k Kp b)^2) := by
  obtain ⟨_, hc⟩ := stable_centeredLoop_responses h hL hq hs hode
  obtain ⟨hp, _⟩ := stable_centeredLoop_transfer_and_area h hL hq hs hode heq hout hA
  exact centeredPIDF_nonnegative_miace hc hp
    (normalizedTransfer_hasDerivAt_zero heq hout hA) (normalizedTransfer_zero heq hout hA)
    he hv α

end Article14
