import MIACE.CompleteAttainment

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:complete_cap/full_stable_capped_area_interval
theorem paper_complete_cap_areas (N : ℕ) (σ : ℕ → ℝ) {δ c U : ℝ}
    (hδ : 0≤δ) (hc : 0<c) (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1) :
    (∃ F : IMCFilter, ∃ v : ℝ → ℝ, NominalCascadeIMC N σ F δ v ∧
      (∀ᵐ t ∂halfLine, 0≤v t ∧ v t≤c) ∧
      (∀ t, 0≤t → 0≤cascadeStepError N σ δ v t) ∧ commandArea v=U) ↔
    0≤U ∧ U≤c*Real.log (1+1/c) := by
  constructor
  · rintro ⟨F,v,hF,hcap,he,harea⟩
    have hm := cascade_nonovershoot_moment N σ hδ hσ hfirst hF.command_integrable
      (hcap.mono (fun _ ht => ht.1)) he
    rw [← harea]
    exact ⟨integral_nonneg_of_ae (hcap.mono (fun _ ht => ht.1)),
      cap_area_necessary c hc hF.command_integrable.integrableOn hm.1 hcap hm.2⟩
  · rintro ⟨hU,hcap⟩
    have hT := div_nonneg hU hc.le
    have hp := cascade_pulse_family N σ hδ hc hU hcap hσ hfirst
    exact ⟨pulseIMC c (U/c) hT,pulse c (U/c),pulse_cascade_IMC N σ c hδ hT hσ hfirst,
      hp.2.2.2.2.2.2.2,hp.2.2.2.2.1,(cap_area_sufficient c U hc hU hcap).2.2.2.1⟩

-- @paper-step thm:complete_cap/full_stable_capped_optimal_attainment
theorem paper_complete_cap_attainment (N : ℕ) (σ : ℕ → ℝ) {δ c α : ℝ}
    (hδ : 0≤δ) (hc : 0<c) (hα : 0<α)
    (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1) :
    (∃ F : IMCFilter, ∃ v : ℝ → ℝ, NominalCascadeIMC N σ F δ v ∧
      (∀ᵐ t ∂halfLine, 0≤v t ∧ v t≤c) ∧
      miace α (cascadeStepError N σ δ v) v halfLine=(cascadeMean σ (N+1)+δ)*minimum α) ↔
    (cascadeMean σ (N+1)+δ)/(1+α)≤c*Real.log (1+1/c) := by
  let S := cascadeMean σ (N+1)+δ
  have hS : 0<S := by
    have := cascadeMean_ge_one N σ (fun j hj => (hσ j hj).1) hfirst
    dsimp [S]; linarith
  constructor
  · rintro ⟨F,v,hF,hcap,heq⟩
    have hP := ordinaryCascade_transfer_response hF.command_integrable σ (N+1)
      (fun j hj => (hσ j (by omega)).1) hδ
    have hu : LocallyIntegrable (fun t => 1+v t) volume :=
      (continuous_const : Continuous (fun _ : ℝ => (1 : ℝ))).locallyIntegrable.add hF.command_integrable.locallyIntegrable
    have hnec := paper_cascade_necessary N σ (ordinaryCascade σ (fun t => 1+v t)) δ α
      (cascadeMean σ (N+1)) hδ hα hS hσ hfirst (fun j _ => ordinaryCascade_response hu σ j)
      rfl hP (cascadeTransfer_derivative σ (N+1)) (cascadeTransfer_zero σ (N+1)) heq
    have harea := (paper_general_plant hP α (cascadeMean σ (N+1)) hα hS
      (cascadeTransfer_derivative σ (N+1)) (cascadeTransfer_zero σ (N+1))).2.2.2.2.2 heq
    have habs : absArea v halfLine=commandArea v := by
      apply integral_congr_ae
      filter_upwards [hcap] with t ht
      exact abs_of_nonneg ht.1
    rw [← harea.2,habs]
    exact cap_area_necessary c hc hP.command_integrable hnec.2.1 hcap hnec.2.2.1
  · intro hcap
    let U := S/(1+α)
    have hU : 0≤U := (div_pos hS (by linarith)).le
    have hT := div_nonneg hU hc.le
    have hp := cascade_pulse_family N σ hδ hc hU hcap hσ hfirst
    refine ⟨pulseIMC c (U/c) hT,pulse c (U/c),pulse_cascade_IMC N σ c hδ hT hσ hfirst,
      hp.2.2.2.2.2.2.2,?_⟩
    have hbal := transfer_signed_balance hp.1 (cascadeMean σ (N+1))
      (cascadeTransfer_derivative σ (N+1)) (cascadeTransfer_zero σ (N+1))
    apply (signal_miace_equality_iff hp.1.error_integrable hp.1.command_integrable α S hα hS hbal).mpr
    refine ⟨?_,hp.2.2.2.2.2.2.2.mono (fun _ ht => ht.1),?_⟩
    · filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
      exact hp.2.2.2.2.1 t (show 0<t from ht).le
    · rw [hp.2.2.2.2.2.1,hp.2.2.2.2.2.2.1]
      change S-U=α*U
      dsimp [U]
      have hd : 1+α≠0 := by linarith
      field_simp <;> ring

-- @paper-step thm:complete_cap/exact_weight_threshold
theorem capped_attainment_weight_iff {α S c : ℝ} (hα : 0<α) (hc : 0<c) :
    S/(1+α)≤c*Real.log (1+1/c) ↔ S/(c*Real.log (1+1/c))-1≤α := by
  have hC := capacity_positive c hc
  rw [div_le_iff₀ (show 0<1+α by linarith)]
  constructor
  · intro h
    have hh : S/(c*Real.log (1+1/c))≤1+α := (div_le_iff₀ hC).mpr (by nlinarith)
    linarith
  · intro h
    have hh := (div_le_iff₀ hC).mp (show S/(c*Real.log (1+1/c))≤1+α by linarith)
    nlinarith

-- @paper-step thm:complete_cap/boundary_pulse_unit_moment
theorem boundary_pulse_moment {c : ℝ} (hc : 0<c) :
    moment (pulse c (Real.log (1+1/c)))=1 := by
  have hlog : 0≤Real.log (1+1/c) := Real.log_nonneg (by linarith [one_div_pos.mpr hc])
  rw [pulse_moment c _ hlog,Real.exp_log (by positivity : 0<1+1/c)]
  field_simp <;> ring

-- @paper-step thm:complete_cap/full_boundary_command_uniqueness
theorem paper_complete_cap_unique (N : ℕ) (σ : ℕ → ℝ) {δ c : ℝ} {v : ℝ → ℝ}
    (hδ : 0≤δ) (hc : 0<c) (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1)
    (hv : Integrable v) (hcap : ∀ᵐ t ∂halfLine, 0≤v t ∧ v t≤c)
    (he : ∀ t, 0≤t → 0≤cascadeStepError N σ δ v t)
    (harea : commandArea v=c*Real.log (1+1/c)) :
    v=ᵐ[halfLine] pulse c (Real.log (1+1/c)) := by
  have hm := cascade_nonovershoot_moment N σ hδ hσ hfirst hv (hcap.mono (fun _ ht => ht.1)) he
  have hlog : 0≤Real.log (1+1/c) := Real.log_nonneg (by linarith [one_div_pos.mpr hc])
  have hmin := pulse_minimizes_moment c (Real.log (1+1/c)) hlog hv.integrableOn hm.1 hcap harea
  have hpm := boundary_pulse_moment hc
  have hl : 1≤moment v := by
    rw [← pulse_moment c _ hlog] at hmin
    rwa [hpm] at hmin
  apply pulse_unique_of_equal_moment c _ hv.integrableOn hm.1 hcap
  · rwa [pulse_area c _ hlog]
  · rw [hpm]; exact le_antisymm hm.2 hl

end MIACE
