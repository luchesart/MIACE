import MIACE.TwoRateKernel
import MIACE.PIDParameters

/-! Точните площи на входовете и на решенията на интегралното уравнение.
    Тук все още не се идентифицират всички вътрешни физически PID състояния. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:pid_two_rate_optimum/exponential_finite_integral
theorem finite_exp_integral {r : ℝ} (hr : r ≠ 0) (δ : ℝ) :
    (∫ t in 0..δ, Real.exp (-r*t))=(1-Real.exp (-r*δ))/r := by
  have hd (t : ℝ) : HasDerivAt (fun s : ℝ => Real.exp (-r*s)/(-r)) (Real.exp (-r*t)) t := by
    convert ((((hasDerivAt_id t).const_mul (-r)).exp).div_const (-r)) using 1
    · rfl
    · dsimp
      field_simp
  have he := intervalIntegral.integral_eq_sub_of_hasDerivAt (fun t _ => hd t)
    ((by fun_prop : Continuous (fun t : ℝ => Real.exp (-r*t))).intervalIntegrable 0 δ)
  rw [he]
  simp only [mul_zero,Real.exp_zero]
  field_simp
  <;> ring

-- @paper-step thm:pid_two_rate_optimum/forcing_finite_integral
theorem twoRateG_finite_integral (A : ℝ) {l m : ℝ} (hl : l ≠ 0) (hm : m ≠ 0) (δ : ℝ) :
    (∫ t in 0..δ, twoRateG A l m t)=
      A*(1-Real.exp (-l*δ))/l+(1-A)*(1-Real.exp (-m*δ))/m := by
  unfold twoRateG
  rw [intervalIntegral.integral_add
    ((by fun_prop : Continuous (fun t : ℝ => A*Real.exp (-l*t))).intervalIntegrable 0 δ)
    ((by fun_prop : Continuous (fun t : ℝ => (1-A)*Real.exp (-m*t))).intervalIntegrable 0 δ),
    intervalIntegral.integral_const_mul,intervalIntegral.integral_const_mul,
    finite_exp_integral hl,finite_exp_integral hm]
  ring

-- @paper-step thm:pid_two_rate_optimum/shifted_pair_integral
theorem causal_exp_pair_integral (C D δ : ℝ) {l m : ℝ} (hl : 0 < l) (hm : 0 < m) :
    (∫ t, causalize (fun s => C*Real.exp (-l*(s+δ))+D*Real.exp (-m*(s+δ))) t)=
      C*Real.exp (-l*δ)/l+D*Real.exp (-m*δ)/m := by
  rw [causalize_integral]
  have he : (fun s => C*Real.exp (-l*(s+δ))+D*Real.exp (-m*(s+δ))) =
      (fun s => (C*Real.exp (-l*δ))*Real.exp (-l*s)+(D*Real.exp (-m*δ))*Real.exp (-m*s)) := by
    funext s
    rw [show -l*(s+δ)=(-l*δ)+(-l*s) by ring,
      show -m*(s+δ)=(-m*δ)+(-m*s) by ring,Real.exp_add,Real.exp_add]
    ring
  rw [he]
  unfold halfLine
  rw [integral_add ((integrableOn_exp_mul_Ioi (neg_neg_of_pos hl) 0).const_mul _)
    ((integrableOn_exp_mul_Ioi (neg_neg_of_pos hm) 0).const_mul _),
    integral_const_mul,integral_const_mul,
    integral_exp_mul_Ioi (neg_neg_of_pos hl),integral_exp_mul_Ioi (neg_neg_of_pos hm)]
  simp [div_eq_mul_inv]

-- @paper-step thm:pid_two_rate_optimum/zero_weight_identity
theorem expWeight_zero (f : ℝ → ℝ) : expWeight 0 f=f := by
  funext t
  simp [expWeight]

-- @paper-step thm:pid_two_rate_optimum/command_forcing_integrability
theorem twoRateR_integrable (A δ : ℝ) {l m : ℝ} (hl : 0 < l) (hm : 0 < m) :
    Integrable (causalize (twoRateR A l m δ)) := by
  simpa only [expWeight_zero] using twoRateR_weighted A δ hl hm

-- @paper-step thm:pid_two_rate_optimum/command_forcing_area
theorem twoRateR_integral (A : ℝ) {l m δ : ℝ} (hl : 0 < l) (hm : 0 < m)
    (hδ : 0 ≤ δ) :
    (∫ t, causalize (twoRateR A l m δ) t)=
      (1+δ)*twoRateG A l m δ-(A/l+(1-A)/m) := by
  let f := fun t => twoRateD A l m (t+δ)-twoRateG A l m (t+δ)
  have he : (fun t => (l-1)*A*Real.exp (-l*(t+δ))+(m-1)*(1-A)*Real.exp (-m*(t+δ)))=f := by
    funext t; dsimp [f,twoRateD,twoRateG]; ring
  have hf : Integrable (causalize f) := by
    have hh := weighted_exp_pair_integrable ((l-1)*A) ((m-1)*(1-A)) δ hl hm
    rw [he] at hh
    simpa only [expWeight_zero] using hh
  have hfi : (∫ t, causalize f t)=
      (l-1)*A*Real.exp (-l*δ)/l+(m-1)*(1-A)*Real.exp (-m*δ)/m := by
    rw [← he]
    exact causal_exp_pair_integral _ _ _ hl hm
  have hc : Integrable ((Ico (0 : ℝ) δ).indicator (fun t => twoRateG A l m δ-twoRateG A l m t)) :=
    compact_indicator_integrable (continuous_const.sub (twoRate_continuous A l m).1) δ
  rw [twoRateR_split,integral_add hf hc,hfi,integral_indicator measurableSet_Ico,
    integral_Ico_eq_integral_Ioc,← intervalIntegral.integral_of_le hδ]
  rw [intervalIntegral.integral_sub (intervalIntegrable_const)
    ((twoRate_continuous A l m).1.intervalIntegrable 0 δ),
    intervalIntegral.integral_const,twoRateG_finite_integral A (ne_of_gt hl) (ne_of_gt hm)]
  simp only [sub_zero,smul_eq_mul,twoRateG]
  field_simp
  <;> ring

-- @paper-step thm:pid_two_rate_optimum/renewal_integral_balance
theorem renewal_integral_balance {K : ℝ → ℝ} (hK : Integrable K) (g z : RealL1)
    (hz : z=g+convOp hK z) :
    (1-(∫ t, K t))*(∫ t, z t)=∫ t, g t := by
  have he : (z : ℝ → ℝ) =ᵐ[volume] (fun t => g t+(K ⋆ (z : ℝ → ℝ)) t) := by
    have hh := Lp.coeFn_add g (convOp hK z)
    rw [← hz] at hh
    filter_upwards [hh,convOp_coe hK z] with t ht hc
    simpa only [Pi.add_apply,hc] using ht
  have hi := integral_congr_ae he
  rw [integral_add (L1.integrable_coeFn g)
    (hK.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) (L1.integrable_coeFn z)),
    integral_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hK (L1.integrable_coeFn z)] at hi
  change (∫ t, z t)=(∫ t, g t)+(∫ t, K t)*(∫ t, z t) at hi
  linarith

-- @paper-step thm:pid_two_rate_optimum/renewal_exact_integral
theorem renewal_integral {K : ℝ → ℝ} (hK : Integrable K) (g z : RealL1)
    (hz : z=g+convOp hK z) (hq : (∫ t, K t) ≠ 1) :
    (∫ t, z t)=(∫ t, g t)/(1-(∫ t, K t)) := by
  apply (eq_div_iff (sub_ne_zero.mpr hq.symm)).mpr
  nlinarith [renewal_integral_balance hK g z hz]

-- @paper-step thm:pid_two_rate_optimum/nonnegative_absolute_area
theorem positive_l1_area (z : RealL1) (hz : 0 ≤ z) :
    absArea z volume=∫ t, z t := by
  rw [← Lp.coeFn_nonneg] at hz
  apply integral_congr_ae
  filter_upwards [hz] with t ht
  exact abs_of_nonneg ht

end MIACE
