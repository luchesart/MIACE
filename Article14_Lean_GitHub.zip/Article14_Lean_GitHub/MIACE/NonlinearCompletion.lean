import MIACE.NonlinearStorage
import MIACE.GeneralCost
import MIACE.NonlinearAttainment

/-! Manuscript Theorem 32, assembled for the original MIACE criterion.
All balances below follow from the physical nonlinear differential equation;
the storage primitive neither replaces the measured error nor changes time.
-/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:nonlinear_miace/unsquared_lower_bound
theorem nonlinear_response_miace_lower_bound {a y w : ℝ → ℝ}
    (ha : Continuous a) (hapos : ∀ x, 0 < a x) (h : NonlinearResponse a y w)
    (α : ℝ) (hα : 0 < α) :
    storageArea a * minimum α ≤
      miace α (fun t => 1-y t) (fun t => w t-1) halfLine :=
  signal_miace_lower_bound h.error_integrable h.command_integrable α (storageArea a)
    hα (storageArea_pos ha hapos).le (nonlinear_response_signed_balance ha hapos h)

-- @paper-step thm:nonlinear_miace/unsquared_equality
theorem nonlinear_response_miace_equality_iff {a y w : ℝ → ℝ}
    (ha : Continuous a) (hapos : ∀ x, 0 < a x) (h : NonlinearResponse a y w)
    (α : ℝ) (hα : 0 < α) :
    miace α (fun t => 1-y t) (fun t => w t-1) halfLine = storageArea a * minimum α ↔
      (∀ᵐ t ∂halfLine, 0 ≤ 1-y t) ∧ (∀ᵐ t ∂halfLine, 0 ≤ w t-1) ∧
      absArea (fun t => 1-y t) halfLine = α * absArea (fun t => w t-1) halfLine :=
  signal_miace_equality_iff h.error_integrable h.command_integrable α (storageArea a)
    hα (storageArea_pos ha hapos) (nonlinear_response_signed_balance ha hapos h)

-- @paper-step thm:nonlinear_miace/original_MIACE_gap
theorem nonlinear_response_miace_gap {a y w : ℝ → ℝ}
    (ha : Continuous a) (hapos : ∀ x, 0 < a x) (h : NonlinearResponse a y w)
    (α : ℝ) (hα : 0 < α) :
    (miace α (fun t => 1-y t) (fun t => w t-1) halfLine)^2 -
        (storageArea a)^2 * (minimum α)^2 =
      4 * (minimum α)^2 *
        (negArea (fun t => 1-y t) halfLine + negArea (fun t => w t-1) halfLine) *
        (storageArea a + (negArea (fun t => 1-y t) halfLine +
          negArea (fun t => w t-1) halfLine)) +
      (absArea (fun t => 1-y t) halfLine -
        α * absArea (fun t => w t-1) halfLine)^2 / (1+α) := by
  rw [miace_square α _ _ halfLine hα, minimum_square α hα]
  have hg := nonlinear_response_excess ha hapos h α hα
  simpa only [baseSq, mul_div_assoc] using hg

-- @paper-step thm:nonlinear_miace/every_attaining_output_monotone
theorem nonlinear_minimizer_monotone {a y w : ℝ → ℝ}
    (ha : Continuous a) (hapos : ∀ x, 0 < a x) (h : NonlinearResponse a y w)
    (α : ℝ) (hα : 0 < α)
    (hmin : miace α (fun t => 1-y t) (fun t => w t-1) halfLine =
      storageArea a * minimum α) :
    MonotoneOn y (Ici 0) ∧ (∀ t : ℝ, 0 ≤ t → 0 ≤ y t ∧ y t ≤ 1) := by
  obtain ⟨he, hv, _⟩ := (nonlinear_response_miace_equality_iff ha hapos h α hα).mp hmin
  exact ⟨nonlinear_response_output_monotone hapos h he hv,
    fun _ ht => nonlinear_response_output_bounds hapos h he hv ht⟩

-- The reciprocal gain is positive, so the pointwise feedback ratio gives
-- exactly the ratio of the two original absolute areas.
-- @paper-step thm:nonlinear_miace/feedback_optimal_areas
theorem nonlinear_feedback_optimum {a y : ℝ → ℝ}
    (ha : Continuous a) (hapos : ∀ x, 0 < a x) {α : ℝ} (hα : 0 < α)
    (h : NonlinearResponse a y (fun t => 1 + (1-y t)/α))
    (hy : ∀ t, 0 ≤ t → y t ≤ 1) :
    miace α (fun t => 1-y t) (fun t => (1 + (1-y t)/α)-1) halfLine =
        storageArea a * minimum α ∧
      absArea (fun t => 1-y t) halfLine = α * storageArea a / (1+α) ∧
      absArea (fun t => (1 + (1-y t)/α)-1) halfLine = storageArea a / (1+α) := by
  have he : ∀ᵐ t ∂halfLine, 0 ≤ 1-y t := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    linarith [hy t ht.le]
  have hv : ∀ᵐ t ∂halfLine, 0 ≤ (1 + (1-y t)/α)-1 := by
    filter_upwards [he] with t ht
    simpa only [add_sub_cancel_left] using div_nonneg ht hα.le
  have harea : absArea (fun t => (1 + (1-y t)/α)-1) halfLine =
      absArea (fun t => 1-y t) halfLine / α := by
    unfold absArea
    simp_rw [add_sub_cancel_left, abs_div, abs_of_pos hα]
    exact integral_div α _
  have hr : absArea (fun t => 1-y t) halfLine =
      α * absArea (fun t => (1 + (1-y t)/α)-1) halfLine := by
    rw [harea]
    field_simp
  have hb := nonlinear_response_area_balance ha hapos h
  rw [(negative_area_zero_iff h.error_integrable).mpr he,
    (negative_area_zero_iff h.command_integrable).mpr hv] at hb
  simp only [add_zero, mul_zero] at hb
  have har := equality_areas α (storageArea a) _ _ hα hb hr
  exact ⟨(nonlinear_response_miace_equality_iff ha hapos h α hα).mpr ⟨he, hv, hr⟩,
    har.2, har.1⟩

/-- A full attaining feedback witness, including attained extrema of the
positive rate, exponential bounds, exact original-signal areas, and the
finite supremum of the ordinary command. -/
structure NonlinearOptimalFeedback (a : ℝ → ℝ) (α : ℝ)
    (y : ℝ → ℝ) (m M : ℝ) : Prop where
  min_pos : 0 < m
  min_attained : ∃ xm ∈ Icc (0 : ℝ) 1, a xm = m
  max_attained : ∃ xM ∈ Icc (0 : ℝ) 1, a xM = M
  rate_lower : ∀ x ∈ Icc (0 : ℝ) 1, m ≤ a x
  rate_upper : ∀ x ∈ Icc (0 : ℝ) 1, a x ≤ M
  response : NonlinearResponse a y (fun t => 1 + (1-y t)/α)
  transient : ∀ t, 0 ≤ t → 0 ≤ y t ∧ y t < 1 ∧
    Real.exp (-(1+1/α)*M*t) ≤ 1-y t ∧ 1-y t ≤ Real.exp (-(1+1/α)*m*t)
  error_area : absArea (fun t => 1-y t) halfLine = α * storageArea a / (1+α)
  command_area : absArea (fun t => (1 + (1-y t)/α)-1) halfLine = storageArea a / (1+α)
  cost : miace α (fun t => 1-y t) (fun t => (1 + (1-y t)/α)-1) halfLine =
    storageArea a * minimum α
  command_bounds : ∀ t, 0 ≤ t → 1 ≤ 1 + (1-y t)/α ∧ 1 + (1-y t)/α ≤ 1 + 1/α
  command_peak : sSup ((fun t => 1 + (1-y t)/α) '' Ici (0 : ℝ)) = 1 + 1/α

-- @paper-step thm:nonlinear_miace/global_attainment
 theorem nonlinear_optimal_feedback_exists {a : ℝ → ℝ}
    (ha : Continuous a) (hapos : ∀ x, 0 < a x) {α : ℝ} (hα : 0 < α) :
    ∃ y m M, NonlinearOptimalFeedback a α y m M := by
  obtain ⟨m, M, hm, hmin, hmax, hlo, hup⟩ := nonlinear_positive_extrema ha hapos
  obtain ⟨y, hr, hb, hw⟩ := nonlinear_feedback_response ha hapos hα hm hlo hup
  obtain ⟨hc, he, hu⟩ := nonlinear_feedback_optimum ha hapos hα hr
    (fun t ht => (hb t ht).2.1.le)
  exact ⟨y, m, M, hm, hmin, hmax, hlo, hup, hr, hb, he, hu, hc, hw,
    nonlinear_feedback_peak hα hr.initial (fun t ht => (hb t ht).1)⟩

-- The minimum is a member of the actual attainable-cost set, not only an
-- infimum or a conditional lower bound.
-- @paper-step thm:nonlinear_miace/global_minimum
theorem nonlinear_miace_global_minimum {a : ℝ → ℝ}
    (ha : Continuous a) (hapos : ∀ x, 0 < a x) {α : ℝ} (hα : 0 < α) :
    IsLeast {C : ℝ | ∃ y w : ℝ → ℝ, NonlinearResponse a y w ∧
        C = miace α (fun t => 1-y t) (fun t => w t-1) halfLine}
      (storageArea a * minimum α) := by
  obtain ⟨y, m, M, hw⟩ := nonlinear_optimal_feedback_exists ha hapos hα
  constructor
  · exact ⟨y, (fun t => 1 + (1-y t)/α), hw.response, hw.cost.symm⟩
  · rintro C ⟨z, w, hr, rfl⟩
    exact nonlinear_response_miace_lower_bound ha hapos hr α hα

-- This is the complete numbered statement under the manuscript's locally
-- Lipschitz hypothesis. The constituent results above in fact need only
-- continuity and positivity. Existence is constructed by an inverse clock;
-- it is not an assumption and makes no claim of uniqueness of all minimizers.
-- @paper-step thm:nonlinear_miace/full_statement
theorem paper_nonlinear_miace {a y w : ℝ → ℝ}
    (ha : LocallyLipschitz a) (hapos : ∀ x, 0 < a x)
    (h : NonlinearResponse a y w) (α : ℝ) (hα : 0 < α) :
    0 < storageArea a ∧
    ((∫ t, (1-y t) ∂halfLine) + (∫ t, (w t-1) ∂halfLine) = storageArea a) ∧
    (absArea (fun t => 1-y t) halfLine + absArea (fun t => w t-1) halfLine =
      storageArea a + 2 * (negArea (fun t => 1-y t) halfLine +
        negArea (fun t => w t-1) halfLine)) ∧
    ((miace α (fun t => 1-y t) (fun t => w t-1) halfLine)^2 -
        (storageArea a)^2 * (minimum α)^2 =
      4 * (minimum α)^2 *
        (negArea (fun t => 1-y t) halfLine + negArea (fun t => w t-1) halfLine) *
        (storageArea a + (negArea (fun t => 1-y t) halfLine +
          negArea (fun t => w t-1) halfLine)) +
      (absArea (fun t => 1-y t) halfLine -
        α * absArea (fun t => w t-1) halfLine)^2 / (1+α)) ∧
    (storageArea a * minimum α ≤
      miace α (fun t => 1-y t) (fun t => w t-1) halfLine) ∧
    (miace α (fun t => 1-y t) (fun t => w t-1) halfLine = storageArea a * minimum α ↔
      (∀ᵐ t ∂halfLine, 0 ≤ 1-y t) ∧ (∀ᵐ t ∂halfLine, 0 ≤ w t-1) ∧
      absArea (fun t => 1-y t) halfLine = α * absArea (fun t => w t-1) halfLine) ∧
    (miace α (fun t => 1-y t) (fun t => w t-1) halfLine = storageArea a * minimum α →
      MonotoneOn y (Ici 0) ∧ (∀ t : ℝ, 0 ≤ t → 0 ≤ y t ∧ y t ≤ 1)) ∧
    IsLeast {C : ℝ | ∃ z u : ℝ → ℝ, NonlinearResponse a z u ∧
        C = miace α (fun t => 1-z t) (fun t => u t-1) halfLine}
      (storageArea a * minimum α) ∧
    (∃ z m M, NonlinearOptimalFeedback a α z m M) := by
  have hc : Continuous a := ha.continuous
  exact ⟨storageArea_pos hc hapos, nonlinear_response_signed_balance hc hapos h,
    nonlinear_response_area_balance hc hapos h, nonlinear_response_miace_gap hc hapos h α hα,
    nonlinear_response_miace_lower_bound hc hapos h α hα,
    nonlinear_response_miace_equality_iff hc hapos h α hα,
    nonlinear_minimizer_monotone hc hapos h α hα,
    nonlinear_miace_global_minimum hc hapos hα,
    nonlinear_optimal_feedback_exists hc hapos hα⟩

end MIACE
