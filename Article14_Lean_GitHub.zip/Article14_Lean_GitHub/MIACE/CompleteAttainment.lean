import MIACE.IMCNominal

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:command_cone/every_front_area_has_stable_feedback
theorem paper_cascade_front_realization (N : ℕ) (σ : ℕ → ℝ) {δ U : ℝ}
    (hδ : 0≤δ) (hU : 0≤U) (hU1 : U<1)
    (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1) :
    ∃ F : IMCFilter, ∃ v : ℝ → ℝ, NominalCascadeIMC N σ F δ v ∧
      (∀ t, 0≤v t) ∧ (∀ t, 0≤t → 0≤cascadeStepError N σ δ v t) ∧
      Monotone (fun t => 1-cascadeStepError N σ δ v t) ∧
      1-cascadeStepError N σ δ v 0=0 ∧
      Tendsto (fun t => 1-cascadeStepError N σ δ v t) atTop (𝓝 1) ∧
      absArea v halfLine=U ∧
      absArea (cascadeStepError N σ δ v) halfLine=cascadeMean σ (N+1)+δ-U := by
  have ha : 0<1-U := by linarith
  have ha1 : 1-U≤1 := by linarith
  have hh := cascade_exponential_family N σ hδ ha ha1 hσ hfirst
  refine ⟨exponentialIMC (1-U) ha,imcExcess (1-U),
    exponential_cascade_IMC N σ hδ ha ha1 hσ hfirst,
    hh.2.2.2.2.2.2.1,hh.2.2.2.2.2.2.2.1,hh.2.1,hh.2.2.1,hh.2.2.2.1,?_,?_⟩
  · simpa only [sub_sub_cancel] using hh.2.2.2.2.1
  · have he : absArea (cascadeStepError N σ δ (imcExcess (1-U))) halfLine=
        cascadeMean σ (N+1)+δ-(1-(1-U)) := hh.2.2.2.2.2.1
    simpa only [sub_sub_cancel] using he

-- @paper-step thm:complete_attainment/optimal_family_parameter
theorem optimal_imc_parameter {α S : ℝ} (hα : 0<α) (hS : 0<S) (h : S-1<α) :
    0<1-S/(1+α) ∧ 1-S/(1+α)<1 := by
  have hd : 0<1+α := by linarith
  have hU : 0<S/(1+α) := div_pos hS hd
  have hU1 : S/(1+α)<1 := (div_lt_one hd).mpr (by linarith)
  constructor <;> linarith

-- @paper-step thm:complete_attainment/exact_optimal_family_cost_and_peak
theorem paper_optimal_exponential_IMC (N : ℕ) (σ : ℕ → ℝ) {δ α : ℝ}
    (hδ : 0≤δ) (hα : 0<α) (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1)
    (hthreshold : cascadeMean σ (N+1)+δ-1<α) :
    let S := cascadeMean σ (N+1)+δ
    let a := 1-S/(1+α)
    ∃ ha : 0<a, NominalCascadeIMC N σ (exponentialIMC a ha) δ (imcExcess a) ∧
      miace α (cascadeStepError N σ δ (imcExcess a)) (imcExcess a) halfLine=S*minimum α ∧
      absArea (imcExcess a) halfLine=S/(1+α) ∧
      absArea (cascadeStepError N σ δ (imcExcess a)) halfLine=α*S/(1+α) ∧
      1+imcExcess a 0=1/a ∧ (∀ t, 0≤t → 1+imcExcess a t≤1/a) := by
  let S := cascadeMean σ (N+1)+δ
  have hS : 0<S := by
    have := cascadeMean_ge_one N σ (fun j hj => (hσ j hj).1) hfirst
    dsimp [S]; linarith
  let a := 1-S/(1+α)
  have ha := optimal_imc_parameter hα hS hthreshold
  have hh := cascade_exponential_family N σ hδ ha.1 ha.2.le hσ hfirst
  have hbal := transfer_signed_balance hh.1 (cascadeMean σ (N+1))
    (cascadeTransfer_derivative σ (N+1)) (cascadeTransfer_zero σ (N+1))
  have he : ∀ᵐ t ∂halfLine, 0≤cascadeStepError N σ δ (imcExcess a) t := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact hh.2.2.2.2.2.2.2.1 t (show 0<t from ht).le
  have hv : ∀ᵐ t ∂halfLine, 0≤ imcExcess a t := ae_of_all _ hh.2.2.2.2.2.2.1
  have huarea : absArea (imcExcess a) halfLine=S/(1+α) := by
    rw [hh.2.2.2.2.1]; ring
  have hearea : absArea (cascadeStepError N σ δ (imcExcess a)) halfLine=α*S/(1+α) := by
    have he : absArea (cascadeStepError N σ δ (imcExcess a)) halfLine=S-(1-a) := hh.2.2.2.2.2.1
    rw [he]
    dsimp [a]
    have hd : 1+α≠0 := by linarith
    field_simp <;> ring
  refine ⟨ha.1,exponential_cascade_IMC N σ hδ ha.1 ha.2.le hσ hfirst,?_,huarea,hearea,
    hh.2.2.2.2.2.2.2.2.1,hh.2.2.2.2.2.2.2.2.2⟩
  apply (signal_miace_equality_iff hh.1.error_integrable hh.1.command_integrable α S hα hS hbal).mpr
  refine ⟨he,hv,?_⟩
  change absArea (cascadeStepError N σ δ (imcExcess a)) halfLine=α*absArea (imcExcess a) halfLine
  rw [huarea,hearea]
  ring

-- @paper-step thm:complete_attainment/full_attainment_equivalence
theorem paper_complete_attainment (N : ℕ) (σ : ℕ → ℝ) {δ α : ℝ}
    (hδ : 0≤δ) (hα : 0<α) (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1) :
    (∃ F : IMCFilter, ∃ v : ℝ → ℝ, NominalCascadeIMC N σ F δ v ∧
      miace α (cascadeStepError N σ δ v) v halfLine=(cascadeMean σ (N+1)+δ)*minimum α) ↔
    cascadeMean σ (N+1)+δ-1<α := by
  have hS : 0<cascadeMean σ (N+1)+δ := by
    have := cascadeMean_ge_one N σ (fun j hj => (hσ j hj).1) hfirst
    linarith
  constructor
  · rintro ⟨F,v,hv,heq⟩
    have hu : LocallyIntegrable (fun t => 1+v t) volume :=
      (continuous_const : Continuous (fun _ : ℝ => (1 : ℝ))).locallyIntegrable.add hv.command_integrable.locallyIntegrable
    have hP := ordinaryCascade_transfer_response hv.command_integrable σ (N+1)
      (fun j hj => (hσ j (by omega)).1) hδ
    exact (paper_cascade_necessary N σ (ordinaryCascade σ (fun t => 1+v t)) δ α
      (cascadeMean σ (N+1)) hδ hα hS hσ hfirst (fun j _ => ordinaryCascade_response hu σ j)
      rfl hP (cascadeTransfer_derivative σ (N+1)) (cascadeTransfer_zero σ (N+1)) heq).1
  · intro ht
    obtain ⟨ha,hF,heq,_⟩ := paper_optimal_exponential_IMC N σ hδ hα hσ hfirst ht
    exact ⟨_,_,hF,heq⟩

-- @paper-step thm:complete_cap/actual_cascade_nonovershoot_implies_moment
theorem cascade_nonovershoot_moment (N : ℕ) (σ : ℕ → ℝ) {δ : ℝ} {v : ℝ → ℝ}
    (hδ : 0≤δ) (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1)
    (hv : Integrable v) (hn : ∀ᵐ t ∂halfLine, 0≤v t)
    (he : ∀ t, 0≤t → 0≤cascadeStepError N σ δ v t) :
    Integrable (fun t => Real.exp t*v t) halfLine ∧ moment v≤1 := by
  have hu : LocallyIntegrable (fun t => 1+v t) volume :=
    (continuous_const : Continuous (fun _ : ℝ => (1 : ℝ))).locallyIntegrable.add hv.locallyIntegrable
  have hP := ordinaryCascade_transfer_response hv σ (N+1) (fun j hj => (hσ j (by omega)).1) hδ
  apply (cascade_signal_cone N σ (ordinaryCascade σ (fun t => 1+v t)) hδ hσ hfirst
    (fun j _ => ordinaryCascade_response hu σ j) rfl hP.command_integrable hn hP.error_integrable).1.mp
  intro t ht
  have hh := he t ht
  change 1-cascadeStepError N σ δ v t≤1
  linarith

end MIACE
