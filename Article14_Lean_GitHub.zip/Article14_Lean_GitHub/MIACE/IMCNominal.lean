import MIACE.IMCInternal

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

def zeroIMCHistory : IMCHistory where
  plantInitial := fun _ => 0
  modelInitial := fun _ => 0
  filterInitial := 0
  plantPast := fun _ => 0
  modelPast := fun _ => 0
  filterPast := fun _ => 0

noncomputable def imcReferenceFeedback (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) (δ ε : ℝ)
    (H : IMCHistory) (r u : ℝ → ℝ) (t : ℝ) : ℝ :=
  filterAction F (fun s => r s+imcFilterInput N σ δ ε H u s) t+filterFreeOutput F H t

-- @paper-step thm:complete_attainment/nominal_reference_feedback_identity
theorem imc_nominal_reference (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) (δ : ℝ)
    (r u : ℝ → ℝ) :
    imcReferenceFeedback N σ F δ 0 zeroIMCHistory r u=filterAction F r := by
  have hq : (fun s => r s+imcFilterInput N σ δ 0 zeroIMCHistory u s)=r := by
    funext s
    simp [imcFilterInput,zeroIMCHistory]
  funext t
  change filterAction F (fun s => r s+imcFilterInput N σ δ 0 zeroIMCHistory u s) t+
    filterFreeOutput F zeroIMCHistory t=filterAction F r t
  rw [hq]
  simp [filterFreeOutput,zeroIMCHistory,historyInput]

-- @paper-step thm:complete_attainment/nominal_ordinary_step_realization
theorem imc_nominal_step_realization (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) (δ : ℝ)
    {v : ℝ → ℝ} (hstep : filterAction F unitStep=ᵐ[halfLine] (fun t => 1+v t)) :
    causalize (fun t => 1+v t)=ᵐ[volume]
      imcReferenceFeedback N σ F δ 0 zeroIMCHistory unitStep (causalize (fun t => 1+v t)) := by
  rw [imc_nominal_reference]
  exact (causalize_of_halfLine_eq (filterAction_causal F (causalize_causal _)) hstep).symm

noncomputable def cascadeStepError (N : ℕ) (σ : ℕ → ℝ) (δ : ℝ) (v : ℝ → ℝ) : ℝ → ℝ :=
  delayedError δ (fun t => 1-ordinaryCascade σ (fun s => 1+v s) (N+1) t)

structure NominalCascadeIMC (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) (δ : ℝ) (v : ℝ → ℝ) : Prop where
  command_integrable : Integrable v
  step_filter : filterAction F unitStep=ᵐ[halfLine] (fun t => 1+v t)
  internal_stability : IMCInternallyStable N σ F δ 0

-- @paper-step thm:complete_attainment/explicit_stable_exponential_controller_family
theorem exponential_cascade_IMC (N : ℕ) (σ : ℕ → ℝ) {δ a : ℝ}
    (hδ : 0≤δ) (ha : 0<a) (ha1 : a≤1)
    (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1) :
    NominalCascadeIMC N σ (exponentialIMC a ha) δ (imcExcess a) := by
  refine ⟨(imcExcess_properties ha ha1).1,?_,imc_nominal_internal_stability N σ _ hδ hσ hfirst⟩
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  exact exponentialIMC_step ha (show 0<t from ht).le

-- @paper-step thm:complete_cap/explicit_stable_pulse_controller_family
theorem pulse_cascade_IMC (N : ℕ) (σ : ℕ → ℝ) {δ T : ℝ} (c : ℝ)
    (hδ : 0≤δ) (hT : 0≤T) (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1) :
    NominalCascadeIMC N σ (pulseIMC c T hT) δ (pulse c T) :=
  ⟨pulse_full_integrable c T,pulseIMC_step c hT,imc_nominal_internal_stability N σ _ hδ hσ hfirst⟩

-- @paper-step thm:complete_attainment/normalized_mean_positive
theorem cascadeMean_ge_one (N : ℕ) (σ : ℕ → ℝ)
    (hσ : ∀ j≤N, 0<σ j) (hfirst : σ 0=1) : 1≤cascadeMean σ (N+1) := by
  induction N with
  | zero => simp [cascadeMean,hfirst]
  | succ N ih =>
    have hp := ih (fun j hj => hσ j (by omega))
    have hs := hσ (N+1) le_rfl
    have he : cascadeMean σ (N+1+1)=cascadeMean σ (N+1)+σ (N+1) := by
      simp [cascadeMean,Finset.sum_range_succ]
    rw [he]
    linarith

-- @paper-step thm:complete_attainment/actual_cascade_ordinary_signal_front
theorem cascade_front_signals (N : ℕ) (σ : ℕ → ℝ) {δ : ℝ} {v : ℝ → ℝ}
    (hδ : 0≤δ) (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1)
    (hv : Integrable v) (hn : ∀ᵐ t ∂halfLine, 0≤v t)
    (hJ : Integrable (fun t => Real.exp t*v t) halfLine) (hm : moment v≤1) :
    TransferResponse (cascadeStepError N σ δ v) v (cascadeTransfer σ (N+1)) δ ∧
      Monotone (fun t => 1-cascadeStepError N σ δ v t) ∧
      1-cascadeStepError N σ δ v 0=0 ∧
      Tendsto (fun t => 1-cascadeStepError N σ δ v t) atTop (𝓝 1) ∧
      (∀ t, 0≤t → 0≤cascadeStepError N σ δ v t) ∧
      absArea v halfLine=commandArea v ∧
      absArea (cascadeStepError N σ δ v) halfLine=cascadeMean σ (N+1)+δ-commandArea v := by
  have hP := ordinaryCascade_transfer_response hv σ (N+1) (fun j hj => (hσ j (by omega)).1) hδ
  have hu : LocallyIntegrable (fun t => 1+v t) volume :=
    (continuous_const : Continuous (fun _ : ℝ => (1 : ℝ))).locallyIntegrable.add hv.locallyIntegrable
  have hc := cascade_signal_cone N σ (ordinaryCascade σ (fun t => 1+v t)) hδ hσ hfirst
    (fun j _ => ordinaryCascade_response hu σ j) rfl hP.command_integrable hn hP.error_integrable
  have hs := hc.2.mpr ⟨hJ,hm⟩
  have hb := hc.1.mpr ⟨hJ,hm⟩
  have hA := cascade_cone_areas N σ _ hδ hσ hfirst (fun j _ => ordinaryCascade_response hu σ j)
    rfl hP (cascadeTransfer_derivative σ (N+1)) (cascadeTransfer_zero σ (N+1)) hn hJ hm
  exact ⟨hP,hs.1,hs.2.1,hs.2.2,fun t ht => by
    have hh : 1-cascadeStepError N σ δ v t≤1 := hb t ht
    linarith,hA.2.2.1,hA.2.2.2⟩

-- @paper-step thm:complete_cap/actual_pulse_cascade_front
theorem cascade_pulse_family (N : ℕ) (σ : ℕ → ℝ) {δ c U : ℝ}
    (hδ : 0≤δ) (hc : 0<c) (hU : 0≤U) (hcap : U≤c*Real.log (1+1/c))
    (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1) :
    let v := pulse c (U/c)
    TransferResponse (cascadeStepError N σ δ v) v (cascadeTransfer σ (N+1)) δ ∧
      Monotone (fun t => 1-cascadeStepError N σ δ v t) ∧
      1-cascadeStepError N σ δ v 0=0 ∧
      Tendsto (fun t => 1-cascadeStepError N σ δ v t) atTop (𝓝 1) ∧
      (∀ t, 0≤t → 0≤cascadeStepError N σ δ v t) ∧
      absArea v halfLine=U ∧
      absArea (cascadeStepError N σ δ v) halfLine=cascadeMean σ (N+1)+δ-U ∧
      (∀ᵐ t ∂halfLine, 0≤v t ∧ v t≤c) := by
  have hp := cap_area_sufficient c U hc hU hcap
  have hh := cascade_front_signals N σ hδ hσ hfirst (pulse_full_integrable c (U/c))
    (hp.2.2.1.mono (fun _ ht => ht.1)) hp.2.1 hp.2.2.2.2
  exact ⟨hh.1,hh.2.1,hh.2.2.1,hh.2.2.2.1,hh.2.2.2.2.1,
    hh.2.2.2.2.2.1.trans hp.2.2.2.1,by rw [hh.2.2.2.2.2.2,hp.2.2.2.1],hp.2.2.1⟩

end MIACE
