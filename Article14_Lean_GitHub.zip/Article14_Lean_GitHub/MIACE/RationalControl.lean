import MIACE.RationalHistory

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

structure RationalHistoryBound (n : ℕ) (δ : ℝ) (H : RationalHistory) (M : ℝ) : Prop where
  nonneg : 0≤M
  command : |H.commandInitial|≤M
  controller : ∀ j≤n, |H.controllerInitial j|≤M
  plant : ∀ j≤n, |H.plantInitial j|≤M
  output : |H.outputInitial|≤M
  continuous : ContinuousOn H.past (Icc (-δ) 0)
  past : ∀ s∈Icc (-δ) 0, |H.past s|≤M

structure RationalInternalControl (r : ℕ → ℝ) (n : ℕ) (δ : ℝ) (H : RationalHistory)
    (w : ℝ → ℝ) (η C : ℝ) : Prop where
  command : WeightedControl η (causalize w) C
  controller : ∀ j≤n, WeightedControl η (causalize (rationalIState r δ H w j)) C
  plant : ∀ j≤n, WeightedControl η (causalize (rationalBState r δ H w j)) C
  output : WeightedControl η (causalize (rationalOutput r n δ H w)) C

-- All constants precede the history quantifier. Initial plant/controller
-- states and the complete transport history can vary independently.
-- @paper-step thm:n_construction/arbitrary_full_rational_state_exponential_estimate
theorem rational_history_uniform_exists (r : ℕ → ℝ) (n : ℕ) {δ a c η C : ℝ}
    (hr : ∀ j≤n, 0<r j ∧ η<r j) (hδ : 0≤δ) (ha : 0<a)
    (hη : 0≤η) (hη1 : η<1) {R : ℝ → ℝ} (hRi : Integrable R) (hRc : Causal R)
    (hRw : WeightedControl η R C)
    (hInv : ∀ p : ℝ, 0<p → (a*p+c+(-1 : ℝ)^(n+1)*
      compactExpMoment (remainderJ r n δ) δ (-p))*laplace R p=1) :
    ∃ D : ℝ, 0≤D ∧ ∀ M H, RationalHistoryBound n δ H M →
      ∃ w : ℝ → ℝ, RationalHistoryEvolution r n δ a c H w ∧
        RationalInternalControl r n δ H w η (D*M) := by
  obtain ⟨CI,hCI,hI⟩ := remainderFilter_uniform_control r δ η n hr
  have hs : ∀ j<n+1, 0<1/r j ∧ η<1/(1/r j) := by
    intro j hj
    exact ⟨one_div_pos.mpr (hr j (by omega)).1,by simpa using (hr j (by omega)).2⟩
  obtain ⟨CB,hCB,hB⟩ := serialState_uniform_control (fun j => 1/r j) (n+1) η hs
  obtain ⟨CY,hCY⟩ := lagKernel_weightedControl (show (0 : ℝ)<1 from zero_lt_one) (by simpa using hη1)
  let P := (δ+1)*Real.exp (η*δ)
  let F := CI+CB*(1+P)
  let W := C*(a+F)
  let I := CI*(1+W)
  let B := CB*(1+P+Real.exp (η*δ)*W)
  let Y := CY*(1+B)
  let D := W+I+B+Y
  have hP : 0≤P := by dsimp [P]; positivity
  have hF : 0≤F := by dsimp [F]; positivity
  have hW : 0≤W := by dsimp [W]; have := hRw.nonneg; positivity
  have hIpos : 0≤I := by dsimp [I]; positivity
  have hBpos : 0≤B := by dsimp [B]; positivity
  have hY : 0≤Y := by dsimp [Y]; have := hCY.nonneg; positivity
  refine ⟨D,by dsimp [D]; positivity,?_⟩
  intro M H hH
  have hhist : WeightedControl η (historyInput δ H.past) (P*M) :=
    historyInput_control_on hδ hη hH.nonneg hH.continuous hH.past
  have hhistC := weightedControl_congr hhist (causalize_eq_ae (historyInput_causal δ H.past)).symm
  have hHi := weightedControl_unweighted hhist (historyInput_causal δ H.past) hη
  have hzero : WeightedControl η (causalize (fun _ => 0)) 0 := by
    simpa [causalize] using weightedControl_zero η
  have hIz := hI M 0 hH.nonneg H.controllerInitial hH.controller (fun _ => 0) hzero n le_rfl
  have hBh := hB M (P*M) hH.nonneg H.plantInitial (fun j hj => hH.plant j (by omega))
    (historyInput δ H.past) hhistC (n+1) le_rfl
  have hfree : WeightedControl η (rationalFree r n δ H) (F*M) := by
    have hh := causal_linear_control hIz hBh 1 (-1)
    simp only [abs_one,abs_neg,one_mul,neg_one_mul] at hh
    convert hh using 1
    · rfl
    · dsimp [F]; ring
  have hfreeC : Causal (rationalFree r n δ H) := causalize_causal _
  obtain ⟨w,he,hw,_⟩ := compact_forced_exists (remainderJ_continuous r n δ) hδ ha hη
    hRi hRc hRw hInv (rationalFree r n δ H) H.commandInitial (F*M) hfreeC hfree
  have hw' : WeightedControl η (causalize w) (W*M) := by
    apply weightedControl_mono hw
    rw [abs_mul,abs_of_pos ha]
    dsimp [W]
    have hh := mul_le_mul_of_nonneg_left hH.command (mul_nonneg hRw.nonneg ha.le)
    nlinarith
  have hwi := weightedControl_unweighted hw' (causalize_causal w) hη
  have hdel : WeightedControl η (rationalDelayed δ H w) ((P+Real.exp (η*δ)*W)*M) := by
    have hh := weightedControl_add hhist (weightedControl_shift hw' δ)
    convert hh using 1
    · rfl
    · ring
  have hdelC : Causal (rationalDelayed δ H w) := by
    filter_upwards [historyInput_causal δ H.past,causal_shift (causalize_causal w) hδ] with t ht hs hn
    change historyInput δ H.past t+shift δ (causalize w) t=0
    rw [ht hn,hs hn,add_zero]
  have hdelCC := weightedControl_congr hdel (causalize_eq_ae hdelC).symm
  have hi (j : ℕ) (hj : j≤n) : WeightedControl η (causalize (rationalIState r δ H w j)) (I*M) := by
    have hh := hI M (W*M) hH.nonneg H.controllerInitial hH.controller w hw' j hj
    convert hh using 1
    · rfl
    · dsimp [I]; ring
  have hb (j : ℕ) (hj : j≤n) : WeightedControl η (causalize (rationalBState r δ H w j)) (B*M) := by
    have hh := hB M ((P+Real.exp (η*δ)*W)*M) hH.nonneg H.plantInitial
      (fun j hj => hH.plant j (by omega)) (rationalDelayed δ H w) hdelCC (j+1) (by omega)
    convert hh using 1
    · rfl
    · dsimp [B]; ring
  have hy : WeightedControl η (causalize (rationalOutput r n δ H w)) (Y*M) := by
    have hh := lagState_weighted_control (show (0 : ℝ)<1 from zero_lt_one) hCY (hb n le_rfl) H.outputInitial
    apply weightedControl_mono hh
    simp only [mul_one]
    dsimp [Y]
    nlinarith [mul_le_mul_of_nonneg_right hH.output hCY.nonneg]
  refine ⟨w,compact_restores_rational r n (fun j hj => (hr j hj).1) hδ H hHi hwi he,?_⟩
  have hWM : W*M≤D*M := mul_le_mul_of_nonneg_right (by dsimp [D]; linarith) hH.nonneg
  have hIM : I*M≤D*M := mul_le_mul_of_nonneg_right (by dsimp [D]; linarith) hH.nonneg
  have hBM : B*M≤D*M := mul_le_mul_of_nonneg_right (by dsimp [D]; linarith) hH.nonneg
  have hYM : Y*M≤D*M := mul_le_mul_of_nonneg_right (by dsimp [D]; linarith) hH.nonneg
  exact ⟨weightedControl_mono hw' hWM,fun j hj => weightedControl_mono (hi j hj) hIM,
    fun j hj => weightedControl_mono (hb j hj) hBM,weightedControl_mono hy hYM⟩

-- @paper-step thm:n_construction/parity_conditions_give_full_state_decay_existence
theorem rational_parity_full_state_exists (r : ℕ → ℝ) (n : ℕ) {δ U : ℝ}
    (hr : ∀ j≤n, 0<r j) (hδ : 0≤δ)
    (ha : 0<rationalCascadeA r n δ U) (ha1 : rationalCascadeA r n δ U<1)
    (hpar : CascadeParityTest (remainderJ r n δ) δ (rationalCascadeA r n δ U) ((-1 : ℝ)^(n+1))) :
    ∃ η D : ℝ, 0<η ∧ 0≤D ∧ ∀ M H, RationalHistoryBound n δ H M →
      ∃ w : ℝ → ℝ, RationalHistoryEvolution r n δ (rationalCascadeA r n δ U)
        (rationalCascadeC r n δ) H w ∧ RationalInternalControl r n δ H w η (D*M) := by
  obtain ⟨R,hR,hRi,⟨β,C,hβ,hC,hRw,hdec⟩,_,_,hInv,_⟩ :=
    rationalCascade_resolvent_and_command r n hr hδ ha ha1 hpar
  obtain ⟨η,hη,hηβ,hη1,hηr⟩ := finite_decay_rate r n hr hβ
  have hw := weightedControl_lower (ordinary_resolvent_control hC hRw hdec) (causalize_causal R) hη.le hηβ
  have hi (p : ℝ) (hp : 0<p) := hInv p hp.le
  simp only [← laplace_causalize R] at hi
  obtain ⟨D,hD,hh⟩ := rational_history_uniform_exists r n (fun j hj => ⟨hr j hj,hηr j hj⟩)
    hδ ha hη.le hη1 hRi (causalize_causal R) hw hi
  exact ⟨η,D,hη,hD,hh⟩

end MIACE
