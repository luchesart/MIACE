import MIACE.DelayedPISufficiency
import MIACE.Lemma6Completion

/-! Stage 19. The exact closed PI attainment interval, parameter uniqueness,
actual all-history stability, and the ordinary optimal response. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:delayed_optimum/necessary_and_sufficient_attainment_interval
theorem paper_delayed_PI_attainment_iff {α δ : ℝ} (hα : 0<α) (hδ : 0≤δ) :
    (∃ x r : ℝ, 0<x ∧ 0<r ∧ ∃ E V : ℝ → ℝ, IdealPIResponse x r δ E V ∧
      miace α E V halfLine=(1+δ)*minimum α) ↔ δ≤delayedPIMaxDelay α := by
  constructor
  · rintro ⟨x,r,hx,hr,E,V,h,hcost⟩
    obtain ⟨_,hx1,hb,hgain⟩ := attaining_PI_necessary h hx hr hα hδ hcost
    exact (delayedPI_range_iff hα hδ).mp (by simpa only [hgain,delayedPIGain] using And.intro hx1 hb)
  · intro hrange
    obtain ⟨E,V,h,_,_,hc,_⟩ := delayedPI_optimum_exists hα hδ hrange
    exact ⟨delayedPIGain α δ,1,delayedPIGain_pos hα hδ,by norm_num,E,V,h,hc⟩

-- @paper-step thm:delayed_optimum/uniqueness_of_positive_optimal_PI_parameters
theorem delayedPI_optimal_parameters_unique {x r δ α : ℝ} {E V : ℝ → ℝ}
    (h : IdealPIResponse x r δ E V) (hx : 0<x) (hr : 0<r) (hα : 0<α) (hδ : 0≤δ)
    (hc : miace α E V halfLine=(1+δ)*minimum α) :
    r=1 ∧ x=delayedPIGain α δ := by
  have hh := attaining_PI_necessary h hx hr hα hδ hc
  exact ⟨hh.1,hh.2.2.2⟩

-- @paper-step thm:delayed_optimum/full_internal_stability_of_the_attaining_controller
theorem delayedPI_optimal_internal_stability {α δ : ℝ} (hα : 0<α) (hδ : 0≤δ)
    (hrange : δ≤delayedPIMaxDelay α) :
    DelayedPIAsymptoticallyStable (delayedPIGain α δ) δ := by
  apply (delayedPI_internal_stability_iff (delayedPIGain_pos hα hδ) hδ).mpr
  have hb := ((delayedPI_range_iff hα hδ).mpr hrange).2
  have he : Real.exp (-1 : ℝ)<1 := Real.exp_lt_one_iff.mpr (by norm_num)
  have hp := Real.two_le_pi
  linarith

-- @paper-step thm:delayed_optimum/paper_theorem7_all_clauses
theorem paper_delayed_PI_optimum {α δ : ℝ} (hα : 0<α) (hδ : 0≤δ) :
    ((∃ x r : ℝ, 0<x ∧ 0<r ∧ ∃ E V : ℝ → ℝ, IdealPIResponse x r δ E V ∧
      miace α E V halfLine=(1+δ)*minimum α) ↔ δ≤delayedPIMaxDelay α) ∧
    (∀ x r : ℝ, ∀ E V : ℝ → ℝ, IdealPIResponse x r δ E V → 0<x → 0<r →
      miace α E V halfLine=(1+δ)*minimum α → r=1 ∧ x=delayedPIGain α δ) ∧
    (δ≤delayedPIMaxDelay α →
      DelayedPIAsymptoticallyStable (delayedPIGain α δ) δ ∧
      ∃ E V : ℝ → ℝ, IdealPIResponse (delayedPIGain α δ) 1 δ E V ∧
        absArea E halfLine=α*(1+δ)/(1+α) ∧ absArea V halfLine=(1+δ)/(1+α) ∧
        miace α E V halfLine=(1+δ)*minimum α ∧
        MonotoneOn (fun t => 1-E t) (Ici 0) ∧ 1-E 0=0 ∧
        Tendsto (fun t => 1-E t) atTop (𝓝 1) ∧
        ∀ e v : ℝ → ℝ, TransferResponse e v (fun p => 1/(1+p)) δ →
          miace α E V halfLine≤miace α e v halfLine) := by
  exact ⟨paper_delayed_PI_attainment_iff hα hδ,
    fun x r E V hp hx hr hc => delayedPI_optimal_parameters_unique hp hx hr hα hδ hc,
    fun hh => ⟨delayedPI_optimal_internal_stability hα hδ hh,delayedPI_optimum_exists hα hδ hh⟩⟩

end MIACE
