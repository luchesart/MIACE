import MIACE.PhysicalEvolution

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:pid_two_rate_optimum/finite_history_continuous_extension
theorem history_continuous_extension {φ : ℝ → Fin 3 → ℝ} {δ : ℝ} (hδ : 0≤δ)
    (hφ : ∀ k, ContinuousOn (fun t => φ t k) (Icc (-δ) 0)) :
    ∃ ψ : ℝ → Fin 3 → ℝ, (∀ k, Continuous (fun t => ψ t k)) ∧
      ∀ t∈Icc (-δ) 0, ψ t=φ t := by
  let q := fun t : ℝ => max (-δ) (min 0 t)
  have hq : Continuous q := continuous_const.max (continuous_const.min continuous_id)
  have hmem (t : ℝ) : q t∈Icc (-δ) 0 :=
    ⟨le_max_left _ _,max_le (by linarith) (min_le_left _ _)⟩
  refine ⟨fun t => φ (q t),fun k => (hφ k).comp_continuous hq hmem,?_⟩
  intro t ht
  have he : q t=t := by dsimp [q]; rw [min_eq_right ht.2,max_eq_right ht.1]
  change φ (q t)=φ t
  rw [he]

-- @paper-step thm:pid_two_rate_optimum/physical_evolution_history_locality
theorem pid_history_evolution_congr {i ρ ell δ : ℝ} {φ ψ x : ℝ → Fin 3 → ℝ}
    (hδ : 0≤δ) (he : ∀ t∈Icc (-δ) 0, φ t=ψ t)
    (h : PIDHistoryEvolution i ρ ell δ φ x) : PIDHistoryEvolution i ρ ell δ ψ x := by
  have h0 : φ 0=ψ 0 := he 0 ⟨by linarith,le_rfl⟩
  have hforce : pidHistoryForcing i ρ ell δ φ=pidHistoryForcing i ρ ell δ ψ := by
    apply historyInput_congr
    intro t ht
    unfold pidCommand
    rw [he t ht]
  exact {h with initial := h.initial.trans h0,plant := by simpa only [hforce] using h.plant}

-- @paper-step thm:pid_two_rate_optimum/physical_history_actual_delayed_equation
theorem pid_history_actual_plant {i ρ ell δ : ℝ} {φ x : ℝ → Fin 3 → ℝ}
    (h : PIDHistoryEvolution i ρ ell δ φ x) :
    ∀ᵐ t, 0<t → HasDerivAt (fun s => x s 0)
      (-x t 0+pidCommand i ρ ell (spliceHistory φ x) (t-δ)) t := by
  filter_upwards [h.plant] with t ht hp
  rw [pid_history_transport i ρ ell δ φ x hp.le,← add_assoc]
  exact ht hp

end MIACE
