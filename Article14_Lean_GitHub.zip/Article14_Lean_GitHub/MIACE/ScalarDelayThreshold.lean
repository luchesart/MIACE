import MIACE.ScalarDelaySpectrum
import Mathlib.Analysis.SpecialFunctions.Exp

/-! The real characteristic root is obtained by an intermediate value
argument, including the double-root endpoint and zero delay. -/
namespace MIACE
open Set

-- @paper-step lem:delayed_cancellation/exact_positive_tilt_threshold
theorem scalarDelay_tilt_iff {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ) :
    (∃ l : ℝ, 0<l ∧ l*Real.exp (-l*δ)=x) ↔ x*δ≤Real.exp (-1) := by
  constructor
  · rintro ⟨l,hl,he⟩
    calc
      x*δ = (l*δ)*Real.exp (-(l*δ)) := by rw [← he]; ring_nf
      _ ≤ Real.exp (-1) := Real.mul_exp_neg_le_exp_neg_one _
  · intro hb
    by_cases hd : δ=0
    · exact ⟨x,hx,by simp [hd]⟩
    have hd : 0<δ := lt_of_le_of_ne hδ (Ne.symm hd)
    let f := fun z : ℝ => z*Real.exp (-z)
    have hf : ContinuousOn f (Icc 0 1) := by fun_prop
    have hm : x*δ∈Icc (f 0) (f 1) := by
      dsimp [f]; simpa using And.intro (mul_pos hx hd).le hb
    obtain ⟨z,hz,he⟩ := intermediate_value_Icc (by norm_num : (0 : ℝ)≤1) hf hm
    have hz0 : 0<z := by
      by_contra hn
      have hh : z=0 := le_antisymm (le_of_not_gt hn) hz.1
      simp [f,hh] at he
      rcases he with he|he <;> linarith
    refine ⟨z/δ,div_pos hz0 hd,?_⟩
    have hden : δ≠0 := ne_of_gt hd
    dsimp [f] at he
    rw [neg_mul,div_mul_cancel₀ _ hden]
    calc
      z/δ*Real.exp (-z) = (z*Real.exp (-z))/δ := by ring
      _ = x := by rw [he,mul_div_cancel_right₀ _ hden]

-- @paper-step lem:delayed_cancellation/exact_real_root_threshold
theorem scalarDelay_negative_real_root_iff {a : ℝ} (ha : 0<a) :
    (∃ l : ℝ, 0<l ∧ scalarDelayChar a (-(l : ℂ))=0) ↔ a≤Real.exp (-1) := by
  constructor
  · rintro ⟨l,hl,he⟩
    have hr := congrArg Complex.re he
    simp [scalarDelayChar,Complex.exp_re] at hr
    have hprod : l*Real.exp (-l)=a := by
      have hh : Real.exp l*Real.exp (-l)=1 := by
        rw [← Real.exp_add,add_neg_cancel,Real.exp_zero]
      nlinarith [congrArg (fun u : ℝ => u*Real.exp (-l)) hr]
    simpa using (scalarDelay_tilt_iff ha (by norm_num : (0 : ℝ)≤1)).mp
      ⟨l,hl,by simpa using hprod⟩
  · intro h
    obtain ⟨l,hl,he⟩ := (scalarDelay_tilt_iff ha (by norm_num : (0 : ℝ)≤1)).mpr (by simpa using h)
    refine ⟨l,hl,?_⟩
    have hh : Real.exp (-l)*Real.exp l=1 := by rw [← Real.exp_add,neg_add_cancel,Real.exp_zero]
    have hr : a*Real.exp l=l := by
      simp only [mul_one] at he
      nlinarith [congrArg (fun u : ℝ => u*Real.exp l) he]
    have hc : (a : ℂ)*Complex.exp (l : ℂ)=(l : ℂ) := by exact_mod_cast hr
    simp only [scalarDelayChar,neg_neg,hc,neg_add_cancel]

-- @paper-step lem:delayed_cancellation/normalized_pi_characteristic_factorization
theorem scalarDelay_PI_factor (x δ : ℝ) (p : ℂ) :
    p*(p+1)+(x : ℂ)*(p+1)*Complex.exp (-(δ : ℂ)*p)=
      (p+1)*(p+(x : ℂ)*Complex.exp (-(δ : ℂ)*p)) := by ring

-- @paper-step lem:delayed_cancellation/physical_scalar_spectral_threshold
theorem delayed_PI_spectral_iff {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ) :
    (∀ p : ℂ, (p+1)*(p+(x : ℂ)*Complex.exp (-(δ : ℂ)*p))=0 → p.re<0) ↔
      x*δ<Real.pi/2 := by
  by_cases hd : δ=0
  · simp only [hd,Complex.ofReal_zero,neg_zero,zero_mul,Complex.exp_zero,mul_one,mul_zero]
    constructor
    · intro _; exact Real.pi_div_two_pos
    · intro _ p hp
      rcases mul_eq_zero.mp hp with hp|hp
      · have hh : p= -1 := by linear_combination hp
        simp [hh]
      · have hh : p= -(x : ℂ) := by linear_combination hp
        simpa [hh] using neg_neg_of_pos hx
  have hd0 : 0<δ := lt_of_le_of_ne hδ (Ne.symm hd)
  have hdc : (δ : ℂ)≠0 := Complex.ofReal_ne_zero.mpr hd
  constructor
  · intro h
    apply (scalarDelay_spectral_iff (mul_pos hx hd0)).mp
    intro z hz
    have he : (z/(δ : ℂ)+1)*(z/(δ : ℂ)+(x : ℂ)*Complex.exp (-(δ : ℂ)*(z/(δ : ℂ))))=0 := by
      have he' : z/(δ : ℂ)+(x : ℂ)*Complex.exp (-(δ : ℂ)*(z/(δ : ℂ)))=0 := by
        have harg : -(δ : ℂ)*(z/(δ : ℂ))= -z := by field_simp
        rw [harg]
        apply (mul_eq_zero.mp (show (δ : ℂ)*(z/(δ : ℂ)+(x : ℂ)*Complex.exp (-z))=0 from by
          field_simp
          simpa [scalarDelayChar,Complex.ofReal_mul,mul_comm,mul_left_comm] using hz)).resolve_left hdc
      rw [he',mul_zero]
    have hh := h (z/(δ : ℂ)) he
    have hh' : z.re/δ<0 := by simpa using hh
    have := (div_lt_iff₀ hd0).mp hh'
    simpa using this
  · intro hb p hp
    rcases mul_eq_zero.mp hp with hp|hp
    · have hh : p= -1 := by linear_combination hp
      simp [hh]
    · have hz : scalarDelayChar (x*δ) ((δ : ℂ)*p)=0 := by
        have he := congrArg (fun z : ℂ => (δ : ℂ)*z) hp
        dsimp [scalarDelayChar]
        push_cast
        simp only [neg_mul] at he
        linear_combination he
      have hh := scalarDelay_root_left (mul_pos hx hd0) hb hz
      simp only [Complex.mul_re,Complex.ofReal_re,Complex.ofReal_im,zero_mul,sub_zero] at hh
      nlinarith

end MIACE
