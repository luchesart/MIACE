import MIACE.ScalarDelayMethodSteps
import MIACE.LagSquareEnergy
import MIACE.LagEvolution

namespace MIACE
open MeasureTheory Set Filter
open scoped Topology

/-- The original two PI states, including the canceled plant mode. -/
structure DelayedPIEvolution (x δ : ℝ) (y z : ℝ → ℝ) : Prop where
  output_continuous : Continuous y
  integrator_continuous : Continuous z
  output_ode : ∀ t, 0<t → HasDerivAt y (-y t+x*(z (t-δ)-y (t-δ))) t
  integrator_ode : ∀ t, 0<t → HasDerivAt z (-y t) t

-- @paper-step lem:delayed_cancellation/actual_full_pi_command_delay_equation
theorem delayedPI_command_deriv {x δ : ℝ} {y z : ℝ → ℝ}
    (he : DelayedPIEvolution x δ y z) (t : ℝ) (ht : 0<t) :
    HasDerivAt (fun s => x*(z s-y s)) (-x*(x*(z (t-δ)-y (t-δ)))) t := by
  convert ((he.integrator_ode t ht).sub (he.output_ode t ht)).const_mul x using 1 <;> ring

-- @paper-step lem:delayed_cancellation/normalized_history_time_change
theorem scalarDelay_normalize {x δ : ℝ} (hx : 0<x) {w : ℝ → ℝ}
    (hw : Continuous w) (hd : ∀ t, 0<t → HasDerivAt w (-x*w (t-δ)) t) :
    Continuous (fun t => w (t/x)) ∧
      ∀ t, 0<t → HasDerivAt (fun s => w (s/x)) (-w ((t-x*δ)/x)) t := by
  refine ⟨hw.comp (continuous_id.div_const x),?_⟩
  intro t ht
  have h := (hd (t/x) (div_pos ht hx)).comp t ((hasDerivAt_id t).div_const x)
  have he : (t-x*δ)/x=t/x-δ := by field_simp
  rw [he]
  change HasDerivAt (fun s => w (s/x)) (-x*w (t/x-δ)*(1/x)) t at h
  convert h using 1 <;> field_simp <;> ring

-- @paper-step lem:delayed_cancellation/zero_delay_arbitrary_continuous_history_construction
theorem scalarDelay_zero_history_exists {x : ℝ} (φ : ℝ → ℝ) (hφ : Continuous φ) :
    ∃ w : ℝ → ℝ, Continuous w ∧ (∀ t, t≤0 → w t=φ t) ∧
      ∀ t, 0<t → HasDerivAt w (-x*w t) t := by
  let w := fun t => φ (min t 0)*Real.exp (-x*max t 0)
  have hw : Continuous w := by dsimp [w]; fun_prop
  refine ⟨w,hw,?_,?_⟩
  · intro t ht; simp [w,min_eq_left ht,max_eq_right ht]
  · intro t ht
    have he : w=ᶠ[𝓝 t] (fun s => φ 0*Real.exp (-x*s)) := by
      filter_upwards [Ioi_mem_nhds ht] with s hs
      change 0<s at hs
      simp [w,min_eq_right hs.le,max_eq_left hs.le]
    have hd := (((hasDerivAt_id t).const_mul (-x)).exp).const_mul (φ 0)
    have hh : w t=φ 0*Real.exp (-x*t) := he.eq_of_nhds
    rw [hh]
    convert hd.congr_of_eventuallyEq he using 1 <;> simp only [id_eq] <;> ring

-- @paper-step lem:delayed_cancellation/physical_scalar_history_existence_all_nonnegative_delays
theorem scalarDelay_physical_history_exists {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    {φ : ℝ → ℝ} (hφ : Continuous φ) :
    ∃ w : ℝ → ℝ, Continuous w ∧ (∀ t, t≤0 → w t=φ t) ∧
      ∀ t, 0<t → HasDerivAt w (-x*w (t-δ)) t := by
  by_cases hd0 : δ=0
  · simpa [hd0] using scalarDelay_zero_history_exists (x := x) φ hφ
  have hδp : 0<δ := lt_of_le_of_ne hδ (Ne.symm hd0)
  obtain ⟨v,hv,hpast,hvd⟩ := scalarDelay_history_exists (mul_pos hx hδp)
    (hφ.comp (continuous_id.div_const x))
  refine ⟨fun t => v (x*t),hv.comp (continuous_const.mul continuous_id),?_,?_⟩
  · intro t ht
    change v (x*t)=φ t
    rw [hpast (x*t) (mul_nonpos_of_nonneg_of_nonpos hx.le ht)]
    dsimp; field_simp
  · intro t ht
    have he := (hvd (x*t) (mul_pos hx ht)).comp t ((hasDerivAt_id t).const_mul x)
    have harg : x*(t-δ)=x*t-x*δ := by ring
    change HasDerivAt (fun s => v (x*s)) (-x*v (x*(t-δ))) t
    rw [harg]
    convert he using 1
    · rfl
    · ring

-- @paper-step lem:delayed_cancellation/retained_unit_lag_classical_derivative
theorem unitLagState_deriv {u : ℝ → ℝ} (hu : Continuous u) (y₀ : ℝ)
    {t : ℝ} (ht : 0<t) : HasDerivAt (lagState 1 y₀ u) (u t-lagState 1 y₀ u t) t := by
  have hd := ((((hasDerivAt_id t).neg.div_const 1).exp).const_mul y₀).add
    (lag_hasDerivAt hu.continuousOn 1 t (by norm_num) ht)
  convert hd using 1
  · rfl
  · simp [lagState]; ring

-- @paper-step lem:delayed_cancellation/arbitrary_full_pi_history_realization
theorem delayedPI_history_exists {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    {φ ψ : ℝ → ℝ} (hφ : Continuous φ) (hψ : Continuous ψ) :
    ∃ y z : ℝ → ℝ, DelayedPIEvolution x δ y z ∧
      (∀ t, t≤0 → y t=φ t) ∧ (∀ t, t≤0 → z t=ψ t) := by
  obtain ⟨w,hw,hpast,hwd⟩ := scalarDelay_physical_history_exists hx hδ
    ((hψ.sub hφ).const_mul x)
  let u := fun t => w (t-δ)
  have hu : Continuous u := hw.comp (continuous_id.sub continuous_const)
  let Y := lagState 1 (φ 0) u
  have hY : Continuous Y := (lagState_evolution hu.locallyIntegrable 1 (φ 0)).1
  let y := fun t => φ (min t 0)+Y (max t 0)-φ 0
  let z := fun t => y t+w t/x
  have hy : Continuous y := (hφ.comp (continuous_id.min continuous_const)).add
    (hY.comp (continuous_id.max continuous_const)) |>.sub continuous_const
  have hz : Continuous z := hy.add (hw.div_const x)
  have hcmd (t : ℝ) : x*(z t-y t)=w t := by dsimp [z]; field_simp; ring
  have hyd (t : ℝ) (ht : 0<t) : HasDerivAt y (-y t+w (t-δ)) t := by
    have he : y=ᶠ[𝓝 t] Y := by
      filter_upwards [Ioi_mem_nhds ht] with s hs
      change 0<s at hs
      simp [y,min_eq_right hs.le,max_eq_left hs.le]
    have hd := (unitLagState_deriv hu (φ 0) ht).congr_of_eventuallyEq he
    rw [he.eq_of_nhds]
    convert hd using 1 <;> dsimp [u,Y] <;> ring
  refine ⟨y,z,⟨hy,hz,?_,?_⟩,?_,?_⟩
  · intro t ht; rw [hcmd]; exact hyd t ht
  · intro t ht
    convert (hyd t ht).add ((hwd t ht).div_const x) using 1
    field_simp; ring
  · intro t ht; simp [y,Y,lagState,lag,min_eq_left ht,max_eq_right ht]
  · intro t ht
    dsimp [z]
    rw [hpast t ht]
    simp [y,Y,lagState,lag,min_eq_left ht,max_eq_right ht]
    field_simp; ring

end MIACE
