import MIACE.NonlinearStorage
import MIACE.NonlinearFlow

/-! The globally constructed nonlinear feedback is an actual admissible
response for the original MIACE signals. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:nonlinear_miace/feedback_response
theorem nonlinear_feedback_response {a : ℝ → ℝ} (ha : Continuous a)
    (hapos : ∀ x, 0 < a x) {α m M : ℝ} (hα : 0 < α) (hm : 0 < m)
    (hlo : ∀ x ∈ Icc (0 : ℝ) 1, m ≤ a x)
    (hup : ∀ x ∈ Icc (0 : ℝ) 1, a x ≤ M) :
    ∃ y : ℝ → ℝ,
      NonlinearResponse a y (fun t => 1 + (1-y t)/α) ∧
      (∀ t, 0 ≤ t → 0 ≤ y t ∧ y t < 1 ∧
        Real.exp (-(1+1/α)*M*t) ≤ 1-y t ∧
        1-y t ≤ Real.exp (-(1+1/α)*m*t)) ∧
      (∀ t, 0 ≤ t → 1 ≤ 1 + (1-y t)/α ∧
        1 + (1-y t)/α ≤ 1 + 1/α) := by
  have hc : 0 < 1 + 1/α := by positivity
  obtain ⟨y, hyC, hy0, hyd, hyb, hylim, hye⟩ :=
    nonlinear_flow_exists_admissible ha hapos hc hm hlo hup
  have hresp : NonlinearResponse a y (fun t => 1 + (1-y t)/α) := by
    refine ⟨?_, ?_, hy0, hylim, hye, ?_⟩
    · intro T hT
      exact hyC.contDiffOn.absolutelyContinuousOnInterval
    · apply ae_of_all
      intro t ht
      rw [(hyd t ht.le).deriv]
      ring
    · have he := hye.div_const α
      convert he using 1
      funext t
      ring
  refine ⟨y, hresp, hyb, ?_⟩
  intro t ht
  have hb := hyb t ht
  constructor
  · have hq : 0 ≤ (1-y t)/α := div_nonneg (by linarith [hb.2.1]) hα.le
    linarith
  · have hq : (1-y t)/α ≤ 1/α :=
      div_le_div_of_nonneg_right (by linarith [hb.1]) hα.le
    linarith

-- @paper-step thm:nonlinear_miace/finite_command_peak
theorem nonlinear_feedback_peak {y : ℝ → ℝ} {α : ℝ} (hα : 0 < α)
    (hy0 : y 0 = 0) (hy : ∀ t, 0 ≤ t → 0 ≤ y t) :
    sSup ((fun t => 1 + (1-y t)/α) '' Ici (0 : ℝ)) = 1 + 1/α := by
  have hub : ∀ t ∈ Ici (0 : ℝ), 1 + (1-y t)/α ≤ 1 + 1/α := by
    intro t ht
    have hq : (1-y t)/α ≤ 1/α :=
      div_le_div_of_nonneg_right (by linarith [hy t ht]) hα.le
    linarith
  apply le_antisymm
  · apply csSup_le
    · exact ⟨1 + (1-y 0)/α, 0, by simp, rfl⟩
    · rintro z ⟨t, ht, rfl⟩
      exact hub t ht
  · apply le_csSup
    · refine ⟨1 + 1/α, ?_⟩
      rintro z ⟨t, ht, rfl⟩
      exact hub t ht
    · refine ⟨0, by simp, ?_⟩
      simp [hy0]

end MIACE
