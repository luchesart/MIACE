import MIACE.Theorem17Signals
import MIACE.CascadeEvolution

/-! A finite stable cascade realization of I_delta/B. It has one state per
factor of B and accepts arbitrary initial states. This is the strictly
proper part needed to realize the displayed rational controller. -/
namespace MIACE
open MeasureTheory Filter Set Polynomial
open scoped Topology Convolution

noncomputable def remainderFeed (r : ℕ → ℝ) (δ : ℝ) : ℕ → ℝ
  | 0 => Real.exp (r 0*δ)
  | n+1 => (-1 : ℝ)^(n+1)*reverseImpulse r (n+1) δ/r (n+1)

noncomputable def remainderFilter (r : ℕ → ℝ) (δ : ℝ) (ξ : ℕ → ℝ)
    (u : ℝ → ℝ) : ℕ → ℝ → ℝ
  | 0 => lagState (1/r 0) (ξ 0) (fun t => remainderFeed r δ 0*u t)
  | n+1 => lagState (1/r (n+1)) (ξ (n+1))
      (fun t => remainderFilter r δ ξ u n t+remainderFeed r δ (n+1)*u t)

-- @paper-step thm:n_construction/halfline_transform_linear_combination
theorem laplace_linear_half {f g : ℝ → ℝ} (hf : Integrable f halfLine)
    (hg : Integrable g halfLine) (a b : ℝ) {p : ℝ} (hp : 0≤p) :
    laplace (fun t => a*f t+b*g t) p=a*laplace f p+b*laplace g p := by
  unfold laplace
  have he : (fun t => Real.exp (-p*t)*(a*f t+b*g t))=
      (fun t => a*(Real.exp (-p*t)*f t)+b*(Real.exp (-p*t)*g t)) := by funext t; ring
  rw [he,integral_add ((laplace_integrable hf hp).const_mul a)
    ((laplace_integrable hg hp).const_mul b),integral_const_mul,integral_const_mul]

-- @paper-step thm:n_construction/arbitrary_initial_lag_integrability
theorem lagState_integrable {u : ℝ → ℝ} (hu : Integrable u halfLine)
    {σ : ℝ} (hσ : 0<σ) (ξ : ℝ) : Integrable (lagState σ ξ u) halfLine :=
  ((lag_transient_transform hσ (show (0 : ℝ)≤0 from le_rfl)).1.const_mul ξ).add
    (lag_integrable hu hσ)

-- @paper-step thm:n_construction/arbitrary_initial_lag_actual_transform
theorem lagState_laplace {u : ℝ → ℝ} (hu : Integrable u halfLine)
    {σ p : ℝ} (hσ : 0<σ) (hp : 0≤p) (ξ : ℝ) :
    laplace (lagState σ ξ u) p=(σ*ξ+laplace u p)/(1+σ*p) := by
  have hh := laplace_linear_half (lag_transient_transform hσ hp).1 (lag_integrable hu hσ) ξ 1 hp
  simp only [one_mul] at hh
  change laplace (lagState σ ξ u) p=_ at hh
  rw [hh,(lag_transient_transform hσ hp).2,lag_laplace hu hσ hp]
  ring

-- @paper-step thm:n_construction/remainder_filter_local_state_construction
theorem remainderFilter_local {u : ℝ → ℝ} (hu : LocallyIntegrable u volume)
    (r : ℕ → ℝ) (δ : ℝ) (ξ : ℕ → ℝ) (n : ℕ) :
    Continuous (remainderFilter r δ ξ u n) := by
  induction n with
  | zero => exact (lagState_evolution (hu.smul (remainderFeed r δ 0)) _ _).1
  | succ n ih => exact (lagState_evolution (ih.locallyIntegrable.add (hu.smul (remainderFeed r δ (n+1)))) _ _).1

-- @paper-step thm:n_construction/remainder_filter_integrable_states
theorem remainderFilter_integrable {u : ℝ → ℝ} (hu : Integrable u halfLine)
    (r : ℕ → ℝ) (δ : ℝ) (ξ : ℕ → ℝ) (n : ℕ) (hr : ∀ j≤n, 0<r j) :
    Integrable (remainderFilter r δ ξ u n) halfLine := by
  induction n with
  | zero => exact lagState_integrable (hu.const_mul _) (one_div_pos.mpr (hr 0 le_rfl)) _
  | succ n ih =>
    exact lagState_integrable
      ((ih (fun j hj => hr j (by omega))).add (hu.const_mul _))
      (one_div_pos.mpr (hr (n+1) le_rfl)) _

-- @paper-step thm:n_construction/remainder_filter_actual_transform_with_initial_transient
theorem remainderFilter_laplace {u : ℝ → ℝ} (hu : Integrable u halfLine)
    (r : ℕ → ℝ) (δ : ℝ) (ξ : ℕ → ℝ) (n : ℕ) (hr : ∀ j≤n, 0<r j)
    {p : ℝ} (hp : 0≤p) :
    laplace (remainderFilter r δ ξ u n) p=
      laplace (remainderFilter r δ ξ (fun _ => 0) n) p+
        (remainderI r δ n).eval p/(remainderB r n).eval p*laplace u p := by
  have hz : Integrable (fun _ : ℝ => (0 : ℝ)) halfLine := integrable_zero _ _ _
  induction n with
  | zero =>
    rw [remainderFilter,remainderFilter,
      lagState_laplace (hu.const_mul _) (one_div_pos.mpr (hr 0 le_rfl)) hp,
      lagState_laplace (hz.const_mul _) (one_div_pos.mpr (hr 0 le_rfl)) hp,
      laplace_smul,laplace_smul]
    simp [laplace,remainderI,remainderB,remainderFeed]
    ring
  | succ n ih =>
    have hr' : ∀ j≤n, 0<r j := fun j hj => hr j (by omega)
    have hU := remainderFilter_integrable hu r δ ξ n hr'
    have hZ := remainderFilter_integrable hz r δ ξ n hr'
    have hden : 1+(1/r (n+1))*p≠0 := ne_of_gt (by have := hr (n+1) le_rfl; positivity)
    have hUadd : Integrable (fun t => remainderFilter r δ ξ u n t + remainderFeed r δ (n+1)*u t) halfLine := hU.add (hu.const_mul _)
    have hZadd : Integrable (fun t => remainderFilter r δ ξ (fun _ => 0) n t + remainderFeed r δ (n+1)*0) halfLine := hZ.add (hz.const_mul _)
    rw [remainderFilter,remainderFilter,
      lagState_laplace hUadd (one_div_pos.mpr (hr (n+1) le_rfl)) hp,
      lagState_laplace hZadd (one_div_pos.mpr (hr (n+1) le_rfl)) hp]
    have hu' := laplace_linear_half hU hu 1 (remainderFeed r δ (n+1)) hp
    have hz' := laplace_linear_half hZ hz 1 (remainderFeed r δ (n+1)) hp
    simp only [one_mul] at hu' hz'
    rw [hu',hz',ih hr']
    simp only [laplace,zero_mul,integral_zero,mul_zero,add_zero,remainderI,remainderB,
      eval_add,eval_mul,eval_C,eval_X,eval_one,remainderFeed]
    field_simp [ne_of_gt (remainderB_eval_pos r n hr' hp),hden]
    ring

-- @paper-step thm:n_construction/remainder_filter_actual_finite_state_odes
theorem remainderFilter_evolution {u : ℝ → ℝ} (hu : LocallyIntegrable u volume)
    (r : ℕ → ℝ) (δ : ℝ) (ξ : ℕ → ℝ) :
    LagEvolution (1/r 0) (ξ 0) (fun t => remainderFeed r δ 0*u t)
      (remainderFilter r δ ξ u 0) ∧
    ∀ n, LagEvolution (1/r (n+1)) (ξ (n+1))
      (fun t => remainderFilter r δ ξ u n t+remainderFeed r δ (n+1)*u t)
      (remainderFilter r δ ξ u (n+1)) := by
  exact ⟨(lagState_evolution (hu.smul (remainderFeed r δ 0)) _ _).2,
    fun n => (lagState_evolution ((remainderFilter_local hu r δ ξ n).locallyIntegrable.add
      (hu.smul (remainderFeed r δ (n+1)))) _ _).2⟩

end MIACE
