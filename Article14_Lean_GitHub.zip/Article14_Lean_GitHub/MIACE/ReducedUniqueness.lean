import MIACE.ReducedEvolution

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:pid_two_rate_optimum/finite_interval_pair_uniqueness
theorem retarded_pair_zero {a b : ℝ → ℝ} (ha : Continuous a) (hb : Continuous b)
    (hac : ∀ T, 0≤T → AbsolutelyContinuousOnInterval a 0 T)
    (hbc : ∀ T, 0≤T → AbsolutelyContinuousOnInterval b 0 T)
    (ha0 : a 0=0) (hb0 : b 0=0) {δ L : ℝ} (hδ : 0≤δ) (hL : 0≤L)
    (hd : ∀ᵐ t, 0<t → |deriv a t|+|deriv b t|≤
      L*(|a t|+|b t|+(|a (max 0 (t-δ))|+|b (max 0 (t-δ))|))) :
    ∀ t, 0≤t → a t=0 ∧ b t=0 := by
  intro T hT
  let f := fun t => |a t|+|b t|
  have hf : Continuous f := ha.abs.add hb.abs
  have hn (t : ℝ) : 0≤f t := add_nonneg (abs_nonneg _) (abs_nonneg _)
  have hi (t : ℝ) (ht : t∈Icc (0 : ℝ) T) :
      f t≤L*(∫ s in 0..t, f s+f (max 0 (s-δ))) := by
    have hia := (hac t ht.1).intervalIntegrable_deriv
    have hib := (hbc t ht.1).intervalIntegrable_deriv
    have hfa := (hac t ht.1).integral_deriv_eq_sub
    have hfb := (hbc t ht.1).integral_deriv_eq_sub
    rw [ha0,sub_zero] at hfa
    rw [hb0,sub_zero] at hfb
    have hna := intervalIntegral.abs_integral_le_integral_abs (f := deriv a) (μ := volume) ht.1
    have hnb := intervalIntegral.abs_integral_le_integral_abs (f := deriv b) (μ := volume) ht.1
    rw [hfa] at hna
    rw [hfb] at hnb
    have hmajor : Continuous (fun s => L*(f s+f (max 0 (s-δ)))) :=
      (hf.add (hf.comp (continuous_const.max (continuous_id.sub continuous_const)))).const_mul L
    have hh := intervalIntegral.integral_mono_ae_restrict ht.1
      (hia.abs.add hib.abs) (hmajor.intervalIntegrable (μ := volume) 0 t) (show
        (fun s => |deriv a s|+|deriv b s|) ≤ᵐ[volume.restrict (Icc 0 t)]
        (fun s => L*(f s+f (max 0 (s-δ)))) from by
          have hd' := hd.filter_mono (ae_mono (Measure.restrict_le_self (s := Icc 0 t)))
          have hz := (volume.ae_ne (0 : ℝ)).filter_mono
            (ae_mono (Measure.restrict_le_self (s := Icc 0 t)))
          filter_upwards [hd',hz,ae_restrict_mem measurableSet_Icc] with s hs hsz hst
          exact hs (lt_of_le_of_ne hst.1 (Ne.symm hsz)))
    rw [intervalIntegral.integral_add hia.abs hib.abs,intervalIntegral.integral_const_mul] at hh
    dsimp [f] at hh ⊢
    linarith
  have hz := retarded_integral_zero hf hδ hL hT (fun t _ => hn t) hi T ⟨hT,le_rfl⟩
  dsimp [f] at hz
  exact ⟨abs_eq_zero.mp (by linarith [abs_nonneg (a T),abs_nonneg (b T)]),
    abs_eq_zero.mp (by linarith [abs_nonneg (a T),abs_nonneg (b T)])⟩

-- @paper-step thm:pid_two_rate_optimum/linear_pair_norm_estimate
theorem linear_pair_bound (r s u v : ℝ) :
    |r*u+s*v|≤(|r|+|s|)*(|u|+|v|) := by
  have hh := abs_add_le (r*u) (s*v)
  simp only [abs_mul] at hh
  nlinarith [mul_nonneg (abs_nonneg r) (abs_nonneg v),
    mul_nonneg (abs_nonneg s) (abs_nonneg u)]

-- @paper-step thm:pid_two_rate_optimum/equal_initial_causal_difference
theorem causalize_sub_clamp {a b : ℝ → ℝ} (h : a 0=b 0) (t : ℝ) :
    causalize a t-causalize b t=a (max 0 t)-b (max 0 t) := by
  by_cases ht : 0≤t
  · simp [causalize,ht,max_eq_right ht]
  · simp [causalize,ht,max_eq_left (le_of_not_ge ht),h]

-- @paper-step thm:pid_two_rate_optimum/unrestricted_reduced_evolution_uniqueness
theorem reduced_evolution_unique {i ρ ell δ a₀ b₀ : ℝ} {H a b A B : ℝ → ℝ}
    (hδ : 0≤δ) (h : ReducedEvolution i ρ ell δ a₀ b₀ H a b)
    (h' : ReducedEvolution i ρ ell δ a₀ b₀ H A B) :
    ∀ t, 0≤t → a t=A t ∧ b t=B t := by
  let r := -1/ρ
  let s := -(i/ρ)*(ell-ρ)
  let u := -(i/ρ)*ell
  let La := |r|+|r|
  let Lb := |s|+|u|
  have hLa : 0≤La := by dsimp [La]; positivity
  have hLb : 0≤Lb := by dsimp [Lb]; positivity
  have hd : ∀ᵐ t, 0<t →
      |deriv (fun s => a s-A s) t|+|deriv (fun s => b s-B s) t|≤
      (La+Lb)*(|a t-A t|+|b t-B t|+
        (|a (max 0 (t-δ))-A (max 0 (t-δ))|+|b (max 0 (t-δ))-B (max 0 (t-δ))|)) := by
    filter_upwards [h.ode_a,h.ode_b,h'.ode_a,h'.ode_b] with t ha hb hA hB ht
    have hda := ((ha ht).sub (hA ht)).deriv
    have hdb := ((hb ht).sub (hB ht)).deriv
    have heA : -(a t+b t)/ρ-(-(A t+B t)/ρ)=r*(a t-A t)+r*(b t-B t) := by dsimp [r]; ring
    have heB : (H t-(i/ρ)*((ell-ρ)*causalize a (t-δ)+ell*causalize b (t-δ)))-
        (H t-(i/ρ)*((ell-ρ)*causalize A (t-δ)+ell*causalize B (t-δ)))=
        s*(a (max 0 (t-δ))-A (max 0 (t-δ)))+u*(b (max 0 (t-δ))-B (max 0 (t-δ))) := by
      rw [← causalize_sub_clamp (h.initial_a.trans h'.initial_a.symm),
        ← causalize_sub_clamp (h.initial_b.trans h'.initial_b.symm)]
      dsimp [s,u]
      ring
    change deriv (fun s => a s-A s) t=_ at hda
    change deriv (fun s => b s-B s) t=_ at hdb
    rw [hda,hdb,heA,heB]
    have hhA := linear_pair_bound r r (a t-A t) (b t-B t)
    have hhB := linear_pair_bound s u (a (max 0 (t-δ))-A (max 0 (t-δ)))
      (b (max 0 (t-δ))-B (max 0 (t-δ)))
    change _≤La*(|a t-A t|+|b t-B t|) at hhA
    change _≤Lb*(|a (max 0 (t-δ))-A (max 0 (t-δ))|+|b (max 0 (t-δ))-B (max 0 (t-δ))|) at hhB
    nlinarith [mul_nonneg hLa (add_nonneg (abs_nonneg (a (max 0 (t-δ))-A (max 0 (t-δ))))
      (abs_nonneg (b (max 0 (t-δ))-B (max 0 (t-δ))))),
      mul_nonneg hLb (add_nonneg (abs_nonneg (a t-A t)) (abs_nonneg (b t-B t)))]
  have hz := retarded_pair_zero (h.continuous_a.sub h'.continuous_a)
    (h.continuous_b.sub h'.continuous_b)
    (fun T hT => (h.ac_a T hT).sub (h'.ac_a T hT))
    (fun T hT => (h.ac_b T hT).sub (h'.ac_b T hT))
    (by simp [h.initial_a,h'.initial_a]) (by simp [h.initial_b,h'.initial_b])
    hδ (add_nonneg hLa hLb) hd
  intro t ht
  exact ⟨sub_eq_zero.mp (hz t ht).1,sub_eq_zero.mp (hz t ht).2⟩

end MIACE
