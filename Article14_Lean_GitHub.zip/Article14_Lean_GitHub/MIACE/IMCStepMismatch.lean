import MIACE.CompleteCap

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:complete_robust/ordinary_unit_step_local_integrability
theorem unitStep_local : LocallyIntegrable unitStep volume := by
  exact continuous_const.locallyIntegrable.indicator measurableSet_Ici

-- @paper-step thm:complete_robust/actual_unit_step_convolution
theorem convolution_unitStep (K : ℝ → ℝ) (t : ℝ) :
    (K ⋆ unitStep) t=∫ s in Iic t, K s := by
  change (∫ s, K s*unitStep (t-s))=_
  rw [← integral_indicator measurableSet_Iic]
  apply integral_congr_ae
  exact ae_of_all _ (fun s => by
    by_cases hs : s≤t
    · simp [unitStep,causalize,show 0≤t-s by linarith,hs]
    · simp [unitStep,causalize,show ¬0≤t-s by linarith,hs])

-- @paper-step thm:complete_robust/finite_window_full_integrability
theorem delayWindow_integrable {K : ℝ → ℝ} (hK : Integrable K) (a b : ℝ) :
    Integrable (fun t => ∫ s in t-b..t-a, K s) := by
  have hord (a b : ℝ) (hab : a≤b) : Integrable (fun t => ∫ s in t-b..t-a, K s) := by
    have hp := (pulse_full_integrable 1 (b-a)).integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hK
    have he : (fun t => ∫ s in t-b..t-a, K s)=shift a (pulse 1 (b-a) ⋆ K) := by
      funext t
      simp only [shift,step_delay_convolution (b-a) (sub_nonneg.mpr hab)]
      congr 1
      ring
    rw [he]
    exact shift_integrable a hp
  rcases le_total a b with hab | hba
  · exact hord a b hab
  · have hh := (hord b a hba).neg
    exact hh.congr (ae_of_all _ (fun t => by
      change -(∫ s in t-a..t-b, K s)=∫ s in t-b..t-a, K s
      rw [intervalIntegral.integral_symm,neg_neg]))

-- @paper-step thm:complete_robust/actual_delay_step_difference_identity
theorem delayMismatch_step (ss : List ℝ) (hs : ∀ σ∈ss, 0<σ)
    {δ ε : ℝ} (hδ : 0≤δ) (hδε : 0≤δ+ε) :
    (delayMismatchKernel ss δ ε ⋆ unitStep)=ᵐ[volume]
      (fun t => -(∫ s in t-(δ+ε)..t-δ, cascadeKernel ss s)) := by
  have hK := cascadeKernel_properties ss hs
  have hh := local_kernel_sub (shift_integrable (δ+ε) hK.1) (shift_integrable δ hK.1)
    (causal_shift hK.2.2.2 hδε) (causal_shift hK.2.2.2 hδ) unitStep_local (causalize_causal _)
  filter_upwards [hh] with t ht
  change (delayMismatchKernel ss δ ε ⋆ unitStep) t=_ at ht
  rw [ht,shift_convolution_left,shift_convolution_left]
  simp only [shift,convolution_unitStep]
  rw [← intervalIntegral.integral_Iic_sub_Iic hK.1.integrableOn hK.1.integrableOn]
  ring

-- @paper-step thm:complete_robust/actual_delay_step_L1_distance
theorem delayMismatch_step_properties (ss : List ℝ) (hs : ∀ σ∈ss, 0<σ)
    {δ ε : ℝ} (hδ : 0≤δ) (hδε : 0≤δ+ε) :
    Integrable (delayMismatchKernel ss δ ε ⋆ unitStep) ∧
      Causal (delayMismatchKernel ss δ ε ⋆ unitStep) ∧
      absArea (delayMismatchKernel ss δ ε ⋆ unitStep) volume=|ε| := by
  have hK := cascadeKernel_properties ss hs
  have he := delayMismatch_step ss hs hδ hδε
  have hc : Causal (delayMismatchKernel ss δ ε) := by
    filter_upwards [causal_shift hK.2.2.2 hδε,causal_shift hK.2.2.2 hδ] with t ht hs hn
    simp [delayMismatchKernel,ht hn,hs hn]
  refine ⟨((delayWindow_integrable hK.1 δ (δ+ε)).neg).congr he.symm,
    ae_of_all _ (convolution_causal hc (causalize_causal _)),?_⟩
  have ha : absArea (delayMismatchKernel ss δ ε ⋆ unitStep) volume=
      absArea (fun t => ∫ s in t-(δ+ε)..t-δ, cascadeKernel ss s) volume := by
    apply integral_congr_ae
    filter_upwards [he] with t ht
    rw [ht,abs_neg]
  rw [ha]
  exact cascade_step_error_norm ss hs δ ε

-- @paper-step thm:complete_robust/filter_and_plant_commute_for_ordinary_signals
theorem local_filter_commute (F : IMCFilter) {K u : ℝ → ℝ}
    (hK : Integrable K) (hKc : Causal K) (hu : LocallyIntegrable u volume) (huc : Causal u) :
    filterAction F (K ⋆ u)=ᵐ[volume] (K ⋆ filterAction F u) := by
  apply causalLocalOperator_ext
    (causalLocalOperator_comp (filter_local_operator F) (convolution_local_operator hK hKc))
    (causalLocalOperator_comp (convolution_local_operator hK hKc) (filter_local_operator F)) _ hu huc
  intro f hf hfc
  have hKf := hK.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hf
  have hKfc : Causal (K ⋆ f) := ae_of_all volume (convolution_causal hKc hfc)
  apply causal_laplace_ext (filterAction_integrable F hKf)
    (hK.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) (filterAction_integrable F hf))
    (filterAction_causal F hKfc) (ae_of_all _ (convolution_causal hKc (filterAction_causal F hfc)))
  intro p hp
  rw [filterAction_laplace F hKf hKfc hp.le,causal_convolution_laplace hK hf hKc hfc hp.le,
    causal_convolution_laplace hK (filterAction_integrable F hf) hKc (filterAction_causal F hfc) hp.le,
    filterAction_laplace F hf hfc hp.le]
  ring

end MIACE
