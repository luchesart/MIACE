import MIACE.HermiteUniqueness

/-! Algebra and DC data of the rational cascade construction. These are
proved from the actual remainder integrals; they do not assert stability. -/
namespace MIACE
open MeasureTheory Filter Set Polynomial
open scoped Topology

noncomputable def rationalCascadeA (r : ℕ → ℝ) (n : ℕ) (δ U : ℝ) : ℝ :=
  1-U+(-1 : ℝ)^(n+1)*compactMoment (remainderJ r n δ) δ 1
noncomputable def rationalCascadeC (r : ℕ → ℝ) (n : ℕ) (δ : ℝ) : ℝ :=
  1-(-1 : ℝ)^(n+1)*compactMoment (remainderJ r n δ) δ 0
noncomputable def rationalCascadeQ (r : ℕ → ℝ) (n : ℕ) (δ U : ℝ) : ℝ[X] :=
  remainderB r n*(C (rationalCascadeA r n δ U)*X+C (rationalCascadeC r n δ))-
    remainderI r δ n

-- @paper-step thm:n_construction/real_restriction_of_compact_transform
theorem compactLaplace_real (J : ℝ → ℝ) (δ p : ℝ) :
    compactLaplace J δ (p : ℂ)=(compactExpMoment J δ (-p) : ℂ) := by
  unfold compactLaplace compactExpMoment
  rw [← intervalIntegral.integral_ofReal]
  apply intervalIntegral.integral_congr
  intro t _
  simp only [Complex.ofReal_mul,Complex.ofReal_exp,Complex.ofReal_neg]

-- @paper-step thm:n_construction/remainder_transform_dc
theorem remainderTransform_zero (r : ℕ → ℝ) (n : ℕ) (δ : ℝ) :
    remainderTransform r n δ 0=compactMoment (remainderJ r n δ) δ 0 := by
  simp [remainderTransform,compactMoment]

-- @paper-step thm:n_construction/remainder_transform_first_moment
theorem remainderTransform_deriv_zero (r : ℕ → ℝ) (n : ℕ) (δ : ℝ) :
    HasDerivAt (remainderTransform r n δ) (-compactMoment (remainderJ r n δ) δ 1) 0 := by
  have hd := (compactLaplace_deriv (remainderJ_continuous r n δ) δ (0 : ℂ)).real_of_complex
  have he : (∫ t in 0..δ, -(t : ℂ)*Complex.exp (-(0 : ℂ)*(t : ℂ))*(remainderJ r n δ t : ℂ))=
      (-compactMoment (remainderJ r n δ) δ 1 : ℝ) := by
    simp only [neg_zero,zero_mul,Complex.exp_zero,mul_one,compactMoment,pow_one]
    rw [← intervalIntegral.integral_neg,← intervalIntegral.integral_ofReal]
    apply intervalIntegral.integral_congr
    intro t _; push_cast; ring
  rw [he] at hd
  change HasDerivAt (fun p => ∫ t in 0..δ, Real.exp (-p*t)*remainderJ r n δ t) _ 0
  simpa only [compactLaplace_real,Complex.ofReal_re,compactExpMoment] using hd

-- @paper-step thm:n_construction/interpolant_dc_from_exact_remainder
theorem remainderI_zero (r : ℕ → ℝ) (n : ℕ) (δ : ℝ) (hr : ∀ j≤n, r j≠0) :
    (remainderI r δ n).eval 0=rationalCascadeC r n δ := by
  have he := exact_delay_remainder_real r n δ 0 hr
  rw [remainderB_zero,remainderTransform_zero] at he
  simp only [mul_zero,Real.exp_zero,mul_one] at he
  unfold rationalCascadeC
  linarith

-- @paper-step thm:n_construction/interpolant_dc_derivative_from_first_moment
theorem remainderI_derivative_zero (r : ℕ → ℝ) (n : ℕ) (δ : ℝ)
    (hr : ∀ j≤n, r j≠0) :
    (remainderI r δ n).derivative.eval 0= -δ-
      (-1 : ℝ)^(n+1)*(remainderB r n).derivative.eval 0*compactMoment (remainderJ r n δ) δ 0+
      (-1 : ℝ)^(n+1)*compactMoment (remainderJ r n δ) δ 1 := by
  have he : (fun p : ℝ => Real.exp (-δ*p))=(fun p => (remainderI r δ n).eval p+
      (-1 : ℝ)^(n+1)*(remainderB r n).eval p*remainderTransform r n δ p) :=
    funext (fun p => exact_delay_remainder_real r n δ p hr)
  have hR := ((remainderI r δ n).hasDerivAt 0).add
    ((((remainderB r n).hasDerivAt 0).const_mul ((-1 : ℝ)^(n+1))).mul
      (remainderTransform_deriv_zero r n δ))
  have hE := (((hasDerivAt_id (0 : ℝ)).const_mul (-δ)).exp)
  change HasDerivAt (fun p => (remainderI r δ n).eval p+
    (-1 : ℝ)^(n+1)*(remainderB r n).eval p*remainderTransform r n δ p) _ 0 at hR
  dsimp only [id_eq] at hE
  have hh := congrArg (fun f : ℝ → ℝ => deriv f 0) he
  rw [hR.deriv,hE.deriv,remainderB_zero,remainderTransform_zero] at hh
  simp only [mul_zero,Real.exp_zero,one_mul,mul_one] at hh
  linarith

-- @paper-step thm:n_construction/rational_controller_exact_characteristic_factorization
theorem rationalCascade_factorization (r : ℕ → ℝ) (n : ℕ) (δ U : ℝ)
    (hr : ∀ j≤n, r j≠0) (p : ℂ) :
    (rationalCascadeQ r n δ U).eval₂ Complex.ofRealHom p+Complex.exp (-(δ : ℂ)*p)=
      (remainderB r n).eval₂ Complex.ofRealHom p*
        ((rationalCascadeA r n δ U : ℂ)*p+(rationalCascadeC r n δ : ℂ)+
          (-1 : ℂ)^(n+1)*compactLaplace (remainderJ r n δ) δ p) := by
  have hcoe (x : ℝ) : Complex.ofRealHom x=(x : ℂ) := rfl
  rw [exact_delay_remainder_complex r n δ p hr]
  simp only [rationalCascadeQ,eval₂_sub,eval₂_mul,eval₂_add,eval₂_C,eval₂_X,hcoe]
  ring

-- @paper-step thm:n_construction/factor_polynomial_dc_derivative
theorem remainderB_derivative_zero (r : ℕ → ℝ) (n : ℕ) :
    (remainderB r n).derivative.eval 0=∑ j∈Finset.range (n+1), 1/r j := by
  induction n with
  | zero => simp [remainderB]
  | succ n ih =>
    simp only [remainderB,derivative_mul,derivative_add,derivative_C,derivative_X,derivative_one,
      eval_add,eval_mul,eval_C,eval_X,eval_one,eval_zero,mul_zero,zero_mul,zero_add,mul_one,
      one_mul,remainderB_zero,ih,Finset.sum_range_succ]
    ring

-- @paper-step thm:n_construction/derived_integrator_and_exact_residue_denominator
theorem rationalCascade_integrator (r : ℕ → ℝ) (n : ℕ) (δ U : ℝ)
    (hr : ∀ j≤n, r j≠0) :
    (rationalCascadeQ r n δ U).eval 0=0 ∧
    (rationalCascadeQ r n δ U).derivative.eval 0=
      1+(∑ j∈Finset.range (n+1), 1/r j)+δ-U := by
  constructor
  · simp [rationalCascadeQ,remainderB_zero,remainderI_zero r n δ hr]
  · simp only [rationalCascadeQ,derivative_sub,derivative_mul,derivative_add,derivative_C,
      derivative_X,eval_sub,eval_add,eval_mul,eval_C,eval_X,eval_one,eval_zero,mul_zero,
      zero_mul,zero_add,mul_one,one_mul,remainderB_zero,remainderI_derivative_zero r n δ hr,
      remainderB_derivative_zero,rationalCascadeA,rationalCascadeC]
    ring

-- @paper-step thm:n_construction/no_cancellation_at_any_cascade_pole
theorem rationalCascade_no_pole_cancellation (r : ℕ → ℝ) (n : ℕ) (δ U : ℝ)
    (hr : ∀ j≤n, r j≠0) (z : ℂ) (hz : (remainderB r n).eval₂ Complex.ofRealHom z=0) :
    (rationalCascadeQ r n δ U).eval₂ Complex.ofRealHom z≠0 := by
  simp only [rationalCascadeQ,eval₂_sub,eval₂_mul,hz,zero_mul,zero_sub,
    remainder_at_root r n δ hr z hz]
  exact neg_ne_zero.mpr (Complex.exp_ne_zero _)

-- @paper-step thm:n_construction/complex_tail_transform_including_zero
theorem compactLaplace_tail {J : ℝ → ℝ} (hJ : Continuous J) (δ : ℝ) (p : ℂ) :
    p*compactLaplace (compactTail J δ) δ p+compactLaplace J δ p=
      (compactMoment J δ 0 : ℂ) := by
  have hc := compactTail_continuous hJ δ
  have ce : Continuous (fun t : ℝ => Complex.exp (-p*(t : ℂ))) := by fun_prop
  have hd : ∀ t : ℝ, HasDerivAt
      (fun s : ℝ => Complex.exp (-p*(s : ℂ))*(compactTail J δ s : ℂ))
      (-p*(Complex.exp (-p*(t : ℂ))*(compactTail J δ t : ℂ))-
        Complex.exp (-p*(t : ℂ))*(J t : ℂ)) t := by
    intro t
    convert ((((hasDerivAt_id t).ofReal_comp.const_mul (-p)).cexp).mul
      (compactTail_deriv hJ δ t).ofReal_comp) using 1
    · rfl
    · dsimp; push_cast; ring
  have hi₁ : IntervalIntegrable
      (fun t : ℝ => -p*(Complex.exp (-p*(t : ℂ))*(compactTail J δ t : ℂ))) volume 0 δ :=
    ((ce.mul (Complex.continuous_ofReal.comp hc)).const_mul _).intervalIntegrable 0 δ
  have hi₂ : IntervalIntegrable
      (fun t : ℝ => Complex.exp (-p*(t : ℂ))*(J t : ℂ)) volume 0 δ :=
    (ce.mul (Complex.continuous_ofReal.comp hJ)).intervalIntegrable 0 δ
  have he := intervalIntegral.integral_eq_sub_of_hasDerivAt (fun t _ => hd t) (hi₁.sub hi₂)
  rw [intervalIntegral.integral_sub hi₁ hi₂,intervalIntegral.integral_const_mul] at he
  simp only [compactTail,intervalIntegral.integral_same,Complex.ofReal_zero,mul_zero,
    Complex.exp_zero,one_mul,zero_sub] at he
  change -p*compactLaplace (compactTail J δ) δ p-compactLaplace J δ p= -((∫ t in 0..δ, J t : ℝ) : ℂ) at he
  simpa only [compactMoment,pow_zero,one_mul] using (show
    p*compactLaplace (compactTail J δ) δ p+compactLaplace J δ p=((∫ t in 0..δ, J t : ℝ) : ℂ) by
      linear_combination -he)

-- @paper-step thm:n_construction/characteristic_resolvent_in_tail_form
theorem rationalCascade_resolvent_tail (r : ℕ → ℝ) (n : ℕ) (δ U : ℝ) (p : ℂ) :
    (rationalCascadeA r n δ U : ℂ)*p+(rationalCascadeC r n δ : ℂ)+
      (-1 : ℂ)^(n+1)*compactLaplace (remainderJ r n δ) δ p=
    1+(rationalCascadeA r n δ U : ℂ)*p-
      (-1 : ℂ)^(n+1)*p*compactLaplace (compactTail (remainderJ r n δ) δ) δ p := by
  have he := compactLaplace_tail (remainderJ_continuous r n δ) δ p
  unfold rationalCascadeC
  push_cast
  linear_combination ((-1 : ℂ)^(n+1))*he

end MIACE
