import MIACE.Theorem17Completion

/-! Stage 19. Preserve all physical conclusions when applying Theorem 17.
The degree certificate records unreduced numerator/denominator degrees and
excludes every common complex root; this is the minimal rational order. -/
namespace MIACE
open MeasureTheory Filter Set Polynomial
open scoped Topology

def CascadeMinimalOrder (r : ℕ → ℝ) (n : ℕ) (δ U : ℝ) : Prop :=
  ((X+1)*remainderB r n).natDegree=n+2 ∧
  (rationalCascadeQ r n δ U).natDegree=n+2 ∧
  ∀ z : ℂ, (((X+1)*remainderB r n : ℝ[X]).eval₂ Complex.ofRealHom z)=0 →
    (rationalCascadeQ r n δ U).eval₂ Complex.ofRealHom z≠0

def CascadeAttainment (r : ℕ → ℝ) (n : ℕ) (δ α : ℝ) : Prop :=
  let S := 1+(∑ j∈Finset.range (n+1), 1/r j)+δ
  RationalInternallyStable r n δ (rationalCascadeA r n δ (S/(1+α)))
    (rationalCascadeC r n δ) ∧
  ∃ v : ℝ → ℝ,
    Integrable v ∧
    TransferResponse (rationalCascadeError r n δ v) v
      (cascadeTransfer (rationalCascadeTimes r) (n+2)) δ ∧
    (∀ t, 0≤t → 0≤v t ∧ 0≤rationalCascadeError r n δ v t) ∧
    Monotone (fun t => 1-rationalCascadeError r n δ v t) ∧
    1-rationalCascadeError r n δ v 0=0 ∧
    Tendsto (fun t => 1-rationalCascadeError r n δ v t) atTop (𝓝 1) ∧
    absArea v halfLine=S/(1+α) ∧
    absArea (rationalCascadeError r n δ v) halfLine=α*S/(1+α) ∧
    miace α (rationalCascadeError r n δ v) v halfLine=S*minimum α ∧
    (∀ p : ℝ, 0<p → (rationalCascadeQ r n δ (S/(1+α))).eval p*
      laplace (fun t => 1+v t) p=
      ((1+p)*(remainderB r n).eval p)*laplace (rationalCascadeError r n δ v) p) ∧
    ∀ e' v' : ℝ → ℝ,
      TransferResponse e' v' (cascadeTransfer (rationalCascadeTimes r) (n+2)) δ →
      miace α (rationalCascadeError r n δ v) v halfLine≤miace α e' v' halfLine

-- @paper-step cor:n_small_delay/application_preserves_all_physical_conclusions
theorem cascadeAttainment_of_conditions (r : ℕ → ℝ) (n : ℕ) {δ α : ℝ}
    (hr : ∀ j≤n, 0<r j) (hδ : 0≤δ) (hα : 0<α)
    (ha : 0<rationalCascadeA r n δ
      ((1+(∑ j∈Finset.range (n+1), 1/r j)+δ)/(1+α)))
    (ha1 : rationalCascadeA r n δ
      ((1+(∑ j∈Finset.range (n+1), 1/r j)+δ)/(1+α))<1)
    (hpar : CascadeParityTest (remainderJ r n δ) δ (rationalCascadeA r n δ
      ((1+(∑ j∈Finset.range (n+1), 1/r j)+δ)/(1+α))) ((-1 : ℝ)^(n+1))) :
    CascadeAttainment r n δ α := by
  obtain ⟨hstab,R,v,_,hv,hT,hn,hm,h0,hlim,hU,hE,hM,hC,hmin⟩ :=
    paper_rationalCascade_attainment r n hr hδ hα ha ha1 hpar
  exact ⟨hstab,v,hv,hT,hn,hm,h0,hlim,hU,hE,hM,hC,hmin⟩

-- @paper-step cor:n_small_delay/denominator_and_numerator_exact_degree
theorem rationalCascade_degrees (r : ℕ → ℝ) (n : ℕ) (δ U : ℝ)
    (hr : ∀ j≤n, r j≠0) (ha : rationalCascadeA r n δ U≠0) :
    ((X+1)*remainderB r n).natDegree=n+2 ∧
    (rationalCascadeQ r n δ U).natDegree=n+2 := by
  have hlin : (C (rationalCascadeA r n δ U)*X+C (rationalCascadeC r n δ)).natDegree=1 :=
    natDegree_linear ha
  have hne : C (rationalCascadeA r n δ U)*X+C (rationalCascadeC r n δ)≠0 := by
    intro hz; simp [hz] at hlin
  have hdeg : (remainderB r n*(C (rationalCascadeA r n δ U)*X+
      C (rationalCascadeC r n δ))).natDegree=n+2 := by
    rw [natDegree_mul (remainderB_ne_zero r n) hne,remainderB_degree r n hr,hlin]
  constructor
  · have hx : (X+1 : ℝ[X]).natDegree=1 := by simpa using (natDegree_X_add_C (1 : ℝ))
    have hn : (X+1 : ℝ[X])≠0 := by intro hz; simp [hz] at hx
    rw [natDegree_mul hn (remainderB_ne_zero r n),hx,remainderB_degree r n hr]
    omega
  · rw [rationalCascadeQ,natDegree_sub_eq_left_of_natDegree_lt,hdeg]
    rw [hdeg]
    exact (remainderI_degree r n δ hr).trans_lt (by omega)

-- @paper-step cor:n_small_delay/no_common_roots_and_minimal_order
theorem rationalCascade_minimal_order (r : ℕ → ℝ) (n : ℕ) (δ U : ℝ)
    (hr : ∀ j≤n, r j≠0) (ha : rationalCascadeA r n δ U≠0)
    (hm : (rationalCascadeQ r n δ U).eval (-1)≠0) : CascadeMinimalOrder r n δ U := by
  obtain ⟨hA,hQ⟩ := rationalCascade_degrees r n δ U hr ha
  refine ⟨hA,hQ,?_⟩
  intro z hz
  simp only [eval₂_mul,eval₂_add,eval₂_X,eval₂_one] at hz
  rcases mul_eq_zero.mp hz with hz|hz
  · have he : z= -1 := by linear_combination hz
    subst z
    have hc : (rationalCascadeQ r n δ U).eval₂ Complex.ofRealHom (-1 : ℂ)=
        (((rationalCascadeQ r n δ U).eval (-1) : ℝ) : ℂ) := by
      simpa using (Polynomial.eval₂_at_apply (p := rationalCascadeQ r n δ U) Complex.ofRealHom (-1 : ℝ))
    rw [hc]
    exact_mod_cast hm
  · exact rationalCascade_no_pole_cancellation r n δ U hr z hz

end MIACE
