import MIACE.ExplicitPIDTransforms

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:pid_explicit_family/actual_ordinary_PID_signals_with_signs_and_exact_error_mass
theorem explicitPID_ordinary {i ρ ell l δ : ℝ} (h : ExplicitPIDData i ρ ell l δ) :
    ∃ E V : ℝ → ℝ, FilteredPIDResponse (i+ρ^2) i (i*ρ^2) ρ δ E V ∧
      (∀ t, 0≤t → 0≤E t ∧ 0≤V t) ∧ E 0=1 ∧ Tendsto E atTop (𝓝 0) ∧
      (∫ t, E t ∂halfLine)=1/i := by
  obtain ⟨η,C,G,hη,_,hGc,hG,hGn,hGT⟩ := explicitPID_Green h
  have hr := (explicitPID_order h).1
  obtain ⟨E,hEc,_,hE0,he,hEn,hEi,hElim⟩ :=
    green_PID_error_ordinary hr h.delay_pos.le hη hGc hG hGn hGT
  have hehalf := representative_halfLine_ae he
  have hET (p : ℝ) (hp : 0≤p) :
      (p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p))*laplace E p=1+ρ*p := by
    rw [← laplace_congr_halfLine hehalf]; exact hGT p hp
  obtain ⟨v,hvi,hvc,hvn,hvT⟩ := explicitPID_command_L1 h
  have hvhalf : Integrable v halfLine := hvi.restrict
  have hplant : TransferResponse E v (fun p => 1/(1+p)) δ := by
    refine ⟨hEi,hvhalf,?_⟩
    intro p hp
    have hs : laplace (fun t => 1-E t) p=1/p-laplace E p := by
      have hh := (laplace_step_add hEi.neg hp).2
      have hn : laplace (-E) p= -laplace E p := by
        unfold laplace; simp only [Pi.neg_apply,mul_neg,integral_neg]
      simpa only [Pi.neg_apply,← sub_eq_add_neg,hn] using hh
    rw [hs,(laplace_step_add hvhalf hp).2]
    exact (explicitPID_transfer_algebra h hET hvT hp).2
  have hcontroller (p : ℝ) (hp : 0<p) :
      1/p+laplace v p=(i+ρ^2+i/p+(i*ρ^2)*p/(1+ρ*p))*laplace E p := by
    have hc := explicitPID_controller_coefficients h
    rw [hc.2.2.1,hc.2.2.2.1]
    exact (explicitPID_transfer_algebra h hET hvT hp).1
  have hvn' := hvn.filter_mono (ae_mono (Measure.restrict_le_self (s:=Ioi (0 : ℝ))))
  obtain ⟨V,hpid,_,hVn⟩ := filteredPID_ordinary_realization hr hEc hplant hvn' hcontroller
  refine ⟨E,V,hpid,fun t ht => ⟨hEn t ht,hVn t ht⟩,hE0,hElim,?_⟩
  have hm := hET 0 le_rfl
  simp only [mul_zero,zero_mul,neg_zero,Real.exp_zero,add_zero,zero_add,mul_one,
    laplace,one_mul] at hm
  exact (eq_div_iff (ne_of_gt h.gain_pos)).mpr (by nlinarith)

-- @paper-step thm:pid_explicit_family/positive_ordinary_response_has_monotone_output
theorem positive_filtered_PID_shape {pc i dc ρ δ : ℝ} {E V : ℝ → ℝ}
    (hδ : 0≤δ) (h : FilteredPIDResponse pc i dc ρ δ E V)
    (hn : ∀ t, 0≤t → 0≤E t ∧ 0≤V t) (h0 : E 0=1)
    (hlim : Tendsto E atTop (𝓝 0)) :
    MonotoneOn (fun t => 1-E t) (Ici 0) ∧ 1-E 0=0 ∧
      Tendsto (fun t => 1-E t) atTop (𝓝 1) := by
  have hr : FirstOrderResponse (firstOrderError V) V := by
    refine ⟨?_,?_,firstOrderError_initial V,?_,
      firstOrderError_integrable h.plant.command_integrable,h.plant.command_integrable⟩
    · intro T hT
      have he : AbsolutelyContinuousOnInterval (fun t : ℝ => Real.exp (-t)) 0 T := by
        apply ContDiffOn.absolutelyContinuousOnInterval; fun_prop
      exact he.sub (lag_ac h.command_continuous.continuousOn 1 T hT)
    · exact ae_of_all _ (fun t ht => (firstOrderError_derivative h.command_continuous ht).deriv)
    · have ht : Tendsto (fun t : ℝ => t+δ) atTop atTop := by
        apply tendsto_atTop.2; intro b
        filter_upwards [eventually_ge_atTop (b-δ)] with t ht
        linarith
      apply (hlim.comp ht).congr'
      filter_upwards [eventually_ge_atTop (0 : ℝ)] with t ht
      exact (transfer_shifted_error h.plant hδ h.error_continuous h.command_continuous t ht).symm
  have hf : ∀ᵐ t ∂halfLine, 0≤firstOrderError V t := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    rw [transfer_shifted_error h.plant hδ h.error_continuous h.command_continuous t
      (show 0<t from ht).le]
    exact (hn (t+δ) (by linarith [show 0<t from ht])).1
  have hv : ∀ᵐ t ∂halfLine, 0≤V t := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact (hn t (show 0<t from ht).le).2
  have hm := delayed_output_monotone hr hf hv δ
  have he := transfer_firstOrder_realization h.plant hδ h.error_continuous h.command_continuous
  refine ⟨?_,by rw [h0]; ring,by simpa using tendsto_const_nhds.sub hlim⟩
  intro a ha b hb hab
  dsimp only
  rw [he a ha,he b hb]
  exact hm ha hb hab

end MIACE
