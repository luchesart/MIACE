import MIACE.IMCRobustIdentity

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:complete_robust/zero_initial_storage_zero_forcing
theorem serialState_zero_input (σ : ℕ → ℝ) (n : ℕ) :
    serialState σ (fun _ => 0) (fun _ => 0) n=(fun _ => 0) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    funext t
    simp [serialState,ih,lagState,lag]

-- @paper-step thm:complete_robust/zero_history_free_output
theorem plantFreeOutput_zero (N : ℕ) (σ : ℕ → ℝ) (δ : ℝ) :
    plantFreeOutput N σ (fun _ => 0) δ (fun _ => 0)=(fun _ => 0) := by
  funext t
  simp [plantFreeOutput,plantHistoryOutput,serialState_zero_input,historyInput,shift,causalize]

-- @paper-step thm:complete_robust/physical_zero_state_plant_kernel
theorem zeroHistory_plant_kernel (N : ℕ) (σ : ℕ → ℝ) (δ : ℝ)
    (hσ : ∀ j≤N, 0<σ j) {u : ℝ → ℝ} (hu : LocallyIntegrable u volume) (huc : Causal u) :
    plantHistoryOutput N σ (fun _ => 0) δ (fun _ => 0) u=ᵐ[volume]
      (shift δ (serialImpulse σ N) ⋆ u) := by
  have hh := plantHistoryOutput_split N σ (fun _ => 0) δ (fun _ => 0) hu huc hσ
  simpa only [plantFreeOutput_zero,zero_add] using hh

-- @paper-step thm:complete_robust/concrete_zero_history_reference_feedback
theorem zeroHistory_reference_feedback (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter)
    {δ ε : ℝ} (hδ : 0≤δ) (hδε : 0≤δ+ε) (hσ : ∀ j≤N, 0<σ j) (hfirst : σ 0=1)
    {u : ℝ → ℝ} (hu : LocallyIntegrable u volume) (huc : Causal u) :
    imcReferenceFeedback N σ F δ ε zeroIMCHistory unitStep u=ᵐ[volume]
      filterAction F (fun t => unitStep t-(delayMismatchKernel (serialRatios σ N) δ ε ⋆ u) t) := by
  have hK := serialImpulse_properties σ N hσ
  have hh := local_kernel_sub (shift_integrable (δ+ε) hK.1) (shift_integrable δ hK.1)
    (causal_shift hK.2 hδε) (causal_shift hK.2 hδ) hu huc
  have hq : (fun t => unitStep t+imcFilterInput N σ δ ε zeroIMCHistory u t)=ᵐ[volume]
      (fun t => unitStep t-(delayMismatchKernel (serialRatios σ N) δ ε ⋆ u) t) := by
    filter_upwards [zeroHistory_plant_kernel N σ δ hσ hu huc,
      zeroHistory_plant_kernel N σ (δ+ε) hσ hu huc,hh] with t ht hs hd
    have hDK : (fun t => shift (δ+ε) (serialImpulse σ N) t-shift δ (serialImpulse σ N) t)=
        delayMismatchKernel (serialRatios σ N) δ ε := by
      rw [serialImpulse_eq_cascade σ hfirst N]; rfl
    rw [hDK] at hd
    simp only [imcFilterInput,zeroIMCHistory,ht,hs]
    linarith
  filter_upwards [filterAction_congr F hq] with t ht
  unfold imcReferenceFeedback
  rw [ht]
  simp [filterFreeOutput,zeroIMCHistory,historyInput]

-- @paper-step thm:complete_attainment/general_cascade_causal_input_kernel
theorem ordinaryCascade_kernel_input {u : ℝ → ℝ} (hu : LocallyIntegrable u volume)
    (σ : ℕ → ℝ) (n : ℕ) (hσ : ∀ j≤n, 0<σ j) :
    causalize (ordinaryCascade σ u (n+1))=ᵐ[volume] (serialImpulse σ n ⋆ causalize u) := by
  induction n with
  | zero =>
    have hh := lagState_causal_formula (hσ 0 le_rfl) 0 u
    simpa only [lagState_zero,zero_mul,zero_add,ordinaryCascade,serialImpulse] using hh
  | succ n ih =>
    have hn : ∀ j≤n, 0<σ j := fun j hj => hσ j (by omega)
    have hs := hσ (n+1) le_rfl
    have hh := lagState_causal_formula hs 0 (ordinaryCascade σ u (n+1))
    simp only [lagState_zero,zero_mul,zero_add] at hh
    have he := convolution_congr (ContinuousLinearMap.lsmul ℝ ℝ)
      (EventuallyEq.rfl (f := lagKernel (σ (n+1)))) (ih hn)
    exact hh.trans ((Filter.EventuallyEq.of_eq he).trans
      (local_convolution_assoc (lagKernel_properties hs).1 (serialImpulse_properties σ n hn).1
        (lagKernel_properties hs).2.2.2 (serialImpulse_properties σ n hn).2
        (hu.indicator measurableSet_Ici) (causalize_causal _)))

-- @paper-step thm:complete_attainment/actual_delayed_step_output_kernel
theorem cascade_step_output_kernel (N : ℕ) (σ : ℕ → ℝ) (δ : ℝ)
    {v : ℝ → ℝ} (hv : Integrable v) (hσ : ∀ j≤N, 0<σ j) :
    (fun t => 1-cascadeStepError N σ δ v t)=ᵐ[volume]
      (shift δ (serialImpulse σ N) ⋆ causalize (fun t => 1+v t)) := by
  have hu : LocallyIntegrable (fun t => 1+v t) volume :=
    (continuous_const : Continuous (fun _ : ℝ => (1 : ℝ))).locallyIntegrable.add hv.locallyIntegrable
  have hzero := (ordinaryCascade_response hu σ N).initial
  have he : (fun t => 1-cascadeStepError N σ δ v t)=
      shift δ (causalize (ordinaryCascade σ (fun t => 1+v t) (N+1))) := by
    funext t
    by_cases ht : t≤δ
    · rcases ht.eq_or_lt with ht | ht
      · subst t
        simp [cascadeStepError,delayedError,shift,causalize,hzero]
      · simp [cascadeStepError,delayedError,shift,causalize,ht.le,show ¬0≤t-δ by linarith]
    · simp [cascadeStepError,delayedError,shift,causalize,ht,show 0≤t-δ by linarith]
  rw [he,shift_convolution_left]
  exact shift_congr (ordinaryCascade_kernel_input hu σ N hσ) δ

-- @paper-step thm:complete_robust/nominal_error_matches_actual_plant_step
theorem nominal_step_error_kernel (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) {δ : ℝ}
    (hδ : 0≤δ) {v : ℝ → ℝ} (hv : Integrable v) (hσ : ∀ j≤N, 0<σ j)
    (hstep : filterAction F unitStep=ᵐ[halfLine] (fun t => 1+v t)) :
    causalize (cascadeStepError N σ δ v)=ᵐ[volume]
      (fun t => unitStep t-(shift δ (serialImpulse σ N) ⋆ filterAction F unitStep) t) := by
  have hw : filterAction F unitStep=ᵐ[volume] causalize (fun t => 1+v t) :=
    causalize_of_halfLine_eq (filterAction_causal F (causalize_causal _)) hstep
  have hc := convolution_congr (ContinuousLinearMap.lsmul ℝ ℝ)
    (EventuallyEq.rfl (f := shift δ (serialImpulse σ N))) hw
  have hy := cascade_step_output_kernel N σ δ hv hσ
  filter_upwards [hy] with t ht
  rw [hc,← ht]
  by_cases hp : 0≤t
  · simp [causalize,unitStep,hp]
  · have hn : t≤δ := by linarith
    simp [causalize,unitStep,hp,cascadeStepError,delayedError,hn]

-- @paper-step thm:complete_robust/nominal_command_excess_matches_filter
theorem nominal_step_excess_kernel (F : IMCFilter) {v : ℝ → ℝ}
    (hstep : filterAction F unitStep=ᵐ[halfLine] (fun t => 1+v t)) :
    causalize v=ᵐ[volume] (fun t => filterAction F unitStep t-unitStep t) := by
  filter_upwards [causalize_of_halfLine_eq (filterAction_causal F (causalize_causal _)) hstep] with t ht
  change filterAction F unitStep t=causalize (fun t => 1+v t) t at ht
  rw [ht]
  by_cases hp : 0≤t <;> simp [causalize,unitStep,hp]

-- @paper-step thm:complete_robust/causal_extension_preserves_halfline_area
theorem absArea_causalize (f : ℝ → ℝ) : absArea (causalize f) volume=absArea f halfLine := by
  have he : (fun t => |causalize f t|)=(Ici 0).indicator (fun t => |f t|) := by
    funext t; by_cases ht : 0≤t <;> simp [causalize,ht]
  unfold absArea
  rw [he,integral_indicator measurableSet_Ici,integral_Ici_eq_integral_Ioi]

-- @paper-step thm:complete_robust/causal_extension_preserves_MIACE
theorem miace_causalize (α : ℝ) (e v : ℝ → ℝ) :
    miace α (causalize e) (causalize v) volume=miace α e v halfLine := by
  simp only [miace,absArea_causalize]

end MIACE
