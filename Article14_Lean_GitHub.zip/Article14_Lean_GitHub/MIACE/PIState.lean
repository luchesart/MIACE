import MIACE.Stability
import MIACE.Attainment

/-! Direct normalized PI loop, exactly the centered-integrator realization
in Appendix C. No energy, stability or transfer-balance assumptions. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

structure PIStateResponse (x r : ℝ) (e i : ℝ → ℝ) : Prop where
  ac_e : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval e 0 T
  ac_i : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval i 0 T
  ode_e : ∀ᵐ t : ℝ, 0 < t → deriv e t = -(1+x)*e t-i t
  ode_i : ∀ᵐ t : ℝ, 0 < t → deriv i t = (x/r)*e t
  initial_e : e 0 = 1
  initial_i : i 0 = -1

-- @paper-step prop:energies/direct_pi_law
theorem pi_state_integral_law {x r : ℝ} {e i : ℝ → ℝ} (h : PIStateResponse x r e i)
    (T : ℝ) (hT : 0 ≤ T) :
    1+(x*e T+i T) = x*e T+(x/r)*(∫ t in 0..T, e t) := by
  have hi := (h.ac_i T hT).integral_deriv_eq_sub
  have heq : (∫ t in 0..T, deriv i t) = (x/r)*(∫ t in 0..T, e t) := by
    rw [← intervalIntegral.integral_const_mul]
    apply intervalIntegral.integral_congr_ae
    filter_upwards [h.ode_i] with t ht hmem
    rw [uIoc_of_le hT] at hmem
    exact ht hmem.1
  rw [heq,h.initial_i] at hi
  linarith

-- @paper-step prop:energies/direct_to_canonical_ode
theorem pi_state_canonical_ode {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r) :
    (∀ᵐ t : ℝ, 0 < t → deriv (fun s => -(r/x)*i s) t = -e t) ∧
    (∀ᵐ t : ℝ, 0 < t → deriv (fun s => -e s) t =
      -(x/r)*(-(r/x)*i t)-(r*(1+x)/r)*(-e t)) := by
  constructor
  · filter_upwards [h.ode_i] with t ht hpos
    rw [deriv_const_mul_field,ht hpos]
    field_simp
    <;> ring
  · filter_upwards [h.ode_e] with t ht hpos
    change deriv (-e) t = _
    rw [deriv.neg,ht hpos]
    field_simp
    <;> ring

-- @paper-step prop:energies/direct_pi_stability
theorem pi_state_settles {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r) :
    Tendsto e atTop (𝓝 0) ∧ Tendsto i atTop (𝓝 0) := by
  have ho := pi_state_canonical_ode h hx hr
  have hf := canonical_settles hr (by positivity : 0 < r*(1+x)) hx
    (fun T hT => (h.ac_i T hT).const_mul (-(r/x)))
    (fun T hT => (h.ac_e T hT).neg) ho.1 ho.2
  constructor
  · simpa using hf.2.neg
  · have hh := hf.1.const_mul (-(x/r))
    have hid : (fun t => -(x/r)*(-(r/x)*i t)) = i := by
      funext t
      field_simp
    simpa only [hid,mul_zero] using hh

-- @paper-step prop:energies/full_statement
theorem paper_pi_energies {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r) :
    (Integrable (fun t => (e t)^2) halfLine ∧
      (∫ t, (e t)^2 ∂halfLine) = tracking x r) ∧
    (Integrable (fun t => (x*e t+i t)^2) halfLine ∧
      (∫ t, (x*e t+i t)^2 ∂halfLine) = effort x r) := by
  have ho := pi_state_canonical_ode h hx hr
  have hE := canonical_state_energy hr (by positivity : 0 < r*(1+x)) hx
    (fun T hT => (h.ac_i T hT).const_mul (-(r/x)))
    (fun T hT => (h.ac_e T hT).neg) ho.1 ho.2 (-1) 0
  have hU := canonical_state_energy hr (by positivity : 0 < r*(1+x)) hx
    (fun T hT => (h.ac_i T hT).const_mul (-(r/x)))
    (fun T hT => (h.ac_e T hT).neg) ho.1 ho.2 (-x) (-(x/r))
  have hfunE : (fun t => 0*(-(r/x)*i t)+(-1)*(-e t)) = e := by funext t; ring
  have hfunU : (fun t => -(x/r)*(-(r/x)*i t)+(-x)*(-e t)) = (fun t => x*e t+i t) := by
    funext t
    field_simp
    <;> ring
  simp only [zero_mul,neg_mul,one_mul,neg_neg,zero_add,Pi.neg_apply] at hE
  have hEs : (∫ t, (e t)^2 ∂halfLine) = tracking x r := by
    convert hE.2 using 1
    rw [h.initial_i,h.initial_e]
    unfold energyPotential tracking
    field_simp
    <;> ring
  have hUs : Integrable (fun t => (x*e t+i t)^2) halfLine ∧
      (∫ t, (x*e t+i t)^2 ∂halfLine) = energyPotential r (r*(1+x)) x (-x) (-(x/r))
        (-(r/x)*i 0) (-e 0) := by
    have hp : (fun t => (-(x/r)*(-(r/x)*i t)+(-x)*(-e t))^2) =
        (fun t => (x*e t+i t)^2) := congrArg (fun f : ℝ → ℝ => fun t => (f t)^2) hfunU
    rw [show (fun t => (-(x/r)*(-(r/x)*i t)+(-x)*(-e) t)^2) = _ from hp] at hU
    exact hU
  refine ⟨⟨hE.1,hEs⟩,⟨hUs.1,?_⟩⟩
  rw [hUs.2,h.initial_i,h.initial_e]
  unfold energyPotential effort
  field_simp
  <;> ring

-- @paper-step thm:global/attaining_pi_state
theorem exponential_pi_state (x : ℝ) :
    PIStateResponse x 1 (expError x) (fun t => -expError x t) := by
  have hac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval (expError x) 0 T := by
    intro T hT
    apply ContDiffOn.absolutelyContinuousOnInterval
    unfold expError
    fun_prop
  refine ⟨hac,fun T hT => (hac T hT).neg,?_,?_,?_,?_⟩
  · apply ae_of_all
    intro t ht
    rw [(exp_error_derivative x t).deriv]
    ring
  · apply ae_of_all
    intro t ht
    change deriv (-expError x) t = _
    rw [(exp_error_derivative x t).neg.deriv]
    ring
  · simp [expError]
  · simp [expError]
end MIACE
