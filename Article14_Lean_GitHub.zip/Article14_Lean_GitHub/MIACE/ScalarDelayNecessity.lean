import MIACE.ScalarDelayUniqueness

/-! The converse nonoscillation criterion for the actual ordinary response.
The proof uses only local regularity: neither integrability nor stability
is assumed of a hypothetical nonnegative response.

A nonnegative solution is decreasing and cannot have a first zero.
Integration over half a delay bounds its backward ratios. If l is an
eventual decay rate, the integrating factor improves it to x*exp(l*delta).
The iterated rates are increasing and bounded by the ratio estimate, so
their limit satisfies l=x*exp(l*delta), forcing x*delta<=exp(-1).
Only the sign change needed by Lemma 6 is asserted, not a general theorem
about infinitely many oscillations for every scalar-delay history. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step lem:delayed_cancellation/local_nonnegative_response_antitone
theorem scalarDelay_antitone_local {x δ : ℝ} (hx : 0<x) {E : ℝ → ℝ}
    (h : ScalarDelayResponse x δ E) (hn : ∀ t, 0≤t → 0≤E t) :
    AntitoneOn E (Ici 0) := by
  have hf := locally_integrable_interval (scalarDelay_shift_local h.continuous δ)
  have hp (t : ℝ) : 0≤shift δ (causalize E) t := by
    by_cases ht : 0≤t-δ
    · simpa [shift,causalize,ht] using hn (t-δ) ht
    · simp [shift,causalize,ht]
  intro a ha b hb hab
  have hI := intervalIntegral.integral_mono_interval le_rfl ha hab
    (ae_of_all _ hp) (hf 0 b)
  rw [h.integral_eq a ha,h.integral_eq b hb]
  nlinarith

-- @paper-step lem:delayed_cancellation/initial_delay_plateau
theorem scalarDelay_plateau {x δ : ℝ} {E : ℝ → ℝ}
    (h : ScalarDelayResponse x δ E) {t : ℝ} (ht : 0≤t) (htδ : t≤δ) : E t=1 := by
  rw [h.integral_eq t ht]
  have hz : (∫ s in 0..t, shift δ (causalize E) s)=0 := by
    rw [intervalIntegral.integral_of_le ht]
    apply integral_eq_zero_of_ae
    filter_upwards [ae_restrict_mem measurableSet_Ioc,
      (volume.ae_ne δ).filter_mono (ae_mono (Measure.restrict_le_self (s := Ioc 0 t)))] with s hs hne
    have hh : ¬0≤s-δ := by intro hh; apply hne; have := hs.2; linarith
    simp [shift,causalize,hh]
  rw [hz]; ring

-- @paper-step lem:delayed_cancellation/classical_derivative_after_first_delay
theorem scalarDelay_derivative_after {x δ : ℝ} (hδ : 0≤δ) {E : ℝ → ℝ}
    (h : ScalarDelayResponse x δ E) {t : ℝ} (ht : δ<t) :
    HasDerivAt E (-x*E (t-δ)) t := by
  have heq : shift δ (causalize E)=ᶠ[𝓝 t] (fun s => E (s-δ)) := by
    filter_upwards [Ioi_mem_nhds ht] with s hs
    simp [shift,causalize,sub_nonneg.mpr (le_of_lt (show δ<s from hs))]
  have hc : ContinuousAt (shift δ (causalize E)) t :=
    ((h.continuous.comp (continuous_id.sub continuous_const)).continuousAt).congr heq.symm
  have hi := locally_integrable_interval (scalarDelay_shift_local h.continuous δ) 0 t
  have hmeas : StronglyMeasurable (shift δ (causalize E)) :=
    (h.continuous.stronglyMeasurable.indicator measurableSet_Ici).comp_measurable
      (continuous_id.sub continuous_const).measurable
  have hd := ((intervalIntegral.integral_hasDerivAt_right hi
    hmeas.stronglyMeasurableAtFilter hc).const_mul x).const_sub 1
  have hf : E=ᶠ[𝓝 t] (fun s => 1-x*(∫ u in 0..s, shift δ (causalize E) u)) := by
    filter_upwards [Ioi_mem_nhds (hδ.trans_lt ht)] with s hs
    exact h.integral_eq s hs.le
  convert hd.congr_of_eventuallyEq hf using 1
  simp [shift,causalize,sub_nonneg.mpr ht.le]

-- @paper-step lem:delayed_cancellation/nonnegative_response_has_no_finite_zero
theorem scalarDelay_strict_positive {x δ : ℝ} (hx : 0<x) (hδ : 0<δ)
    {E : ℝ → ℝ} (h : ScalarDelayResponse x δ E)
    (hn : ∀ t, 0≤t → 0≤E t) : ∀ t, 0≤t → 0<E t := by
  intro t ht
  by_contra hp
  have hz : E t=0 := le_antisymm (le_of_not_gt hp) (hn t ht)
  let Z := Icc (0 : ℝ) t ∩ E ⁻¹' {0}
  have hZ : IsCompact Z := isCompact_Icc.inter_right
    (isClosed_singleton.preimage h.continuous)
  obtain ⟨c,hc,hmin⟩ := hZ.exists_isMinOn ⟨t,⟨⟨ht,le_rfl⟩,hz⟩⟩ continuous_id.continuousOn
  have hc0 : 0≤c := hc.1.1
  have hcz : E c=0 := hc.2
  have hcδ : δ<c := by
    by_contra hh
    have hh := scalarDelay_plateau h hc0 (le_of_not_gt hh)
    linarith
  have hprev : 0<E (c-δ) := by
    have hp0 := hn (c-δ) (by linarith)
    by_contra hh
    have he : E (c-δ)=0 := le_antisymm (le_of_not_gt hh) hp0
    have hh := hmin (show c-δ∈Z from ⟨⟨by linarith,by have := hc.1.2; linarith⟩,he⟩)
    change c≤c-δ at hh
    linarith
  have hlocal : IsLocalMin E c := by
    filter_upwards [Ioi_mem_nhds (hδ.trans hcδ)] with s hs
    simpa [hcz] using hn s hs.le
  have hd := hlocal.hasDerivAt_eq_zero (scalarDelay_derivative_after hδ.le h hcδ)
  nlinarith

-- @paper-step lem:delayed_cancellation/local_delay_increment_identity
theorem scalarDelay_increment {x δ : ℝ} (hδ : 0≤δ) {E : ℝ → ℝ}
    (h : ScalarDelayResponse x δ E) {t u : ℝ} (ht : δ≤t) (hu : δ≤u) :
    E t-E u=x*(∫ s in (t-δ)..(u-δ), E s) := by
  have he (s : ℝ) (hs : δ≤s) : E s=1-x*(∫ v in 0..(s-δ), E v) := by
    have hh := h.integral_eq ((s-δ)+δ) (by linarith : 0≤(s-δ)+δ)
    rw [scalarDelay_shift_primitive E hδ (by linarith)] at hh
    simpa using hh
  rw [he t ht,he u hu]
  have hi := intervalIntegral.integral_add_adjacent_intervals
    (h.continuous.intervalIntegrable (μ := volume) 0 (t-δ))
    (h.continuous.intervalIntegrable (t-δ) (u-δ))
  linear_combination -x*hi

-- @paper-step lem:delayed_cancellation/uniform_half_delay_ratio_bound
theorem scalarDelay_half_bound {x δ : ℝ} (hx : 0<x) (hδ : 0<δ)
    {E : ℝ → ℝ} (h : ScalarDelayResponse x δ E)
    (hn : ∀ t, 0≤t → 0≤E t) {t : ℝ} (ht : δ≤t) :
    (x*δ/2)*E (t-δ/2)≤E t := by
  have hm := scalarDelay_antitone_local hx h hn
  have hi := intervalIntegral.integral_mono_on (by linarith : t-δ≤t-δ/2)
    (intervalIntegrable_const (μ := volume) (c := E (t-δ/2)))
    (h.continuous.intervalIntegrable (t-δ) (t-δ/2))
    (fun s hs => hm (by change 0≤s; have := hs.1; linarith)
      (by change 0≤t-δ/2; linarith) hs.2)
  have he := scalarDelay_increment hδ.le h ht (show δ≤t+δ/2 by linarith)
  have hb := hn (t+δ/2) (by linarith)
  have hend : t+δ/2-δ=t-δ/2 := by ring
  rw [hend] at he
  simp only [intervalIntegral.integral_const,smul_eq_mul] at hi
  nlinarith

-- @paper-step lem:delayed_cancellation/exponential_rate_improvement
theorem scalarDelay_rate_improve {x δ l T : ℝ} (hx : 0<x) (hδ : 0<δ)
    {E : ℝ → ℝ} (h : ScalarDelayResponse x δ E) (hT : δ≤T)
    (hb : ∀ t, T≤t → l*E t≤x*E (t-δ)) :
    ∀ t, T+δ≤t → (x*Real.exp (l*δ))*E t≤x*E (t-δ) := by
  have hm : AntitoneOn (fun t => Real.exp (l*t)*E t) (Ici T) := by
    have hd (t : ℝ) (ht : t∈interior (Ici T)) :
        HasDerivAt (fun s => Real.exp (l*s)*E s)
          (Real.exp (l*t)*(l*E t-x*E (t-δ))) t := by
      have ht' : T<t := by simpa only [interior_Ici,mem_Ioi] using ht
      have hh := (((hasDerivAt_id t).const_mul l).exp).mul
        (scalarDelay_derivative_after hδ.le h (hT.trans_lt ht'))
      change HasDerivAt (fun s => Real.exp (l*s)*E s) _ t at hh
      convert hh using 1 <;> dsimp <;> ring
    apply antitoneOn_of_deriv_nonpos (convex_Ici T)
      ((by fun_prop : Continuous (fun t : ℝ => Real.exp (l*t))).mul h.continuous).continuousOn
      (fun t ht => (hd t ht).differentiableAt.differentiableWithinAt)
    intro t ht
    change deriv (fun s => Real.exp (l*s)*E s) t≤0
    rw [(hd t ht).deriv]
    have ht' : T<t := by simpa only [interior_Ici,mem_Ioi] using ht
    exact mul_nonpos_of_nonneg_of_nonpos (Real.exp_nonneg _) (sub_nonpos.mpr (hb t ht'.le))
  intro t ht
  have hh := hm (show t-δ∈Ici T by change T≤t-δ; linarith)
    (show t∈Ici T by change T≤t; linarith) (by linarith : t-δ≤t)
  have he : Real.exp (l*t)=Real.exp (l*(t-δ))*Real.exp (l*δ) := by
    rw [← Real.exp_add]; congr 1; ring
  dsimp only at hh
  rw [he,mul_assoc] at hh
  have hh' := (mul_le_mul_iff_right₀ (Real.exp_pos (l*(t-δ)))).mp hh
  nlinarith

noncomputable def scalarDelayRate (x δ : ℝ) : ℕ → ℝ
  | 0 => x
  | n+1 => x*Real.exp (scalarDelayRate x δ n*δ)

-- @paper-step lem:delayed_cancellation/iterated_rate_is_eventually_valid
theorem scalarDelay_rate_valid {x δ : ℝ} (hx : 0<x) (hδ : 0<δ)
    {E : ℝ → ℝ} (h : ScalarDelayResponse x δ E)
    (hn : ∀ t, 0≤t → 0≤E t) (n : ℕ) :
    ∃ T : ℝ, δ≤T ∧ ∀ t, T≤t → scalarDelayRate x δ n*E t≤x*E (t-δ) := by
  induction n with
  | zero =>
    refine ⟨δ,le_rfl,fun t ht => ?_⟩
    apply mul_le_mul_of_nonneg_left _ hx.le
    exact scalarDelay_antitone_local hx h hn (by change 0≤t-δ; linarith)
      (by change 0≤t; linarith) (by linarith)
  | succ n ih =>
    obtain ⟨T,hT,hb⟩ := ih
    exact ⟨T+δ,by linarith,scalarDelay_rate_improve hx hδ h hT hb⟩

-- @paper-step lem:delayed_cancellation/nonnegative_response_bounds_all_iterated_rates
theorem scalarDelay_rates_bounded {x δ : ℝ} (hx : 0<x) (hδ : 0<δ)
    {E : ℝ → ℝ} (h : ScalarDelayResponse x δ E)
    (hn : ∀ t, 0≤t → 0≤E t) : BddAbove (range (scalarDelayRate x δ)) := by
  let k := x*δ/2
  have hk : 0<k := by dsimp [k]; positivity
  refine ⟨x/(k*k),?_⟩
  rintro _ ⟨n,rfl⟩
  obtain ⟨T,hT,hb⟩ := scalarDelay_rate_valid hx hδ h hn n
  let t := max T (2*δ)
  have htT : T≤t := le_max_left _ _
  have htδ : 2*δ≤t := le_max_right _ _
  have ht0 : 0≤t := by linarith
  have h₁ := scalarDelay_half_bound hx hδ h hn (show δ≤t by linarith)
  have h₂ := scalarDelay_half_bound hx hδ h hn (show δ≤t-δ/2 by linarith)
  have he : t-δ/2-δ/2=t-δ := by ring
  rw [he] at h₂
  change k*E (t-δ/2)≤E t at h₁
  change k*E (t-δ)≤E (t-δ/2) at h₂
  have h₃ : (k*k)*E (t-δ)≤E t := by nlinarith [mul_le_mul_of_nonneg_left h₂ hk.le]
  have h₄ := mul_le_mul_of_nonneg_left (hb t htT) (mul_pos hk hk).le
  have h₅ := mul_le_mul_of_nonneg_left h₃ hx.le
  have hEt := scalarDelay_strict_positive hx hδ h hn t ht0
  apply (le_div_iff₀ (mul_pos hk hk)).mpr
  have hh : (scalarDelayRate x δ n*(k*k))*E t≤x*E t := by nlinarith [h₄,h₅]
  exact (mul_le_mul_iff_left₀ hEt).mp hh

-- @paper-step lem:delayed_cancellation/monotone_iterated_exponential_rates
theorem scalarDelay_rates_monotone {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ) :
    Monotone (scalarDelayRate x δ) := by
  apply monotone_nat_of_le_succ
  intro n
  induction n with
  | zero =>
    change x≤x*Real.exp (x*δ)
    have hh := Real.one_le_exp_iff.mpr (mul_nonneg hx.le hδ)
    nlinarith
  | succ n ih =>
    exact mul_le_mul_of_nonneg_left
      (Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_right ih hδ)) hx.le

-- @paper-step lem:delayed_cancellation/necessary_nonoscillation_threshold_without_decay_assumption
theorem scalarDelay_nonnegative_necessary {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    {E : ℝ → ℝ} (h : ScalarDelayResponse x δ E)
    (hn : ∀ t, 0≤t → 0≤E t) : x*δ≤Real.exp (-1) := by
  by_cases hd : δ=0
  · simp [hd,Real.exp_nonneg]
  have hd : 0<δ := lt_of_le_of_ne hδ (Ne.symm hd)
  have hb := scalarDelay_rates_bounded hx hd h hn
  let l : ℝ := ⨆ n, scalarDelayRate x δ n
  have hl : 0<l := hx.trans_le (le_ciSup hb 0)
  have ht : Tendsto (scalarDelayRate x δ) atTop (𝓝 l) :=
    tendsto_atTop_ciSup (scalarDelay_rates_monotone hx hδ) hb
  have he : l=x*Real.exp (l*δ) := by
    apply tendsto_nhds_unique (ht.comp (tendsto_add_atTop_nat 1))
    exact (Real.continuous_exp.tendsto _ |>.comp (ht.mul_const δ)).const_mul x
  apply (scalarDelay_tilt_iff hx hδ).mp
  refine ⟨l,hl,?_⟩
  have hh : Real.exp (l*δ)*Real.exp (-l*δ)=1 := by
    rw [← Real.exp_add]; ring_nf; simp
  calc
    l*Real.exp (-l*δ) = (x*Real.exp (l*δ))*Real.exp (-l*δ) := by rw [← he]
    _ = x := by rw [mul_assoc,hh,mul_one]

-- @paper-step lem:delayed_cancellation/exact_ordinary_response_nonnegativity_equivalence
theorem scalarDelay_nonnegative_iff {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    {E : ℝ → ℝ} (h : ScalarDelayResponse x δ E) :
    (∀ t, 0≤t → 0≤E t) ↔ x*δ≤Real.exp (-1) := by
  refine ⟨scalarDelay_nonnegative_necessary hx hδ h,?_⟩
  intro hb
  obtain ⟨F,hF,_,_,hFn,_⟩ := scalarDelay_monotone_sufficient hx hδ hb
  intro t ht
  rw [scalarDelay_response_unique hx hδ h hF t ht]
  exact (hFn t ht).1.le

-- @paper-step lem:delayed_cancellation/exact_ordinary_monotone_tracking_equivalence
theorem scalarDelay_monotone_iff {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    {E : ℝ → ℝ} (h : ScalarDelayResponse x δ E) :
    (MonotoneOn (fun t => 1-E t) (Ici 0) ∧
      1-E 0=0 ∧ Tendsto (fun t => 1-E t) atTop (𝓝 1)) ↔
      x*δ≤Real.exp (-1) := by
  constructor
  · rintro ⟨hm,_,hl⟩
    apply scalarDelay_nonnegative_necessary hx hδ h
    intro t ht
    have hb : 1-E t≤1 := by
      apply ge_of_tendsto hl
      filter_upwards [eventually_ge_atTop t] with s hs
      exact hm ht (ht.trans hs) hs
    linarith
  · intro hb
    obtain ⟨F,hF,_,_,_,hm,h0,hl,_⟩ := scalarDelay_monotone_sufficient hx hδ hb
    have he := scalarDelay_response_unique hx hδ h hF
    refine ⟨fun a ha b hb hab => ?_,by rw [h.initial]; ring,?_⟩
    · simpa only [he a ha,he b hb] using hm ha hb hab
    · apply hl.congr'
      filter_upwards [eventually_ge_atTop (0 : ℝ)] with t ht
      rw [he t ht]

-- @paper-step lem:delayed_cancellation/negative_error_above_exact_threshold
theorem scalarDelay_negative_value {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    {E : ℝ → ℝ} (h : ScalarDelayResponse x δ E) (hb : Real.exp (-1)<x*δ) :
    ∃ t : ℝ, 0≤t ∧ E t<0 := by
  by_contra hh
  push_neg at hh
  exact (not_le_of_gt hb) (scalarDelay_nonnegative_necessary hx hδ h hh)

end MIACE
