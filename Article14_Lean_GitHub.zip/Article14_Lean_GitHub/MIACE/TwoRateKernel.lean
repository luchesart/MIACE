import MIACE.TwoRate

/-! Конкретните знаци на K и R, масата на компактното ядро и
    експоненциалната интегруемост се доказват, а не се приемат. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:pid_two_rate_optimum/compact_continuous_integrability
theorem compact_indicator_integrable {f : ℝ → ℝ} (hf : Continuous f) (δ : ℝ) :
    Integrable ((Ico 0 δ).indicator f) := by
  apply IntegrableOn.integrable_indicator _ measurableSet_Ico
  exact (hf.integrableOn_Icc).mono_set Ico_subset_Icc_self

-- @paper-step thm:pid_two_rate_optimum/kernel_integrability
theorem twoRateK_integrable (A l m δ : ℝ) : Integrable (twoRateK A l m δ) :=
  compact_indicator_integrable (twoRate_continuous A l m).2 δ

-- @paper-step thm:pid_two_rate_optimum/kernel_causality
theorem twoRateK_causal (A l m δ : ℝ) : Causal (twoRateK A l m δ) := by
  apply ae_of_all
  intro t ht
  simp [twoRateK,not_le.mpr ht]

-- @paper-step thm:pid_two_rate_optimum/kernel_nonnegativity
theorem twoRateK_nonneg {A l m δ : ℝ} (hA : 1 ≤ A) (hl : 1 < l)
    (hlm : l ≤ m) (hzero : 1 ≤ l*A+m*(1-A)) :
    ∀ t, 0 ≤ twoRateK A l m δ t := by
  intro t
  by_cases ht : t ∈ Ico (0 : ℝ) δ
  · rw [twoRateK,indicator_of_mem ht]
    exact (twoRateG_positive hA hlm ht.1).le.trans (twoRateD_ge_G hA hl hlm hzero ht.1)
  · simp [twoRateK,ht]

-- @paper-step thm:pid_two_rate_optimum/kernel_mass
theorem twoRateK_integral (A l m : ℝ) {δ : ℝ} (hδ : 0 ≤ δ) :
    (∫ t, twoRateK A l m δ t)=1-twoRateG A l m δ := by
  rw [twoRateK,integral_indicator measurableSet_Ico,integral_Ico_eq_integral_Ioc,
    ← intervalIntegral.integral_of_le hδ]
  have he := intervalIntegral.integral_eq_sub_of_hasDerivAt
    (fun t (_ : t ∈ uIcc (0 : ℝ) δ) => (twoRate_derivative A l m t).neg)
    (by simpa only [neg_neg] using (twoRate_continuous A l m).2.intervalIntegrable (μ := volume) 0 δ)
  simp only [neg_neg] at he
  simpa only [Pi.neg_apply,(twoRate_initial A l m).1,neg_sub_neg] using he

-- @paper-step thm:pid_two_rate_optimum/kernel_strict_contraction
theorem twoRateK_small {A l m δ : ℝ} (hA : 1 ≤ A) (hlm : l ≤ m) (hδ : 0 ≤ δ) :
    (∫ t, twoRateK A l m δ t) < 1 := by
  rw [twoRateK_integral A l m hδ]
  linarith [twoRateG_positive hA hlm hδ]

-- @paper-step thm:pid_two_rate_optimum/kernel_all_exponential_moments
theorem twoRateK_weighted (A l m δ η : ℝ) :
    Integrable (expWeight η (twoRateK A l m δ)) := by
  have he : expWeight η (twoRateK A l m δ) =
      (Ico 0 δ).indicator (fun t => Real.exp (η*t)*twoRateD A l m t) := by
    funext t
    by_cases ht : t ∈ Ico (0 : ℝ) δ <;> simp [expWeight,twoRateK,ht]
  rw [he]
  apply compact_indicator_integrable
  exact (by fun_prop : Continuous (fun t : ℝ => Real.exp (η*t))).mul
    (twoRate_continuous A l m).2

-- @paper-step thm:pid_two_rate_optimum/command_tail
theorem twoRateR_tail (A l m δ t : ℝ) (ht : δ ≤ t) :
    twoRateR A l m δ t=twoRateD A l m (t+δ)-twoRateG A l m (t+δ) := by
  simp [twoRateR,max_eq_right ht]

-- @paper-step thm:pid_two_rate_optimum/command_initial_interval
theorem twoRateR_initial (A l m δ t : ℝ) (ht : t ≤ δ) :
    twoRateR A l m δ t=twoRateG A l m δ+
      A*((l-1)*Real.exp (-l*δ)-1)*Real.exp (-l*t)+
      (1-A)*((m-1)*Real.exp (-m*δ)-1)*Real.exp (-m*t) := by
  unfold twoRateR
  rw [max_eq_left ht]
  unfold twoRateG twoRateD
  rw [show -l*(t+δ)=(-l*t)+(-l*δ) by ring,
    show -m*(t+δ)=(-m*t)+(-m*δ) by ring,Real.exp_add,Real.exp_add]
  ring

-- @paper-step thm:pid_two_rate_optimum/three_scalar_sign_checks
theorem twoRateR_initial_nonneg {A l m δ : ℝ} (hA : 1 ≤ A) (hm : 0 ≤ m)
    (hc₁ : 0 ≤ (l-1)*Real.exp (-l*δ)-1)
    (hc₂ : 0 ≤ (m-1)*Real.exp (-m*δ)-1)
    (hcheck : (A-1)*((m-1)*Real.exp (-m*δ)-1) ≤ twoRateG A l m δ)
    {t : ℝ} (ht : 0 ≤ t) (htδ : t ≤ δ) : 0 ≤ twoRateR A l m δ t := by
  rw [twoRateR_initial A l m δ t htδ]
  have hp : 0 ≤ A*((l-1)*Real.exp (-l*δ)-1)*Real.exp (-l*t) := by positivity
  have he : Real.exp (-m*t) ≤ 1 := Real.exp_le_one_iff.mpr (by nlinarith)
  have hn := mul_nonneg (mul_nonneg (sub_nonneg.mpr hA) hc₂) (sub_nonneg.mpr he)
  nlinarith

-- @paper-step thm:pid_two_rate_optimum/command_global_nonnegativity
theorem twoRateR_nonneg {A l m δ : ℝ} (hA : 1 ≤ A) (hl : 1 < l)
    (hlm : l ≤ m) (hzero : 1 ≤ l*A+m*(1-A)) (hδ : 0 ≤ δ)
    (hinit : ∀ t ∈ Icc (0 : ℝ) δ, 0 ≤ twoRateR A l m δ t) :
    ∀ t ∈ Ici (0 : ℝ), 0 ≤ twoRateR A l m δ t := by
  intro t ht
  by_cases htδ : t ≤ δ
  · exact hinit t ⟨ht,htδ⟩
  · rw [twoRateR_tail A l m δ t (le_of_not_ge htδ)]
    exact sub_nonneg.mpr (twoRateD_ge_G hA hl hlm hzero (by linarith [ht]))

-- @paper-step thm:pid_two_rate_optimum/weighted_causal_extension
theorem expWeight_causalize (η : ℝ) (f : ℝ → ℝ) :
    expWeight η (causalize f)=causalize (expWeight η f) := by
  funext t
  by_cases ht : t ∈ Ici (0 : ℝ) <;> simp [causalize,expWeight,ht]

-- @paper-step thm:pid_two_rate_optimum/weighted_exponential_pair
theorem weighted_exp_pair_integrable (C D δ : ℝ) {l m η : ℝ}
    (hl : η < l) (hm : η < m) :
    Integrable (expWeight η (causalize (fun t =>
      C*Real.exp (-l*(t+δ))+D*Real.exp (-m*(t+δ))))) := by
  rw [expWeight_causalize]
  have he : expWeight η (fun t => C*Real.exp (-l*(t+δ))+D*Real.exp (-m*(t+δ))) =
      (fun t => (C*Real.exp (-l*δ))*Real.exp (-(l-η)*t)+
        (D*Real.exp (-m*δ))*Real.exp (-(m-η)*t)) := by
    funext t
    unfold expWeight
    dsimp only
    rw [show -l*(t+δ)=(-l*δ)+(-l*t) by ring,
      show -m*(t+δ)=(-m*δ)+(-m*t) by ring,Real.exp_add,Real.exp_add]
    have hel : Real.exp (η*t)*Real.exp (-l*t)=Real.exp (-(l-η)*t) := by
      rw [← Real.exp_add]; congr 1; ring
    have hem : Real.exp (η*t)*Real.exp (-m*t)=Real.exp (-(m-η)*t) := by
      rw [← Real.exp_add]; congr 1; ring
    calc
      _ = (C*Real.exp (-l*δ))*(Real.exp (η*t)*Real.exp (-l*t))+
          (D*Real.exp (-m*δ))*(Real.exp (η*t)*Real.exp (-m*t)) := by ring
      _ = _ := by rw [hel,hem]
  rw [he]
  apply causalize_integrable
  exact ((integrableOn_exp_mul_Ioi (by linarith : -(l-η)<0) 0).const_mul _).add
    ((integrableOn_exp_mul_Ioi (by linarith : -(m-η)<0) 0).const_mul _)

-- @paper-step thm:pid_two_rate_optimum/weighted_error_forcing
theorem twoRateG_weighted (A : ℝ) {l m η : ℝ} (hl : η < l) (hm : η < m) :
    Integrable (expWeight η (causalize (twoRateG A l m))) := by
  change Integrable (expWeight η (causalize (fun t => A*Real.exp (-l*t)+(1-A)*Real.exp (-m*t))))
  simpa only [add_zero] using weighted_exp_pair_integrable A (1-A) 0 hl hm

-- @paper-step thm:pid_two_rate_optimum/command_tail_compact_split
theorem twoRateR_split (A l m δ : ℝ) :
    causalize (twoRateR A l m δ) =
      (fun t => causalize (fun s => twoRateD A l m (s+δ)-twoRateG A l m (s+δ)) t+
        (Ico 0 δ).indicator (fun s => twoRateG A l m δ-twoRateG A l m s) t) := by
  funext t
  by_cases ht : 0 ≤ t
  · simp only [causalize,indicator_of_mem (show t ∈ Ici (0 : ℝ) from ht)]
    by_cases htδ : t < δ
    · rw [indicator_of_mem (show t ∈ Ico (0 : ℝ) δ from ⟨ht,htδ⟩)]
      simp only [twoRateR,max_eq_left htδ.le]
      ring
    · rw [indicator_of_notMem (show t ∉ Ico (0 : ℝ) δ from fun h => htδ h.2),add_zero]
      exact twoRateR_tail A l m δ t (le_of_not_gt htδ)
  · simp [causalize,ht]

-- @paper-step thm:pid_two_rate_optimum/weighted_command_forcing
theorem twoRateR_weighted (A δ : ℝ) {l m η : ℝ} (hl : η < l) (hm : η < m) :
    Integrable (expWeight η (causalize (twoRateR A l m δ))) := by
  have hi := weighted_exp_pair_integrable ((l-1)*A) ((m-1)*(1-A)) δ hl hm
  have he : (fun t => (l-1)*A*Real.exp (-l*(t+δ))+(m-1)*(1-A)*Real.exp (-m*(t+δ)))=
      (fun t => twoRateD A l m (t+δ)-twoRateG A l m (t+δ)) := by
    funext t; unfold twoRateD twoRateG; ring
  rw [he] at hi
  have hc : Integrable ((Ico (0 : ℝ) δ).indicator
      (fun t => Real.exp (η*t)*(twoRateG A l m δ-twoRateG A l m t))) := by
    apply compact_indicator_integrable
    exact (by fun_prop : Continuous (fun t : ℝ => Real.exp (η*t))).mul
      (continuous_const.sub (twoRate_continuous A l m).1)
  apply (hi.add hc).congr
  apply ae_of_all
  intro t
  rw [twoRateR_split]
  by_cases ht : t ∈ Ico (0 : ℝ) δ <;> simp [expWeight,ht,mul_add]

end MIACE
