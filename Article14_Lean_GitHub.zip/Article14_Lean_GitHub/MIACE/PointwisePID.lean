import MIACE.StateTransforms

/-! Етап 10: действителната команда от построените състояния съвпада
    точково с 1+V. Равенството е извод от проверената единственост. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:pid_two_rate_optimum/step_plus_signal_transform
theorem laplace_step_add {v : ℝ → ℝ} (hv : Integrable v halfLine) {p : ℝ} (hp : 0<p) :
    Integrable (fun t => Real.exp (-p*t)*(1+v t)) halfLine ∧
      laplace (fun t => 1+v t) p=1/p+laplace v p := by
  have hc : Integrable (fun t : ℝ => Real.exp (-p*t)) halfLine :=
    integrableOn_exp_mul_Ioi (by linarith : -p<0) 0
  have hvp := laplace_integrable hv hp.le
  constructor
  · have hi : Integrable (fun t => Real.exp (-p*t)+Real.exp (-p*t)*v t) halfLine :=
      hc.add hvp
    apply hi.congr
    exact ae_of_all _ (fun t => by ring)
  · unfold laplace
    simp_rw [mul_add,mul_one]
    rw [integral_add hc hvp]
    have hs := laplace_step p hp
    simpa only [laplace,mul_one] using congrArg (fun x => x+laplace v p) hs

-- @paper-step thm:pid_two_rate_optimum/actual_pointwise_PID_law
theorem ordinary_PID_command {i ρ ell δ : ℝ} {E V : ℝ → ℝ}
    (hρ : 0<ρ) (h : OrdinaryPIDSignals i ρ ell δ E V) :
    ∀ t : ℝ, 0≤t →
      pidTimeCommand (i*(1+ell-ρ)) i (i*(ell-ρ)*(1-ρ)) ρ E t=1+V t := by
  apply laplace_injective_weighted (a := 1)
    (pidTimeCommand_transform h.plant.error_integrable _ _ _ hρ (by norm_num : (0 : ℝ)<1)).1
    (laplace_step_add h.plant.command_integrable (by norm_num : (0 : ℝ)<1)).1
    (pidTimeCommand_continuous h.error_continuous _ _ _ _)
    (continuous_const.add h.command_continuous)
  intro p hp
  have hp0 : 0<p := by linarith
  rw [(pidTimeCommand_transform h.plant.error_integrable _ _ _ hρ hp0).2,
    (laplace_step_add h.plant.command_integrable hp0).2]
  exact (h.controller p hp0).symm

-- @paper-step thm:pid_two_rate_optimum/actual_PID_command_settling
theorem ordinary_PID_command_settles {i ρ ell δ : ℝ} {E V : ℝ → ℝ}
    (hρ : 0<ρ) (h : OrdinaryPIDSignals i ρ ell δ E V) :
    Tendsto (pidTimeCommand (i*(1+ell-ρ)) i (i*(ell-ρ)*(1-ρ)) ρ E) atTop (𝓝 1) := by
  have hv := (ordinary_PID_settling h).2.1
  have hl : Tendsto (fun t => 1+V t) atTop (𝓝 1) := by
    simpa using tendsto_const_nhds.add hv
  apply hl.congr'
  filter_upwards [eventually_ge_atTop (0 : ℝ)] with t ht
  exact (ordinary_PID_command hρ h t ht).symm

end MIACE
