import MIACE.PIState

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def physicalCost (Q R τ k : ℝ) (e v : ℝ → ℝ) : ℝ :=
  Q*(∫ t, (e (t/τ))^2 ∂halfLine)+R*(∫ t, (v (t/τ)/k)^2 ∂halfLine)

-- @paper-step thm:global/time_and_amplitude_scaling
theorem physical_energy_scaling (f : ℝ → ℝ) (τ k : ℝ) (hτ : 0 < τ) :
    (∫ t, (f (t/τ)/k)^2 ∂halfLine) = (τ/k^2)*(∫ t, (f t)^2 ∂halfLine) := by
  have hs := integral_comp_mul_right_Ioi (fun t => (f t)^2) 0 (inv_pos.mpr hτ)
  simp only [zero_mul,inv_inv,smul_eq_mul,← div_eq_mul_inv] at hs
  unfold halfLine
  simp_rw [div_pow]
  rw [integral_div,hs]
  ring

-- @paper-step thm:global/physical_integrability
theorem physical_energy_integrable {f : ℝ → ℝ} (hf : Integrable (fun t => (f t)^2) halfLine)
    (τ k : ℝ) (hτ : 0 < τ) : Integrable (fun t => (f (t/τ)/k)^2) halfLine := by
  have hh := (integrableOn_Ioi_comp_mul_right_iff (fun t => (f t)^2) 0 (inv_pos.mpr hτ)).2
    (by simpa only [zero_mul,halfLine,IntegrableOn] using hf)
  simpa only [div_pow,← div_eq_mul_inv] using hh.div_const (k^2)

-- @paper-step thm:global/physical_cost_identity
theorem pi_physical_cost {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r)
    (Q R τ k : ℝ) (hR : 0 < R) (hτ : 0 < τ) (hk : 0 < k) :
    physicalCost Q R τ k e (fun t => x*e t+i t) =
      (R*τ/k^2)*quadratic (Q*k^2/R) x r := by
  obtain ⟨he,hu⟩ := paper_pi_energies h hx hr
  have hs := physical_energy_scaling e τ 1 hτ
  simp only [div_one,one_pow] at hs
  unfold physicalCost
  rw [hs,physical_energy_scaling (fun t => x*e t+i t) τ k hτ,he.2,hu.2]
  unfold quadratic
  field_simp
  <;> ring

-- All clauses of Theorem 26: actual integrals, exact gap, unique parameters,
-- physical scaling, and an explicit PI response attaining the minimum.
-- @paper-step thm:global/full_statement
theorem paper_global_quadratic {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r)
    (Q R τ k : ℝ) (hQ : 0 < Q) (hR : 0 < R) (hτ : 0 < τ) (hk : 0 < k) :
    let q := Q*k^2/R
    let s := Real.sqrt (1+q)
    let F := q*(∫ t, (e t)^2 ∂halfLine)+(∫ t, (x*e t+i t)^2 ∂halfLine)
    (F-(s-1) = (s*r-x)^2/(2*r*x*(1+x))+(x-s)^2/(2*(1+x))) ∧
    (s-1 ≤ F) ∧ (F = s-1 ↔ x=s ∧ r=1) ∧
    (physicalCost Q R τ k e (fun t => x*e t+i t) = (R*τ/k^2)*F) ∧
    ((R*τ/k^2)*(s-1) ≤ physicalCost Q R τ k e (fun t => x*e t+i t)) ∧
    (physicalCost Q R τ k e (fun t => x*e t+i t) = (R*τ/k^2)*(s-1) ↔
      x/k=s/k ∧ r*τ=τ) ∧
    (physicalCost Q R τ k (expError s) (fun t => (s-1)*expError s t) =
      (R*τ/k^2)*(s-1)) := by
  dsimp only
  have hq : 0 < Q*k^2/R := by positivity
  have hs : 0 < Real.sqrt (1+Q*k^2/R) := Real.sqrt_pos.mpr (by positivity)
  have hs2 : (Real.sqrt (1+Q*k^2/R))^2 = 1+Q*k^2/R := Real.sq_sqrt (by positivity)
  obtain ⟨he,hu⟩ := paper_pi_energies h hx hr
  rw [he.2,hu.2]
  change (quadratic _ _ _ - _ = _) ∧ (_ ≤ quadratic _ _ _) ∧
    (quadratic _ _ _ = _ ↔ _) ∧ _
  have hscale := pi_physical_cost h hx hr Q R τ k hR hτ hk
  have hl := quadratic_lower_bound (Q*k^2/R) _ x r hx hr hs2
  have heq := quadratic_sqrt_optimum (Q*k^2/R) x r hq hx hr
  have hp : 0 < R*τ/k^2 := by positivity
  refine ⟨quadratic_gap _ _ x r hx hr hs2,hl,heq,hscale,?_,?_,?_⟩
  · rw [hscale]
    exact mul_le_mul_of_nonneg_left hl hp.le
  · rw [hscale,mul_right_inj' (ne_of_gt hp),heq]
    constructor
    · rintro ⟨rfl,rfl⟩; simp
    · rintro ⟨hg,ht⟩
      exact ⟨(div_left_inj' (ne_of_gt hk)).mp hg,
        (mul_right_cancel₀ (ne_of_gt hτ) (by simpa using ht : r*τ=1*τ))⟩
  · have ht := pi_physical_cost (exponential_pi_state (Real.sqrt (1+Q*k^2/R))) hs
      zero_lt_one Q R τ k hR hτ hk
    have hcst := (quadratic_sqrt_optimum (Q*k^2/R) _ 1 hq hs zero_lt_one).mpr ⟨rfl,rfl⟩
    rw [hcst] at ht
    convert ht using 1
    congr 1
    funext t
    ring
end MIACE
