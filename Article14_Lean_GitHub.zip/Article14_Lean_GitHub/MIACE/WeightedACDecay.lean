import MIACE.CascadeOrdinary

/-! A weighted W^{1,1} estimate converts the constructed ordinary
resolvent into a pointwise exponential bound. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:n_construction/weighted_finite_interval_bound
theorem weighted_interval_abs_bound {f : ℝ → ℝ} {η t u : ℝ} (hη : 0≤η)
    (ht : 0≤t) (htu : t≤u) (hi : IntervalIntegrable f volume t u)
    (hw : Integrable (expWeight η f)) :
    (∫ s in t..u, |f s|)≤Real.exp (-η*t)*(∫ s, |expWeight η f s|) := by
  have hb (s : ℝ) (hs : s∈Icc t u) : |f s|≤Real.exp (-η*t)*|expWeight η f s| := by
    rw [expWeight,abs_mul,abs_of_pos (Real.exp_pos _),← mul_assoc,← Real.exp_add]
    have hh : 1≤Real.exp (-η*t+η*s) := Real.one_le_exp_iff.mpr (by nlinarith [hs.1])
    nlinarith [abs_nonneg (f s)]
  have hh := intervalIntegral.integral_mono_on htu hi.abs
    ((hw.abs.const_mul (Real.exp (-η*t))).intervalIntegrable) hb
  rw [intervalIntegral.integral_const_mul] at hh
  have hpartial : (∫ s in t..u, |expWeight η f s|)≤∫ s, |expWeight η f s| := by
    rw [intervalIntegral.integral_of_le htu]
    exact setIntegral_le_integral hw.abs (ae_of_all _ (fun _ => abs_nonneg _))
  exact hh.trans (mul_le_mul_of_nonneg_left hpartial (Real.exp_nonneg _))

-- @paper-step thm:n_construction/weighted_ordinary_ode_pointwise_decay
theorem weighted_AC_decay {R F : ℝ → ℝ} {η : ℝ} (hη : 0≤η)
    (hR : Continuous R) (hF : Integrable F) (hwR : Integrable (expWeight η (causalize R)))
    (hwF : Integrable (expWeight η F))
    (hftc : ∀ u v, 0≤u → u≤v → (∫ s in u..v, F s)=R v-R u) :
    ∀ t, 0≤t → |R t|≤
      ((∫ s, |expWeight η (causalize R) s|)+(∫ s, |expWeight η F s|))*Real.exp (-η*t) := by
  intro t ht
  let D := Real.exp (-η*t)*(∫ s, |expWeight η F s|)
  have hb (s : ℝ) (hs : s∈Icc t (t+1)) : |R t|≤|R s|+D := by
    have hdiff : |R s-R t|≤D := by
      rw [← hftc t s ht hs.1]
      have hh := intervalIntegral.norm_integral_le_integral_norm (f := F) (μ := volume) hs.1
      simp only [Real.norm_eq_abs] at hh
      exact hh.trans (weighted_interval_abs_bound hη ht hs.1 hF.intervalIntegrable hwF)
    have hh := abs_add_le (R s) (R t-R s)
    rw [add_sub_cancel] at hh
    rw [abs_sub_comm (R t) (R s)] at hh
    linarith
  have hbound := intervalIntegral.integral_mono_on (show t≤t+1 by linarith)
    intervalIntegrable_const ((hR.abs.add continuous_const).intervalIntegrable (μ := volume) t (t+1)) hb
  change (∫ s in t..t+1, |R t|)≤(∫ s in t..t+1, |R s|+D) at hbound
  rw [intervalIntegral.integral_add (hR.abs.intervalIntegrable t (t+1)) intervalIntegrable_const,
    intervalIntegral.integral_const,intervalIntegral.integral_const] at hbound
  simp only [add_sub_cancel_left,smul_eq_mul,one_mul] at hbound
  have hlocal : IntervalIntegrable (causalize R) volume t (t+1) := by
    apply (hR.intervalIntegrable t (t+1)).congr
    intro s hs
    rw [uIoc_of_le (show t≤t+1 by linarith)] at hs
    simp [causalize,show 0≤s from ht.trans hs.1.le]
  have hRbound := weighted_interval_abs_bound hη ht (show t≤t+1 by linarith) hlocal hwR
  have he : (∫ s in t..t+1, |causalize R s|)=(∫ s in t..t+1, |R s|) := by
    apply intervalIntegral.integral_congr
    intro s hs
    rw [uIcc_of_le (show t≤t+1 by linarith)] at hs
    simp [causalize,show 0≤s from ht.trans hs.1]
  rw [he] at hRbound
  dsimp only [D] at hbound
  nlinarith

-- @paper-step thm:n_construction/compact_resolvent_pointwise_exponential_decay
theorem compact_resolvent_decay {J : ℝ → ℝ} (hc : Continuous J) {δ a c ε η : ℝ}
    (hη : 0<η) {R : ℝ → ℝ} (h : CompactResolventEvolution J δ a c ε R)
    (hi : Integrable (causalize R)) (hw : Integrable (expWeight η (causalize R))) :
    ∃ C : ℝ, 0≤C ∧ ∀ t, 0≤t → |R t|≤C*Real.exp (-η*t) := by
  let F := fun t => -(c/a)*causalize R t-(ε/a)*(compactKernel J δ ⋆ causalize R) t
  have hJ := compactKernel_integrable hc δ
  have hF : Integrable F := (hi.const_mul (-(c/a))).sub
    ((hJ.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hi).const_mul (ε/a))
  have hwF : Integrable (expWeight η F) := by
    have hh := (hw.const_mul (-(c/a))).sub
      (((compactKernel_weighted hc δ η).integrable_convolution
        (ContinuousLinearMap.lsmul ℝ ℝ) hw).const_mul (ε/a))
    rw [← expWeight_convolution] at hh
    convert hh using 1
    funext t; dsimp [F,expWeight]; ring
  have hftc (u v : ℝ) (hu : 0≤u) (huv : u≤v) :
      (∫ s in u..v, F s)=R v-R u := by
    rw [← (h.ac u v).integral_deriv_eq_sub]
    apply intervalIntegral.integral_congr_ae
    filter_upwards [h.ode] with t hd ht
    rw [uIoc_of_le huv] at ht
    have ht0 : 0<t := hu.trans_lt ht.1
    rw [(hd ht0).deriv]
    simp only [F,causalize,indicator_of_mem (show t∈Ici (0 : ℝ) from ht0.le)]
  refine ⟨(∫ s, |expWeight η (causalize R) s|)+(∫ s, |expWeight η F s|),
    add_nonneg (integral_nonneg (fun _ => abs_nonneg _)) (integral_nonneg (fun _ => abs_nonneg _)),?_⟩
  exact weighted_AC_decay hη.le h.continuous hF hw hwF hftc

end MIACE
