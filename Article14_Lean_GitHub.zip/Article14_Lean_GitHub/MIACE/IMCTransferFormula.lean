import MIACE.RobustFamilies

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def restPolynomial (ss : List ℝ) (p : ℝ) : ℝ :=
  (ss.map (fun σ => 1+σ*p)).prod
noncomputable def imcControllerTransfer (F : IMCFilter) (P : ℝ → ℝ) (p : ℝ) : ℝ :=
  filterTransfer F p/(1-P p*filterTransfer F p)

-- @paper-step thm:complete_attainment/remaining_lag_polynomial_bound
theorem restPolynomial_ge_one (ss : List ℝ) (hs : ∀ σ∈ss, 0<σ) {p : ℝ} (hp : 0≤p) :
    1≤restPolynomial ss p := by
  induction ss with
  | nil => simp [restPolynomial]
  | cons σ ss ih =>
    have hσ := hs σ (by simp)
    have hb := ih (fun τ hτ => hs τ (by simp [hτ]))
    have hsp := mul_nonneg hσ.le hp
    change 1≤(1+σ*p)*restPolynomial ss p
    nlinarith

-- @paper-step thm:complete_attainment/finite_inverse_lag_product
theorem inverse_lag_product (ss : List ℝ) (p : ℝ) :
    (ss.map (fun σ => 1/(1+σ*p))).prod=1/restPolynomial ss p := by
  induction ss with
  | nil => simp [restPolynomial]
  | cons σ ss ih =>
    change (1/(1+σ*p))*(ss.map (fun τ => 1/(1+τ*p))).prod=
      1/((1+σ*p)*restPolynomial ss p)
    rw [ih]
    exact one_div_mul_one_div _ _

-- @paper-step thm:complete_attainment/actual_cascade_polynomial_transfer
theorem cascadeKernel_polynomial_transfer (ss : List ℝ) (hs : ∀ σ∈ss, 0<σ)
    {p : ℝ} (hp : 0≤p) :
    laplace (cascadeKernel ss) p=1/((1+p)*restPolynomial ss p) := by
  rw [cascadeKernel_laplace ss hs hp,inverse_lag_product]
  exact one_div_mul_one_div _ _

-- @paper-step thm:complete_attainment/ordinary_IMC_to_output_feedback_algebra
theorem imc_output_feedback_algebra (F P E U : ℝ) (h : U=F*(E+P*U))
    (hden : 1-P*F≠0) : U=(F/(1-P*F))*E := by
  rw [div_mul_eq_mul_div]
  apply (eq_div_iff hden).mpr
  nlinarith

-- @paper-step thm:complete_attainment/exact_nominal_output_transfer
theorem exponentialIMC_output_transfer (ss : List ℝ) (hs : ∀ σ∈ss, 0<σ)
    {a δ p : ℝ} (ha : 0<a) (hδ : 0≤δ) (hp : 0≤p) :
    laplace (shift δ (cascadeKernel ss)) p*filterTransfer (exponentialIMC a ha) p=
      Real.exp (-δ*p)/(restPolynomial ss p*(1+a*p)) := by
  have hB : restPolynomial ss p≠0 := ne_of_gt (lt_of_lt_of_le zero_lt_one (restPolynomial_ge_one ss hs hp))
  have hp1 : 1+p≠0 := by positivity
  have ha1 : 1+a*p≠0 := by positivity
  rw [laplace_shift (cascadeKernel_properties ss hs).2.2.2 hδ p,
    cascadeKernel_polynomial_transfer ss hs hp,exponentialIMC_transfer ha hp]
  field_simp <;> ring

-- @paper-step thm:complete_attainment/exact_displayed_controller_transfer
theorem exponentialIMC_controller_transfer (ss : List ℝ) (hs : ∀ σ∈ss, 0<σ)
    {a δ p : ℝ} (ha : 0<a) (hδ : 0≤δ) (hp : 0<p) :
    imcControllerTransfer (exponentialIMC a ha) (laplace (shift δ (cascadeKernel ss))) p=
      (1+p)*restPolynomial ss p/((1+a*p)*restPolynomial ss p-Real.exp (-δ*p)) := by
  have hB1 := restPolynomial_ge_one ss hs hp.le
  have hB : restPolynomial ss p≠0 := ne_of_gt (lt_of_lt_of_le zero_lt_one hB1)
  have hp1 : 1+p≠0 := by positivity
  have ha1 : 1+a*p≠0 := by positivity
  have hexp : Real.exp (-δ*p)≤1 := Real.exp_le_one_iff.mpr (by nlinarith)
  have hden : (1+a*p)*restPolynomial ss p-Real.exp (-δ*p)≠0 := by
    have hh := mul_le_mul_of_nonneg_left hB1 (show 0≤1+a*p by positivity)
    have hap := mul_pos ha hp
    nlinarith
  unfold imcControllerTransfer
  rw [exponentialIMC_output_transfer ss hs ha hδ hp.le,exponentialIMC_transfer ha hp.le]
  field_simp <;> ring

-- @paper-step thm:complete_attainment/physical_gain_and_time_scaling
theorem imc_physical_scaling (P C : ℝ → ℝ) (k τ s : ℝ) (hk : k≠0) :
    (k*P (τ*s))*(C (τ*s)/k)=P (τ*s)*C (τ*s) ∧
      ((k*P (τ*s))*(C (τ*s)/k))/(1+(k*P (τ*s))*(C (τ*s)/k))=
        (P (τ*s)*C (τ*s))/(1+P (τ*s)*C (τ*s)) := by
  have he : (k*P (τ*s))*(C (τ*s)/k)=P (τ*s)*C (τ*s) := by field_simp
  exact ⟨he,by rw [he]⟩

end MIACE
