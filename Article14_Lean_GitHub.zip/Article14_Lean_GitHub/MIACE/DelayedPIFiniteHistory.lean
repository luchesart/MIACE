import MIACE.DelayedPIUniqueness

namespace MIACE
open Set Filter
open scoped Topology

-- @paper-step lem:delayed_cancellation/extension_of_every_continuous_finite_history
theorem delayedPI_finite_history_exists {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    {φ ψ : ℝ → ℝ} (hφ : ContinuousOn φ (Icc (-δ) 0))
    (hψ : ContinuousOn ψ (Icc (-δ) 0)) :
    ∃ y z : ℝ → ℝ, DelayedPIEvolution x δ y z ∧
      EqOn y φ (Icc (-δ) 0) ∧ EqOn z ψ (Icc (-δ) 0) := by
  let c := fun t : ℝ => min 0 (max (-δ) t)
  have hc : Continuous c := by dsimp [c]; fun_prop
  have hcI (t : ℝ) : c t∈Icc (-δ) 0 :=
    ⟨le_min (by linarith) (le_max_left _ _),min_le_left _ _⟩
  have hφc : Continuous (fun t => φ (c t)) := hφ.comp_continuous hc hcI
  have hψc : Continuous (fun t => ψ (c t)) := hψ.comp_continuous hc hcI
  obtain ⟨y,z,he,hy,hz⟩ := delayedPI_history_exists hx hδ hφc hψc
  refine ⟨y,z,he,?_,?_⟩
  · intro t ht; rw [hy t ht.2]; simp [c,max_eq_right ht.1,min_eq_right ht.2]
  · intro t ht; rw [hz t ht.2]; simp [c,max_eq_right ht.1,min_eq_right ht.2]

-- @paper-step lem:delayed_cancellation/past_before_history_window_does_not_affect_dynamics
theorem delayedPI_clamp_history {x δ : ℝ} (hδ : 0≤δ) {y z : ℝ → ℝ}
    (he : DelayedPIEvolution x δ y z) :
    DelayedPIEvolution x δ (fun t => y (max (-δ) t)) (fun t => z (max (-δ) t)) := by
  have hmax : Continuous (fun t : ℝ => max (-δ) t) := continuous_const.max continuous_id
  have heq (f : ℝ → ℝ) {t : ℝ} (ht : 0<t) :
      (fun s => f (max (-δ) s))=ᶠ[𝓝 t] f := by
    filter_upwards [Ioi_mem_nhds ht] with s hs
    change 0<s at hs
    rw [max_eq_right (by linarith : -δ≤s)]
  refine ⟨he.output_continuous.comp hmax,he.integrator_continuous.comp hmax,?_,?_⟩
  · intro t ht
    have hd := (he.output_ode t ht).congr_of_eventuallyEq (heq y ht)
    simpa only [max_eq_right (by linarith : -δ≤t),max_eq_right (by linarith : -δ≤t-δ)] using hd
  · intro t ht
    have hd := (he.integrator_ode t ht).congr_of_eventuallyEq (heq z ht)
    simpa only [max_eq_right (by linarith : -δ≤t)] using hd

-- @paper-step lem:delayed_cancellation/uniqueness_depends_only_on_finite_physical_history
theorem delayedPI_finite_history_unique {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    {y z Y Z : ℝ → ℝ} (he : DelayedPIEvolution x δ y z)
    (hE : DelayedPIEvolution x δ Y Z)
    (hy : EqOn y Y (Icc (-δ) 0)) (hz : EqOn z Z (Icc (-δ) 0)) :
    EqOn y Y (Ici 0) ∧ EqOn z Z (Ici 0) := by
  have hp (t : ℝ) (ht : t≤0) : max (-δ) t∈Icc (-δ) 0 :=
    ⟨le_max_left _ _,max_le (by linarith) ht⟩
  obtain ⟨hey,hez⟩ := delayedPI_history_unique hx hδ (delayedPI_clamp_history hδ he)
    (delayedPI_clamp_history hδ hE) (fun t ht => hy (hp t ht)) (fun t ht => hz (hp t ht))
  constructor
  · intro t ht
    change 0≤t at ht
    simpa only [max_eq_right (by linarith : -δ≤t)] using congrFun hey t
  · intro t ht
    change 0≤t at ht
    simpa only [max_eq_right (by linarith : -δ≤t)] using congrFun hez t

end MIACE
