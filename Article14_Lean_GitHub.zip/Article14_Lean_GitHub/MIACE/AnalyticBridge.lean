import MIACE.PIState
import MIACE.PIEnergy
import MIACE.Transfer

/-! Поправка: L¹-интегрируемостта и преобразуванията на Лаплас вече
се извеждат от самото ОДУ. Те не са допълнителни предпоставки. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step lem:h2/local_ac_continuity
theorem local_ac_continuous {f : ℝ → ℝ}
    (h : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval f 0 T) :
    ContinuousOn f (Ioi 0) := by
  intro t ht
  have hT : 0 ≤ t+1 := by linarith [show 0 < t from ht]
  have hc : ContinuousOn f (Icc 0 (t+1)) := by
    simpa [uIcc_of_le hT] using (h (t+1) hT).continuousOn
  exact (hc.continuousAt (Icc_mem_nhds ht (by linarith))).continuousWithinAt

-- @paper-step lem:h2/exponential_square_to_l1
theorem integrable_of_square_exponential {f : ℝ → ℝ} {K k : ℝ}
    (hc : ContinuousOn f (Ioi 0)) (hK : 0 ≤ K) (hk : 0 < k)
    (hb : ∀ t : ℝ, 0 ≤ t → (f t)^2 ≤ K*Real.exp (-(2*k)*t)) :
    Integrable f halfLine := by
  have hg : Integrable (fun t : ℝ => Real.sqrt K*Real.exp (-k*t)) halfLine :=
    (integrableOn_exp_mul_Ioi (by linarith : -k < 0) 0).const_mul _
  apply hg.mono' (hc.aestronglyMeasurable measurableSet_Ioi)
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  have h := hb t (le_of_lt ht)
  have hs : (Real.sqrt K*Real.exp (-k*t))^2 = K*Real.exp (-(2*k)*t) := by
    rw [mul_pow,Real.sq_sqrt hK,pow_two,← Real.exp_add]
    congr 2
    ring
  rw [Real.norm_eq_abs]
  have hn : 0 ≤ Real.sqrt K*Real.exp (-k*t) := by positivity
  nlinarith [sq_abs (f t),abs_nonneg (f t)]

-- @paper-step lem:h2/canonical_l1_integrability
theorem canonical_integrable {a b c : ℝ} {z w : ℝ → ℝ}
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (hzac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval z 0 T)
    (hwac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval w 0 T)
    (hzode : ∀ᵐ t : ℝ, 0 < t → deriv z t = w t)
    (hwode : ∀ᵐ t : ℝ, 0 < t → deriv w t = -(c/a)*z t-(b/a)*w t) :
    Integrable z halfLine ∧ Integrable w halfLine := by
  let K := (2*b/a)*stabilityV a b c (z 0) (w 0)
  let k := 1/(2*stabilityC a b c)
  have hC : 0 < stabilityC a b c := by unfold stabilityC; positivity
  have hk : 0 < k := by dsimp [k]; positivity
  have hV : 0 ≤ stabilityV a b c (z 0) (w 0) := by
    exact le_trans (by positivity) (stability_bounds a b c (z 0) (w 0) ha hb hc).1
  have hK : 0 ≤ K := mul_nonneg (by positivity) hV
  have hrate : 2*k = 1/stabilityC a b c := by dsimp [k]; ring
  have hbound : ∀ t : ℝ, 0 ≤ t → (z t)^2+(w t)^2 ≤ K*Real.exp (-(2*k)*t) := by
    intro t ht
    rw [hrate]
    exact canonical_exponential_bound ha hb hc hzac hwac hzode hwode t ht
  constructor
  · apply integrable_of_square_exponential (local_ac_continuous hzac) hK hk
    intro t ht
    nlinarith [hbound t ht,sq_nonneg (w t)]
  · apply integrable_of_square_exponential (local_ac_continuous hwac) hK hk
    intro t ht
    nlinarith [hbound t ht,sq_nonneg (z t)]

-- @paper-step lem:h2/laplace_ode_identity
theorem laplace_ode_identity {f g : ℝ → ℝ}
    (hac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval f 0 T)
    (hode : ∀ᵐ t : ℝ, 0 < t → deriv f t = g t)
    (hf : Integrable f halfLine) (hg : Integrable g halfLine)
    (hlim : Tendsto f atTop (𝓝 0)) (p : ℝ) (hp : 0 ≤ p) :
    laplace g p = p*laplace f p-f 0 := by
  have hfinite : ∀ T : ℝ, 0 ≤ T →
      (∫ t in 0..T, Real.exp (-p*t)*(g t-p*f t)) = Real.exp (-p*T)*f T-f 0 := by
    intro T hT
    have he : AbsolutelyContinuousOnInterval (fun t : ℝ => Real.exp (-p*t)) 0 T := by
      apply ContDiffOn.absolutelyContinuousOnInterval
      fun_prop
    have hi := (he.mul (hac T hT)).integral_deriv_eq_sub
    have heq : (∫ t in 0..T, deriv (fun s => Real.exp (-p*s)*f s) t) =
        ∫ t in 0..T, Real.exp (-p*t)*(g t-p*f t) := by
      apply intervalIntegral.integral_congr_ae
      filter_upwards [(hac T hT).ae_differentiableAt,hode] with t hd ho ht
      have hdf := (hd (uIoc_subset_uIcc ht)).hasDerivAt
      rw [uIoc_of_le hT] at ht
      rw [ho ht.1] at hdf
      have hd := (((hasDerivAt_id t).const_mul (-p)).exp).mul hdf
      change HasDerivAt (fun s => Real.exp (-p*s)*f s) _ t at hd
      rw [hd.deriv]
      simp only [id_eq]
      ring
    change (∫ t in 0..T, deriv (fun s => Real.exp (-p*s)*f s) t) =
      Real.exp (-p*T)*f T-Real.exp (-p*0)*f 0 at hi
    rw [heq] at hi
    simpa using hi
  have hi : Integrable (fun t => Real.exp (-p*t)*(g t-p*f t)) halfLine :=
    laplace_integrable (hg.sub (hf.const_mul p)) hp
  have hzero : Tendsto (fun t => Real.exp (-p*t)*f t) atTop (𝓝 0) := by
    apply tendsto_zero_iff_norm_tendsto_zero.mpr
    apply squeeze_zero' (Eventually.of_forall (fun t => norm_nonneg _)) _
      (tendsto_zero_iff_norm_tendsto_zero.mp hlim)
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with t ht
    exact laplace_kernel_bound p t (f t) hp ht
  have hl := intervalIntegral_tendsto_integral_Ioi 0 hi tendsto_id
  have hr : Tendsto (fun T : ℝ => ∫ t in 0..T, Real.exp (-p*t)*(g t-p*f t))
      atTop (𝓝 (-f 0)) := by
    have hh : Tendsto (fun T => Real.exp (-p*T)*f T-f 0) atTop (𝓝 (-f 0)) := by
      simpa using hzero.sub_const (f 0)
    apply hh.congr'
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with T hT
    exact (hfinite T hT).symm
  have h := tendsto_nhds_unique hl hr
  have heq : (fun t => Real.exp (-p*t)*(g t-p*f t)) =
      (fun t => Real.exp (-p*t)*g t-p*(Real.exp (-p*t)*f t)) := by funext t; ring
  rw [heq,integral_sub (laplace_integrable hg hp) ((laplace_integrable hf hp).const_mul p),
    integral_const_mul] at h
  change laplace g p-p*laplace f p = -f 0 at h
  linarith

-- @paper-step thm:miace/direct_pi_l1_admissibility
theorem pi_state_integrable {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r) :
    Integrable e halfLine ∧ Integrable i halfLine := by
  have ho := pi_state_canonical_ode h hx hr
  have hh := canonical_integrable hr (by positivity : 0 < r*(1+x)) hx
    (fun T hT => (h.ac_i T hT).const_mul (-(r/x)))
    (fun T hT => (h.ac_e T hT).neg) ho.1 ho.2
  constructor
  · simpa using hh.2.neg
  · have hh := hh.1.const_mul (-(x/r))
    have hid : (fun t => -(x/r)*(-(r/x)*i t)) = i := by funext t; field_simp
    rwa [hid] at hh

-- @paper-step thm:miace/direct_first_order_bridge
theorem pi_state_response {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r) :
    FirstOrderResponse e (fun t => x*e t+i t) := by
  have hi := pi_state_integrable h hx hr
  refine ⟨h.ac_e,?_,h.initial_e,(pi_state_settles h hx hr).1,hi.1,(hi.1.const_mul x).add hi.2⟩
  filter_upwards [h.ode_e] with t ht hpos
  rw [ht hpos]
  ring

-- @paper-step thm:miace/direct_signed_areas
theorem pi_state_signed_areas {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r) :
    (∫ t, e t ∂halfLine) = r/x ∧ (∫ t, (x*e t+i t) ∂halfLine) = 1-r/x := by
  have hi := pi_state_integrable h hx hr
  have hl := laplace_ode_identity h.ac_i h.ode_i hi.2 (hi.1.const_mul (x/r))
    (pi_state_settles h hx hr).2 0 le_rfl
  simp only [laplace,neg_zero,zero_mul,Real.exp_zero,one_mul,h.initial_i,neg_neg,
    sub_neg_eq_add,zero_add,integral_const_mul] at hl
  have he : (∫ t, e t ∂halfLine) = r/x := by
    apply (eq_div_iff (ne_of_gt hx)).2
    rw [div_mul_eq_mul_div,div_eq_iff (ne_of_gt hr)] at hl
    nlinarith
  refine ⟨he,?_⟩
  have hb := response_signed_balance (pi_state_response h hx hr)
  rw [he] at hb
  linarith
end MIACE
