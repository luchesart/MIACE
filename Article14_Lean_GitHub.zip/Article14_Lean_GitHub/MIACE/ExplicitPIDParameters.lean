import MIACE.DelayedPICompletion
import MIACE.HistoryStability

/-! Stage 19. The explicit family uses a one-exponential forcing and a
noncompact kernel. These inequalities are derived from the paper's interval. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

structure ExplicitPIDData (i ρ ell l δ : ℝ) : Prop where
  gain_pos : 0 < i
  gain_lt_one : i < 1
  filter_eq : ρ=1-i
  lead_eq : ell=ρ/i
  rate_pos : 0<l
  delay_pos : 0<δ
  rate_delay : l*δ=1
  kernel_jump : 1≤l*Real.exp (-1)
  command_tail : l*Real.exp 1*(1-i)≤ i*(Real.exp 1-1)

noncomputable def explicitA (ρ ell l : ℝ) : ℝ := (1-l*ell)/(1-l*ρ)
noncomputable def explicitB (ρ ell l : ℝ) : ℝ := (ell-ρ)/(ρ*(1-l*ρ))

-- @paper-step thm:pid_explicit_family/interval_implies_all_explicit_parameter_conditions
theorem explicitPID_data {α δ : ℝ} (hα : Real.exp 1<α)
    (hδ : 1/α<δ) (hδ1 : δ≤1/Real.exp 1)
    (hδ2 : δ≤Real.exp 1/(α+1-Real.exp 1)) :
    ExplicitPIDData (delayedPIGain α δ) (1-delayedPIGain α δ)
      ((1-delayedPIGain α δ)/delayedPIGain α δ) (1/δ) δ := by
  have he := Real.exp_pos (1 : ℝ)
  have ha : 0<α := lt_trans he hα
  have hd : 0<δ := lt_trans (one_div_pos.mpr ha) hδ
  have hd1 : 0<1+δ := by linarith
  have hg : delayedPIGain α δ=(α+1)/(α*(1+δ)) := by unfold delayedPIGain; field_simp
  have hi := delayedPIGain_pos ha hd.le
  have hi1 : delayedPIGain α δ<1 := by
    rw [delayedPIGain,div_lt_iff₀ hd1]; linarith
  refine ⟨hi,hi1,rfl,rfl,one_div_pos.mpr hd,hd,by field_simp,?_,?_⟩
  · rw [Real.exp_neg,← one_div,div_mul_eq_mul_div]
    apply (le_div_iff₀ hd).mpr
    simpa using hδ1
  · have hden : 0<α+1-Real.exp 1 := by linarith
    have hh := (le_div_iff₀ hden).mp hδ2
    rw [hg]
    field_simp
    nlinarith

-- @paper-step thm:pid_explicit_family/strict_filter_and_lead_order
theorem explicitPID_order {i ρ ell l δ : ℝ} (h : ExplicitPIDData i ρ ell l δ) :
    0<ρ ∧ ρ<ell ∧ ell<1/l ∧ ρ<1 ∧ 0<1-l*ρ := by
  have hi := h.gain_pos
  have hi1 := h.gain_lt_one
  have hl := h.rate_pos
  have he := Real.exp_pos (1 : ℝ)
  have hr : 0<ρ := by rw [h.filter_eq]; linarith
  have hr1 : ρ<1 := by rw [h.filter_eq]; linarith
  have hrl : ρ<ell := by rw [h.lead_eq,lt_div_iff₀ hi]; nlinarith
  have hle : l*ρ< i := by
    have hh := h.command_tail
    rw [← h.filter_eq] at hh
    nlinarith
  have hell : ell<1/l := by
    rw [h.lead_eq,div_lt_div_iff₀ hi hl]
    nlinarith
  have hlr : 0<1-l*ρ := by nlinarith
  exact ⟨hr,hrl,hell,hr1,hlr⟩

-- @paper-step thm:pid_explicit_family/positive_partial_fraction_coefficients
theorem explicitPID_coefficients {i ρ ell l δ : ℝ} (h : ExplicitPIDData i ρ ell l δ) :
    0<explicitA ρ ell l ∧ 0<explicitB ρ ell l ∧
      explicitA ρ ell l+explicitB ρ ell l=ell/ρ ∧
      explicitA ρ ell l/l+explicitB ρ ell l*ρ=1/l := by
  obtain ⟨hr,hrl,hell,_,hden⟩ := explicitPID_order h
  have hl := h.rate_pos
  have he : l*ell<1 := by have hh := (lt_div_iff₀ hl).mp hell; nlinarith
  refine ⟨div_pos (by linarith) hden,div_pos (sub_pos.mpr hrl) (mul_pos hr hden),?_,?_⟩
  · unfold explicitA explicitB
    field_simp
    <;> ring
  · unfold explicitA explicitB
    field_simp
    <;> ring

-- @paper-step thm:pid_explicit_family/positive_physical_controller_coefficients
theorem explicitPID_controller_coefficients {i ρ ell l δ : ℝ} (h : ExplicitPIDData i ρ ell l δ) :
    0< i+ρ^2 ∧ 0< i*ρ^2 ∧
      i+ρ^2=i*(1+ell-ρ) ∧ i*ρ^2=i*(ell-ρ)*(1-ρ) ∧ i*(ell/ρ)=1 := by
  obtain ⟨hr,_,_,_,_⟩ := explicitPID_order h
  have hi := h.gain_pos
  have hilell : i*ell=ρ := by rw [h.lead_eq]; field_simp
  have hiρ : i+ρ=1 := by rw [h.filter_eq]; ring
  refine ⟨by positivity,by positivity,by nlinarith,?_,?_⟩
  · nlinarith [sq_nonneg ρ]
  · rw [← mul_div_assoc,hilell]; exact div_self (ne_of_gt hr)

end MIACE
