import MIACE.ConvolutionL1
import Mathlib.MeasureTheory.Integral.DominatedConvergence

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution
noncomputable def expWeight (η : ℝ) (f : ℝ → ℝ) (t : ℝ) : ℝ := Real.exp (η*t)*f t

-- @paper-step lem:pid_positive_resolvent/weight_majorant
theorem expWeight_majorant (f : ℝ → ℝ) {η β : ℝ} (hη : 0 ≤ η) (hβ : η ≤ β)
    (t : ℝ) : ‖expWeight η f t‖ ≤ |f t|+|expWeight β f t| := by
  simp only [expWeight,Real.norm_eq_abs,abs_mul,abs_of_pos (Real.exp_pos _)]
  by_cases ht : 0 ≤ t
  · have he := Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_right hβ ht)
    have := mul_le_mul_of_nonneg_right he (abs_nonneg (f t))
    linarith [abs_nonneg (f t)]
  · have he := Real.exp_le_one_iff.mpr (mul_nonpos_of_nonneg_of_nonpos hη (le_of_not_ge ht))
    have := mul_le_mul_of_nonneg_right he (abs_nonneg (f t))
    nlinarith [Real.exp_pos (β*t),abs_nonneg (f t)]

-- @paper-step lem:pid_positive_resolvent/smaller_weight_integrable
theorem expWeight_integrable {f : ℝ → ℝ} (hf : Integrable f) {η β : ℝ}
    (hβ : Integrable (expWeight β f)) (hη : 0 ≤ η) (hle : η ≤ β) :
    Integrable (expWeight η f) := by
  apply (hf.abs.add hβ.abs).mono'
  · exact (by fun_prop : Continuous (fun t : ℝ => Real.exp (η*t))).aestronglyMeasurable.mul
      hf.aestronglyMeasurable
  · exact ae_of_all volume (expWeight_majorant f hη hle)

-- @paper-step lem:pid_positive_resolvent/exponential_moment_continuity
theorem expWeight_integral_limit {f : ℝ → ℝ} (hf : Integrable f) {β : ℝ} (hβ : 0 < β)
    (hw : Integrable (expWeight β f)) :
    Tendsto (fun n : ℕ => ∫ t, expWeight (β/(n+1)) f t) atTop (𝓝 (∫ t, f t)) := by
  have hη : Tendsto (fun n : ℕ => β/(n+1)) atTop (𝓝 (0 : ℝ)) := by
    simpa only [mul_zero,div_eq_mul_inv,one_mul] using
      (tendsto_one_div_add_atTop_nhds_zero_nat (𝕜 := ℝ)).const_mul β
  apply tendsto_integral_of_dominated_convergence (fun t => |f t|+|expWeight β f t|)
  · intro n
    exact (by fun_prop : Continuous (fun t : ℝ => Real.exp (β/(n+1)*t))).aestronglyMeasurable.mul
      hf.aestronglyMeasurable
  · exact hf.abs.add hw.abs
  · intro n
    apply ae_of_all
    intro t
    apply expWeight_majorant f (by positivity)
    exact div_le_self hβ.le (by linarith [Nat.cast_nonneg (α := ℝ) n])
  · apply ae_of_all
    intro t
    simpa [expWeight] using (Real.continuous_exp.continuousAt.tendsto.comp (hη.mul_const t)).mul_const (f t)

-- @paper-step lem:pid_positive_resolvent/strict_small_weight
theorem expWeight_small_mass {K : ℝ → ℝ} (hK : Integrable K)
    (hq : (∫ t, K t) < 1) {β : ℝ} (hβ : 0 < β)
    (hw : Integrable (expWeight β K)) :
    ∃ η : ℝ, 0 < η ∧ η ≤ β ∧ Integrable (expWeight η K) ∧
      (∫ t, expWeight η K t) < 1 := by
  have hh := (expWeight_integral_limit hK hβ hw).eventually (gt_mem_nhds hq)
  obtain ⟨n,hn⟩ := hh.exists
  have hη : 0 < β/(n+1 : ℝ) := by positivity
  have hle : β/(n+1 : ℝ) ≤ β := div_le_self hβ.le (by linarith [Nat.cast_nonneg (α := ℝ) n])
  exact ⟨β/(n+1),hη,hle,expWeight_integrable hK hw hη.le hle,hn⟩

-- @paper-step lem:pid_positive_resolvent/weight_convolution
theorem expWeight_convolution (η : ℝ) (f g : ℝ → ℝ) :
    expWeight η (f ⋆ g) = (expWeight η f) ⋆ (expWeight η g) := by
  funext t
  unfold expWeight convolution
  simp only [ContinuousLinearMap.lsmul_apply,smul_eq_mul]
  rw [← integral_const_mul]
  congr 1
  funext s
  have he : Real.exp (η*s)*Real.exp (η*(t-s)) = Real.exp (η*t) := by
    rw [← Real.exp_add]
    congr 1
    ring
  calc
    _ = (Real.exp (η*s)*Real.exp (η*(t-s)))*(f s*g (t-s)) := by rw [he]
    _ = _ := by ring

-- @paper-step lem:pid_positive_resolvent/weight_inversion
theorem expWeight_inverse (η : ℝ) (f : ℝ → ℝ) :
    expWeight (-η) (expWeight η f) = f := by
  funext t
  simp only [expWeight,← mul_assoc,← Real.exp_add]
  rw [show -η*t+η*t=0 by ring,Real.exp_zero,one_mul]

end MIACE
