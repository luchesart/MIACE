import MIACE.TwoRateOptimal

/-! Реални Лапласови интеграли на конкретното ядро (p≥0).
    Комплексната спектрална и вътрешна устойчивост не се подменя с това твърдение. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:pid_two_rate_optimum/weighted_two_rate_identity
theorem expWeight_twoRateG (η A l m : ℝ) :
    expWeight η (causalize (twoRateG A l m))=causalize (twoRateG A (l-η) (m-η)) := by
  rw [expWeight_causalize]
  congr 1
  funext t
  change Real.exp (η*t)*(A*Real.exp (-l*t)+(1-A)*Real.exp (-m*t))=_
  have hl : Real.exp (η*t)*Real.exp (-l*t)=Real.exp (-(l-η)*t) := by
    rw [← Real.exp_add]; congr 1; ring
  have hm : Real.exp (η*t)*Real.exp (-m*t)=Real.exp (-(m-η)*t) := by
    rw [← Real.exp_add]; congr 1; ring
  unfold twoRateG
  calc
    _ = A*(Real.exp (η*t)*Real.exp (-l*t))+(1-A)*(Real.exp (η*t)*Real.exp (-m*t)) := by ring
    _ = _ := by rw [hl,hm]

-- @paper-step thm:pid_two_rate_optimum/actual_forcing_laplace
theorem twoRateG_laplace (A : ℝ) {l m p : ℝ} (hl : 0 < l) (hm : 0 < m) (hp : 0 ≤ p) :
    laplace (causalize (twoRateG A l m)) p=A/(p+l)+(1-A)/(p+m) := by
  rw [← kernel_laplace_full (causalize_causal _) p,expWeight_twoRateG,
    twoRateG_integral A (by linarith : 0<l-(-p)) (by linarith : 0<m-(-p))]
  congr 2 <;> ring

-- @paper-step thm:pid_two_rate_optimum/actual_rational_forcing_transform
theorem twoRateG_rational_laplace {ρ l m p : ℝ} (hρ : 0 < ρ) (hl : 0 < l)
    (hm : 0 < m) (hlm : l < m) (hp : 0 ≤ p) :
    laplace (causalize (twoRateG (twoRateA ρ l m) l m)) p=
      (1+ρ*p)/(ρ*(p+l)*(p+m)) := by
  rw [twoRateG_laplace _ hl hm hp]
  exact twoRate_partial_fraction (ne_of_gt hρ) (ne_of_lt hlm)
    (ne_of_gt (by positivity)) (ne_of_gt (by positivity))

-- @paper-step thm:pid_two_rate_optimum/actual_compact_kernel_transform
theorem twoRateK_laplace (A : ℝ) {l m p δ : ℝ} (hl : 0 < l) (hm : 0 < m)
    (hp : 0 ≤ p) (hδ : 0 ≤ δ) :
    laplace (twoRateK A l m δ) p=
      l*A*(1-Real.exp (-(p+l)*δ))/(p+l)+
      m*(1-A)*(1-Real.exp (-(p+m)*δ))/(p+m) := by
  have he : expWeight (-p) (twoRateK A l m δ)=
      (Ico 0 δ).indicator (fun t => l*A*Real.exp (-(p+l)*t)+m*(1-A)*Real.exp (-(p+m)*t)) := by
    funext t
    by_cases ht : t ∈ Ico (0 : ℝ) δ
    · simp only [expWeight,twoRateK,indicator_of_mem ht,twoRateD]
      have he₁ : Real.exp (-p*t)*Real.exp (-l*t)=Real.exp (-(p+l)*t) := by
        rw [← Real.exp_add]; congr 1; ring
      have he₂ : Real.exp (-p*t)*Real.exp (-m*t)=Real.exp (-(p+m)*t) := by
        rw [← Real.exp_add]; congr 1; ring
      calc
        _ = l*A*(Real.exp (-p*t)*Real.exp (-l*t))+m*(1-A)*(Real.exp (-p*t)*Real.exp (-m*t)) := by ring
        _ = _ := by rw [he₁,he₂]
    · simp [expWeight,twoRateK,ht]
  rw [← kernel_laplace_full (twoRateK_causal A l m δ) p,he,
    integral_indicator measurableSet_Ico,integral_Ico_eq_integral_Ioc,
    ← intervalIntegral.integral_of_le hδ]
  rw [intervalIntegral.integral_add
    ((by fun_prop : Continuous (fun t : ℝ => l*A*Real.exp (-(p+l)*t))).intervalIntegrable 0 δ)
    ((by fun_prop : Continuous (fun t : ℝ => m*(1-A)*Real.exp (-(p+m)*t))).intervalIntegrable 0 δ),
    intervalIntegral.integral_const_mul,intervalIntegral.integral_const_mul,
    finite_exp_integral (ne_of_gt (by positivity : 0<p+l)),
    finite_exp_integral (ne_of_gt (by positivity : 0<p+m))]
  ring

-- @paper-step thm:pid_two_rate_optimum/shifted_controller_partial_fractions
theorem twoRate_shifted_fraction {i ρ ell l m δ p : ℝ} (hρ : ρ ≠ 0)
    (hlm : l ≠ m) (hl : p+l ≠ 0) (hm : p+m ≠ 0)
    (hrootl : i*(1-ell*l)=l*(1-ρ*l)*Real.exp (-l*δ))
    (hrootm : i*(1-ell*m)=m*(1-ρ*m)*Real.exp (-m*δ)) :
    l*twoRateA ρ l m*Real.exp (-l*δ)/(p+l)+
      m*(1-twoRateA ρ l m)*Real.exp (-m*δ)/(p+m)=
        i*(1+ell*p)/(ρ*(p+l)*(p+m)) := by
  rw [twoRate_first_residue hρ hlm hrootl,twoRate_second_residue hρ hlm hrootm]
  have hml : m-l ≠ 0 := sub_ne_zero.mpr hlm.symm
  field_simp
  <;> ring

-- @paper-step thm:pid_two_rate_optimum/compact_kernel_transform_factorization
theorem twoRate_characteristic_factor {i ρ ell l m δ p : ℝ}
    (h : TwoRateData i ρ ell l m δ) (hp : 0 ≤ p) :
    p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p)=
      ρ*(p+l)*(p+m)*(1-laplace (twoRateK (twoRateA ρ l m) l m δ) p) := by
  have hl : 0 < l := by linarith [h.lower_rate]
  have hm : 0 < m := by linarith [h.lower_rate,h.ordered_rates]
  have hlp : p+l ≠ 0 := ne_of_gt (by positivity)
  have hmp : p+m ≠ 0 := ne_of_gt (by positivity)
  let A := twoRateA ρ l m
  have hg := twoRate_partial_fraction (ne_of_gt h.filter_pos) (ne_of_lt h.ordered_rates) hlp hmp
  have hs := twoRate_shifted_fraction (ne_of_gt h.filter_pos) (ne_of_lt h.ordered_rates)
    hlp hmp h.root_l h.root_m
  have hk : 1-laplace (twoRateK A l m δ) p =
      p*(A/(p+l)+(1-A)/(p+m))+Real.exp (-δ*p)*
        (l*A*Real.exp (-l*δ)/(p+l)+m*(1-A)*Real.exp (-m*δ)/(p+m)) := by
    rw [twoRateK_laplace A hl hm hp h.delay_nonneg]
    have hel : Real.exp (-(p+l)*δ)=Real.exp (-δ*p)*Real.exp (-l*δ) := by
      rw [← Real.exp_add]; congr 1; ring
    have hem : Real.exp (-(p+m)*δ)=Real.exp (-δ*p)*Real.exp (-m*δ) := by
      rw [← Real.exp_add]; congr 1; ring
    rw [hel,hem]
    field_simp
    <;> ring
  rw [hk,hg,hs]
  field_simp [ne_of_gt h.filter_pos]
  <;> ring

-- @paper-step thm:pid_two_rate_optimum/actual_renewal_laplace
theorem renewal_laplace {K : ℝ → ℝ} (hK : Integrable K) (hKc : Causal K)
    (g z : RealL1) (hgc : Causal g) (hzc : Causal z) (hz : z=g+convOp hK z)
    {p : ℝ} (hp : 0 ≤ p) :
    (1-laplace K p)*laplace z p=laplace g p := by
  have he : (z : ℝ → ℝ) =ᵐ[volume] (fun t => g t+(K ⋆ (z : ℝ → ℝ)) t) := by
    have hh := Lp.coeFn_add g (convOp hK z)
    rw [← hz] at hh
    filter_upwards [hh,convOp_coe hK z] with t ht hc
    simpa only [Pi.add_apply,hc] using ht
  have hw : expWeight (-p) z =ᵐ[volume]
      (fun t => expWeight (-p) g t+expWeight (-p) (K ⋆ (z : ℝ → ℝ)) t) := by
    filter_upwards [he] with t ht
    simp only [expWeight,ht,mul_add]
  have hi := integral_congr_ae hw
  rw [integral_add (expWeight_negative_integrable (L1.integrable_coeFn g) hgc hp)
    (expWeight_negative_integrable
      (hK.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) (L1.integrable_coeFn z))
      (ae_of_all volume (convolution_causal hKc hzc)) hp),
    kernel_laplace_full hzc,kernel_laplace_full hgc,
    kernel_laplace_full (ae_of_all volume (convolution_causal hKc hzc)),
    causal_convolution_laplace hK (L1.integrable_coeFn z) hKc hzc hp] at hi
  linarith

-- @paper-step thm:pid_two_rate_optimum/laplace_ae_invariance
theorem laplace_congr_ae {f g : ℝ → ℝ} (hfg : f =ᵐ[volume] g) (p : ℝ) :
    laplace f p=laplace g p := by
  apply integral_congr_ae
  have hh := hfg.filter_mono (ae_mono (Measure.restrict_le_self (s := Ioi (0 : ℝ))))
  filter_upwards [hh] with t ht
  rw [ht]

-- @paper-step thm:pid_two_rate_optimum/positive_real_characteristic
theorem pid_characteristic_positive {i ρ ell l m δ p : ℝ}
    (h : TwoRateData i ρ ell l m δ) (hp : 0 ≤ p) :
    0 < p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p) := by
  have hρ := h.filter_pos
  have hi := h.integral_pos
  have hell : 0 < ell := h.filter_pos.trans h.lead_gt_filter
  positivity

-- @paper-step thm:pid_two_rate_optimum/error_transfer_identification
theorem twoRate_error_transfer {i ρ ell l m δ : ℝ} (h : TwoRateData i ρ ell l m δ)
    (e : RealL1) (hc : Causal e)
    (he : e=(twoRateG_integrable (twoRateA ρ l m)
        (by linarith [h.lower_rate] : 0<l)
        (by linarith [h.lower_rate,h.ordered_rates] : 0<m)).toL1
          (causalize (twoRateG (twoRateA ρ l m) l m))+
      convOp (twoRateK_integrable (twoRateA ρ l m) l m δ) e)
    {p : ℝ} (hp : 0 ≤ p) :
    laplace e p=(1+ρ*p)/(p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p)) := by
  let A := twoRateA ρ l m
  have hl : 0 < l := by linarith [h.lower_rate]
  have hm : 0 < m := by linarith [h.lower_rate,h.ordered_rates]
  let hG := twoRateG_integrable A hl hm
  let G := hG.toL1 (causalize (twoRateG A l m))
  have hGc : Causal G := causal_congr (causalize_causal _) hG.coeFn_toL1.symm
  have hE := renewal_laplace (twoRateK_integrable A l m δ) (twoRateK_causal A l m δ)
    G e hGc hc he hp
  have hGhat : laplace G p=(1+ρ*p)/(ρ*(p+l)*(p+m)) := by
    rw [laplace_congr_ae hG.coeFn_toL1]
    exact twoRateG_rational_laplace h.filter_pos hl hm h.ordered_rates hp
  rw [hGhat] at hE
  apply (eq_div_iff (ne_of_gt (pid_characteristic_positive h hp))).mpr
  have hd : ρ*(p+l)*(p+m) ≠ 0 := ne_of_gt (by have hρ := h.filter_pos; positivity)
  have hprod := congrArg (fun z : ℝ => (ρ*(p+l)*(p+m))*z) hE
  rw [mul_div_cancel₀ _ hd] at hprod
  have hfac := twoRate_characteristic_factor h hp
  calc
    _ = (ρ*(p+l)*(p+m))*((1-laplace (twoRateK A l m δ) p)*laplace e p) := by
      rw [hfac]; ring
    _ = _ := hprod

end MIACE
