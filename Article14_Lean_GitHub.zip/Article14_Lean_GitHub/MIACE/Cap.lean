import MIACE.Algebra
import Mathlib.Analysis.SpecialFunctions.Log.Basic

namespace MIACE

-- @paper-step thm:complete_cap/moment_to_capacity
 theorem pulse_moment_criterion (c U : ℝ) (hc : 0 < c) :
    c * (Real.exp (U/c) - 1) ≤ 1 ↔ U ≤ c * Real.log (1 + 1/c) := by
  have hy : 0 < 1 + 1/c := by positivity
  have h1 : c * (Real.exp (U/c)-1) ≤ 1 ↔ Real.exp (U/c) ≤ 1+1/c := by
    constructor
    · intro h
      have hdiv : Real.exp (U/c) - 1 ≤ 1/c := (le_div_iff₀ hc).2 (by nlinarith)
      linarith
    · intro h
      have hdiv : Real.exp (U/c) - 1 ≤ 1/c := by linarith
      have hm := (le_div_iff₀ hc).1 hdiv
      nlinarith
  rw [h1, ← Real.le_log_iff_exp_le hy]
  constructor
  · intro h
    have h' := (div_le_iff₀ hc).1 h
    simpa [mul_comm] using h'
  · intro h
    apply (div_le_iff₀ hc).2
    simpa [mul_comm] using h

-- @paper-step thm:complete_cap/capacity_positive
 theorem capacity_positive (c : ℝ) (hc : 0 < c) :
    0 < c * Real.log (1 + 1/c) := by
  apply mul_pos hc
  apply Real.log_pos
  have : 0 < 1/c := by positivity
  linarith

-- @paper-step thm:complete_cap/capacity_strict_bound
 theorem capacity_lt_one (c : ℝ) (hc : 0 < c) :
    c * Real.log (1 + 1/c) < 1 := by
  have hy : 0 < 1 + 1/c := by positivity
  have hn : 1 + 1/c ≠ 1 := by
    have : 0 < 1/c := by positivity
    linarith
  have hlog := Real.log_lt_sub_one_of_pos hy hn
  have h := mul_lt_mul_of_pos_left hlog hc
  have hc0 := ne_of_gt hc
  field_simp at h ⊢
  nlinarith

-- @paper-step thm:command_cone/first_lag_bounds
 theorem first_lag_bounds (t J : ℝ) (ht : 0 ≤ t) (hJ0 : 0 ≤ J) (hJ1 : J ≤ 1) :
    0 ≤ 1 - Real.exp (-t) + Real.exp (-t) * J ∧
      1 - Real.exp (-t) + Real.exp (-t) * J ≤ 1 := by
  have hp := Real.exp_pos (-t)
  have hu : Real.exp (-t) ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
  constructor <;> nlinarith

-- @paper-step thm:command_cone/first_lag_derivative_sign
 theorem first_lag_derivative_nonneg (v x : ℝ) (hv : 0 ≤ v) (hx : x ≤ 1) :
    0 ≤ 1 + v - x := by linarith

end MIACE
