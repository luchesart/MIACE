import MIACE.WindowConvolution

/-! Етап 9: непрекъснати представители на двата конкретни L¹ реда.
    Стойностите на представителите се определят от действителната конволюция. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

noncomputable def twoRateErrorRep (A l m δ : ℝ) (e : ℝ → ℝ) (t : ℝ) : ℝ :=
  twoRateG A l m t+(twoRateK A l m δ ⋆ e) t
noncomputable def twoRateCommandRep (A l m δ : ℝ) (v : ℝ → ℝ) (t : ℝ) : ℝ :=
  twoRateR A l m δ t+(twoRateK A l m δ ⋆ v) t

-- @paper-step thm:pid_two_rate_optimum/kernel_convolution_split
theorem twoRateK_convolution_split {f : ℝ → ℝ} (hf : Integrable f) (A l m δ t : ℝ) :
    (twoRateK A l m δ ⋆ f) t=
      l*A*(cutExp l δ ⋆ f) t+m*(1-A)*(cutExp m δ ⋆ f) t := by
  have he : (fun s => twoRateK A l m δ s*f (t-s))=
      (fun s => (l*A)*(cutExp l δ s*f (t-s))+(m*(1-A))*(cutExp m δ s*f (t-s))) := by
    funext s
    by_cases hs : s∈Ico (0 : ℝ) δ <;> simp [twoRateK,twoRateD,cutExp,hs] <;> ring
  change (∫ s, twoRateK A l m δ s*f (t-s))=_
  rw [he,integral_add ((cutExp_convolution_integrable hf l δ t).const_mul _)
    ((cutExp_convolution_integrable hf m δ t).const_mul _),integral_const_mul,integral_const_mul]
  rfl

-- @paper-step thm:pid_two_rate_optimum/kernel_convolution_continuity
theorem twoRateK_convolution_continuous {f : ℝ → ℝ} (hf : Integrable f)
    (A l m : ℝ) {δ : ℝ} (hδ : 0 ≤ δ) : Continuous (twoRateK A l m δ ⋆ f) := by
  have he : twoRateK A l m δ ⋆ f=(fun t => l*A*(cutExp l δ ⋆ f) t+m*(1-A)*(cutExp m δ ⋆ f) t) :=
    funext (twoRateK_convolution_split hf A l m δ)
  rw [he]
  exact ((cutExp_convolution_continuous hf l hδ).const_mul _).add
    ((cutExp_convolution_continuous hf m hδ).const_mul _)

-- @paper-step thm:pid_two_rate_optimum/kernel_convolution_absolute_continuity
theorem twoRateK_convolution_ac {f : ℝ → ℝ} (hf : Integrable f)
    (A l m : ℝ) {δ : ℝ} (hδ : 0 ≤ δ) (a b : ℝ) :
    AbsolutelyContinuousOnInterval (twoRateK A l m δ ⋆ f) a b := by
  have hh := ((cutExp_convolution_ac hf l hδ a b).const_mul (l*A)).add
    ((cutExp_convolution_ac hf m hδ a b).const_mul (m*(1-A)))
  exact hh.congr (fun t _ => (twoRateK_convolution_split hf A l m δ t).symm)

-- @paper-step thm:pid_two_rate_optimum/ordinary_error_regularity
theorem twoRateErrorRep_regularity {f : ℝ → ℝ} (hf : Integrable f)
    (A l m : ℝ) {δ : ℝ} (hδ : 0 ≤ δ) :
    Continuous (twoRateErrorRep A l m δ f) ∧
      ∀ a b : ℝ, AbsolutelyContinuousOnInterval (twoRateErrorRep A l m δ f) a b := by
  constructor
  · exact (twoRate_continuous A l m).1.add (twoRateK_convolution_continuous hf A l m hδ)
  · intro a b
    have hg : AbsolutelyContinuousOnInterval (twoRateG A l m) a b := by
      apply ContDiffOn.absolutelyContinuousOnInterval
      change ContDiffOn ℝ 1 (fun t => A*Real.exp (-l*t)+(1-A)*Real.exp (-m*t)) _
      fun_prop
    exact hg.add (twoRateK_convolution_ac hf A l m hδ a b)

-- @paper-step thm:pid_two_rate_optimum/ordinary_command_continuity
theorem twoRateCommandRep_continuous {f : ℝ → ℝ} (hf : Integrable f)
    (A l m : ℝ) {δ : ℝ} (hδ : 0 ≤ δ) : Continuous (twoRateCommandRep A l m δ f) := by
  have hr : Continuous (twoRateR A l m δ) := by
    change Continuous (fun t => twoRateD A l m (t+δ)-twoRateG A l m (t+δ)+
      twoRateG A l m (max δ t)-twoRateG A l m t)
    exact ((((twoRate_continuous A l m).2.comp (continuous_id.add continuous_const)).sub
      ((twoRate_continuous A l m).1.comp (continuous_id.add continuous_const))).add
      ((twoRate_continuous A l m).1.comp (continuous_const.max continuous_id))).sub
      (twoRate_continuous A l m).1
  exact hr.add (twoRateK_convolution_continuous hf A l m hδ)

-- @paper-step thm:pid_two_rate_optimum/renewal_representative_identification
theorem renewal_representative_ae {K f : ℝ → ℝ} (hK : Integrable K) (hKc : Causal K)
    (hf : Integrable (causalize f) volume) {z : RealL1} (hc : Causal z)
    (hz : z=hf.toL1 (causalize f)+convOp hK z) :
    (z : ℝ → ℝ)=ᵐ[volume] causalize (fun t => f t+(K ⋆ (z : ℝ → ℝ)) t) := by
  have hh := Lp.coeFn_add (hf.toL1 (causalize f)) (convOp hK z)
  rw [← hz] at hh
  filter_upwards [hh,hf.coeFn_toL1,convOp_coe hK z] with t ht hft hkt
  rw [ht]
  simp only [Pi.add_apply,hft,hkt]
  by_cases hn : 0 ≤ t
  · simp [causalize,hn]
  · simp [causalize,hn,convolution_causal hKc hc t (lt_of_not_ge hn)]

-- @paper-step thm:pid_two_rate_optimum/ordinary_PID_representatives
theorem twoRate_representatives_ae {i ρ ell l m δ : ℝ} (h : TwoRateData i ρ ell l m δ)
    {e v : RealL1} (hs : TwoRateRenewalPair h e v) :
    (e : ℝ → ℝ)=ᵐ[volume] causalize (twoRateErrorRep (twoRateA ρ l m) l m δ e) ∧
    (v : ℝ → ℝ)=ᵐ[volume] causalize (twoRateCommandRep (twoRateA ρ l m) l m δ v) := by
  exact ⟨renewal_representative_ae _ (twoRateK_causal _ _ _ _) _ hs.error_causal hs.error_eq,
    renewal_representative_ae _ (twoRateK_causal _ _ _ _) _ hs.command_causal hs.command_eq⟩

-- @paper-step thm:pid_two_rate_optimum/causal_convolution_initial_value
theorem causal_convolution_zero {K f : ℝ → ℝ} (hK : Causal K) (hf : Causal f) :
    (K ⋆ f) 0=0 := by
  rw [causal_convolution_interval hK hf le_rfl]
  simp

-- @paper-step thm:pid_two_rate_optimum/ordinary_initial_values
theorem twoRate_representatives_initial {i ρ ell l m δ : ℝ} (h : TwoRateData i ρ ell l m δ)
    {e v : RealL1} (hs : TwoRateRenewalPair h e v) :
    twoRateErrorRep (twoRateA ρ l m) l m δ e 0=1 ∧
    twoRateCommandRep (twoRateA ρ l m) l m δ v 0=
      twoRateD (twoRateA ρ l m) l m δ-1 := by
  constructor
  · rw [twoRateErrorRep,causal_convolution_zero (twoRateK_causal _ _ _ _) hs.error_causal,
      (twoRate_initial _ _ _).1,add_zero]
  · rw [twoRateCommandRep,causal_convolution_zero (twoRateK_causal _ _ _ _) hs.command_causal]
    simp only [twoRateR,zero_add,add_zero,max_eq_left h.delay_nonneg,(twoRate_initial _ _ _).1]
    ring

-- @paper-step thm:pid_two_rate_optimum/pointwise_convolution_nonnegativity
theorem convolution_pointwise_nonneg {K f : ℝ → ℝ}
    (hK : ∀ᵐ t, 0 ≤ K t) (hf : ∀ᵐ t, 0 ≤ f t) (t : ℝ) : 0 ≤ (K ⋆ f) t := by
  apply integral_nonneg_of_ae
  have hft := (quasiMeasurePreserving_sub_left_of_right_invariant
    (volume : Measure ℝ) t).tendsto_ae.eventually hf
  filter_upwards [hK,hft] with s hs hfs
  exact mul_nonneg hs hfs

-- @paper-step thm:pid_two_rate_optimum/ordinary_pointwise_signal_signs
theorem twoRate_representatives_nonneg {i ρ ell l m δ : ℝ} (h : TwoRateData i ρ ell l m δ)
    {e v : RealL1} (he : 0 ≤ e) (hv : 0 ≤ v) {t : ℝ} (ht : 0 ≤ t) :
    0 < twoRateErrorRep (twoRateA ρ l m) l m δ e t ∧
      0 ≤ twoRateCommandRep (twoRateA ρ l m) l m δ v t := by
  have hA := twoRateA_ge_one h.ordered_rates h.filter_lower
  have hz := twoRate_rate_condition h.ordered_rates h.filter_upper
  have hKn : ∀ᵐ s, 0 ≤ twoRateK (twoRateA ρ l m) l m δ s := ae_of_all volume
    (twoRateK_nonneg hA h.lower_rate h.ordered_rates.le hz)
  constructor
  · exact add_pos_of_pos_of_nonneg (twoRateG_positive hA h.ordered_rates.le ht)
      (convolution_pointwise_nonneg hKn ((Lp.coeFn_nonneg _).mpr he) t)
  · exact add_nonneg (twoRateR_nonneg hA h.lower_rate h.ordered_rates.le hz h.delay_nonneg
      h.initial_forcing t ht) (convolution_pointwise_nonneg hKn ((Lp.coeFn_nonneg _).mpr hv) t)

end MIACE
