import MIACE.Dynamics
import Mathlib.Analysis.Calculus.ContDiff.Deriv
import Mathlib.Analysis.Calculus.ContDiff.RCLike

/-! The nonlinear storage balance underlying manuscript Theorem 32.
The physical output and command are `y` and `w`.  The criterion retains
the original signals `1-y` and `w-1`; the storage primitive is used only
to integrate the ODE.  In particular, the signed balance is a conclusion.
-/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def storagePhi (a : ℝ → ℝ) (x : ℝ) : ℝ :=
  ∫ z in (0 : ℝ)..x, (a z)⁻¹

noncomputable def storageArea (a : ℝ → ℝ) : ℝ := storagePhi a 1

structure NonlinearResponse (a y w : ℝ → ℝ) : Prop where
  ac : ∀ h : ℝ, 0 ≤ h → AbsolutelyContinuousOnInterval y 0 h
  ode : ∀ᵐ t : ℝ, 0 < t → deriv y t = a (y t) * (w t - y t)
  initial : y 0 = 0
  finalValue : Tendsto y atTop (𝓝 1)
  error_integrable : Integrable (fun t => 1 - y t) halfLine
  command_integrable : Integrable (fun t => w t - 1) halfLine

-- @paper-step thm:nonlinear_miace/reciprocal_continuity
theorem nonlinear_reciprocal_continuous {a : ℝ → ℝ}
    (ha : Continuous a) (hapos : ∀ x, 0 < a x) :
    Continuous (fun x => (a x)⁻¹) :=
  ha.inv₀ (fun x => ne_of_gt (hapos x))

-- @paper-step thm:nonlinear_miace/storage_derivative
theorem storagePhi_hasDerivAt {a : ℝ → ℝ}
    (ha : Continuous a) (hapos : ∀ x, 0 < a x) (x : ℝ) :
    HasDerivAt (storagePhi a) (a x)⁻¹ x := by
  have hi := nonlinear_reciprocal_continuous ha hapos
  exact intervalIntegral.integral_hasDerivAt_right
    (hi.intervalIntegrable 0 x)
    hi.aestronglyMeasurable.stronglyMeasurableAtFilter hi.continuousAt

-- @paper-step thm:nonlinear_miace/storage_C1
theorem storagePhi_contDiff {a : ℝ → ℝ}
    (ha : Continuous a) (hapos : ∀ x, 0 < a x) :
    ContDiff ℝ 1 (storagePhi a) := by
  apply contDiff_one_iff_deriv.mpr
  refine ⟨fun x => (storagePhi_hasDerivAt ha hapos x).differentiableAt, ?_⟩
  have heq : deriv (storagePhi a) = fun x => (a x)⁻¹ := by
    funext x
    exact (storagePhi_hasDerivAt ha hapos x).deriv
  rw [heq]
  exact nonlinear_reciprocal_continuous ha hapos

-- @paper-step thm:nonlinear_miace/storage_origin
@[simp] theorem storagePhi_zero (a : ℝ → ℝ) : storagePhi a 0 = 0 := by
  simp [storagePhi]

-- @paper-step thm:nonlinear_miace/storage_area_positive
theorem storageArea_pos {a : ℝ → ℝ}
    (ha : Continuous a) (hapos : ∀ x, 0 < a x) : 0 < storageArea a := by
  unfold storageArea storagePhi
  exact intervalIntegral.integral_pos (by norm_num)
    (nonlinear_reciprocal_continuous ha hapos).continuousOn
    (fun x _ => le_of_lt (inv_pos.mpr (hapos x)))
    ⟨0, by simp, inv_pos.mpr (hapos 0)⟩

-- @paper-step thm:nonlinear_miace/C1_AC_composition
theorem c1_comp_absolutelyContinuous {phi y : ℝ → ℝ} {b c : ℝ}
    (hphi : ContDiff ℝ 1 phi) (hy : AbsolutelyContinuousOnInterval y b c) :
    AbsolutelyContinuousOnInterval (phi ∘ y) b c := by
  have hk : IsCompact (y '' uIcc b c) :=
    isCompact_uIcc.image_of_continuousOn hy.continuousOn
  obtain ⟨K, hK⟩ :=
    hphi.locallyLipschitz.locallyLipschitzOn.exists_lipschitzOnWith_of_compact hk
  exact hK.comp_absolutelyContinuousOnInterval (fun x hx => ⟨x, hx, rfl⟩) hy

-- @paper-step thm:nonlinear_miace/AC_chain_FTC
theorem c1_chain_integral {phi y : ℝ → ℝ} {b c : ℝ}
    (hphi : ContDiff ℝ 1 phi) (hy : AbsolutelyContinuousOnInterval y b c) :
    (∫ t in b..c, deriv phi (y t) * deriv y t) = phi (y c) - phi (y b) := by
  have hFTC := (c1_comp_absolutelyContinuous hphi hy).integral_deriv_eq_sub
  have heq : (∫ t in b..c, deriv (phi ∘ y) t) =
      ∫ t in b..c, deriv phi (y t) * deriv y t := by
    apply intervalIntegral.integral_congr_ae
    filter_upwards [hy.ae_differentiableAt] with t ht htmem
    have hyt := ht (uIoc_subset_uIcc htmem)
    exact ((hphi.differentiable (by decide) (y t)).hasDerivAt.comp t hyt.hasDerivAt).deriv
  rw [heq] at hFTC
  exact hFTC

-- @paper-step thm:nonlinear_miace/AC_restriction
theorem nonlinear_response_ac_between {a y w : ℝ → ℝ}
    (h : NonlinearResponse a y w) {b c : ℝ} (hb : 0 ≤ b) (hbc : b ≤ c) :
    AbsolutelyContinuousOnInterval y b c := by
  apply (h.ac c (hb.trans hbc)).mono
  rw [uIcc_of_le hbc, uIcc_of_le (hb.trans hbc)]
  exact fun _ hx => ⟨hb.trans hx.1, hx.2⟩

-- @paper-step thm:nonlinear_miace/finite_storage_balance
theorem nonlinear_response_increment {a y w : ℝ → ℝ}
    (ha : Continuous a) (hapos : ∀ x, 0 < a x) (h : NonlinearResponse a y w)
    {b c : ℝ} (hb : 0 ≤ b) (hbc : b ≤ c) :
    (∫ t in b..c, (1 - y t) + (w t - 1)) =
      storagePhi a (y c) - storagePhi a (y b) := by
  have hFTC := c1_chain_integral (storagePhi_contDiff ha hapos)
    (nonlinear_response_ac_between h hb hbc)
  have heq : (∫ t in b..c, deriv (storagePhi a) (y t) * deriv y t) =
      ∫ t in b..c, (1 - y t) + (w t - 1) := by
    apply intervalIntegral.integral_congr_ae
    filter_upwards [h.ode] with t ht htmem
    rw [uIoc_of_le hbc] at htmem
    rw [(storagePhi_hasDerivAt ha hapos (y t)).deriv,
      ht (lt_of_le_of_lt hb htmem.1)]
    field_simp [ne_of_gt (hapos (y t))]
    ring
  rw [heq] at hFTC
  exact hFTC

-- @paper-step thm:nonlinear_miace/infinite_storage_balance
theorem nonlinear_response_signed_balance {a y w : ℝ → ℝ}
    (ha : Continuous a) (hapos : ∀ x, 0 < a x) (h : NonlinearResponse a y w) :
    (∫ t, (1 - y t) ∂halfLine) + (∫ t, (w t - 1) ∂halfLine) = storageArea a := by
  have hlim := intervalIntegral_tendsto_integral_Ioi 0
    (h.error_integrable.add h.command_integrable) tendsto_id
  have heq : (fun b : ℝ => ∫ t in 0..b, (1 - y t) + (w t - 1)) =ᶠ[atTop]
      (fun b => storagePhi a (y b)) := by
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with b hb
    rw [nonlinear_response_increment ha hapos h le_rfl hb, h.initial,
      storagePhi_zero, sub_zero]
  have hlim2 : Tendsto (fun b : ℝ => storagePhi a (y b)) atTop (𝓝 (storageArea a)) :=
    (storagePhi_contDiff ha hapos).continuous.continuousAt.tendsto.comp h.finalValue
  have hi := tendsto_nhds_unique hlim (hlim2.congr' heq.symm)
  simpa only [Pi.add_apply, integral_add h.error_integrable h.command_integrable] using hi

-- @paper-step thm:nonlinear_miace/absolute_area_balance
theorem nonlinear_response_area_balance {a y w : ℝ → ℝ}
    (ha : Continuous a) (hapos : ∀ x, 0 < a x) (h : NonlinearResponse a y w) :
    absArea (fun t => 1 - y t) halfLine + absArea (fun t => w t - 1) halfLine =
      storageArea a + 2 * (negArea (fun t => 1 - y t) halfLine +
        negArea (fun t => w t - 1) halfLine) :=
  area_balance h.error_integrable h.command_integrable (storageArea a)
    (nonlinear_response_signed_balance ha hapos h)

-- @paper-step thm:nonlinear_miace/exact_gap
theorem nonlinear_response_excess {a y w : ℝ → ℝ}
    (ha : Continuous a) (hapos : ∀ x, 0 < a x) (h : NonlinearResponse a y w)
    (α : ℝ) (hα : 0 < α) :
    costSq α (absArea (fun t => 1 - y t) halfLine)
        (absArea (fun t => w t - 1) halfLine) - baseSq α (storageArea a) =
      4 * α / (1 + α) *
        (negArea (fun t => 1 - y t) halfLine + negArea (fun t => w t - 1) halfLine) *
        (storageArea a + (negArea (fun t => 1 - y t) halfLine +
          negArea (fun t => w t - 1) halfLine)) +
      (absArea (fun t => 1 - y t) halfLine -
        α * absArea (fun t => w t - 1) halfLine)^2 / (1 + α) :=
  signal_excess h.error_integrable h.command_integrable α (storageArea a) hα
    (nonlinear_response_signed_balance ha hapos h)

-- @paper-step thm:nonlinear_miace/equality_iff
theorem nonlinear_response_equality_iff {a y w : ℝ → ℝ}
    (ha : Continuous a) (hapos : ∀ x, 0 < a x) (h : NonlinearResponse a y w)
    (α : ℝ) (hα : 0 < α) :
    costSq α (absArea (fun t => 1 - y t) halfLine)
        (absArea (fun t => w t - 1) halfLine) = baseSq α (storageArea a) ↔
      (∀ᵐ t ∂halfLine, 0 ≤ 1 - y t) ∧
      (∀ᵐ t ∂halfLine, 0 ≤ w t - 1) ∧
      absArea (fun t => 1 - y t) halfLine =
        α * absArea (fun t => w t - 1) halfLine :=
  signal_equality_iff h.error_integrable h.command_integrable α (storageArea a)
    hα (storageArea_pos ha hapos) (nonlinear_response_signed_balance ha hapos h)

-- @paper-step thm:nonlinear_miace/equality_output_monotone
theorem nonlinear_response_output_monotone {a y w : ℝ → ℝ}
    (hapos : ∀ x, 0 < a x) (h : NonlinearResponse a y w)
    (he : ∀ᵐ t ∂halfLine, 0 ≤ 1 - y t)
    (hv : ∀ᵐ t ∂halfLine, 0 ≤ w t - 1) : MonotoneOn y (Ici 0) := by
  intro b hb c hc hbc
  have hac := nonlinear_response_ac_between h hb hbc
  have hn : 0 ≤ ∫ t in b..c, deriv y t := by
    rw [intervalIntegral.integral_of_le hbc]
    apply integral_nonneg_of_ae
    have hsub : Ioc b c ⊆ Ioi (0 : ℝ) := fun t ht => lt_of_le_of_lt hb ht.1
    filter_upwards [ae_restrict_of_ae_restrict_of_subset hsub he,
      ae_restrict_of_ae_restrict_of_subset hsub hv,
      ae_restrict_of_ae h.ode, ae_restrict_mem measurableSet_Ioc] with t ht hu ho hm
    rw [ho (lt_of_le_of_lt hb hm.1)]
    exact mul_nonneg (le_of_lt (hapos (y t))) (by linarith)
  rw [hac.integral_deriv_eq_sub] at hn
  linarith

-- @paper-step thm:nonlinear_miace/equality_output_bounds
theorem nonlinear_response_output_bounds {a y w : ℝ → ℝ}
    (hapos : ∀ x, 0 < a x) (h : NonlinearResponse a y w)
    (he : ∀ᵐ t ∂halfLine, 0 ≤ 1 - y t)
    (hv : ∀ᵐ t ∂halfLine, 0 ≤ w t - 1)
    {t : ℝ} (ht : 0 ≤ t) : 0 ≤ y t ∧ y t ≤ 1 := by
  have hm := nonlinear_response_output_monotone hapos h he hv
  constructor
  · have hz := hm (by simp) ht ht
    simpa only [h.initial] using hz
  · apply ge_of_tendsto h.finalValue
    filter_upwards [eventually_ge_atTop t] with b hb
    exact hm ht (ht.trans hb) hb

end MIACE
