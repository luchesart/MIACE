import MIACE.RemainderInterpolation
import Mathlib.Algebra.Polynomial.Splits

namespace MIACE
open Polynomial

-- @paper-step lem:n_remainder/uniqueness_from_confluent_interpolation
theorem hermite_polynomial_unique (B P Q : ℂ[X]) (hB : B.Splits) (hB0 : B≠0)
    (hP : P.natDegree<B.natDegree) (hQ : Q.natDegree<B.natDegree)
    (hjets : ∀ z : ℂ, ∀ k<B.rootMultiplicity z,
      iteratedDeriv k (fun p => P.eval p) z=iteratedDeriv k (fun p => Q.eval p) z) : P=Q := by
  by_contra hne
  have hD : P-Q≠0 := sub_ne_zero.mpr hne
  have hm (z : ℂ) : B.rootMultiplicity z≤(P-Q).rootMultiplicity z := by
    by_contra hh
    have hh' : (P-Q).rootMultiplicity z<B.rootMultiplicity z := lt_of_not_ge hh
    have hz := lt_rootMultiplicity_of_isRoot_iterate_derivative hD
      (n := (P-Q).rootMultiplicity z) (t := z) (fun k hk => by
        change ((derivative^[k]) (P-Q)).eval z=0
        rw [← polynomial_iterated_deriv]
        have he : (fun p => (P-Q).eval p)=(fun p => P.eval p-Q.eval p) := by
          funext p; simp
        rw [he,iteratedDeriv_fun_sub
          (by exact (Differentiable.analyticAt (fun p => P.differentiableAt) z).contDiffAt)
          (by exact (Differentiable.analyticAt (fun p => Q.differentiableAt) z).contDiffAt),hjets z k (hk.trans_lt hh'),sub_self])
    exact (lt_irrefl _) hz
  have hd : B∣P-Q := hB.dvd_of_roots_le_roots hB0 (by
    apply Multiset.le_iff_count.mpr
    intro z; simpa only [count_roots] using hm z)
  have hdeg := natDegree_le_of_dvd hd hD
  have hsmall : (P-Q).natDegree<B.natDegree :=
    (natDegree_sub_le P Q).trans_lt (max_lt hP hQ)
  exact (not_lt_of_ge hdeg) hsmall

-- @paper-step lem:n_remainder/real_factor_polynomial_splits
theorem remainderB_splits (r : ℕ → ℝ) (n : ℕ) : (remainderB r n).Splits := by
  have hl (j : ℕ) : (C (1/r j)*X+(1 : ℝ[X])).Splits :=
    Splits.of_natDegree_le_one (by simpa using (natDegree_linear_le (a := 1/r j) (b := (1 : ℝ))))
  induction n with
  | zero => exact hl 0
  | succ n ih => exact ih.mul (hl (n+1))

-- @paper-step lem:n_remainder/constructed_polynomial_is_unique_hermite_interpolant
theorem remainderI_unique (r : ℕ → ℝ) (n : ℕ) (δ : ℝ)
    (hr : ∀ j≤n, r j≠0) (P : ℝ[X]) (hP : P.natDegree≤n)
    (hjets : ∀ z : ℂ, ∀ k<((remainderB r n).map Complex.ofRealHom).rootMultiplicity z,
      iteratedDeriv k (fun p => P.eval₂ Complex.ofRealHom p) z=
        (-(δ : ℂ))^k*Complex.exp (-(δ : ℂ)*z)) : P=remainderI r δ n := by
  have he : P.map Complex.ofRealHom=(remainderI r δ n).map Complex.ofRealHom := by
    apply hermite_polynomial_unique ((remainderB r n).map Complex.ofRealHom)
      _ _ ((remainderB_splits r n).map _) (by simpa using remainderB_ne_zero r n)
    · simpa only [natDegree_map,remainderB_degree r n hr] using Nat.lt_succ_of_le hP
    · simpa only [natDegree_map,remainderB_degree r n hr] using
        Nat.lt_succ_of_le (remainderI_degree r n δ hr)
    · intro z k hk
      simpa only [eval_map] using (hjets z k hk).trans (remainder_hermite r n δ hr z k hk).symm
  exact (Polynomial.map_injective Complex.ofRealHom Complex.ofReal_injective) he

-- @paper-step lem:n_remainder/full_interpolatory_delay_identity
theorem paper_delay_remainder (r : ℕ → ℝ) (n : ℕ) (δ : ℝ)
    (hr : ∀ j≤n, 0<r j) (P : ℝ[X]) (hP : P.natDegree≤n)
    (hjets : ∀ z : ℂ, ∀ k<((remainderB r n).map Complex.ofRealHom).rootMultiplicity z,
      iteratedDeriv k (fun p => P.eval₂ Complex.ofRealHom p) z=
        (-(δ : ℂ))^k*Complex.exp (-(δ : ℂ)*z)) :
    (∀ p : ℂ, Complex.exp (-(δ : ℂ)*p)=P.eval₂ Complex.ofRealHom p+
      (-1 : ℂ)^(n+1)*(remainderB r n).eval₂ Complex.ofRealHom p*
        compactLaplace (remainderJ r n δ) δ p) ∧
    (∀ t≤δ, 0≤remainderJ r n δ t) := by
  rw [remainderI_unique r n δ (fun j hj => ne_of_gt (hr j hj)) P hP hjets]
  exact ⟨fun p => exact_delay_remainder_complex r n δ p (fun j hj => ne_of_gt (hr j hj)),
    fun t ht => remainderJ_nonneg r n (fun j hj => (hr j hj).le) ht⟩

end MIACE
