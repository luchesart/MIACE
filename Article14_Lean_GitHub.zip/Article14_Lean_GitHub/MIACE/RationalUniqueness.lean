import MIACE.RationalControl
import MIACE.FiniteRetarded
import MIACE.ScalarDelayUniqueness

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

abbrev RationalIndex (n : ℕ) := Unit ⊕ (Fin (n+1) ⊕ Fin (n+1))
noncomputable def rationalCoordinate (r : ℕ → ℝ) (n : ℕ) (δ : ℝ)
    (H : RationalHistory) (w : ℝ → ℝ) : RationalIndex n → ℝ → ℝ
  | .inl _ => w
  | .inr (.inl j) => rationalIState r δ H w j
  | .inr (.inr j) => rationalBState r δ H w j

-- @paper-step thm:n_construction/three_term_uniform_coordinate_estimate
theorem linear_three_bound (a b c x y z S : ℝ) (hx : |x|≤S) (hy : |y|≤S) (hz : |z|≤S) :
    |a*x+b*y+c*z|≤(|a|+|b|+|c|)*S := by
  have hh := (abs_add_le (a*x+b*y) (c*z)).trans
    (add_le_add (abs_add_le (a*x) (b*y)) (le_refl _))
  simp only [abs_mul] at hh
  nlinarith [mul_le_mul_of_nonneg_left hx (abs_nonneg a),
    mul_le_mul_of_nonneg_left hy (abs_nonneg b),mul_le_mul_of_nonneg_left hz (abs_nonneg c)]

-- @paper-step thm:n_construction/ordinary_full_coordinates_regular
 theorem rational_coordinates_regular (r : ℕ → ℝ) (n : ℕ) {δ a c : ℝ} (H : RationalHistory)
    (hHi : Integrable (historyInput δ H.past)) {w : ℝ → ℝ}
    (hw : RationalHistoryEvolution r n δ a c H w) :
    (∀ k, Continuous (rationalCoordinate r n δ H w k)) ∧
    (∀ k T, 0≤T → AbsolutelyContinuousOnInterval (rationalCoordinate r n δ H w k) 0 T) := by
  have hu : LocallyIntegrable (rationalDelayed δ H w) volume :=
    hHi.locallyIntegrable.add (scalarDelay_shift_local hw.continuous δ)
  have hI := remainderFilter_evolution hw.continuous.locallyIntegrable r δ H.controllerInitial
  constructor
  · intro k
    rcases k with u | (j | j)
    · exact hw.continuous
    · exact remainderFilter_local hw.continuous.locallyIntegrable r δ H.controllerInitial j
    · exact (serialState_evolution hu (fun j => 1/r j) H.plantInitial j).1
  · intro k T hT
    rcases k with u | (j | j)
    · exact hw.ac T hT
    · cases hj : j.val with
      | zero => exact (hj ▸ hI.1).ac T hT
      | succ m => exact (hj ▸ hI.2 m).ac T hT
    · exact (serialState_evolution hu (fun j => 1/r j) H.plantInitial j).2.ac T hT

-- @paper-step thm:n_construction/full_state_initial_coordinates
 theorem rational_coordinates_initial (r : ℕ → ℝ) (n : ℕ) {δ a c : ℝ} (H : RationalHistory)
    {w W : ℝ → ℝ} (hw : RationalHistoryEvolution r n δ a c H w)
    (hW : RationalHistoryEvolution r n δ a c H W) :
    ∀ k, rationalCoordinate r n δ H w k 0=rationalCoordinate r n δ H W k 0 := by
  intro k
  rcases k with u | (j | j)
  · exact hw.initial.trans hW.initial.symm
  · change remainderFilter r δ H.controllerInitial w j 0=remainderFilter r δ H.controllerInitial W j 0
    cases j.val <;> simp [remainderFilter,lagState,lag]
  · simp [rationalCoordinate,rationalBState,serialState,lagState,lag]

-- @paper-step thm:n_construction/full_rational_evolution_unrestricted_uniqueness
theorem rational_history_unique (r : ℕ → ℝ) (n : ℕ) {δ a c : ℝ} (hδ : 0≤δ)
    (H : RationalHistory) (hHi : Integrable (historyInput δ H.past)) {w W : ℝ → ℝ}
    (hw : RationalHistoryEvolution r n δ a c H w)
    (hW : RationalHistoryEvolution r n δ a c H W) : ∀ t, 0≤t → w t=W t := by
  classical
  let x := fun k t => rationalCoordinate r n δ H w k t-rationalCoordinate r n δ H W k t
  let f := fun t => ∑ k : RationalIndex n, |x k t|
  let L : RationalIndex n → ℝ
    | .inl _ => |-c/a|+|1/a|+|-(1/a)|
    | .inr (.inl j) => |r j|+|r j*remainderFeed r δ j|+|-r j|
    | .inr (.inr j) => |r j|+|-r j|+0
  have hL (k : RationalIndex n) : 0≤L k := by
    rcases k with u | (j | j) <;> dsimp [L] <;> positivity
  have hwreg := rational_coordinates_regular r n H hHi hw
  have hWreg := rational_coordinates_regular r n H hHi hW
  have h0 (k : RationalIndex n) : x k 0=0 := sub_eq_zero.mpr (rational_coordinates_initial r n H hw hW k)
  have hb (k : RationalIndex n) (t : ℝ) : |x k t|≤f t :=
    Finset.single_le_sum (f := fun j => |x j t|) (fun j _ => abs_nonneg _) (Finset.mem_univ k)
  have hf (t : ℝ) : 0≤f t := Finset.sum_nonneg (fun _ _ => abs_nonneg _)
  have hbnow (k : RationalIndex n) (t : ℝ) : |x k t|≤f t+f (max 0 (t-δ)) :=
    (hb k t).trans (le_add_of_nonneg_right (hf _))
  have hbdel (k : RationalIndex n) (t : ℝ) : |x k (max 0 (t-δ))|≤f t+f (max 0 (t-δ)) :=
    (hb k _).trans (le_add_of_nonneg_left (hf _))
  have hzero (t : ℝ) : |(0 : ℝ)|≤f t+f (max 0 (t-δ)) := by rw [abs_zero]; exact add_nonneg (hf _) (hf _)
  have huw : LocallyIntegrable (rationalDelayed δ H w) volume :=
    hHi.locallyIntegrable.add (scalarDelay_shift_local hw.continuous δ)
  have huW : LocallyIntegrable (rationalDelayed δ H W) volume :=
    hHi.locallyIntegrable.add (scalarDelay_shift_local hW.continuous δ)
  have hIw := remainderFilter_evolution hw.continuous.locallyIntegrable r δ H.controllerInitial
  have hIW := remainderFilter_evolution hW.continuous.locallyIntegrable r δ H.controllerInitial
  have hd (k : RationalIndex n) : ∀ᵐ t, 0<t → |deriv (x k) t|≤L k*(f t+f (max 0 (t-δ))) := by
    rcases k with u | (j | j)
    · filter_upwards [hw.ode,hW.ode] with t ht hT ht0
      have hh := ((ht ht0).sub (hT ht0)).deriv
      change deriv (x (.inl u)) t=_ at hh
      rw [hh]
      have he : ((-c*w t+rationalIState r δ H w n t-rationalBState r δ H w n t)/a)-
          ((-c*W t+rationalIState r δ H W n t-rationalBState r δ H W n t)/a)=
          (-c/a)*x (.inl u) t+(1/a)*x (.inr (.inl ⟨n,by omega⟩)) t+
            (-(1/a))*x (.inr (.inr ⟨n,by omega⟩)) t := by dsimp [x,rationalCoordinate]; ring
      rw [he]
      exact linear_three_bound _ _ _ _ _ _ _ (hbnow _ t) (hbnow _ t) (hbnow _ t)
    · cases hj : j.val with
      | zero =>
        filter_upwards [hIw.1.ode,hIW.1.ode] with t ht hT ht0
        have hh := ((ht ht0).sub (hT ht0)).deriv
        change deriv (fun s => remainderFilter r δ H.controllerInitial w 0 s-remainderFilter r δ H.controllerInitial W 0 s) t=_ at hh
        have hder : deriv (x (.inr (.inl j))) t=
            r j*0+(r j*remainderFeed r δ j)*x (.inl ()) t+(-r j)*x (.inr (.inl j)) t := by
          change deriv (fun s => remainderFilter r δ H.controllerInitial w j s-remainderFilter r δ H.controllerInitial W j s) t=_
          simp only [hj]
          rw [hh]
          simp only [div_div_eq_mul_div,div_one]
          dsimp [x,rationalCoordinate,rationalIState]
          rw [hj]
          ring
        rw [hder]
        exact linear_three_bound _ _ _ _ _ _ _ (hzero t) (hbnow _ t) (hbnow _ t)
      | succ m =>
        filter_upwards [(hIw.2 m).ode,(hIW.2 m).ode] with t ht hT ht0
        have hh := ((ht ht0).sub (hT ht0)).deriv
        have hm : m<n+1 := by omega
        change deriv (fun s => remainderFilter r δ H.controllerInitial w (m+1) s-remainderFilter r δ H.controllerInitial W (m+1) s) t=_ at hh
        have hder : deriv (x (.inr (.inl j))) t=
            r j*x (.inr (.inl ⟨m,hm⟩)) t+(r j*remainderFeed r δ j)*x (.inl ()) t+
              (-r j)*x (.inr (.inl j)) t := by
          change deriv (fun s => remainderFilter r δ H.controllerInitial w j s-remainderFilter r δ H.controllerInitial W j s) t=_
          simp only [hj]
          rw [hh]
          simp only [div_div_eq_mul_div,div_one]
          dsimp [x,rationalCoordinate,rationalIState]
          rw [hj]
          ring
        rw [hder]
        exact linear_three_bound _ _ _ _ _ _ _ (hbnow _ t) (hbnow _ t) (hbnow _ t)
    · have hpw := (serialState_evolution huw (fun j => 1/r j) H.plantInitial j).2
      have hpW := (serialState_evolution huW (fun j => 1/r j) H.plantInitial j).2
      filter_upwards [hpw.ode,hpW.ode] with t ht hT ht0
      have hh := ((ht ht0).sub (hT ht0)).deriv
      change deriv (x (.inr (.inr j))) t=_ at hh
      cases hj : j.val with
      | zero =>
        have hder : deriv (x (.inr (.inr j))) t=
            r j*x (.inl ()) (max 0 (t-δ))+(-r j)*x (.inr (.inr j)) t+0*0 := by
          rw [hh]
          simp only [div_div_eq_mul_div,div_one]
          dsimp [x,rationalCoordinate,rationalBState]
          simp only [hj,serialState]
          have he := causalize_sub_clamp (hw.initial.trans hW.initial.symm) (t-δ)
          dsimp [rationalDelayed,shift]
          linear_combination r 0*he
        rw [hder]
        simpa only [abs_zero] using linear_three_bound (r j) (-r j) 0 _ _ 0 _ (hbdel _ t) (hbnow _ t) (hzero t)
      | succ m =>
        have hm : m<n+1 := by omega
        have hder : deriv (x (.inr (.inr j))) t=
            r j*x (.inr (.inr ⟨m,hm⟩)) t+(-r j)*x (.inr (.inr j)) t+0*0 := by
          rw [hh]
          simp only [div_div_eq_mul_div,div_one]
          dsimp [x,rationalCoordinate,rationalBState]
          simp only [hj]
          ring
        rw [hder]
        simpa only [abs_zero] using linear_three_bound (r j) (-r j) 0 _ _ 0 _ (hbnow _ t) (hbnow _ t) (hzero t)
  have hz := finite_retarded_zero (fun k => (hwreg.1 k).sub (hWreg.1 k))
    (fun k T hT => (hwreg.2 k T hT).sub (hWreg.2 k T hT)) h0 hδ L hL hd
  intro t ht
  exact sub_eq_zero.mp (hz t ht (.inl ()))

end MIACE
