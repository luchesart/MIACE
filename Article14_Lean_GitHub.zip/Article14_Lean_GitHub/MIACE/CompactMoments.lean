import MIACE.DelayRemainder

/-! Finite-support moment calculus shared by Theorems 17--19. Integrals
are actual interval integrals, and all formulas include delta=0. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def compactTail (J : ℝ → ℝ) (δ t : ℝ) : ℝ := ∫ s in t..δ, J s
noncomputable def compactMoment (J : ℝ → ℝ) (δ : ℝ) (n : ℕ) : ℝ :=
  ∫ t in 0..δ, t^n*J t
noncomputable def compactExpMoment (J : ℝ → ℝ) (δ γ : ℝ) : ℝ :=
  ∫ t in 0..δ, Real.exp (γ*t)*J t

-- @paper-step thm:n_construction/compact_tail_derivative
theorem compactTail_deriv {J : ℝ → ℝ} (hJ : Continuous J) (δ t : ℝ) :
    HasDerivAt (compactTail J δ) (-J t) t := by
  exact intervalIntegral.integral_hasDerivAt_left (hJ.intervalIntegrable t δ)
    (hJ.stronglyMeasurableAtFilter _ _) hJ.continuousAt

-- @paper-step thm:n_construction/compact_tail_continuity
theorem compactTail_continuous {J : ℝ → ℝ} (hJ : Continuous J) (δ : ℝ) :
    Continuous (compactTail J δ) :=
  continuous_iff_continuousAt.mpr (fun t => (compactTail_deriv hJ δ t).continuousAt)

-- @paper-step thm:n_construction/compact_tail_nonnegativity
theorem compactTail_nonneg {J : ℝ → ℝ} {δ t : ℝ} (ht : 0≤t) (htδ : t≤δ)
    (hn : ∀ s∈Icc (0 : ℝ) δ, 0≤J s) : 0≤compactTail J δ t := by
  apply intervalIntegral.integral_nonneg htδ
  exact fun s hs => hn s ⟨ht.trans hs.1,hs.2⟩

-- @paper-step thm:n_construction/tail_mass_equals_first_moment
theorem compactTail_integral {J : ℝ → ℝ} (hJ : Continuous J) (δ : ℝ) :
    (∫ t in 0..δ, compactTail J δ t)=compactMoment J δ 1 := by
  have hc := compactTail_continuous hJ δ
  have hd : ∀ t : ℝ, HasDerivAt (fun s => s*compactTail J δ s)
      (compactTail J δ t-t*J t) t := by
    intro t
    convert (hasDerivAt_id t).mul (compactTail_deriv hJ δ t) using 1
    · rfl
    · dsimp [id_eq]; ring
  have he := intervalIntegral.integral_eq_sub_of_hasDerivAt (fun t _ => hd t)
    ((hc.sub (continuous_id.mul hJ)).intervalIntegrable (μ := volume) 0 δ)
  rw [intervalIntegral.integral_sub (hc.intervalIntegrable 0 δ)
    (show IntervalIntegrable (fun t => t*J t) volume 0 δ from (continuous_id.mul hJ).intervalIntegrable 0 δ)] at he
  simp only [compactTail,intervalIntegral.integral_same,mul_zero,zero_mul,sub_self] at he
  simpa [compactMoment,compactTail] using sub_eq_zero.mp he

-- @paper-step thm:n_construction/exponential_tail_moment_identity
theorem compactTail_exp_identity {J : ℝ → ℝ} (hJ : Continuous J) (δ γ : ℝ) :
    γ*compactExpMoment (compactTail J δ) δ γ=
      compactExpMoment J δ γ-compactMoment J δ 0 := by
  have hc := compactTail_continuous hJ δ
  have ce : Continuous (fun t : ℝ => Real.exp (γ*t)) := by fun_prop
  have hd : ∀ t : ℝ, HasDerivAt (fun s => Real.exp (γ*s)*compactTail J δ s)
      (γ*(Real.exp (γ*t)*compactTail J δ t)-Real.exp (γ*t)*J t) t := by
    intro t
    convert (((hasDerivAt_id t).const_mul γ).exp).mul (compactTail_deriv hJ δ t)
      using 1
    · rfl
    · dsimp [id_eq]; ring
  have he := intervalIntegral.integral_eq_sub_of_hasDerivAt (fun t _ => hd t)
    ((((ce.mul hc).const_mul γ).sub (ce.mul hJ)).intervalIntegrable (μ := volume) 0 δ)
  rw [intervalIntegral.integral_sub
    (show IntervalIntegrable (fun t => γ*(Real.exp (γ*t)*compactTail J δ t)) volume 0 δ from
      ((ce.mul hc).const_mul γ).intervalIntegrable 0 δ)
    (show IntervalIntegrable (fun t => Real.exp (γ*t)*J t) volume 0 δ from
      (ce.mul hJ).intervalIntegrable 0 δ), intervalIntegral.integral_const_mul] at he
  simp only [compactTail,intervalIntegral.integral_same,mul_zero,Real.exp_zero,one_mul] at he
  dsimp [compactExpMoment,compactMoment,compactTail]
  simp only [pow_zero,one_mul]
  linarith


-- @paper-step thm:n_construction/exponential_tail_moment_quotient
theorem compactTail_exp_formula {J : ℝ → ℝ} (hJ : Continuous J) (δ : ℝ)
    {γ : ℝ} (hγ : γ≠0) :
    compactExpMoment (compactTail J δ) δ γ=
      (compactExpMoment J δ γ-compactMoment J δ 0)/γ := by
  apply (eq_div_iff hγ).mpr
  simpa [mul_comm] using compactTail_exp_identity hJ δ γ

-- @paper-step thm:n_construction/exponential_moment_bound
theorem compactExpMoment_bound {J : ℝ → ℝ} (hJ : Continuous J) {δ γ : ℝ}
    (hδ : 0≤δ) (hγ : 0≤γ) (hn : ∀ t∈Icc (0 : ℝ) δ, 0≤J t) :
    compactExpMoment J δ γ≤Real.exp (γ*δ)*compactMoment J δ 0 := by
  simp only [compactExpMoment,compactMoment,pow_zero,one_mul]
  rw [← intervalIntegral.integral_const_mul]
  apply intervalIntegral.integral_mono_on hδ
    (((by fun_prop : Continuous (fun t : ℝ => Real.exp (γ*t))).mul hJ).intervalIntegrable 0 δ)
    ((hJ.const_mul _).intervalIntegrable 0 δ)
  intro t ht
  exact mul_le_mul_of_nonneg_right (Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_left ht.2 hγ)) (hn t ht)

-- @paper-step thm:n_construction/weighted_tail_bound_by_first_moment
theorem compactTail_exp_bound {J : ℝ → ℝ} (hJ : Continuous J) {δ γ : ℝ}
    (hδ : 0≤δ) (hγ : 0≤γ) (hn : ∀ t∈Icc (0 : ℝ) δ, 0≤J t) :
    compactExpMoment (compactTail J δ) δ γ≤Real.exp (γ*δ)*compactMoment J δ 1 := by
  have hb := compactExpMoment_bound (compactTail_continuous hJ δ) hδ hγ
    (fun t ht => compactTail_nonneg ht.1 ht.2 hn)
  simpa [compactMoment,compactTail_integral hJ δ] using hb

-- @paper-step thm:n_construction/zero_delay_moments
theorem compactMoments_zero (J : ℝ → ℝ) (n : ℕ) (γ : ℝ) :
    compactMoment J 0 n=0 ∧ compactExpMoment J 0 γ=0 ∧ compactTail J 0 0=0 := by
  simp [compactMoment,compactExpMoment,compactTail]

end MIACE
