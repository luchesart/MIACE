import MIACE.PIDStateSpectrum
import MIACE.PIDTimeStates

/-! Етап 11: обратима координатна промяна, която запазва третото състояние.
    a=z+(1-ρ)ζ, b=y-z, c=z. Редуцираният контур е (a,b);
    c'=-c-b е стабилният режим, който не трябва да се изтрива при съкращение. -/
namespace MIACE
open MeasureTheory Filter Set Matrix
open scoped Topology Matrix

noncomputable def pidReduce (ρ : ℝ) (x : Fin 3 → ℝ) : Fin 3 → ℝ :=
  ![x 1 + (1-ρ)*x 2, x 0-x 1, x 1]
noncomputable def pidRestore (ρ : ℝ) (u : Fin 3 → ℝ) : Fin 3 → ℝ :=
  ![u 1+u 2, u 2, (u 0-u 2)/(1-ρ)]

-- @paper-step thm:pid_two_rate_optimum/reduced_state_left_inverse
theorem pidRestore_reduce {ρ : ℝ} (hρ : ρ ≠ 1) (x : Fin 3 → ℝ) :
    pidRestore ρ (pidReduce ρ x) = x := by
  have hh : 1-ρ ≠ 0 := sub_ne_zero.mpr hρ.symm
  ext k
  fin_cases k <;> simp [pidRestore,pidReduce] <;> field_simp <;> ring

-- @paper-step thm:pid_two_rate_optimum/reduced_state_right_inverse
theorem pidReduce_restore {ρ : ℝ} (hρ : ρ ≠ 1) (u : Fin 3 → ℝ) :
    pidReduce ρ (pidRestore ρ u) = u := by
  have hh : 1-ρ ≠ 0 := sub_ne_zero.mpr hρ.symm
  ext k
  fin_cases k <;> simp [pidRestore,pidReduce] <;> field_simp <;> ring

-- @paper-step thm:pid_two_rate_optimum/reduced_command_identity
theorem pid_command_reduced (i ell : ℝ) {ρ : ℝ} (hρ : ρ ≠ 0) (x : Fin 3 → ℝ) :
    pidHomogeneousCommand (i*(1+ell-ρ)) i (i*(ell-ρ)*(1-ρ)) ρ x =
      -(i/ρ)*((ell-ρ)*(pidReduce ρ x) 0+ell*(pidReduce ρ x) 1) := by
  simp [pidHomogeneousCommand,pidReduce]
  field_simp
  <;> ring

-- @paper-step thm:pid_two_rate_optimum/triangular_physical_state_equations
theorem pid_reduced_dynamics (i ell : ℝ) {ρ : ℝ} (hρ : ρ ≠ 0)
    (x xd : Fin 3 → ℝ) :
    pidReduce ρ ((pidStateA0 ρ).mulVec x +
      (pidStateA1 (i*(1+ell-ρ)) i (i*(ell-ρ)*(1-ρ)) ρ).mulVec xd) =
      ![-((pidReduce ρ x) 0+(pidReduce ρ x) 1)/ρ,
        -(i/ρ)*((ell-ρ)*(pidReduce ρ xd) 0+ell*(pidReduce ρ xd) 1),
        -(pidReduce ρ x) 2-(pidReduce ρ x) 1] := by
  rw [pid_state_equations,pid_command_reduced i ell hρ]
  ext k
  fin_cases k <;> simp [pidReduce] <;> field_simp <;> ring

-- @paper-step thm:pid_two_rate_optimum/reduced_trajectory_derivatives
theorem pid_reduced_derivatives {y z ζ : ℝ → ℝ} {i ρ ell δ t : ℝ}
    (hρ : ρ ≠ 0)
    (hy : HasDerivAt y (-y t+pidHomogeneousCommand (i*(1+ell-ρ)) i
      (i*(ell-ρ)*(1-ρ)) ρ ![y (t-δ),z (t-δ),ζ (t-δ)]) t)
    (hz : HasDerivAt z (-y t) t)
    (hζ : HasDerivAt ζ ((-y t-ζ t)/ρ) t) :
    HasDerivAt (fun s => z s+(1-ρ)*ζ s)
      (-((z t+(1-ρ)*ζ t)+(y t-z t))/ρ) t ∧
    HasDerivAt (fun s => y s-z s)
      (-(i/ρ)*((ell-ρ)*(z (t-δ)+(1-ρ)*ζ (t-δ))+ell*(y (t-δ)-z (t-δ)))) t ∧
    HasDerivAt z (-z t-(y t-z t)) t := by
  refine ⟨?_,?_,?_⟩
  · convert hz.add (hζ.const_mul (1-ρ)) using 1 <;> field_simp <;> ring
  · have he := pid_command_reduced i ell hρ ![y (t-δ),z (t-δ),ζ (t-δ)]
    simp [pidReduce] at he
    convert hy.sub hz using 1
    rw [he]
    ring
  · convert hz using 1 <;> ring

-- @paper-step thm:pid_two_rate_optimum/scalar_reduced_characteristic_equation
theorem pid_reduced_scalar_equation {i ρ ell a ad add aδ adδ b bd bδ : ℝ}
    (hρ : ρ ≠ 0) (ha : ad=-(a+b)/ρ) (haδ : adδ=-(aδ+bδ)/ρ)
    (hb : bd=-(i/ρ)*((ell-ρ)*aδ+ell*bδ))
    (hda : add=-(ad+bd)/ρ) :
    ρ*add+ad+i*(ell*adδ+aδ)=0 := by
  have hh := (eq_div_iff hρ).mp ha
  have hhδ := (eq_div_iff hρ).mp haδ
  have hd := (eq_div_iff hρ).mp hda
  have hb' : ρ*bd = -i*((ell-ρ)*aδ+ell*bδ) := by rw [hb]; field_simp <;> ring
  have hb0 : bd=i*(ell*adδ+aδ) := by
    apply mul_left_cancel₀ hρ
    linear_combination hb' - i*ell*hhδ
  rw [hb0] at hd
  linarith

noncomputable def pidStableState (c₀ : ℝ) (b : ℝ → ℝ) (t : ℝ) : ℝ :=
  c₀*Real.exp (-t)-lag 1 b t

-- За t>δ и двете точки t и t-δ принадлежат на решението, а не на
-- произволно зададената история. На първия интервал остава входът Hφ.
-- @paper-step thm:pid_two_rate_optimum/actual_second_order_delay_equation
theorem pid_reduced_actual_scalar_DDE {a b : ℝ → ℝ} {i ρ ell δ t : ℝ}
    (hρ : ρ ≠ 0) (hδ : 0≤δ) (ht : δ<t)
    (ha : ∀ s, 0<s → HasDerivAt a (-(a s+b s)/ρ) s)
    (hb : HasDerivAt b (-(i/ρ)*((ell-ρ)*a (t-δ)+ell*b (t-δ))) t) :
    ρ*deriv (deriv a) t+deriv a t+i*(ell*deriv a (t-δ)+a (t-δ))=0 := by
  have ht0 : 0<t := lt_of_le_of_lt hδ ht
  have ha' : HasDerivAt a (deriv a t) t := (ha t ht0).differentiableAt.hasDerivAt
  have hb' : HasDerivAt b (deriv b t) t := hb.differentiableAt.hasDerivAt
  have hh := ((ha'.add hb').neg.div_const ρ)
  have he : deriv a =ᶠ[𝓝 t] (fun s => -(a s+b s)/ρ) := by
    filter_upwards [eventually_gt_nhds ht0] with s hs
    exact (ha s hs).deriv
  have hdd : HasDerivAt (deriv a) (-(deriv a t+deriv b t)/ρ) t :=
    hh.congr_of_eventuallyEq he
  exact pid_reduced_scalar_equation hρ (ha t ht0).deriv
    (ha (t-δ) (sub_pos.mpr ht)).deriv hb.deriv hdd.deriv

-- @paper-step thm:pid_two_rate_optimum/restored_stable_mode_initial
theorem pidStableState_initial (c₀ : ℝ) (b : ℝ → ℝ) :
    pidStableState c₀ b 0=c₀ := by simp [pidStableState,lag]

-- @paper-step thm:pid_two_rate_optimum/restored_stable_mode_derivative
theorem pidStableState_derivative (c₀ : ℝ) {b : ℝ → ℝ} (hb : Continuous b)
    {t : ℝ} (ht : 0<t) :
    HasDerivAt (pidStableState c₀ b) (-pidStableState c₀ b t-b t) t := by
  have he : HasDerivAt (fun s : ℝ => Real.exp (-s)) (-Real.exp (-t)) t := by
    simpa using (hasDerivAt_id t).neg.exp
  have hl := lag_hasDerivAt hb.continuousOn 1 t (by norm_num) ht
  convert (he.const_mul c₀).sub hl using 1
  · rfl
  · dsimp only [pidStableState]
    ring

-- @paper-step thm:pid_two_rate_optimum/restored_stable_mode_decay
theorem pidStableState_decay (c₀ : ℝ) {b : ℝ → ℝ} {η : ℝ}
    (hη : η≤1) (hb : Integrable (expWeight η (causalize b))) {t : ℝ} (ht : 0≤t) :
    |pidStableState c₀ b t| ≤
      (|c₀|+(∫ s, |expWeight η (causalize b) s|))*Real.exp (-η*t) := by
  have hl := lag_weighted_decay (by norm_num : (0 : ℝ)<1) (by simpa using hη) hb ht
  have he : Real.exp (-t)≤Real.exp (-η*t) := Real.exp_le_exp.mpr (by nlinarith)
  have hm := mul_le_mul_of_nonneg_left he (abs_nonneg c₀)
  have ha := abs_sub_le (c₀*Real.exp (-t)) 0 (lag 1 b t)
  simp only [sub_zero,zero_sub,abs_neg,abs_mul,abs_of_pos (Real.exp_pos _)] at ha
  simp only [div_self one_ne_zero,one_mul] at hl
  unfold pidStableState
  nlinarith

-- @paper-step thm:pid_two_rate_optimum/all_three_state_decay_from_reduced_pair
theorem pidRestore_decay {ρ η Ca Cb : ℝ} (hρ : ρ ≠ 1) (hη : η≤1)
    (c₀ : ℝ) {a b : ℝ → ℝ} (hb : Integrable (expWeight η (causalize b)))
    (ha : ∀ t, 0≤t → |a t|≤Ca*Real.exp (-η*t))
    (hbb : ∀ t, 0≤t → |b t|≤Cb*Real.exp (-η*t)) :
    let Cc := |c₀|+∫ s, |expWeight η (causalize b) s|
    ∀ t, 0≤t →
      |(pidRestore ρ ![a t,b t,pidStableState c₀ b t]) 0|≤(Cb+Cc)*Real.exp (-η*t) ∧
      |(pidRestore ρ ![a t,b t,pidStableState c₀ b t]) 1|≤Cc*Real.exp (-η*t) ∧
      |(pidRestore ρ ![a t,b t,pidStableState c₀ b t]) 2|≤
        ((Ca+Cc)/|1-ρ|)*Real.exp (-η*t) := by
  dsimp only
  intro t ht
  have hc := pidStableState_decay c₀ hη hb ht
  have ha' := ha t ht
  have hb' := hbb t ht
  refine ⟨?_,hc,?_⟩
  · change |b t+pidStableState c₀ b t| ≤ _
    have hh := abs_add_le (b t) (pidStableState c₀ b t)
    nlinarith
  · change |(a t-pidStableState c₀ b t)/(1-ρ)| ≤ _
    rw [abs_div]
    have hd : 0 < |1-ρ| := abs_pos.mpr (sub_ne_zero.mpr hρ.symm)
    apply (div_le_iff₀ hd).mpr
    have hh := abs_sub_le (a t) 0 (pidStableState c₀ b t)
    simp only [sub_zero,zero_sub,abs_neg] at hh
    field_simp
    simp only [neg_mul] at hc ha' hb'
    nlinarith

-- @paper-step thm:pid_two_rate_optimum/stable_mode_uniqueness_from_actual_ODE
theorem pidStableState_unique {c b : ℝ → ℝ}
    (hc : ∀ T, 0≤T → AbsolutelyContinuousOnInterval c 0 T)
    (hode : ∀ᵐ t, 0<t → deriv c t = -c t-b t) {t : ℝ} (ht : 0≤t) :
    c t=pidStableState (c 0) b t := by
  have he : AbsolutelyContinuousOnInterval Real.exp 0 t := by
    apply ContDiffOn.absolutelyContinuousOnInterval
    fun_prop
  have hi := (hc t ht).integral_deriv_mul_eq_sub he
  have hi' : (∫ s in 0..t, deriv c s*Real.exp s+c s*deriv Real.exp s)=
      -(∫ s in 0..t, Real.exp s*b s) := by
    rw [← intervalIntegral.integral_neg]
    apply intervalIntegral.integral_congr_ae
    filter_upwards [hode] with s hs hst
    rw [uIoc_of_le ht] at hst
    rw [hs hst.1,Real.deriv_exp]
    ring
  rw [hi',Real.exp_zero,mul_one] at hi
  have hh := congrArg (fun u => Real.exp (-t)*u) hi
  have hcancel : Real.exp (-t)*Real.exp t=1 := by rw [← Real.exp_add]; simp
  unfold pidStableState lag
  simp only [div_one] at ⊢
  have heq : Real.exp (-t)*(c t*Real.exp t)=c t := by
    calc
      _ = (Real.exp (-t)*Real.exp t)*c t := by ring
      _ = c t := by rw [hcancel,one_mul]
  rw [mul_sub,heq] at hh
  linarith

-- @paper-step thm:pid_two_rate_optimum/actual_state_decay_from_reduced_bounds
theorem pid_actual_state_decay {y z ζ : ℝ → ℝ} {ρ η Ca Cb : ℝ}
    (hρ : ρ ≠ 1) (hη : η≤1)
    (hz : ∀ T, 0≤T → AbsolutelyContinuousOnInterval z 0 T)
    (hode : ∀ᵐ t, 0<t → deriv z t = -y t)
    (hb : Integrable (expWeight η (causalize (fun t => y t-z t))))
    (ha : ∀ t, 0≤t → |z t+(1-ρ)*ζ t|≤Ca*Real.exp (-η*t))
    (hbb : ∀ t, 0≤t → |y t-z t|≤Cb*Real.exp (-η*t)) :
    let Cc := |z 0|+∫ s, |expWeight η (causalize (fun t => y t-z t)) s|
    ∀ t, 0≤t → |y t|≤(Cb+Cc)*Real.exp (-η*t) ∧
      |z t|≤Cc*Real.exp (-η*t) ∧
      |ζ t|≤((Ca+Cc)/|1-ρ|)*Real.exp (-η*t) := by
  dsimp only
  intro t ht
  have he : z t=pidStableState (z 0) (fun s => y s-z s) t := by
    apply pidStableState_unique hz _ ht
    filter_upwards [hode] with s hs hst
    rw [hs hst]
    ring
  have hh := pidRestore_decay hρ hη (z 0) hb ha hbb t ht
  rw [← he] at hh
  have hr := pidRestore_reduce hρ ![y t,z t,ζ t]
  change pidRestore ρ ![z t+(1-ρ)*ζ t,y t-z t,z t]=![y t,z t,ζ t] at hr
  rw [hr] at hh
  exact hh

end MIACE
