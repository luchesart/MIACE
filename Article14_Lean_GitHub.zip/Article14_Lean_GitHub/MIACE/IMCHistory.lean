import MIACE.IMCPlant

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

structure IMCHistory where
  plantInitial : ℕ → ℝ
  modelInitial : ℕ → ℝ
  filterInitial : ℝ
  plantPast : ℝ → ℝ
  modelPast : ℝ → ℝ
  filterPast : ℝ → ℝ

noncomputable def filterFreeOutput (F : IMCFilter) (H : IMCHistory) (t : ℝ) : ℝ :=
  F.delayed*historyInput F.delay H.filterPast t+
    (F.residue*H.filterInitial*F.timeConstant)*lagKernel F.timeConstant t
noncomputable def imcFreeInput (N : ℕ) (σ : ℕ → ℝ) (δ ε : ℝ) (H : IMCHistory) (t : ℝ) : ℝ :=
  plantFreeOutput N σ H.modelInitial δ H.modelPast t-
    plantFreeOutput N σ H.plantInitial (δ+ε) H.plantPast t
noncomputable def imcHistoryForcing (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) (δ ε : ℝ)
    (H : IMCHistory) (t : ℝ) : ℝ :=
  filterAction F (imcFreeInput N σ δ ε H) t+filterFreeOutput F H t
noncomputable def imcFilterInput (N : ℕ) (σ : ℕ → ℝ) (δ ε : ℝ) (H : IMCHistory)
    (u : ℝ → ℝ) (t : ℝ) : ℝ :=
  plantHistoryOutput N σ H.modelInitial δ H.modelPast u t-
    plantHistoryOutput N σ H.plantInitial (δ+ε) H.plantPast u t
noncomputable def imcFeedback (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) (δ ε : ℝ)
    (H : IMCHistory) (u : ℝ → ℝ) (t : ℝ) : ℝ :=
  filterAction F (imcFilterInput N σ δ ε H u) t+filterFreeOutput F H t

-- @paper-step thm:complete_robust/filter_initial_history_causality
theorem filterFreeOutput_causal (F : IMCFilter) (H : IMCHistory) : Causal (filterFreeOutput F H) := by
  exact causal_linear (historyInput_causal _ _) (lagKernel_properties F.timeConstant_pos).2.2.2
    F.delayed (F.residue*H.filterInitial*F.timeConstant)

-- @paper-step thm:complete_robust/initial_model_error_causality
theorem imcFreeInput_causal (N : ℕ) (σ : ℕ → ℝ) {δ ε : ℝ}
    (hδ : 0≤δ) (hδε : 0≤δ+ε) (H : IMCHistory) : Causal (imcFreeInput N σ δ ε H) := by
  filter_upwards [plantHistoryOutput_causal N σ H.modelInitial hδ H.modelPast (fun _ => 0),
    plantHistoryOutput_causal N σ H.plantInitial hδε H.plantPast (fun _ => 0)] with t ht hs hn
  change _-_=0
  simp only [plantFreeOutput,ht hn,hs hn,sub_self]

-- @paper-step thm:complete_robust/full_initial_forcing_causality
theorem imcHistoryForcing_causal (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) {δ ε : ℝ}
    (hδ : 0≤δ) (hδε : 0≤δ+ε) (H : IMCHistory) : Causal (imcHistoryForcing N σ F δ ε H) := by
  filter_upwards [filterAction_causal F (imcFreeInput_causal N σ hδ hδε H),
    filterFreeOutput_causal F H] with t ht hs hn
  simp [imcHistoryForcing,ht hn,hs hn]

-- The explicit filter state is retained even when its output coefficient
-- is zero. In particular, no cancellation is used as an internal-stability assumption.
-- @paper-step thm:complete_attainment/physical_filter_initial_state_semantics
theorem filter_history_state_identity (F : IMCFilter) (H : IMCHistory)
    {q : ℝ → ℝ} (hqc : Causal q) :
    (fun t => filterAction F q t+filterFreeOutput F H t)=ᵐ[volume]
      (fun t => F.direct*q t+F.delayed*(historyInput F.delay H.filterPast t+shift F.delay q t)+
        F.residue*causalize (lagState F.timeConstant H.filterInitial q) t) := by
  have he := lagState_causal_formula F.timeConstant_pos H.filterInitial q
  have hc := convolution_congr (ContinuousLinearMap.lsmul ℝ ℝ)
    (EventuallyEq.rfl (f := lagKernel F.timeConstant)) (causalize_eq_ae hqc)
  filter_upwards [he] with t ht
  rw [ht,hc]
  unfold filterAction filterFreeOutput
  ring

-- @paper-step thm:complete_robust/initial_filter_history_uniform_gain
theorem filterFreeOutput_control (F : IMCFilter) (H : IMCHistory) {η M C : ℝ}
    (hη : 0≤η) (hM : 0≤M) (hK : WeightedControl η (lagKernel F.timeConstant) C)
    (hφ : ContinuousOn H.filterPast (Icc (-F.delay) 0)) (hφM : ∀ s∈Icc (-F.delay) 0, |H.filterPast s|≤M)
    (hz : |H.filterInitial|≤M) :
    WeightedControl η (filterFreeOutput F H)
      ((|F.delayed| *(F.delay+1)*Real.exp (η*F.delay)+|F.residue| *F.timeConstant*C)*M) := by
  have hh := weightedControl_add
    (weightedControl_smul (historyInput_control_on F.delay_nonneg hη hM hφ hφM) F.delayed)
    (weightedControl_smul hK (F.residue*H.filterInitial*F.timeConstant))
  apply weightedControl_mono hh
  rw [abs_mul,abs_mul,abs_of_pos F.timeConstant_pos]
  have hmul := mul_le_mul_of_nonneg_right hz
    (mul_nonneg (mul_nonneg (abs_nonneg F.residue) F.timeConstant_pos.le) hK.nonneg)
  nlinarith

-- @paper-step thm:complete_robust/full_feedback_loop_identity
theorem imcFeedback_loop_identity (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) {δ ε : ℝ}
    (hδ : 0≤δ) (hδε : 0≤δ+ε) (H : IMCHistory)
    (hσ : ∀ j≤N, 0<σ j) (hfirst : σ 0=1)
    (hfree : Integrable (imcFreeInput N σ δ ε H))
    {u : ℝ → ℝ} (hu : LocallyIntegrable u volume) (huc : Causal u) :
    imcFeedback N σ F δ ε H u=ᵐ[volume]
      (fun t => imcHistoryForcing N σ F δ ε H t+
        (imcLoopKernel F (serialRatios σ N) δ ε ⋆ u) t) := by
  let K := serialImpulse σ N
  let P := shift δ K
  let Pe := shift (δ+ε) K
  let D := fun t => Pe t-P t
  have hK := serialImpulse_properties σ N hσ
  have hP : Integrable P := shift_integrable δ hK.1
  have hPe : Integrable Pe := shift_integrable (δ+ε) hK.1
  have hPc : Causal P := causal_shift hK.2 hδ
  have hPec : Causal Pe := causal_shift hK.2 hδε
  have hD : Integrable D := hPe.sub hP
  have hDc : Causal D := by
    filter_upwards [hPec,hPc] with t ht hs hn
    change Pe t-P t=0
    rw [ht hn,hs hn,sub_self]
  have hDu := causalLocalOperator_local_integrable (convolution_local_operator hD hDc) hu huc
  have hDuc : Causal (D ⋆ u) := ae_of_all _ (convolution_causal hDc huc)
  have hqc : Causal (imcFreeInput N σ δ ε H) := imcFreeInput_causal N σ hδ hδε H
  have hq : imcFilterInput N σ δ ε H u=ᵐ[volume]
      (fun t => imcFreeInput N σ δ ε H t-(D ⋆ u) t) := by
    filter_upwards [plantHistoryOutput_split N σ H.modelInitial δ H.modelPast hu huc hσ,
      plantHistoryOutput_split N σ H.plantInitial (δ+ε) H.plantPast hu huc hσ,
      local_kernel_sub hPe hP hPec hPc hu huc] with t ht hs hd
    change _-_= _-_
    rw [ht,hs]
    change _= _-(D ⋆ u) t
    rw [hd]
    unfold imcFreeInput
    ring
  have hF := (filterAction_congr F hq).trans (local_filter_sub F hfree.locallyIntegrable hDu hqc hDuc)
  have hconv := local_filter_convolution F hD hDc hu huc
  have hDdef : D=delayMismatchKernel (serialRatios σ N) δ ε := by
    funext t
    simp only [D,Pe,P,K,delayMismatchKernel,serialImpulse_eq_cascade σ hfirst N]
  have hneg : (imcLoopKernel F (serialRatios σ N) δ ε ⋆ u)=
      (fun t => -(filterAction F D ⋆ u) t) := by
    rw [hDdef]
    have hk : imcLoopKernel F (serialRatios σ N) δ ε=
        (-1 : ℝ) • filterAction F (delayMismatchKernel (serialRatios σ N) δ ε) := by
      funext t; simp [imcLoopKernel]
    rw [hk,smul_convolution]
    ext t
    simp
  filter_upwards [hF,hconv] with t ht hs
  unfold imcFeedback imcHistoryForcing
  rw [ht,hs,hneg]
  ring

end MIACE
