import MIACE.PIDNecessaryStructure
import MIACE.Lemma6Completion

/-! Stage 19. The positive ideal PI law is the ordinary PID law with zero
derivative coefficient; the auxiliary filter then has no effect. Necessity
is established before setting r=1, using the actual Laplace integral. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

abbrev IdealPIResponse (x r δ : ℝ) (E V : ℝ → ℝ) :=
  FilteredPIDResponse x (x/r) 0 1 δ E V

noncomputable def delayedPIDenominator (x r δ p : ℝ) : ℝ :=
  p*(p+1)+x*(p+1/r)*Real.exp (-δ*p)

-- @paper-step thm:delayed_optimum/actual_PI_multiplied_error_identity
theorem idealPI_error_identity {x r δ : ℝ} {E V : ℝ → ℝ}
    (h : IdealPIResponse x r δ E V) {p : ℝ} (hp : 0<p) :
    delayedPIDenominator x r δ p*laplace E p=p+1 := by
  have he := generalPID_error_identity h (by norm_num : (0 : ℝ)<1) hp
  apply mul_left_cancel₀ (ne_of_gt (by linarith : 0<p+1))
  convert he using 1 <;> (try simp only [delayedPIDenominator,pidDenominator,pidNumerator]) <;> ring

-- @paper-step thm:delayed_optimum/continued_PI_identity_from_attainment
theorem attaining_PI_extended_identity {x r δ α : ℝ} {E V : ℝ → ℝ}
    (h : IdealPIResponse x r δ E V) (hα : 0<α) (hδ : 0≤δ)
    (hcost : miace α E V halfLine=(1+δ)*minimum α) :
    ∀ p, -1<p → delayedPIDenominator x r δ p*laplace E p=p+1 := by
  obtain ⟨hnE,hnV,_,_⟩ := attaining_firstOrder_signs h.plant h.error_continuous h.command_continuous hα hδ hcost
  have hbound := attaining_error_exp_bound h.plant h.error_continuous h.command_continuous hδ hnE hnV
  have hL := laplace_real_analytic h.error_continuous (Real.exp_nonneg δ) hbound
  apply analytic_identity_from_positive
  · intro p hp
    apply AnalyticAt.mul
    · unfold delayedPIDenominator; fun_prop
    · exact hL p hp
  · intro p _; fun_prop
  · intro p hp; exact idealPI_error_identity h hp

-- @paper-step thm:delayed_optimum/attainment_forces_PI_cancellation_and_integral_gain
theorem attaining_PI_cancellation {x r δ α : ℝ} {E V : ℝ → ℝ}
    (h : IdealPIResponse x r δ E V) (hx : 0<x) (hr : 0<r) (hα : 0<α) (hδ : 0≤δ)
    (hcost : miace α E V halfLine=(1+δ)*minimum α) :
    r=1 ∧ 1≤x ∧ x=(1+1/α)/(1+δ) := by
  obtain ⟨hnE,hnV,hmass,hm⟩ := attaining_firstOrder_signs h.plant h.error_continuous h.command_continuous hα hδ hcost
  have hbound := attaining_error_exp_bound h.plant h.error_continuous h.command_continuous hδ hnE hnV
  have he := attaining_PI_extended_identity h hα hδ hcost
  have hcan := laplace_boundary_cancellation h.error_continuous h.plant.error_integrable hbound hnE hm
    (D := delayedPIDenominator x r δ) (N := fun p => p+1)
    (by unfold delayedPIDenominator; fun_prop) (by fun_prop) (by norm_num) he
  have hr1 : r=1 := by
    have he' : x*(-1+1/r)*Real.exp δ=0 := by simpa [delayedPIDenominator] using hcan
    have hz : -1+1/r=0 := (mul_eq_zero.mp ((mul_eq_zero.mp he').resolve_right
      (Real.exp_ne_zero δ))).resolve_left (ne_of_gt hx)
    field_simp at hz
    linarith
  subst r
  have hE0 : E 0=1 := by
    rw [transfer_firstOrder_realization h.plant hδ h.error_continuous h.command_continuous 0 le_rfl]
    simp [delayedError,hδ]
  have hV0 := h.command 0 le_rfl
  simp only [pidTimeCommand,hE0,intervalIntegral.integral_same,mul_zero,zero_div,zero_mul,
    add_zero,mul_one] at hV0
  have hx1 : 1≤x := by linarith [hnV 0 le_rfl]
  have hmass' := he 0 (by norm_num)
  simp only [delayedPIDenominator,mul_zero,zero_add,one_div_one,Real.exp_zero,mul_one,
    laplace,neg_zero,zero_mul,one_mul] at hmass'
  rw [hmass] at hmass'
  refine ⟨rfl,hx1,?_⟩
  have hd : 1+δ≠0 := ne_of_gt (by linarith)
  have ha : 1+α≠0 := ne_of_gt (by linarith)
  field_simp [ne_of_gt hα,hd,ha] at hmass' ⊢
  nlinarith

-- @paper-step thm:delayed_optimum/causal_scalar_response_from_unreduced_PI_law
theorem cancelled_PI_scalar_response {x δ : ℝ} (hδ : 0≤δ) {E V : ℝ → ℝ}
    (h : IdealPIResponse x 1 δ E V) :
    ∃ F : ℝ → ℝ, ScalarDelayResponse x δ F ∧ ∀ t, 0≤t → F t=E t := by
  have htrans (p : ℝ) (hp : 0<p) : (p+x*Real.exp (-δ*p))*laplace E p=1 := by
    have he := idealPI_error_identity h hp
    apply mul_left_cancel₀ (ne_of_gt (by linarith : 0<p+1))
    convert he using 1 <;> (try simp only [delayedPIDenominator,one_div_one]) <;> ring
  have heq := scalarDelay_integral_equation hδ h.error_continuous h.plant.error_integrable htrans
  let F := fun t => 1-x*(∫ s in (0 : ℝ)..t, shift δ (causalize E) s)
  have hloc := locally_integrable_interval (scalarDelay_shift_local h.error_continuous δ)
  have hF : Continuous F := continuous_const.sub
    ((intervalIntegral.continuous_primitive hloc 0).const_mul x)
  have he : ∀ t, 0≤t → F t=E t := fun t ht => (heq t ht).symm
  have hcausal : causalize F=causalize E := by
    funext t
    by_cases ht : 0≤t
    · simp [causalize,ht,he t ht]
    · simp [causalize,ht]
  refine ⟨F,⟨hF,?_,by simp [F],?_⟩,he⟩
  · intro a b
    have hc : AbsolutelyContinuousOnInterval (fun _ : ℝ => (1 : ℝ)) a b := by
      apply ContDiffOn.absolutelyContinuousOnInterval; fun_prop
    exact hc.sub ((intervalPrimitive_ac hloc 0 a b).const_mul x)
  · intro t _; rw [hcausal]

-- @paper-step thm:delayed_optimum/exact_nonoscillation_threshold_is_necessary_for_attainment
theorem attaining_PI_necessary {x r δ α : ℝ} {E V : ℝ → ℝ}
    (h : IdealPIResponse x r δ E V) (hx : 0<x) (hr : 0<r) (hα : 0<α) (hδ : 0≤δ)
    (hcost : miace α E V halfLine=(1+δ)*minimum α) :
    r=1 ∧ 1≤x ∧ x*δ≤Real.exp (-1) ∧ x=(1+1/α)/(1+δ) := by
  obtain ⟨rfl,hx1,hgain⟩ := attaining_PI_cancellation h hx hr hα hδ hcost
  obtain ⟨F,hF,he⟩ := cancelled_PI_scalar_response hδ h
  have hn := (attaining_firstOrder_signs h.plant h.error_continuous h.command_continuous hα hδ hcost).1
  have hb := scalarDelay_nonnegative_necessary hx hδ hF (fun t ht => by rw [he t ht]; exact hn t ht)
  exact ⟨rfl,hx1,hb,hgain⟩

end MIACE
