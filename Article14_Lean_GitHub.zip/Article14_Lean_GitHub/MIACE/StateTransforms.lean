import MIACE.LaplaceUniqueness

/-! Етап 10: преобразувания на действителните интегратор и филтър.
    Интегруемостта на всяко претеглено състояние се доказва преди
    използването на линейността на интеграла. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

noncomputable def pidTimeCommand (pc i dc ρ : ℝ) (E : ℝ → ℝ) (t : ℝ) : ℝ :=
  pc*E t+i*(∫ s in 0..t, E s)+(dc/ρ)*(E t-lag ρ E t)

-- @paper-step thm:pid_two_rate_optimum/ordinary_lag_continuity
theorem lag_continuous {f : ℝ → ℝ} (hf : Continuous f) (ρ : ℝ) : Continuous (lag ρ f) := by
  have hi : ∀ a b : ℝ, IntervalIntegrable (fun s => Real.exp (s/ρ)*f s) volume a b :=
    fun a b => ((by fun_prop : Continuous (fun s : ℝ => Real.exp (s/ρ))).mul hf).intervalIntegrable a b
  exact (by fun_prop : Continuous (fun t : ℝ => Real.exp (-t/ρ)/ρ)).mul
    (intervalIntegral.continuous_primitive hi 0)

-- @paper-step thm:pid_two_rate_optimum/lag_halfline_convolution_identity
theorem lag_convolution_halfLine {ρ : ℝ} (hρ : 0<ρ) (f : ℝ → ℝ) :
    (lagKernel ρ ⋆ causalize f)=ᵐ[halfLine] lag ρ f := by
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  exact lag_as_causal_convolution ρ hρ f (show 0<t from ht).le

-- @paper-step thm:pid_two_rate_optimum/ordinary_lag_integrability
theorem lag_integrable {f : ℝ → ℝ} (hf : Integrable f halfLine) {ρ : ℝ} (hρ : 0<ρ) :
    Integrable (lag ρ f) halfLine := by
  have hh := (lagKernel_properties hρ).1.integrable_convolution
    (ContinuousLinearMap.lsmul ℝ ℝ) (causalize_integrable hf)
  exact (hh.mono_measure Measure.restrict_le_self).congr (lag_convolution_halfLine hρ f)

-- @paper-step thm:pid_two_rate_optimum/ordinary_lag_laplace
theorem lag_laplace {f : ℝ → ℝ} (hf : Integrable f halfLine) {ρ p : ℝ}
    (hρ : 0<ρ) (hp : 0≤p) : laplace (lag ρ f) p=laplace f p/(1+ρ*p) := by
  rw [← laplace_congr_halfLine (lag_convolution_halfLine hρ f),
    causal_convolution_laplace (lagKernel_properties hρ).1 (causalize_integrable hf)
      (lagKernel_properties hρ).2.2.2 (causalize_causal f) hp,
    lagKernel_laplace hρ hp,
    laplace_congr_halfLine (representative_halfLine_ae (EventuallyEq.rfl :
      causalize f=ᵐ[volume] causalize f))]
  ring

-- @paper-step thm:pid_two_rate_optimum/damped_primitive_convolution
theorem damped_primitive_convolution (f : ℝ → ℝ) (p : ℝ) {t : ℝ} (ht : 0≤t) :
    (causalize (fun u => Real.exp (-p*u)) ⋆ causalize (fun u => Real.exp (-p*u)*f u)) t=
      Real.exp (-p*t)*(∫ s in 0..t, f s) := by
  rw [causal_convolution_interval (causalize_causal _) (causalize_causal _) ht,
    ← intervalIntegral.integral_const_mul]
  apply intervalIntegral.integral_congr
  intro s hs
  rw [uIcc_of_le ht] at hs
  have hs0 : s∈Ici (0 : ℝ) := hs.1
  have hts : t-s∈Ici (0 : ℝ) := sub_nonneg.mpr hs.2
  dsimp only
  rw [causalize,indicator_of_mem hts,causalize,indicator_of_mem hs0,← mul_assoc,← Real.exp_add]
  congr 2; ring

-- @paper-step thm:pid_two_rate_optimum/integrator_integrability_and_laplace
theorem primitive_laplace {f : ℝ → ℝ} (hf : Integrable f halfLine) {p : ℝ} (hp : 0<p) :
    Integrable (fun t => Real.exp (-p*t)*(∫ s in 0..t, f s)) halfLine ∧
      laplace (fun t => ∫ s in 0..t, f s) p=laplace f p/p := by
  let k := causalize (fun t => Real.exp (-p*t))
  let g := causalize (fun t => Real.exp (-p*t)*f t)
  have hk : Integrable k := causal_exp_integrable hp
  have hg : Integrable g := causalize_integrable (laplace_integrable hf hp.le)
  have hc : Causal (k ⋆ g) := ae_of_all volume
    (convolution_causal (causalize_causal _) (causalize_causal _))
  have he : (k ⋆ g)=ᵐ[halfLine] (fun t => Real.exp (-p*t)*(∫ s in 0..t, f s)) := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact damped_primitive_convolution f p (show 0<t from ht).le
  refine ⟨((hk.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hg).mono_measure
    Measure.restrict_le_self).congr he,?_⟩
  change (∫ t, Real.exp (-p*t)*(∫ s in 0..t, f s) ∂halfLine)=_
  rw [← integral_congr_ae he,← causal_integral_halfLine hc,
    integral_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hk hg]
  change (∫ t, k t)*(∫ t, g t)=_
  rw [show (∫ t, k t)=1/p from causal_exp_integral hp,
    show (∫ t, g t)=laplace f p from causalize_integral _]
  ring

-- @paper-step thm:pid_two_rate_optimum/computed_PID_command_continuity
theorem pidTimeCommand_continuous {f : ℝ → ℝ} (hf : Continuous f) (pc i dc ρ : ℝ) :
    Continuous (pidTimeCommand pc i dc ρ f) := by
  exact ((hf.const_mul pc).add
    ((intervalIntegral.continuous_primitive (fun a b => hf.intervalIntegrable a b) 0).const_mul i)).add
    ((hf.sub (lag_continuous hf ρ)).const_mul (dc/ρ))

-- @paper-step thm:pid_two_rate_optimum/computed_PID_command_laplace
theorem pidTimeCommand_transform {f : ℝ → ℝ} (hf : Integrable f halfLine)
    (pc i dc : ℝ) {ρ p : ℝ} (hρ : 0<ρ) (hp : 0<p) :
    Integrable (fun t => Real.exp (-p*t)*pidTimeCommand pc i dc ρ f t) halfLine ∧
    laplace (pidTimeCommand pc i dc ρ f) p=
      (pc+i/p+dc*p/(1+ρ*p))*laplace f p := by
  have he := laplace_integrable hf hp.le
  have hz := primitive_laplace hf hp
  have hl := laplace_integrable (lag_integrable hf hρ) hp.le
  have heq : (fun t => Real.exp (-p*t)*pidTimeCommand pc i dc ρ f t)=
      (fun t => (pc*(Real.exp (-p*t)*f t)+i*(Real.exp (-p*t)*(∫ s in 0..t, f s)))+
        (dc/ρ)*((Real.exp (-p*t)*f t)-(Real.exp (-p*t)*lag ρ f t))) := by
    funext t; unfold pidTimeCommand; ring
  have hi : Integrable (fun t => Real.exp (-p*t)*pidTimeCommand pc i dc ρ f t) halfLine := by
    rw [heq]
    exact ((he.const_mul pc).add (hz.1.const_mul i)).add ((he.sub hl).const_mul (dc/ρ))
  refine ⟨hi,?_⟩
  have ha := integral_add ((he.const_mul pc).add (hz.1.const_mul i))
      ((he.sub hl).const_mul (dc/ρ))
  simp only [Pi.add_apply,Pi.sub_apply] at ha
  rw [laplace,heq,ha,integral_add (he.const_mul pc) (hz.1.const_mul i),
    integral_const_mul,integral_const_mul,integral_const_mul,integral_sub he hl]
  change pc*laplace f p+i*laplace (fun t => ∫ s in 0..t, f s) p+
    (dc/ρ)*(laplace f p-laplace (lag ρ f) p)=_
  rw [hz.2,lag_laplace hf hρ hp.le]
  field_simp [ne_of_gt hρ,ne_of_gt hp,ne_of_gt (by positivity : 0<1+ρ*p)]
  <;> ring

end MIACE
