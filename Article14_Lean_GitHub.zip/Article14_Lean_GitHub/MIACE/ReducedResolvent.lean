import MIACE.WeightedRenewal
import MIACE.LaplaceLinear

/-! Етап 12: съществуване на редуцираното решение за произволен каузален
    вход H. Началните a₀,b₀ се включват в самия вход на резолвентата.
    Нито трансферните уравнения, нито оценките на решението се предполагат. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

structure ReducedTransform (i ρ ell δ a₀ b₀ : ℝ) (H a b : ℝ → ℝ) : Prop where
  integrable_a : Integrable a
  integrable_b : Integrable b
  causal_a : Causal a
  causal_b : Causal b
  equation_a : ∀ p, 0<p → p*laplace a p=a₀-(laplace a p+laplace b p)/ρ
  equation_b : ∀ p, 0<p → p*laplace b p=b₀+laplace H p-
    (i/ρ)*Real.exp (-δ*p)*((ell-ρ)*laplace a p+ell*laplace b p)

-- @paper-step thm:pid_two_rate_optimum/forced_reduced_resolvent_construction
theorem reduced_resolvent_exists {i ρ ell l m δ η CK CG CL : ℝ}
    (h : TwoRateData i ρ ell l m δ) (hη : 0≤η)
    (hK : WeightedControl η (twoRateK (twoRateA ρ l m) l m δ) CK)
    (hqw : absArea (expWeight η (twoRateK (twoRateA ρ l m) l m δ)) volume<1)
    (hG : WeightedControl η (causalize (twoRateG (twoRateA ρ l m) l m)) CG)
    (hL : WeightedControl η (lagKernel ρ) CL) :
    ∃ D : ℝ, 0<D ∧ ∀ (H : ℝ → ℝ) (a₀ b₀ M : ℝ), Causal H →
      WeightedControl η H M → |a₀|≤M → |b₀|≤M →
      ∃ a b : ℝ → ℝ, ReducedTransform i ρ ell δ a₀ b₀ H a b ∧
        WeightedControl η a (D*M) ∧ WeightedControl η b (D*M) := by
  let K := twoRateK (twoRateA ρ l m) l m δ
  let G := causalize (twoRateG (twoRateA ρ l m) l m)
  let L := lagKernel ρ
  let q := absArea (expWeight η K) volume
  let R := (1+CK)/(1-q)
  let CF := CG+|i*(ρ-ell)| *Real.exp (η*δ)*(CL*CG)+CG
  let CB := R*CF
  let CA := |ρ| *CL+CL*CB
  have hCK := hK.nonneg
  have hCG := hG.nonneg
  have hCL := hL.nonneg
  have hden : 0<1-q := sub_pos.mpr hqw
  have hR : 0≤R := by dsimp [R]; positivity
  have hCF : 0≤CF := by dsimp [CF]; positivity
  have hCB : 0≤CB := mul_nonneg hR hCF
  have hCA : 0≤CA := by dsimp [CA]; positivity
  refine ⟨1+CA+CB,by linarith,?_⟩
  intro H a₀ b₀ M hHc hH ha₀ hb₀
  have hM := hH.nonneg
  have hGc : Causal G := causalize_causal _
  have hLc : Causal L := (lagKernel_properties h.filter_pos).2.2.2
  have hGi : Integrable G := weightedControl_unweighted hG hGc hη
  have hLi : Integrable L := (lagKernel_properties h.filter_pos).1
  have hHi : Integrable H := weightedControl_unweighted hH hHc hη
  let J := L ⋆ G
  have hJ := weightedControl_convolution hL hG
  have hJc : Causal J := ae_of_all _ (convolution_causal hLc hGc)
  have hJi : Integrable J := hLi.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hGi
  let f := fun t => (b₀*G t+(i*(ρ-ell)*a₀)*shift δ J t)+(G ⋆ H) t
  have hfc : Causal f := by
    have h₁ := causal_linear hGc (causal_shift hJc h.delay_nonneg) b₀ (i*(ρ-ell)*a₀)
    have h₂ : Causal (G ⋆ H) := ae_of_all _ (convolution_causal hGc hHc)
    simpa only [one_mul] using causal_linear h₁ h₂ 1 1
  have hfw0 := weightedControl_add
    (weightedControl_add (weightedControl_smul hG b₀)
      (weightedControl_smul (weightedControl_shift hJ δ) (i*(ρ-ell)*a₀)))
    (weightedControl_convolution hG hH)
  have hfw : WeightedControl η f (CF*M) := by
    apply weightedControl_mono hfw0
    rw [abs_mul]
    dsimp [CF]
    have h₁ := mul_le_mul_of_nonneg_right hb₀ hCG
    have h₂ := mul_le_mul_of_nonneg_left ha₀
      (show 0≤|i*(ρ-ell)| *Real.exp (η*δ)*(CL*CG) by positivity)
    nlinarith
  let hKi := twoRateK_integrable (twoRateA ρ l m) l m δ
  have hKc : Causal K := twoRateK_causal _ _ _ _
  have hq : absArea K volume<1 := (twoRate_signed_kernel h).1
  let hfi := weightedControl_unweighted hfw hfc hη
  let b : RealL1 := (∑' n : ℕ, (convOp hKi)^n) (hfi.toL1 f)
  obtain ⟨hbc,hbe,hbw⟩ := weightedControl_renewal hη hKi hKc hq hK hqw hfw hfc
  have hbw' : WeightedControl η b (CB*M) := by
    convert hbw using 1 <;> dsimp [CB,R,q] <;> ring
  have hbi : Integrable (b : ℝ → ℝ) := L1.integrable_coeFn b
  let a := fun t => (ρ*a₀)*L t-(L ⋆ (b : ℝ → ℝ)) t
  have hac : Causal a := by
    have hc : Causal (L ⋆ (b : ℝ → ℝ)) := ae_of_all _ (convolution_causal hLc hbc)
    simpa only [a,L,neg_one_mul,sub_eq_add_neg] using causal_linear hLc hc (ρ*a₀) (-1)
  have haw0 := weightedControl_add (weightedControl_smul hL (ρ*a₀))
    (weightedControl_smul (weightedControl_convolution hL hbw') (-1))
  have haw : WeightedControl η a (CA*M) := by
    apply weightedControl_mono (by simpa only [a,L,neg_one_mul,sub_eq_add_neg] using haw0)
    simp only [abs_neg,abs_one,one_mul,abs_mul]
    dsimp [CA]
    have hh := mul_le_mul_of_nonneg_left ha₀ (mul_nonneg (abs_nonneg ρ) hCL)
    nlinarith
  have hai : Integrable a := weightedControl_unweighted haw hac hη
  have hAlap (p : ℝ) (hp : 0≤p) :
      laplace a p=(ρ*a₀-laplace b p)/(1+ρ*p) := by
    have he := laplace_linear hLi
      (hLi.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hbi) (ρ*a₀) (-1) hp
    simp only [neg_one_mul,← sub_eq_add_neg] at he
    change laplace a p=_ at he
    rw [causal_convolution_laplace hLi hbi hLc hbc hp,lagKernel_laplace h.filter_pos hp] at he
    rw [he]
    ring
  have hBchar (p : ℝ) (hp : 0≤p) :
      (p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p))*laplace b p=
      (1+ρ*p)*(b₀+laplace H p)+i*(ρ-ell)*a₀*Real.exp (-δ*p) := by
    have hl : 0<l := by linarith [h.lower_rate]
    have hm : 0<m := by linarith [h.lower_rate,h.ordered_rates]
    have hFhat : laplace f p=
        b₀*laplace G p+(i*(ρ-ell)*a₀)*
          (Real.exp (-δ*p)*(laplace L p*laplace G p))+laplace G p*laplace H p := by
      have h₁ := laplace_linear ((hGi.const_mul b₀).add
        ((shift_integrable δ hJi).const_mul (i*(ρ-ell)*a₀)))
        (hGi.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hHi) 1 1 hp
      simp only [one_mul,Pi.add_apply] at h₁
      change laplace f p=_ at h₁
      rw [h₁]
      change laplace (fun t => b₀*G t+(i*(ρ-ell)*a₀)*shift δ J t) p+laplace (G ⋆ H) p=_
      rw [laplace_linear hGi (shift_integrable δ hJi) b₀ (i*(ρ-ell)*a₀) hp,
        laplace_shift hJc h.delay_nonneg p,
        causal_convolution_laplace hLi hGi hLc hGc hp,
        causal_convolution_laplace hGi hHi hGc hHc hp]
    have hren := signed_renewal_function_laplace hKi hKc hq hfi hfc hp
    change (1-laplace K p)*laplace b p=laplace f p at hren
    calc
      _ = (ρ*(p+l)*(p+m))*((1-laplace K p)*laplace b p) := by
        rw [twoRate_characteristic_factor h hp]; ring
      _ = (ρ*(p+l)*(p+m))*laplace f p := by rw [hren]
      _ = _ := by
        rw [hFhat,show laplace G p=(1+ρ*p)/(ρ*(p+l)*(p+m)) from
          twoRateG_rational_laplace h.filter_pos hl hm h.ordered_rates hp,
          show laplace L p=1/(1+ρ*p) from lagKernel_laplace h.filter_pos hp]
        have hρ0 := ne_of_gt h.filter_pos
        have hlp : p+l≠0 := ne_of_gt (by linarith)
        have hmp : p+m≠0 := ne_of_gt (by linarith)
        have hfp : 1+ρ*p≠0 := ne_of_gt (by have hh:=h.filter_pos; positivity)
        field_simp
        <;> ring
  refine ⟨a,b,⟨hai,hbi,hac,hbc,?_,?_⟩,
    weightedControl_mono haw (by nlinarith),weightedControl_mono hbw' (by nlinarith)⟩
  · intro p hp
    have hρ0 := ne_of_gt h.filter_pos
    have hfp : 1+ρ*p≠0 := ne_of_gt (by have hh:=h.filter_pos; positivity)
    have ha := (eq_div_iff hfp).mp (hAlap p hp.le)
    field_simp [hρ0]
    nlinarith [ha]
  · intro p hp
    have hρ0 := ne_of_gt h.filter_pos
    have hfp : 1+ρ*p≠0 := ne_of_gt (by have hh:=h.filter_pos; positivity)
    have ha := (eq_div_iff hfp).mp (hAlap p hp.le)
    have hh := hBchar p hp.le
    field_simp [hρ0]
    apply (mul_left_cancel₀ hfp)
    linear_combination (norm := skip) ρ*hh + i*Real.exp (-δ*p)*(ell-ρ)*ha
    simp only [neg_mul,mul_comm δ p]
    ring

end MIACE
