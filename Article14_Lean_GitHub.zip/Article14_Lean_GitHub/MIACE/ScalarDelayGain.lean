import MIACE.ScalarDelayDecay

namespace MIACE
open MeasureTheory Set Filter
open scoped Topology

-- @paper-step lem:delayed_cancellation/history_windows_are_actual_history_integrals
theorem delayWindows_integral {w : ℝ → ℝ} (hw : Continuous w) (h t s : ℝ) :
    delayCosWindow h w t s=(∫ r in s..h, Real.cos r*w (t-h+r)) ∧
    delaySinWindow h w t s=(∫ r in s..h, Real.sin r*w (t-h+r)) := by
  have hc : Continuous (fun r => Real.cos r*w (t-h+r)) := by fun_prop
  have hs : Continuous (fun r => Real.sin r*w (t-h+r)) := by fun_prop
  have hp := intervalIntegral.integral_eq_sub_of_hasDerivAt (f' := fun r => -(Real.cos r*w (t-h+r)))
    (fun r _ => by simpa only [neg_mul] using (delayWindows_space_deriv hw h t r).1) (hc.neg.intervalIntegrable s h)
  have hq := intervalIntegral.integral_eq_sub_of_hasDerivAt (f' := fun r => -(Real.sin r*w (t-h+r)))
    (fun r _ => by simpa only [neg_mul] using (delayWindows_space_deriv hw h t r).2) (hs.neg.intervalIntegrable s h)
  rw [intervalIntegral.integral_neg,(delayWindows_terminal h t w).1] at hp
  rw [intervalIntegral.integral_neg,(delayWindows_terminal h t w).2] at hq
  exact ⟨by linarith,by linarith⟩

-- @paper-step lem:delayed_cancellation/history_window_uniform_bounds
theorem delayWindows_initial_bound {h M : ℝ} (h0 : 0≤h) (hM : 0≤M)
    {w : ℝ → ℝ} (hw : Continuous w) (hb : ∀ t∈Icc (-h) 0, |w t|≤M)
    {s : ℝ} (hs : s∈Icc 0 h) :
    |delayCosWindow h w 0 s|≤h*M ∧ |delaySinWindow h w 0 s|≤h*M := by
  rw [(delayWindows_integral hw h 0 s).1,(delayWindows_integral hw h 0 s).2]
  have hbound (c : ℝ → ℝ) (hc : ∀ r, |c r|≤1) :
      |∫ r in s..h, c r*w (0-h+r)|≤h*M := by
    have he := intervalIntegral.norm_integral_le_of_norm_le_const (C := M)
      (a := s) (b := h) (f := fun r => c r*w (0-h+r)) (by
        intro r hr
        rw [uIoc_of_le hs.2] at hr
        rw [Real.norm_eq_abs,abs_mul]
        have hw' := hb (0-h+r) ⟨by linarith [hs.1,hr.1],by linarith [hr.2]⟩
        calc
          |c r| * |w (0-h+r)|≤1*M := mul_le_mul (hc r) hw' (abs_nonneg _) (by norm_num)
          _ = M := one_mul M)
    rw [Real.norm_eq_abs,abs_of_nonneg (sub_nonneg.mpr hs.2)] at he
    nlinarith [mul_nonneg hs.1 hM]
  exact ⟨hbound _ Real.abs_cos_le_one,hbound _ Real.abs_sin_le_one⟩

noncomputable def scalarDelayHistoryGain (h : ℝ) : ℝ :=
  ((1+Real.sin h)/Real.cos h+1)*(1+h)^2+h*(h/Real.cos h)^2

-- @paper-step lem:delayed_cancellation/nonnegative_uniform_history_gain
theorem scalarDelayHistoryGain_nonneg {h : ℝ} (h0 : 0≤h) (hh : h<Real.pi/2) :
    0≤scalarDelayHistoryGain h := by
  have hc : 0<Real.cos h := delay_cos_pos hh ⟨h0,le_rfl⟩
  have hs : 0≤Real.sin h := Real.sin_nonneg_of_nonneg_of_le_pi h0 (by linarith [Real.pi_pos])
  unfold scalarDelayHistoryGain
  positivity

-- @paper-step lem:delayed_cancellation/finite_history_square_energy_bound
theorem history_square_bound {h M : ℝ} (h0 : 0≤h) (hM : 0≤M)
    {w : ℝ → ℝ} (hw : Continuous w) (hb : ∀ t∈Icc (-h) 0, |w t|≤M) :
    (∫ t in -h..(0 : ℝ), (w t)^2)≤h*M^2 := by
  have hi := intervalIntegral.integral_mono_on (μ := volume) (by linarith : -h≤0)
    ((hw.pow 2).intervalIntegrable (-h) 0) (g := fun _ => M^2) intervalIntegrable_const
    (fun t ht => by
      have ha := hb t ht
      have hm := mul_nonneg (sub_nonneg.mpr ha) (add_nonneg (abs_nonneg (w t)) hM)
      simpa only [Pi.pow_apply] using (show (w t)^2≤M^2 by nlinarith [sq_abs (w t)]))
  simpa using hi

-- @paper-step lem:delayed_cancellation/history_energy_continuous_quadratic_bound
theorem scalarDelayLyapunov_initial_bound {h M : ℝ} (h0 : 0≤h) (hh : h<Real.pi/2)
    (hM : 0≤M) {w : ℝ → ℝ} (hw : Continuous w)
    (hb : ∀ t∈Icc (-h) 0, |w t|≤M) :
    scalarDelayLyapunov h w 0≤scalarDelayHistoryGain h*M^2 := by
  let A := (1+Real.sin h)/(2*Real.cos h)
  let C := w 0-delayCosWindow h w 0 0
  let S := -delaySinWindow h w 0 0
  have hc : 0<Real.cos h := delay_cos_pos hh ⟨h0,le_rfl⟩
  have hs : 0≤Real.sin h := Real.sin_nonneg_of_nonneg_of_le_pi h0 (by linarith [Real.pi_pos])
  have hA : 0≤A := by dsimp [A]; positivity
  obtain ⟨hP,hQ⟩ := delayWindows_initial_bound h0 hM hw hb (show (0 : ℝ)∈Icc 0 h from ⟨le_rfl,h0⟩)
  have hw0 := hb 0 ⟨by linarith,le_rfl⟩
  have hC : |C|≤(1+h)*M := by
    dsimp [C]
    calc
      |w 0-delayCosWindow h w 0 0|≤|w 0|+|delayCosWindow h w 0 0| := abs_sub _ _
      _ ≤ M+h*M := add_le_add hw0 hP
      _ = (1+h)*M := by ring
  have hS : |S|≤(1+h)*M := by dsimp [S]; rw [abs_neg]; nlinarith
  have hCsq : C^2≤((1+h)*M)^2 := by
    have he := mul_nonneg (sub_nonneg.mpr hC) (add_nonneg (abs_nonneg C) (show 0≤(1+h)*M by positivity))
    nlinarith [sq_abs C]
  have hSsq : S^2≤((1+h)*M)^2 := by
    have he := mul_nonneg (sub_nonneg.mpr hS) (add_nonneg (abs_nonneg S) (show 0≤(1+h)*M by positivity))
    nlinarith [sq_abs S]
  have hI : delayWindowEnergy h w 0≤h*(h*M/Real.cos h)^2 := by
    have hden : ∀ s∈Icc 0 h, Real.cos s≠0 := fun s hs => ne_of_gt (delay_cos_pos hh hs)
    have hcont : ContinuousOn (fun s => (delayCosWindow h w 0 s/Real.cos s)^2) (Icc 0 h) :=
      ((continuous_iff_continuousAt.mpr (fun s =>
        (delayWindows_space_deriv hw h 0 s).1.continuousAt)).continuousOn.div
        Real.continuous_cos.continuousOn hden).pow 2
    have hi := intervalIntegral.integral_mono_on h0 (hcont.intervalIntegrable_of_Icc h0)
      (intervalIntegrable_const : IntervalIntegrable (fun _ : ℝ => (h*M/Real.cos h)^2) volume 0 h)
      (fun s hs => by
        have hp := (delayWindows_initial_bound h0 hM hw hb hs).1
        have hcs := delay_cos_pos hh hs
        have hcmp := Real.cos_le_cos_of_nonneg_of_le_pi hs.1 (by linarith [Real.pi_pos]) hs.2
        have hq : |delayCosWindow h w 0 s/Real.cos s|≤h*M/Real.cos h := by
          rw [abs_div,abs_of_pos hcs]
          exact (div_le_div_of_nonneg_right hp hcs.le).trans
            (div_le_div_of_nonneg_left (mul_nonneg h0 hM) hc hcmp)
        nlinarith [sq_abs (delayCosWindow h w 0 s/Real.cos s),abs_nonneg (delayCosWindow h w 0 s/Real.cos s),
          div_nonneg (mul_nonneg h0 hM) hc.le,
          mul_nonneg (sub_nonneg.mpr hq) (add_nonneg (abs_nonneg (delayCosWindow h w 0 s/Real.cos s))
            (div_nonneg (mul_nonneg h0 hM) hc.le))])
    simpa [delayWindowEnergy] using hi
  have hbase : A*(C^2+S^2)-C*S≤(2*A+1)*((1+h)*M)^2 := by
    nlinarith [sq_nonneg (C+S),mul_nonneg hA (sub_nonneg.mpr hCsq),
      mul_nonneg hA (sub_nonneg.mpr hSsq)]
  have he : (2*A+1)*((1+h)*M)^2+h*(h*M/Real.cos h)^2=scalarDelayHistoryGain h*M^2 := by
    dsimp [A,scalarDelayHistoryGain]; ring
  change A*(C^2+S^2)-C*S+delayWindowEnergy h w 0≤_
  linarith

end MIACE
