import MIACE.CascadeOutput

/-! The signal and global-cost conclusions of Theorem 17 for the article's
rational coefficients. This is not yet an all-history internal-stability
theorem for the unreduced rational realization. -/
namespace MIACE
open MeasureTheory Filter Set Polynomial
open scoped Topology

noncomputable def rationalCascadeTimes (r : ℕ → ℝ) : ℕ → ℝ
  | 0 => 1
  | j+1 => 1/r j

noncomputable def rationalCascadeError (r : ℕ → ℝ) (n : ℕ) (δ : ℝ)
    (v : ℝ → ℝ) : ℝ → ℝ :=
  delayedError δ (fun t => 1-ordinaryCascade (rationalCascadeTimes r)
    (fun s => 1+v s) (n+2) t)

-- @paper-step thm:n_construction/physical_cascade_positive_time_constants
theorem rationalCascadeTimes_pos (r : ℕ → ℝ) (n : ℕ) (hr : ∀ j≤n, 0<r j) :
    ∀ j≤n+1, 0<rationalCascadeTimes r j := by
  intro j hj
  cases j with
  | zero => norm_num [rationalCascadeTimes]
  | succ j => exact one_div_pos.mpr (hr j (by omega))

-- @paper-step thm:n_construction/physical_cascade_mean_matches_article
theorem rationalCascadeMean (r : ℕ → ℝ) (n : ℕ) :
    cascadeMean (rationalCascadeTimes r) (n+2)=1+∑ j∈Finset.range (n+1), 1/r j := by
  induction n with
  | zero => simp [cascadeMean,Finset.sum_range_succ,rationalCascadeTimes]
  | succ n ih =>
    have he : cascadeMean (rationalCascadeTimes r) (n+1+2)=
        cascadeMean (rationalCascadeTimes r) (n+2)+1/r (n+1) := by
      simp [cascadeMean,Finset.sum_range_succ,rationalCascadeTimes]
    rw [he,ih]
    simp only [Finset.sum_range_succ]
    ring

-- @paper-step thm:n_construction/physical_cascade_transfer_matches_article
theorem rationalCascadeTransfer (r : ℕ → ℝ) (n : ℕ) (p : ℝ) :
    cascadeTransfer (rationalCascadeTimes r) (n+2) p=
      1/((1+p)*(remainderB r n).eval p) := by
  induction n with
  | zero => simp [cascadeTransfer,rationalCascadeTimes,remainderB]; ring
  | succ n ih =>
    change cascadeTransfer (rationalCascadeTimes r) (n+2) p /
      (1+(1/r (n+1))*p)=_
    rw [ih,remainderB,eval_mul,eval_add,eval_mul,eval_C,eval_X,eval_one]
    rw [div_div]
    congr 1
    ring

-- @paper-step thm:n_construction/positive_real_axis_cascade_denominator
theorem remainderB_eval_pos (r : ℕ → ℝ) (n : ℕ) (hr : ∀ j≤n, 0<r j)
    {p : ℝ} (hp : 0≤p) : 0<(remainderB r n).eval p := by
  induction n with
  | zero =>
    simp only [remainderB,eval_add,eval_mul,eval_C,eval_X,eval_one]
    have := one_div_pos.mpr (hr 0 le_rfl)
    positivity
  | succ n ih =>
    simp only [remainderB,eval_mul,eval_add,eval_C,eval_X,eval_one]
    apply mul_pos (ih (fun j hj => hr j (by omega)))
    have := one_div_pos.mpr (hr (n+1) le_rfl)
    positivity

-- @paper-step thm:n_construction/actual_rational_controller_feedback_transform
theorem rationalCascade_feedback_identity (r : ℕ → ℝ) (n : ℕ) {δ U : ℝ}
    (hr : ∀ j≤n, 0<r j) {R v : ℝ → ℝ}
    (hP : TransferResponse (rationalCascadeError r n δ v) v
      (cascadeTransfer (rationalCascadeTimes r) (n+2)) δ)
    (hT : ∀ p : ℝ, 0<p → (1+p)*laplace R p=1+p*laplace v p)
    (hInv : ∀ p : ℝ, 0<p →
      (rationalCascadeA r n δ U*p+rationalCascadeC r n δ+
        (-1 : ℝ)^(n+1)*compactExpMoment (remainderJ r n δ) δ (-p))*laplace R p=1) :
    ∀ p : ℝ, 0<p → (rationalCascadeQ r n δ U).eval p*laplace (fun t => 1+v t) p=
      ((1+p)*(remainderB r n).eval p)*laplace (rationalCascadeError r n δ v) p := by
  intro p hp
  have hB := remainderB_eval_pos r n hr hp.le
  have hA : 1+p≠0 := ne_of_gt (by linarith)
  have hI := exact_delay_remainder_real r n δ p (fun j hj => ne_of_gt (hr j hj))
  have hfac : (rationalCascadeQ r n δ U).eval p+Real.exp (-δ*p)=
      (remainderB r n).eval p*(rationalCascadeA r n δ U*p+rationalCascadeC r n δ+
        (-1 : ℝ)^(n+1)*compactExpMoment (remainderJ r n δ) δ (-p)) := by
    simp only [rationalCascadeQ,eval_sub,eval_mul,eval_add,eval_C,eval_X]
    change (remainderB r n).eval p*(rationalCascadeA r n δ U*p+rationalCascadeC r n δ)-
      (remainderI r δ n).eval p+Real.exp (-δ*p)=_
    dsimp only [remainderTransform] at hI
    dsimp only [compactExpMoment]
    linear_combination hI
  have hres : ((rationalCascadeQ r n δ U).eval p+Real.exp (-δ*p))*laplace R p=
      (remainderB r n).eval p := by
    rw [hfac,mul_assoc,hInv p hp,mul_one]
  have hErr := transfer_error_identity hP p hp
  rw [rationalCascadeTransfer] at hErr
  have hcmd := hT p hp
  rw [(laplace_step_add hP.command_integrable hp).2]
  have hden : (1+p)*(remainderB r n).eval p≠0 := mul_ne_zero hA (ne_of_gt hB)
  field_simp [ne_of_gt hp,hden] at hErr ⊢
  simp only [neg_mul,mul_comm δ p] at hres
  linear_combination
    -((rationalCascadeQ r n δ U).eval p+Real.exp (-(p*δ)))*hcmd +
    (1+p)*hres - hErr

-- @paper-step thm:n_construction/constructed_ordinary_signals_and_exact_areas
theorem rationalCascade_signals (r : ℕ → ℝ) (n : ℕ) {δ U : ℝ}
    (hr : ∀ j≤n, 0<r j) (hδ : 0≤δ)
    (ha : 0<rationalCascadeA r n δ U) (ha1 : rationalCascadeA r n δ U<1)
    (hpar : CascadeParityTest (remainderJ r n δ) δ (rationalCascadeA r n δ U) ((-1 : ℝ)^(n+1))) :
    ∃ R v : ℝ → ℝ,
      CompactResolventEvolution (remainderJ r n δ) δ (rationalCascadeA r n δ U)
        (rationalCascadeC r n δ) ((-1 : ℝ)^(n+1)) R ∧
      v=causalize (cascadeCommand (remainderJ r n δ) δ
        (rationalCascadeA r n δ U) ((-1 : ℝ)^(n+1)) R) ∧ Integrable v ∧
      (∀ t, 0≤t → 0≤v t) ∧
      TransferResponse (rationalCascadeError r n δ v) v
        (cascadeTransfer (rationalCascadeTimes r) (n+2)) δ ∧
      (∀ t, 0≤t → 0≤rationalCascadeError r n δ v t) ∧
      Monotone (fun t => 1-rationalCascadeError r n δ v t) ∧
      1-rationalCascadeError r n δ v 0=0 ∧
      Tendsto (fun t => 1-rationalCascadeError r n δ v t) atTop (𝓝 1) ∧
      absArea v halfLine=U ∧
      absArea (rationalCascadeError r n δ v) halfLine=
        1+(∑ j∈Finset.range (n+1), 1/r j)+δ-U ∧
      (∀ p : ℝ, 0<p → (1+p)*laplace R p=1+p*laplace v p) ∧
      (∀ p : ℝ, 0<p → (rationalCascadeQ r n δ U).eval p*laplace (fun t => 1+v t) p=
        ((1+p)*(remainderB r n).eval p)*laplace (rationalCascadeError r n δ v) p) := by
  obtain ⟨R,hR,hi,_,hRn,hm,hT,hVi,hVn,hVa⟩ :=
    rationalCascade_resolvent_and_command r n hr hδ ha ha1 hpar
  let V := cascadeCommand (remainderJ r n δ) δ (rationalCascadeA r n δ U) ((-1 : ℝ)^(n+1)) R
  let v := causalize V
  have hv : Integrable v := causalize_integrable hVi
  have hvn : ∀ t, 0≤t → 0≤v t := by
    intro t ht; simpa [v,causalize,ht] using hVn t ht
  have heq : v=ᵐ[halfLine] V := representative_halfLine_ae (EventuallyEq.rfl (f := causalize V))
  have htrans (p : ℝ) (hp : 0<p) : (1+p)*laplace R p=1+p*laplace v p := by
    rw [laplace_congr_halfLine heq]
    apply cascadeCommand_resolvent_identity (remainderJ_continuous r n δ) hδ hi _ hp.le
    intro q hq
    simpa only [rationalCascadeC,add_sub_assoc] using hT q hq
  have hh := resolvent_cascade_output (n+1) (rationalCascadeTimes r) hδ
    (rationalCascadeTimes_pos r n hr) rfl hR.continuous hi hRn hm hv hvn htrans
  have hav : absArea v halfLine=U := by
    rw [show absArea v halfLine=absArea V halfLine from integral_congr_ae (heq.fun_comp abs)]
    exact hVa
  refine ⟨R,v,hR,rfl,hv,hvn,hh.1,hh.2.1,hh.2.2.1,hh.2.2.2.1,
    hh.2.2.2.2.1,hav,?_,htrans,?_⟩
  · simpa only [rationalCascadeError,rationalCascadeMean,hav] using hh.2.2.2.2.2
  · exact rationalCascade_feedback_identity r n hr hh.1 htrans (fun p hp => hT p hp.le)

-- @paper-step thm:n_construction/exact_optimal_areas_and_universal_signal_comparison
theorem rationalCascade_global_signal_minimum (r : ℕ → ℝ) (n : ℕ) {δ α : ℝ}
    (hr : ∀ j≤n, 0<r j) (hδ : 0≤δ) (hα : 0<α)
    (ha : 0<rationalCascadeA r n δ
      ((1+(∑ j∈Finset.range (n+1), 1/r j)+δ)/(1+α)))
    (ha1 : rationalCascadeA r n δ
      ((1+(∑ j∈Finset.range (n+1), 1/r j)+δ)/(1+α))<1)
    (hpar : CascadeParityTest (remainderJ r n δ) δ (rationalCascadeA r n δ
      ((1+(∑ j∈Finset.range (n+1), 1/r j)+δ)/(1+α))) ((-1 : ℝ)^(n+1))) :
    let S := 1+(∑ j∈Finset.range (n+1), 1/r j)+δ
    ∃ R v : ℝ → ℝ,
      v=causalize (cascadeCommand (remainderJ r n δ) δ
        (rationalCascadeA r n δ (S/(1+α))) ((-1 : ℝ)^(n+1)) R) ∧
      Integrable v ∧
      TransferResponse (rationalCascadeError r n δ v) v
        (cascadeTransfer (rationalCascadeTimes r) (n+2)) δ ∧
      (∀ t, 0≤t → 0≤v t ∧ 0≤rationalCascadeError r n δ v t) ∧
      Monotone (fun t => 1-rationalCascadeError r n δ v t) ∧
      1-rationalCascadeError r n δ v 0=0 ∧
      Tendsto (fun t => 1-rationalCascadeError r n δ v t) atTop (𝓝 1) ∧
      absArea v halfLine=S/(1+α) ∧
      absArea (rationalCascadeError r n δ v) halfLine=α*S/(1+α) ∧
      miace α (rationalCascadeError r n δ v) v halfLine=S*minimum α ∧
      (∀ p : ℝ, 0<p → (rationalCascadeQ r n δ (S/(1+α))).eval p*
        laplace (fun t => 1+v t) p=
        ((1+p)*(remainderB r n).eval p)*laplace (rationalCascadeError r n δ v) p) ∧
      ∀ e' v' : ℝ → ℝ,
        TransferResponse e' v' (cascadeTransfer (rationalCascadeTimes r) (n+2)) δ →
        miace α (rationalCascadeError r n δ v) v halfLine≤miace α e' v' halfLine := by
  dsimp only
  let S := 1+(∑ j∈Finset.range (n+1), 1/r j)+δ
  have hS : 0<S := by
    have hh : 0≤∑ j∈Finset.range (n+1), 1/r j :=
      Finset.sum_nonneg (fun j hj => (one_div_pos.mpr (hr j (by simpa using Finset.mem_range.mp hj))).le)
    dsimp [S]; linarith
  obtain ⟨R,v,_,hvdef,hvi,hvn,hP,hen,hmono,hzero,hlim,hva,hea,_,hfeedback⟩ :=
    rationalCascade_signals r n hr hδ ha ha1 hpar
  have hbal := transfer_signed_balance hP (cascadeMean (rationalCascadeTimes r) (n+2))
    (cascadeTransfer_derivative _ _) (cascadeTransfer_zero _ _)
  rw [rationalCascadeMean] at hbal
  have hearea : absArea (rationalCascadeError r n δ v) halfLine=α*S/(1+α) := by
    rw [hea]
    change S-S/(1+α)=α*S/(1+α)
    field_simp [show 1+α≠0 by linarith]
    ring
  have hena : ∀ᵐ t ∂halfLine, 0≤rationalCascadeError r n δ v t := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact hen t (show 0<t from ht).le
  have hvna : ∀ᵐ t ∂halfLine, 0≤v t := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact hvn t (show 0<t from ht).le
  have hcost : miace α (rationalCascadeError r n δ v) v halfLine=S*minimum α := by
    apply (signal_miace_equality_iff hP.error_integrable hP.command_integrable α S hα hS hbal).mpr
    refine ⟨hena,hvna,?_⟩
    rw [hearea,hva]
    dsimp only [S]; ring
  refine ⟨R,v,hvdef,hvi,hP,fun t ht => ⟨hvn t ht,hen t ht⟩,
    hmono,hzero,hlim,hva,hearea,hcost,hfeedback,?_⟩
  intro e' v' hP'
  rw [hcost]
  apply signal_miace_lower_bound hP'.error_integrable hP'.command_integrable α S hα hS.le
  have hh := transfer_signed_balance hP' (cascadeMean (rationalCascadeTimes r) (n+2))
    (cascadeTransfer_derivative _ _) (cascadeTransfer_zero _ _)
  simpa only [rationalCascadeMean] using hh

end MIACE
