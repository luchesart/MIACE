import MIACE.L1Front

/-! Поправка: ограничението се налага върху действителната команда.
Ниският коефициент x<1 се изключва чрез строго доминиране, а не по предположение. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

def CommandCap (A x : ℝ) (e i : ℝ → ℝ) : Prop :=
  ∀ t : ℝ, 0 ≤ t → 0 ≤ 1+(x*e t+i t) ∧ 1+(x*e t+i t) ≤ A

noncomputable def l1Scalar (α z : ℝ) : ℝ := z^2+α*(1-z)^2

-- @paper-step thm:amplitude/actual_amplitude_constraint
theorem command_cap_iff {A x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r)
    (hd : MonotoneDomain x r) (hA : 1 ≤ A) : CommandCap A x e i ↔ x ≤ A := by
  constructor
  · intro hc
    have hh := (hc 0 le_rfl).2
    simpa [h.initial_e,h.initial_i] using hh
  · intro hxA t ht
    exact ⟨pi_command_nonnegative h hx hr hd t ht,
      (pi_command_upper h hx hr hd t ht).trans (max_le hA hxA)⟩

-- @paper-step thm:amplitude/low_gain_strict_dominance
theorem low_gain_dominance {x r : ℝ} (hx : 0 < x) (hr : 0 < r)
    (hx1 : x < 1) (hd : MonotoneDomain x r) :
    1/2 < tracking x r ∧ 1 < r/x := by
  have hden : 0 < (1+x)^2 := by positivity
  have hdom : 4*x/(1+x)^2 ≤ r := by simpa [MonotoneDomain,hx1.le] using hd
  have h4 : (1+x)^2 < 4 := by nlinarith
  have hsmall : x < 4*x/(1+x)^2 := by
    apply (lt_div_iff₀ hden).mpr
    nlinarith [mul_lt_mul_of_pos_left h4 hx]
  have hxr : x < r := hsmall.trans_le hdom
  constructor
  · unfold tracking
    apply (lt_div_iff₀ (by positivity : 0 < 2*x*(1+x))).mpr
    nlinarith
  · exact (one_lt_div hx).mpr hxr

-- @paper-step thm:amplitude/quadratic_clipped_high_gain
theorem quadratic_clipped_high {q s A x r : ℝ} (hq : 0 < q)
    (hs : s^2=1+q) (hs1 : 1 < s) (hA : 1 ≤ A)
    (hx1 : 1 ≤ x) (hxA : x ≤ A) (hr1 : 1 ≤ r) :
    quadratic q (min s A) 1 ≤ quadratic q x r ∧
    (quadratic q x r=quadratic q (min s A) 1 ↔ x=min s A ∧ r=1) := by
  have hx : 0 < x := by linarith
  have hr : 0 < r := by linarith
  have hA0 : 0 < A := by linarith
  by_cases hsa : s ≤ A
  · rw [min_eq_left hsa]
    have hopt : quadratic q s 1=s-1 :=
      (quadratic_equality_iff q s s 1 (by linarith) zero_lt_one (by linarith) hs).mpr ⟨rfl,rfl⟩
    rw [hopt]
    exact ⟨quadratic_lower_bound q s x r hx hr hs,
      quadratic_equality_iff q s x r hx hr (by linarith) hs⟩
  · have has : A < s := lt_of_not_ge hsa
    rw [min_eq_right has.le]
    have hcoef : 0 < s^2*r-x^2 := by
      nlinarith [mul_le_mul_of_nonneg_left hr1 (sq_nonneg s)]
    have hcoef2 : 0 < s^2-A*x := by
      nlinarith [mul_le_mul_of_nonneg_left hxA hA0.le]
    have hg1 : quadratic q x r-quadratic q x 1 =
        (r-1)*(s^2*r-x^2)/(2*r*x*(1+x)) := by
      have hqeq : q=s^2-1 := by linarith
      rw [hqeq]
      unfold quadratic tracking effort
      field_simp
      <;> ring
    have hg2 : quadratic q x 1-quadratic q A 1 = (A-x)*(s^2-A*x)/(2*A*x) := by
      have hqeq : q=s^2-1 := by linarith
      rw [hqeq]
      unfold quadratic tracking effort
      field_simp
      <;> ring
    have hd1 : 0 < 2*r*x*(1+x) := by positivity
    have hd2 : 0 < 2*A*x := by positivity
    have hn1 : 0 ≤ (r-1)*(s^2*r-x^2)/(2*r*x*(1+x)) := by positivity
    have hn2 : 0 ≤ (A-x)*(s^2-A*x)/(2*A*x) := by positivity
    refine ⟨by linarith,?_⟩
    constructor
    · intro heq
      have hz1 : (r-1)*(s^2*r-x^2)/(2*r*x*(1+x))=0 := by linarith
      have hz2 : (A-x)*(s^2-A*x)/(2*A*x)=0 := by linarith
      have hh1 := ((div_eq_zero_iff.mp hz1).resolve_right (ne_of_gt hd1))
      have hh2 := ((div_eq_zero_iff.mp hz2).resolve_right (ne_of_gt hd2))
      have hr0 := (mul_eq_zero.mp hh1).resolve_right (ne_of_gt hcoef)
      have hx0 := (mul_eq_zero.mp hh2).resolve_right (ne_of_gt hcoef2)
      exact ⟨by linarith,by linarith⟩
    · rintro ⟨rfl,rfl⟩
      rfl

-- @paper-step thm:amplitude/cancellation_cost_identification
theorem pi_cancellation_cost {x α : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x 1 e i) (hx : 1 ≤ x) :
    costSq α (absArea e halfLine) (absArea (fun t => x*e t+i t) halfLine)=l1Scalar α (1/x) := by
  have ha := pi_cancellation_areas h hx
  rw [ha.1,ha.2]
  rfl

-- @paper-step thm:amplitude/quadratic_complete_domain
theorem quadratic_clipped {q A x r : ℝ} (hq : 0 < q) (hA : 1 ≤ A)
    (hx : 0 < x) (hr : 0 < r) (hd : MonotoneDomain x r) (hxA : x ≤ A) :
    quadratic q (min (Real.sqrt (1+q)) A) 1 ≤ quadratic q x r ∧
    (quadratic q x r=quadratic q (min (Real.sqrt (1+q)) A) 1 ↔
      x=min (Real.sqrt (1+q)) A ∧ r=1) := by
  let s := Real.sqrt (1+q)
  have hs : s^2=1+q := Real.sq_sqrt (by linarith)
  have hs1 : 1 < s := by
    have hn : 0 ≤ s := Real.sqrt_nonneg _
    nlinarith
  have hc1 : 1 ≤ min s A := le_min hs1.le hA
  by_cases hx1 : 1 ≤ x
  · have hr1 : 1 ≤ r := by
      unfold MonotoneDomain at hd
      split_ifs at hd with hxl
      · have heq : x=1 := le_antisymm hxl hx1
        norm_num [heq] at hd
        exact hd
      · exact hd
    exact quadratic_clipped_high hq hs hs1 hA hx1 hxA hr1
  · have hxlt : x < 1 := lt_of_not_ge hx1
    have htrack := (low_gain_dominance hx hr hxlt hd).1
    have hu : 0 ≤ effort x r := by unfold effort; positivity
    have hcost : q/2 < quadratic q x r := by
      unfold quadratic
      nlinarith [mul_lt_mul_of_pos_left htrack hq]
    have hc := (quadratic_clipped_high hq hs hs1 hA (x := 1) (r := 1) le_rfl hA le_rfl).1
    have hone : quadratic q 1 1=q/2 := by norm_num [quadratic,tracking,effort]; ring
    rw [hone] at hc
    have hstrict : quadratic q (min s A) 1 < quadratic q x r := by linarith
    refine ⟨hstrict.le,?_⟩
    constructor
    · intro heq
      exact (ne_of_gt hstrict heq).elim
    · rintro ⟨heq,hr1⟩
      have hxx : 1 ≤ x := heq ▸ hc1
      linarith

-- @paper-step thm:amplitude/miace_signed_square_bound
theorem pi_signed_square_bound {x r α : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r) (hα : 0 < α) :
    l1Scalar α (r/x) ≤ costSq α (absArea e halfLine) (absArea (fun t => x*e t+i t) halfLine) := by
  have hs := pi_state_signed_areas h hx hr
  have he : |r/x| ≤ absArea e halfLine := by
    rw [← hs.1]
    exact abs_integral_le_integral_abs
  have hv : |1-r/x| ≤ absArea (fun t => x*e t+i t) halfLine := by
    rw [← hs.2]
    exact abs_integral_le_integral_abs
  have hes : (r/x)^2 ≤ (absArea e halfLine)^2 := by nlinarith [sq_abs (r/x),abs_nonneg (r/x)]
  have hvs : (1-r/x)^2 ≤ (absArea (fun t => x*e t+i t) halfLine)^2 := by
    nlinarith [sq_abs (1-r/x),abs_nonneg (1-r/x)]
  unfold l1Scalar costSq
  nlinarith [mul_le_mul_of_nonneg_left hvs hα.le]

-- @paper-step thm:amplitude/clipped_scalar_miace
theorem l1_scalar_clipped {α A z : ℝ} (hα : 0 < α) (hA : 1 ≤ A)
    (hz : 1/A ≤ z) :
    l1Scalar α (1/(min (1+1/α) A)) ≤ l1Scalar α z ∧
    (l1Scalar α z=l1Scalar α (1/(min (1+1/α) A)) ↔ z=1/(min (1+1/α) A)) := by
  have hA0 : 0 < A := by linarith
  have hopt : 1/(1+1/α)=α/(1+α) := by field_simp; ring
  have hcomp : ∀ u : ℝ, l1Scalar α u=α/(1+α)+(1+α)*(u-α/(1+α))^2 := by
    intro u
    unfold l1Scalar
    field_simp
    <;> ring
  by_cases hsel : 1+1/α ≤ A
  · rw [min_eq_left hsel,hopt,hcomp z,hcomp (α/(1+α))]
    simp only [sub_self,zero_pow (by decide : 2 ≠ 0),mul_zero,add_zero]
    have hn : 0 ≤ (1+α)*(z-α/(1+α))^2 := by positivity
    refine ⟨by linarith,?_⟩
    constructor
    · intro heq
      have hs : (z-α/(1+α))^2=0 := by nlinarith
      exact sub_eq_zero.mp (sq_eq_zero_iff.mp hs)
    · rintro rfl
      ring
  · have hsel : A < 1+1/α := lt_of_not_ge hsel
    rw [min_eq_right hsel.le]
    have ha : α/(1+α) < 1/A := by
      apply (div_lt_div_iff₀ (by linarith : 0 < 1+α) hA0).mpr
      have hh := (lt_div_iff₀ hα).mp (show A-1 < 1/α by linarith)
      nlinarith
    have hgap : l1Scalar α z-l1Scalar α (1/A)=
        (z-1/A)*((1+α)*(z+1/A)-2*α) := by unfold l1Scalar; ring
    have hcoef : 0 < (1+α)*(z+1/A)-2*α := by
      have hh := (div_lt_iff₀ (by linarith : 0 < 1+α)).mp ha
      nlinarith
    have hn : 0 ≤ (z-1/A)*((1+α)*(z+1/A)-2*α) := by positivity
    refine ⟨by linarith,?_⟩
    constructor
    · intro heq
      have hzero : (z-1/A)*((1+α)*(z+1/A)-2*α)=0 := by linarith
      exact sub_eq_zero.mp ((mul_eq_zero.mp hzero).resolve_right (ne_of_gt hcoef))
    · rintro rfl
      rfl

-- @paper-step thm:amplitude/miace_complete_domain
theorem miace_clipped {α A x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hα : 0 < α) (hA : 1 ≤ A)
    (hx : 0 < x) (hr : 0 < r) (hd : MonotoneDomain x r) (hxA : x ≤ A) :
    l1Scalar α (1/(min (1+1/α) A)) ≤
      costSq α (absArea e halfLine) (absArea (fun t => x*e t+i t) halfLine) ∧
    (costSq α (absArea e halfLine) (absArea (fun t => x*e t+i t) halfLine)=
      l1Scalar α (1/(min (1+1/α) A)) ↔ x=min (1+1/α) A ∧ r=1) := by
  let c := min (1+1/α) A
  have hs1 : 1 < 1+1/α := by
    have hh : 0 < 1/α := by positivity
    linarith
  have hc1 : 1 ≤ c := le_min hs1.le hA
  have hA0 : 0 < A := by linarith
  have hbound := pi_signed_square_bound h hx hr hα
  by_cases hx1 : 1 ≤ x
  · have hr1 : 1 ≤ r := by
      unfold MonotoneDomain at hd
      split_ifs at hd with hxl
      · have heq : x=1 := le_antisymm hxl hx1
        norm_num [heq] at hd
        exact hd
      · exact hd
    have hz : 1/A ≤ r/x := (div_le_div_iff₀ hA0 hx).mpr (by nlinarith)
    have hscalar := l1_scalar_clipped hα hA hz
    refine ⟨hscalar.1.trans hbound,?_⟩
    constructor
    · intro heq
      by_cases hsel : 1+1/α ≤ A
      · have hcost : costSq α (absArea e halfLine) (absArea (fun t => x*e t+i t) halfLine)=α/(1+α) := by
          rw [heq,min_eq_left hsel]
          unfold l1Scalar
          field_simp
          <;> ring
        have hm : miace α e (fun t => x*e t+i t) halfLine=minimum α := by
          unfold miace minimum
          rw [hcost]
        have hm := (pi_miace_equality_iff h hx hr hα).mp hm
        rw [min_eq_left hsel]
        exact hm
      · have hsel : A < 1+1/α := lt_of_not_ge hsel
        have heqs : l1Scalar α (r/x)=l1Scalar α (1/(min (1+1/α) A)) := by linarith [hscalar.1]
        have hz1 := hscalar.2.mp heqs
        rw [min_eq_right hsel.le] at hz1 ⊢
        have hmul : r*A=x := by
          have hh := (div_eq_div_iff (ne_of_gt hx) (ne_of_gt hA0)).mp hz1
          linarith
        have hrle : r ≤ 1 := by nlinarith
        have hreq : r=1 := le_antisymm hrle hr1
        exact ⟨by nlinarith,hreq⟩
    · rintro ⟨rfl,rfl⟩
      exact pi_cancellation_cost h hc1
  · have hxlt : x < 1 := lt_of_not_ge hx1
    have hz1 := (low_gain_dominance hx hr hxlt hd).2
    have hcost : 1 < costSq α (absArea e halfLine) (absArea (fun t => x*e t+i t) halfLine) := by
      have hp : 0 ≤ α*(1-r/x)^2 := by positivity
      unfold l1Scalar at hbound
      nlinarith
    have hcap : 1/A ≤ (1:ℝ) := (div_le_one hA0).mpr hA
    have hscalar := (l1_scalar_clipped hα hA hcap).1
    have hone : l1Scalar α 1=1 := by simp [l1Scalar]
    rw [hone] at hscalar
    have hstrict : l1Scalar α (1/c) < costSq α (absArea e halfLine)
        (absArea (fun t => x*e t+i t) halfLine) := by
      change l1Scalar α (1/c) ≤ 1 at hscalar
      linarith
    refine ⟨hstrict.le,?_⟩
    constructor
    · intro heq
      exact (ne_of_gt hstrict heq).elim
    · rintro ⟨heq,hr1⟩
      have hxx : 1 ≤ x := heq ▸ hc1
      linarith

-- @paper-step thm:amplitude/feasible_attaining_responses
theorem clipped_response_feasible {s A : ℝ} (hs : 1 ≤ s) (hA : 1 ≤ A) :
    PIStateResponse (min s A) 1 (expError (min s A)) (fun t => -expError (min s A) t) ∧
    MonotoneDomain (min s A) 1 ∧
    CommandCap A (min s A) (expError (min s A)) (fun t => -expError (min s A) t) := by
  have hc : 1 ≤ min s A := le_min hs hA
  have hc0 : 0 < min s A := by linarith
  have hd : MonotoneDomain (min s A) 1 := by
    unfold MonotoneDomain
    split_ifs with hcl
    · have heq : min s A=1 := le_antisymm hcl hc
      norm_num [heq]
    · exact le_rfl
  exact ⟨exponential_pi_state _,hd,
    (command_cap_iff (exponential_pi_state _) hc0 zero_lt_one hd hA).mpr (min_le_right _ _)⟩

-- @paper-step thm:amplitude/full_statement
theorem paper_amplitude {q α A x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hq : 0 < q) (hα : 0 < α) (hA : 1 ≤ A)
    (hx : 0 < x) (hr : 0 < r) (hd : MonotoneDomain x r) (hcap : CommandCap A x e i) :
    let cq := min (Real.sqrt (1+q)) A
    let cm := min (1+1/α) A
    let F := q*(∫ t, (e t)^2 ∂halfLine)+(∫ t, (x*e t+i t)^2 ∂halfLine)
    (CommandCap A x e i ↔ x ≤ A) ∧
    (quadratic q cq 1 ≤ F) ∧ (F=quadratic q cq 1 ↔ x=cq ∧ r=1) ∧
    (Real.sqrt (l1Scalar α (1/cm)) ≤ miace α e (fun t => x*e t+i t) halfLine) ∧
    (miace α e (fun t => x*e t+i t) halfLine=Real.sqrt (l1Scalar α (1/cm)) ↔ x=cm ∧ r=1) ∧
    (PIStateResponse cq 1 (expError cq) (fun t => -expError cq t) ∧
      MonotoneDomain cq 1 ∧ CommandCap A cq (expError cq) (fun t => -expError cq t)) ∧
    (PIStateResponse cm 1 (expError cm) (fun t => -expError cm t) ∧
      MonotoneDomain cm 1 ∧ CommandCap A cm (expError cm) (fun t => -expError cm t)) := by
  dsimp only
  have hcapiff := command_cap_iff h hx hr hd hA
  have hxA := hcapiff.mp hcap
  obtain ⟨he,hu⟩ := paper_pi_energies h hx hr
  rw [he.2,hu.2]
  change _ ∧ (_ ≤ quadratic q x r) ∧ (quadratic q x r = _ ↔ _) ∧ _
  have hqopt := quadratic_clipped hq hA hx hr hd hxA
  have hmopt := miace_clipped h hα hA hx hr hd hxA
  have hsq : 1 ≤ Real.sqrt (1+q) := by
    have hh := Real.sq_sqrt (show 0 ≤ 1+q by linarith)
    have hn := Real.sqrt_nonneg (1+q)
    nlinarith
  have hm : 1 ≤ 1+1/α := by
    have hh : 0 < 1/α := by positivity
    linarith
  refine ⟨hcapiff,hqopt.1,hqopt.2,Real.sqrt_le_sqrt hmopt.1,?_,
    clipped_response_feasible hsq hA,clipped_response_feasible hm hA⟩
  unfold miace
  rw [Real.sqrt_inj (by unfold costSq; positivity) (by unfold l1Scalar; positivity)]
  exact hmopt.2
end MIACE
