import MIACE.Dynamics
import Mathlib.Analysis.SpecialFunctions.ImproperIntegrals
import Mathlib.Analysis.Calculus.ContDiff.Deriv
import Mathlib.Tactic

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:nonlinear_miace/exponential_dominance_integrability
theorem nonlinear_integrable_of_exp_bound {y : ℝ → ℝ} (hy : Continuous y)
    {β : ℝ} (hβ : 0 < β)
    (hb : ∀ t, 0 ≤ t → 0 ≤ 1-y t ∧ 1-y t ≤ Real.exp (-β*t)) :
    Integrable (fun t => 1-y t) halfLine := by
  have he : Integrable (fun t : ℝ => Real.exp (-β*t)) halfLine :=
    integrableOn_exp_mul_Ioi (neg_neg_of_pos hβ) 0
  apply he.mono' (continuous_const.sub hy).aestronglyMeasurable
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  change |1-y t| ≤ Real.exp (-β*t)
  rw [abs_of_nonneg (hb t ht.le).1]
  exact (hb t ht.le).2

-- @paper-step thm:nonlinear_miace/exponential_dominance_settling
theorem nonlinear_settling_of_exp_bound {y : ℝ → ℝ}
    {β : ℝ} (hβ : 0 < β)
    (hb : ∀ t, 0 ≤ t → 0 ≤ 1-y t ∧ 1-y t ≤ Real.exp (-β*t)) :
    Tendsto y atTop (𝓝 1) := by
  have ht : Tendsto (fun t : ℝ => β*t) atTop atTop :=
    tendsto_id.const_mul_atTop hβ
  have hexp : Tendsto (fun t : ℝ => Real.exp (-β*t)) atTop (𝓝 0) := by
    simpa [Function.comp_def, neg_mul] using
      Real.tendsto_exp_neg_atTop_nhds_zero.comp ht
  have he : Tendsto (fun t => 1-y t) atTop (𝓝 0) := by
    apply squeeze_zero' ?_ ?_ hexp
    · filter_upwards [eventually_ge_atTop (0 : ℝ)] with t ht
      exact (hb t ht).1
    · filter_upwards [eventually_ge_atTop (0 : ℝ)] with t ht
      exact (hb t ht).2
  simpa only [sub_sub_cancel, sub_zero] using
    (tendsto_const_nhds (x := (1 : ℝ))).sub he

-- @paper-step thm:nonlinear_miace/inverse_clock_C1
theorem nonlinear_inverse_clock_contDiff {q s : ℝ → ℝ}
    (hq : Continuous q) (hs : Continuous s) (hq0 : ∀ x, q x ≠ 0)
    (hder : ∀ t, HasDerivAt s (q (s t))⁻¹ t) : ContDiff ℝ 1 s := by
  rw [contDiff_one_iff_deriv]
  refine ⟨fun t => (hder t).differentiableAt, ?_⟩
  have heq : deriv s = fun t => (q (s t))⁻¹ := funext (fun t => (hder t).deriv)
  rw [heq]
  exact (hq.comp hs).inv₀ (fun t => hq0 (s t))

end MIACE
