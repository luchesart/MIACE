import MIACE.Attainment

namespace MIACE
open MeasureTheory Set

-- @paper-step thm:complete_attainment/weighted_exponential
theorem weighted_expCommand (x : ℝ) :
    (fun t => Real.exp t*expCommand x t) = (fun t => (x-1)*Real.exp (-(x-1)*t)) := by
  funext t
  unfold expCommand expError
  calc
    _ = (x-1)*(Real.exp t*Real.exp (-x*t)) := by ring
    _ = _ := by rw [← Real.exp_add]; congr 2 <;> ring

-- @paper-step thm:complete_attainment/moments
theorem expCommand_moment (x : ℝ) (hx : 1 < x) :
    Integrable (fun t => Real.exp t*expCommand x t) halfLine ∧ moment (expCommand x) = 1 := by
  have hi : Integrable (fun t : ℝ => Real.exp (-(x-1)*t)) halfLine :=
    integrableOn_exp_mul_Ioi (by linarith : -(x-1) < 0) 0
  refine ⟨?_,?_⟩
  · rw [weighted_expCommand]
    exact hi.const_mul (x-1)
  · unfold moment
    rw [weighted_expCommand,integral_const_mul]
    unfold halfLine
    rw [integral_exp_mul_Ioi (by linarith : -(x-1) < 0)]
    simp
    have hx0 : 1-x ≠ 0 := by linarith
    field_simp
    ring

-- @paper-step thm:complete_attainment/command_peak
theorem expCommand_peak (x : ℝ) (hx : 1 ≤ x) :
    1+expCommand x 0 = x ∧ ∀ t : ℝ, 0 ≤ t → 1+expCommand x t ≤ x := by
  refine ⟨by simp [expCommand,expError],?_⟩
  intro t ht
  have he : Real.exp (-x*t) ≤ 1 := Real.exp_le_one_iff.mpr (by nlinarith)
  unfold expCommand expError
  nlinarith

-- @paper-step thm:complete_attainment/exponential_area_realization
theorem ordinary_command_for_area (U : ℝ) (hU : 0 ≤ U) (hU1 : U < 1) :
    ∃ v : ℝ → ℝ, Integrable v halfLine ∧
      Integrable (fun t => Real.exp t*v t) halfLine ∧
      (∀ᵐ t ∂halfLine, 0 ≤ v t) ∧ commandArea v = U ∧ moment v ≤ 1 := by
  by_cases h0 : U = 0
  · subst U
    refine ⟨fun _ => 0,by simp,by simp,by simp,?_,?_⟩ <;> simp [commandArea,moment]
  · have hUp : 0 < U := lt_of_le_of_ne hU (Ne.symm h0)
    have ha : 0 < 1-U := by linarith
    have hx : 1 < 1/(1-U) := by apply (lt_div_iff₀ ha).2; linarith
    have hresp := exponential_response (1/(1-U)) (by linarith)
    have hm := expCommand_moment (1/(1-U)) hx
    have hv : ∀ᵐ t ∂halfLine, 0 ≤ expCommand (1/(1-U)) t := by
      apply ae_of_all
      intro t
      exact mul_nonneg (by linarith) (Real.exp_nonneg _)
    refine ⟨expCommand (1/(1-U)),hresp.command_integrable,hm.1,hv,?_,by rw [hm.2]⟩
    have heq : commandArea (expCommand (1/(1-U))) = absArea (expCommand (1/(1-U))) halfLine := by
      unfold commandArea absArea
      apply integral_congr_ae
      filter_upwards [hv] with t ht
      exact (abs_of_nonneg ht).symm
    rw [heq,(exponential_areas (1/(1-U)) hx.le).2]
    field_simp
    ring

end MIACE
