import MIACE.Lag

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def lag (σ : ℝ) (u : ℝ → ℝ) (t : ℝ) : ℝ :=
  (Real.exp (-t/σ)/σ)*(∫ s in 0..t, Real.exp (s/σ)*u s)

-- @paper-step thm:command_cone/lag_kernel_mass
theorem lag_kernel_mass (σ t : ℝ) (hσ : 0 < σ) :
    (Real.exp (-t/σ)/σ)*(∫ s in 0..t, Real.exp (s/σ)) = 1-Real.exp (-t/σ) := by
  rw [intervalIntegral.integral_comp_div _ (ne_of_gt hσ),integral_exp]
  simp only [zero_div,Real.exp_zero,smul_eq_mul]
  have he : Real.exp (-t/σ)*Real.exp (t/σ) = 1 := by
    rw [← Real.exp_add]
    have : -t/σ+t/σ = 0 := by ring
    rw [this,Real.exp_zero]
  field_simp
  simp only [neg_div] at he
  nlinarith

-- @paper-step thm:command_cone/lag_local_integrability
theorem lag_input_integrable {u : ℝ → ℝ} (hu : ContinuousOn u (Ici 0))
    (σ t : ℝ) (ht : 0 ≤ t) :
    IntervalIntegrable (fun s => Real.exp (s/σ)*u s) volume 0 t := by
  apply ContinuousOn.intervalIntegrable
  rw [uIcc_of_le ht]
  exact (by fun_prop : Continuous (fun s : ℝ => Real.exp (s/σ))).continuousOn.mul
    (hu.mono (fun s hs => hs.1))

-- @paper-step thm:command_cone/lag_absolute_continuity
theorem lag_ac {u : ℝ → ℝ} (hu : ContinuousOn u (Ici 0))
    (σ H : ℝ) (hH : 0 ≤ H) : AbsolutelyContinuousOnInterval (lag σ u) 0 H := by
  have hcoef : AbsolutelyContinuousOnInterval (fun t : ℝ => Real.exp (-t/σ)/σ) 0 H := by
    apply ContDiffOn.absolutelyContinuousOnInterval
    fun_prop
  exact hcoef.mul ((lag_input_integrable hu σ H hH).absolutelyContinuousOnInterval_intervalIntegral
    (by simp))

-- A positive lag cannot exceed a nonnegative nondecreasing input.
-- @paper-step thm:command_cone/lag_order_bounds
theorem lag_order_bounds {u : ℝ → ℝ} (hu : ContinuousOn u (Ici 0))
    (hn : ∀ t : ℝ, 0 ≤ t → 0 ≤ u t) (hm : MonotoneOn u (Ici 0))
    (σ t : ℝ) (hσ : 0 < σ) (ht : 0 ≤ t) : 0 ≤ lag σ u t ∧ lag σ u t ≤ u t := by
  have hi := lag_input_integrable hu σ t ht
  have hexp : IntervalIntegrable (fun s : ℝ => Real.exp (s/σ)) volume 0 t :=
    (by fun_prop : Continuous (fun s : ℝ => Real.exp (s/σ))).intervalIntegrable _ _
  have hp : 0 ≤ Real.exp (-t/σ)/σ := div_nonneg (Real.exp_nonneg _) hσ.le
  have hb := intervalIntegral.integral_mono_on ht hi (hexp.const_mul (u t))
    (fun s hs => by
      have hu' := hm hs.1 ht hs.2
      have hh := mul_le_mul_of_nonneg_left hu' (Real.exp_nonneg (s/σ))
      simpa [mul_comm] using hh)
  rw [intervalIntegral.integral_const_mul] at hb
  constructor
  · unfold lag
    apply mul_nonneg hp
    rw [intervalIntegral.integral_of_le ht]
    apply integral_nonneg_of_ae
    filter_upwards [ae_restrict_mem measurableSet_Ioc] with s hs
    exact mul_nonneg (Real.exp_nonneg _) (hn s (le_of_lt (show 0 < s from hs.1)))
  · have hb' := mul_le_mul_of_nonneg_left hb hp
    have heq : (Real.exp (-t/σ)/σ)*(u t*(∫ s in 0..t, Real.exp (s/σ))) =
        u t*(1-Real.exp (-t/σ)) := by
      calc
        _ = u t*((Real.exp (-t/σ)/σ)*(∫ s in 0..t, Real.exp (s/σ))) := by ring
        _ = _ := by rw [lag_kernel_mass σ t hσ]
    rw [heq] at hb'
    unfold lag
    nlinarith [hn t ht,Real.exp_nonneg (-t/σ)]

-- @paper-step thm:command_cone/lag_ode
theorem lag_hasDerivAt {u : ℝ → ℝ} (hu : ContinuousOn u (Ici 0))
    (σ t : ℝ) (hσ : 0 < σ) (ht : 0 < t) :
    HasDerivAt (lag σ u) ((u t-lag σ u t)/σ) t := by
  have hc : ContinuousOn (fun s : ℝ => Real.exp (s/σ)*u s) (Ici 0) :=
    (by fun_prop : Continuous (fun s : ℝ => Real.exp (s/σ))).continuousOn.mul hu
  have hi := intervalIntegral.integral_hasDerivAt_right (lag_input_integrable hu σ t ht.le)
    (ContinuousOn.stronglyMeasurableAtFilter isOpen_Ioi (hc.mono Ioi_subset_Ici_self) t ht)
    (hc.continuousAt (Ici_mem_nhds ht))
  have hcoef := (((hasDerivAt_id t).neg.div_const σ).exp).div_const σ
  have hd := hcoef.mul hi
  have he : Real.exp (-t/σ)*Real.exp (t/σ) = 1 := by
    rw [← Real.exp_add]
    have : -t/σ+t/σ = 0 := by ring
    rw [this,Real.exp_zero]
  convert hd using 1
  · rfl
  · unfold lag
    field_simp
    simp only [neg_div] at he
    simp only [Pi.neg_apply,id_eq,neg_div]
    nlinarith [congrArg (fun z => z*(u t*σ)) he]

-- @paper-step thm:command_cone/lag_monotonicity_preservation
theorem lag_preserves_monotone {u : ℝ → ℝ} (hu : ContinuousOn u (Ici 0))
    (hn : ∀ t : ℝ, 0 ≤ t → 0 ≤ u t) (hm : MonotoneOn u (Ici 0))
    (σ : ℝ) (hσ : 0 < σ) : MonotoneOn (lag σ u) (Ici 0) := by
  intro a ha b hb hab
  have hac : AbsolutelyContinuousOnInterval (lag σ u) a b := by
    apply (lag_ac hu σ b hb).mono
    rw [uIcc_of_le hab,uIcc_of_le hb]
    exact fun s hs => ⟨ha.trans hs.1,hs.2⟩
  have hi := hac.integral_deriv_eq_sub
  have hp : 0 ≤ ∫ s in a..b, deriv (lag σ u) s := by
    rw [intervalIntegral.integral_of_le hab]
    apply integral_nonneg_of_ae
    filter_upwards [ae_restrict_mem measurableSet_Ioc] with s hs
    have hs0 : 0 < s := lt_of_le_of_lt ha hs.1
    rw [(lag_hasDerivAt hu σ s hσ hs0).deriv]
    exact div_nonneg (sub_nonneg.mpr (lag_order_bounds hu hn hm σ s hσ hs0.le).2) hσ.le
  linarith

-- Repeated application to a finite cascade. The recurrence is the standard
-- zero-state convolution realization; continuity of its states is explicit.
-- @paper-step thm:command_cone/cascade_monotonicity_induction
theorem cascade_preserves_monotone (N : ℕ) (σ : ℕ → ℝ) (x : ℕ → ℝ → ℝ)
    (hσ : ∀ j < N, 0 < σ j)
    (hc : ∀ j ≤ N, ContinuousOn (x j) (Ici 0))
    (hx : ∀ j < N, x (j+1) = lag (σ j) (x j))
    (hm : MonotoneOn (x 0) (Ici 0))
    (hb : ∀ t : ℝ, 0 ≤ t → 0 ≤ x 0 t ∧ x 0 t ≤ 1) :
    ∀ j ≤ N, MonotoneOn (x j) (Ici 0) ∧
      ∀ t : ℝ, 0 ≤ t → 0 ≤ x j t ∧ x j t ≤ 1 := by
  intro j hj
  induction j with
  | zero => exact ⟨hm,hb⟩
  | succ j ih =>
    have hjN : j < N := by omega
    have hprev := ih (by omega)
    rw [hx j hjN]
    have hn : ∀ t : ℝ, 0 ≤ t → 0 ≤ x j t := fun t ht => (hprev.2 t ht).1
    refine ⟨lag_preserves_monotone (hc j (by omega)) hn hprev.1 (σ j) (hσ j hjN),?_⟩
    intro t ht
    have hlag := lag_order_bounds (hc j (by omega)) hn hprev.1 (σ j) t (hσ j hjN) ht
    exact ⟨hlag.1,hlag.2.trans (hprev.2 t ht).2⟩

end MIACE
