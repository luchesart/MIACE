import MIACE.IMCTransferFormula

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:command_cone/full_statement
theorem paper_command_cone (N : ℕ) (σ : ℕ → ℝ) (x : ℕ → ℝ → ℝ)
    {v : ℝ → ℝ} {δ : ℝ} (hδ : 0≤δ)
    (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1)
    (hx : ∀ j≤N, LagResponse (σ j) (x j) (x (j+1))) (hw : x 0=fun t => 1+v t)
    (h : TransferResponse (delayedError δ (fun t => 1-x (N+1) t)) v (cascadeTransfer σ (N+1)) δ)
    (hn : ∀ᵐ t ∂halfLine, 0≤v t) :
    let e := delayedError δ (fun t => 1-x (N+1) t)
    ((∀ t, 0≤t → 1-e t≤1) ↔ Integrable (fun t => Real.exp t*v t) halfLine ∧ moment v≤1) ∧
    ((Monotone (fun t => 1-e t) ∧ 1-e 0=0 ∧ Tendsto (fun t => 1-e t) atTop (𝓝 1)) ↔
      Integrable (fun t => Real.exp t*v t) halfLine ∧ moment v≤1) ∧
    (Integrable (fun t => Real.exp t*v t) halfLine → moment v≤1 →
      0≤commandArea v ∧ commandArea v<1 ∧ absArea v halfLine=commandArea v ∧
      absArea e halfLine=cascadeMean σ (N+1)+δ-commandArea v) ∧
    ∀ U : ℝ, 0≤U → U<1 → ∃ F : IMCFilter, ∃ vU : ℝ → ℝ,
      NominalCascadeIMC N σ F δ vU ∧
      (∀ t, 0≤vU t) ∧ (∀ t, 0≤t → 0≤cascadeStepError N σ δ vU t) ∧
      Monotone (fun t => 1-cascadeStepError N σ δ vU t) ∧
      1-cascadeStepError N σ δ vU 0=0 ∧
      Tendsto (fun t => 1-cascadeStepError N σ δ vU t) atTop (𝓝 1) ∧
      absArea vU halfLine=U ∧
      absArea (cascadeStepError N σ δ vU) halfLine=cascadeMean σ (N+1)+δ-U := by
  have heq := cascade_signal_cone N σ x hδ hσ hfirst hx hw h.command_integrable hn h.error_integrable
  exact ⟨heq.1,heq.2,fun hJ hM => cascade_cone_areas N σ x hδ hσ hfirst hx hw h
    (cascadeTransfer_derivative σ (N+1)) (cascadeTransfer_zero σ (N+1)) hn hJ hM,
    fun U hU hU1 => paper_cascade_front_realization N σ hδ hU hU1 hσ hfirst⟩

-- @paper-step thm:complete_attainment/full_statement
theorem paper_complete_attainment_full (N : ℕ) (σ : ℕ → ℝ) {δ α : ℝ}
    (hδ : 0≤δ) (hα : 0<α) (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1) :
    let S := cascadeMean σ (N+1)+δ
    let a := 1-S/(1+α)
    let ss := serialRatios σ N
    ((∃ F : IMCFilter, ∃ v : ℝ → ℝ, NominalCascadeIMC N σ F δ v ∧
      miace α (cascadeStepError N σ δ v) v halfLine=S*minimum α) ↔ S-1<α) ∧
    (S-1<α → ∃ ha : 0<a, NominalCascadeIMC N σ (exponentialIMC a ha) δ (imcExcess a) ∧
      miace α (cascadeStepError N σ δ (imcExcess a)) (imcExcess a) halfLine=S*minimum α ∧
      absArea (imcExcess a) halfLine=S/(1+α) ∧
      absArea (cascadeStepError N σ δ (imcExcess a)) halfLine=α*S/(1+α) ∧
      1+imcExcess a 0=1/a ∧ (∀ t, 0≤t → 1+imcExcess a t≤1/a) ∧
      ∀ p : ℝ, 0<p →
        laplace (shift δ (cascadeKernel ss)) p*filterTransfer (exponentialIMC a ha) p=
          Real.exp (-δ*p)/(restPolynomial ss p*(1+a*p)) ∧
        imcControllerTransfer (exponentialIMC a ha) (laplace (shift δ (cascadeKernel ss))) p=
          (1+p)*restPolynomial ss p/((1+a*p)*restPolynomial ss p-Real.exp (-δ*p))) := by
  refine ⟨paper_complete_attainment N σ hδ hα hσ hfirst,?_⟩
  intro hthreshold
  obtain ⟨ha,hF,heq,hAu,hAe,hpeak,hbound⟩ := paper_optimal_exponential_IMC N σ hδ hα hσ hfirst hthreshold
  refine ⟨ha,hF,heq,hAu,hAe,hpeak,hbound,?_⟩
  intro p hp
  have hs : ∀ τ∈serialRatios σ N, 0<τ := fun τ hτ => (serialRatios_normalized σ N hσ τ hτ).1
  exact ⟨exponentialIMC_output_transfer _ hs ha hδ hp.le,exponentialIMC_controller_transfer _ hs ha hδ hp⟩

-- @paper-step thm:complete_cap/full_statement
theorem paper_complete_cap (N : ℕ) (σ : ℕ → ℝ) {δ c α : ℝ}
    (hδ : 0≤δ) (hc : 0<c) (hα : 0<α) (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1) :
    let S := cascadeMean σ (N+1)+δ
    let Umax := c*Real.log (1+1/c)
    (∀ U : ℝ, (∃ F : IMCFilter, ∃ v : ℝ → ℝ, NominalCascadeIMC N σ F δ v ∧
      (∀ᵐ t ∂halfLine, 0≤v t ∧ v t≤c) ∧
      (∀ t, 0≤t → 0≤cascadeStepError N σ δ v t) ∧ commandArea v=U) ↔ 0≤U ∧ U≤Umax) ∧
    ((∃ F : IMCFilter, ∃ v : ℝ → ℝ, NominalCascadeIMC N σ F δ v ∧
      (∀ᵐ t ∂halfLine, 0≤v t ∧ v t≤c) ∧
      miace α (cascadeStepError N σ δ v) v halfLine=S*minimum α) ↔ S/(1+α)≤Umax) ∧
    (S/(1+α)≤Umax ↔ S/Umax-1≤α) ∧
    (∀ U : ℝ, 0≤U → U≤Umax → ∃ hT : 0≤U/c,
      NominalCascadeIMC N σ (pulseIMC c (U/c) hT) δ (pulse c (U/c))) ∧
    ∀ v : ℝ → ℝ, Integrable v → (∀ᵐ t ∂halfLine, 0≤v t ∧ v t≤c) →
      (∀ t, 0≤t → 0≤cascadeStepError N σ δ v t) → commandArea v=Umax →
      v=ᵐ[halfLine] pulse c (Real.log (1+1/c)) := by
  refine ⟨fun U => paper_complete_cap_areas N σ hδ hc hσ hfirst,
    paper_complete_cap_attainment N σ hδ hc hα hσ hfirst,capped_attainment_weight_iff hα hc,?_,?_⟩
  · intro U hU _
    exact ⟨div_nonneg hU hc.le,pulse_cascade_IMC N σ c hδ (div_nonneg hU hc.le) hσ hfirst⟩
  · intro v hv hcap he harea
    exact paper_complete_cap_unique N σ hδ hc hσ hfirst hv hcap he harea

-- @paper-step thm:complete_robust/full_two_family_statement
theorem paper_complete_robust_families (N : ℕ) (σ : ℕ → ℝ) {δ ε α : ℝ}
    (hδ : 0≤δ) (hδε : 0≤δ+ε) (hα : 0≤α)
    (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1) :
    (∀ a : ℝ, ∀ ha : 0<a, a≤1 → 2*(2/a-1)*(1-Real.exp (-|ε|))<1 →
      IMCDelayRobust N σ (exponentialIMC a ha) δ ε α (imcExcess a) (2/a-1)) ∧
    (∀ c T : ℝ, 0<c → ∀ hT : 0<T, c*(Real.exp T-1)≤1 →
      2*(1+2*c)*(1-Real.exp (-|ε|))<1 →
      IMCDelayRobust N σ (pulseIMC c T hT.le) δ ε α (pulse c T) (1+2*c)) := by
  exact ⟨fun a ha ha1 hq => paper_exponential_delay_robust N σ hδ hδε hα ha ha1 hσ hfirst hq,
    fun c T hc hT hJ hq => paper_pulse_delay_robust N σ hδ hδε hα hc hT hJ hσ hfirst hq⟩

end MIACE
