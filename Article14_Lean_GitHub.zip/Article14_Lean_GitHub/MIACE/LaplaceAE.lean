import MIACE.StateTransforms

/-! Етап 12: единственост на действителния Лапласов интеграл за L¹ класове.
    Примитивната функция е непрекъсната; теоремата на Лебег възстановява
    първоначалния сигнал почти навсякъде. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:pid_two_rate_optimum/laplace_L1_zero_uniqueness
theorem laplace_zero_ae {f : ℝ → ℝ} (hf : Integrable f)
    (hz : ∀ p : ℝ, 0<p → laplace f p=0) : f=ᵐ[halfLine] (fun _ => 0) := by
  let F := fun t => ∫ s in 0..t, f s
  have hFc : Continuous F := intervalIntegral.continuous_primitive
    (fun a b => hf.intervalIntegrable) 0
  have hF : ∀ t, 0≤t → F t=0 := by
    apply laplace_injective_weighted (a := 1)
      (primitive_laplace (hf.mono_measure Measure.restrict_le_self) (by norm_num : (0 : ℝ)<1)).1
      (by simpa using (integrable_zero : Integrable (fun _ : ℝ => (0 : ℝ)) halfLine))
      hFc continuous_const
    intro p hp
    have hp0 : 0<p := by linarith
    change laplace (fun t => ∫ s in 0..t, f s) p=laplace (fun _ => 0) p
    rw [(primitive_laplace (hf.mono_measure Measure.restrict_le_self) hp0).2,hz p hp0]
    simp [laplace]
  have hder := LocallyIntegrable.ae_hasDerivAt_integral hf.locallyIntegrable
  have hd := hder.filter_mono (ae_mono (Measure.restrict_le_self (s := Ioi (0 : ℝ))))
  filter_upwards [hd,ae_restrict_mem measurableSet_Ioi] with t ht ht0
  have he : (fun _ : ℝ => (0 : ℝ)) =ᶠ[𝓝 t] F := by
    filter_upwards [eventually_gt_nhds (show 0<t from ht0)] with s hs
    exact (hF s hs.le).symm
  exact (ht 0).congr_of_eventuallyEq he |>.unique (hasDerivAt_const t (0 : ℝ))

-- @paper-step thm:pid_two_rate_optimum/laplace_L1_injectivity
theorem laplace_injective_ae {f g : ℝ → ℝ} (hf : Integrable f) (hg : Integrable g)
    (he : ∀ p : ℝ, 0<p → laplace f p=laplace g p) : f=ᵐ[halfLine] g := by
  have hz := laplace_zero_ae (hf.sub hg) (fun p hp => by
    unfold laplace
    simp_rw [Pi.sub_apply,mul_sub]
    rw [integral_sub (laplace_integrable (hf.mono_measure Measure.restrict_le_self) hp.le)
      (laplace_integrable (hg.mono_measure Measure.restrict_le_self) hp.le)]
    exact sub_eq_zero.mpr (he p hp))
  filter_upwards [hz] with t ht
  exact sub_eq_zero.mp ht

-- @paper-step thm:pid_two_rate_optimum/weighted_L1_laplace_injectivity
theorem laplace_injective_weighted_ae {f g : ℝ → ℝ} {a : ℝ}
    (hf : Integrable (expWeight (-a) (causalize f)))
    (hg : Integrable (expWeight (-a) (causalize g)))
    (he : ∀ p : ℝ, a<p → laplace f p=laplace g p) : f=ᵐ[halfLine] g := by
  have hs (F : ℝ → ℝ) (p : ℝ) :
      laplace (expWeight (-a) (causalize F)) p=laplace F (p+a) := by
    apply integral_congr_ae
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    have ht' : t∈Ici (0 : ℝ) := (show 0<t from ht).le
    simp only [expWeight,causalize,indicator_of_mem ht']
    rw [← mul_assoc,← Real.exp_add]
    congr 2
    ring
  have hh := laplace_injective_ae hf hg (fun p hp => by
    rw [hs,hs]
    exact he (p+a) (by linarith))
  filter_upwards [hh,ae_restrict_mem measurableSet_Ioi] with t ht ht0
  have ht' : t∈Ici (0 : ℝ) := (show 0<t from ht0).le
  simp only [expWeight,causalize,indicator_of_mem ht'] at ht
  exact mul_left_cancel₀ (ne_of_gt (Real.exp_pos _)) ht

-- @paper-step thm:pid_two_rate_optimum/continuous_bound_from_ae_bound
theorem continuous_halfLine_bound {f g : ℝ → ℝ} (hf : Continuous f) (hg : Continuous g)
    (he : ∀ᵐ t∂halfLine, f t≤g t) : ∀ t, 0≤t → f t≤g t := by
  have hh : (fun t => max (f t-g t) 0)=ᵐ[halfLine] (fun _ => 0) := by
    filter_upwards [he] with t ht
    exact max_eq_right (sub_nonpos.mpr ht)
  intro t ht
  have hz := continuous_halfLine_unique ((hf.sub hg).max continuous_const) continuous_const hh t ht
  simp only [Pi.sub_apply] at hz
  have hb := le_max_left (f t-g t) 0
  rw [hz] at hb
  linarith

end MIACE
