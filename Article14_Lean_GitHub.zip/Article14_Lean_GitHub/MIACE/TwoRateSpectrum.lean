import MIACE.ComplexKernel

/-! Етап 8: точно комплексно разлагане и полуплоскост без корени.
    Изводът е спектрален; общата теорема за устойчивост на DDE остава отделна. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def pidCharacteristic (i ρ ell δ : ℝ) (p : ℂ) : ℂ :=
  p*(1+(ρ : ℂ)*p)+(i : ℂ)*(1+(ell : ℂ)*p)*Complex.exp (-(δ : ℂ)*p)

-- @paper-step thm:pid_two_rate_optimum/complex_forcing_partial_fractions
theorem twoRate_complex_fraction {ρ l m : ℝ} (hρ : ρ ≠ 0) (hlm : l ≠ m)
    {p : ℂ} (hlp : p+(l : ℂ) ≠ 0) (hmp : p+(m : ℂ) ≠ 0) :
    (twoRateA ρ l m : ℂ)/(p+l)+(1-(twoRateA ρ l m : ℂ))/(p+m)=
      (1+(ρ : ℂ)*p)/((ρ : ℂ)*(p+l)*(p+m)) := by
  unfold twoRateA
  have hr : (ρ : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hρ
  have hd : (m : ℂ)-(l : ℂ) ≠ 0 := by exact_mod_cast sub_ne_zero.mpr hlm.symm
  push_cast
  field_simp
  <;> ring

-- @paper-step thm:pid_two_rate_optimum/complex_shifted_residues
theorem twoRate_complex_shifted_fraction {i ρ ell l m δ : ℝ}
    (h : TwoRateData i ρ ell l m δ) {p : ℂ}
    (hlp : p+(l : ℂ) ≠ 0) (hmp : p+(m : ℂ) ≠ 0) :
    (l : ℂ)*twoRateA ρ l m*Complex.exp (-(l : ℂ)*δ)/(p+l)+
      (m : ℂ)*(1-(twoRateA ρ l m : ℂ))*Complex.exp (-(m : ℂ)*δ)/(p+m)=
        (i : ℂ)*(1+(ell : ℂ)*p)/((ρ : ℂ)*(p+l)*(p+m)) := by
  have hr₁ := congrArg Complex.ofReal
    (twoRate_first_residue (ne_of_gt h.filter_pos) (ne_of_lt h.ordered_rates) h.root_l)
  have hr₂ := congrArg Complex.ofReal
    (twoRate_second_residue (ne_of_gt h.filter_pos) (ne_of_lt h.ordered_rates) h.root_m)
  push_cast at hr₁ hr₂
  rw [hr₁,hr₂]
  have hr : (ρ : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr (ne_of_gt h.filter_pos)
  have hd : (m : ℂ)-(l : ℂ) ≠ 0 := by exact_mod_cast sub_ne_zero.mpr (ne_of_gt h.ordered_rates)
  field_simp
  <;> ring

-- @paper-step thm:pid_two_rate_optimum/complex_characteristic_factorization
theorem twoRate_complex_characteristic_factor {i ρ ell l m δ : ℝ}
    (h : TwoRateData i ρ ell l m δ) {p : ℂ}
    (hlp : p+(l : ℂ) ≠ 0) (hmp : p+(m : ℂ) ≠ 0) :
    pidCharacteristic i ρ ell δ p=
      (ρ : ℂ)*(p+l)*(p+m)*(1-complexLaplace (twoRateK (twoRateA ρ l m) l m δ) p) := by
  let A : ℂ := (twoRateA ρ l m : ℂ)
  have hk : 1-complexLaplace (twoRateK (twoRateA ρ l m) l m δ) p=
      p*(A/(p+l)+(1-A)/(p+m))+Complex.exp (-(δ : ℂ)*p)*
        ((l : ℂ)*A*Complex.exp (-(l : ℂ)*δ)/(p+l)+
          (m : ℂ)*(1-A)*Complex.exp (-(m : ℂ)*δ)/(p+m)) := by
    rw [twoRateK_complex_laplace _ _ _ h.delay_nonneg hlp hmp]
    have h₁ : Complex.exp (-(p+l)*(δ : ℂ))=Complex.exp (-(δ : ℂ)*p)*Complex.exp (-(l : ℂ)*δ) := by
      rw [← Complex.exp_add]; congr 1; ring
    have h₂ : Complex.exp (-(p+m)*(δ : ℂ))=Complex.exp (-(δ : ℂ)*p)*Complex.exp (-(m : ℂ)*δ) := by
      rw [← Complex.exp_add]; congr 1; ring
    rw [h₁,h₂]
    dsimp only [A]
    field_simp
    <;> ring
  rw [hk,twoRate_complex_fraction (ne_of_gt h.filter_pos) (ne_of_lt h.ordered_rates) hlp hmp,
    twoRate_complex_shifted_fraction h hlp hmp]
  unfold pidCharacteristic
  field_simp [Complex.ofReal_ne_zero.mpr (ne_of_gt h.filter_pos)]
  <;> ring

-- @paper-step thm:pid_two_rate_optimum/shifted_complex_rate_nonzero
theorem complex_rate_ne_zero {η r : ℝ} (hr : η < r) {p : ℂ} (hp : -η ≤ p.re) :
    p+(r : ℂ) ≠ 0 := by
  intro hz
  have he := congrArg Complex.re hz
  simp only [Complex.add_re,Complex.ofReal_re,Complex.zero_re] at he
  linarith

-- @paper-step thm:pid_two_rate_optimum/complex_zero_free_half_plane
theorem twoRate_zero_free_half_plane {i ρ ell l m δ : ℝ} (h : TwoRateData i ρ ell l m δ) :
    ∃ η : ℝ, 0 < η ∧ η ≤ 1/2 ∧
      ∀ p : ℂ, -η ≤ p.re →
        ‖complexLaplace (twoRateK (twoRateA ρ l m) l m δ) p‖<1 ∧
        pidCharacteristic i ρ ell δ p ≠ 0 ∧
        (p+1)*pidCharacteristic i ρ ell δ p/(ρ : ℂ) ≠ 0 := by
  let A := twoRateA ρ l m
  have hK := twoRateK_integrable A l m δ
  have hc := twoRateK_causal A l m δ
  have hA := twoRateA_ge_one h.ordered_rates h.filter_lower
  have hn : ∀ᵐ t, 0 ≤ twoRateK A l m δ t := ae_of_all volume
    (twoRateK_nonneg hA h.lower_rate h.ordered_rates.le
      (twoRate_rate_condition h.ordered_rates h.filter_upper))
  obtain ⟨η,hη,hle,hw,hq⟩ := expWeight_small_mass hK
    (twoRateK_small hA h.ordered_rates.le h.delay_nonneg)
    (by norm_num : (0 : ℝ)<1/2) (twoRateK_weighted A l m δ (1/2))
  refine ⟨η,hη,hle,?_⟩
  intro p hp
  have hlp := complex_rate_ne_zero (by linarith [h.lower_rate] : η<l) hp
  have hmp := complex_rate_ne_zero (by linarith [h.lower_rate,h.ordered_rates] : η<m) hp
  have h1p : p+1 ≠ 0 := by simpa using complex_rate_ne_zero (by linarith : η<(1 : ℝ)) hp
  have hr : (ρ : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr (ne_of_gt h.filter_pos)
  have hchar : pidCharacteristic i ρ ell δ p ≠ 0 := by
    rw [twoRate_complex_characteristic_factor h hlp hmp]
    exact mul_ne_zero (mul_ne_zero (mul_ne_zero hr hlp) hmp)
      (complex_resolvent_ne_zero hc hn hw hq hp)
  exact ⟨(complex_laplace_norm_le hc hn hw hp).trans_lt hq,hchar,
    div_ne_zero (mul_ne_zero h1p hchar) hr⟩

end MIACE
