import MIACE.Causal

/-! Етап 6: пълната положителна резолвента, включително същото решение в
експоненциално претегленото пространство. Единствеността е в L¹ (т.е. ae). -/
set_option maxHeartbeats 1200000

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step lem:pid_positive_resolvent/causal_ae_invariance
theorem causal_congr {f g : ℝ → ℝ} (hf : Causal f) (he : f =ᵐ[volume] g) : Causal g := by
  filter_upwards [hf,he] with t ht he hn
  rw [← he]
  exact ht hn

-- @paper-step lem:pid_positive_resolvent/weighted_solution_identification
theorem weighted_renewal_identification {K : ℝ → ℝ} (hK : Integrable K)
    {η : ℝ} (hη : 0 ≤ η) (hKw : Integrable (expWeight η K) volume)
    (g z Z : RealL1) (hgw : Integrable (expWeight η g) volume)
    (hZc : Causal Z)
    (hZ : Z = hgw.toL1 (expWeight η g)+convOp hKw Z)
    (huniq : ∀ z' : RealL1, z'=g+convOp hK z' → z'=z) :
    Integrable (expWeight η z) volume ∧
      (expWeight η z =ᵐ[volume] (Z : ℝ → ℝ)) := by
  let f := expWeight (-η) (Z : ℝ → ℝ)
  have hf : Integrable f volume := expWeight_negative_integrable (L1.integrable_coeFn Z) hZc hη
  let z' := hf.toL1 f
  have hz' : z' =ᵐ[volume] f := hf.coeFn_toL1
  have hZae : (Z : ℝ → ℝ) =ᵐ[volume]
      (fun t => expWeight η g t+((expWeight η K) ⋆ (Z : ℝ → ℝ)) t) := by
    have hc := Lp.coeFn_add (hgw.toL1 (expWeight η g)) (convOp hKw Z)
    rw [← hZ] at hc
    filter_upwards [hc,hgw.coeFn_toL1,convOp_coe hKw Z] with t ht hg hconv
    simpa only [Pi.add_apply,hg,hconv] using ht
  have heq : f =ᵐ[volume] (fun t => g t+(K ⋆ f) t) := by
    have hid : expWeight (-η) (expWeight η K) = K := expWeight_inverse η K
    have hconv := congrFun (expWeight_convolution (-η) (expWeight η K) (Z : ℝ → ℝ))
    filter_upwards [hZae] with t ht
    change Real.exp (-η*t)*Z t = _
    rw [ht,mul_add]
    have hg := congrFun (expWeight_inverse η (g : ℝ → ℝ)) t
    change Real.exp (-η*t)*(Real.exp (η*t)*g t)=g t at hg
    change Real.exp (-η*t)*expWeight η g t = g t at hg
    rw [hg]
    have hh := hconv t
    rw [hid] at hh
    exact congrArg (fun a : ℝ => g t+a) hh
  have hzsol : z'=g+convOp hK z' := by
    apply Lp.ext
    have hconv := convolution_congr (ContinuousLinearMap.lsmul ℝ ℝ)
      (EventuallyEq.rfl (f := K)) hz'
    filter_upwards [hz',heq,Lp.coeFn_add g (convOp hK z'),convOp_coe hK z']
      with t ht hf hadd hconv'
    rw [ht,hadd]
    simp only [Pi.add_apply]
    rw [hconv',hconv]
    exact hf
  have hzz := huniq z' hzsol
  have hwz : expWeight η z =ᵐ[volume] (Z : ℝ → ℝ) := by
    have hinv : expWeight η f = (Z : ℝ → ℝ) := by
      simpa only [neg_neg] using expWeight_inverse (-η) (Z : ℝ → ℝ)
    rw [← hzz]
    filter_upwards [hz'] with t ht
    change Real.exp (η*t)*z' t=Z t
    rw [ht]
    exact congrFun hinv t
  exact ⟨(L1.integrable_coeFn Z).congr hwz.symm,hwz⟩

-- @paper-step lem:pid_positive_resolvent/weighted_series_same_solution
theorem positive_resolvent_weighted {K : ℝ → ℝ} (hK : Integrable K)
    (hKn : ∀ᵐ t, 0 ≤ K t) (hKc : Causal K) (hq : (∫ t, K t) < 1)
    {η : ℝ} (hη : 0 ≤ η) (hKw : Integrable (expWeight η K) volume)
    (hqw : (∫ t, expWeight η K t) < 1)
    (g : RealL1) (hgn : 0 ≤ g) (hgc : Causal g) (hgw : Integrable (expWeight η g) volume) :
    let z := (∑' n : ℕ, (convOp hK)^n) g
    ∃ hz : Integrable (expWeight η z) volume,
      HasSum (fun n : ℕ => ((convOp hKw)^n) (hgw.toL1 (expWeight η g)))
        (hz.toL1 (expWeight η z)) ∧
      ‖hz.toL1 (expWeight η z)‖ ≤
        ‖hgw.toL1 (expWeight η g)‖/(1-(∫ t, expWeight η K t)) := by
  dsimp only
  let gw := hgw.toL1 (expWeight η g)
  have hgwn : 0 ≤ gw := by
    rw [← Lp.coeFn_nonneg] at hgn ⊢
    filter_upwards [hgw.coeFn_toL1,hgn] with t ht hn
    rw [ht]
    exact mul_nonneg (Real.exp_nonneg _) hn
  have hgwc : Causal gw := causal_congr (expWeight_causal η hgc) hgw.coeFn_toL1.symm
  have hKwn : ∀ᵐ t, 0 ≤ expWeight η K t := by
    filter_upwards [hKn] with t ht
    exact mul_nonneg (Real.exp_nonneg _) ht
  obtain ⟨hs,_,he,_,hn⟩ := renewal_l1 hKw hKwn hqw gw hgwn
  let Z := (∑' n : ℕ, (convOp hKw)^n) gw
  have hsmall : ‖convOp hKw‖ < 1 := by
    have hh := convOp_norm hKw
    rw [positive_kernel_mass hKwn] at hh
    exact hh.trans_lt hqw
  have hc : Causal Z := causal_renewal_series hKw (expWeight_causal η hKc) hsmall hgwc
  have hu := (renewal_l1 hK hKn hq g hgn).2.2.2.1
  obtain ⟨hz,hze⟩ := weighted_renewal_identification hK hη hKw g _ Z hgw hc he hu
  have heq : hz.toL1 _ = Z := by
    apply Lp.ext
    exact hz.coeFn_toL1.trans hze
  exact ⟨hz,heq.symm ▸ hs,heq.symm ▸ hn⟩

-- @paper-step lem:pid_positive_resolvent/operator_statement
theorem positive_resolvent_all_parts {K : ℝ → ℝ} (hK : Integrable K)
    (hKn : ∀ᵐ t, 0 ≤ K t) (hKc : Causal K) (hq : (∫ t, K t) < 1)
    (g : RealL1) (hgn : 0 ≤ g) (hgc : Causal g) :
    let T := convOp hK
    let z := (∑' n : ℕ, T^n) g
    HasSum (fun n : ℕ => (T^n) g) z ∧
      0 ≤ z ∧ Causal z ∧ z=g+T z ∧
      (∀ z' : RealL1, z'=g+T z' → z'=z) ∧
      ‖z‖ ≤ ‖g‖/(1-(∫ t, K t)) ∧
      (∀ β : ℝ, 0 < β → Integrable (expWeight β K) volume →
        ∃ η : ℝ, ∃ hKw : Integrable (expWeight η K) volume,
          0 < η ∧ η ≤ β ∧ (∫ t, expWeight η K t) < 1 ∧
          (∀ hgw : Integrable (expWeight η g) volume,
            ∃ hz : Integrable (expWeight η z) volume,
              HasSum (fun n : ℕ => ((convOp hKw)^n) (hgw.toL1 (expWeight η g)))
                (hz.toL1 (expWeight η z)))) := by
  dsimp only
  obtain ⟨hs,hp,he,hu,hn⟩ := renewal_l1 hK hKn hq g hgn
  have hsmall : ‖convOp hK‖ < 1 := by
    have hh := convOp_norm hK
    rw [positive_kernel_mass hKn] at hh
    exact hh.trans_lt hq
  refine ⟨hs,hp,causal_renewal_series hK hKc hsmall hgc,he,hu,hn,?_⟩
  intro β hβ hw
  obtain ⟨η,hη,hle,hKw,hqw⟩ := expWeight_small_mass hK hq hβ hw
  refine ⟨η,hKw,hη,hle,hqw,?_⟩
  intro hgw
  obtain ⟨hz,hs,_⟩ := positive_resolvent_weighted hK hKn hKc hq hη.le hKw hqw g hgn hgc hgw
  exact ⟨hz,hs⟩

end MIACE
