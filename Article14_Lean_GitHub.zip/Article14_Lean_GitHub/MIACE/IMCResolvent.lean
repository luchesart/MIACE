import MIACE.CascadeEvolution
import MIACE.SmallGain

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

noncomputable def delayMismatchKernel (ss : List ℝ) (δ ε : ℝ) (t : ℝ) : ℝ :=
  shift (δ+ε) (cascadeKernel ss) t-shift δ (cascadeKernel ss) t
noncomputable def imcLoopKernel (F : IMCFilter) (ss : List ℝ) (δ ε : ℝ) (t : ℝ) : ℝ :=
  -filterAction F (delayMismatchKernel ss δ ε) t
noncomputable def imcDelayGain (F : IMCFilter) (ε : ℝ) : ℝ :=
  2*filterGain F*(1-Real.exp (-|ε|))

-- @paper-step thm:complete_robust/actual_loop_integrability_and_causality
theorem imcLoopKernel_properties (F : IMCFilter) (ss : List ℝ)
    (hs : ∀ σ∈ss, 0<σ) {δ ε : ℝ} (hδ : 0≤δ) (hδε : 0≤δ+ε) :
    Integrable (imcLoopKernel F ss δ ε) ∧ Causal (imcLoopKernel F ss δ ε) ∧
      absArea (imcLoopKernel F ss δ ε) volume ≤ imcDelayGain F ε := by
  have hP := cascadeKernel_properties ss hs
  have hD : Integrable (delayMismatchKernel ss δ ε) :=
    (shift_integrable (δ+ε) hP.1).sub (shift_integrable δ hP.1)
  have hDc : Causal (delayMismatchKernel ss δ ε) := by
    filter_upwards [causal_shift hP.2.2.2 hδε,causal_shift hP.2.2.2 hδ] with t ht hs hn
    simp [delayMismatchKernel,ht hn,hs hn]
  refine ⟨(filterAction_integrable F hD).neg,?_,?_⟩
  · filter_upwards [filterAction_causal F hDc] with t ht hn
    simp [imcLoopKernel,ht hn]
  · have hh := delay_mismatch_filter_bound F ss hs δ ε
    unfold imcLoopKernel absArea
    simp_rw [abs_neg]
    exact hh

-- @paper-step thm:complete_robust/actual_loop_exponential_moment
theorem imcLoopKernel_weighted (F : IMCFilter) (ss : List ℝ)
    (hs : ∀ σ∈ss, 0<σ ∧ σ≤1) (δ ε : ℝ) :
    ∃ β C : ℝ, 0<β ∧ β≤1/2 ∧ β<1/F.timeConstant ∧
      WeightedControl β (imcLoopKernel F ss δ ε) C := by
  let β := min (1/2) (1/(2*F.timeConstant))
  have hβ : 0<β := lt_min (by norm_num) (by have := F.timeConstant_pos; positivity)
  have hb1 : β≤1/2 := min_le_left _ _
  have hb2 : β<1/F.timeConstant := by
    have hh : (1 : ℝ)/(2*F.timeConstant)<1/F.timeConstant := by
      apply (div_lt_div_iff₀ (by have := F.timeConstant_pos; positivity) F.timeConstant_pos).mpr
      nlinarith [F.timeConstant_pos]
    exact (min_le_right _ _).trans_lt hh
  obtain ⟨C,hC⟩ := cascadeKernel_weightedControl ss (show β<1 by linarith)
    (fun σ hσ => ⟨(hs σ hσ).1,by
      have h1 : (1 : ℝ)≤1/σ := (le_div_iff₀ (hs σ hσ).1).mpr (by simpa using (hs σ hσ).2)
      linarith⟩)
  obtain ⟨D,hD⟩ := lagKernel_weightedControl F.timeConstant_pos hb2
  have hK := weightedControl_smul (filterAction_weightedControl F hD
    (delay_mismatch_weightedControl ss (δ := δ) (ε := ε) hC)) (-1)
  have hK' := weightedControl_congr hK (g := imcLoopKernel F ss δ ε)
    (ae_of_all _ (fun t => by
      change (-1)*filterAction F (delayMismatchKernel ss δ ε) t= -filterAction F (delayMismatchKernel ss δ ε) t
      ring))
  exact ⟨β,_,hβ,hb1,hb2,hK'⟩

structure IMCLoopCertificate (F : IMCFilter) (ss : List ℝ) (δ ε η C : ℝ) : Prop where
  exponent_pos : 0<η
  exponent_half : η≤1/2
  exponent_filter : η<1/F.timeConstant
  integrable : Integrable (imcLoopKernel F ss δ ε)
  causal : Causal (imcLoopKernel F ss δ ε)
  small : absArea (imcLoopKernel F ss δ ε) volume<1
  control : WeightedControl η (imcLoopKernel F ss δ ε) C
  weighted_small : absArea (expWeight η (imcLoopKernel F ss δ ε)) volume<1

-- @paper-step thm:complete_robust/concrete_weighted_small_gain_certificate
theorem imc_loop_certificate (F : IMCFilter) (ss : List ℝ)
    (hs : ∀ σ∈ss, 0<σ ∧ σ≤1) {δ ε : ℝ} (hδ : 0≤δ) (hδε : 0≤δ+ε)
    (hq : imcDelayGain F ε<1) :
    ∃ η C : ℝ, IMCLoopCertificate F ss δ ε η C := by
  have hp := imcLoopKernel_properties F ss (fun σ hσ => (hs σ hσ).1) hδ hδε
  have hsmall := hp.2.2.trans_lt hq
  obtain ⟨β,C,hβ,hβhalf,hβF,hKC⟩ := imcLoopKernel_weighted F ss hs δ ε
  obtain ⟨η,hw,hη,hηβ,hqw,_⟩ := weighted_small_gain hp.1 hsmall hβ hKC.integrable
  exact ⟨η,C,⟨hη,hηβ.trans hβhalf,hηβ.trans_lt hβF,hp.1,hp.2.1,hsmall,
    weightedControl_lower hKC hp.2.1 hη.le hηβ,hqw⟩⟩

-- The resulting solution is unique even among locally integrable competing
-- evolutions, not only in the weighted Banach space used to construct it.
-- @paper-step thm:complete_robust/ordinary_loop_existence_decay_and_uniqueness
theorem imc_ordinary_loop {F : IMCFilter} {ss : List ℝ} {δ ε η C D : ℝ}
    (h : IMCLoopCertificate F ss δ ε η C) {f : ℝ → ℝ}
    (hf : WeightedControl η f D) (hfc : Causal f) :
    ∃ u : ℝ → ℝ, Integrable u ∧ Causal u ∧
      u=ᵐ[volume] (fun t => f t+(imcLoopKernel F ss δ ε ⋆ u) t) ∧
      WeightedControl η u (((1+C)/(1-absArea (expWeight η (imcLoopKernel F ss δ ε)) volume))*D) ∧
      ∀ v : ℝ → ℝ, LocallyIntegrable v volume → Causal v →
        v=ᵐ[volume] (fun t => f t+(imcLoopKernel F ss δ ε ⋆ v) t) → v=ᵐ[volume] u := by
  let hfi := weightedControl_unweighted hf hfc h.exponent_pos.le
  let g := hfi.toL1 f
  let u := (∑' n : ℕ, (convOp h.integrable)^n) g
  obtain ⟨hc,he,hu⟩ := weightedControl_renewal h.exponent_pos.le h.integrable h.causal h.small
    h.control h.weighted_small hf hfc
  have heq : (u : ℝ → ℝ)=ᵐ[volume] (fun t => f t+(imcLoopKernel F ss δ ε ⋆ (u : ℝ → ℝ)) t) := by
    filter_upwards [signed_renewal_representative h.integrable h.small g,hfi.coeFn_toL1] with t ht hft
    simpa only [g,hft] using ht
  refine ⟨u,L1.integrable_coeFn u,hc,heq,hu,?_⟩
  intro v hv hvc hve
  exact local_renewal_unique h.integrable h.causal h.small hv (L1.integrable_coeFn u).locallyIntegrable
    hvc hc hve heq

end MIACE
