import MIACE.TwoRateRegularity

/-! Етап 9: от претеглената L¹ резолвента до точкова експоненциална оценка.
    Константата е изведена от компактното ядро и действителния интеграл на входа. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:pid_two_rate_optimum/compact_weighted_kernel_bound
theorem twoRateK_weighted_bound (A l m δ η : ℝ) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ t : ℝ, |expWeight η (twoRateK A l m δ) t| ≤ C := by
  have hc : Continuous (fun t => Real.exp (η*t)*twoRateD A l m t) :=
    (by fun_prop : Continuous (fun t : ℝ => Real.exp (η*t))).mul (twoRate_continuous A l m).2
  obtain ⟨C,hC⟩ := isCompact_Icc.exists_bound_of_continuousOn hc.continuousOn
  refine ⟨max C 0,le_max_right _ _,?_⟩
  intro t
  by_cases ht : t∈Ico (0 : ℝ) δ
  · simp only [expWeight,twoRateK,indicator_of_mem ht]
    exact (hC t ⟨ht.1,ht.2.le⟩).trans (le_max_left _ _)
  · simp [expWeight,twoRateK,ht]

-- @paper-step thm:pid_two_rate_optimum/weighted_convolution_pointwise_bound
theorem convolution_weighted_pointwise_bound {K f : ℝ → ℝ} {η C : ℝ}
    (hC : 0 ≤ C) (hK : ∀ s : ℝ, |expWeight η K s| ≤ C)
    (hf : Integrable (expWeight η f)) (t : ℝ) :
    |(K ⋆ f) t| ≤ (C*(∫ s, |expWeight η f s|))*Real.exp (-η*t) := by
  have hb : |((expWeight η K) ⋆ (expWeight η f)) t| ≤ C*(∫ s, |expWeight η f s|) := by
    change ‖∫ s, expWeight η K s*expWeight η f (t-s)‖ ≤ _
    have hn := norm_integral_le_of_norm_le ((hf.abs.comp_sub_left t).const_mul C)
      (ae_of_all volume (fun s => show ‖expWeight η K s*expWeight η f (t-s)‖ ≤
        C*|expWeight η f (t-s)| from by
          rw [Real.norm_eq_abs,abs_mul]
          exact mul_le_mul_of_nonneg_right (hK s) (abs_nonneg _)))
    rw [integral_const_mul,integral_sub_left_eq_self (fun s => |expWeight η f s|) volume t] at hn
    exact hn
  have he : (K ⋆ f) t=Real.exp (-η*t)*((expWeight η K) ⋆ (expWeight η f)) t := by
    rw [← expWeight_convolution]
    have hi := congrFun (expWeight_inverse η (K ⋆ f)) t
    exact hi.symm
  rw [he,abs_mul,abs_of_pos (Real.exp_pos _)]
  nlinarith [Real.exp_pos (-η*t)]

-- @paper-step thm:pid_two_rate_optimum/exponential_pair_decay_bound
theorem exp_pair_decay_bound (C D : ℝ) {l m η t : ℝ}
    (hl : η ≤ l) (hm : η ≤ m) (ht : 0 ≤ t) :
    |C*Real.exp (-l*t)+D*Real.exp (-m*t)| ≤ (|C|+|D|)*Real.exp (-η*t) := by
  have h₁ := Real.exp_le_exp.mpr (show -l*t≤-η*t by nlinarith)
  have h₂ := Real.exp_le_exp.mpr (show -m*t≤-η*t by nlinarith)
  calc
    _ ≤ |C*Real.exp (-l*t)|+|D*Real.exp (-m*t)| := abs_add_le _ _
    _ = |C| *Real.exp (-l*t)+|D| *Real.exp (-m*t) := by
      rw [abs_mul,abs_mul,abs_of_pos (Real.exp_pos _),abs_of_pos (Real.exp_pos _)]
    _ ≤ _ := by nlinarith [abs_nonneg C,abs_nonneg D]

-- @paper-step thm:pid_two_rate_optimum/command_forcing_pointwise_decay
theorem twoRateR_decay_bound (A : ℝ) {l m δ η t : ℝ}
    (hl : η ≤ l) (hm : η ≤ m) (hδ : 0 ≤ δ) (hη : 0 ≤ η) (ht : 0 ≤ t) :
    |twoRateR A l m δ t| ≤
      (|l*A|+|m*(1-A)|+3*(|A|+|1-A|))*Real.exp (-η*t) := by
  have hb (s : ℝ) (hs : t ≤ s) : |twoRateG A l m s| ≤ (|A|+|1-A|)*Real.exp (-η*t) := by
    exact (exp_pair_decay_bound A (1-A) hl hm (ht.trans hs)).trans
      (mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (by nlinarith)) (by positivity))
  have hd : |twoRateD A l m (t+δ)| ≤ (|l*A|+|m*(1-A)|)*Real.exp (-η*t) := by
    exact (exp_pair_decay_bound (l*A) (m*(1-A)) hl hm (by linarith : 0≤t+δ)).trans
      (mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (by nlinarith)) (by positivity))
  have h₁ := hb (t+δ) (by linarith)
  have h₂ := hb (max δ t) (le_max_right _ _)
  have h₃ := hb t le_rfl
  have hh := abs_sub_le (twoRateD A l m (t+δ)-twoRateG A l m (t+δ)+twoRateG A l m (max δ t)) 0 (twoRateG A l m t)
  have hh₂ := abs_add_le (twoRateD A l m (t+δ)-twoRateG A l m (t+δ)) (twoRateG A l m (max δ t))
  have hh₃ := abs_sub_le (twoRateD A l m (t+δ)) 0 (twoRateG A l m (t+δ))
  simp only [sub_zero,zero_sub,abs_neg] at hh hh₃
  unfold twoRateR
  nlinarith

-- @paper-step thm:pid_two_rate_optimum/ordinary_representatives_exponential_bound
theorem twoRate_representatives_decay {i ρ ell l m δ : ℝ} (h : TwoRateData i ρ ell l m δ)
    {e v : RealL1} {η : ℝ} (hη : 0<η) (hηb : η≤1/2)
    (he : Integrable (expWeight η e) volume) (hv : Integrable (expWeight η v) volume) :
    ∃ Ce Cv : ℝ, 0 ≤ Ce ∧ 0 ≤ Cv ∧ ∀ t : ℝ, 0 ≤ t →
      |twoRateErrorRep (twoRateA ρ l m) l m δ e t| ≤ Ce*Real.exp (-η*t) ∧
      |twoRateCommandRep (twoRateA ρ l m) l m δ v t| ≤ Cv*Real.exp (-η*t) := by
  let A := twoRateA ρ l m
  obtain ⟨C,hC,hK⟩ := twoRateK_weighted_bound A l m δ η
  let Ce := |A|+|1-A|+C*(∫ s, |expWeight η e s|)
  let Cv := |l*A|+|m*(1-A)|+3*(|A|+|1-A|)+C*(∫ s, |expWeight η v s|)
  have hl : η≤l := by linarith [h.lower_rate]
  have hm : η≤m := by linarith [h.lower_rate,h.ordered_rates]
  refine ⟨Ce,Cv,?_,?_,?_⟩
  · dsimp [Ce]; positivity
  · dsimp [Cv]; positivity
  · intro t ht
    constructor
    · have hg := exp_pair_decay_bound A (1-A) hl hm ht
      have hk := convolution_weighted_pointwise_bound hC hK he t
      have ha := abs_add_le (twoRateG A l m t) ((twoRateK A l m δ ⋆ (e : ℝ → ℝ)) t)
      change |twoRateG A l m t+(twoRateK A l m δ ⋆ (e : ℝ → ℝ)) t|≤_
      dsimp only [Ce]
      change |twoRateG A l m t|≤_ at hg
      nlinarith
    · have hr := twoRateR_decay_bound A hl hm h.delay_nonneg hη.le ht
      have hk := convolution_weighted_pointwise_bound hC hK hv t
      have ha := abs_add_le (twoRateR A l m δ t) ((twoRateK A l m δ ⋆ (v : ℝ → ℝ)) t)
      change |twoRateR A l m δ t+(twoRateK A l m δ ⋆ (v : ℝ → ℝ)) t|≤_
      dsimp only [Cv]
      nlinarith

-- @paper-step thm:pid_two_rate_optimum/exponential_bound_implies_settling
theorem tendsto_zero_of_exp_bound {f : ℝ → ℝ} {C η : ℝ} (hη : 0<η)
    (hb : ∀ t : ℝ, 0≤t → |f t|≤C*Real.exp (-η*t)) : Tendsto f atTop (𝓝 0) := by
  have he : Tendsto (fun t : ℝ => C*Real.exp (-η*t)) atTop (𝓝 0) := by
    have hh := Real.tendsto_exp_neg_atTop_nhds_zero.comp (tendsto_id.const_mul_atTop hη)
    simpa [neg_mul] using hh.const_mul C
  exact squeeze_zero_norm' (by filter_upwards [eventually_ge_atTop (0 : ℝ)] with t ht; exact hb t ht) he

end MIACE
