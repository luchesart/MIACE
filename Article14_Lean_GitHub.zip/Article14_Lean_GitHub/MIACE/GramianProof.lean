import MIACE.Gramian
import MIACE.PIExplicit

/-! Поправка: пътят от приложение A се проследява самостоятелно.
Първо се доказва сходимост от експоненциалната оценка; след това ОДУ
за произведенията дава уравнението на Ляпунов и едва тогава енергията. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step lem:h2/gramian_convergence_from_exponential_decay
theorem canonical_gramian_integrable {a b c : ℝ} {z w : ℝ → ℝ}
    (h : CanonicalImpulse a b c z w) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) :
    Integrable (fun t => (z t)^2) halfLine ∧ Integrable (fun t => z t*w t) halfLine ∧
    Integrable (fun t => (w t)^2) halfLine := by
  let K := (2*b/a)*stabilityV a b c (z 0) (w 0)
  let k := 1/stabilityC a b c
  have hC : 0 < stabilityC a b c := by unfold stabilityC; positivity
  have hk : 0 < k := by dsimp [k]; positivity
  have hbound : ∀ t : ℝ, 0 ≤ t → (z t)^2+(w t)^2 ≤ K*Real.exp (-k*t) :=
    canonical_exponential_bound ha hb hc h.ac_z h.ac_w h.ode_z h.ode_w
  have hmaj : Integrable (fun t : ℝ => K*Real.exp (-k*t)) halfLine :=
    (integrableOn_exp_mul_Ioi (by linarith : -k < 0) 0).const_mul K
  have hzm : AEStronglyMeasurable z halfLine := (local_ac_continuous h.ac_z).aestronglyMeasurable measurableSet_Ioi
  have hwm : AEStronglyMeasurable w halfLine := (local_ac_continuous h.ac_w).aestronglyMeasurable measurableSet_Ioi
  have hz2 : Integrable (fun t => (z t)^2) halfLine := by
    apply hmaj.mono' (hzm.pow 2)
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    change ‖(z t)^2‖ ≤ K*Real.exp (-k*t)
    rw [Real.norm_eq_abs,abs_sq]
    nlinarith [hbound t ht.le,sq_nonneg (w t)]
  have hw2 : Integrable (fun t => (w t)^2) halfLine := by
    apply hmaj.mono' (hwm.pow 2)
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    change ‖(w t)^2‖ ≤ K*Real.exp (-k*t)
    rw [Real.norm_eq_abs,abs_sq]
    nlinarith [hbound t ht.le,sq_nonneg (z t)]
  have hzw : Integrable (fun t => z t*w t) halfLine := by
    apply (hz2.add hw2).mono' (hzm.mul hwm)
    apply ae_of_all
    intro t
    change ‖z t*w t‖ ≤ (z t)^2+(w t)^2
    rw [Real.norm_eq_abs]
    apply abs_le.mpr
    constructor <;> nlinarith [sq_nonneg (z t-w t),sq_nonneg (z t+w t)]
  exact ⟨hz2,hzw,hw2⟩

-- @paper-step lem:h2/integrated_controllability_lyapunov_equation
theorem canonical_gramian_equations {a b c : ℝ} {z w : ℝ → ℝ}
    (h : CanonicalImpulse a b c z w) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) :
    let P11 := ∫ t, (z t)^2 ∂halfLine
    let P12 := ∫ t, z t*w t ∂halfLine
    let P22 := ∫ t, (w t)^2 ∂halfLine
    2*P12=0 ∧ P22-(c/a)*P11-(b/a)*P12=0 ∧
      -(2*c/a)*P12-(2*b/a)*P22+1/a^2=0 := by
  dsimp only
  obtain ⟨hz2,hzw,hw2⟩ := canonical_gramian_integrable h ha hb hc
  have hf := canonical_settles ha hb hc h.ac_z h.ac_w h.ode_z h.ode_w
  have hdz := local_ac_ae_differentiable h.ac_z
  have hdw := local_ac_ae_differentiable h.ac_w
  have ho1 : ∀ᵐ t : ℝ, 0 < t → deriv (fun s => (z s)^2) t=2*(z t*w t) := by
    filter_upwards [hdz,h.ode_z] with t hd ho ht
    have hh := (hd ht).hasDerivAt
    rw [ho ht] at hh
    have hp := hh.pow 2
    change HasDerivAt (fun s => (z s)^2) _ t at hp
    rw [hp.deriv]
    ring
  have ho2 : ∀ᵐ t : ℝ, 0 < t → deriv (fun s => z s*w s) t=
      (w t)^2-(c/a)*(z t)^2-(b/a)*(z t*w t) := by
    filter_upwards [hdz,hdw,h.ode_z,h.ode_w] with t hdz hdw ho hp ht
    have hz := (hdz ht).hasDerivAt
    have hw := (hdw ht).hasDerivAt
    rw [ho ht] at hz
    rw [hp ht] at hw
    have hh := hz.mul hw
    change HasDerivAt (fun s => z s*w s) _ t at hh
    rw [hh.deriv]
    ring
  have ho3 : ∀ᵐ t : ℝ, 0 < t → deriv (fun s => (w s)^2) t=
      -(2*c/a)*(z t*w t)-(2*b/a)*(w t)^2 := by
    filter_upwards [hdw,h.ode_w] with t hd ho ht
    have hh := (hd ht).hasDerivAt
    rw [ho ht] at hh
    have hp := hh.pow 2
    change HasDerivAt (fun s => (w s)^2) _ t at hp
    rw [hp.deriv]
    ring
  have hzAC : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval (fun t => (z t)^2) 0 T := by
    intro T hT
    simpa only [pow_two,Pi.mul_def] using (h.ac_z T hT).mul (h.ac_z T hT)
  have hwAC : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval (fun t => (w t)^2) 0 T := by
    intro T hT
    simpa only [pow_two,Pi.mul_def] using (h.ac_w T hT).mul (h.ac_w T hT)
  have h1 := laplace_ode_identity hzAC ho1 hz2 (hzw.const_mul 2)
    (by simpa using hf.1.pow 2) 0 le_rfl
  have hzwAC : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval (fun t => z t*w t) 0 T := by
    intro T hT
    simpa only [Pi.mul_def] using (h.ac_z T hT).mul (h.ac_w T hT)
  have h2 := laplace_ode_identity hzwAC ho2 hzw
    ((hw2.sub (hz2.const_mul (c/a))).sub (hzw.const_mul (b/a)))
    (by simpa using hf.1.mul hf.2) 0 le_rfl
  have h3 := laplace_ode_identity hwAC ho3 hw2
    ((hzw.const_mul (-(2*c/a))).sub (hw2.const_mul (2*b/a)))
    (by simpa using hf.2.pow 2) 0 le_rfl
  simp only [laplace,neg_zero,zero_mul,Real.exp_zero,one_mul,zero_sub,
    Pi.mul_apply,h.initial_z,h.initial_w,zero_pow (by decide : 2 ≠ 0),neg_zero,integral_const_mul] at h1 h2 h3
  rw [integral_sub (show Integrable (fun t => (w t)^2-(c/a)*(z t)^2) halfLine from hw2.sub (hz2.const_mul _)) (hzw.const_mul _),
    integral_sub hw2 (hz2.const_mul _),integral_const_mul,integral_const_mul] at h2
  rw [integral_sub (hzw.const_mul _) (hw2.const_mul _),integral_const_mul,integral_const_mul] at h3
  refine ⟨h1,h2,?_⟩
  have hp : (1/a)^2=1/a^2 := by ring
  rw [hp] at h3
  linarith

-- @paper-step lem:h2/energy_from_controllability_gramian
theorem canonical_energy_from_gramian {a b c : ℝ} {z w : ℝ → ℝ}
    (h : CanonicalImpulse a b c z w) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (d e : ℝ) :
    Integrable (fun t => (e*z t+d*w t)^2) halfLine ∧
    (∫ t, (e*z t+d*w t)^2 ∂halfLine)=(a*e^2+c*d^2)/(2*a*b*c) := by
  obtain ⟨hz2,hzw,hw2⟩ := canonical_gramian_integrable h ha hb hc
  have hG := (gramian_unique a b c _ _ _ ha hb hc).mp (canonical_gramian_equations h ha hb hc)
  have heq : (fun t => (e*z t+d*w t)^2) =
      (fun t => e^2*(z t)^2+2*e*d*(z t*w t)+d^2*(w t)^2) := by funext t; ring
  rw [heq]
  refine ⟨((hz2.const_mul _).add (hzw.const_mul _)).add (hw2.const_mul _),?_⟩
  rw [integral_add (show Integrable (fun t => e^2*(z t)^2+2*e*d*(z t*w t)) halfLine from (hz2.const_mul _).add (hzw.const_mul _)) (hw2.const_mul _),
    integral_add (hz2.const_mul _) (hzw.const_mul _),integral_const_mul,integral_const_mul,
    integral_const_mul,hG.1,hG.2.1,hG.2.2]
  exact gramian_output a b c d e ha hb hc

-- @paper-step lem:h2/full_gramian_proof
theorem paper_h2_gramian (a b c d e : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) :
    ∃ z w : ℝ → ℝ, CanonicalImpulse a b c z w ∧
      (∀ p : ℝ, 0 ≤ p → laplace (fun t => e*z t+d*w t) p=(d*p+e)/(a*p^2+b*p+c)) ∧
      Integrable (fun t => (e*z t+d*w t)^2) halfLine ∧
      (∫ t, (e*z t+d*w t)^2 ∂halfLine)=(a*e^2+c*d^2)/(2*a*b*c) := by
  let z := fun t => (canonicalFlow a b c t).1
  let w := fun t => (canonicalFlow a b c t).2
  have h : CanonicalImpulse a b c z w := canonical_flow_realization a b c
  have he := canonical_energy_from_gramian h ha hb hc d e
  exact ⟨z,w,h,fun p hp => canonical_laplace h ha hb hc d e p hp,he.1,he.2⟩

-- @paper-step prop:energies/canonical_to_direct_state_realization
theorem canonical_direct_pi_state {x r : ℝ} {z w : ℝ → ℝ}
    (h : CanonicalImpulse r (r*(1+x)) x z w) (hr : 0 < r) :
    PIStateResponse x r (fun t => r*z t+r*w t)
      (fun t => (x-r-x*r)*z t-r*w t) := by
  have hdz := local_ac_ae_differentiable h.ac_z
  have hdw := local_ac_ae_differentiable h.ac_w
  refine ⟨fun T hT => ((h.ac_z T hT).const_mul r).add ((h.ac_w T hT).const_mul r),
    fun T hT => ((h.ac_z T hT).const_mul (x-r-x*r)).sub ((h.ac_w T hT).const_mul r),?_,?_,?_,?_⟩
  · filter_upwards [hdz,hdw,h.ode_z,h.ode_w] with t hdZ hdW ho hp ht
    have hz := (hdZ ht).hasDerivAt
    have hw := (hdW ht).hasDerivAt
    rw [ho ht] at hz
    rw [hp ht] at hw
    have hh := (hz.const_mul r).add (hw.const_mul r)
    change HasDerivAt (fun s => r*z s+r*w s) _ t at hh
    rw [hh.deriv]
    field_simp
    <;> ring
  · filter_upwards [hdz,hdw,h.ode_z,h.ode_w] with t hdZ hdW ho hp ht
    have hz := (hdZ ht).hasDerivAt
    have hw := (hdW ht).hasDerivAt
    rw [ho ht] at hz
    rw [hp ht] at hw
    have hh := (hz.const_mul (x-r-x*r)).sub (hw.const_mul r)
    change HasDerivAt (fun s => (x-r-x*r)*z s-r*w s) _ t at hh
    rw [hh.deriv]
    field_simp
    <;> ring
  · rw [h.initial_z,h.initial_w]
    field_simp
    <;> ring
  · rw [h.initial_z,h.initial_w]
    field_simp
    <;> ring

-- @paper-step prop:energies/original_gramian_substitutions
theorem canonical_pi_energies_gramian {x r : ℝ} {z w : ℝ → ℝ}
    (h : CanonicalImpulse r (r*(1+x)) x z w) (hx : 0 < x) (hr : 0 < r) :
    (Integrable (fun t => (r*z t+r*w t)^2) halfLine ∧
      (∫ t, (r*z t+r*w t)^2 ∂halfLine)=tracking x r) ∧
    (Integrable (fun t => ((x-r)*z t+r*(x-1)*w t)^2) halfLine ∧
      (∫ t, ((x-r)*z t+r*(x-1)*w t)^2 ∂halfLine)=effort x r) := by
  have hb : 0 < r*(1+x) := by positivity
  have he := canonical_energy_from_gramian h hr hb hx r r
  have hu := canonical_energy_from_gramian h hr hb hx (r*(x-1)) (x-r)
  rw [energy_tracking_substitution x r hx hr] at he
  rw [energy_effort_substitution x r hx hr] at hu
  exact ⟨he,hu⟩

-- @paper-step prop:energies/full_original_gramian_proof
theorem paper_pi_energies_gramian {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r) :
    (Integrable (fun t => (e t)^2) halfLine ∧
      (∫ t, (e t)^2 ∂halfLine)=tracking x r) ∧
    (Integrable (fun t => (x*e t+i t)^2) halfLine ∧
      (∫ t, (x*e t+i t)^2 ∂halfLine)=effort x r) := by
  let z := fun t => (canonicalFlow r (r*(1+x)) x t).1
  let w := fun t => (canonicalFlow r (r*(1+x)) x t).2
  have hi : CanonicalImpulse r (r*(1+x)) x z w := canonical_flow_realization _ _ _
  have hd := canonical_direct_pi_state hi hr
  have hu := pi_state_unique h hd hx hr
  obtain ⟨hE,hU⟩ := canonical_pi_energies_gramian hi hx hr
  have heq : (fun t => (e t)^2) =ᵐ[halfLine] (fun t => (r*z t+r*w t)^2) := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    rw [(hu t ht.le).1]
  have hvq : (fun t => (x*e t+i t)^2) =ᵐ[halfLine] (fun t => ((x-r)*z t+r*(x-1)*w t)^2) := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    rw [(hu t ht.le).1,(hu t ht.le).2]
    congr 1
    ring
  exact ⟨⟨hE.1.congr heq.symm,(integral_congr_ae heq).trans hE.2⟩,
    ⟨hU.1.congr hvq.symm,(integral_congr_ae hvq).trans hU.2⟩⟩

-- @paper-step thm:miace/actual_pi_laplace_transforms
theorem pi_state_laplace {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r) (p : ℝ) (hp : 0 ≤ p) :
    laplace e p=r*(p+1)/(r*p^2+r*(1+x)*p+x) ∧
    laplace (fun t => x*e t+i t) p=(r*(x-1)*p+x-r)/(r*p^2+r*(1+x)*p+x) := by
  let z := fun t => (canonicalFlow r (r*(1+x)) x t).1
  let w := fun t => (canonicalFlow r (r*(1+x)) x t).2
  have hi : CanonicalImpulse r (r*(1+x)) x z w := canonical_flow_realization _ _ _
  have hu := pi_state_unique h (canonical_direct_pi_state hi hr) hx hr
  have heq : laplace e p=laplace (fun t => r*z t+r*w t) p := by
    apply integral_congr_ae
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    rw [(hu t ht.le).1]
  have hvq : laplace (fun t => x*e t+i t) p=laplace (fun t => (x-r)*z t+r*(x-1)*w t) p := by
    apply integral_congr_ae
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    rw [(hu t ht.le).1,(hu t ht.le).2]
    ring
  have hb : 0 < r*(1+x) := by positivity
  rw [heq,hvq,canonical_laplace hi hr hb hx r r p hp,canonical_laplace hi hr hb hx (r*(x-1)) (x-r) p hp]
  constructor <;> ring
end MIACE
