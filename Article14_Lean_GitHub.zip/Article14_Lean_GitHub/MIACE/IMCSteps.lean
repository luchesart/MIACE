import MIACE.LocalOperators
import MIACE.ExponentialCommand

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

noncomputable def unitStep : ℝ → ℝ := causalize (fun _ => 1)
noncomputable def imcExcess (a : ℝ) : ℝ → ℝ := causalize (expCommand (1/a))

-- @paper-step thm:complete_attainment/causal_command_halfline_identification
theorem causalize_halfLine (f : ℝ → ℝ) : causalize f=ᵐ[halfLine] f := by
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  simp [causalize,(show 0<t from ht).le]

-- @paper-step thm:complete_attainment/ordinary_unit_step_lag
theorem lag_unit_step {σ : ℝ} (hσ : 0<σ) (t : ℝ) :
    lag σ (fun _ => 1) t=1-Real.exp (-t/σ) := by
  simpa [lag] using lag_kernel_mass σ t hσ

-- @paper-step thm:complete_attainment/actual_exponential_IMC_step
theorem exponentialIMC_step {a : ℝ} (ha : 0<a) {t : ℝ} (ht : 0≤t) :
    filterAction (exponentialIMC a ha) unitStep t=1+imcExcess a t := by
  have hl := lag_as_causal_convolution a ha (fun _ => 1) ht
  change (lagKernel a ⋆ unitStep) t=lag a (fun _ => 1) t at hl
  rw [lag_unit_step ha] at hl
  simp only [filterAction,exponentialIMC,zero_mul,add_zero,hl]
  simp only [unitStep,imcExcess,causalize,indicator_of_mem (show t∈Ici (0 : ℝ) from ht),
    expCommand,expError]
  have he : -(1/a)*t=-t/a := by ring
  rw [he]
  ring

-- @paper-step thm:complete_cap/actual_pulse_IMC_step
theorem pulseIMC_step (c : ℝ) {T : ℝ} (hT : 0≤T) :
    filterAction (pulseIMC c T hT) unitStep=ᵐ[halfLine] (fun t => 1+pulse c T t) := by
  have hne := (volume.ae_ne T).filter_mono (ae_mono (Measure.restrict_le_self (s := Ioi (0 : ℝ))))
  filter_upwards [ae_restrict_mem measurableSet_Ioi,hne] with t ht hnt
  have ht0 : 0<t := ht
  by_cases htT : t≤T
  · have hlt : t<T := lt_of_le_of_ne htT hnt
    simp [filterAction,pulseIMC,unitStep,shift,causalize,ht0.le,
      show ¬0≤t-T by linarith,pulse,ht0,htT]
  · simp [filterAction,pulseIMC,unitStep,shift,causalize,ht0.le,
      show 0≤t-T by linarith,pulse,ht0,htT]

-- @paper-step thm:complete_attainment/exponential_command_full_signal_properties
theorem imcExcess_properties {a : ℝ} (ha : 0<a) (ha1 : a≤1) :
    Integrable (imcExcess a) ∧
      Integrable (fun t => Real.exp t*imcExcess a t) halfLine ∧
      (∀ t : ℝ, 0≤ imcExcess a t) ∧ commandArea (imcExcess a)=1-a ∧
      moment (imcExcess a)≤1 ∧ 1+imcExcess a 0=1/a ∧
      (∀ t : ℝ, 0≤t → 1+imcExcess a t≤1/a) := by
  have hx : 0<1/a := by positivity
  have hx1 : (1 : ℝ)≤1/a := (le_div_iff₀ ha).mpr (by simpa using ha1)
  have heq := causalize_halfLine (expCommand (1/a))
  have hnon (t : ℝ) : 0≤ imcExcess a t := by
    by_cases ht : 0≤t
    · simp only [imcExcess,causalize,indicator_of_mem (show t∈Ici (0 : ℝ) from ht),expCommand]
      exact mul_nonneg (sub_nonneg.mpr hx1) (Real.exp_nonneg _)
    · simp [imcExcess,causalize,ht]
  have hJ : Integrable (fun t => Real.exp t*imcExcess a t) halfLine ∧ moment (imcExcess a)≤1 := by
    rcases ha1.eq_or_lt with he | he
    · have haeq : a=1 := he
      subst a
      have hz : imcExcess 1=(fun _ => 0) := by ext t; simp [imcExcess,expCommand,causalize]
      rw [hz]; simp [moment]
    · have hxx : (1 : ℝ)<1/a := (lt_div_iff₀ ha).mpr (by simpa using he)
      obtain ⟨hI,hM⟩ := expCommand_moment (1/a) hxx
      have hew : (fun t => Real.exp t*imcExcess a t)=ᵐ[halfLine]
          (fun t => Real.exp t*expCommand (1/a) t) := heq.mono (fun t ht => congrArg (fun z => Real.exp t*z) ht)
      exact ⟨hI.congr hew.symm,by unfold moment; rw [integral_congr_ae hew]; exact hM.le⟩
  refine ⟨causalize_integrable (exponential_response (1/a) hx).command_integrable,hJ.1,hnon,?_,hJ.2,?_,?_⟩
  · have hh : commandArea (imcExcess a)=absArea (expCommand (1/a)) halfLine := by
      apply integral_congr_ae
      filter_upwards [heq] with t ht
      change imcExcess a t=|expCommand (1/a) t|
      rw [show imcExcess a t=expCommand (1/a) t from ht]
      exact (abs_of_nonneg (mul_nonneg (sub_nonneg.mpr hx1) (Real.exp_nonneg _))).symm
    rw [hh,(exponential_areas (1/a) hx1).2]
    field_simp <;> ring
  · simpa [imcExcess,causalize] using (expCommand_peak (1/a) hx1).1
  · intro t ht
    simpa [imcExcess,causalize,ht] using (expCommand_peak (1/a) hx1).2 t ht

-- @paper-step thm:complete_cap/pulse_command_full_line_integrability
theorem pulse_full_integrable (c T : ℝ) : Integrable (pulse c T) :=
  (continuous_const.integrableOn_Icc.mono_set Ioc_subset_Icc_self).integrable_indicator measurableSet_Ioc

-- @paper-step thm:complete_attainment/exponential_family_actual_cascade
theorem cascade_exponential_family (N : ℕ) (σ : ℕ → ℝ) {δ a : ℝ}
    (hδ : 0≤δ) (ha : 0<a) (ha1 : a≤1)
    (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1) :
    let v := imcExcess a
    let x := ordinaryCascade σ (fun t => 1+v t)
    let e := delayedError δ (fun t => 1-x (N+1) t)
    TransferResponse e v (cascadeTransfer σ (N+1)) δ ∧
      Monotone (fun t => 1-e t) ∧ 1-e 0=0 ∧ Tendsto (fun t => 1-e t) atTop (𝓝 1) ∧
      absArea v halfLine=1-a ∧ absArea e halfLine=cascadeMean σ (N+1)+δ-(1-a) ∧
      (∀ t : ℝ, 0≤v t) ∧ (∀ t : ℝ, 0≤t → 0≤e t) ∧
      1+v 0=1/a ∧ (∀ t : ℝ, 0≤t → 1+v t≤1/a) := by
  dsimp only
  have hv := imcExcess_properties ha ha1
  have hn : ∀ᵐ t ∂halfLine, 0≤ imcExcess a t := ae_of_all _ hv.2.2.1
  have hP := ordinaryCascade_transfer_response hv.1 σ (N+1) (fun j hj => (hσ j (by omega)).1) hδ
  have hu : LocallyIntegrable (fun t => 1+imcExcess a t) volume :=
    (continuous_const : Continuous (fun _ : ℝ => (1 : ℝ))).locallyIntegrable.add hv.1.locallyIntegrable
  have hc := cascade_signal_cone N σ (ordinaryCascade σ (fun t => 1+imcExcess a t)) hδ hσ hfirst
    (fun j _ => ordinaryCascade_response hu σ j) rfl hP.command_integrable hn hP.error_integrable
  have hs := hc.2.mpr ⟨hv.2.1,hv.2.2.2.2.1⟩
  have hb := hc.1.mpr ⟨hv.2.1,hv.2.2.2.2.1⟩
  have hA := cascade_cone_areas N σ _ hδ hσ hfirst (fun j _ => ordinaryCascade_response hu σ j)
    rfl hP (cascadeTransfer_derivative σ (N+1)) (cascadeTransfer_zero σ (N+1)) hn hv.2.1 hv.2.2.2.2.1
  refine ⟨hP,hs.1,hs.2.1,hs.2.2,?_,?_,hv.2.2.1,?_,hv.2.2.2.2.2.1,hv.2.2.2.2.2.2⟩
  · exact hA.2.2.1.trans hv.2.2.2.1
  · rw [hA.2.2.2,hv.2.2.2.1]
  · intro t ht
    linarith [hb t ht]

end MIACE
