import MIACE.DelayedPIStability
import MIACE.DelayedPINecessity
import MIACE.DelayedPIFiniteHistory
import MIACE.ScalarDelayStepExistence

/-! Complete Lemma 6. Internal stability is a property of the actual two
PI states and every continuous history on [-δ,0], not a synonym for a
characteristic-root condition. The retained plant mode is included. -/
namespace MIACE
open MeasureTheory Set Filter
open scoped Topology

structure DelayedPIAsymptoticallyStable (x δ : ℝ) : Prop where
  history_exists : ∀ φ ψ : ℝ → ℝ,
    ContinuousOn φ (Icc (-δ) 0) → ContinuousOn ψ (Icc (-δ) 0) →
    ∃ y z : ℝ → ℝ, DelayedPIEvolution x δ y z ∧
      EqOn y φ (Icc (-δ) 0) ∧ EqOn z ψ (Icc (-δ) 0)
  history_unique : ∀ y z Y Z : ℝ → ℝ,
    DelayedPIEvolution x δ y z → DelayedPIEvolution x δ Y Z →
    EqOn y Y (Icc (-δ) 0) → EqOn z Z (Icc (-δ) 0) →
    EqOn y Y (Ici 0) ∧ EqOn z Z (Ici 0)
  uniform_stability : ∃ K : ℝ, 0<K ∧ ∀ (M : ℝ) (y z : ℝ → ℝ),
    0≤M → DelayedPIEvolution x δ y z →
    (∀ t∈Icc (-δ) 0, |y t|≤M ∧ |z t|≤M) →
    ∀ t, 0≤t → (y t)^2+(z t)^2≤K*M^2
  attraction : ∀ y z : ℝ → ℝ, DelayedPIEvolution x δ y z →
    Tendsto y atTop (𝓝 0) ∧ Tendsto z atTop (𝓝 0)
  transport_attraction : ∀ y z : ℝ → ℝ, DelayedPIEvolution x δ y z →
    ∀ ε : ℝ, 0<ε → ∃ T : ℝ, ∀ t, T≤t → ∀ s∈Icc (-δ) 0,
      |y (t+s)|<ε ∧ |z (t+s)|<ε

-- @paper-step lem:delayed_cancellation/exact_full_pi_internal_asymptotic_stability_iff
theorem delayedPI_internal_stability_iff {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ) :
    DelayedPIAsymptoticallyStable x δ ↔ x*δ<Real.pi/2 := by
  constructor
  · intro h
    exact delayedPI_attraction_necessary hx hδ h.attraction
  · intro hb
    refine ⟨fun φ ψ hφ hψ => delayedPI_finite_history_exists hx hδ hφ hψ,
      fun y z Y Z he hE hy hz => delayedPI_finite_history_unique hx hδ he hE hy hz,
      ⟨delayedPIHistoryGain x δ,delayedPIHistoryGain_pos hx hδ hb,?_⟩,
      fun y z he => delayedPI_states_tendsto_zero hx hδ hb he,
      fun y z he => delayedPI_transport_attraction hx hδ hb he⟩
    intro M y z hM he hh t ht
    exact delayedPI_uniform_history_bound hx hδ hb hM he hh ht

-- @paper-step lem:delayed_cancellation/positive_error_and_actual_pi_command_for_every_response
theorem scalarDelay_response_positive_command {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    {E : ℝ → ℝ} (hE : ScalarDelayResponse x δ E) (hb : x*δ≤Real.exp (-1)) :
    (∀ t, 0≤t → 0<E t) ∧ (1≤x → ∀ t, 0≤t → 0≤x*E t-E (t+δ)) := by
  obtain ⟨F,hF,_,_,hpos,_,_,_,_,_,hcmd⟩ := scalarDelay_monotone_sufficient hx hδ hb
  have he := scalarDelay_response_unique hx hδ hE hF
  constructor
  · intro t ht; rw [he t ht]; exact (hpos t ht).1
  · intro hx1 t ht
    rw [he t ht,he (t+δ) (add_nonneg ht hδ)]
    exact hcmd hx1 t ht

-- @paper-step lem:delayed_cancellation/paper_lemma6_all_clauses
theorem paper_delayed_cancellation {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ) :
    (DelayedPIAsymptoticallyStable x δ ↔ x*δ<Real.pi/2) ∧
    (∃ E : ℝ → ℝ, ScalarDelayResponse x δ E) ∧
    (∀ E : ℝ → ℝ, ScalarDelayResponse x δ E →
      ((MonotoneOn (fun t => 1-E t) (Ici 0) ∧
        1-E 0=0 ∧ Tendsto (fun t => 1-E t) atTop (𝓝 1)) ↔ x*δ≤Real.exp (-1)) ∧
      (x*δ≤Real.exp (-1) → (∀ t, 0≤t → 0<E t) ∧
        (1≤x → ∀ t, 0≤t → 0≤x*E t-E (t+δ))) ∧
      (∀ t, 0≤t → x*E t-E (t+δ)=x*E t+x*(∫ s in (0 : ℝ)..t, E s)-1)) := by
  refine ⟨delayedPI_internal_stability_iff hx hδ,scalarDelay_response_exists hx hδ,?_⟩
  intro E hE
  exact ⟨scalarDelay_monotone_iff hx hδ hE,
    scalarDelay_response_positive_command hx hδ hE,fun t ht => scalarDelay_command_identity hδ hE ht⟩

end MIACE
