import MIACE.PositiveLag

/-! The paper's one-way-crossing argument, for ordinary locally integrable
inputs and locally absolutely continuous ODE states. Clipping at the target
packages both monotonicity below one and the no-return assertion. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

structure LagResponse (σ : ℝ) (u x : ℝ → ℝ) : Prop where
  ac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval x 0 T
  input_integrable : ∀ T : ℝ, 0 ≤ T → IntervalIntegrable u volume 0 T
  ode : ∀ᵐ t : ℝ, 0 < t → deriv x t = (u t-x t)/σ
  initial : x 0 = 0

def ClippedMonotone (x : ℝ → ℝ) : Prop := MonotoneOn (fun t => min (x t) 1) (Ici 0)

-- @paper-step lem:n_crossing/shifted_integrating_factor
theorem lag_weighted_increment {σ : ℝ} {u x : ℝ → ℝ} (h : LagResponse σ u x)
    {a b : ℝ} (ha : 0 ≤ a) (hab : a ≤ b) (L : ℝ) :
    (∫ s in a..b, Real.exp (s/σ)*(u s-L)/σ) =
      Real.exp (b/σ)*(x b-L)-Real.exp (a/σ)*(x a-L) := by
  have hac : AbsolutelyContinuousOnInterval x a b := by
    apply (h.ac b (ha.trans hab)).mono
    rw [uIcc_of_le hab,uIcc_of_le (ha.trans hab)]
    exact fun s hs => ⟨ha.trans hs.1,hs.2⟩
  have hc : AbsolutelyContinuousOnInterval (fun _ : ℝ => L) a b := by
    apply ContDiffOn.absolutelyContinuousOnInterval
    fun_prop
  have he : AbsolutelyContinuousOnInterval (fun s : ℝ => Real.exp (s/σ)) a b := by
    apply ContDiffOn.absolutelyContinuousOnInterval
    fun_prop
  have hi := (hac.sub hc).integral_deriv_mul_eq_sub he
  have heq : (∫ s in a..b, deriv (fun t => x t-L) s*Real.exp (s/σ) +
      (x s-L)*deriv (fun t => Real.exp (t/σ)) s) =
      ∫ s in a..b, Real.exp (s/σ)*(u s-L)/σ := by
    apply intervalIntegral.integral_congr_ae
    filter_upwards [h.ode] with s hs hsm
    rw [uIoc_of_le hab] at hsm
    have hed : deriv (fun t : ℝ => Real.exp (t/σ)) s = Real.exp (s/σ)*(1/σ) := by
      simpa using (((hasDerivAt_id s).div_const σ).exp).deriv
    rw [deriv_sub_const,hs (lt_of_le_of_lt ha hsm.1),hed]
    ring
  change (∫ s in a..b, deriv (fun t => x t-L) s*Real.exp (s/σ) +
      (x s-L)*deriv (fun t => Real.exp (t/σ)) s) = _ at hi
  rw [heq] at hi
  simpa [mul_comm] using hi

-- @paper-step lem:n_crossing/lower_barrier
theorem lag_lower_barrier {σ : ℝ} {u x : ℝ → ℝ} (h : LagResponse σ u x)
    (hσ : 0 < σ) {a b L : ℝ} (ha : 0 ≤ a) (hab : a ≤ b)
    (hxa : L ≤ x a) (hu : ∀ᵐ s ∂volume.restrict (Ioc a b), L ≤ u s) : L ≤ x b := by
  have hi := lag_weighted_increment h ha hab L
  have hp : 0 ≤ ∫ s in a..b, Real.exp (s/σ)*(u s-L)/σ := by
    rw [intervalIntegral.integral_of_le hab]
    apply integral_nonneg_of_ae
    filter_upwards [hu] with s hs
    exact div_nonneg (mul_nonneg (Real.exp_nonneg _) (sub_nonneg.mpr hs)) hσ.le
  have hp0 : 0 ≤ Real.exp (a/σ)*(x a-L) := mul_nonneg (Real.exp_nonneg _) (sub_nonneg.mpr hxa)
  have he := Real.exp_pos (b/σ)
  nlinarith

-- @paper-step lem:n_crossing/upper_barrier
theorem lag_upper_barrier {σ : ℝ} {u x : ℝ → ℝ} (h : LagResponse σ u x)
    (hσ : 0 < σ) {a b L : ℝ} (ha : 0 ≤ a) (hab : a ≤ b)
    (hxa : x a ≤ L) (hu : ∀ᵐ s ∂volume.restrict (Ioc a b), u s ≤ L) : x b ≤ L := by
  have hi := lag_weighted_increment h ha hab L
  have hp : (∫ s in a..b, Real.exp (s/σ)*(u s-L)/σ) ≤ 0 := by
    rw [intervalIntegral.integral_of_le hab]
    apply integral_nonpos_of_ae
    filter_upwards [hu] with s hs
    exact div_nonpos_of_nonpos_of_nonneg (mul_nonpos_of_nonneg_of_nonpos
      (Real.exp_nonneg _) (sub_nonpos.mpr hs)) hσ.le
  have hp0 : Real.exp (a/σ)*(x a-L) ≤ 0 :=
    mul_nonpos_of_nonneg_of_nonpos (Real.exp_nonneg _) (sub_nonpos.mpr hxa)
  have he := Real.exp_pos (b/σ)
  nlinarith

-- @paper-step lem:n_crossing/first_state_clipping
theorem first_lag_clipped_monotone {σ : ℝ} {u x : ℝ → ℝ}
    (h : LagResponse σ u x) (hσ : 0 < σ) (hu : ∀ᵐ t ∂halfLine, 1 ≤ u t) :
    (∀ t : ℝ, 0 ≤ t → 0 ≤ x t) ∧ ClippedMonotone x := by
  constructor
  · intro t ht
    apply lag_lower_barrier h hσ le_rfl ht (by rw [h.initial])
    have hsub : Ioc 0 t ⊆ Ioi (0 : ℝ) := fun s hs => hs.1
    filter_upwards [ae_restrict_of_ae_restrict_of_subset hsub hu] with s hs
    linarith
  · intro a ha b hb hab
    apply le_min _ (min_le_right _ _)
    apply lag_lower_barrier h hσ ha hab (min_le_left _ _)
    have hsub : Ioc a b ⊆ Ioi (0 : ℝ) := fun s hs => lt_of_le_of_lt ha hs.1
    filter_upwards [ae_restrict_of_ae_restrict_of_subset hsub hu] with s hs
    exact (min_le_right _ _).trans hs

-- @paper-step lem:n_crossing/clipped_state_below_input
theorem clipped_state_le_input {σ : ℝ} {u x : ℝ → ℝ}
    (h : LagResponse σ u x) (hσ : 0 < σ)
    (hn : ∀ t : ℝ, 0 ≤ t → 0 ≤ u t) (hm : ClippedMonotone u)
    {t : ℝ} (ht : 0 ≤ t) : min (x t) 1 ≤ min (u t) 1 := by
  by_cases hut : 1 ≤ u t
  · rw [min_eq_right hut]
    exact min_le_right _ _
  · have hut' : u t < 1 := lt_of_not_ge hut
    rw [min_eq_left hut'.le]
    apply (min_le_left _ _).trans
    apply lag_upper_barrier h hσ le_rfl ht (by rw [h.initial]; exact hn t ht)
    filter_upwards [ae_restrict_mem measurableSet_Ioc] with s hs
    have hh := hm (le_of_lt (show 0 < s from hs.1)) ht hs.2
    change min (u s) 1 ≤ min (u t) 1 at hh
    rw [min_eq_left hut'.le] at hh
    rcases le_total (u s) 1 with hle | hge
    · simpa [min_eq_left hle] using hh
    · rw [min_eq_right hge] at hh
      linarith

-- @paper-step lem:n_crossing/cascade_induction_step
theorem lag_preserves_clipping {σ : ℝ} {u x : ℝ → ℝ}
    (h : LagResponse σ u x) (hσ : 0 < σ)
    (hn : ∀ t : ℝ, 0 ≤ t → 0 ≤ u t) (hm : ClippedMonotone u) :
    (∀ t : ℝ, 0 ≤ t → 0 ≤ x t) ∧ ClippedMonotone x := by
  constructor
  · intro t ht
    apply lag_lower_barrier h hσ le_rfl ht (by rw [h.initial])
    filter_upwards [ae_restrict_mem measurableSet_Ioc] with s hs
    exact hn s (le_of_lt (show 0 < s from hs.1))
  · intro a ha b hb hab
    apply le_min _ (min_le_right _ _)
    apply lag_lower_barrier h hσ ha hab (min_le_left _ _)
    filter_upwards [ae_restrict_mem measurableSet_Ioc] with s hs
    exact (clipped_state_le_input h hσ hn hm ha).trans
      ((hm ha (ha.trans hs.1.le) hs.1.le).trans (min_le_left _ _))

-- @paper-step lem:n_crossing/full_cascade_induction
theorem cascade_clipped_monotone (N : ℕ) (σ : ℕ → ℝ) (x : ℕ → ℝ → ℝ)
    (hσ : ∀ j < N, 0 < σ j) (hx : ∀ j < N, LagResponse (σ j) (x j) (x (j+1)))
    (hw : ∀ᵐ t ∂halfLine, 1 ≤ x 0 t) :
    ∀ j < N, (∀ t : ℝ, 0 ≤ t → 0 ≤ x (j+1) t) ∧ ClippedMonotone (x (j+1)) := by
  intro j hj
  induction j with
  | zero => exact first_lag_clipped_monotone (hx 0 hj) (hσ 0 hj) hw
  | succ j ih =>
    have hprev := ih (by omega)
    exact lag_preserves_clipping (hx (j+1) hj) (hσ (j+1) hj) hprev.1 hprev.2

-- @paper-step lem:n_crossing/full_statement
theorem paper_one_way_crossing (N : ℕ) (σ : ℕ → ℝ) (x : ℕ → ℝ → ℝ)
    (hσ : ∀ j < N, 0 < σ j) (hx : ∀ j < N, LagResponse (σ j) (x j) (x (j+1)))
    (hw : ∀ᵐ t ∂halfLine, 1 ≤ x 0 t) :
    ∀ j < N, (∀ t : ℝ, 0 ≤ t → 0 ≤ x (j+1) t) ∧
      (∀ a b : ℝ, 0 ≤ a → a ≤ b → x (j+1) b < 1 → x (j+1) a ≤ x (j+1) b) ∧
      (∀ a b : ℝ, 0 ≤ a → a ≤ b → 1 ≤ x (j+1) a → 1 ≤ x (j+1) b) := by
  intro j hj
  obtain ⟨hn,hm⟩ := cascade_clipped_monotone N σ x hσ hx hw j hj
  refine ⟨hn,?_,?_⟩
  · intro a b ha hab hb
    have hh := hm ha (ha.trans hab) hab
    change min (x (j+1) a) 1 ≤ min (x (j+1) b) 1 at hh
    rw [min_eq_left hb.le] at hh
    rcases le_total (x (j+1) a) 1 with hle | hge
    · simpa [min_eq_left hle] using hh
    · rw [min_eq_right hge] at hh
      linarith
  · intro a b ha hab hax
    have hh := hm ha (ha.trans hab) hab
    change min (x (j+1) a) 1 ≤ min (x (j+1) b) 1 at hh
    rw [min_eq_right hax] at hh
    exact hh.trans (min_le_left _ _)
end MIACE
