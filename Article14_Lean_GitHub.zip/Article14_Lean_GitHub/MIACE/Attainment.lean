import MIACE.Shape
import MIACE.Moments

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def expError (x t : ℝ) : ℝ := Real.exp (-x*t)
noncomputable def expCommand (x t : ℝ) : ℝ := (x-1)*expError x t

-- @paper-step thm:miace_shape_gap/exponential_derivative
 theorem exp_error_derivative (x t : ℝ) :
    HasDerivAt (expError x) (-x*expError x t) t := by
  change HasDerivAt (fun s : ℝ => Real.exp (-x*s)) (-x*Real.exp (-x*t)) t
  simpa [mul_comm] using ((hasDerivAt_id t).const_mul (-x)).exp

-- @paper-step thm:miace_shape_gap/exponential_admissibility
 theorem exponential_response (x : ℝ) (hx : 0 < x) :
    FirstOrderResponse (expError x) (expCommand x) := by
  have he : Integrable (expError x) halfLine :=
    integrableOn_exp_mul_Ioi (by linarith : -x < 0) 0
  refine ⟨?_,?_,?_,?_,he,he.const_mul (x-1)⟩
  · intro h hh
    apply ContDiffOn.absolutelyContinuousOnInterval
    unfold expError
    fun_prop
  · apply ae_of_all
    intro t ht
    rw [(exp_error_derivative x t).deriv]
    unfold expCommand
    ring
  · simp [expError]
  · have ht : Tendsto (fun t : ℝ => x*t) atTop atTop := tendsto_id.const_mul_atTop hx
    have hl := Real.tendsto_exp_neg_atTop_nhds_zero.comp ht
    convert hl using 1
    funext t
    simp [expError, Function.comp_def, neg_mul]

-- @paper-step thm:miace_shape_gap/exponential_areas
 theorem exponential_areas (x : ℝ) (hx : 1 ≤ x) :
    absArea (expError x) halfLine = 1/x ∧
    absArea (expCommand x) halfLine = (x-1)/x := by
  have hx0 : 0 < x := by linarith
  have hi : (∫ t, expError x t ∂halfLine) = 1/x := by
    unfold expError halfLine
    rw [integral_exp_mul_Ioi (by linarith : -x < 0)]
    simp
  have he : absArea (expError x) halfLine = 1/x := by
    unfold absArea
    have eq : (fun t => |expError x t|) = expError x := by
      funext t
      exact abs_of_pos (Real.exp_pos _)
    rw [eq,hi]
  refine ⟨he,?_⟩
  unfold absArea expCommand
  have eq : (fun t => |(x-1)*expError x t|) = (fun t => (x-1)*expError x t) := by
    funext t
    apply abs_of_nonneg
    exact mul_nonneg (by linarith) (Real.exp_nonneg _)
  rw [eq,integral_const_mul,hi]
  ring

-- @paper-step thm:miace_shape_gap/pi_realization
 theorem exponential_pi_law (x t : ℝ) (hx : 0 < x) (ht : 0 ≤ t) :
    1+expCommand x t = x*expError x t + x*(∫ s in 0..t, expError x s) := by
  have hi := response_increment (exponential_response x hx) le_rfl ht
  have heq : (fun s => expError x s+expCommand x s) = (fun s => x*expError x s) := by
    funext s
    unfold expCommand
    ring
  rw [heq, intervalIntegral.integral_const_mul] at hi
  simp only [expError, mul_zero, Real.exp_zero] at hi
  unfold expCommand expError
  nlinarith

-- @paper-step thm:miace_shape_gap/controller_attainment
 theorem optimal_exponential_cost (α : ℝ) (hα : 0 < α) :
    miace α (expError (1+1/α)) (expCommand (1+1/α)) halfLine = minimum α := by
  have hx : 1 ≤ 1+1/α := by
    have : 0 < 1/α := by positivity
    linarith
  have ha := exponential_areas (1+1/α) hx
  unfold miace minimum costSq
  rw [ha.1,ha.2]
  congr 1
  have h0 : α ≠ 0 := ne_of_gt hα
  have h1 : 1+α ≠ 0 := by linarith
  field_simp
  <;> ring

-- @paper-step thm:miace_shape_gap/unsquared_minimum
 theorem response_miace_lower_bound {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (α : ℝ) (hα : 0 < α) : minimum α ≤ miace α e v halfLine := by
  apply Real.sqrt_le_sqrt
  have hb := cost_lower_bound α 1 (absArea e halfLine) (absArea v halfLine)
    (negArea e halfLine+negArea v halfLine) hα (by norm_num)
    (add_nonneg (negative_area_nonneg _) (negative_area_nonneg _))
    (area_balance h.error_integrable h.command_integrable 1 (response_signed_balance h))
  simpa [baseSq] using hb

-- @paper-step thm:miace_shape_gap/unsquared_equality
 theorem response_miace_equality_iff {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (α : ℝ) (hα : 0 < α) :
    miace α e v halfLine = minimum α ↔
    (∀ᵐ t ∂halfLine, 0 ≤ e t) ∧ (∀ᵐ t ∂halfLine, 0 ≤ v t) ∧
      absArea e halfLine = α*absArea v halfLine := by
  rw [← response_equality_iff h α hα]
  unfold miace minimum
  have hc : 0 ≤ costSq α (absArea e halfLine) (absArea v halfLine) := by unfold costSq; positivity
  have hb : 0 ≤ α/(1+α) := by positivity
  rw [Real.sqrt_inj hc hb]
  simp [baseSq]

end MIACE
