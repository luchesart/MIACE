import MIACE.PositiveResolvent

set_option maxHeartbeats 1200000

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:complete_robust/absolute_exponential_weight
theorem expWeight_abs (η : ℝ) (K : ℝ → ℝ) :
    expWeight η (fun t => |K t|) = fun t => |expWeight η K t| := by
  funext t
  simp [expWeight,abs_mul,abs_of_pos (Real.exp_pos _)]

-- @paper-step thm:complete_robust/weighted_small_gain
theorem weighted_small_gain {K : ℝ → ℝ} (hK : Integrable K)
    (hq : absArea K volume < 1) {β : ℝ} (hβ : 0 < β)
    (hKw : Integrable (expWeight β K) volume) :
    ∃ η : ℝ, ∃ hw : Integrable (expWeight η K) volume,
      0 < η ∧ η ≤ β ∧ absArea (expWeight η K) volume < 1 ∧
      let T := convOp hw
      let R := ∑' n : ℕ, (-T)^n
      (1+T)*R=1 ∧ R*(1+T)=1 ∧
        ‖R‖ ≤ 1/(1-absArea (expWeight η K) volume) := by
  have hwa : Integrable (expWeight β (fun t => |K t|)) := by
    rw [expWeight_abs]
    exact hKw.abs
  obtain ⟨η,hη,hle,hwabs,hqa⟩ := expWeight_small_mass hK.abs hq hβ hwa
  have hw := expWeight_integrable hK hKw hη.le hle
  have hqw : absArea (expWeight η K) volume < 1 := by
    rw [expWeight_abs] at hqa
    exact hqa
  have hn : ‖-(convOp hw)‖ ≤ absArea (expWeight η K) volume := by
    rw [norm_neg]
    exact convOp_norm hw
  obtain ⟨_,hl,hr,hbound⟩ := neumann_inverse_operator (-(convOp hw)) hn hqw
  refine ⟨η,hw,hη,hle,hqw,?_,?_,hbound⟩
  · simpa only [sub_neg_eq_add] using hl
  · simpa only [sub_neg_eq_add] using hr

-- @paper-step thm:complete_robust/operator_signal_bounds
theorem robust_operator_bounds {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [CompleteSpace E] (F H D : E →L[ℝ] E) (g : E) {f d q : ℝ}
    (hf : 0 ≤ f) (hd : 0 ≤ d) (hF : ‖F‖ ≤ f) (hH : ‖H‖ ≤ 1)
    (hFD : ‖F*D‖ ≤ q) (hq : q < 1) (hg : ‖g‖ ≤ d) :
    let R := ∑' n : ℕ, (-(F*D))^n
    (1+F*D)*R=1 ∧ R*(1+F*D)=1 ∧
      ‖F (F (R g))‖ ≤ f^2*d/(1-q) ∧
      ‖F ((1-H) (R g))‖ ≤ 2*f*d/(1-q) := by
  dsimp only
  let R := ∑' n : ℕ, (-(F*D))^n
  have hn : ‖-(F*D)‖ ≤ q := by simpa only [norm_neg] using hFD
  obtain ⟨_,hl,hr,hbound⟩ := neumann_inverse_operator (-(F*D)) hn hq
  have hden : 0 < 1-q := sub_pos.mpr hq
  have hRg : ‖R g‖ ≤ d/(1-q) := calc
    ‖R g‖ ≤ ‖R‖*‖g‖ := R.le_opNorm g
    _ ≤ (1/(1-q))*d := mul_le_mul hbound hg (norm_nonneg _) (by positivity)
    _ = _ := by ring
  have hS : ‖(1 : E →L[ℝ] E)-H‖ ≤ 2 := by
    have hh := norm_sub_le (1 : E →L[ℝ] E) H
    have hi : ‖(1 : E →L[ℝ] E)‖ ≤ 1 := ContinuousLinearMap.norm_id_le
    linarith
  refine ⟨by simpa only [sub_neg_eq_add] using hl,
    by simpa only [sub_neg_eq_add] using hr,?_,?_⟩
  · calc
      ‖F (F (R g))‖ ≤ ‖F‖*‖F (R g)‖ := F.le_opNorm _
      _ ≤ f*(f*(d/(1-q))) := mul_le_mul hF
        ((F.le_opNorm _).trans (mul_le_mul hF hRg (norm_nonneg _) hf))
        (norm_nonneg _) hf
      _ = _ := by ring
  · calc
      ‖F ((1-H) (R g))‖ ≤ ‖F‖*‖(1-H) (R g)‖ := F.le_opNorm _
      _ ≤ f*(2*(d/(1-q))) := mul_le_mul hF
        (((1-H).le_opNorm _).trans (mul_le_mul hS hRg (norm_nonneg _) (by norm_num)))
        (norm_nonneg _) hf
      _ = _ := by ring

end MIACE
