import MIACE.ExplicitPIDForcing
import MIACE.GreenPIDOrdinary

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:pid_explicit_family/actual_command_forcing_Laplace_transform
theorem explicitR_laplace {i ρ ell l δ : ℝ} (h : ExplicitPIDData i ρ ell l δ)
    {p : ℝ} (hp : 0<p) :
    laplace (explicitR i ρ ell l δ) p=
      (i*(1+ell*p)/(1+ρ*p)*(1+(1-Real.exp (-δ*p))/p)-1)/(p+l) := by
  have hr := (explicitPID_order h).1
  let A := explicitA ρ ell l
  let B := explicitB ρ ell l
  let J := explicitJ ρ ell l
  let g := expKernel l
  let f := expKernel (1/ρ)
  let box := compactKernel (fun _ => 1) δ
  have hgi := expKernel_integrable h.rate_pos
  have hfi := expKernel_integrable (one_div_pos.mpr hr)
  have hbi := compactKernel_integrable (J:=fun _ => (1 : ℝ)) continuous_const δ
  have hJi := explicitJ_integrable hr ell h.rate_pos
  have hQi : Integrable (g ⋆ box) := hgi.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hbi
  have hTi : Integrable (f ⋆ box) := hfi.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hbi
  have hsum : A*laplace g p+B*laplace f p=laplace J p :=
    (laplace_linear hgi hfi A B hp.le).symm
  have hS := laplace_linear hJi hQi 1 A hp.le
  simp only [one_mul] at hS
  have hT := laplace_linear (hJi.add (hQi.const_mul A)) hTi 1 B hp.le
  simp only [one_mul,Pi.add_apply] at hT
  have hR := laplace_linear ((hJi.add (hQi.const_mul A)).add (hTi.const_mul B)) hgi i (-1) hp.le
  simp only [Pi.add_apply,neg_one_mul,← sub_eq_add_neg] at hR
  change laplace (explicitR i ρ ell l δ) p=_ at hR
  simp only [Pi.add_def] at hR hT
  rw [hR,hT,hS,
    causal_convolution_laplace hgi hbi (causalize_causal _) (compactKernel_causal _ δ) hp.le,
    causal_convolution_laplace hfi hbi (causalize_causal _) (compactKernel_causal _ δ) hp.le]
  calc
    _ = i*(laplace J p+(A*laplace g p+B*laplace f p)*laplace box p)-laplace g p := by ring
    _ = _ := by
      rw [hsum,show laplace J p=(1+ell*p)/((1+ρ*p)*(p+l)) from explicitJ_laplace h hp.le,
        show laplace g p=1/(p+l) from expKernel_laplace h.rate_pos hp.le,
        show laplace box p=(1-Real.exp (-δ*p))/p from delay_box_laplace h.delay_pos.le hp]
      have hl := h.rate_pos
      have hf : 1+ρ*p≠0 := ne_of_gt (by positivity)
      have hpl : p+l≠0 := ne_of_gt (by positivity)
      field_simp [hf,hpl,ne_of_gt hp]
      <;> ring

-- @paper-step thm:pid_explicit_family/positive_command_solution_and_exact_transfer
theorem explicitPID_command_L1 {i ρ ell l δ : ℝ} (h : ExplicitPIDData i ρ ell l δ) :
    ∃ v : ℝ → ℝ, Integrable v ∧ Causal v ∧ (∀ᵐ t, 0≤v t) ∧
      ∀ p, 0<p → laplace v p=
        (i*(1+ell*p)*(1+(1-Real.exp (-δ*p))/p)-(1+ρ*p))/
          (p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p)) := by
  let hK := explicitK_integrable h
  let hR := explicitR_integrable h
  let R := explicitR i ρ ell l δ
  let v : RealL1 := (∑' n : ℕ, (convOp hK)^n) (hR.toL1 R)
  have hRc := explicitR_causal i ρ ell l δ
  have hKc := explicitK_causal h.delay_pos.le i ρ ell l
  have hq := (explicitK_mass h).2
  have hRn : 0≤hR.toL1 R := by
    rw [← Lp.coeFn_nonneg]
    filter_upwards [hR.coeFn_toL1] with t ht
    rw [ht]; exact explicitR_nonneg h t
  have hm : (∫ t, explicitK i ρ ell l δ t)<1 := by
    rw [← positive_kernel_mass (ae_of_all _ (explicitK_nonneg h))]; exact hq
  have hn := (renewal_l1 hK (ae_of_all _ (explicitK_nonneg h)) hm (hR.toL1 R) hRn).2.1
  have hc := causal_renewal_series hK hKc ((convOp_norm hK).trans_lt hq)
    (causal_congr hRc hR.coeFn_toL1.symm)
  refine ⟨v,L1.integrable_coeFn v,hc,(Lp.coeFn_nonneg v).mpr hn,?_⟩
  intro p hp
  have he := signed_renewal_function_laplace hK hKc hq hR hRc hp.le
  change (1-laplace (explicitK i ρ ell l δ) p)*laplace v p=laplace R p at he
  rw [explicitK_laplace h hp.le,show laplace R p=_ from explicitR_laplace h hp] at he
  obtain ⟨hr,hrl,_,_,_⟩ := explicitPID_order h
  have hell : 0<ell := lt_trans hr hrl
  have hi := h.gain_pos
  have hl := h.rate_pos
  have hfp : 1+ρ*p≠0 := ne_of_gt (by positivity)
  have hpl : p+l≠0 := ne_of_gt (by positivity)
  have hd : p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p)≠0 := ne_of_gt (by positivity)
  apply (eq_div_iff hd).mpr
  field_simp [ne_of_gt hp,hfp,hpl] at he ⊢
  try simp only [neg_mul,mul_comm δ p] at he ⊢
  linear_combination he

-- @paper-step thm:pid_explicit_family/ordinary_plant_and_controller_transfer_algebra
theorem explicitPID_transfer_algebra {i ρ ell l δ : ℝ} (h : ExplicitPIDData i ρ ell l δ)
    {E v : ℝ → ℝ}
    (hE : ∀ p, 0≤p → (p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p))*laplace E p=1+ρ*p)
    (hv : ∀ p, 0<p → laplace v p=
      (i*(1+ell*p)*(1+(1-Real.exp (-δ*p))/p)-(1+ρ*p))/
        (p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p))) {p : ℝ} (hp : 0<p) :
    1/p+laplace v p=(i*(1+ell-ρ)+i/p+i*(ell-ρ)*(1-ρ)*p/(1+ρ*p))*laplace E p ∧
    1/p-laplace E p=1/(1+p)*Real.exp (-δ*p)*(1/p+laplace v p) := by
  obtain ⟨hr,hrl,_,_,_⟩ := explicitPID_order h
  have hell : 0<ell := lt_trans hr hrl
  have hi := h.gain_pos
  have hf : 1+ρ*p≠0 := ne_of_gt (by positivity)
  have hd : p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p)≠0 := ne_of_gt (by positivity)
  have he : laplace E p=(1+ρ*p)/(p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p)) :=
    (eq_div_iff hd).mpr (by nlinarith [hE p hp.le])
  rw [he,hv p hp,pid_controller_factor i ρ ell p (ne_of_gt hp) hf]
  constructor <;> field_simp [ne_of_gt hp,hf,hd,ne_of_gt (by positivity : 0<1+p)] <;> ring

end MIACE
