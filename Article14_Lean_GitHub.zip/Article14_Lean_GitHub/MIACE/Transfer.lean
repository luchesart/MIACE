import MIACE.GeneralCost
import Mathlib.Analysis.Calculus.Deriv.Polynomial

/-! Real Laplace transforms on the positive real axis. The zero-state transfer
equation is the plant model; the DC area identity is derived by dominated
convergence and differentiation at zero, following the article's proof. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def laplace (f : ℝ → ℝ) (p : ℝ) : ℝ :=
  ∫ t, Real.exp (-p*t)*f t ∂halfLine

structure TransferResponse (e v H : ℝ → ℝ) (δ : ℝ) : Prop where
  error_integrable : Integrable e halfLine
  command_integrable : Integrable v halfLine
  zero_state : ∀ p : ℝ, 0 < p →
    laplace (fun t => 1-e t) p = H p*Real.exp (-δ*p)*laplace (fun t => 1+v t) p

-- @paper-step thm:n_gap/laplace_domination
theorem laplace_kernel_bound (p t z : ℝ) (hp : 0 ≤ p) (ht : 0 ≤ t) :
    ‖Real.exp (-p*t)*z‖ ≤ ‖z‖ := by
  have he : Real.exp (-p*t) ≤ 1 := Real.exp_le_one_iff.mpr (by nlinarith)
  rw [norm_mul,Real.norm_of_nonneg (Real.exp_nonneg _)]
  exact mul_le_of_le_one_left (norm_nonneg _) he

-- @paper-step thm:n_gap/laplace_integrability
theorem laplace_integrable {f : ℝ → ℝ} (hf : Integrable f halfLine)
    {p : ℝ} (hp : 0 ≤ p) : Integrable (fun t => Real.exp (-p*t)*f t) halfLine := by
  have hm : AEStronglyMeasurable (fun t : ℝ => Real.exp (-p*t)) halfLine :=
    (by fun_prop : Continuous (fun t : ℝ => Real.exp (-p*t))).aestronglyMeasurable
  apply hf.norm.mono' (hm.mul hf.aestronglyMeasurable)
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  exact laplace_kernel_bound p t (f t) hp (le_of_lt (show 0 < t from ht))

-- @paper-step thm:n_gap/laplace_dc_limit
theorem laplace_tendsto_zero {f : ℝ → ℝ} (hf : Integrable f halfLine) :
    Tendsto (laplace f) (𝓝[>] (0 : ℝ)) (𝓝 (∫ t, f t ∂halfLine)) := by
  apply tendsto_integral_filter_of_dominated_convergence (fun t => ‖f t‖)
  · apply Eventually.of_forall
    intro p
    have hm : Continuous (fun t : ℝ => Real.exp (-p*t)) := by fun_prop
    exact hm.aestronglyMeasurable.mul hf.aestronglyMeasurable
  · filter_upwards [self_mem_nhdsWithin] with p hp
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact laplace_kernel_bound p t (f t) (le_of_lt (show 0 < p from hp))
      (le_of_lt (show 0 < t from ht))
  · exact hf.norm
  · apply ae_of_all
    intro t
    have hc : Continuous (fun p : ℝ => Real.exp (-p*t)*f t) := by fun_prop
    simpa using hc.continuousAt.tendsto.mono_left (nhdsWithin_le_nhds : 𝓝[>] (0 : ℝ) ≤ 𝓝 0)

-- @paper-step thm:n_gap/step_transform
theorem laplace_step (p : ℝ) (hp : 0 < p) : laplace (fun _ => 1) p = 1/p := by
  unfold laplace halfLine
  simp only [mul_one]
  rw [integral_exp_mul_Ioi (by linarith : -p < 0)]
  simp

-- @paper-step thm:n_gap/centered_transfer_identity
theorem transfer_error_identity {e v H : ℝ → ℝ} {δ : ℝ}
    (h : TransferResponse e v H δ) (p : ℝ) (hp : 0 < p) :
    laplace e p = (1-H p*Real.exp (-δ*p))/p-H p*Real.exp (-δ*p)*laplace v p := by
  have hconst : Integrable (fun t : ℝ => Real.exp (-p*t)) halfLine :=
    integrableOn_exp_mul_Ioi (by linarith : -p < 0) 0
  have he := laplace_integrable h.error_integrable hp.le
  have hv := laplace_integrable h.command_integrable hp.le
  have hy : laplace (fun t => 1-e t) p = 1/p-laplace e p := by
    unfold laplace
    simp_rw [mul_sub,mul_one]
    rw [integral_sub hconst he]
    have hs := laplace_step p hp
    simpa [laplace] using congrArg (fun a => a-∫ t, Real.exp (-p*t)*e t ∂halfLine) hs
  have hw : laplace (fun t => 1+v t) p = 1/p+laplace v p := by
    unfold laplace
    simp_rw [mul_add,mul_one]
    rw [integral_add hconst hv]
    have hs := laplace_step p hp
    simpa [laplace] using congrArg (fun a => a+∫ t, Real.exp (-p*t)*v t ∂halfLine) hs
  have hz := h.zero_state p hp
  rw [hy,hw] at hz
  calc
    laplace e p = 1/p-H p*Real.exp (-δ*p)*(1/p+laplace v p) := by linarith
    _ = _ := by ring

-- @paper-step thm:n_gap/delayed_dc_derivative
theorem transfer_delay_derivative {H : ℝ → ℝ} (μ δ : ℝ)
    (hH : HasDerivAt H (-μ) 0) (h0 : H 0 = 1) :
    HasDerivAt (fun p => H p*Real.exp (-δ*p)) (-(μ+δ)) 0 := by
  have hd := hH.mul (((hasDerivAt_id (0 : ℝ)).const_mul (-δ)).exp)
  convert hd using 1 <;> simp [h0] <;> ring
  rfl

-- @paper-step thm:n_gap/plant_to_balance
theorem transfer_signed_balance {e v H : ℝ → ℝ} {δ : ℝ}
    (h : TransferResponse e v H δ) (μ : ℝ)
    (hH : HasDerivAt H (-μ) 0) (h0 : H 0 = 1) :
    (∫ t, e t ∂halfLine)+(∫ t, v t ∂halfLine) = μ+δ := by
  have hd := transfer_delay_derivative μ δ hH h0
  have hs : Tendsto (fun p => (1-H p*Real.exp (-δ*p))/p) (𝓝[>] (0 : ℝ)) (𝓝 (μ+δ)) := by
    have hh := hd.tendsto_slope_zero_right.neg
    convert hh using 1
    · funext p
      simp [h0,smul_eq_mul]
      ring
    · simp
  have hprod : Tendsto (fun p => H p*Real.exp (-δ*p)) (𝓝[>] (0 : ℝ)) (𝓝 1) := by
    simpa [h0] using hd.continuousAt.tendsto.mono_left
      (nhdsWithin_le_nhds : 𝓝[>] (0 : ℝ) ≤ 𝓝 0)
  have hr := hs.sub (hprod.mul (laplace_tendsto_zero h.command_integrable))
  have heq : laplace e =ᶠ[𝓝[>] (0 : ℝ)]
      (fun p => (1-H p*Real.exp (-δ*p))/p-H p*Real.exp (-δ*p)*laplace v p) := by
    filter_upwards [self_mem_nhdsWithin] with p hp
    exact transfer_error_identity h p hp
  have hi := tendsto_nhds_unique (laplace_tendsto_zero h.error_integrable) (hr.congr' heq.symm)
  linarith

-- Stable normalized rational plants satisfy the local regularity used above.
-- Stability is stronger than needed here: A(0)=1 suffices for differentiability.
-- @paper-step thm:n_gap/rational_dc_regularity
theorem rational_dc_derivative (A B : Polynomial ℝ)
    (hA : A.eval 0 = 1) (hB : B.eval 0 = 1) :
    HasDerivAt (fun p : ℝ => B.eval p/A.eval p)
      (-(A.derivative.eval 0-B.derivative.eval 0)) 0 := by
  have hd := (B.hasDerivAt 0).div (A.hasDerivAt 0) (by rw [hA]; norm_num)
  convert hd using 1 <;> simp [hA,hB] <;> ring

-- Theorem 12 in zero-state transfer-function semantics. The regularity
-- hypothesis also covers nonrational transfer functions differentiable at DC.
-- @paper-step thm:n_gap/full_statement
theorem paper_general_plant {e v H : ℝ → ℝ} {δ : ℝ}
    (h : TransferResponse e v H δ) (α μ : ℝ) (hα : 0 < α)
    (hS : 0 < μ+δ) (hH : HasDerivAt H (-μ) 0) (h0 : H 0 = 1) :
    (∫ t, e t ∂halfLine)+(∫ t, v t ∂halfLine) = μ+δ ∧
    absArea e halfLine+absArea v halfLine = μ+δ+2*(negArea e halfLine+negArea v halfLine) ∧
    ((miace α e v halfLine)^2-(μ+δ)^2*(minimum α)^2 =
      4*(minimum α)^2*(negArea e halfLine+negArea v halfLine)*
        (μ+δ+(negArea e halfLine+negArea v halfLine)) +
      (absArea e halfLine-α*absArea v halfLine)^2/(1+α)) ∧
    (μ+δ)*minimum α ≤ miace α e v halfLine ∧
    (miace α e v halfLine = (μ+δ)*minimum α ↔
      (∀ᵐ t ∂halfLine, 0 ≤ e t) ∧ (∀ᵐ t ∂halfLine, 0 ≤ v t) ∧
      absArea e halfLine = α*absArea v halfLine) ∧
    (miace α e v halfLine = (μ+δ)*minimum α →
      absArea e halfLine = α*(μ+δ)/(1+α) ∧ absArea v halfLine = (μ+δ)/(1+α)) := by
  have hb := transfer_signed_balance h μ hH h0
  have hab := area_balance h.error_integrable h.command_integrable (μ+δ) hb
  have heq := signal_miace_equality_iff h.error_integrable h.command_integrable α (μ+δ) hα hS hb
  refine ⟨hb,hab,?_,signal_miace_lower_bound h.error_integrable h.command_integrable
    α (μ+δ) hα hS.le hb,heq,?_⟩
  · rw [miace_square α e v halfLine hα,minimum_square α hα]
    have hi := signal_excess h.error_integrable h.command_integrable α (μ+δ) hα hb
    convert hi using 1 <;> (try unfold baseSq) <;> ring
  · intro hm
    obtain ⟨he,hv,hr⟩ := heq.mp hm
    rw [(negative_area_zero_iff h.error_integrable).mpr he,
      (negative_area_zero_iff h.command_integrable).mpr hv] at hab
    have hsum : absArea e halfLine+absArea v halfLine = μ+δ := by linarith
    exact (equality_areas α (μ+δ) _ _ hα hsum hr).symm

end MIACE
