import MIACE.CompactRenewal

/-! Both parity hypotheses yield an actual nonnegative exponentially
weighted L1 inverse of R. No inverse-transform existence is assumed. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:n_construction/odd_kernel_transform_identity
theorem oddCascadeKernel_laplace {J : ℝ → ℝ} (hc : Continuous J) {δ a c l p : ℝ}
    (hδ : 0≤δ) (hl : 0<l) (hp : 0≤p) :
    laplace (oddCascadeKernel J δ a c l) p=
      (l-c/a)/(p+l)-(1/a)*((1/(p+l))*compactExpMoment J δ (-p)) := by
  have hE := expKernel_integrable hl
  have hJ := compactKernel_integrable hc δ
  have hEc : Causal (expKernel l) := causalize_causal _
  have hC := hE.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hJ
  have hh := laplace_linear hE hC (l-c/a) (-(1/a)) hp
  simp only [neg_mul,← sub_eq_add_neg] at hh
  change laplace (oddCascadeKernel J δ a c l) p=_ at hh
  rw [hh,expKernel_laplace hl hp,
    causal_convolution_laplace hE hJ hEc (compactKernel_causal J δ) hp,
    expKernel_laplace hl hp,compactKernel_laplace J hδ]
  ring

-- @paper-step thm:n_construction/even_kernel_transform_identity
theorem evenCascadeKernel_laplace {J : ℝ → ℝ} (hc : Continuous J) {δ a c p : ℝ}
    (hδ : 0≤δ) (ha : 0<a) (hc0 : 0<c) (hp : 0≤p) :
    laplace (evenCascadeKernel J δ a c) p=
      (1/a)*((1/(p+c/a))*compactExpMoment J δ (-p)) := by
  have hE := expKernel_integrable (div_pos hc0 ha)
  have hJ := compactKernel_integrable hc δ
  have hEc : Causal (expKernel (c/a)) := causalize_causal _
  have he : laplace (evenCascadeKernel J δ a c) p=
      (1/a)*laplace (expKernel (c/a) ⋆ compactKernel J δ) p := by
    unfold laplace evenCascadeKernel
    simp_rw [mul_left_comm _ (1/a)]
    rw [integral_const_mul]
  rw [he,causal_convolution_laplace hE hJ hEc (compactKernel_causal J δ) hp,
    expKernel_laplace (div_pos hc0 ha) hp,compactKernel_laplace J hδ]

-- @paper-step thm:n_construction/positive_series_with_exponential_moment
theorem positive_exp_renewal {K G : ℝ → ℝ}
    (hK : Integrable K) (hKn : ∀ᵐ t, 0≤K t) (hKc : Causal K)
    (hq : (∫ t, K t)<1) (hG : Integrable G volume) (hGn : ∀ᵐ t ∂volume, 0≤G t) (hGc : Causal G)
    {β : ℝ} (hβ : 0<β) (hKw : Integrable (expWeight β K))
    (hGw : Integrable (expWeight β G)) :
    ∃ r : RealL1, 0≤r ∧ Causal r ∧ r=hG.toL1 G+convOp hK r ∧
      (∃ η : ℝ, 0<η ∧ Integrable (expWeight η r)) ∧
      (∀ z : RealL1, z=hG.toL1 G+convOp hK z → z=r) := by
  let g := hG.toL1 G
  have hgc := causal_congr hGc hG.coeFn_toL1.symm
  have hgn : 0≤g := by
    rw [← Lp.coeFn_nonneg]
    filter_upwards [hG.coeFn_toL1,hGn] with t he hn
    rw [he]; exact hn
  obtain ⟨_,hn,hc,he,hu,_,_⟩ := positive_resolvent_all_parts hK hKn hKc hq g hgn hgc
  refine ⟨_,hn,hc,he,?_,hu⟩
  obtain ⟨η,hη,hle,hKi,hqi⟩ := expWeight_small_mass hK hq hβ hKw
  have hGi := expWeight_integrable hG hGw hη.le hle
  have hgw := expWeight_toL1_integrable hG hGi
  obtain ⟨hr,_,_⟩ := positive_resolvent_weighted hK hKn hKc hq hη.le hKi hqi g hgn hgc hgw
  exact ⟨η,hη,hr⟩

-- @paper-step thm:n_construction/odd_parity_positive_resolvent_exists
theorem oddCascade_resolvent {J : ℝ → ℝ} (hc : Continuous J) {δ a l : ℝ}
    (hδ : 0≤δ) (ha : 0<a) (hl : 0<l)
    (hn : ∀ s∈Icc (0 : ℝ) δ, 0≤J s)
    (hcond : 1-compactMoment J δ 0+compactExpMoment J δ l≤a*l) :
    ∃ r : RealL1, 0≤r ∧ Causal r ∧
      (∃ η : ℝ, 0<η ∧ Integrable (expWeight η r)) ∧
      (∫ t, r t)=1 ∧
      ∀ p : ℝ, 0≤p →
        (a*p+(1-compactMoment J δ 0)+compactExpMoment J δ (-p))*laplace r p=1 := by
  let c := 1-compactMoment J δ 0
  let K := oddCascadeKernel J δ a c l
  have hK : Integrable K := by
    simpa only [expWeight_zero] using oddCascadeKernel_weighted hc δ a c hl
  have hKn : ∀ᵐ t, 0≤K t := ae_of_all _ (oddCascadeKernel_nonneg hc hδ ha hn hcond)
  have hKc := (cascadeKernels_causal J δ a c l).1
  have hq : (∫ t, K t)<1 := by
    rw [show (∫ t, K t)=1-1/(a*l) from oddCascadeKernel_mass hc hδ ha hl]
    have : 0<1/(a*l) := by positivity
    linarith
  let G := fun t => (1/a)*expKernel l t
  have hG := (expKernel_integrable hl).const_mul (1/a)
  have hGn : ∀ᵐ t, 0≤G t := ae_of_all _ (fun t => mul_nonneg (by positivity) (expKernel_nonneg l t))
  have hGc : Causal G := by
    apply ae_of_all; intro t ht; simp [G,expKernel,causalize,not_le.mpr ht]
  have hGw : Integrable (expWeight (l/2) G) := by
    have hh := (expKernel_weighted (show l/2<l by linarith)).const_mul (1/a)
    convert hh using 1; funext t; dsimp [G,expWeight]; ring
  obtain ⟨r,hrn,hrc,hreq,hrw,_⟩ := positive_exp_renewal hK hKn hKc hq hG hGn hGc
    (half_pos hl) (oddCascadeKernel_weighted hc δ a c (show l/2<l by linarith)) hGw
  have hGtrans (p : ℝ) (hp : 0≤p) : laplace G p=1/(a*(p+l)) := by
    change (∫ t, Real.exp (-p*t)*((1/a)*expKernel l t) ∂halfLine)=_
    simp_rw [mul_left_comm _ (1/a)]
    rw [integral_const_mul]
    change (1/a)*laplace (expKernel l) p=_
    rw [expKernel_laplace hl hp]
    simp [div_eq_mul_inv,mul_comm]
  have htrans (p : ℝ) (hp : 0≤p) :
      (a*p+c+compactExpMoment J δ (-p))*laplace r p=1 := by
    have hh := renewal_laplace hK hKc (hG.toL1 G) r
      (causal_congr hGc hG.coeFn_toL1.symm) hrc hreq hp
    rw [laplace_congr_ae hG.coeFn_toL1,hGtrans p hp,
      oddCascadeKernel_laplace hc hδ hl hp] at hh
    have ha0 := ne_of_gt ha
    have hpl : p+l≠0 := ne_of_gt (by linarith)
    field_simp at hh
    nlinarith [hh]
  refine ⟨r,hrn,hrc,hrw,?_,htrans⟩
  have hh := htrans 0 le_rfl
  simp only [c,compactExpMoment,compactMoment,neg_zero,zero_mul,Real.exp_zero,
    pow_zero,one_mul,mul_zero,sub_add_cancel,one_mul] at hh
  rw [← kernel_laplace_full hrc 0] at hh
  simpa [expWeight_zero] using hh

-- @paper-step thm:n_construction/even_parity_positive_resolvent_exists
theorem evenCascade_resolvent {J : ℝ → ℝ} (hc : Continuous J) {δ a : ℝ}
    (hδ : 0≤δ) (ha : 0<a) (hn : ∀ s∈Icc (0 : ℝ) δ, 0≤J s) :
    ∃ r : RealL1, 0≤r ∧ Causal r ∧
      (∃ η : ℝ, 0<η ∧ Integrable (expWeight η r)) ∧
      (∫ t, r t)=1 ∧
      ∀ p : ℝ, 0≤p →
        (a*p+(1+compactMoment J δ 0)-compactExpMoment J δ (-p))*laplace r p=1 := by
  let c := 1+compactMoment J δ 0
  have hj0 : 0≤compactMoment J δ 0 := by
    rw [← compactKernel_mass J hδ]
    exact integral_nonneg (compactKernel_nonneg hn)
  have hc0 : 0<c := by dsimp [c]; linarith
  let l := c/a
  have hl : 0<l := div_pos hc0 ha
  let K := evenCascadeKernel J δ a c
  have hK : Integrable K := by
    simpa only [expWeight_zero] using evenCascadeKernel_weighted hc δ a c hl
  have hKn : ∀ᵐ t, 0≤K t := ae_of_all _ (evenCascadeKernel_nonneg ha hn c)
  have hKc := (cascadeKernels_causal J δ a c l).2
  have hq : (∫ t, K t)<1 := by
    rw [show (∫ t, K t)=compactMoment J δ 0/c from evenCascadeKernel_mass hc hδ ha hc0]
    exact (div_lt_one hc0).mpr (by dsimp [c]; linarith)
  let G := fun t => (1/a)*expKernel l t
  have hG := (expKernel_integrable hl).const_mul (1/a)
  have hGn : ∀ᵐ t, 0≤G t := ae_of_all _ (fun t => mul_nonneg (by positivity) (expKernel_nonneg l t))
  have hGc : Causal G := by
    apply ae_of_all; intro t ht; simp [G,expKernel,causalize,not_le.mpr ht]
  have hGw : Integrable (expWeight (l/2) G) := by
    have hh := (expKernel_weighted (show l/2<l by linarith)).const_mul (1/a)
    convert hh using 1; funext t; dsimp [G,expWeight]; ring
  obtain ⟨r,hrn,hrc,hreq,hrw,_⟩ := positive_exp_renewal hK hKn hKc hq hG hGn hGc
    (half_pos hl) (evenCascadeKernel_weighted hc δ a c (show l/2<l by linarith)) hGw
  have hGtrans (p : ℝ) (hp : 0≤p) : laplace G p=1/(a*(p+l)) := by
    change (∫ t, Real.exp (-p*t)*((1/a)*expKernel l t) ∂halfLine)=_
    simp_rw [mul_left_comm _ (1/a)]
    rw [integral_const_mul]
    change (1/a)*laplace (expKernel l) p=_
    rw [expKernel_laplace hl hp]
    simp [div_eq_mul_inv,mul_comm]
  have htrans (p : ℝ) (hp : 0≤p) :
      (a*p+c-compactExpMoment J δ (-p))*laplace r p=1 := by
    have hh := renewal_laplace hK hKc (hG.toL1 G) r
      (causal_congr hGc hG.coeFn_toL1.symm) hrc hreq hp
    rw [laplace_congr_ae hG.coeFn_toL1,hGtrans p hp,
      evenCascadeKernel_laplace hc hδ ha hc0 hp] at hh
    have ha0 := ne_of_gt ha
    have hpl : p+c/a≠0 := ne_of_gt (by linarith [hl])
    dsimp [l] at hh
    field_simp at hh
    nlinarith [hh]
  refine ⟨r,hrn,hrc,hrw,?_,htrans⟩
  have hh := htrans 0 le_rfl
  simp only [c,compactExpMoment,compactMoment,neg_zero,zero_mul,Real.exp_zero,
    pow_zero,one_mul,mul_zero,add_sub_cancel_right,one_mul] at hh
  rw [← kernel_laplace_full hrc 0] at hh
  simpa [expWeight_zero] using hh

end MIACE
