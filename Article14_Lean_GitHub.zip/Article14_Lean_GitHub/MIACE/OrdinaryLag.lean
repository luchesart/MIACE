import MIACE.CascadeCone
import MIACE.PrimitiveRealization
import MIACE.WeightedRenewal

/-! Stage 13: ordinary lag states for locally integrable inputs, including
finite jumps. Existence and uniqueness are local statements and do not
assume stability, L1 integrability, or a terminal condition on the state. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:complete_attainment/local_input_interval_integrability
theorem locally_integrable_interval {u : ℝ → ℝ} (hu : LocallyIntegrable u volume)
    (a b : ℝ) : IntervalIntegrable u volume a b := by
  exact (intervalIntegrable_iff' (f := u) (a := a) (b := b)).mpr (hu.integrableOn_isCompact isCompact_uIcc)

-- @paper-step thm:complete_attainment/ordinary_lag_full_regularity
theorem ordinary_lag_regular {u : ℝ → ℝ} (hu : LocallyIntegrable u volume) (σ : ℝ) :
    Continuous (lag σ u) ∧
      (∀ a b, AbsolutelyContinuousOnInterval (lag σ u) a b) ∧
      (∀ᵐ t, HasDerivAt (lag σ u) ((u t-lag σ u t)/σ) t) := by
  have hw : LocallyIntegrable (fun s => Real.exp (s/σ)*u s) volume :=
    hu.continuous_mul (by fun_prop)
  have hi := locally_integrable_interval hw
  have hp := intervalIntegral.continuous_primitive hi 0
  refine ⟨(by fun_prop : Continuous (fun t : ℝ => Real.exp (-t/σ)/σ)).mul hp,?_,?_⟩
  · intro a b
    have hc : AbsolutelyContinuousOnInterval (fun t : ℝ => Real.exp (-t/σ)/σ) a b := by
      apply ContDiffOn.absolutelyContinuousOnInterval; fun_prop
    exact hc.mul (intervalPrimitive_ac hi 0 a b)
  · filter_upwards [LocallyIntegrable.ae_hasDerivAt_integral hw] with t ht
    have hc := (((hasDerivAt_id t).neg.div_const σ).exp).div_const σ
    have hd := hc.mul (ht 0)
    have he : Real.exp (-t/σ)*Real.exp (t/σ)=1 := by
      rw [← Real.exp_add]; ring_nf; simp
    convert hd using 1
    · rfl
    · by_cases hσ : σ=0
      · simp [hσ,lag]
      · dsimp [lag]
        field_simp [hσ]
        simp only [neg_div] at he
        nlinarith [congrArg (fun z => z*(u t*σ)) he]

-- @paper-step thm:command_cone/constructed_ordinary_lag_response
theorem ordinary_lag_response {u : ℝ → ℝ} (hu : LocallyIntegrable u volume) (σ : ℝ) :
    LagResponse σ u (lag σ u) := by
  have hr := ordinary_lag_regular hu σ
  exact ⟨fun T _ => hr.2.1 0 T,fun T _ => locally_integrable_interval hu 0 T,
    hr.2.2.mono (fun _ ht _ => ht.deriv),by simp [lag]⟩

-- @paper-step thm:command_cone/lag_deficit_recurrence
theorem lag_deficit {u : ℝ → ℝ} (hu : LocallyIntegrable u volume)
    {σ : ℝ} (hσ : 0<σ) (t : ℝ) :
    1-lag σ u t=Real.exp (-t/σ)+lag σ (fun s => 1-u s) t := by
  have hu' := (locally_integrable_interval hu 0 t).continuousOn_mul
    (by fun_prop : Continuous (fun s : ℝ => Real.exp (s/σ))).continuousOn
  have hc := (by fun_prop : Continuous (fun s : ℝ => Real.exp (s/σ))).intervalIntegrable (μ := volume) 0 t
  have hm := lag_kernel_mass σ t hσ
  unfold lag
  simp_rw [mul_sub,mul_one]
  rw [intervalIntegral.integral_sub hc hu']
  nlinarith

-- @paper-step thm:command_cone/ordinary_lag_deficit_integrability
theorem lag_deficit_integrable {u : ℝ → ℝ} (hu : LocallyIntegrable u volume)
    (he : Integrable (fun t => 1-u t) halfLine) {σ : ℝ} (hσ : 0<σ) :
    Integrable (fun t => 1-lag σ u t) halfLine := by
  have hexp : Integrable (fun t : ℝ => Real.exp (-t/σ)) halfLine := by
    change IntegrableOn (fun t : ℝ => Real.exp (-t/σ)) (Ioi 0) volume
    convert integrableOn_exp_mul_Ioi (div_neg_of_neg_of_pos (by norm_num : (-1 : ℝ)<0) hσ) 0 using 1
    ext t; congr 1; ring
  exact (hexp.add (lag_integrable he hσ)).congr (ae_of_all _ (fun t => (lag_deficit hu hσ t).symm))

noncomputable def ordinaryCascade (σ : ℕ → ℝ) (u : ℝ → ℝ) : ℕ → ℝ → ℝ
  | 0 => u
  | n+1 => lag (σ n) (ordinaryCascade σ u n)

-- @paper-step thm:command_cone/ordinary_cascade_local_integrability
theorem ordinaryCascade_local {u : ℝ → ℝ} (hu : LocallyIntegrable u volume)
    (σ : ℕ → ℝ) (n : ℕ) : LocallyIntegrable (ordinaryCascade σ u n) volume := by
  induction n with
  | zero => exact hu
  | succ n ih => exact (ordinary_lag_regular ih (σ n)).1.locallyIntegrable

-- @paper-step thm:command_cone/ordinary_cascade_actual_states
theorem ordinaryCascade_response {u : ℝ → ℝ} (hu : LocallyIntegrable u volume)
    (σ : ℕ → ℝ) (n : ℕ) :
    LagResponse (σ n) (ordinaryCascade σ u n) (ordinaryCascade σ u (n+1)) :=
  ordinary_lag_response (ordinaryCascade_local hu σ n) (σ n)

-- @paper-step thm:command_cone/ordinary_cascade_error_integrability
theorem ordinaryCascade_deficit_integrable {u : ℝ → ℝ}
    (hu : LocallyIntegrable u volume) (he : Integrable (fun t => 1-u t) halfLine)
    (σ : ℕ → ℝ) (n : ℕ) (hσ : ∀ j<n, 0<σ j) :
    Integrable (fun t => 1-ordinaryCascade σ u n t) halfLine := by
  induction n with
  | zero => exact he
  | succ n ih =>
    exact lag_deficit_integrable (ordinaryCascade_local hu σ n) (ih (fun j hj => hσ j (by omega)))
      (hσ n (by omega))

-- @paper-step thm:command_cone/actual_cascade_from_ordinary_command
theorem ordinaryCascade_command_cone {v : ℝ → ℝ} (hv : Integrable v)
    (hn : ∀ᵐ t ∂halfLine, 0≤v t) (N : ℕ) (σ : ℕ → ℝ) {δ : ℝ}
    (hδ : 0≤δ) (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1) :
    let x := ordinaryCascade σ (fun t => 1+v t)
    let y := fun t => 1-delayedError δ (fun s => 1-x (N+1) s) t
    ((∀ t : ℝ, 0≤t → y t≤1) ↔
      Integrable (fun t => Real.exp t*v t) halfLine ∧ moment v≤1) ∧
    ((Monotone y ∧ y 0=0 ∧ Tendsto y atTop (𝓝 1)) ↔
      Integrable (fun t => Real.exp t*v t) halfLine ∧ moment v≤1) := by
  have hu : LocallyIntegrable (fun t => 1+v t) volume :=
    (continuous_const : Continuous (fun _ : ℝ => (1 : ℝ))).locallyIntegrable.add hv.locallyIntegrable
  apply cascade_signal_cone N σ _ hδ hσ hfirst (fun j _ => ordinaryCascade_response hu σ j)
    rfl (hv.mono_measure Measure.restrict_le_self) hn
  apply delayedError_integrable δ hδ
  apply ordinaryCascade_deficit_integrable hu _ σ (N+1) (fun j hj => (hσ j (by omega)).1)
  convert (hv.mono_measure Measure.restrict_le_self).neg using 1
  ext t; simp

end MIACE
