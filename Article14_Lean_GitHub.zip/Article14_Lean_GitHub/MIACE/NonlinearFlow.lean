import MIACE.Dynamics
import MIACE.PositiveClock
import MIACE.NonlinearDecay
import Mathlib.Analysis.Calculus.ContDiff.Deriv
import Mathlib.Analysis.SpecialFunctions.Integrals.Basic

/-! A constructive global response for the nonlinear first-order MIACE class.
The construction uses the inverse of a strictly increasing time integral.
The original MIACE time and error are unchanged: the inverse clock is only
an auxiliary parametrization used to construct the physical response. -/

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def nonlinearClippedPhase (s : ℝ) : ℝ :=
  1 - Real.exp (- max s 0)

noncomputable def nonlinearClockRate (a : ℝ → ℝ) (c s : ℝ) : ℝ :=
  (c * a (nonlinearClippedPhase s))⁻¹

-- @paper-step thm:nonlinear_miace/clock_phase_range
theorem nonlinear_clipped_phase_mem (s : ℝ) :
    nonlinearClippedPhase s ∈ Icc (0 : ℝ) 1 := by
  have he : Real.exp (- max s 0) ≤ 1 := Real.exp_le_one_iff.mpr (by
    have := le_max_right s (0 : ℝ)
    linarith)
  have hp := Real.exp_pos (- max s 0)
  constructor <;> unfold nonlinearClippedPhase <;> linarith

-- @paper-step thm:nonlinear_miace/clock_continuity
theorem nonlinear_clock_rate_continuous {a : ℝ → ℝ} (ha : Continuous a)
    (hapos : ∀ x, 0 < a x) {c : ℝ} (hc : 0 < c) :
    Continuous (nonlinearClockRate a c) := by
  have hp : Continuous nonlinearClippedPhase := by
    unfold nonlinearClippedPhase
    fun_prop
  exact (continuous_const.mul (ha.comp hp)).inv₀ (fun s =>
    ne_of_gt (mul_pos hc (hapos _)))

-- @paper-step thm:nonlinear_miace/clock_uniform_bounds
theorem nonlinear_clock_rate_bounds {a : ℝ → ℝ} {c m M : ℝ}
    (hc : 0 < c) (hm : 0 < m)
    (hlo : ∀ x ∈ Icc (0 : ℝ) 1, m ≤ a x)
    (hup : ∀ x ∈ Icc (0 : ℝ) 1, a x ≤ M) (s : ℝ) :
    0 < (c * M)⁻¹ ∧ (c * M)⁻¹ ≤ nonlinearClockRate a c s ∧
      nonlinearClockRate a c s ≤ (c * m)⁻¹ := by
  have hl := hlo _ (nonlinear_clipped_phase_mem s)
  have hu := hup _ (nonlinear_clipped_phase_mem s)
  have hap : 0 < a (nonlinearClippedPhase s) := lt_of_lt_of_le hm hl
  have hM : 0 < M := lt_of_lt_of_le hap hu
  refine ⟨inv_pos.mpr (mul_pos hc hM), ?_, ?_⟩
  · exact inv_le_inv₀ (mul_pos hc hM) (mul_pos hc hap) |>.mpr
      (mul_le_mul_of_nonneg_left hu hc.le)
  · exact inv_le_inv₀ (mul_pos hc hap) (mul_pos hc hm) |>.mpr
      (mul_le_mul_of_nonneg_left hl hc.le)

-- @paper-step thm:nonlinear_miace/positive_compact_extrema
theorem nonlinear_positive_extrema {a : ℝ → ℝ} (ha : Continuous a)
    (hapos : ∀ x, 0 < a x) :
    ∃ m M : ℝ, 0 < m ∧
      (∃ xm ∈ Icc (0 : ℝ) 1, a xm = m) ∧
      (∃ xM ∈ Icc (0 : ℝ) 1, a xM = M) ∧
      (∀ x ∈ Icc (0 : ℝ) 1, m ≤ a x) ∧
      (∀ x ∈ Icc (0 : ℝ) 1, a x ≤ M) := by
  obtain ⟨xm, hxm, hmin⟩ := isCompact_Icc.exists_isMinOn
    (show (Icc (0 : ℝ) 1).Nonempty from ⟨0, by norm_num⟩) ha.continuousOn
  obtain ⟨xM, hxM, hmax⟩ := isCompact_Icc.exists_isMaxOn
    (show (Icc (0 : ℝ) 1).Nonempty from ⟨0, by norm_num⟩) ha.continuousOn
  exact ⟨a xm, a xM, hapos xm, ⟨xm, hxm, rfl⟩, ⟨xM, hxM, rfl⟩,
    fun x hx => hmin hx, fun x hx => hmax hx⟩

-- @paper-step thm:nonlinear_miace/global_flow_construction
theorem nonlinear_flow_exists {a : ℝ → ℝ} (ha : Continuous a)
    (hapos : ∀ x, 0 < a x) {c m M : ℝ} (hc : 0 < c) (hm : 0 < m)
    (hlo : ∀ x ∈ Icc (0 : ℝ) 1, m ≤ a x)
    (hup : ∀ x ∈ Icc (0 : ℝ) 1, a x ≤ M) :
    ∃ y : ℝ → ℝ, ContDiff ℝ 1 y ∧ y 0 = 0 ∧
      (∀ t, 0 ≤ t → HasDerivAt y (c * a (y t) * (1-y t)) t) ∧
      (∀ t, 0 ≤ t → 0 ≤ y t ∧ y t < 1 ∧
        Real.exp (-c*M*t) ≤ 1-y t ∧ 1-y t ≤ Real.exp (-c*m*t)) := by
  have hq := nonlinear_clock_rate_continuous ha hapos hc
  have hb := nonlinear_clock_rate_bounds hc hm hlo hup
  have hM : 0 < M := lt_of_lt_of_le (hapos 0) (hup 0 (by norm_num))
  obtain ⟨s, hs0, hsmono, hscont, hsder, hsb⟩ := positiveClock_exists_inverse
    (nonlinearClockRate a c) hq ((c*M)⁻¹) ((c*m)⁻¹) (hb 0).1
    (fun x => (hb x).2.1) (fun x => (hb x).2.2)
  have hsC : ContDiff ℝ 1 s := nonlinear_inverse_clock_contDiff hq hscont
    (fun x => ne_of_gt ((hb x).1.trans_le (hb x).2.1)) hsder
  let y : ℝ → ℝ := fun t => 1 - Real.exp (-s t)
  have hyC : ContDiff ℝ 1 y := by
    dsimp [y]
    fun_prop
  refine ⟨y, hyC, ?_, ?_, ?_⟩
  · simp [y, hs0]
  · intro t ht
    have hs := (hsb t ht).1
    convert ((hsder t).neg.exp).const_sub (1 : ℝ) using 1
    dsimp [y]
    simp only [nonlinearClockRate, nonlinearClippedPhase, max_eq_left hs, inv_inv]
    ring
  · intro t ht
    obtain ⟨hs, hsl, hsu⟩ := hsb t ht
    have hloS : c*m*t ≤ s t := by
      have heq : t ≤ s t / (c*m) := by
        simpa only [div_eq_mul_inv, mul_comm] using hsu
      have hi := (le_div_iff₀ (mul_pos hc hm)).mp heq
      nlinarith
    have hupS : s t ≤ c*M*t := by
      have heq : s t / (c*M) ≤ t := by
        simpa only [div_eq_mul_inv, mul_comm] using hsl
      have hi := (div_le_iff₀ (mul_pos hc hM)).mp heq
      nlinarith
    have hep : 0 < Real.exp (-s t) := Real.exp_pos _
    have he1 : Real.exp (-s t) ≤ 1 := Real.exp_le_one_iff.mpr (by linarith)
    have hel : Real.exp (-c*M*t) ≤ Real.exp (-s t) :=
      Real.exp_le_exp.mpr (by nlinarith)
    have heu : Real.exp (-s t) ≤ Real.exp (-c*m*t) :=
      Real.exp_le_exp.mpr (by nlinarith)
    dsimp [y]
    exact ⟨by linarith, by linarith, by linarith, by linarith⟩

-- @paper-step thm:nonlinear_miace/global_flow_admissibility
theorem nonlinear_flow_exists_admissible {a : ℝ → ℝ} (ha : Continuous a)
    (hapos : ∀ x, 0 < a x) {c m M : ℝ} (hc : 0 < c) (hm : 0 < m)
    (hlo : ∀ x ∈ Icc (0 : ℝ) 1, m ≤ a x)
    (hup : ∀ x ∈ Icc (0 : ℝ) 1, a x ≤ M) :
    ∃ y : ℝ → ℝ, ContDiff ℝ 1 y ∧ y 0 = 0 ∧
      (∀ t, 0 ≤ t → HasDerivAt y (c * a (y t) * (1-y t)) t) ∧
      (∀ t, 0 ≤ t → 0 ≤ y t ∧ y t < 1 ∧
        Real.exp (-c*M*t) ≤ 1-y t ∧ 1-y t ≤ Real.exp (-c*m*t)) ∧
      Tendsto y atTop (𝓝 1) ∧ Integrable (fun t => 1-y t) halfLine := by
  obtain ⟨y, hyC, hy0, hyd, hyb⟩ := nonlinear_flow_exists ha hapos hc hm hlo hup
  have hb : ∀ t, 0 ≤ t → 0 ≤ 1-y t ∧ 1-y t ≤ Real.exp (-(c*m)*t) := by
    intro t ht
    have hb := hyb t ht
    exact ⟨by linarith [hb.2.1], by simpa only [neg_mul] using hb.2.2.2⟩
  exact ⟨y, hyC, hy0, hyd, hyb,
    nonlinear_settling_of_exp_bound (mul_pos hc hm) hb,
    nonlinear_integrable_of_exp_bound hyC.continuous (mul_pos hc hm) hb⟩

end MIACE
