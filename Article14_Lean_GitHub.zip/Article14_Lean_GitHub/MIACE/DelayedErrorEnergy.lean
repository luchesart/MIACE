import MIACE.DelayEnergyEndpoint
import MIACE.Lemma6Completion

/-! Stage 19. Normalize the actual scalar-delay step response, retain its
waiting interval, and derive square integrability before evaluating energy. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step prop:delayed_quadratic/normalized_actual_step_trajectory
theorem scalarDelay_response_normalized {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    {E : ℝ → ℝ} (hE : ScalarDelayResponse x δ E) :
    let W := fun t => E (t/x+δ)
    Continuous W ∧ (∀ t, 0<t → HasDerivAt W (-W (t-x*δ)) t) ∧
      (∀ t∈Icc (-(x*δ)) 0, W t=1) := by
  dsimp only
  refine ⟨hE.continuous.comp (by fun_prop),?_,?_⟩
  · intro t ht
    have hd := (scalarDelay_derivative_after hδ hE
      (show δ<t/x+δ by linarith [div_pos ht hx])).comp t
        (((hasDerivAt_id t).div_const x).add_const δ)
    convert hd using 1
    · rfl
    · have he : (t-x*δ)/x+δ=t/x := by field_simp; ring
      rw [he]
      simp only [add_sub_cancel_right]
      field_simp
  · intro t ht
    apply scalarDelay_plateau hE
    · have hm := (le_div_iff₀ hx).mpr (show -δ*x≤t by nlinarith [ht.1])
      linarith
    · have hm := div_nonpos_of_nonpos_of_nonneg ht.2 hx.le
      linarith

-- @paper-step prop:delayed_quadratic/energy_rescaling_including_waiting_interval
theorem scalarDelay_energy_rescaling {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    {E : ℝ → ℝ} (hE : ScalarDelayResponse x δ E) {T : ℝ} (hT : δ≤T) :
    (∫ t in (0 : ℝ)..T, (E t)^2)=δ+
      (∫ t in (0 : ℝ)..x*(T-δ), (E (t/x+δ))^2)/x := by
  have hwait : (∫ t in (0 : ℝ)..δ, (E t)^2)=δ := by
    calc
      _ = ∫ t in (0 : ℝ)..δ, (1 : ℝ) := by
        apply intervalIntegral.integral_congr
        intro t ht
        rw [uIcc_of_le hδ] at ht
        dsimp only; rw [scalarDelay_plateau hE ht.1 ht.2]; norm_num
      _ = _ := by simp
  have hs := intervalIntegral.smul_integral_comp_mul_left
    (fun t => (E (t/x+δ))^2) x (a := 0) (b := T-δ)
  simp only [smul_eq_mul,mul_zero] at hs
  have hi : (∫ t in (0 : ℝ)..T-δ, (E (x*t/x+δ))^2)=∫ t in δ..T, (E t)^2 := by
    simp only [mul_div_cancel_left₀ _ (ne_of_gt hx)]
    simpa using intervalIntegral.integral_comp_add_right (fun t => (E t)^2) δ (a := 0) (b := T-δ)
  change x*(∫ t in (0 : ℝ)..T-δ, (E (x*t/x+δ))^2)=_ at hs
  rw [hi] at hs
  have hadj := intervalIntegral.integral_add_adjacent_intervals
    ((hE.continuous.pow 2).intervalIntegrable (μ := volume) 0 δ)
    ((hE.continuous.pow 2).intervalIntegrable (μ := volume) δ T)
  simp only [Pi.pow_apply] at hadj
  rw [hwait] at hadj
  rw [← hadj,← hs]
  field_simp

-- @paper-step prop:delayed_quadratic/square_integrability_on_entire_stable_domain
theorem scalarDelay_response_square_integrable {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    (hb : x*δ<Real.pi/2) {E : ℝ → ℝ} (hE : ScalarDelayResponse x δ E) :
    Integrable (fun t => (E t)^2) halfLine := by
  obtain ⟨hw,hd,_⟩ := scalarDelay_response_normalized hx hδ hE
  let V := scalarDelayLyapunov (x*δ) (fun t => E (t/x+δ)) 0
  apply integrableOn_Ioi_of_intervalIntegral_norm_bounded (δ+V/x) 0
    (fun T : ℝ => (hE.continuous.pow 2).integrableOn_Icc.mono_set Ioc_subset_Icc_self) tendsto_id
  filter_upwards [eventually_ge_atTop δ] with T hT
  simp only [Real.norm_eq_abs,Pi.pow_apply,id_eq,abs_pow,sq_abs]
  rw [scalarDelay_energy_rescaling hx hδ hE hT]
  exact add_le_add le_rfl (div_le_div_of_nonneg_right
    (scalarDelay_energy_bound (mul_nonneg hx.le hδ) hb hw hd
      (mul_nonneg hx.le (sub_nonneg.mpr hT))) hx.le)

-- @paper-step prop:delayed_quadratic/exact_error_energy_for_actual_response
theorem scalarDelay_response_energy {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    (hb : x*δ<Real.pi/2) {E : ℝ → ℝ} (hE : ScalarDelayResponse x δ E) :
    (∫ t, (E t)^2 ∂halfLine)=(1+Real.sin (x*δ))/(2*x*Real.cos (x*δ)) := by
  obtain ⟨hw,hd,hpast⟩ := scalarDelay_response_normalized hx hδ hE
  have h0 := mul_nonneg hx.le hδ
  have hi := scalarDelay_square_integrable h0 hb hw hd
  have htime : Tendsto (fun T : ℝ => x*(T-δ)) atTop atTop :=
    (show Tendsto (fun T : ℝ => T-δ) atTop atTop from by
      apply tendsto_atTop.2
      intro b
      filter_upwards [eventually_ge_atTop (b+δ)] with T hT
      linarith).const_mul_atTop hx
  have hl := intervalIntegral_tendsto_integral_Ioi 0 hi htime
  have hformula := (scalarDelay_exact_energy h0 hb hw hd).trans
    (scalarDelayLyapunov_constant_history h0 hb hw hpast)
  rw [hformula] at hl
  have hlim := (tendsto_const_nhds (x := δ)).add (hl.div_const x)
  have heq : (fun T : ℝ => ∫ t in (0 : ℝ)..T, (E t)^2)=ᶠ[atTop]
      (fun T => δ+(∫ t in (0 : ℝ)..x*(T-δ), (E (t/x+δ))^2)/x) := by
    filter_upwards [eventually_ge_atTop δ] with T hT
    exact scalarDelay_energy_rescaling hx hδ hE hT
  have he := tendsto_nhds_unique (intervalIntegral_tendsto_integral_Ioi 0
    (scalarDelay_response_square_integrable hx hδ hb hE) tendsto_id) (hlim.congr' heq.symm)
  change (∫ t, (E t)^2 ∂halfLine)=δ+((1+Real.sin (x*δ))/(2*Real.cos (x*δ))-x*δ)/x at he
  rw [he]
  field_simp
  <;> ring

-- @paper-step prop:delayed_quadratic/actual_error_decay_on_stable_domain
theorem scalarDelay_response_decay {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    (hb : x*δ<Real.pi/2) {E : ℝ → ℝ} (hE : ScalarDelayResponse x δ E) :
    Tendsto E atTop (𝓝 0) := by
  obtain ⟨hw,hd,_⟩ := scalarDelay_response_normalized hx hδ hE
  have hl := (scalarDelay_history_decay (mul_nonneg hx.le hδ) hb hw hd).comp
    ((show Tendsto (fun T : ℝ => T-δ) atTop atTop from by
      apply tendsto_atTop.2
      intro b
      filter_upwards [eventually_ge_atTop (b+δ)] with T hT
      linarith).const_mul_atTop hx)
  simpa only [Function.comp_def,mul_div_cancel_left₀ _ (ne_of_gt hx),sub_add_cancel] using hl

end MIACE
