import MIACE.IMCStateInterface
import MIACE.RobustCost

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- All errors and command excesses are extended by zero to negative time.
-- Thus their full-line L1 norms are exactly the paper's half-line norms.
structure IMCStepResponse (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) (δ ε : ℝ)
    (w e v : ℝ → ℝ) : Prop where
  ordinary_command : LocallyIntegrable w volume
  causal_command : Causal w
  feedback : w=ᵐ[volume] imcReferenceFeedback N σ F δ ε zeroIMCHistory unitStep w
  error_integrable : Integrable e
  excess_integrable : Integrable v
  error_causal : Causal e
  excess_causal : Causal v
  command_excess : v=ᵐ[volume] (fun t => w t-unitStep t)
  actual_error : e=ᵐ[volume] (fun t => unitStep t-
    plantHistoryOutput N σ (fun _ => 0) (δ+ε) (fun _ => 0) w t)

-- @paper-step thm:complete_robust/causal_signal_area_is_paper_area
theorem causal_absArea_halfLine {f : ℝ → ℝ} (hf : Causal f) :
    absArea f volume=absArea f halfLine := by
  apply causal_integral_halfLine
  filter_upwards [hf] with t ht hn
  simp [ht hn]

-- @paper-step thm:complete_robust/causal_signal_MIACE_is_paper_MIACE
theorem causal_miace_halfLine {e v : ℝ → ℝ} (he : Causal e) (hv : Causal v) (α : ℝ) :
    miace α e v volume=miace α e v halfLine := by
  simp only [miace,causal_absArea_halfLine he,causal_absArea_halfLine hv]

-- @paper-step thm:complete_robust/full_actual_delay_robustness
theorem paper_complete_robust (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) {δ ε α : ℝ}
    (hδ : 0≤δ) (hδε : 0≤δ+ε) (hα : 0≤α)
    (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1)
    {v0 : ℝ → ℝ} (hNom : NominalCascadeIMC N σ F δ v0)
    (hbase : ∀ᵐ t, 0≤filterAction F (lagKernel 1) t) (hDC : filterTransfer F 0=1)
    (hq : imcDelayGain F ε<1) :
    IMCInternallyStable N σ F δ ε ∧
      ∃ w e v : ℝ → ℝ, IMCStepResponse N σ F δ ε w e v ∧
        absArea (fun t => v t-v0 t) halfLine≤(filterGain F)^2*|ε|/(1-imcDelayGain F ε) ∧
        absArea (fun t => e t-cascadeStepError N σ δ v0 t) halfLine≤
          2*filterGain F*|ε|/(1-imcDelayGain F ε) ∧
        |miace α e v halfLine-miace α (cascadeStepError N σ δ v0) v0 halfLine|≤
          filterGain F*|ε| *Real.sqrt (4+α*(filterGain F)^2)/(1-imcDelayGain F ε) := by
  have hs := serialRatios_normalized σ N hσ
  have hsp : ∀ τ∈serialRatios σ N, 0<τ := fun τ hτ => (hs τ hτ).1
  let ss := serialRatios σ N
  let P := shift δ (cascadeKernel ss)
  let Pe := shift (δ+ε) (cascadeKernel ss)
  let D := delayMismatchKernel ss δ ε
  have hK := cascadeKernel_properties ss hsp
  have hP : Integrable P := shift_integrable δ hK.1
  have hPe : Integrable Pe := shift_integrable (δ+ε) hK.1
  have hPc : Causal P := causal_shift hK.2.2.2 hδ
  have hPec : Causal Pe := causal_shift hK.2.2.2 hδε
  have hPF := filtered_delayed_kernel F ss hsp hδ hbase hDC
  obtain ⟨z,hz,hzc,hze,hzB⟩ := imc_step_auxiliary F ss hsp hδ hδε hq
  have hg := delayMismatch_step_properties ss hsp hδ hδε
  have hid := imc_perturbed_step_identity F hP hPe hPc hPec hz hzc hg.1 hze
  let c := filterAction F (filterAction F z)
  let E := filterAction F (fun t => z t-(P ⋆ filterAction F z) t)
  let e0 := causalize (cascadeStepError N σ δ v0)
  let V0 := causalize v0
  let e := fun t => e0 t-E t
  let v := fun t => V0 t-c t
  have hc : Integrable c := filterAction_integrable F (filterAction_integrable F hz)
  have hcc : Causal c := filterAction_causal F (filterAction_causal F hzc)
  have hPb := hP.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) (filterAction_integrable F hz)
  have hPbc : Causal (P ⋆ filterAction F z) :=
    ae_of_all volume (convolution_causal hPc (filterAction_causal F hzc))
  have hEi : Integrable E := filterAction_integrable F (hz.sub hPb)
  have hEc : Causal E := by
    apply filterAction_causal
    filter_upwards [hzc,hPbc] with t ht hs hn
    change z t-(P ⋆ filterAction F z) t=0
    rw [ht hn,hs hn,sub_self]
  have htransfer := ordinaryCascade_transfer_response hNom.command_integrable σ (N+1)
    (fun j hj => (hσ j (by omega)).1) hδ
  have he0 : Integrable e0 := causalize_integrable htransfer.error_integrable
  have hV0 : Integrable V0 := causalize_integrable htransfer.command_integrable
  have hei : Integrable e := he0.sub hEi
  have hvi : Integrable v := hV0.sub hc
  have hec : Causal e := by
    filter_upwards [causalize_causal (cascadeStepError N σ δ v0),hEc] with t ht hs hn
    change causalize (cascadeStepError N σ δ v0) t-E t=0
    rw [ht hn,hs hn,sub_self]
  have hvc : Causal v := by
    filter_upwards [causalize_causal v0,hcc] with t ht hs hn
    change causalize v0 t-c t=0
    rw [ht hn,hs hn,sub_self]
  have hnomE := nominal_step_error_kernel N σ F hδ hNom.command_integrable
    (fun j hj => (hσ j hj).1) hNom.step_filter
  rw [serialImpulse_eq_cascade σ hfirst N] at hnomE
  have hnomV := nominal_step_excess_kernel F hNom.step_filter
  have hresponse : IMCStepResponse N σ F δ ε (imcPerturbedStep F z) e v := by
    refine ⟨hid.1,hid.2.1,?_,hei,hvi,hec,hvc,?_,?_⟩
    · exact hid.2.2.1.trans (zeroHistory_reference_feedback N σ F hδ hδε
        (fun j hj => (hσ j hj).1) hfirst hid.1 hid.2.1).symm
    · filter_upwards [hnomV] with t ht
      change V0 t-c t=filterAction F unitStep t-c t-unitStep t
      change V0 t=filterAction F unitStep t-unitStep t at ht
      linarith
    · have hplant := zeroHistory_plant_kernel N σ (δ+ε) (fun j hj => (hσ j hj).1) hid.1 hid.2.1
      rw [serialImpulse_eq_cascade σ hfirst N] at hplant
      filter_upwards [hnomE,hid.2.2.2,hplant] with t ht hs hj
      change e0 t=unitStep t-(P ⋆ filterAction F unitStep) t at ht
      change (Pe ⋆ imcPerturbedStep F z) t-(P ⋆ filterAction F unitStep) t=E t at hs
      change plantHistoryOutput N σ (fun _ => 0) (δ+ε) (fun _ => 0) (imcPerturbedStep F z) t=
        (Pe ⋆ imcPerturbedStep F z) t at hj
      change e0 t-E t=unitStep t-_
      rw [hj]
      linarith
  have hgains := imc_step_difference_gains F hP hPc hz hzc hPF.2.2.2.le
  have hf : 0≤filterGain F := by unfold filterGain; positivity
  have hcB : absArea c volume≤(filterGain F)^2*|ε|/(1-imcDelayGain F ε) := by
    have hh := hgains.1.trans (mul_le_mul_of_nonneg_left hzB (sq_nonneg (filterGain F)))
    exact hh.trans_eq (by ring)
  have hEB : absArea E volume≤2*filterGain F*|ε|/(1-imcDelayGain F ε) := by
    have hh := hgains.2.trans (mul_le_mul_of_nonneg_left hzB (by positivity))
    exact hh.trans_eq (by ring)
  have hvdiff : absArea (fun t => v t-V0 t) volume=absArea c volume := by
    apply integral_congr_ae
    exact ae_of_all _ (fun t => by change |V0 t-c t-V0 t|=|c t|; ring_nf; rw [abs_neg])
  have hediff : absArea (fun t => e t-e0 t) volume=absArea E volume := by
    apply integral_congr_ae
    exact ae_of_all _ (fun t => by change |e0 t-E t-e0 t|=|E t|; ring_nf; rw [abs_neg])
  have hvfull : absArea (fun t => v t-V0 t) volume≤(filterGain F)^2*|ε|/(1-imcDelayGain F ε) := by
    rwa [hvdiff]
  have hefull : absArea (fun t => e t-e0 t) volume≤2*filterGain F*|ε|/(1-imcDelayGain F ε) := by
    rwa [hediff]
  have hvhalf : absArea (fun t => v t-v0 t) halfLine=absArea c volume := by
    have hh : (fun t => v t-v0 t)=ᵐ[halfLine] (fun t => -c t) := by
      filter_upwards [causalize_halfLine v0] with t ht
      change V0 t-c t-v0 t= -c t
      change V0 t=v0 t at ht
      rw [ht]; ring
    rw [absArea_congr hh]
    unfold absArea
    simp_rw [abs_neg]
    exact (causal_absArea_halfLine hcc).symm
  have hehalf : absArea (fun t => e t-cascadeStepError N σ δ v0 t) halfLine=absArea E volume := by
    have hh : (fun t => e t-cascadeStepError N σ δ v0 t)=ᵐ[halfLine] (fun t => -E t) := by
      filter_upwards [causalize_halfLine (cascadeStepError N σ δ v0)] with t ht
      change e0 t-E t-cascadeStepError N σ δ v0 t= -E t
      change e0 t=cascadeStepError N σ δ v0 t at ht
      rw [ht]; ring
    rw [absArea_congr hh]
    unfold absArea
    simp_rw [abs_neg]
    exact (causal_absArea_halfLine hEc).symm
  refine ⟨imc_internal_stability N σ F hδ hδε hσ hfirst hq,
    imcPerturbedStep F z,e,v,hresponse,?_,?_,?_⟩
  · rwa [hvhalf]
  · rwa [hehalf]
  · have hh := robust_miace_bound hei hvi he0 hV0 hα hf (abs_nonneg ε) hq hefull hvfull
    rw [causal_miace_halfLine hec hvc,miace_causalize] at hh
    exact hh

end MIACE
