import MIACE.AttainmentContinuation

/-! Stage 19. Necessary structure of every attaining genuine filtered PID.
The input certificate specifies the ordinary time-domain controller law and
the physical plant. Analytic continuation and cancellation are conclusions. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

structure FilteredPIDResponse (pc i dc ρ δ : ℝ) (E V : ℝ → ℝ) : Prop where
  error_continuous : Continuous E
  command_continuous : Continuous V
  plant : TransferResponse E V (fun p => 1/(1+p)) δ
  command : ∀ t, 0≤t → pidTimeCommand pc i dc ρ E t=1+V t

noncomputable def pidNumerator (pc i dc ρ p : ℝ) : ℝ :=
  (pc*ρ+dc)*p^2+(pc+i*ρ)*p+i
noncomputable def pidDenominator (pc i dc ρ δ p : ℝ) : ℝ :=
  p*(p+1)*(1+ρ*p)+pidNumerator pc i dc ρ p*Real.exp (-δ*p)

-- @paper-step prop:pid_necessary_structure/transform_of_actual_general_PID_command
theorem generalPID_command_transform {pc i dc ρ δ : ℝ} {E V : ℝ → ℝ}
    (h : FilteredPIDResponse pc i dc ρ δ E V) (hρ : 0<ρ) {p : ℝ} (hp : 0<p) :
    (pc+i/p+dc*p/(1+ρ*p))*laplace E p=1/p+laplace V p := by
  have he : pidTimeCommand pc i dc ρ E=ᵐ[halfLine] (fun t => 1+V t) := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact h.command t (show 0<t from ht).le
  rw [← (pidTimeCommand_transform h.plant.error_integrable pc i dc hρ hp).2,
    laplace_congr_halfLine he,(laplace_step_add h.plant.command_integrable hp).2]

-- @paper-step prop:pid_necessary_structure/multiplied_PID_error_identity_before_continuation
theorem generalPID_error_identity {pc i dc ρ δ : ℝ} {E V : ℝ → ℝ}
    (h : FilteredPIDResponse pc i dc ρ δ E V) (hρ : 0<ρ) {p : ℝ} (hp : 0<p) :
    pidDenominator pc i dc ρ δ p*laplace E p=(p+1)*(1+ρ*p) := by
  have hc := generalPID_command_transform h hρ hp
  have he := transfer_error_identity h.plant p hp
  have hp0 := ne_of_gt hp
  have hf : 1+ρ*p≠0 := ne_of_gt (by positivity)
  have hp1 : 1+p≠0 := ne_of_gt (by linarith)
  field_simp [hp0,hf,hp1] at hc he
  unfold pidDenominator pidNumerator
  simp only [neg_mul,mul_comm δ p] at hc he ⊢
  linear_combination (1+ρ*p)*he + Real.exp (-(p*δ))*hc

-- @paper-step prop:pid_necessary_structure/continued_error_identity_is_derived_from_attainment
theorem attaining_PID_extended_identity {pc i dc ρ δ α : ℝ} {E V : ℝ → ℝ}
    (h : FilteredPIDResponse pc i dc ρ δ E V) (hρ : 0<ρ) (hα : 0<α) (hδ : 0≤δ)
    (hcost : miace α E V halfLine=(1+δ)*minimum α) :
    ∀ p, -1<p → pidDenominator pc i dc ρ δ p*laplace E p=(p+1)*(1+ρ*p) := by
  obtain ⟨hnE,hnV,_,_⟩ := attaining_firstOrder_signs h.plant h.error_continuous h.command_continuous hα hδ hcost
  have hbound := attaining_error_exp_bound h.plant h.error_continuous h.command_continuous hδ hnE hnV
  have hL := laplace_real_analytic h.error_continuous (Real.exp_nonneg δ) hbound
  apply analytic_identity_from_positive
  · intro p hp
    apply AnalyticAt.mul
    · unfold pidDenominator pidNumerator
      fun_prop
    · exact hL p hp
  · intro p _; fun_prop
  · intro p hp; exact generalPID_error_identity h hρ hp

-- @paper-step prop:pid_necessary_structure/filter_upper_bound_and_forced_plant_cancellation
theorem attaining_PID_structure {pc i dc ρ δ α : ℝ} {E V : ℝ → ℝ}
    (h : FilteredPIDResponse pc i dc ρ δ E V) (hi : 0 < i) (hd : 0<dc) (hρ : 0<ρ)
    (hα : 0<α) (hδ : 0≤δ) (hcost : miace α E V halfLine=(1+δ)*minimum α) :
    ρ<1 ∧ i < pc ∧ dc=(1-ρ)*(pc-i) := by
  obtain ⟨hnE,hnV,_,hm⟩ := attaining_firstOrder_signs h.plant h.error_continuous h.command_continuous hα hδ hcost
  have hbound := attaining_error_exp_bound h.plant h.error_continuous h.command_continuous hδ hnE hnV
  have he := attaining_PID_extended_identity h hρ hα hδ hcost
  have hQ : pidNumerator pc i dc ρ (-1)=0 := by
    have hc := laplace_boundary_cancellation h.error_continuous h.plant.error_integrable hbound hnE hm
      (D := pidDenominator pc i dc ρ δ) (N := fun p => (p+1)*(1+ρ*p))
      (by unfold pidDenominator pidNumerator; fun_prop) (by fun_prop) (by norm_num) he
    simpa [pidDenominator] using (mul_eq_zero.mp (show
      pidNumerator pc i dc ρ (-1)*Real.exp δ=0 by simpa [pidDenominator] using hc)).resolve_right
        (Real.exp_ne_zero δ)
  have hrle : ρ≤1 := by
    by_contra hh
    have hrgt : 1<ρ := lt_of_not_ge hh
    have hp : -1< -1/ρ := by apply (lt_div_iff₀ hρ).mpr; linarith
    have hp0 : -1/ρ≤0 := div_nonpos_of_nonpos_of_nonneg (by norm_num) hρ.le
    have hLp := hm.trans_le (laplace_negative_lower_bound h.error_continuous h.plant.error_integrable
      hbound hnE hp hp0)
    have hx := he (-1/ρ) hp
    have hnum : pidNumerator pc i dc ρ (-1/ρ)=dc/ρ^2 := by
      unfold pidNumerator; field_simp; ring
    have hfilter : 1+ρ*(-1/ρ)=0 := by field_simp; ring
    rw [pidDenominator,hfilter,hnum] at hx
    simp only [mul_zero,zero_add] at hx
    have hpos : 0<(dc/ρ^2)*Real.exp (-δ*(-1/ρ))*laplace E (-1/ρ) := by positivity
    linarith
  have hrne : ρ≠1 := by intro hh; subst ρ; norm_num [pidNumerator] at hQ; linarith
  have hrlt : ρ<1 := lt_of_le_of_ne hrle hrne
  have hdc : dc=(1-ρ)*(pc-i) := by dsimp [pidNumerator] at hQ; nlinarith
  refine ⟨hrlt,?_,hdc⟩
  have hp : 0<pc-i := (mul_pos_iff.mp (show 0<(1-ρ)*(pc-i) by rw [← hdc]; exact hd)).resolve_right
    (by rintro ⟨hneg,_⟩; linarith)
    |>.2
  linarith

-- @paper-step prop:pid_necessary_structure/paper_proposition_all_clauses
theorem paper_PID_necessary_structure {pc i dc ρ δ α : ℝ} {E V : ℝ → ℝ}
    (h : FilteredPIDResponse pc i dc ρ δ E V) (hpc : 0<pc) (hi : 0 < i) (hd : 0<dc) (hρ : 0<ρ)
    (hα : 0<α) (hδ : 0≤δ) (hcost : miace α E V halfLine=(1+δ)*minimum α) :
    (0<ρ ∧ ρ<1 ∧ i < pc ∧ dc=(1-ρ)*(pc-i)) ∧
    ∃ ell : ℝ, ρ<ell ∧ pc=i*(1+ell-ρ) ∧ dc=i*(ell-ρ)*(1-ρ) ∧
      (∀ p : ℝ, pidNumerator pc i dc ρ p=i*(p+1)*(1+ell*p)) ∧
      ∀ p : ℝ, p≠0 → 1+ρ*p≠0 →
        pc+i/p+dc*p/(1+ρ*p)=i*(p+1)*(1+ell*p)/(p*(1+ρ*p)) := by
  obtain ⟨hr,hp,hdc⟩ := attaining_PID_structure h hi hd hρ hα hδ hcost
  let ell := ρ+(pc-i)/i
  have hl : ρ<ell := by dsimp [ell]; linarith [div_pos (sub_pos.mpr hp) hi]
  have hpc' : pc=i*(1+ell-ρ) := by dsimp [ell]; field_simp; ring
  have hdc' : dc=i*(ell-ρ)*(1-ρ) := by rw [hdc]; dsimp [ell]; field_simp; ring
  refine ⟨⟨hρ,hr,hp,hdc⟩,ell,hl,hpc',hdc',?_,?_⟩
  · intro p; rw [hpc',hdc']; exact pid_polynomial_factor i ρ ell p
  · intro p hp hf; rw [hpc',hdc']; exact pid_controller_factor i ρ ell p hp hf

end MIACE
