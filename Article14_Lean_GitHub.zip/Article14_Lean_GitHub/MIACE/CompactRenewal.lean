import MIACE.RationalCascade
import MIACE.SignedOrdinary
import MIACE.LaplaceLinear

/-! Concrete positive convolution kernels for both parities in Theorem 17.
All masses and exponential moments are Lebesgue integrals of those kernels. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

noncomputable def expKernel (l : ℝ) : ℝ → ℝ :=
  causalize (fun t => Real.exp (-l*t))
noncomputable def compactKernel (J : ℝ → ℝ) (δ : ℝ) : ℝ → ℝ :=
  (Icc 0 δ).indicator J

-- @paper-step thm:n_construction/compact_kernel_integrable
theorem compactKernel_integrable {J : ℝ → ℝ} (hJ : Continuous J) (δ : ℝ) :
    Integrable (compactKernel J δ) :=
  (hJ.integrableOn_Icc).integrable_indicator measurableSet_Icc

-- @paper-step thm:n_construction/compact_kernel_causal
theorem compactKernel_causal (J : ℝ → ℝ) (δ : ℝ) : Causal (compactKernel J δ) := by
  apply ae_of_all; intro t ht
  simp [compactKernel,show ¬0≤t from not_le.mpr ht]

-- @paper-step thm:n_construction/compact_kernel_nonnegative
theorem compactKernel_nonneg {J : ℝ → ℝ} {δ : ℝ}
    (hJ : ∀ t∈Icc (0 : ℝ) δ, 0≤J t) (t : ℝ) : 0≤compactKernel J δ t := by
  by_cases ht : t∈Icc (0 : ℝ) δ
  · simpa [compactKernel,ht] using hJ t ht
  · simp [compactKernel,ht]

-- @paper-step thm:n_construction/compact_kernel_exponential_integrability
theorem compactKernel_weighted {J : ℝ → ℝ} (hJ : Continuous J) (δ η : ℝ) :
    Integrable (expWeight η (compactKernel J δ)) := by
  have he : expWeight η (compactKernel J δ)=
      compactKernel (fun t => Real.exp (η*t)*J t) δ := by
    funext t; by_cases ht : t∈Icc (0 : ℝ) δ <;> simp [expWeight,compactKernel,ht]
  rw [he]
  exact compactKernel_integrable ((by fun_prop : Continuous (fun t : ℝ => Real.exp (η*t))).mul hJ) δ

-- @paper-step thm:n_construction/compact_kernel_exact_moment
theorem compactKernel_moment (J : ℝ → ℝ) {δ : ℝ} (hδ : 0≤δ) (η : ℝ) :
    (∫ t, expWeight η (compactKernel J δ) t)=compactExpMoment J δ η := by
  have he : expWeight η (compactKernel J δ)=
      (Icc (0 : ℝ) δ).indicator (fun t => Real.exp (η*t)*J t) := by
    funext t; by_cases ht : t∈Icc (0 : ℝ) δ <;> simp [expWeight,compactKernel,ht]
  rw [he,integral_indicator measurableSet_Icc,integral_Icc_eq_integral_Ioc,
    ← intervalIntegral.integral_of_le hδ]
  rfl

-- @paper-step thm:n_construction/compact_kernel_mass
theorem compactKernel_mass (J : ℝ → ℝ) {δ : ℝ} (hδ : 0≤δ) :
    (∫ t, compactKernel J δ t)=compactMoment J δ 0 := by
  simpa [expWeight,compactExpMoment,compactMoment] using compactKernel_moment J hδ 0

-- @paper-step thm:n_construction/compact_kernel_actual_transform
theorem compactKernel_laplace (J : ℝ → ℝ) {δ : ℝ} (hδ : 0≤δ) (p : ℝ) :
    laplace (compactKernel J δ) p=compactExpMoment J δ (-p) := by
  rw [← kernel_laplace_full (compactKernel_causal J δ) p,compactKernel_moment J hδ]

-- @paper-step thm:n_construction/base_exponential_weighted_integrability
theorem expKernel_weighted {l η : ℝ} (h : η<l) : Integrable (expWeight η (expKernel l)) := by
  simpa [expKernel] using weighted_exp_pair_integrable 1 0 0 h h

-- @paper-step thm:n_construction/base_exponential_integrability
theorem expKernel_integrable {l : ℝ} (hl : 0<l) : Integrable (expKernel l) := by
  simpa only [expWeight_zero] using expKernel_weighted hl

-- @paper-step thm:n_construction/base_exponential_mass
theorem expKernel_mass {l : ℝ} (hl : 0<l) : (∫ t, expKernel l t)=1/l := by
  simpa [expKernel] using causal_exp_pair_integral 1 0 0 hl hl

-- @paper-step thm:n_construction/base_exponential_actual_transform
theorem expKernel_laplace {l p : ℝ} (hl : 0<l) (hp : 0≤p) :
    laplace (expKernel l) p=1/(p+l) := by
  have he : twoRateG 1 l l=(fun t => Real.exp (-l*t)) := by
    funext t; simp [twoRateG]
  simpa [expKernel,he] using twoRateG_laplace 1 hl hl hp

-- @paper-step thm:n_construction/base_exponential_positive
theorem expKernel_nonneg (l t : ℝ) : 0≤expKernel l t := by
  by_cases ht : 0≤t <;> simp [expKernel,causalize,ht,Real.exp_nonneg]

-- @paper-step thm:n_construction/exponential_convolution_integrating_factor
theorem expKernel_convolution_formula (l : ℝ) {f : ℝ → ℝ} (hf : Causal f)
    {t : ℝ} (ht : 0≤t) :
    (expKernel l ⋆ f) t=Real.exp (-l*t)*(∫ s in 0..t, Real.exp (l*s)*f s) := by
  have hEc : Causal (expKernel l) := causalize_causal _
  rw [causal_convolution_interval hEc hf ht,
    ← intervalIntegral.integral_const_mul]
  apply intervalIntegral.integral_congr
  intro s hs
  rw [uIcc_of_le ht] at hs
  simp only [expKernel,causalize,indicator_of_mem (show t-s∈Ici (0 : ℝ) from sub_nonneg.mpr hs.2)]
  rw [← mul_assoc,← Real.exp_add]
  congr 2
  ring

-- @paper-step thm:n_construction/exponential_convolution_compact_majorant
theorem expKernel_compact_bound {J : ℝ → ℝ} (hc : Continuous J) {δ : ℝ} (hδ : 0≤δ)
    (hn : ∀ s∈Icc (0 : ℝ) δ, 0≤J s) (l : ℝ) {t : ℝ} (ht : 0≤t) :
    (expKernel l ⋆ compactKernel J δ) t≤Real.exp (-l*t)*compactExpMoment J δ l := by
  rw [expKernel_convolution_formula l (compactKernel_causal J δ) ht]
  apply mul_le_mul_of_nonneg_left _ (Real.exp_nonneg _)
  rw [intervalIntegral.integral_of_le ht,← compactKernel_moment J hδ l]
  exact setIntegral_le_integral (compactKernel_weighted hc δ l)
    (ae_of_all _ (fun s => mul_nonneg (Real.exp_nonneg _) (compactKernel_nonneg hn s)))

noncomputable def oddCascadeKernel (J : ℝ → ℝ) (δ a c l : ℝ) (t : ℝ) : ℝ :=
  (l-c/a)*expKernel l t-(1/a)*(expKernel l ⋆ compactKernel J δ) t
noncomputable def evenCascadeKernel (J : ℝ → ℝ) (δ a c : ℝ) (t : ℝ) : ℝ :=
  (1/a)*(expKernel (c/a) ⋆ compactKernel J δ) t

-- @paper-step thm:n_construction/odd_parity_actual_kernel_positive
theorem oddCascadeKernel_nonneg {J : ℝ → ℝ} (hc : Continuous J) {δ a c l : ℝ}
    (hδ : 0≤δ) (ha : 0<a) (hn : ∀ s∈Icc (0 : ℝ) δ, 0≤J s)
    (h : c+compactExpMoment J δ l≤a*l) (t : ℝ) : 0≤oddCascadeKernel J δ a c l t := by
  by_cases ht : 0≤t
  · have hb := expKernel_compact_bound hc hδ hn l ht
    have hcoef : 0≤l-c/a-compactExpMoment J δ l/a := by
      have hh := (div_le_iff₀ ha).mpr (show c+compactExpMoment J δ l≤l*a by nlinarith)
      rw [add_div] at hh
      linarith
    have hdiv := mul_le_mul_of_nonneg_left hb (show 0≤1/a by positivity)
    have hh := mul_nonneg hcoef (Real.exp_nonneg (-l*t))
    have het : expKernel l t=Real.exp (-l*t) := by simp [expKernel,causalize,ht]
    rw [oddCascadeKernel,het]
    simp only [div_eq_mul_inv] at *
    nlinarith
  · have hz := convolution_causal (show Causal (expKernel l) from causalize_causal _) (compactKernel_causal J δ) t (lt_of_not_ge ht)
    rw [oddCascadeKernel,hz]
    simp [expKernel,causalize,ht]

-- @paper-step thm:n_construction/parity_kernels_causal
theorem cascadeKernels_causal (J : ℝ → ℝ) (δ a c l : ℝ) :
    Causal (oddCascadeKernel J δ a c l) ∧ Causal (evenCascadeKernel J δ a c) := by
  have hE (r : ℝ) : Causal (expKernel r) := causalize_causal _
  constructor
  · have h := causal_linear (hE l)
      (ae_of_all _ (convolution_causal (hE l) (compactKernel_causal J δ)))
      (l-c/a) (-(1/a))
    change Causal (fun t => (l-c/a)*expKernel l t-(1/a)*(expKernel l ⋆ compactKernel J δ) t)
    simpa only [neg_mul,← sub_eq_add_neg] using h
  · apply ae_of_all; intro t ht
    simp [evenCascadeKernel,convolution_causal (hE (c/a)) (compactKernel_causal J δ) t ht]

-- @paper-step thm:n_construction/odd_parity_exponential_integrability
theorem oddCascadeKernel_weighted {J : ℝ → ℝ} (hc : Continuous J) (δ a c : ℝ)
    {l η : ℝ} (h : η<l) : Integrable (expWeight η (oddCascadeKernel J δ a c l)) := by
  have he : expWeight η (oddCascadeKernel J δ a c l)=
      (fun t => (l-c/a)*expWeight η (expKernel l) t-
        (1/a)*((expWeight η (expKernel l)) ⋆ (expWeight η (compactKernel J δ))) t) := by
    rw [← expWeight_convolution]
    funext t; dsimp [oddCascadeKernel,expWeight]; ring
  rw [he]
  exact ((expKernel_weighted h).const_mul _).sub
    (((expKernel_weighted h).integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ)
      (compactKernel_weighted hc δ η)).const_mul _)

-- @paper-step thm:n_construction/even_parity_positive_kernel
theorem evenCascadeKernel_nonneg {J : ℝ → ℝ} {δ a : ℝ} (ha : 0<a)
    (hn : ∀ s∈Icc (0 : ℝ) δ, 0≤J s) (c t : ℝ) : 0≤evenCascadeKernel J δ a c t :=
  mul_nonneg (by positivity) (convolution_pointwise_nonneg
    (ae_of_all _ (expKernel_nonneg _)) (ae_of_all _ (compactKernel_nonneg hn)) t)

-- @paper-step thm:n_construction/even_parity_exponential_integrability
theorem evenCascadeKernel_weighted {J : ℝ → ℝ} (hc : Continuous J) (δ a c : ℝ)
    {η : ℝ} (h : η<c/a) : Integrable (expWeight η (evenCascadeKernel J δ a c)) := by
  have he : expWeight η (evenCascadeKernel J δ a c)=
      (fun t => (1/a)*((expWeight η (expKernel (c/a))) ⋆
        (expWeight η (compactKernel J δ))) t) := by
    rw [← expWeight_convolution]
    funext t; dsimp [evenCascadeKernel,expWeight]; ring
  rw [he]
  exact (((expKernel_weighted h).integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ)
    (compactKernel_weighted hc δ η)).const_mul _)

-- @paper-step thm:n_construction/odd_parity_kernel_mass
theorem oddCascadeKernel_mass {J : ℝ → ℝ} (hc : Continuous J) {δ a l : ℝ}
    (hδ : 0≤δ) (ha : 0<a) (hl : 0<l) :
    (∫ t, oddCascadeKernel J δ a (1-compactMoment J δ 0) l t)=1-1/(a*l) := by
  have hE := expKernel_integrable hl
  have hJ := compactKernel_integrable hc δ
  unfold oddCascadeKernel
  rw [integral_sub (hE.const_mul _) ((hE.integrable_convolution
    (ContinuousLinearMap.lsmul ℝ ℝ) hJ).const_mul _),integral_const_mul,integral_const_mul,
    integral_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hE hJ,
    expKernel_mass hl,compactKernel_mass J hδ]
  change (l-(1-compactMoment J δ 0)/a)*(1/l)-(1/a)*((1/l)*compactMoment J δ 0)=_
  field_simp
  <;> ring

-- @paper-step thm:n_construction/even_parity_kernel_mass
theorem evenCascadeKernel_mass {J : ℝ → ℝ} (hc : Continuous J) {δ a c : ℝ}
    (hδ : 0≤δ) (ha : 0<a) (hc0 : 0<c) :
    (∫ t, evenCascadeKernel J δ a c t)=compactMoment J δ 0/c := by
  have hE := expKernel_integrable (div_pos hc0 ha)
  have hJ := compactKernel_integrable hc δ
  unfold evenCascadeKernel
  rw [integral_const_mul,integral_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hE hJ,
    expKernel_mass (div_pos hc0 ha),compactKernel_mass J hδ]
  change (1/a)*((1/(c/a))*compactMoment J δ 0)=_
  field_simp

end MIACE
