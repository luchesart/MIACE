import MIACE.Theorem17Resolvent
import MIACE.CascadeTransfer

/-! Identification with the ordinary plant states. Positivity of a formal
transfer is not assumed to identify an output: Laplace uniqueness supplies
the first lag identity, and the remaining states are actual lag solutions. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:n_construction/actual_command_transform
theorem cascadeCommand_laplace {J : ℝ → ℝ} (hc : Continuous J) {δ : ℝ} (hδ : 0≤δ)
    (a ε : ℝ) {R : ℝ → ℝ} (hi : Integrable (causalize R)) {p : ℝ} (hp : 0≤p) :
    laplace (cascadeCommand J δ a ε R) p=
      (1-a+ε*compactExpMoment (compactTail J δ) δ (-p))*laplace R p := by
  have hK := compactKernel_integrable (compactTail_continuous hc δ) δ
  have hconv := hK.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hi
  have hRhalf : Integrable R halfLine := by
    apply (hi.mono_measure Measure.restrict_le_self).congr
    exact representative_halfLine_ae (EventuallyEq.rfl (f := causalize R))
  unfold cascadeCommand laplace
  simp_rw [mul_add,mul_left_comm (Real.exp (-p*_)) ε,
    mul_left_comm (Real.exp (-p*_)) (1-a)]
  rw [integral_add ((laplace_integrable hRhalf hp).const_mul (1-a))
    ((laplace_integrable (hconv.mono_measure Measure.restrict_le_self) hp).const_mul ε)]
  rw [integral_const_mul,integral_const_mul]
  change (1-a)*laplace R p+ε*laplace
    (compactKernel (compactTail J δ) δ ⋆ causalize R) p=_
  rw [causal_convolution_laplace hK hi (compactKernel_causal _ δ) (causalize_causal R) hp,
    compactKernel_laplace _ hδ,laplace_congr_halfLine
      (representative_halfLine_ae (EventuallyEq.rfl (f := causalize R)))]
  dsimp only [laplace]
  ring

-- @paper-step thm:n_construction/resolvent_command_first_lag_identity
theorem cascadeCommand_resolvent_identity {J : ℝ → ℝ} (hc : Continuous J)
    {δ a ε : ℝ} (hδ : 0≤δ) {R : ℝ → ℝ} (hi : Integrable (causalize R))
    (hT : ∀ p : ℝ, 0≤p →
      (a*p+1-ε*compactMoment J δ 0+ε*compactExpMoment J δ (-p))*laplace R p=1)
    {p : ℝ} (hp : 0≤p) :
    (1+p)*laplace R p=1+p*laplace (cascadeCommand J δ a ε R) p := by
  rw [cascadeCommand_laplace hc hδ a ε hi hp]
  have htail := compactTail_exp_identity hc δ (-p)
  have ht := hT p hp
  linear_combination ht + ε*laplace R p*htail

-- @paper-step thm:n_construction/first_ordinary_lag_is_resolvent_primitive
theorem resolvent_first_lag {R v : ℝ → ℝ} (hR : Continuous R)
    (hi : Integrable (causalize R)) (hv : Integrable v)
    (hT : ∀ p : ℝ, 0<p → (1+p)*laplace R p=1+p*laplace v p) :
    ∀ t, 0≤t → lag 1 (fun s => 1+v s) t=∫ s in 0..t, R s := by
  have hu : LocallyIntegrable (fun t => 1+v t) volume :=
    (continuous_const : Continuous (fun _ : ℝ => (1 : ℝ))).locallyIntegrable.add hv.locallyIntegrable
  have hdef : Integrable (fun t => 1-(1+v t)) halfLine := by
    convert (hv.mono_measure Measure.restrict_le_self).neg using 1
    ext t; simp
  have hE := lag_deficit_integrable hu hdef (by norm_num : (0 : ℝ)<1)
  let F := integratedState 1 (fun t => -causalize R t)
  have hF := integratedState_regular 1 hi.neg
  have hFi := integratedState_laplace 1
    (hi.neg.mono_measure Measure.restrict_le_self) (by norm_num : (0 : ℝ)<1)
  have hsame : ∀ t, 0≤t → 1-lag 1 (fun s => 1+v s) t=F t := by
    apply laplace_injective_weighted (laplace_integrable hE (by norm_num : (0 : ℝ)≤1))
      hFi.1 (continuous_const.sub (ordinary_lag_regular hu 1).1) hF.1
    intro p hp
    have hp0 : 0<p := by linarith
    rw [lag_deficit_transform hu hdef (by norm_num : (0 : ℝ)<1) hp0.le,
      (integratedState_laplace 1 (hi.neg.mono_measure Measure.restrict_le_self) hp0).2]
    have he : (fun t => 1-(1+v t))=(fun t => (-1)*v t) := by ext t; ring
    have he' : (-causalize R)=(fun t => (-1)*causalize R t) := by ext t; simp
    rw [he,he',laplace_smul,laplace_smul,laplace_congr_halfLine
      (representative_halfLine_ae (EventuallyEq.rfl (f := causalize R)))]
    have ht := hT p hp0
    field_simp [ne_of_gt hp0,show 1+p≠0 by linarith]
    nlinarith [ht]
  intro t ht
  have hh := hsame t ht
  have he : (∫ s in 0..t, causalize R s)=(∫ s in 0..t, R s) := by
    apply intervalIntegral.integral_congr
    intro s hs
    have hs' : 0≤s := (uIcc_of_le ht ▸ hs).1
    simp [causalize,hs']
  dsimp only [F,integratedState] at hh
  rw [intervalIntegral.integral_neg,he] at hh
  linarith

-- @paper-step thm:n_construction/positive_unit_mass_primitive_bounds
theorem resolvent_primitive_bounds {R : ℝ → ℝ} (hc : Continuous R)
    (hi : Integrable R halfLine) (hn : ∀ t, 0≤t → 0≤R t)
    (hm : (∫ t, R t ∂halfLine)=1) :
    MonotoneOn (fun t => ∫ s in 0..t, R s) (Ici 0) ∧
      ∀ t, 0≤t → 0≤(∫ s in 0..t, R s) ∧ (∫ s in 0..t, R s)≤1 := by
  have hna : ∀ᵐ t ∂halfLine, 0≤R t := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact hn t (show 0<t from ht).le
  constructor
  · intro a ha b hb hab
    change (∫ s in 0..a, R s)≤(∫ s in 0..b, R s)
    rw [intervalIntegral.integral_of_le ha,intervalIntegral.integral_of_le hb]
    exact setIntegral_mono_set (IntegrableOn.mono_set hi (fun _ hs => hs.1))
      (hna.filter_mono (ae_mono (Measure.restrict_mono (fun _ hs => hs.1) le_rfl)))
      (Eventually.of_forall (fun _ hs => ⟨hs.1,hs.2.trans hab⟩))
  · intro t ht
    constructor
    · exact intervalIntegral.integral_nonneg ht (fun s hs => hn s hs.1)
    · rw [← hm,intervalIntegral.integral_of_le ht]
      exact setIntegral_mono_set hi hna (Eventually.of_forall (fun _ hs => hs.1))

-- @paper-step thm:n_construction/ordinary_plant_output_monotonicity_and_area
theorem resolvent_cascade_output (N : ℕ) (σ : ℕ → ℝ) {δ : ℝ} (hδ : 0≤δ)
    (hσ : ∀ j≤N, 0<σ j) (hfirst : σ 0=1) {R v : ℝ → ℝ}
    (hR : Continuous R) (hi : Integrable (causalize R))
    (hRn : ∀ t, 0≤t → 0≤R t) (hRm : (∫ t, R t ∂halfLine)=1)
    (hv : Integrable v) (hvn : ∀ t, 0≤t → 0≤v t)
    (hT : ∀ p : ℝ, 0<p → (1+p)*laplace R p=1+p*laplace v p) :
    let E := delayedError δ (fun t => 1-ordinaryCascade σ (fun s => 1+v s) (N+1) t)
    TransferResponse E v (cascadeTransfer σ (N+1)) δ ∧
      (∀ t, 0≤t → 0≤E t) ∧ Monotone (fun t => 1-E t) ∧
      1-E 0=0 ∧ Tendsto (fun t => 1-E t) atTop (𝓝 1) ∧
      absArea E halfLine=cascadeMean σ (N+1)+δ-absArea v halfLine := by
  dsimp only
  let u := fun t => 1+v t
  let X := ordinaryCascade σ u
  let E := delayedError δ (fun t => 1-X (N+1) t)
  have hu : LocallyIntegrable u volume :=
    (continuous_const : Continuous (fun _ : ℝ => (1 : ℝ))).locallyIntegrable.add hv.locallyIntegrable
  have hRi : Integrable R halfLine := by
    apply (hi.mono_measure Measure.restrict_le_self).congr
    exact representative_halfLine_ae (EventuallyEq.rfl (f := causalize R))
  have hp := resolvent_primitive_bounds hR hRi hRn hRm
  have h₁ : ∀ t, 0≤t → X 1 t=∫ s in 0..t, R s := by
    intro t ht
    change lag (σ 0) u t=_
    rw [hfirst]
    exact resolvent_first_lag hR hi hv hT t ht
  have hm : MonotoneOn (X 1) (Ici 0) := by
    intro a ha b hb hab
    rw [h₁ a ha,h₁ b hb]
    exact hp.1 ha hb hab
  have hb : ∀ t, 0≤t → 0≤X 1 t ∧ X 1 t≤1 := by
    intro t ht; rw [h₁ t ht]; exact hp.2 t ht
  have hstates := cascade_preserves_monotone N (fun j => σ (j+1)) (fun j => X (j+1))
    (fun j hj => hσ (j+1) (by omega))
    (fun j _ => (ordinary_lag_regular (ordinaryCascade_local hu σ j) (σ j)).1.continuousOn)
    (fun _ _ => rfl) hm hb N le_rfl
  have hP := ordinaryCascade_transfer_response hv σ (N+1) (fun j hj => hσ j (by omega)) hδ
  have hy := cascade_delayed_monotone hstates.1 (fun t ht => (hstates.2 t ht).1) (δ := δ)
  have hEn : ∀ t, 0≤t → 0≤E t := by
    intro t ht
    by_cases htd : t≤δ
    · simp [E,delayedError,htd]
    · change 0≤delayedError δ (fun t => 1-X (N+1) t) t
      simp only [delayedError,if_neg htd]
      linarith [(hstates.2 (t-δ) (by linarith)).2]
  have hlim := monotone_error_settles hP.error_integrable hEn
    (fun a _ b _ hab => by have hh := hy hab; dsimp only at hh; linarith)
  refine ⟨hP,hEn,hy,by simp [delayedError,hδ],?_,?_⟩
  · simpa using tendsto_const_nhds.sub hlim
  · have hAe : absArea E halfLine=∫ t, E t ∂halfLine := by
      apply integral_congr_ae
      filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
      exact abs_of_nonneg (hEn t (show 0<t from ht).le)
    have hAv : absArea v halfLine=∫ t, v t ∂halfLine := by
      apply integral_congr_ae
      filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
      exact abs_of_nonneg (hvn t (show 0<t from ht).le)
    change absArea E halfLine=cascadeMean σ (N+1)+δ-absArea v halfLine
    rw [hAe,hAv]
    have hh := transfer_signed_balance hP (cascadeMean σ (N+1))
      (cascadeTransfer_derivative σ (N+1)) (cascadeTransfer_zero σ (N+1))
    linarith

end MIACE
