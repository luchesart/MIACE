import MIACE.DelayedPIEvolution
import MIACE.ScalarDelayGain

namespace MIACE
open MeasureTheory Set Filter
open scoped Topology

noncomputable def normalizedPICommand (x : ℝ) (y z : ℝ → ℝ) (t : ℝ) : ℝ :=
  x*(z (t/x)-y (t/x))
noncomputable def normalizedPIOutput (x : ℝ) (y : ℝ → ℝ) (t : ℝ) : ℝ := y (t/x)

-- @paper-step lem:delayed_cancellation/full_pi_normalized_state_equations
theorem delayedPI_normalized {x δ : ℝ} (hx : 0<x) {y z : ℝ → ℝ}
    (he : DelayedPIEvolution x δ y z) :
    Continuous (normalizedPICommand x y z) ∧ Continuous (normalizedPIOutput x y) ∧
    (∀ t, 0<t → HasDerivAt (normalizedPICommand x y z)
      (-normalizedPICommand x y z (t-x*δ)) t) ∧
    (∀ t, 0<t → HasDerivAt (normalizedPIOutput x y)
      ((1/x)*(normalizedPICommand x y z (t-x*δ)-normalizedPIOutput x y t)) t) := by
  obtain ⟨hw,hwd⟩ := scalarDelay_normalize hx
    ((he.integrator_continuous.sub he.output_continuous).const_mul x) (delayedPI_command_deriv he)
  refine ⟨hw,he.output_continuous.comp (continuous_id.div_const x),hwd,?_⟩
  intro t ht
  have hd := (he.output_ode (t/x) (div_pos ht hx)).comp t ((hasDerivAt_id t).div_const x)
  have harg : (t-x*δ)/x=t/x-δ := by field_simp
  change HasDerivAt (fun s => y (s/x)) ((-y (t/x)+x*(z (t/x-δ)-y (t/x-δ)))*(1/x)) t at hd
  convert hd using 1
  · rfl
  · dsimp [normalizedPICommand,normalizedPIOutput]; rw [harg]; ring

-- @paper-step lem:delayed_cancellation/all_full_pi_states_decay_below_exact_threshold
theorem delayedPI_states_tendsto_zero {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    (hb : x*δ<Real.pi/2) {y z : ℝ → ℝ} (he : DelayedPIEvolution x δ y z) :
    Tendsto y atTop (𝓝 0) ∧ Tendsto z atTop (𝓝 0) := by
  obtain ⟨hw,hy,hwd,hyd⟩ := delayedPI_normalized hx he
  have h0 := mul_nonneg hx.le hδ
  let w := normalizedPICommand x y z
  let Y := normalizedPIOutput x y
  have hwlim := scalarDelay_history_decay h0 hb hw hwd
  have hylim := (stableLag_energy_decay (one_div_pos.mpr hx) hy
    (hw.comp (continuous_id.sub continuous_const)) hyd
    (fun T hT => scalarDelay_shifted_energy_bound h0 hb hw hwd hT)).2
  have htime : Tendsto (fun t : ℝ => x*t) atTop atTop := tendsto_id.const_mul_atTop hx
  have hyl : Tendsto y atTop (𝓝 0) := by
    simpa [normalizedPIOutput,Function.comp_def,ne_of_gt hx] using hylim.comp htime
  have hwl : Tendsto (fun t => x*(z t-y t)) atTop (𝓝 0) := by
    simpa [normalizedPICommand,Function.comp_def,ne_of_gt hx] using hwlim.comp htime
  have hzl := hyl.add (hwl.div_const x)
  have heq : (fun t => y t+(x*(z t-y t))/x)=z := by
    funext t; field_simp; ring
  rw [heq] at hzl
  exact ⟨hyl,by simpa using hzl⟩

-- @paper-step lem:delayed_cancellation/entire_transport_history_uniformly_tends_to_zero
theorem delayedPI_transport_attraction {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    (hb : x*δ<Real.pi/2) {y z : ℝ → ℝ} (he : DelayedPIEvolution x δ y z) :
    ∀ ε : ℝ, 0<ε → ∃ T : ℝ, ∀ t, T≤t → ∀ s∈Icc (-δ) 0,
      |y (t+s)|<ε ∧ |z (t+s)|<ε := by
  intro ε hε
  obtain ⟨hy,hz⟩ := delayedPI_states_tendsto_zero hx hδ hb he
  have hya : Tendsto (fun t => |y t|) atTop (𝓝 0) := by simpa using hy.abs
  have hza : Tendsto (fun t => |z t|) atTop (𝓝 0) := by simpa using hz.abs
  obtain ⟨T,hT⟩ := eventually_atTop.mp
    (((tendsto_order.mp hya).2 ε hε).and ((tendsto_order.mp hza).2 ε hε))
  refine ⟨T+δ,?_⟩
  intro t ht s hs
  exact hT (t+s) (by linarith [hs.1])

noncomputable def delayedPIHistoryGain (x δ : ℝ) : ℝ :=
  3*(1+4*x*(x*δ+scalarDelayHistoryGain (x*δ)))+
    8*(1+x*δ+2*scalarDelayHistoryGain (x*δ))

-- @paper-step lem:delayed_cancellation/full_pi_uniform_gain_positive
theorem delayedPIHistoryGain_pos {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    (hb : x*δ<Real.pi/2) : 0<delayedPIHistoryGain x δ := by
  have hK := scalarDelayHistoryGain_nonneg (mul_nonneg hx.le hδ) hb
  unfold delayedPIHistoryGain
  positivity

-- @paper-step lem:delayed_cancellation/full_pi_uniform_stability_in_history_sup_norm
theorem delayedPI_uniform_history_bound {x δ M : ℝ} (hx : 0<x) (hδ : 0≤δ)
    (hb : x*δ<Real.pi/2) (hM : 0≤M) {y z : ℝ → ℝ}
    (he : DelayedPIEvolution x δ y z)
    (hhist : ∀ t∈Icc (-δ) 0, |y t|≤M ∧ |z t|≤M)
    {t : ℝ} (ht : 0≤t) : (y t)^2+(z t)^2≤delayedPIHistoryGain x δ*M^2 := by
  obtain ⟨hw,hy,hwd,hyd⟩ := delayedPI_normalized hx he
  let h := x*δ
  let K := scalarDelayHistoryGain h
  let w := normalizedPICommand x y z
  let Y := normalizedPIOutput x y
  have h0 : 0≤h := mul_nonneg hx.le hδ
  have hhistW : ∀ s∈Icc (-h) 0, |w s|≤2*x*M := by
    intro s hs
    have hs' : s/x∈Icc (-δ) 0 := ⟨(le_div_iff₀ hx).mpr (by dsimp [h] at hs; nlinarith [hs.1]),
      div_nonpos_of_nonpos_of_nonneg hs.2 hx.le⟩
    obtain ⟨hys,hzs⟩ := hhist (s/x) hs'
    dsimp [w,normalizedPICommand]
    rw [abs_mul,abs_of_pos hx]
    have ha := abs_sub (z (s/x)) (y (s/x))
    nlinarith
  have hM' : 0≤2*x*M := by positivity
  have hV : scalarDelayLyapunov h w 0≤K*(2*x*M)^2 :=
    scalarDelayLyapunov_initial_bound h0 hb hM' hw hhistW
  have hH : (∫ s in -h..(0 : ℝ), (w s)^2)≤h*(2*x*M)^2 :=
    history_square_bound h0 hM' hw hhistW
  have hw0 : (w 0)^2≤(2*x*M)^2 := by
    have ha := hhistW 0 ⟨by linarith,le_rfl⟩
    have hh := mul_nonneg (sub_nonneg.mpr ha) (add_nonneg (abs_nonneg (w 0)) hM')
    nlinarith [sq_abs (w 0)]
  have hy0 : (Y 0)^2≤M^2 := by
    have ha := (hhist 0 ⟨by linarith,le_rfl⟩).1
    have hh := mul_nonneg (sub_nonneg.mpr ha) (add_nonneg (abs_nonneg (y 0)) hM)
    dsimp [Y,normalizedPIOutput]; simp only [zero_div]
    nlinarith [sq_abs (y 0)]
  have hwt : (w (x*t))^2≤(1+h+2*K)*(2*x*M)^2 := by
    have hh := scalarDelay_pointwise_energy_bound h0 hb hw hwd (mul_nonneg hx.le ht)
    change (w (x*t))^2≤(w 0)^2+(∫ s in -h..(0 : ℝ), (w s)^2)+2*scalarDelayLyapunov h w 0 at hh
    nlinarith
  have hyt : (Y (x*t))^2≤(1+4*x*(h+K))*M^2 := by
    have hh := (stableLag_energy_decay (one_div_pos.mpr hx) hy
      (hw.comp (continuous_id.sub continuous_const)) hyd
      (fun T hT => scalarDelay_shifted_energy_bound h0 hb hw hwd hT)).1 (x*t) (mul_nonneg hx.le ht)
    change (Y (x*t))^2≤(Y 0)^2+(1/x)*((∫ s in -h..(0 : ℝ), (w s)^2)+scalarDelayLyapunov h w 0) at hh
    have hmul := mul_le_mul_of_nonneg_left (add_le_add hH hV) (one_div_pos.mpr hx).le
    have halg : M^2+(1/x)*(h*(2*x*M)^2+K*(2*x*M)^2)=(1+4*x*(h+K))*M^2 := by field_simp; ring
    linarith
  have hws : (w (x*t)/x)^2≤4*(1+h+2*K)*M^2 := by
    rw [div_pow]
    calc
      _ ≤ ((1+h+2*K)*(2*x*M)^2)/x^2 := div_le_div_of_nonneg_right hwt (sq_nonneg x)
      _ = _ := by field_simp; ring
  have hyid : Y (x*t)=y t := by simp [Y,normalizedPIOutput,ne_of_gt hx]
  have hzid : z t=y t+w (x*t)/x := by
    dsimp [w,normalizedPICommand]; simp only [mul_div_cancel_left₀ _ (ne_of_gt hx)]
    ring
  rw [hyid] at hyt
  have hzs : (z t)^2≤2*(y t)^2+2*(w (x*t)/x)^2 := by
    rw [hzid]; nlinarith [sq_nonneg (y t-w (x*t)/x)]
  change (y t)^2+(z t)^2≤(3*(1+4*x*(h+K))+8*(1+h+2*K))*M^2
  nlinarith

end MIACE
