import MIACE.DelayedPIUniqueness
import MIACE.ScalarDelayThreshold

namespace MIACE
open MeasureTheory Set Filter
open scoped Topology

-- @paper-step lem:delayed_cancellation/full_pi_attraction_forces_actual_scalar_attraction
theorem delayedPI_attraction_scalar {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    (ha : ∀ y z, DelayedPIEvolution x δ y z →
      Tendsto y atTop (𝓝 0) ∧ Tendsto z atTop (𝓝 0))
    {w : ℝ → ℝ} (hw : Continuous w)
    (hd : ∀ t, 0<t → HasDerivAt w (-x*w (t-δ)) t) : Tendsto w atTop (𝓝 0) := by
  obtain ⟨y,z,he,hy,hz⟩ := delayedPI_history_exists hx hδ continuous_const (hw.div_const x)
    (φ := fun _ => 0)
  have heq := scalarDelay_physical_unique hx hδ
    ((he.integrator_continuous.sub he.output_continuous).const_mul x) hw
    (fun t ht => by change x*(z t-y t)=w t; rw [hy t ht,hz t ht]; field_simp; ring)
    (delayedPI_command_deriv he) hd
  obtain ⟨hyl,hzl⟩ := ha y z he
  have hh := (hzl.sub hyl).const_mul x
  change (fun t => x*(z t-y t))=w at heq
  rw [heq] at hh
  simpa using hh

-- @paper-step lem:delayed_cancellation/complex_characteristic_root_gives_classical_time_mode
theorem scalarDelay_complex_mode_deriv {x δ : ℝ} {p : ℂ}
    (hp : p+(x : ℂ)*Complex.exp (-(δ : ℂ)*p)=0) (t : ℝ) :
    HasDerivAt (fun s : ℝ => Complex.exp (p*(s : ℂ)))
      (-(x : ℂ)*Complex.exp (p*((t-δ : ℝ) : ℂ))) t := by
  have hd := (((hasDerivAt_id t).ofReal_comp).const_mul p).cexp
  have he : Complex.exp (p*((t-δ : ℝ) : ℂ))=
      Complex.exp (-(δ : ℂ)*p)*Complex.exp (p*(t : ℂ)) := by
    rw [← Complex.exp_add]
    congr 1
    push_cast
    ring
  convert hd using 1
  · rfl
  · simp only [id_eq,Complex.ofReal_one,mul_one,he]
    linear_combination -Complex.exp (p*(t : ℂ))*hp

-- @paper-step lem:delayed_cancellation/unstable_modes_obstruct_all_history_attraction
theorem delayedPI_attraction_necessary {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    (ha : ∀ y z, DelayedPIEvolution x δ y z →
      Tendsto y atTop (𝓝 0) ∧ Tendsto z atTop (𝓝 0)) : x*δ<Real.pi/2 := by
  apply (delayed_PI_spectral_iff hx hδ).mp
  intro p hp
  by_contra hn
  have hre : 0≤p.re := le_of_not_gt hn
  have hroot : p+(x : ℂ)*Complex.exp (-(δ : ℂ)*p)=0 := by
    rcases mul_eq_zero.mp hp with hp|hp
    · have he : p= -1 := by linear_combination hp
      norm_num [he] at hre
    · exact hp
  let E := fun t : ℝ => Complex.exp (p*(t : ℂ))
  have hc : Continuous E := by dsimp [E]; fun_prop
  have hR : Tendsto (fun t => (E t).re) atTop (𝓝 0) := by
    apply delayedPI_attraction_scalar hx hδ ha (Complex.continuous_re.comp hc)
    intro t _
    have hd := Complex.reCLM.hasFDerivAt.comp_hasDerivAt t (scalarDelay_complex_mode_deriv hroot t)
    simpa [E,Function.comp_def,Complex.mul_re] using hd
  have hI : Tendsto (fun t => (E t).im) atTop (𝓝 0) := by
    apply delayedPI_attraction_scalar hx hδ ha (Complex.continuous_im.comp hc)
    intro t _
    have hd := Complex.imCLM.hasFDerivAt.comp_hasDerivAt t (scalarDelay_complex_mode_deriv hroot t)
    simpa [E,Function.comp_def,Complex.mul_im] using hd
  have hE : Tendsto E atTop (𝓝 0) := by
    have hh := ((Complex.continuous_ofReal.tendsto 0).comp hR).add
      (((Complex.continuous_ofReal.tendsto 0).comp hI).mul_const Complex.I)
    simpa only [Function.comp_def,Complex.re_add_im,Complex.ofReal_zero,zero_mul,zero_add] using hh
  have hb : ∀ᶠ t : ℝ in atTop, 1≤‖E t‖ := by
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with t ht
    dsimp [E]
    rw [Complex.norm_exp]
    apply Real.one_le_exp_iff.mpr
    simpa using mul_nonneg hre ht
  have hbad : (1 : ℝ)≤0 := by simpa using ge_of_tendsto hE.norm hb
  norm_num at hbad

end MIACE
