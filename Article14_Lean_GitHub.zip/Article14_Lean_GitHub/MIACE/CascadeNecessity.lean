import MIACE.CascadeShape
import MIACE.FirstOrderCone

/-! Stage 13. Necessity is proved directly from ordinary cascade ODEs.
The exponential comparison includes repeated slowest poles (σ = 1).
This replaces the paper's partial-fraction tail asymptotics; no tail estimate
or intermediate-state sign is taken as an extra premise. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:n_necessary/exponential_comparison_integral
theorem exp_mul_interval (r a b : ℝ) (hr : r ≠ 0) :
    (∫ s in a..b, Real.exp (r*s)) = (Real.exp (r*b)-Real.exp (r*a))/r := by
  rw [intervalIntegral.integral_comp_mul_left _ hr, integral_exp]
  simp [smul_eq_mul,div_eq_mul_inv,mul_comm]

-- The integrating-factor lower bound forces an eventually positive state,
-- including the repeated-pole case r = 0.
-- @paper-step thm:n_necessary/positive_forcing_eventual_lower_bound
theorem exponential_comparison_eventual {q : ℝ → ℝ} {r m a : ℝ}
    (hr : 0 ≤ r) (hm : 0 < m)
    (hb : ∀ t, a ≤ t →
      Real.exp (r*a)*q a+m*(∫ s in a..t, Real.exp (r*s)) ≤ Real.exp (r*t)*q t) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ t in atTop, c ≤ q t := by
  rcases hr.eq_or_lt with hr | hr
  · subst r
    have hl : Tendsto (fun t : ℝ => q a+m*(t-a)) atTop atTop :=
      by
        apply tendsto_atTop_add_const_left
        apply Tendsto.const_mul_atTop hm
        simpa [sub_eq_add_neg] using tendsto_atTop_add_const_right atTop (-a) tendsto_id
    refine ⟨1,by norm_num,?_⟩
    filter_upwards [(tendsto_atTop.1 hl) 1,eventually_ge_atTop a] with t ht ha
    have hh := hb t ha
    simp only [zero_mul,Real.exp_zero,one_mul,intervalIntegral.integral_const,
      smul_eq_mul,mul_one] at hh
    exact ht.trans hh
  · let B := Real.exp (r*a)*q a-m*Real.exp (r*a)/r
    have hl : Tendsto (fun t : ℝ => m/r+Real.exp (-(r*t))*B) atTop (𝓝 (m/r)) := by
      have he := Real.tendsto_exp_neg_atTop_nhds_zero.comp (tendsto_id.const_mul_atTop hr)
      simpa using tendsto_const_nhds.add (he.mul_const B)
    have hp : 0 < m/r := div_pos hm hr
    refine ⟨(m/r)/2,by positivity,?_⟩
    filter_upwards [(tendsto_order.1 hl).1 ((m/r)/2) (by linarith),
      eventually_ge_atTop a] with t ht ha
    have hh := hb t ha
    rw [exp_mul_interval r a t (ne_of_gt hr)] at hh
    have he : Real.exp (-(r*t))*Real.exp (r*t)=1 := by
      rw [← Real.exp_add]; simp
    have hh' := mul_le_mul_of_nonneg_left hh (Real.exp_nonneg (-(r*t)))
    have heq : Real.exp (-(r*t))*(Real.exp (r*a)*q a+
        m*((Real.exp (r*t)-Real.exp (r*a))/r)) = m/r+Real.exp (-(r*t))*B := by
      dsimp [B]
      field_simp
      nlinarith [he]
    rw [heq,← mul_assoc,he,one_mul] at hh'
    exact ht.le.trans hh'

-- @paper-step thm:n_necessary/lag_weighted_forcing_comparison
theorem lag_excess_comparison {σ a c : ℝ} {u x : ℝ → ℝ}
    (h : LagResponse σ u x) (hσ : 0 < σ) (ha : 0 ≤ a)
    (hu : ∀ s, a ≤ s → c ≤ Real.exp s*(u s-1)) :
    ∀ t, a ≤ t →
      Real.exp ((1/σ-1)*a)*(Real.exp a*(x a-1))+
        (c/σ)*(∫ s in a..t, Real.exp ((1/σ-1)*s)) ≤
      Real.exp ((1/σ-1)*t)*(Real.exp t*(x t-1)) := by
  intro t hat
  have he (s : ℝ) : Real.exp ((1/σ-1)*s)*Real.exp s=Real.exp (s/σ) := by
    rw [← Real.exp_add]
    congr 1
    ring
  have hiu : IntervalIntegrable (fun s => Real.exp (s/σ)*(u s-1)/σ) volume a t := by
    have hi := (h.input_integrable t (ha.trans hat)).mono_set (by
      rw [uIcc_of_le hat,uIcc_of_le (ha.trans hat)]
      exact fun s hs => ⟨ha.trans hs.1,hs.2⟩)
    exact ((hi.sub intervalIntegrable_const).continuousOn_mul
      (by fun_prop : Continuous (fun s : ℝ => Real.exp (s/σ))).continuousOn).div_const σ
  have hic : IntervalIntegrable (fun s => (c/σ)*Real.exp ((1/σ-1)*s)) volume a t :=
    (by fun_prop : Continuous (fun s : ℝ => (c/σ)*Real.exp ((1/σ-1)*s))).intervalIntegrable _ _
  have hb := intervalIntegral.integral_mono_on hat hic hiu (fun s hs => by
    have hh := mul_le_mul_of_nonneg_left (hu s hs.1) (Real.exp_nonneg ((1/σ-1)*s))
    have hh' := div_le_div_of_nonneg_right hh hσ.le
    rw [← mul_assoc,he s] at hh'
    convert hh' using 1 <;> ring)
  rw [intervalIntegral.integral_const_mul,lag_weighted_increment h ha hat 1] at hb
  rw [← mul_assoc,he a,← mul_assoc,he t]
  linarith

-- @paper-step thm:n_necessary/overshoot_propagates_through_fast_or_equal_lag
theorem lag_excess_eventual {σ : ℝ} {u x : ℝ → ℝ}
    (h : LagResponse σ u x) (hσ : 0 < σ) (hσ1 : σ ≤ 1)
    (hu : ∃ c : ℝ, 0 < c ∧ ∀ᶠ t in atTop, c ≤ Real.exp t*(u t-1)) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ t in atTop, c ≤ Real.exp t*(x t-1) := by
  obtain ⟨c,hc,hu⟩ := hu
  obtain ⟨a,ha⟩ := eventually_atTop.1 hu
  have hr : 0 ≤ 1/σ-1 := by
    have : (1 : ℝ) ≤ 1/σ := (le_div_iff₀ hσ).2 (by simpa using hσ1)
    linarith
  exact exponential_comparison_eventual hr (div_pos hc hσ)
    (lag_excess_comparison h hσ (le_max_left 0 a)
      (fun s hs => ha s ((le_max_right 0 a).trans hs)))

-- @paper-step thm:n_necessary/slowest_lag_persistent_excess
theorem slowest_lag_excess {u x : ℝ → ℝ} (h : LagResponse 1 u x)
    (hu : ∀ᵐ t ∂halfLine, 1 ≤ u t) {a : ℝ} (ha : 0 ≤ a) (hx : 1 < x a) :
    ∃ c : ℝ, 0 < c ∧ ∀ᶠ t in atTop, c ≤ Real.exp t*(x t-1) := by
  refine ⟨Real.exp a*(x a-1),mul_pos (Real.exp_pos _) (by linarith),?_⟩
  filter_upwards [eventually_ge_atTop a] with t hat
  have hi := lag_weighted_increment h ha hat 1
  have hn : 0 ≤ ∫ s in a..t, Real.exp (s/1)*(u s-1)/1 := by
    rw [intervalIntegral.integral_of_le hat]
    apply integral_nonneg_of_ae
    have hs : Ioc a t ⊆ Ioi (0 : ℝ) := fun s hs => lt_of_le_of_lt ha hs.1
    filter_upwards [ae_restrict_of_ae_restrict_of_subset hs hu] with s hsu
    positivity
  simp only [div_one] at hi hn
  linarith

-- Backwards necessity for a finite cascade, with the slowest lag placed first.
-- @paper-step thm:n_necessary/cascade_backwards_nonovershoot
theorem cascade_first_nonovershoot (N : ℕ) (σ : ℕ → ℝ) (x : ℕ → ℝ → ℝ)
    (hσ : ∀ j ≤ N, 0 < σ j ∧ σ j ≤ 1) (hfirst : σ 0=1)
    (hx : ∀ j ≤ N, LagResponse (σ j) (x j) (x (j+1)))
    (hw : ∀ᵐ t ∂halfLine, 1 ≤ x 0 t)
    (hy : ∀ t : ℝ, 0 ≤ t → x (N+1) t ≤ 1) :
    ∀ t : ℝ, 0 ≤ t → x 1 t ≤ 1 := by
  intro a ha
  by_contra hn
  have hstart : ∃ c : ℝ, 0 < c ∧ ∀ᶠ t in atTop, c ≤ Real.exp t*(x 1 t-1) :=
    slowest_lag_excess (by simpa [hfirst] using hx 0 (Nat.zero_le N)) hw ha (lt_of_not_ge hn)
  have hind : ∀ j ≤ N, ∃ c : ℝ, 0 < c ∧
      ∀ᶠ t in atTop, c ≤ Real.exp t*(x (j+1) t-1) := by
    intro j hj
    induction j with
    | zero => exact hstart
    | succ j ih =>
      exact lag_excess_eventual (hx (j+1) hj) (hσ (j+1) hj).1 (hσ (j+1) hj).2
        (ih (by omega))
  obtain ⟨c,hc,he⟩ := hind N le_rfl
  obtain ⟨t,ht,hb⟩ := (he.and (eventually_ge_atTop (0 : ℝ))).exists
  have hh := mul_nonpos_of_nonneg_of_nonpos (Real.exp_nonneg t) (sub_nonpos.mpr (hy t hb))
  linarith

-- @paper-step thm:command_cone/ordinary_slowest_state_balance
theorem slowest_lag_balance {v x : ℝ → ℝ} (h : LagResponse 1 (fun t => 1+v t) x)
    {t : ℝ} (ht : 0 ≤ t) :
    (∫ s in 0..t, Real.exp s*v s)=1+Real.exp t*(x t-1) := by
  have hi := lag_weighted_increment h (show (0 : ℝ)≤0 from le_rfl) ht 1
  simpa [h.initial,add_comm] using hi

-- @paper-step thm:command_cone/ordinary_slowest_moment_finiteness
theorem slowest_lag_moment_finite {v x : ℝ → ℝ}
    (h : LagResponse 1 (fun t => 1+v t) x) (hv : Integrable v halfLine)
    (hn : ∀ᵐ t ∂halfLine, 0 ≤ v t) (hx : ∀ t : ℝ, 0 ≤ t → x t ≤ 1) :
    Integrable (fun t => Real.exp t*v t) halfLine ∧ moment v ≤ 1 := by
  refine fatou_moment_bound (G := fun n => truncatedWeight v (n : ℝ))
    (fun n => truncatedWeight_integrable hv n (Nat.cast_nonneg n)) ?_ ?_ hn ?_
  · intro n
    filter_upwards [hn] with t ht
    by_cases hnt : t ∈ Ioc 0 (n : ℝ)
    · simp only [truncatedWeight,indicator_of_mem hnt]
      exact mul_nonneg (Real.exp_nonneg _) ht
    · simp [truncatedWeight,hnt]
  · intro n
    rw [truncatedWeight_integral v n (Nat.cast_nonneg n),slowest_lag_balance h (Nat.cast_nonneg n)]
    have hp := mul_nonpos_of_nonneg_of_nonpos (Real.exp_nonneg (n : ℝ))
      (sub_nonpos.mpr (hx n (Nat.cast_nonneg n)))
    linarith
  · filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    obtain ⟨N,hN⟩ := exists_nat_ge t
    have heq : (fun n : ℕ => truncatedWeight v (n : ℝ) t) =ᶠ[atTop]
        (fun _ => Real.exp t*v t) := by
      filter_upwards [eventually_ge_atTop N] with n hn
      have hcast : (N : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
      simp [truncatedWeight,show t ∈ Ioc 0 (n : ℝ) from ⟨ht,hN.trans hcast⟩]
    exact tendsto_const_nhds.congr' heq.symm

-- @paper-step thm:command_cone/cascade_moment_necessity
theorem cascade_moment_necessary (N : ℕ) (σ : ℕ → ℝ) (x : ℕ → ℝ → ℝ)
    {v : ℝ → ℝ} (hσ : ∀ j ≤ N, 0 < σ j ∧ σ j ≤ 1) (hfirst : σ 0=1)
    (hx : ∀ j ≤ N, LagResponse (σ j) (x j) (x (j+1)))
    (hw : x 0=fun t => 1+v t) (hv : Integrable v halfLine)
    (hn : ∀ᵐ t ∂halfLine, 0 ≤ v t)
    (hy : ∀ t : ℝ, 0 ≤ t → x (N+1) t ≤ 1) :
    Integrable (fun t => Real.exp t*v t) halfLine ∧ moment v ≤ 1 := by
  have hw1 : ∀ᵐ t ∂halfLine, 1 ≤ x 0 t := by
    rw [hw]
    filter_upwards [hn] with t ht
    linarith
  exact slowest_lag_moment_finite (by simpa [hfirst,hw] using hx 0 (Nat.zero_le N)) hv hn
    (cascade_first_nonovershoot N σ x hσ hfirst hx hw1 hy)

-- All hypotheses describe the actual ordinary zero-state cascade and its
-- transfer integrals. The crucial moment condition is a conclusion.
-- @paper-step thm:n_necessary/full_statement
theorem paper_cascade_necessary (N : ℕ) (σ : ℕ → ℝ) (x : ℕ → ℝ → ℝ)
    {v H : ℝ → ℝ} (δ α μ : ℝ) (hδ : 0 ≤ δ) (hα : 0 < α) (hS : 0 < μ+δ)
    (hσ : ∀ j ≤ N, 0 < σ j ∧ σ j ≤ 1) (hfirst : σ 0=1)
    (hx : ∀ j ≤ N, LagResponse (σ j) (x j) (x (j+1)))
    (hw : x 0=fun t => 1+v t)
    (h : TransferResponse (delayedError δ (fun t => 1-x (N+1) t)) v H δ)
    (hH : HasDerivAt H (-μ) 0) (h0 : H 0=1)
    (heq : miace α (delayedError δ (fun t => 1-x (N+1) t)) v halfLine =
      (μ+δ)*minimum α) :
    α > μ+δ-1 ∧ Integrable (fun t => Real.exp t*v t) halfLine ∧
      moment v ≤ 1 ∧ commandArea v < 1 := by
  have hg := paper_general_plant h α μ hα hS hH h0
  obtain ⟨he,hv,_⟩ := hg.2.2.2.2.1.mp heq
  have hxu := undelayed_error_nonnegative hδ he
  have hxy : ∀ t : ℝ, 0 ≤ t → x (N+1) t ≤ 1 := by
    apply lag_ae_upper_bound (hx N le_rfl)
    filter_upwards [hxu] with t ht
    linarith
  obtain ⟨hJ,hM⟩ := cascade_moment_necessary N σ x hσ hfirst hx hw h.command_integrable hv hxy
  have hU := area_lt_one_of_moment h.command_integrable hJ hv hM
  have ha : absArea v halfLine=commandArea v := by
    apply integral_congr_ae
    filter_upwards [hv] with t ht
    exact abs_of_nonneg ht
  have harea := (hg.2.2.2.2.2 heq).2
  rw [ha] at harea
  have hb : (μ+δ)/(1+α)<1 := by rwa [← harea]
  have hc := (div_lt_one (show 0 < 1+α by linarith)).mp hb
  exact ⟨by linarith,hJ,hM,hU⟩

-- Physical-unit form, with δ = L/τ* and μ = 1 + Στj/τ*.
-- @paper-step thm:n_necessary/dimensional_equivalence
theorem cascade_necessary_dimensional (α L τstar τrest : ℝ) (hτ : 0 < τstar) :
    α > (1+τrest/τstar)+L/τstar-1 ↔ L < α*τstar-τrest := by
  have he : (1+τrest/τstar)+L/τstar-1=(τrest+L)/τstar := by ring
  rw [he,gt_iff_lt,div_lt_iff₀ hτ]
  constructor <;> intro h <;> linarith

end MIACE
