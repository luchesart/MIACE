import MIACE.CompactLaplace
import MIACE.FirstOrderRealization
import Mathlib.Analysis.Analytic.Uniqueness

/-! Stage 19. Analytic continuation of the actual absolutely convergent
Laplace integral. The decay bound is proved from attainment in the next
module; the multiplied controller identity can then be continued to p>-1. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def halfComplexLaplace (E : ℝ → ℝ) (p : ℂ) : ℂ :=
  ∫ t, Complex.exp (-p*(t : ℂ))*(E t : ℂ) ∂halfLine

-- @paper-step thm:delayed_optimum/exponential_polynomial_domination
theorem linear_exp_bound {b t : ℝ} (hb : 0<b) (ht : 0≤t) :
    t*Real.exp (-b*t)≤(2/b)*Real.exp (-(b/2)*t) := by
  have hp := Real.add_one_le_exp ((b/2)*t)
  have ht' : t≤(2/b)*Real.exp ((b/2)*t) := by
    rw [div_mul_eq_mul_div]
    apply (le_div_iff₀ hb).mpr
    linarith
  calc
    t*Real.exp (-b*t)≤((2/b)*Real.exp ((b/2)*t))*Real.exp (-b*t) :=
      mul_le_mul_of_nonneg_right ht' (Real.exp_nonneg _)
    _ = (2/b)*Real.exp (-(b/2)*t) := by
      rw [mul_assoc,← Real.exp_add]
      congr 2; ring

-- @paper-step thm:delayed_optimum/absolute_complex_laplace_domination
theorem halfLaplace_exp_bound {E : ℝ → ℝ} {C : ℝ}
    (hE : ∀ t, 0≤t → |E t|≤C*Real.exp (-t)) (p : ℂ) {t : ℝ} (ht : 0≤t) :
    ‖Complex.exp (-p*(t : ℂ))*(E t : ℂ)‖≤C*Real.exp (-(p.re+1)*t) := by
  rw [norm_mul,Complex.norm_exp,Complex.norm_real,Real.norm_eq_abs]
  have he : (-p*(t : ℂ)).re= -p.re*t := by simp
  rw [he]
  calc
    Real.exp (-p.re*t)*|E t|≤Real.exp (-p.re*t)*(C*Real.exp (-t)) :=
      mul_le_mul_of_nonneg_left (hE t ht) (Real.exp_nonneg _)
    _ = C*Real.exp (-(p.re+1)*t) := by
      rw [mul_left_comm,← Real.exp_add]
      congr 2; ring

-- @paper-step thm:delayed_optimum/complex_laplace_integrability_on_extended_half_plane
theorem halfLaplace_integrable {E : ℝ → ℝ} (hc : Continuous E) {C : ℝ}
    (hE : ∀ t, 0≤t → |E t|≤C*Real.exp (-t)) {p : ℂ} (hp : -1<p.re) :
    Integrable (fun t : ℝ => Complex.exp (-p*(t : ℂ))*(E t : ℂ)) halfLine := by
  have hi := (integrableOn_exp_mul_Ioi (by linarith : -(p.re+1)<0) 0).const_mul C
  apply hi.mono' (by apply Continuous.aestronglyMeasurable; fun_prop)
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  exact halfLaplace_exp_bound hE p (show 0<t from ht).le

-- @paper-step thm:delayed_optimum/complex_differentiation_under_infinite_integral
theorem halfLaplace_deriv {E : ℝ → ℝ} (hc : Continuous E) {C : ℝ} (hC : 0≤C)
    (hE : ∀ t, 0≤t → |E t|≤C*Real.exp (-t)) {p : ℂ} (hp : -1<p.re) :
    HasDerivAt (halfComplexLaplace E)
      (∫ t, -(t : ℂ)*(Complex.exp (-p*(t : ℂ))*(E t : ℂ)) ∂halfLine) p := by
  let b := (p.re+1)/2
  have hb : 0<b := by dsimp [b]; linarith
  let B := fun t : ℝ => C*(2/b)*Real.exp (-(b/2)*t)
  have hB : Integrable B halfLine :=
    (integrableOn_exp_mul_Ioi (by linarith : -(b/2)<0) 0).const_mul (C*(2/b))
  apply (hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (μ := halfLine) (F := fun q t => Complex.exp (-q*(t : ℂ))*(E t : ℂ))
    (F' := fun q t => -(t : ℂ)*(Complex.exp (-q*(t : ℂ))*(E t : ℂ)))
    (s := Metric.ball p b) (bound := B) (Metric.ball_mem_nhds p hb)
    (Eventually.of_forall (fun q => by apply Continuous.aestronglyMeasurable; fun_prop))
    (halfLaplace_integrable hc hE hp)
    (by apply Continuous.aestronglyMeasurable; fun_prop) ?_ hB ?_).2
  · filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht q hq
    have ht0 : 0≤t := (show 0<t from ht).le
    have hqr : |q.re-p.re|≤‖q-p‖ := by simpa using Complex.abs_re_le_norm (q-p)
    have hdist : |q.re-p.re|<b := hqr.trans_lt (by simpa only [Metric.mem_ball,dist_eq_norm] using hq)
    have hqre : b≤q.re+1 := by dsimp [b] at *; linarith [(abs_lt.mp hdist).1]
    rw [norm_mul,norm_neg,Complex.norm_real,Real.norm_of_nonneg ht0]
    calc
      t*‖Complex.exp (-q*(t : ℂ))*(E t : ℂ)‖≤t*(C*Real.exp (-(q.re+1)*t)) :=
        mul_le_mul_of_nonneg_left (halfLaplace_exp_bound hE q ht0) ht0
      _ ≤ t*(C*Real.exp (-b*t)) := mul_le_mul_of_nonneg_left
        (mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (by nlinarith)) hC) ht0
      _ ≤ B t := by
        have hh := mul_le_mul_of_nonneg_left (linear_exp_bound hb ht0) hC
        dsimp [B]; nlinarith
  · apply Eventually.of_forall
    intro t q _
    convert (((hasDerivAt_id q).neg.mul_const (t : ℂ)).cexp).mul_const (E t : ℂ) using 1
    · rfl
    · dsimp; ring

-- @paper-step thm:delayed_optimum/analytic_laplace_on_extended_half_plane
theorem halfLaplace_analytic {E : ℝ → ℝ} (hc : Continuous E) {C : ℝ} (hC : 0≤C)
    (hE : ∀ t, 0≤t → |E t|≤C*Real.exp (-t)) {p : ℂ} (hp : -1<p.re) :
    AnalyticAt ℂ (halfComplexLaplace E) p := by
  apply (show DifferentiableOn ℂ (halfComplexLaplace E) {z : ℂ | -1<z.re} from
    fun z hz => (halfLaplace_deriv hc hC hE hz).differentiableAt.differentiableWithinAt).analyticAt
  exact (isOpen_lt continuous_const Complex.continuous_re).mem_nhds hp

-- @paper-step thm:delayed_optimum/complex_integral_restricts_to_real_laplace
theorem halfComplexLaplace_real (E : ℝ → ℝ) (p : ℝ) :
    halfComplexLaplace E (p : ℂ)=(laplace E p : ℂ) := by
  rw [halfComplexLaplace,laplace,← integral_complex_ofReal]
  apply integral_congr_ae
  apply Eventually.of_forall
  intro t
  simp only [Complex.ofReal_mul,Complex.ofReal_exp,Complex.ofReal_neg]

-- @paper-step thm:delayed_optimum/real_analytic_continuation_of_laplace
theorem laplace_real_analytic {E : ℝ → ℝ} (hc : Continuous E) {C : ℝ} (hC : 0≤C)
    (hE : ∀ t, 0≤t → |E t|≤C*Real.exp (-t)) :
    AnalyticOnNhd ℝ (laplace E) (Ioi (-1)) := by
  intro p hp
  have hh := halfLaplace_analytic hc hC hE (p := (p : ℂ)) hp
  have hr : AnalyticAt ℝ (fun x : ℝ => (halfComplexLaplace E (x : ℂ)).re) p := (Complex.reCLM.analyticAt (halfComplexLaplace E (p : ℂ))).comp
    (f := fun x : ℝ => halfComplexLaplace E (x : ℂ))
    (hh.restrictScalars.comp (Complex.ofRealCLM.analyticAt p))
  simpa only [Function.comp_def,halfComplexLaplace_real,Complex.ofReal_re] using hr

-- @paper-step thm:delayed_optimum/identity_principle_for_multiplied_transfer_equations
theorem analytic_identity_from_positive {f g : ℝ → ℝ}
    (hf : AnalyticOnNhd ℝ f (Ioi (-1))) (hg : AnalyticOnNhd ℝ g (Ioi (-1)))
    (he : ∀ p, 0<p → f p=g p) : ∀ p, -1<p → f p=g p := by
  apply hf.eqOn_of_preconnected_of_eventuallyEq hg (convex_Ioi (-1 : ℝ)).isPreconnected
    (show (1 : ℝ)∈Ioi (-1) by norm_num)
  filter_upwards [Ioi_mem_nhds (by norm_num : (0 : ℝ)<1)] with p hp
  exact he p hp

end MIACE
