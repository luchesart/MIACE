import MIACE.HistoryStability
import MIACE.PhysicalComparison

/-! Етап 12: завършена Теорема 10. Вътрешната експоненциална устойчивост
    за произволни истории е заключение, отделно от конкретната стъпкова
    траектория. Всички части са събрани в един вход към картата. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

/-- Every clause of the article's two-rate PID optimum, with actual integral
    costs, ordinary zero-history step states and all-history internal stability. -/
def TwoRateOptimum (α ρ ell δ : ℝ) : Prop :=
  PIDInternallyExponentiallyStable ((1+1/α)/(1+δ)) ρ ell δ ∧
  ∃ E V : ℝ → ℝ,
    OrdinaryPIDSignals ((1+1/α)/(1+δ)) ρ ell δ E V ∧
    PhysicalPIDStep ((1+1/α)/(1+δ)) ρ ell δ E V ∧
    absArea E halfLine=α*(1+δ)/(1+α) ∧
    absArea V halfLine=(1+δ)/(1+α) ∧
    miace α E V halfLine=(1+δ)*Real.sqrt (α/(1+α)) ∧
    MonotoneOn (fun t => 1-E t) (Ici 0) ∧
    (1-E 0)=0 ∧ Tendsto (fun t => 1-E t) atTop (𝓝 1) ∧
    (∀ t, 0≤t → 0≤1-E t ∧ 1-E t<1) ∧
    ∀ e v : ℝ → ℝ, FirstOrderResponse e v →
      miace α E V halfLine≤miace α (delayedError δ e) v halfLine

-- @paper-step thm:pid_two_rate_optimum/complete_theorem_10
theorem paper_two_rate_optimum {α ρ ell l m δ : ℝ} (hα : 0<α)
    (h : TwoRateData ((1+1/α)/(1+δ)) ρ ell l m δ) : TwoRateOptimum α ρ ell δ := by
  obtain ⟨E,V,hs,hphys,he,hv,hcost,hglobal⟩ := twoRate_physical_global_optimum hα h
  exact ⟨twoRate_internal_exponential_stability h,E,V,hs,hphys,he,hv,hcost,
    hphys.output_monotone,hphys.output_initial,(ordinary_PID_settling hs).2.2.2.1,
    hphys.output_bounds,hglobal⟩

-- @paper-step thm:pid_two_rate_optimum/complete_theorem_from_displayed_tuning
theorem paper_two_rate_optimum_from_formulas {α l m δ : ℝ} (hα : 0<α)
    (hl : 1<l) (hlm : l<m) (hδ : 0≤δ)
    (hd : l*Real.exp (-l*δ)-m*Real.exp (-m*δ)≠0)
    (hρ : 0<pidRho ((1+1/α)/(1+δ)) δ l m)
    (hρ1 : pidRho ((1+1/α)/(1+δ)) δ l m<1)
    (hell : pidRho ((1+1/α)/(1+δ)) δ l m<
      pidLead ((1+1/α)/(1+δ)) δ l (pidRho ((1+1/α)/(1+δ)) δ l m))
    (hlo : m≤1/pidRho ((1+1/α)/(1+δ)) δ l m)
    (hhi : 1/pidRho ((1+1/α)/(1+δ)) δ l m≤l+m-1)
    (hinit : ∀ t∈Icc (0 : ℝ) δ,
      0≤twoRateR (twoRateA (pidRho ((1+1/α)/(1+δ)) δ l m) l m) l m δ t) :
    TwoRateOptimum α (pidRho ((1+1/α)/(1+δ)) δ l m)
      (pidLead ((1+1/α)/(1+δ)) δ l (pidRho ((1+1/α)/(1+δ)) δ l m)) δ := by
  apply paper_two_rate_optimum hα
  exact twoRate_data_from_formulas (by positivity) hl hlm hδ hd hρ hρ1 hell hlo hhi hinit

end MIACE
