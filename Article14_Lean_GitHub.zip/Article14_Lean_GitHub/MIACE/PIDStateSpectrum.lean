import MIACE.TwoRateSpectrum
import Mathlib.LinearAlgebra.Matrix.Determinant.Basic

/-! Етап 8: физическите хомогенни състояния (y,z,ζ).
    Векторът е отклонение от равновесието: e=-y, z'=−y, ρζ'=−y−ζ.
    Закъснението действа върху цялата команда в уравнението y'=−y+w(t−δ).
    Доказва се пълният детерминант; критерият за DDE устойчивост не е аксиома. -/
namespace MIACE
open Matrix
open scoped Matrix

noncomputable def pidStateA0 (ρ : ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  !![-1,0,0; -1,0,0; -1/ρ,0,-1/ρ]
noncomputable def pidStateA1 (pc i dc ρ : ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  !![-(pc+dc/ρ),i,-dc/ρ; 0,0,0; 0,0,0]
noncomputable def pidHomogeneousCommand (pc i dc ρ : ℝ) (x : Fin 3 → ℝ) : ℝ :=
  -pc*x 0+i*x 1+(dc/ρ)*(-x 0-x 2)
noncomputable def pidStateSymbol (pc i dc ρ δ : ℝ) (p : ℂ) : Matrix (Fin 3) (Fin 3) ℂ :=
  p • (1 : Matrix (Fin 3) (Fin 3) ℂ)-(pidStateA0 ρ).map Complex.ofReal-
    Complex.exp (-(δ : ℂ)*p) • (pidStateA1 pc i dc ρ).map Complex.ofReal

-- @paper-step thm:pid_two_rate_optimum/physical_three_state_equations
theorem pid_state_equations (pc i dc ρ : ℝ) (x xd : Fin 3 → ℝ) :
    (pidStateA0 ρ).mulVec x+(pidStateA1 pc i dc ρ).mulVec xd=
      ![-x 0+pidHomogeneousCommand pc i dc ρ xd,-x 0,(-x 0-x 2)/ρ] := by
  ext k
  fin_cases k <;> simp [pidStateA0,pidStateA1,pidHomogeneousCommand,Matrix.mulVec,
    dotProduct,Fin.sum_univ_succ] <;> ring

-- @paper-step thm:pid_two_rate_optimum/full_physical_characteristic_determinant
theorem pid_state_determinant (pc i dc δ : ℝ) {ρ : ℝ} (hρ : ρ ≠ 0) (p : ℂ) :
    (pidStateSymbol pc i dc ρ δ p).det=
      (p*(p+1)*(1+(ρ : ℂ)*p)+
        (((pc : ℂ)*ρ+dc)*p^2+((pc : ℂ)+(i : ℂ)*ρ)*p+i)*Complex.exp (-(δ : ℂ)*p))/(ρ : ℂ) := by
  have hr : (ρ : ℂ) ≠ 0 := Complex.ofReal_ne_zero.mpr hρ
  rw [Matrix.det_fin_three]
  simp only [pidStateSymbol,pidStateA0,pidStateA1,Matrix.sub_apply,Matrix.smul_apply,
    Matrix.map_apply,smul_eq_mul]
  norm_num
  field_simp
  <;> ring

-- @paper-step thm:pid_two_rate_optimum/uncancelled_physical_factorization
theorem pid_state_factorization {i ρ ell l m δ : ℝ} (h : TwoRateData i ρ ell l m δ) (p : ℂ) :
    (pidStateSymbol (i*(1+ell-ρ)) i (i*(ell-ρ)*(1-ρ)) ρ δ p).det=
      (p+1)*pidCharacteristic i ρ ell δ p/(ρ : ℂ) := by
  rw [pid_state_determinant _ _ _ _ (ne_of_gt h.filter_pos)]
  unfold pidCharacteristic
  push_cast
  ring

-- @paper-step thm:pid_two_rate_optimum/physical_characteristic_zero_free_half_plane
theorem twoRate_physical_spectrum {i ρ ell l m δ : ℝ} (h : TwoRateData i ρ ell l m δ) :
    ∃ η : ℝ, 0<η ∧ η≤1/2 ∧ ∀ p : ℂ, -η≤p.re →
      (pidStateSymbol (i*(1+ell-ρ)) i (i*(ell-ρ)*(1-ρ)) ρ δ p).det ≠ 0 := by
  obtain ⟨η,hη,hle,hstrip⟩ := twoRate_zero_free_half_plane h
  refine ⟨η,hη,hle,?_⟩
  intro p hp
  rw [pid_state_factorization h]
  exact (hstrip p hp).2.2

end MIACE
