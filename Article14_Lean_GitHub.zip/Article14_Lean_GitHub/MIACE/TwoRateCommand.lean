import MIACE.TwoRateLaplace

/-! Етап 8: действителният Лапласов интеграл на командата.
    Формулата се извежда от явното R, а не се приема като условие. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:pid_two_rate_optimum/shifted_pair_laplace
theorem causal_exp_pair_laplace (C D δ : ℝ) {l m p : ℝ}
    (hl : 0 < l) (hm : 0 < m) (hp : 0 ≤ p) :
    laplace (causalize (fun t => C*Real.exp (-l*(t+δ))+D*Real.exp (-m*(t+δ)))) p=
      C*Real.exp (-l*δ)/(p+l)+D*Real.exp (-m*δ)/(p+m) := by
  rw [← kernel_laplace_full (causalize_causal _) p,expWeight_causalize,causalize_integral]
  have he : (fun t => Real.exp (-p*t)*(C*Real.exp (-l*(t+δ))+D*Real.exp (-m*(t+δ))))=
      (fun t => (C*Real.exp (-l*δ))*Real.exp (-(p+l)*t)+
        (D*Real.exp (-m*δ))*Real.exp (-(p+m)*t)) := by
    funext t
    have h₁ : Real.exp (-p*t)*Real.exp (-l*(t+δ))=Real.exp (-l*δ)*Real.exp (-(p+l)*t) := by
      rw [← Real.exp_add,← Real.exp_add]; congr 1; ring
    have h₂ : Real.exp (-p*t)*Real.exp (-m*(t+δ))=Real.exp (-m*δ)*Real.exp (-(p+m)*t) := by
      rw [← Real.exp_add,← Real.exp_add]; congr 1; ring
    calc
      _ = C*(Real.exp (-p*t)*Real.exp (-l*(t+δ)))+D*(Real.exp (-p*t)*Real.exp (-m*(t+δ))) := by ring
      _ = _ := by rw [h₁,h₂]; ring
  change (∫ t, (Real.exp (-p*t)*(C*Real.exp (-l*(t+δ))+D*Real.exp (-m*(t+δ)))) ∂halfLine)=_
  rw [he]
  unfold halfLine
  rw [integral_add ((integrableOn_exp_mul_Ioi (by linarith : -(p+l)<0) 0).const_mul _)
    ((integrableOn_exp_mul_Ioi (by linarith : -(p+m)<0) 0).const_mul _),
    integral_const_mul,integral_const_mul,
    integral_exp_mul_Ioi (by linarith : -(p+l)<0),integral_exp_mul_Ioi (by linarith : -(p+m)<0)]
  simp only [mul_zero,Real.exp_zero,neg_div_neg_eq]
  ring

-- @paper-step thm:pid_two_rate_optimum/compact_correction_laplace
theorem twoRate_correction_laplace (A : ℝ) {l m δ p : ℝ}
    (hl : 0 < l) (hm : 0 < m) (hδ : 0 ≤ δ) (hp : 0 < p) :
    laplace ((Ico (0 : ℝ) δ).indicator (fun t => twoRateG A l m δ-twoRateG A l m t)) p=
      twoRateG A l m δ*(1-Real.exp (-p*δ))/p-
        (A*(1-Real.exp (-(p+l)*δ))/(p+l)+(1-A)*(1-Real.exp (-(p+m)*δ))/(p+m)) := by
  have hc : Causal ((Ico (0 : ℝ) δ).indicator (fun t => twoRateG A l m δ-twoRateG A l m t)) := by
    apply ae_of_all
    intro t ht
    exact indicator_of_notMem (show t ∉ Ico (0 : ℝ) δ from fun h => (not_le_of_gt ht) h.1) _
  have he : expWeight (-p) ((Ico (0 : ℝ) δ).indicator (fun t => twoRateG A l m δ-twoRateG A l m t))=
      (Ico (0 : ℝ) δ).indicator (fun t => twoRateG A l m δ*Real.exp (-p*t)-
        (A*Real.exp (-(p+l)*t)+(1-A)*Real.exp (-(p+m)*t))) := by
    funext t
    by_cases ht : t ∈ Ico (0 : ℝ) δ
    · simp only [expWeight,indicator_of_mem ht,twoRateG]
      have h₁ : Real.exp (-p*t)*Real.exp (-l*t)=Real.exp (-(p+l)*t) := by
        rw [← Real.exp_add]; congr 1; ring
      have h₂ : Real.exp (-p*t)*Real.exp (-m*t)=Real.exp (-(p+m)*t) := by
        rw [← Real.exp_add]; congr 1; ring
      calc
        _ = (A*Real.exp (-l*δ)+(1-A)*Real.exp (-m*δ))*Real.exp (-p*t)-
          (A*(Real.exp (-p*t)*Real.exp (-l*t))+(1-A)*(Real.exp (-p*t)*Real.exp (-m*t))) := by ring
        _ = _ := by rw [h₁,h₂]
    · simp [expWeight,ht]
  rw [← kernel_laplace_full hc p,he,integral_indicator measurableSet_Ico,
    integral_Ico_eq_integral_Ioc,← intervalIntegral.integral_of_le hδ]
  rw [intervalIntegral.integral_sub (by apply Continuous.intervalIntegrable; fun_prop)
      (by apply Continuous.intervalIntegrable; fun_prop),
    intervalIntegral.integral_add (by apply Continuous.intervalIntegrable; fun_prop)
      (by apply Continuous.intervalIntegrable; fun_prop),
    intervalIntegral.integral_const_mul,intervalIntegral.integral_const_mul,
    intervalIntegral.integral_const_mul,finite_exp_integral (ne_of_gt hp),
    finite_exp_integral (ne_of_gt (by positivity : 0<p+l)),
    finite_exp_integral (ne_of_gt (by positivity : 0<p+m))]
  ring

-- @paper-step thm:pid_two_rate_optimum/actual_command_forcing_laplace
theorem twoRateR_laplace (A : ℝ) {l m δ p : ℝ}
    (hl : 0 < l) (hm : 0 < m) (hδ : 0 ≤ δ) (hp : 0 < p) :
    laplace (causalize (twoRateR A l m δ)) p=
      (l*A*Real.exp (-l*δ)/(p+l)+m*(1-A)*Real.exp (-m*δ)/(p+m))*
        (1+(1-Real.exp (-δ*p))/p)-(A/(p+l)+(1-A)/(p+m)) := by
  let f := fun t => (l-1)*A*Real.exp (-l*(t+δ))+(m-1)*(1-A)*Real.exp (-m*(t+δ))
  let q := (Ico (0 : ℝ) δ).indicator (fun t => twoRateG A l m δ-twoRateG A l m t)
  have hf : Integrable (causalize f) := by
    simpa only [expWeight_zero] using weighted_exp_pair_integrable ((l-1)*A) ((m-1)*(1-A)) δ hl hm
  have hq : Integrable q := compact_indicator_integrable (continuous_const.sub (twoRate_continuous A l m).1) δ
  have hsplit : causalize (twoRateR A l m δ)=(fun t => causalize f t+q t) := by
    rw [twoRateR_split]
    have hfun : (fun t => twoRateD A l m (t+δ)-twoRateG A l m (t+δ))=f := by
      funext t
      dsimp [twoRateD,twoRateG,f]
      ring
    rw [hfun]
  rw [hsplit]
  have hlin : laplace (fun t => causalize f t+q t) p=laplace (causalize f) p+laplace q p := by
    unfold laplace
    simp_rw [mul_add]
    exact integral_add (laplace_integrable hf.restrict hp.le) (laplace_integrable hq.restrict hp.le)
  rw [hlin,causal_exp_pair_laplace _ _ _ hl hm hp.le,twoRate_correction_laplace A hl hm hδ hp]
  have h₁ : Real.exp (-(p+l)*δ)=Real.exp (-δ*p)*Real.exp (-l*δ) := by
    rw [← Real.exp_add]; congr 1; ring
  have h₂ : Real.exp (-(p+m)*δ)=Real.exp (-δ*p)*Real.exp (-m*δ) := by
    rw [← Real.exp_add]; congr 1; ring
  rw [h₁,h₂,show -p*δ= -δ*p by ring]
  unfold twoRateG
  field_simp
  <;> ring

-- @paper-step thm:pid_two_rate_optimum/command_forcing_controller_factor
theorem twoRateR_controller_laplace {i ρ ell l m δ p : ℝ}
    (h : TwoRateData i ρ ell l m δ) (hp : 0 < p) :
    laplace (causalize (twoRateR (twoRateA ρ l m) l m δ)) p=
      (i*(1+ell*p)/(1+ρ*p)*(1+(1-Real.exp (-δ*p))/p)-1)*
        laplace (causalize (twoRateG (twoRateA ρ l m) l m)) p := by
  have hl : 0 < l := by linarith [h.lower_rate]
  have hm : 0 < m := by linarith [h.lower_rate,h.ordered_rates]
  have hρ : ρ ≠ 0 := ne_of_gt h.filter_pos
  have hlp : p+l ≠ 0 := ne_of_gt (by positivity)
  have hmp : p+m ≠ 0 := ne_of_gt (by positivity)
  rw [twoRateR_laplace _ hl hm h.delay_nonneg hp,
    twoRate_shifted_fraction hρ (ne_of_lt h.ordered_rates) hlp hmp h.root_l h.root_m,
    twoRate_partial_fraction hρ (ne_of_lt h.ordered_rates) hlp hmp,
    twoRateG_rational_laplace h.filter_pos hl hm h.ordered_rates hp.le]
  have hf : 1+ρ*p ≠ 0 := ne_of_gt (by have hh:=h.filter_pos; positivity)
  field_simp [hf,hρ,hlp,hmp,ne_of_gt hp]
  ring_nf
  field_simp [show 1+p*ρ ≠ 0 by nlinarith [h.filter_pos]]
  <;> ring

end MIACE
