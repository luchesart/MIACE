import MIACE.DelayedPIAttainmentNecessity

/-! Stage 19. Exact closed attainment range, including both boundary cases.
The positive denominator is proved before clearing inequalities. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def delayedPIGain (α δ : ℝ) : ℝ := (1+1/α)/(1+δ)
noncomputable def delayedPIMaxDelay (α : ℝ) : ℝ :=
  min (1/α) (α/(Real.exp 1*(α+1)-α))

-- @paper-step thm:delayed_optimum/positive_range_denominator
theorem delayedPI_range_denominator {α : ℝ} (hα : 0<α) :
    0<Real.exp 1*(α+1)-α := by
  have he : 1<Real.exp (1 : ℝ) := Real.one_lt_exp_iff.mpr (by norm_num)
  nlinarith

-- @paper-step thm:delayed_optimum/gain_and_nonoscillation_constraints_exactly_match_range
theorem delayedPI_range_iff {α δ : ℝ} (hα : 0<α) (hδ : 0≤δ) :
    (1≤delayedPIGain α δ ∧ delayedPIGain α δ*δ≤Real.exp (-1)) ↔ δ≤delayedPIMaxDelay α := by
  have hd : 0<1+δ := by linarith
  have he : 0<Real.exp (1 : ℝ) := Real.exp_pos _
  have hden := delayedPI_range_denominator hα
  have hg : delayedPIGain α δ=(α+1)/(α*(1+δ)) := by
    unfold delayedPIGain; field_simp
  have h1 : 1≤delayedPIGain α δ ↔ δ≤1/α := by
    rw [delayedPIGain,le_div_iff₀ hd]
    constructor <;> intro h <;> linarith
  have h2 : delayedPIGain α δ*δ≤Real.exp (-1) ↔ δ≤α/(Real.exp 1*(α+1)-α) := by
    rw [hg,Real.exp_neg,← one_div,div_mul_eq_mul_div,div_le_div_iff₀ (mul_pos hα hd) he,
      le_div_iff₀ hden]
    constructor <;> intro h <;> nlinarith
  rw [h1,h2,delayedPIMaxDelay,le_min_iff]

-- @paper-step thm:delayed_optimum/positive_exact_optimal_gain
theorem delayedPIGain_pos {α δ : ℝ} (hα : 0<α) (hδ : 0≤δ) : 0<delayedPIGain α δ := by
  unfold delayedPIGain
  positivity

-- @paper-step thm:delayed_optimum/optimal_gain_satisfies_exact_area_ratio
theorem delayedPIGain_balance {α δ : ℝ} (hα : 0<α) (hδ : 0≤δ) :
    1/delayedPIGain α δ=α*(1+δ-1/delayedPIGain α δ) := by
  have hα1 : 1+1/α≠0 := ne_of_gt (by positivity)
  have hd : 1+δ≠0 := ne_of_gt (by positivity)
  unfold delayedPIGain
  field_simp
  <;> ring

-- @paper-step thm:delayed_optimum/physical_optimal_controller_parameters
theorem delayedPI_physical_gain {α τ k L : ℝ} (hα : 0<α) (hτ : 0<τ) (hk : 0<k) (hL : 0≤L) :
    delayedPIGain α (L/τ)/k=τ*(1+1/α)/(k*(τ+L)) := by
  have hd : τ+L≠0 := ne_of_gt (by linarith)
  unfold delayedPIGain
  field_simp
  <;> ring

end MIACE
