import MIACE.PointwiseDecay
import MIACE.PositiveLag
import Mathlib.Analysis.Calculus.ContDiff.RCLike

/-! Етап 9: действителни състояния на интегратора и филтъра при дадена грешка.
    Тук не се приема, че изчислената от тях команда вече съвпада с v. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:pid_two_rate_optimum/clamped_forcing_absolute_continuity
theorem twoRateG_max_ac (A l m δ a b : ℝ) :
    AbsolutelyContinuousOnInterval (fun t => twoRateG A l m (max δ t)) a b := by
  have hg : ContDiffOn ℝ 1 (twoRateG A l m) (Icc δ (max δ (max a b))) := by
    unfold twoRateG; fun_prop
  obtain ⟨C,hC⟩ := hg.exists_lipschitzOnWith (by norm_num) (convex_Icc _ _) isCompact_Icc
  have hm : AbsolutelyContinuousOnInterval (fun t : ℝ => max δ t) a b :=
    (LipschitzWith.id.const_max δ).lipschitzOnWith.absolutelyContinuousOnInterval
  exact hC.comp_absolutelyContinuousOnInterval
    (fun t ht => ⟨le_max_left _ _,max_le_max_left δ ht.2⟩) hm

-- @paper-step thm:pid_two_rate_optimum/ordinary_command_absolute_continuity
theorem twoRateCommandRep_ac {f : ℝ → ℝ} (hf : Integrable f)
    (A l m : ℝ) {δ : ℝ} (hδ : 0 ≤ δ) (a b : ℝ) :
    AbsolutelyContinuousOnInterval (twoRateCommandRep A l m δ f) a b := by
  have hd : AbsolutelyContinuousOnInterval (fun t => twoRateD A l m (t+δ)) a b := by
    apply ContDiffOn.absolutelyContinuousOnInterval
    unfold twoRateD; fun_prop
  have hg : AbsolutelyContinuousOnInterval (fun t => twoRateG A l m (t+δ)) a b := by
    apply ContDiffOn.absolutelyContinuousOnInterval
    unfold twoRateG; fun_prop
  have hg0 : AbsolutelyContinuousOnInterval (twoRateG A l m) a b := by
    apply ContDiffOn.absolutelyContinuousOnInterval
    unfold twoRateG; fun_prop
  exact (((hd.sub hg).add (twoRateG_max_ac A l m δ a b)).sub hg0).add
    (twoRateK_convolution_ac hf A l m hδ a b)

-- @paper-step thm:pid_two_rate_optimum/initial_command_high_frequency_gain
theorem twoRateD_initial_gain {i ρ ell l m δ : ℝ} (h : TwoRateData i ρ ell l m δ) :
    twoRateD (twoRateA ρ l m) l m δ=i*ell/ρ ∧
      i*(1+ell-ρ)+i*(ell-ρ)*(1-ρ)/ρ=i*ell/ρ := by
  have hρ := ne_of_gt h.filter_pos
  have hml : m-l ≠ 0 := sub_ne_zero.mpr (ne_of_gt h.ordered_rates)
  constructor
  · unfold twoRateD
    rw [twoRate_first_residue hρ (ne_of_lt h.ordered_rates) h.root_l,
      twoRate_second_residue hρ (ne_of_lt h.ordered_rates) h.root_m]
    field_simp
    <;> ring
  · field_simp
    <;> ring

-- @paper-step thm:pid_two_rate_optimum/lag_actual_convolution_realization
theorem lag_as_causal_convolution (ρ : ℝ) (hρ : 0<ρ) (f : ℝ → ℝ) {t : ℝ} (ht : 0≤t) :
    (lagKernel ρ ⋆ causalize f) t=lag ρ f t := by
  rw [causal_convolution_interval (lagKernel_properties hρ).2.2.2 (causalize_causal _) ht]
  unfold lag
  rw [← intervalIntegral.integral_const_mul]
  apply intervalIntegral.integral_congr_ae
  filter_upwards [volume.ae_ne t] with s hs hst
  rw [uIoc_of_le ht] at hst
  have hst' : s<t := lt_of_le_of_ne hst.2 hs
  have h₁ : t-s∈Ioi (0 : ℝ) := sub_pos.mpr hst'
  have h₂ : s∈Ici (0 : ℝ) := hst.1.le
  simp only [lagKernel,causalize,indicator_of_mem h₁,indicator_of_mem h₂]
  have he : Real.exp (-t/ρ)*Real.exp (s/ρ)=Real.exp ((-1/ρ)*(t-s)) := by
    rw [← Real.exp_add]; congr 1; ring
  calc
    _ = (1/ρ)*Real.exp ((-1/ρ)*(t-s))*f s := rfl
    _ = _ := by rw [← he]; ring

-- @paper-step thm:pid_two_rate_optimum/lag_weighted_impulse_bound
theorem lagKernel_weighted_bound {ρ η : ℝ} (hρ : 0<ρ) (hη : η≤1/ρ) (t : ℝ) :
    |expWeight η (lagKernel ρ) t| ≤ 1/ρ := by
  by_cases ht : t∈Ioi (0 : ℝ)
  · simp only [expWeight,lagKernel,indicator_of_mem ht]
    have he : Real.exp (η*t)*Real.exp ((-1/ρ)*t)≤1 := by
      rw [← Real.exp_add]
      apply Real.exp_le_one_iff.mpr
      calc
        η*t+(-1/ρ)*t=(η-1/ρ)*t := by ring
        _ ≤ 0 := mul_nonpos_of_nonpos_of_nonneg (sub_nonpos.mpr hη) (le_of_lt ht)
    rw [abs_of_nonneg (by positivity)]
    have hh := mul_le_mul_of_nonneg_left he (by positivity : 0≤1/ρ)
    nlinarith
  · simp [expWeight,lagKernel,ht,le_of_lt hρ]

-- @paper-step thm:pid_two_rate_optimum/constructed_filter_exponential_bound
theorem lag_weighted_decay {f : ℝ → ℝ} {ρ η : ℝ} (hρ : 0<ρ) (hη : η≤1/ρ)
    (hf : Integrable (expWeight η (causalize f))) {t : ℝ} (ht : 0≤t) :
    |lag ρ f t|≤((1/ρ)*(∫ s, |expWeight η (causalize f) s|))*Real.exp (-η*t) := by
  rw [← lag_as_causal_convolution ρ hρ f ht]
  exact convolution_weighted_pointwise_bound (by positivity) (lagKernel_weighted_bound hρ hη) hf t

-- @paper-step thm:pid_two_rate_optimum/constructed_controller_state_ODEs
theorem pid_state_functions {E : ℝ → ℝ} (hE : Continuous E) {ρ : ℝ} (hρ : 0<ρ) :
    (∫ s in (0 : ℝ)..0, E s)=0 ∧ lag ρ E 0=0 ∧
    (∀ t : ℝ, HasDerivAt (fun u => ∫ s in 0..u, E s) (E t) t) ∧
    (∀ t : ℝ, 0<t → HasDerivAt (lag ρ E) ((E t-lag ρ E t)/ρ) t) ∧
    (∀ T : ℝ, 0≤T → AbsolutelyContinuousOnInterval (fun t => ∫ s in 0..t, E s) 0 T ∧
      AbsolutelyContinuousOnInterval (lag ρ E) 0 T) := by
  refine ⟨by simp,by simp [lag],?_,?_,?_⟩
  · intro t
    exact intervalIntegral.integral_hasDerivAt_right (hE.intervalIntegrable _ _)
      hE.stronglyMeasurable.stronglyMeasurableAtFilter hE.continuousAt
  · intro t ht
    exact lag_hasDerivAt hE.continuousOn ρ t hρ ht
  · intro T hT
    exact ⟨intervalPrimitive_ac (fun a b => hE.intervalIntegrable a b) 0 0 T,
      lag_ac hE.continuousOn ρ T hT⟩

end MIACE
