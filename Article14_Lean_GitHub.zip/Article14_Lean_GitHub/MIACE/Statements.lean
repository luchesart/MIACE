import MIACE.Attainment

/-! Complete paper statements. These declarations assemble the reviewed steps,
using the actual derivative of y = 1-e. No balance or shape conclusion is an
additional hypothesis. The numbered labels refer to the captured article v10. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def outputVariation (e : ℝ → ℝ) : ℝ :=
  absArea (deriv (fun t => 1-e t)) halfLine
noncomputable def backwardMotion (e : ℝ → ℝ) : ℝ :=
  negArea (deriv (fun t => 1-e t)) halfLine

-- Connect the paper's squared square-root criterion to the polynomial cost.
-- @paper-step thm:miace_shape_gap/square_semantics
theorem miace_square (α : ℝ) (e v : ℝ → ℝ) (μ : Measure ℝ) (hα : 0 < α) :
    (miace α e v μ)^2 = costSq α (absArea e μ) (absArea v μ) := by
  apply Real.sq_sqrt
  unfold costSq
  positivity

-- @paper-step thm:miace_shape_gap/minimum_square
theorem minimum_square (α : ℝ) (hα : 0 < α) :
    (minimum α)^2 = α/(1+α) := by
  apply Real.sq_sqrt
  positivity

-- Every clause of Theorem 2, including the attaining normalized PI law.
-- @paper-step thm:miace_shape_gap/full_statement
theorem paper_shape_gap {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (α : ℝ) (hα : 0 < α) :
    ((miace α e v halfLine)^2 - (minimum α)^2 =
      4*(minimum α)^2*(negArea e halfLine+negArea v halfLine)*
        (1+(negArea e halfLine+negArea v halfLine)) +
      (absArea e halfLine-α*absArea v halfLine)^2/(1+α)) ∧
    minimum α ≤ miace α e v halfLine ∧
    (miace α e v halfLine = minimum α ↔
      (∀ᵐ t ∂halfLine, 0 ≤ e t) ∧ (∀ᵐ t ∂halfLine, 0 ≤ v t) ∧
      absArea e halfLine = α*absArea v halfLine) ∧
    (miace α e v halfLine = minimum α →
      MonotoneOn (fun t => 1-e t) (Ici 0) ∧
      (∀ t : ℝ, 0 ≤ t → 0 ≤ 1-e t ∧ 1-e t ≤ 1)) ∧
    FirstOrderResponse (expError (1+1/α)) (expCommand (1+1/α)) ∧
    (∀ t : ℝ, 0 ≤ t →
      1+expCommand (1+1/α) t = (1+1/α)*expError (1+1/α) t +
        (1+1/α)*(∫ s in 0..t, expError (1+1/α) s)) ∧
    miace α (expError (1+1/α)) (expCommand (1+1/α)) halfLine = minimum α := by
  have hx : 0 < 1+1/α := by positivity
  refine ⟨?_,response_miace_lower_bound h α hα,
    response_miace_equality_iff h α hα,?_,exponential_response _ hx,
    fun t ht => exponential_pi_law _ t hx ht,optimal_exponential_cost α hα⟩
  · rw [miace_square α e v halfLine hα, minimum_square α hα]
    have hi := response_excess h α hα
    simpa [baseSq, mul_div_assoc] using hi
  · intro hm
    obtain ⟨he,hv,_⟩ := (response_miace_equality_iff h α hα).mp hm
    exact ⟨response_output_monotone h he hv,fun t ht => response_output_bounds h he hv ht⟩

-- Substitute the ODE only after proving equality of actual derivatives ae.
-- @paper-step thm:miace_variation/variation_semantics
theorem actual_variation_eq {e v : ℝ → ℝ} (h : FirstOrderResponse e v) :
    outputVariation e = absArea (e+v) halfLine ∧
    backwardMotion e = negArea (e+v) halfLine := by
  constructor
  · unfold outputVariation absArea
    apply integral_congr_ae
    filter_upwards [response_output_derivative h] with t ht
    exact congrArg abs ht
  · unfold backwardMotion negArea
    apply integral_congr_ae
    filter_upwards [response_output_derivative h] with t ht
    exact congrArg (fun x : ℝ => max (-x) 0) ht

-- Equations (27)--(29), with V and B defined using y', as in the article.
-- @paper-step thm:miace_variation/full_statement
theorem paper_variation {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (α : ℝ) (hα : 0 < α) :
    1 ≤ outputVariation e ∧
    outputVariation e = 1+2*backwardMotion e ∧
    outputVariation e ≤ absArea e halfLine+absArea v halfLine ∧
    absArea e halfLine+absArea v halfLine = 1+2*(negArea e halfLine+negArea v halfLine) ∧
    absArea e halfLine+absArea v halfLine ≤ miace α e v halfLine/minimum α ∧
    peak e (Ici 0) ≤ backwardMotion e ∧
    backwardMotion e ≤ negArea e halfLine+negArea v halfLine ∧
    negArea e halfLine+negArea v halfLine ≤ (miace α e v halfLine/minimum α-1)/2 ∧
    (∀ ε : ℝ, 0 ≤ ε → miace α e v halfLine ≤ (1+ε)*minimum α →
      outputVariation e-1 ≤ ε ∧ backwardMotion e ≤ ε/2 ∧
      peak e (Ici 0) ≤ ε/2 ∧ negArea e halfLine+negArea v halfLine ≤ ε/2) := by
  rw [(actual_variation_eq h).1,(actual_variation_eq h).2]
  have hc := response_variation_chain h α hα
  have hb := area_balance h.error_integrable h.command_integrable 1 (response_signed_balance h)
  refine ⟨hc.1,response_variation_identity h,hc.2.1,hb,hc.2.2,
    response_peak_bound h,response_backward_le_negative_area h,?_,?_⟩
  · linarith [hc.2.2]
  · intro ε _ hm
    exact response_near_optimal h α ε hα hm

-- Proposition 4: supremum is an attained maximum, including the H=0 case.
-- @paper-step prop:finite_miace_shape/full_statement
theorem paper_finite_record {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (α H : ℝ) (hα : 0 < α) (hH : 0 ≤ H) :
    (∃ t ∈ Icc 0 H, peak e (Icc 0 H) = max (-e t) 0) ∧
    peak e (Icc 0 H) ≤
      (miace α e v (volume.restrict (Ioc 0 H))/minimum α-1+|e H|)/2 ∧
    (∀ ε εe : ℝ,
      miace α e v (volume.restrict (Ioc 0 H)) ≤ (1+ε)*minimum α →
      |e H| ≤ εe → peak e (Icc 0 H) ≤ (ε+εe)/2) :=
  ⟨finite_peak_attained h H hH,finite_record_certificate h α H hα hH,
    fun ε εe hm he => finite_record_tolerances h α H ε εe hα hH hm he⟩

end MIACE
