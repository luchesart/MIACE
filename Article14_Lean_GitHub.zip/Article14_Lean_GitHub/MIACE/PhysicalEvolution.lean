import MIACE.ReducedUniqueness

/-! Етап 12: пълната хомогенна физическа система с произволна непрекъсната
    история. Решенията са локално абсолютно непрекъснати; не се изисква
    предварително интегруемост или затихване. Отрицателните аргументи на x
    са само непрекъснато продължение; транспортът използва отделно φ. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Matrix

noncomputable def pidCommand (i ρ ell : ℝ) (x : ℝ → Fin 3 → ℝ) (t : ℝ) : ℝ :=
  pidHomogeneousCommand (i*(1+ell-ρ)) i (i*(ell-ρ)*(1-ρ)) ρ (x t)
noncomputable def pidHistoryForcing (i ρ ell δ : ℝ) (φ : ℝ → Fin 3 → ℝ) : ℝ → ℝ :=
  historyInput δ (pidCommand i ρ ell φ)
noncomputable def spliceHistory (φ x : ℝ → Fin 3 → ℝ) (t : ℝ) : Fin 3 → ℝ :=
  if t<0 then φ t else x t

structure PIDHistoryEvolution (i ρ ell δ : ℝ) (φ x : ℝ → Fin 3 → ℝ) : Prop where
  continuous_state : ∀ k, Continuous (fun t => x t k)
  ac_state : ∀ k T, 0≤T → AbsolutelyContinuousOnInterval (fun t => x t k) 0 T
  initial : x 0=φ 0
  plant : ∀ᵐ t, 0<t → HasDerivAt (fun s => x s 0)
    (-x t 0+pidHistoryForcing i ρ ell δ φ t+causalize (pidCommand i ρ ell x) (t-δ)) t
  integrator : ∀ᵐ t, 0<t → HasDerivAt (fun s => x s 1) (-x t 0) t
  filter : ∀ᵐ t, 0<t → HasDerivAt (fun s => x s 2) ((-x t 0-x t 2)/ρ) t

-- @paper-step thm:pid_two_rate_optimum/full_history_transport_semantics
theorem pid_history_transport (i ρ ell δ : ℝ) (φ x : ℝ → Fin 3 → ℝ)
    {t : ℝ} (ht : 0≤t) :
    pidCommand i ρ ell (spliceHistory φ x) (t-δ)=
      pidHistoryForcing i ρ ell δ φ t+causalize (pidCommand i ρ ell x) (t-δ) := by
  by_cases hs : t<δ
  · have hd : t-δ<0 := by linarith
    simp [pidCommand,spliceHistory,hd,pidHistoryForcing,historyInput,
      show t∈Ico (0 : ℝ) δ from ⟨ht,hs⟩,causalize,not_le.mpr hd]
  · have hd : 0≤t-δ := by linarith
    simp [pidCommand,spliceHistory,not_lt.mpr hd,pidHistoryForcing,historyInput,
      show t∉Ico (0 : ℝ) δ by simp [hs],causalize,hd]

-- @paper-step thm:pid_two_rate_optimum/causal_command_coordinate_identity
theorem pid_causal_reduced_command (i ell : ℝ) {ρ : ℝ} (hρ : ρ≠0)
    (x : ℝ → Fin 3 → ℝ) (t : ℝ) :
    causalize (pidCommand i ρ ell x) t=-(i/ρ)*
      ((ell-ρ)*causalize (fun s => (pidReduce ρ (x s)) 0) t+
        ell*causalize (fun s => (pidReduce ρ (x s)) 1) t) := by
  by_cases ht : 0≤t
  · simp only [causalize,indicator_of_mem (show t∈Ici (0 : ℝ) from ht)]
    exact pid_command_reduced i ell hρ (x t)
  · simp [causalize,ht]

-- @paper-step thm:pid_two_rate_optimum/physical_evolution_reduces
theorem pid_evolution_reduce {i ρ ell δ : ℝ} {φ x : ℝ → Fin 3 → ℝ}
    (hρ : ρ≠0) (h : PIDHistoryEvolution i ρ ell δ φ x) :
    ReducedEvolution i ρ ell δ (pidReduce ρ (φ 0) 0) (pidReduce ρ (φ 0) 1)
      (pidHistoryForcing i ρ ell δ φ)
      (fun t => pidReduce ρ (x t) 0) (fun t => pidReduce ρ (x t) 1) := by
  refine ⟨(h.continuous_state 1).add ((h.continuous_state 2).const_mul _),
    (h.continuous_state 0).sub (h.continuous_state 1),
    (fun T hT => (h.ac_state 1 T hT).add ((h.ac_state 2 T hT).const_mul _)),
    (fun T hT => (h.ac_state 0 T hT).sub (h.ac_state 1 T hT)),
    by rw [h.initial],by rw [h.initial],?_,?_⟩
  · filter_upwards [h.integrator,h.filter] with t hz hζ ht
    convert (hz ht).add ((hζ ht).const_mul (1-ρ)) using 1
    · rfl
    · change -((x t 1+(1-ρ)*x t 2)+(x t 0-x t 1))/ρ=_
      field_simp [hρ]
      <;> ring
  · filter_upwards [h.plant,h.integrator] with t hy hz ht
    have hh := (hy ht).sub (hz ht)
    rw [pid_causal_reduced_command i ell hρ x (t-δ)] at hh
    convert hh using 1
    · rfl
    · ring

-- @paper-step thm:pid_two_rate_optimum/reduced_evolution_restores_physical_states
theorem pid_evolution_restore {i ρ ell δ : ℝ} (hρ : ρ≠0) (hρ1 : ρ≠1)
    (φ : ℝ → Fin 3 → ℝ) {a b : ℝ → ℝ}
    (h : ReducedEvolution i ρ ell δ (pidReduce ρ (φ 0) 0) (pidReduce ρ (φ 0) 1)
      (pidHistoryForcing i ρ ell δ φ) a b) :
    PIDHistoryEvolution i ρ ell δ φ
      (fun t => pidRestore ρ ![a t,b t,pidStableState (φ 0 1) b t]) := by
  let c := pidStableState (φ 0 1) b
  let x := fun t => pidRestore ρ ![a t,b t,c t]
  have hc : Continuous c := (by fun_prop : Continuous (fun t : ℝ => φ 0 1*Real.exp (-t))).sub
    (lag_continuous h.continuous_b 1)
  have hac (T : ℝ) (hT : 0≤T) : AbsolutelyContinuousOnInterval c 0 T := by
    have he : AbsolutelyContinuousOnInterval (fun t : ℝ => φ 0 1*Real.exp (-t)) 0 T := by
      apply ContDiffOn.absolutelyContinuousOnInterval; fun_prop
    exact he.sub (lag_ac h.continuous_b.continuousOn 1 T hT)
  have hdx (t : ℝ) : pidReduce ρ (x t)=![a t,b t,c t] := pidReduce_restore hρ1 _
  have hda : (fun t => pidReduce ρ (x t) 0)=a := by funext t; rw [hdx]; rfl
  have hdb : (fun t => pidReduce ρ (x t) 1)=b := by funext t; rw [hdx]; rfl
  have hcmd (t : ℝ) : causalize (pidCommand i ρ ell x) t=
      -(i/ρ)*((ell-ρ)*causalize a t+ell*causalize b t) := by
    rw [pid_causal_reduced_command i ell hρ x t,hda,hdb]
  have hden : 1-ρ≠0 := sub_ne_zero.mpr hρ1.symm
  change PIDHistoryEvolution i ρ ell δ φ x
  refine ⟨?_,?_,?_,?_,?_,?_⟩
  · intro k
    fin_cases k
    · exact h.continuous_b.add hc
    · exact hc
    · exact (h.continuous_a.sub hc).div_const (1-ρ)
  · intro k T hT
    fin_cases k
    · exact (h.ac_b T hT).add (hac T hT)
    · exact hac T hT
    · change AbsolutelyContinuousOnInterval (fun t => (a t-c t)/(1-ρ)) 0 T
      convert ((h.ac_a T hT).sub (hac T hT)).const_mul (1/(1-ρ)) using 1
      funext t
      simp only [Pi.sub_apply]
      ring
  · change pidRestore ρ ![a 0,b 0,pidStableState (φ 0 1) b 0]=φ 0
    rw [h.initial_a,h.initial_b,pidStableState_initial]
    exact pidRestore_reduce hρ1 (φ 0)
  · filter_upwards [h.ode_b] with t hb ht
    have hh := (hb ht).add (pidStableState_derivative (φ 0 1) h.continuous_b ht)
    rw [hcmd]
    convert hh using 1
    · rfl
    · rw [show x t 0=b t+c t from rfl]
      dsimp only [c]
      ring
  · exact ae_of_all _ (fun t ht => by
      convert pidStableState_derivative (φ 0 1) h.continuous_b ht using 1
      · rfl
      · change -(b t+c t)=-c t-b t
        ring)
  · filter_upwards [h.ode_a] with t ha ht
    have hh := ((ha ht).sub (pidStableState_derivative (φ 0 1) h.continuous_b ht)).div_const (1-ρ)
    convert hh using 1
    · rfl
    · change (-(b t+c t)-(a t-c t)/(1-ρ))/ρ=(-(a t+b t)/ρ-(-c t-b t))/(1-ρ)
      field_simp [hρ,hden]
      <;> ring

end MIACE
