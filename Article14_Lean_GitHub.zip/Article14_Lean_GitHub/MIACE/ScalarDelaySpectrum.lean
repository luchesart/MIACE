import MIACE.ComplexKernel
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds

/-! Scalar characteristic equation used in Lemma 6. These statements concern
actual complex roots; a time-domain stability theorem is a separate step. -/
namespace MIACE
open Set
open scoped Topology

noncomputable def scalarDelayChar (a : ℝ) (z : ℂ) : ℂ :=
  z+(a : ℂ)*Complex.exp (-z)

-- @paper-step lem:delayed_cancellation/scalar_root_modulus
theorem scalarDelay_root_norm {a : ℝ} (ha : 0<a) {z : ℂ}
    (hz : scalarDelayChar a z=0) : ‖z‖=a*Real.exp (-z.re) := by
  have he : z= -(a : ℂ)*Complex.exp (-z) := by
    unfold scalarDelayChar at hz
    linear_combination hz
  conv_lhs => rw [he]
  rw [norm_mul,norm_neg,Complex.norm_real,Real.norm_of_nonneg ha.le,
    Complex.norm_exp,Complex.neg_re]

-- @paper-step lem:delayed_cancellation/no_closed_right_half_plane_root
theorem scalarDelay_root_left {a : ℝ} (ha : 0<a) (hb : a<Real.pi/2)
    {z : ℂ} (hz : scalarDelayChar a z=0) : z.re<0 := by
  by_contra hn
  have hu : 0≤z.re := le_of_not_gt hn
  have hnorm : ‖z‖≤a := by
    rw [scalarDelay_root_norm ha hz]
    exact mul_le_of_le_one_right ha.le (Real.exp_le_one_iff.mpr (by linarith))
  have him : |z.im|<Real.pi/2 := (Complex.abs_im_le_norm z).trans_lt (hnorm.trans_lt hb)
  have hcos : 0<Real.cos z.im := Real.cos_pos_of_mem_Ioo (abs_lt.mp him)
  have hre := congrArg Complex.re hz
  simp [scalarDelayChar,Complex.exp_re,Real.cos_neg] at hre
  nlinarith [mul_pos (mul_pos ha (Real.exp_pos (-z.re))) hcos]

noncomputable def scalarDelayRootReal (v : ℝ) : ℝ :=
  -v*Real.cos v/Real.sin v
noncomputable def scalarDelayRootGain (v : ℝ) : ℝ :=
  v*Real.exp (scalarDelayRootReal v)/Real.sin v

-- @paper-step lem:delayed_cancellation/unstable_root_parametrization
theorem scalarDelay_parametric_root {v : ℝ} (hv : 0<v) (hvπ : v<Real.pi) :
    scalarDelayChar (scalarDelayRootGain v)
      ((scalarDelayRootReal v : ℂ)+(v : ℂ)*Complex.I)=0 := by
  have hs : Real.sin v≠0 := ne_of_gt (Real.sin_pos_of_mem_Ioo ⟨hv,hvπ⟩)
  have he : Real.exp (scalarDelayRootReal v)*Real.exp (-scalarDelayRootReal v)=1 := by
    rw [← Real.exp_add,add_neg_cancel,Real.exp_zero]
  apply Complex.ext <;>
    simp only [scalarDelayChar,Complex.add_re,Complex.add_im,Complex.mul_re,
      Complex.mul_im,Complex.ofReal_re,Complex.ofReal_im,Complex.I_re,Complex.I_im,
      Complex.neg_re,Complex.neg_im,Complex.zero_re,Complex.zero_im,Complex.exp_re,
      Complex.exp_im,Real.cos_neg,Real.sin_neg,mul_zero,zero_mul,mul_one,one_mul,
      sub_zero,zero_sub,add_zero,zero_add,neg_neg]
  all_goals unfold scalarDelayRootGain
  · calc
      _ = scalarDelayRootReal v+v*Real.cos v/Real.sin v := by
        field_simp
        linear_combination v*Real.cos v*he
      _ = 0 := by dsimp [scalarDelayRootReal]; ring
  · field_simp
    nlinarith [he]

-- @paper-step lem:delayed_cancellation/first_imaginary_boundary
theorem scalarDelay_boundary_root :
    scalarDelayChar (Real.pi/2) ((Real.pi/2 : ℝ)*Complex.I)=0 := by
  have h := scalarDelay_parametric_root Real.pi_div_two_pos (by linarith [Real.pi_pos])
  simpa [scalarDelayRootGain,scalarDelayRootReal] using h

-- @paper-step lem:delayed_cancellation/root_parameter_continuity
theorem scalarDelayRootGain_continuous {b : ℝ} (hb : b<Real.pi) :
    ContinuousOn scalarDelayRootGain (Icc (Real.pi/2) b) := by
  have hs : ∀ v∈Icc (Real.pi/2) b, Real.sin v≠0 := by
    intro v hv
    exact ne_of_gt (Real.sin_pos_of_mem_Ioo ⟨lt_of_lt_of_le Real.pi_div_two_pos hv.1,
      hv.2.trans_lt hb⟩)
  unfold scalarDelayRootGain scalarDelayRootReal
  exact (continuousOn_id.mul (Real.continuous_exp.comp_continuousOn
    ((continuousOn_id.neg.mul Real.continuous_cos.continuousOn).div
    Real.continuous_sin.continuousOn hs))).div Real.continuous_sin.continuousOn hs

-- @paper-step lem:delayed_cancellation/root_parameter_unbounded_above
theorem scalarDelayRootGain_large {a : ℝ} (ha : 0<a) :
    ∃ b : ℝ, Real.pi/2<b ∧ b<Real.pi ∧ a<scalarDelayRootGain b := by
  let d := Real.pi/(4*(a+1))
  have hd : 0<d := by dsimp [d]; positivity
  have hda : d*(a+1)=Real.pi/4 := by dsimp [d]; field_simp
  have hdπ : d≤Real.pi/4 := by nlinarith
  let b := Real.pi-d
  have hb : Real.pi/2<b := by dsimp [b]; linarith [Real.pi_pos]
  have hbπ : b<Real.pi := by dsimp [b]; linarith
  have hb0 : 0<b := Real.pi_div_two_pos.trans hb
  have hs : 0<Real.sin b := Real.sin_pos_of_mem_Ioo ⟨hb0,hbπ⟩
  have hsd : Real.sin b≤d := by simpa [b,Real.sin_pi_sub] using Real.sin_le hd.le
  have hu : 0≤scalarDelayRootReal b := by
    unfold scalarDelayRootReal
    exact div_nonneg (mul_nonneg_of_nonpos_of_nonpos (neg_nonpos.mpr hb0.le)
      (Real.cos_nonpos_of_pi_div_two_le_of_le hb.le (by linarith [Real.pi_pos]))) hs.le
  have hu' : 1≤Real.exp (scalarDelayRootReal b) := Real.one_le_exp_iff.mpr hu
  have had : a*d<Real.pi/4 := by nlinarith
  refine ⟨b,hb,hbπ,?_⟩
  apply (lt_div_iff₀ hs).mpr
  have hh := mul_le_mul_of_nonneg_left hsd ha.le
  have hh' := mul_le_mul_of_nonneg_left hu' hb0.le
  nlinarith

-- @paper-step lem:delayed_cancellation/existence_of_nonnegative_real_part_root
theorem scalarDelay_right_root {a : ℝ} (ha : Real.pi/2≤a) :
    ∃ z : ℂ, 0≤z.re ∧ scalarDelayChar a z=0 := by
  obtain ⟨b,hb,hbπ,hba⟩ := scalarDelayRootGain_large (Real.pi_div_two_pos.trans_le ha)
  have hstart : scalarDelayRootGain (Real.pi/2)=Real.pi/2 := by
    simp [scalarDelayRootGain,scalarDelayRootReal]
  obtain ⟨v,hv,hva⟩ := intermediate_value_Icc hb.le
    (scalarDelayRootGain_continuous hbπ) (show a∈Icc (scalarDelayRootGain (Real.pi/2))
      (scalarDelayRootGain b) by rw [hstart]; exact ⟨ha,hba.le⟩)
  have hv0 : 0<v := Real.pi_div_two_pos.trans_le hv.1
  have hvπ : v<Real.pi := hv.2.trans_lt hbπ
  refine ⟨(scalarDelayRootReal v : ℂ)+(v : ℂ)*Complex.I,?_,?_⟩
  · simp only [Complex.add_re,Complex.ofReal_re,Complex.mul_re,Complex.I_re,
      Complex.I_im,Complex.ofReal_im,mul_zero,zero_mul,sub_self,add_zero]
    exact div_nonneg (mul_nonneg_of_nonpos_of_nonpos (neg_nonpos.mpr hv0.le)
      (Real.cos_nonpos_of_pi_div_two_le_of_le hv.1 (by linarith [Real.pi_pos])))
      (Real.sin_pos_of_mem_Ioo ⟨hv0,hvπ⟩).le
  · rw [← hva]
    exact scalarDelay_parametric_root hv0 hvπ

-- @paper-step lem:delayed_cancellation/exact_scalar_spectral_threshold
theorem scalarDelay_spectral_iff {a : ℝ} (ha : 0<a) :
    (∀ z : ℂ, scalarDelayChar a z=0 → z.re<0) ↔ a<Real.pi/2 := by
  constructor
  · intro h
    by_contra hn
    obtain ⟨z,hz,hroot⟩ := scalarDelay_right_root (le_of_not_gt hn)
    exact (not_lt_of_ge hz) (h z hroot)
  · intro h z hz
    exact scalarDelay_root_left ha h hz

-- @paper-step lem:delayed_cancellation/uniform_strict_spectral_gap
theorem scalarDelay_spectral_gap {a : ℝ} (ha : 0<a) (hb : a<Real.pi/2) :
    ∃ η : ℝ, 0<η ∧ ∀ z : ℂ, scalarDelayChar a z=0 → z.re< -η := by
  let S := Metric.closedBall (0 : ℂ) (a*Real.exp 1) ∩ {z | scalarDelayChar a z=0}
  have hc : Continuous (scalarDelayChar a) := by unfold scalarDelayChar; fun_prop
  have hball : IsCompact (Metric.closedBall (0 : ℂ) (a*Real.exp 1)) := isCompact_closedBall _ _
  have hS : IsCompact S := hball.inter_right (isClosed_eq hc continuous_const)
  have hmem (z : ℂ) (hz : scalarDelayChar a z=0) (hr : -1≤z.re) : z∈S := by
    refine ⟨?_,hz⟩
    rw [Metric.mem_closedBall,dist_zero_right,scalarDelay_root_norm ha hz]
    exact mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr (by linarith)) ha.le
  by_cases hne : S.Nonempty
  · obtain ⟨w,hw,hmax⟩ := hS.exists_isMaxOn hne Complex.continuous_re.continuousOn
    have hw0 : w.re<0 := scalarDelay_root_left ha hb hw.2
    let η := min 1 (-w.re)/2
    have hη : 0<η := half_pos (lt_min (by norm_num) (by linarith))
    have hη1 : η≤1/2 := div_le_div_of_nonneg_right (min_le_left _ _) (by norm_num)
    have hηw : η≤(-w.re)/2 := div_le_div_of_nonneg_right (min_le_right _ _) (by norm_num)
    refine ⟨η,hη,?_⟩
    intro z hz
    by_cases hr : -1≤z.re
    · have hh := hmax (hmem z hz hr)
      change z.re≤w.re at hh
      linarith
    · linarith
  · refine ⟨1,by norm_num,?_⟩
    intro z hz
    by_contra hn
    exact hne ⟨z,hmem z hz (by linarith)⟩

end MIACE
