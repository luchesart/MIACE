import MIACE.Areas
import Mathlib.MeasureTheory.Integral.IntervalIntegral.AbsolutelyContinuousFun
import Mathlib.MeasureTheory.Integral.IntegralEqImproper

/-! The analytic bridge from the actual first-order ODE to the area balance.
Absolute continuity, integrability, endpoint and limit assumptions are exactly
explicit. The global signed balance is a conclusion, not a structure field. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable abbrev halfLine : Measure ℝ := volume.restrict (Ioi (0 : ℝ))

structure FirstOrderResponse (e v : ℝ → ℝ) : Prop where
  ac : ∀ h : ℝ, 0 ≤ h → AbsolutelyContinuousOnInterval e 0 h
  ode : ∀ᵐ t : ℝ, 0 < t → deriv e t = -(e t + v t)
  initial : e 0 = 1
  finalValue : Tendsto e atTop (𝓝 0)
  error_integrable : Integrable e halfLine
  command_integrable : Integrable v halfLine

-- @paper-step thm:miace_shape_gap/ac_restriction
 theorem response_ac_between {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    {a b : ℝ} (ha : 0 ≤ a) (hab : a ≤ b) : AbsolutelyContinuousOnInterval e a b := by
  apply (h.ac b (ha.trans hab)).mono
  rw [uIcc_of_le hab, uIcc_of_le (ha.trans hab)]
  exact fun _ hx => ⟨ha.trans hx.1, hx.2⟩

-- @paper-step thm:miace_shape_gap/finite_ode_balance
 theorem response_increment {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    {a b : ℝ} (ha : 0 ≤ a) (hab : a ≤ b) :
    (∫ t in a..b, e t + v t) = e a - e b := by
  have hFTC := (response_ac_between h ha hab).integral_deriv_eq_sub
  have heq : (∫ t in a..b, deriv e t) = ∫ t in a..b, -(e t + v t) := by
    apply intervalIntegral.integral_congr_ae
    filter_upwards [h.ode] with t ht htmem
    rw [uIoc_of_le hab] at htmem
    exact ht (lt_of_le_of_lt ha htmem.1)
  rw [heq, intervalIntegral.integral_neg] at hFTC
  linarith

-- @paper-step thm:miace_shape_gap/ode_balance
 theorem response_signed_balance {e v : ℝ → ℝ} (h : FirstOrderResponse e v) :
    (∫ t, e t ∂halfLine) + (∫ t, v t ∂halfLine) = 1 := by
  have hlim := intervalIntegral_tendsto_integral_Ioi 0
    (h.error_integrable.add h.command_integrable) tendsto_id
  have heq : (fun b : ℝ => ∫ t in 0..b, e t + v t) =ᶠ[atTop]
      (fun b => 1 - e b) := by
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with b hb
    rw [response_increment h le_rfl hb, h.initial]
  have hlim2 : Tendsto (fun b : ℝ => 1 - e b) atTop (𝓝 1) := by
    simpa using tendsto_const_nhds.sub h.finalValue
  have hi := tendsto_nhds_unique hlim (hlim2.congr' heq.symm)
  change (∫ t, (e+v) t ∂halfLine) = 1 at hi
  simp only [Pi.add_apply, integral_add h.error_integrable h.command_integrable] at hi
  exact hi

-- @paper-step thm:miace_shape_gap/ode_excess
 theorem response_excess {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (α : ℝ) (hα : 0 < α) :
    costSq α (absArea e halfLine) (absArea v halfLine) - baseSq α 1 =
      4*α/(1+α) * (negArea e halfLine + negArea v halfLine) *
        (1 + (negArea e halfLine + negArea v halfLine)) +
      (absArea e halfLine - α * absArea v halfLine)^2/(1+α) :=
  signal_excess h.error_integrable h.command_integrable α 1 hα (response_signed_balance h)

-- @paper-step thm:miace_shape_gap/ode_equality
 theorem response_equality_iff {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (α : ℝ) (hα : 0 < α) :
    costSq α (absArea e halfLine) (absArea v halfLine) = baseSq α 1 ↔
      (∀ᵐ t ∂halfLine, 0 ≤ e t) ∧ (∀ᵐ t ∂halfLine, 0 ≤ v t) ∧
      absArea e halfLine = α * absArea v halfLine :=
  signal_equality_iff h.error_integrable h.command_integrable α 1 hα (by norm_num)
    (response_signed_balance h)

-- @paper-step thm:miace_shape_gap/output_monotone
 theorem response_output_monotone {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (he : ∀ᵐ t ∂halfLine, 0 ≤ e t) (hv : ∀ᵐ t ∂halfLine, 0 ≤ v t) :
    MonotoneOn (fun t => 1-e t) (Ici 0) := by
  intro a ha b hb hab
  have hn : 0 ≤ ∫ t in a..b, e t + v t := by
    rw [intervalIntegral.integral_of_le hab]
    apply integral_nonneg_of_ae
    have hsub : Ioc a b ⊆ Ioi (0 : ℝ) := fun t ht => lt_of_le_of_lt ha ht.1
    filter_upwards [ae_restrict_of_ae_restrict_of_subset hsub he,
      ae_restrict_of_ae_restrict_of_subset hsub hv] with t ht hu
    exact add_nonneg ht hu
  rw [response_increment h ha hab] at hn
  linarith

-- @paper-step thm:miace_shape_gap/no_overshoot
 theorem response_output_bounds {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (he : ∀ᵐ t ∂halfLine, 0 ≤ e t) (hv : ∀ᵐ t ∂halfLine, 0 ≤ v t)
    {t : ℝ} (ht : 0 ≤ t) : 0 ≤ 1-e t ∧ 1-e t ≤ 1 := by
  have hm := response_output_monotone h he hv
  constructor
  · have hz := hm (by simp) ht ht
    change 1-e 0 ≤ 1-e t at hz
    rw [h.initial] at hz
    linarith
  · have hlim : Tendsto (fun b : ℝ => 1-e b) atTop (𝓝 1) := by
      simpa using tendsto_const_nhds.sub h.finalValue
    apply ge_of_tendsto hlim
    filter_upwards [eventually_ge_atTop t] with b hb
    exact hm ht (ht.trans hb) hb

-- @paper-step thm:miace_variation/actual_output_derivative
 theorem response_output_derivative {e v : ℝ → ℝ} (h : FirstOrderResponse e v) :
    deriv (fun t => 1-e t) =ᵐ[halfLine] (fun t => e t+v t) := by
  apply (ae_restrict_iff' measurableSet_Ioi).2
  filter_upwards [h.ode] with t ht htpos
  rw [deriv_const_sub, ht htpos, neg_neg]

-- @paper-step thm:miace_variation/net_motion
 theorem response_variation_identity {e v : ℝ → ℝ} (h : FirstOrderResponse e v) :
    absArea (fun t => e t+v t) halfLine = 1 + 2 * negArea (fun t => e t+v t) halfLine := by
  change absArea (e+v) halfLine = 1 + 2 * negArea (e+v) halfLine
  rw [absolute_area_identity (h.error_integrable.add h.command_integrable)]
  simp only [Pi.add_apply, integral_add h.error_integrable h.command_integrable, response_signed_balance h]

-- @paper-step thm:miace_variation/backward_area
 theorem response_backward_le_negative_area {e v : ℝ → ℝ} (h : FirstOrderResponse e v) :
    negArea (fun t => e t+v t) halfLine ≤ negArea e halfLine + negArea v halfLine := by
  have htri := absolute_area_add_le h.error_integrable h.command_integrable
  have hvar := response_variation_identity h
  have hbal := area_balance h.error_integrable h.command_integrable 1 (response_signed_balance h)
  linarith

end MIACE
