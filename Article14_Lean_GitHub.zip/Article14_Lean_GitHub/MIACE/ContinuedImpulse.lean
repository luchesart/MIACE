import MIACE.HermiteUniqueness
import MIACE.StateTransforms

/-! The remainder kernel is tied to the ordinary cascade impulse, rather
than an arbitrary positive function. The all-real integrating-factor
recurrence defines its continuation before time zero. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def continuedImpulse (r : ℕ → ℝ) (n : ℕ) (t : ℝ) : ℝ :=
  (-1 : ℝ)^n*reverseImpulse r n (-t)

-- @paper-step lem:n_remainder/continued_impulse_continuity
theorem continuedImpulse_continuous (r : ℕ → ℝ) (n : ℕ) :
    Continuous (continuedImpulse r n) :=
  ((reverseImpulse_continuous r n).comp continuous_neg).const_mul _

-- @paper-step lem:n_remainder/continued_impulse_actual_lag_ode
theorem continuedImpulse_deriv (r : ℕ → ℝ) (n : ℕ) (t : ℝ) :
    HasDerivAt (continuedImpulse r (n+1))
      (r (n+1)*(continuedImpulse r n t-continuedImpulse r (n+1) t)) t := by
  have hd := ((reverseImpulse_deriv r n (-t)).comp t (hasDerivAt_id t).neg).const_mul ((-1 : ℝ)^(n+1))
  convert hd using 1
  · rfl
  · simp only [continuedImpulse,pow_succ,id_eq]
    ring

-- @paper-step lem:n_remainder/global_lag_integrating_factor
theorem global_lag_formula {u x : ℝ → ℝ} (hu : Continuous u) (hx : Continuous x)
    (r : ℝ) (hr : r≠0) (hx0 : x 0=0)
    (hd : ∀ t, HasDerivAt x (r*(u t-x t)) t) (t : ℝ) : x t=lag (1/r) u t := by
  have hp : ∀ t, HasDerivAt (fun s => Real.exp (r*s)*x s) (r*(Real.exp (r*t)*u t)) t := by
    intro s
    convert (((hasDerivAt_id s).const_mul r).exp).mul (hd s) using 1
    · rfl
    · dsimp; ring
  have he := intervalIntegral.integral_eq_sub_of_hasDerivAt (fun s _ => hp s)
    (a := 0) (b := t)
    (by apply Continuous.intervalIntegrable; exact
      (((by fun_prop : Continuous (fun s : ℝ => Real.exp (r*s))).mul hu).const_mul r))
  rw [intervalIntegral.integral_const_mul] at he
  simp only [hx0,mul_zero,sub_zero] at he
  have he' := congrArg (fun z => Real.exp (-r*t)*z) he
  have hc : Real.exp (-r*t)*Real.exp (r*t)=1 := by rw [← Real.exp_add]; ring_nf; simp
  simp only [← mul_assoc,hc,one_mul] at he'
  rw [← he']
  simp only [lag,one_div,div_inv_eq_mul,neg_mul,mul_comm,mul_left_comm]
  rw [show t * -r = r * -t by ring]


-- @paper-step lem:n_remainder/continued_impulse_is_recursive_cascade
theorem continuedImpulse_lag (r : ℕ → ℝ) (n : ℕ) (hr : r (n+1)≠0) :
    continuedImpulse r (n+1)=lag (1/r (n+1)) (continuedImpulse r n) := by
  funext t
  apply global_lag_formula (continuedImpulse_continuous r n)
    (continuedImpulse_continuous r (n+1)) _ hr
    (by simp [continuedImpulse,reverseImpulse]) (continuedImpulse_deriv r n)

-- @paper-step lem:n_remainder/continued_impulse_first_factor
theorem continuedImpulse_first (r : ℕ → ℝ) (t : ℝ) :
    continuedImpulse r 0 t=r 0*Real.exp (-r 0*t) := by
  simp only [continuedImpulse,pow_zero,one_mul,reverseImpulse]
  congr 2; ring

-- @paper-step lem:n_remainder/continued_impulse_integrability
theorem continuedImpulse_integrable (r : ℕ → ℝ) (n : ℕ) (hr : ∀ j≤n, 0<r j) :
    Integrable (continuedImpulse r n) halfLine := by
  induction n with
  | zero =>
    change Integrable (fun t => continuedImpulse r 0 t) halfLine
    simp_rw [continuedImpulse_first]
    exact (integrableOn_exp_mul_Ioi (neg_neg_of_pos (hr 0 le_rfl)) 0).const_mul _
  | succ n ih =>
    rw [continuedImpulse_lag r n (ne_of_gt (hr (n+1) le_rfl))]
    exact lag_integrable (ih (fun j hj => hr j (by omega))) (one_div_pos.mpr (hr (n+1) le_rfl))

-- @paper-step lem:n_remainder/actual_impulse_transfer_one_over_B
theorem continuedImpulse_laplace (r : ℕ → ℝ) (n : ℕ) (hr : ∀ j≤n, 0<r j)
    {p : ℝ} (hp : 0≤p) : laplace (continuedImpulse r n) p=1/(remainderB r n).eval p := by
  induction n with
  | zero =>
    have hden : 0<p+r 0 := by linarith [hr 0 le_rfl]
    have he : (fun t => Real.exp (-p*t)*continuedImpulse r 0 t)=
        (fun t => r 0*Real.exp (-(p+r 0)*t)) := by
      funext t
      rw [continuedImpulse_first]
      rw [show -(p+r 0)*t=(-p*t)+(-r 0*t) by ring,Real.exp_add]
      ring
    unfold laplace
    rw [he,integral_const_mul]
    change r 0*(∫ t in Ioi (0 : ℝ), Real.exp (-(p+r 0)*t))=_
    rw [integral_exp_mul_Ioi (neg_neg_of_pos hden)]
    simp only [mul_zero,Real.exp_zero,remainderB,Polynomial.eval_add,Polynomial.eval_mul,
      Polynomial.eval_C,Polynomial.eval_X,Polynomial.eval_one]
    field_simp [ne_of_gt (hr 0 le_rfl),ne_of_gt hden]
    <;> ring
  | succ n ih =>
    have hrn : ∀ j≤n, 0<r j := fun j hj => hr j (by omega)
    rw [continuedImpulse_lag r n (ne_of_gt (hr (n+1) le_rfl)),
      lag_laplace (continuedImpulse_integrable r n hrn) (one_div_pos.mpr (hr (n+1) le_rfl)) hp,
      ih hrn,remainderB,Polynomial.eval_mul,Polynomial.eval_add,Polynomial.eval_mul,
      Polynomial.eval_C,Polynomial.eval_X,Polynomial.eval_one]
    simp only [one_div,div_eq_mul_inv,mul_inv_rev,add_comm,mul_comm,one_mul,mul_one]

-- @paper-step lem:n_remainder/kernel_is_signed_shift_of_actual_continuation
theorem remainderJ_impulse (r : ℕ → ℝ) (n : ℕ) (δ t : ℝ) :
    remainderJ r n δ t=(-1 : ℝ)^n*continuedImpulse r n (t-δ) := by
  simp only [remainderJ,continuedImpulse,neg_sub,← mul_assoc,← pow_add]
  rw [show n+n=2*n by omega,pow_mul]
  norm_num

end MIACE
