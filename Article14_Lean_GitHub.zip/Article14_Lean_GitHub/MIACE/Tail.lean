import MIACE.Lag

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- Fatou establishes finiteness as well as the inequality. The target's
-- integrability is a conclusion, so a divergent total Bochner integral cannot
-- masquerade as a zero moment.
-- @paper-step thm:n_necessary/fatou_integrability_and_bound
theorem fatou_moment_bound {G : ℕ → ℝ → ℝ} {v : ℝ → ℝ}
    (hG : ∀ n, Integrable (G n) halfLine)
    (hGn : ∀ n, ∀ᵐ t ∂halfLine, 0 ≤ G n t)
    (hGi : ∀ n, (∫ t, G n t ∂halfLine) ≤ 1)
    (hv : ∀ᵐ t ∂halfLine, 0 ≤ v t)
    (hlim : ∀ᵐ t ∂halfLine, Tendsto (fun n => G n t) atTop (𝓝 (Real.exp t*v t))) :
    Integrable (fun t => Real.exp t*v t) halfLine ∧ moment v ≤ 1 := by
  have hnint : ∀ n, (∫ t, ‖G n t‖ ∂halfLine) ≤ 1 := by
    intro n
    have heq : (fun t => ‖G n t‖) =ᵐ[halfLine] G n := by
      filter_upwards [hGn n] with t ht
      exact Real.norm_of_nonneg ht
    rw [integral_congr_ae heq]
    exact hGi n
  have hE : ∀ n, (∫⁻ t, ‖G n t‖ₑ ∂halfLine) ≤ 1 := by
    intro n
    rw [← ofReal_integral_norm_eq_lintegral_enorm (hG n)]
    simpa using ENNReal.ofReal_le_ofReal (hnint n)
  have hL : liminf (fun n => ∫⁻ t, ‖G n t‖ₑ ∂halfLine) atTop ≤ 1 :=
    liminf_le_of_frequently_le (Eventually.of_forall hE).frequently
  have hJ := integrable_of_tendsto hlim (fun n => (hG n).aestronglyMeasurable)
    (ne_top_of_le_ne_top ENNReal.one_ne_top hL)
  refine ⟨hJ,?_⟩
  have hf := lintegral_enorm_le_liminf_of_tendsto hlim
    (fun n => (hG n).aestronglyMeasurable.aemeasurable.enorm)
  have hb := ENNReal.toReal_mono ENNReal.one_ne_top (hf.trans hL)
  have heq : (fun t => ‖Real.exp t*v t‖) =ᵐ[halfLine] (fun t => Real.exp t*v t) := by
    filter_upwards [hv] with t ht
    exact Real.norm_of_nonneg (mul_nonneg (Real.exp_nonneg _) ht)
  rw [← integral_norm_eq_lintegral_enorm hJ.aestronglyMeasurable,integral_congr_ae heq] at hb
  simpa [moment] using hb

-- The exact Fatou step used for the normalized impulse-response tails.
-- The remaining cascade-specific input is the repeated-pole tail asymptotic.
-- @paper-step thm:n_necessary/tail_fatou
theorem tail_ratio_moment_bound {K v : ℝ → ℝ} {T : ℕ → ℝ}
    (hT : ∀ n, 0 < T n)
    (hK : ∀ n : ℕ, ∀ᵐ t ∂halfLine, 0 ≤ K ((n : ℝ)-t))
    (hv : ∀ᵐ t ∂halfLine, 0 ≤ v t)
    (hG : ∀ n : ℕ, Integrable (fun t => K ((n : ℝ)-t)/T n*v t) halfLine)
    (hbound : ∀ n : ℕ, (∫ t, K ((n : ℝ)-t)/T n*v t ∂halfLine) ≤ 1)
    (hratio : ∀ᵐ t ∂halfLine,
      Tendsto (fun n : ℕ => K ((n : ℝ)-t)/T n) atTop (𝓝 (Real.exp t))) :
    Integrable (fun t => Real.exp t*v t) halfLine ∧ moment v ≤ 1 := by
  refine fatou_moment_bound hG ?_ hbound hv ?_
  · intro n
    filter_upwards [hK n,hv] with t hkt hvt
    exact mul_nonneg (div_nonneg hkt (hT n).le) hvt
  · filter_upwards [hratio] with t ht
    exact ht.mul_const (v t)

end MIACE
