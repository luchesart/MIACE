import MIACE.ExponentialBox

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

noncomputable def explicitR (i ρ ell l δ : ℝ) (t : ℝ) : ℝ :=
  i*(explicitJ ρ ell l t+explicitA ρ ell l*(expKernel l ⋆ compactKernel (fun _ => 1) δ) t+
    explicitB ρ ell l*(expKernel (1/ρ) ⋆ compactKernel (fun _ => 1) δ) t)-expKernel l t

-- @paper-step thm:pid_explicit_family/simplified_partial_fraction_coefficients
theorem explicitPID_scaled_coefficients {i ρ ell l δ : ℝ} (h : ExplicitPIDData i ρ ell l δ) :
    i*explicitA ρ ell l=(i-l*ρ)/(1-l*ρ) ∧
      i*explicitB ρ ell l=ρ/(1-l*ρ) := by
  obtain ⟨hr,_,_,_,hden⟩ := explicitPID_order h
  have hi := h.gain_pos
  constructor
  · rw [explicitA,h.lead_eq]
    field_simp
    <;> ring
  · rw [explicitB,h.lead_eq]
    field_simp
    rw [← h.filter_eq]

-- @paper-step thm:pid_explicit_family/command_forcing_integrability
theorem explicitR_integrable {i ρ ell l δ : ℝ} (h : ExplicitPIDData i ρ ell l δ) :
    Integrable (explicitR i ρ ell l δ) := by
  have hbox := compactKernel_integrable (J:=fun _ => (1 : ℝ)) continuous_const δ
  have hg := expKernel_integrable h.rate_pos
  have hh := expKernel_integrable (one_div_pos.mpr (explicitPID_order h).1)
  exact (((explicitJ_integrable (explicitPID_order h).1 ell h.rate_pos).add
    ((hg.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hbox).const_mul _)).add
    ((hh.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hbox).const_mul _)).const_mul i |>.sub hg

-- @paper-step thm:pid_explicit_family/command_forcing_causality
theorem explicitR_causal (i ρ ell l δ : ℝ) : Causal (explicitR i ρ ell l δ) := by
  have hc1 : Causal (expKernel l ⋆ compactKernel (fun _ => 1) δ) :=
    ae_of_all _ (convolution_causal (causalize_causal _) (compactKernel_causal _ δ))
  have hc2 : Causal (expKernel (1/ρ) ⋆ compactKernel (fun _ => 1) δ) :=
    ae_of_all _ (convolution_causal (causalize_causal _) (compactKernel_causal _ δ))
  have hc := causal_linear (causal_linear (explicitJ_causal ρ ell l) hc1 1 (explicitA ρ ell l))
    hc2 1 (explicitB ρ ell l)
  have hh := causal_linear hc (causalize_causal (fun t => Real.exp (-l*t))) i (-1)
  change Causal (fun t => i*(explicitJ ρ ell l t+explicitA ρ ell l*_
    +explicitB ρ ell l*_)-expKernel l t)
  simpa only [one_mul,neg_one_mul,expKernel,sub_eq_add_neg] using hh

-- @paper-step thm:pid_explicit_family/initial_command_forcing_formula
theorem explicitR_initial {i ρ ell l δ t : ℝ} (h : ExplicitPIDData i ρ ell l δ)
    (ht : 0≤t) (htd : t≤δ) :
    explicitR i ρ ell l δ t=i/(l*(1-l*ρ))*
      (1-l*ρ-Real.exp (-l*t)+l*ρ*Real.exp (-(1/ρ)*t)) := by
  obtain ⟨hr,_,_,_,hden⟩ := explicitPID_order h
  have hl := h.rate_pos
  obtain ⟨ha,hb⟩ := explicitPID_scaled_coefficients h
  have hid : i+ρ=1 := by rw [h.filter_eq]; ring
  unfold explicitR
  rw [exp_delay_box_convolution h.delay_pos.le ht hl,
    exp_delay_box_convolution h.delay_pos.le ht (one_div_pos.mpr hr)]
  simp only [explicitJ,min_eq_left htd,
    sub_self,mul_zero,Real.exp_zero,expKernel,causalize,
    indicator_of_mem (show t∈Ici (0 : ℝ) from ht)]
  have he : i*(explicitA ρ ell l*Real.exp (-l*t)+explicitB ρ ell l*Real.exp (-(1/ρ)*t)+
      explicitA ρ ell l*((1-Real.exp (-l*t))/l)+
      explicitB ρ ell l*((1-Real.exp (-(1/ρ)*t))/(1/ρ)))=
      (i*explicitA ρ ell l)*(Real.exp (-l*t)+(1-Real.exp (-l*t))/l)+
      (i*explicitB ρ ell l)*(Real.exp (-(1/ρ)*t)+ρ*(1-Real.exp (-(1/ρ)*t))) := by
    field_simp
    <;> ring
  rw [he,ha,hb]
  have hiEq : i=1-ρ := by linarith
  rw [hiEq]
  have hdn : 1-ρ*l≠0 := by nlinarith
  field_simp [ne_of_gt hden,hdn]
  <;> ring

-- @paper-step thm:pid_explicit_family/initial_command_forcing_is_nonnegative
theorem explicitR_initial_nonneg {i ρ ell l δ t : ℝ} (h : ExplicitPIDData i ρ ell l δ)
    (ht : 0≤t) (htd : t≤δ) : 0≤explicitR i ρ ell l δ t := by
  obtain ⟨hr,_,_,_,hden⟩ := explicitPID_order h
  have hl := h.rate_pos
  have hord : l≤1/ρ := by apply (le_div_iff₀ hr).mpr; nlinarith
  have hint := intervalIntegral.integral_mono_on ht
    ((by fun_prop : Continuous (fun s : ℝ => Real.exp (-(1/ρ)*s))).intervalIntegrable (μ:=volume) 0 t)
    ((by fun_prop : Continuous (fun s : ℝ => Real.exp (-l*s))).intervalIntegrable (μ:=volume) 0 t)
    (fun s hs => Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_right (neg_le_neg hord) hs.1))
  rw [finite_exp_integral (ne_of_gt (one_div_pos.mpr hr)),finite_exp_integral (ne_of_gt hl)] at hint
  have hmul := mul_le_mul_of_nonneg_right hint hl.le
  have he : ((1-Real.exp (-l*t))/l)*l=1-Real.exp (-l*t) := by field_simp
  rw [he] at hmul
  rw [explicitR_initial h ht htd]
  apply mul_nonneg (div_nonneg h.gain_pos.le (mul_pos hl hden).le)
  simp only [div_div_eq_mul_div,mul_one,div_one] at hmul
  nlinarith only [hmul]

-- @paper-step thm:pid_explicit_family/tail_coefficient_is_nonnegative
theorem explicitR_tail_coefficient {i ρ ell l δ : ℝ} (h : ExplicitPIDData i ρ ell l δ) :
    0≤ i*explicitA ρ ell l*(1+(Real.exp 1-1)/l)-1 := by
  obtain ⟨hr,_,_,_,hden⟩ := explicitPID_order h
  have hl := h.rate_pos
  have hc : i*explicitA ρ ell l*(1+(Real.exp 1-1)/l)-1=
      (i*(Real.exp 1-1)-l*Real.exp 1*(1-i))/(l*(1-l*ρ)) := by
    rw [(explicitPID_scaled_coefficients h).1]
    have hiEq : i=1-ρ := by linarith [h.filter_eq]
    rw [hiEq]
    have hdn : 1-ρ*l≠0 := by nlinarith
    field_simp [ne_of_gt hden,hdn]
    <;> ring
  rw [hc]
  exact div_nonneg (sub_nonneg.mpr h.command_tail) (mul_pos hl hden).le

-- @paper-step thm:pid_explicit_family/tail_command_forcing_formula
theorem explicitR_tail {i ρ ell l δ t : ℝ} (h : ExplicitPIDData i ρ ell l δ)
    (htd : δ≤t) :
    explicitR i ρ ell l δ t=
      (i*explicitA ρ ell l*(1+(Real.exp 1-1)/l)-1)*Real.exp (-l*t)+
      i*explicitB ρ ell l*(1+ρ*(Real.exp (δ/ρ)-1))*Real.exp (-(1/ρ)*t) := by
  have ht : 0≤t := h.delay_pos.le.trans htd
  have hr := (explicitPID_order h).1
  have hl := h.rate_pos
  have he1 : Real.exp (-l*(t-δ))=Real.exp 1*Real.exp (-l*t) := by
    rw [← Real.exp_add]; congr 1; nlinarith [h.rate_delay]
  have he2 : Real.exp (-(1/ρ)*(t-δ))=Real.exp (δ/ρ)*Real.exp (-(1/ρ)*t) := by
    rw [← Real.exp_add]; congr 1; ring
  unfold explicitR
  rw [exp_delay_box_convolution h.delay_pos.le ht hl,
    exp_delay_box_convolution h.delay_pos.le ht (one_div_pos.mpr hr)]
  simp only [explicitJ,min_eq_right htd,
    expKernel,causalize,indicator_of_mem (show t∈Ici (0 : ℝ) from ht)]
  rw [he1,he2]
  field_simp
  <;> ring

-- @paper-step thm:pid_explicit_family/command_forcing_nonnegative_on_the_whole_halfline
theorem explicitR_nonneg {i ρ ell l δ : ℝ} (h : ExplicitPIDData i ρ ell l δ) (t : ℝ) :
    0≤explicitR i ρ ell l δ t := by
  by_cases ht : 0≤t
  · by_cases htd : t≤δ
    · exact explicitR_initial_nonneg h ht htd
    · rw [explicitR_tail h (le_of_not_ge htd)]
      have hr := (explicitPID_order h).1
      have hB := (explicitPID_coefficients h).2.1
      have he : 1≤Real.exp (δ/ρ) := Real.one_le_exp_iff.mpr (div_nonneg h.delay_pos.le hr.le)
      exact add_nonneg (mul_nonneg (explicitR_tail_coefficient h) (Real.exp_nonneg _))
        (mul_nonneg (mul_nonneg (mul_nonneg h.gain_pos.le hB.le)
          (by nlinarith : 0≤1+ρ*(Real.exp (δ/ρ)-1))) (Real.exp_nonneg _))
  · have hn := lt_of_not_ge ht
    have hz1 := convolution_causal (causalize_causal (fun s => Real.exp (-l*s)))
      (compactKernel_causal (fun _ => 1) δ) t hn
    have hz2 := convolution_causal (causalize_causal (fun s => Real.exp (-(1/ρ)*s)))
      (compactKernel_causal (fun _ => 1) δ) t hn
    change (expKernel l ⋆ compactKernel (fun _ => 1) δ) t=0 at hz1
    change (expKernel (1/ρ) ⋆ compactKernel (fun _ => 1) δ) t=0 at hz2
    rw [explicitR,hz1,hz2]
    simp [explicitJ,expKernel,causalize,ht]

end MIACE
