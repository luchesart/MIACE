import MIACE.ScalarLyapunovWindows

/-! Method of steps with arbitrary continuous initial history. Each finite
iterate agrees with every later iterate on a growing interval, so the
construction introduces no integrability or decay assumption at infinity. -/
namespace MIACE
open MeasureTheory Set Filter
open scoped Topology

noncomputable def delayHistoryStep (h : ℝ) (φ f : ℝ → ℝ) (t : ℝ) : ℝ :=
  φ (min t 0)-∫ s in (0 : ℝ)..max t 0, f (s-h)

noncomputable def delayHistoryIterate (h : ℝ) (φ : ℝ → ℝ) : ℕ → ℝ → ℝ
  | 0 => fun t => φ (min t 0)
  | n+1 => delayHistoryStep h φ (delayHistoryIterate h φ n)

-- @paper-step lem:delayed_cancellation/method_of_steps_continuous_iterates
theorem delayHistoryIterate_continuous {φ : ℝ → ℝ} (hφ : Continuous φ)
    (h : ℝ) (n : ℕ) : Continuous (delayHistoryIterate h φ n) := by
  induction n with
  | zero => exact hφ.comp (continuous_id.min continuous_const)
  | succ n ih =>
    have hc : Continuous (fun s => delayHistoryIterate h φ n (s-h)) :=
      ih.comp (continuous_id.sub continuous_const)
    have hp : Continuous (fun t => ∫ s in (0 : ℝ)..t, delayHistoryIterate h φ n (s-h)) :=
      intervalIntegral.continuous_primitive (fun a b => hc.intervalIntegrable a b) 0
    exact (hφ.comp (continuous_id.min continuous_const)).sub
      (hp.comp (continuous_id.max continuous_const))

-- @paper-step lem:delayed_cancellation/method_of_steps_preserves_entire_past
theorem delayHistoryIterate_past (h : ℝ) (φ : ℝ → ℝ) (n : ℕ)
    {t : ℝ} (ht : t≤0) : delayHistoryIterate h φ n t=φ t := by
  cases n <;> simp [delayHistoryIterate,delayHistoryStep,min_eq_left ht,max_eq_right ht]

-- @paper-step lem:delayed_cancellation/method_of_steps_local_stabilization
theorem delayHistoryIterate_stable {h : ℝ} (hh : 0≤h) (φ : ℝ → ℝ)
    (n : ℕ) {t : ℝ} (ht : t≤n*h) :
    delayHistoryIterate h φ (n+1) t=delayHistoryIterate h φ n t := by
  induction n generalizing t with
  | zero =>
    have ht0 : t≤0 := by simpa using ht
    rw [delayHistoryIterate_past h φ 1 ht0,delayHistoryIterate_past h φ 0 ht0]
  | succ n ih =>
    by_cases ht0 : t≤0
    · rw [delayHistoryIterate_past h φ (n+1+1) ht0,delayHistoryIterate_past h φ (n+1) ht0]
    have ht0 : 0≤t := le_of_lt (lt_of_not_ge ht0)
    change φ (min t 0)-(∫ s in (0 : ℝ)..max t 0, delayHistoryIterate h φ (n+1) (s-h))=
      φ (min t 0)-(∫ s in (0 : ℝ)..max t 0, delayHistoryIterate h φ n (s-h))
    rw [max_eq_left ht0]
    congr 1
    apply intervalIntegral.integral_congr
    intro s hs
    rw [uIcc_of_le ht0] at hs
    apply ih
    push_cast at ht
    nlinarith [hs.2]

-- @paper-step lem:delayed_cancellation/method_of_steps_all_later_iterates_agree
theorem delayHistoryIterate_agree {h : ℝ} (hh : 0≤h) (φ : ℝ → ℝ)
    {n m : ℕ} (hnm : n≤m) {t : ℝ} (ht : t≤n*h) :
    delayHistoryIterate h φ m t=delayHistoryIterate h φ n t := by
  induction m,hnm using Nat.le_induction with
  | base => rfl
  | succ m hnm ih =>
    rw [delayHistoryIterate_stable hh φ m (ht.trans
      (mul_le_mul_of_nonneg_right (by exact_mod_cast hnm) hh)),ih]

noncomputable def delayHistorySolution (h : ℝ) (φ : ℝ → ℝ) (t : ℝ) : ℝ :=
  delayHistoryIterate h φ (⌈max t 0/h⌉₊+1) t

-- @paper-step lem:delayed_cancellation/method_of_steps_solution_equals_finite_iterate
theorem delayHistorySolution_eq {h : ℝ} (hh : 0<h) (φ : ℝ → ℝ)
    (n : ℕ) {t : ℝ} (ht : t≤n*h) :
    delayHistorySolution h φ t=delayHistoryIterate h φ n t := by
  let m := ⌈max t 0/h⌉₊+1
  have hm : t≤m*h := by
    have hc := Nat.le_ceil (max t 0/h)
    have hd : max t 0≤(⌈max t 0/h⌉₊ : ℝ)*h := (div_le_iff₀ hh).mp hc
    dsimp [m]; push_cast; nlinarith [le_max_left t 0]
  change delayHistoryIterate h φ m t=delayHistoryIterate h φ n t
  rcases le_total n m with hnm|hmn
  · exact delayHistoryIterate_agree hh.le φ hnm ht
  · exact (delayHistoryIterate_agree hh.le φ hmn hm).symm

-- @paper-step lem:delayed_cancellation/method_of_steps_solution_continuity
theorem delayHistorySolution_continuous {h : ℝ} (hh : 0<h)
    {φ : ℝ → ℝ} (hφ : Continuous φ) : Continuous (delayHistorySolution h φ) := by
  apply continuous_iff_continuousAt.mpr
  intro t
  obtain ⟨n,hn⟩ := exists_nat_gt (t/h)
  have ht : t<n*h := (div_lt_iff₀ hh).mp hn
  have he : delayHistorySolution h φ=ᶠ[𝓝 t] delayHistoryIterate h φ n := by
    filter_upwards [Iio_mem_nhds ht] with s hs
    exact delayHistorySolution_eq hh φ n hs.le
  exact ((delayHistoryIterate_continuous hφ h n).continuousAt).congr he.symm

-- @paper-step lem:delayed_cancellation/method_of_steps_actual_delay_equation
theorem delayHistorySolution_deriv {h : ℝ} (hh : 0<h)
    {φ : ℝ → ℝ} (hφ : Continuous φ) {t : ℝ} (ht : 0<t) :
    HasDerivAt (delayHistorySolution h φ) (-delayHistorySolution h φ (t-h)) t := by
  obtain ⟨n,hn⟩ := exists_nat_gt (t/h)
  have htn : t<n*h := (div_lt_iff₀ hh).mp hn
  have hc : Continuous (fun s => delayHistoryIterate h φ n (s-h)) :=
    (delayHistoryIterate_continuous hφ h n).comp (continuous_id.sub continuous_const)
  have hd := (intervalIntegral.integral_hasDerivAt_right (hc.intervalIntegrable 0 t)
    (hc.stronglyMeasurableAtFilter _ _) hc.continuousAt).const_sub (φ 0)
  have he : (fun u => φ 0-∫ s in (0 : ℝ)..u, delayHistoryIterate h φ n (s-h))
      =ᶠ[𝓝 t] delayHistorySolution h φ := by
    filter_upwards [Ioo_mem_nhds ht htn] with u hu
    rw [delayHistorySolution_eq hh φ (n+1) (by push_cast; nlinarith [hu.2])]
    simp [delayHistoryIterate,delayHistoryStep,min_eq_right hu.1.le,max_eq_left hu.1.le]
  rw [delayHistorySolution_eq hh φ n (by linarith)]
  exact hd.congr_of_eventuallyEq he.symm

-- @paper-step lem:delayed_cancellation/arbitrary_continuous_history_solution_exists
theorem scalarDelay_history_exists {h : ℝ} (hh : 0<h)
    {φ : ℝ → ℝ} (hφ : Continuous φ) :
    ∃ w : ℝ → ℝ, Continuous w ∧ (∀ t, t≤0 → w t=φ t) ∧
      ∀ t, 0<t → HasDerivAt w (-w (t-h)) t := by
  refine ⟨delayHistorySolution h φ,delayHistorySolution_continuous hh hφ,?_,
    fun t ht => delayHistorySolution_deriv hh hφ ht⟩
  intro t ht
  exact delayHistoryIterate_past h φ _ ht

-- @paper-step lem:delayed_cancellation/ordinary_history_solution_integral_identity
theorem scalarDelay_history_integral {h : ℝ} {w : ℝ → ℝ} (hw : Continuous w)
    (hd : ∀ t, 0<t → HasDerivAt w (-w (t-h)) t) {t : ℝ} (ht : 0≤t) :
    w t=w 0-∫ s in (0 : ℝ)..t, w (s-h) := by
  have hc : Continuous (fun s => w (s-h)) := hw.comp (continuous_id.sub continuous_const)
  have he := intervalIntegral.integral_eq_sub_of_hasDerivAt_of_le ht hw.continuousOn
    (fun s hs => hd s hs.1) (hc.neg.intervalIntegrable 0 t)
  rw [intervalIntegral.integral_neg] at he
  linarith

-- @paper-step lem:delayed_cancellation/uniqueness_on_every_finite_history_interval
theorem scalarDelay_history_eq_iterate {h : ℝ} {φ w : ℝ → ℝ}
    (hw : Continuous w) (hp : ∀ t, t≤0 → w t=φ t)
    (hd : ∀ t, 0<t → HasDerivAt w (-w (t-h)) t)
    (n : ℕ) {t : ℝ} (ht : t≤n*h) : w t=delayHistoryIterate h φ n t := by
  induction n generalizing t with
  | zero =>
    have ht0 : t≤0 := by simpa using ht
    rw [delayHistoryIterate_past h φ 0 ht0,hp t ht0]
  | succ n ih =>
    by_cases ht0 : t≤0
    · rw [delayHistoryIterate_past h φ (n+1) ht0,hp t ht0]
    have ht0 : 0≤t := le_of_lt (lt_of_not_ge ht0)
    rw [scalarDelay_history_integral hw hd ht0,hp 0 le_rfl]
    simp only [delayHistoryIterate,delayHistoryStep,min_eq_right ht0,max_eq_left ht0]
    congr 1
    apply intervalIntegral.integral_congr
    intro s hs
    rw [uIcc_of_le ht0] at hs
    apply ih
    push_cast at ht
    linarith [hs.2]

-- @paper-step lem:delayed_cancellation/unrestricted_ordinary_history_uniqueness
theorem scalarDelay_history_unique {h : ℝ} (hh : 0<h) {φ w : ℝ → ℝ}
    (hw : Continuous w) (hp : ∀ t, t≤0 → w t=φ t)
    (hd : ∀ t, 0<t → HasDerivAt w (-w (t-h)) t) :
    w=delayHistorySolution h φ := by
  funext t
  obtain ⟨n,hn⟩ := exists_nat_gt (t/h)
  have ht : t≤n*h := ((div_lt_iff₀ hh).mp hn).le
  rw [delayHistorySolution_eq hh φ n ht]
  exact scalarDelay_history_eq_iterate hw hp hd n ht

end MIACE
