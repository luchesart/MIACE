import MIACE.Areas
import Mathlib.Analysis.Convolution
import Mathlib.MeasureTheory.Function.LpOrder
import Mathlib.MeasureTheory.Function.LpSpace.Complete
import Mathlib.Analysis.Normed.Ring.Units

/-! Етап 6: конволюцията е действителният интеграл на Лебег и непрекъснат
линеен оператор върху пълното пространство L¹. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution
noncomputable abbrev RealL1 := ℝ →₁[(volume : Measure ℝ)] ℝ

-- @paper-step lem:pid_positive_resolvent/young_l1
theorem convolution_absArea {f g : ℝ → ℝ} (hf : Integrable f) (hg : Integrable g) :
    absArea (f ⋆ g) volume ≤ absArea f volume * absArea g volume := by
  have hn : ∀ t : ℝ, |(f ⋆ g) t| ≤ ((fun s => |f s|) ⋆ (fun s => |g s|)) t := by
    intro t
    simpa only [convolution_def,ContinuousLinearMap.lsmul_apply,smul_eq_mul,abs_mul]
      using (abs_integral_le_integral_abs (f := fun s => f s*g (t-s)))
  have h := integral_mono (hf.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hg).abs
    (hf.abs.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hg.abs) hn
  rw [integral_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hf.abs hg.abs] at h
  exact h

noncomputable def convolutionL1 {K : ℝ → ℝ} (hK : Integrable K) (g : RealL1) : RealL1 :=
  (hK.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ)
    (L1.integrable_coeFn g)).toL1 (K ⋆ (g : ℝ → ℝ))

-- @paper-step lem:pid_positive_resolvent/convolution_coercion
theorem convolutionL1_coe {K : ℝ → ℝ} (hK : Integrable K) (g : RealL1) :
    convolutionL1 hK g =ᵐ[volume] K ⋆ (g : ℝ → ℝ) := Integrable.coeFn_toL1 _

-- @paper-step lem:pid_positive_resolvent/convolution_linear_add
theorem convolutionL1_add {K : ℝ → ℝ} (hK : Integrable K) (g h : RealL1) :
    convolutionL1 hK (g+h) = convolutionL1 hK g + convolutionL1 hK h := by
  apply Lp.ext
  have hc := convolution_congr (ContinuousLinearMap.lsmul ℝ ℝ)
    (EventuallyEq.rfl (f := K)) (Lp.coeFn_add g h)
  filter_upwards [convolutionL1_coe hK (g+h),Lp.coeFn_add (convolutionL1 hK g) (convolutionL1 hK h),
    convolutionL1_coe hK g,convolutionL1_coe hK h,
    hK.ae_convolution_exists (ContinuousLinearMap.lsmul ℝ ℝ) (L1.integrable_coeFn g),
    hK.ae_convolution_exists (ContinuousLinearMap.lsmul ℝ ℝ) (L1.integrable_coeFn h)]
    with t ht hadd hg hh hgx hhx
  rw [ht,hadd]
  simp only [Pi.add_apply]
  rw [hg,hh,hc]
  exact hgx.distrib_add hhx

-- @paper-step lem:pid_positive_resolvent/convolution_linear_smul
theorem convolutionL1_smul {K : ℝ → ℝ} (hK : Integrable K) (a : ℝ) (g : RealL1) :
    convolutionL1 hK (a • g) = a • convolutionL1 hK g := by
  apply Lp.ext
  have hc := convolution_congr (ContinuousLinearMap.lsmul ℝ ℝ)
    (EventuallyEq.rfl (f := K)) (Lp.coeFn_smul a g)
  filter_upwards [convolutionL1_coe hK (a • g),Lp.coeFn_smul a (convolutionL1 hK g),
    convolutionL1_coe hK g] with t ht hs hg
  rw [ht,hs]
  simp only [Pi.smul_apply]
  rw [hg,hc,convolution_smul]
  rfl

-- @paper-step lem:pid_positive_resolvent/convolution_operator_bound
theorem convolutionL1_bound {K : ℝ → ℝ} (hK : Integrable K) (g : RealL1) :
    ‖convolutionL1 hK g‖ ≤ absArea K volume * ‖g‖ := by
  rw [convolutionL1,L1.norm_of_fun_eq_integral_norm,L1.norm_eq_integral_norm]
  simpa only [Real.norm_eq_abs,absArea] using convolution_absArea hK (L1.integrable_coeFn g)

noncomputable def convOp {K : ℝ → ℝ} (hK : Integrable K) : RealL1 →L[ℝ] RealL1 :=
  LinearMap.mkContinuous
    { toFun := convolutionL1 hK
      map_add' := convolutionL1_add hK
      map_smul' := convolutionL1_smul hK }
    (absArea K volume) (convolutionL1_bound hK)

-- @paper-step lem:pid_positive_resolvent/operator_coercion
theorem convOp_coe {K : ℝ → ℝ} (hK : Integrable K) (g : RealL1) :
    convOp hK g =ᵐ[volume] K ⋆ (g : ℝ → ℝ) := convolutionL1_coe hK g

-- @paper-step lem:pid_positive_resolvent/convolution_norm
theorem convOp_norm {K : ℝ → ℝ} (hK : Integrable K) :
    ‖convOp hK‖ ≤ absArea K volume := by
  apply ContinuousLinearMap.opNorm_le_bound (convOp hK)
    (integral_nonneg (fun _ => abs_nonneg _)) (convolutionL1_bound hK)

-- @paper-step lem:pid_positive_resolvent/convolution_positive
theorem convOp_nonneg {K : ℝ → ℝ} (hK : Integrable K) (hKn : ∀ᵐ t, 0 ≤ K t)
    {g : RealL1} (hg : 0 ≤ g) : 0 ≤ convOp hK g := by
  rw [← Lp.coeFn_nonneg] at hg ⊢
  filter_upwards [convolutionL1_coe hK g] with t ht
  change 0 ≤ convolutionL1 hK g t
  rw [ht]
  apply integral_nonneg_of_ae
  have hg' := (quasiMeasurePreserving_sub_left_of_right_invariant
    (volume : Measure ℝ) t).tendsto_ae.eventually hg
  filter_upwards [hKn,hg'] with s hs hgs
  exact mul_nonneg hs hgs

-- @paper-step lem:pid_positive_resolvent/positive_kernel_mass
theorem positive_kernel_mass {K : ℝ → ℝ} (hn : ∀ᵐ t, 0 ≤ K t) :
    absArea K volume = ∫ t, K t := by
  apply integral_congr_ae
  filter_upwards [hn] with t ht
  exact abs_of_nonneg ht

end MIACE
