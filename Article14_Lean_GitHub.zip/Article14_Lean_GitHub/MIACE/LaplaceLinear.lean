import MIACE.WeightedControl
import MIACE.PrimitiveRealization

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:pid_two_rate_optimum/actual_L1_transform_linearity
theorem laplace_linear {f g : ℝ → ℝ} (hf : Integrable f) (hg : Integrable g)
    (a b : ℝ) {p : ℝ} (hp : 0≤p) :
    laplace (fun t => a*f t+b*g t) p=a*laplace f p+b*laplace g p := by
  unfold laplace
  have he : (fun t => Real.exp (-p*t)*(a*f t+b*g t))=
      (fun t => a*(Real.exp (-p*t)*f t)+b*(Real.exp (-p*t)*g t)) := by funext t; ring
  rw [he,integral_add
    ((laplace_integrable (hf.mono_measure Measure.restrict_le_self) hp).const_mul a)
    ((laplace_integrable (hg.mono_measure Measure.restrict_le_self) hp).const_mul b),
    integral_const_mul,integral_const_mul]

-- @paper-step thm:pid_two_rate_optimum/actual_L1_transform_scaling
theorem laplace_smul (a : ℝ) (f : ℝ → ℝ) (p : ℝ) :
    laplace (fun t => a*f t) p=a*laplace f p := by
  unfold laplace
  simp_rw [mul_left_comm (Real.exp _) a]
  exact integral_const_mul a _

-- @paper-step thm:pid_two_rate_optimum/actual_causal_transport_transform
theorem laplace_shift {f : ℝ → ℝ} (hf : Causal f) {δ : ℝ} (hδ : 0≤δ) (p : ℝ) :
    laplace (shift δ f) p=Real.exp (-δ*p)*laplace f p := by
  rw [← kernel_laplace_full (causal_shift hf hδ),expWeight_shift,
    integral_const_mul]
  change Real.exp (-p*δ) * (∫ t, expWeight (-p) f (t-δ)) = _
  rw [integral_sub_right_eq_self, kernel_laplace_full hf]
  congr 1
  congr 1
  ring

-- @paper-step thm:pid_two_rate_optimum/actual_ordinary_renewal_transform
theorem signed_renewal_function_laplace {K f : ℝ → ℝ} (hK : Integrable K)
    (hKc : Causal K) (hq : absArea K volume<1) (hf : Integrable f) (hfc : Causal f)
    {p : ℝ} (hp : 0≤p) :
    let z := (∑' n : ℕ, (convOp hK)^n) (hf.toL1 f)
    (1-laplace K p)*laplace z p=laplace f p := by
  dsimp only
  have hgc := causal_congr hfc hf.coeFn_toL1.symm
  have hz := (signed_renewal_l1 hK hq (hf.toL1 f)).2.1
  have hc := causal_renewal_series hK hKc ((convOp_norm hK).trans_lt hq) hgc
  have hh := renewal_laplace hK hKc (hf.toL1 f) _ hgc hc hz hp
  rwa [laplace_congr_ae hf.coeFn_toL1] at hh

end MIACE
