import MIACE.IMCWeighted

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:complete_robust/causal_extension_invariance
theorem causalize_eq_ae {f : ℝ → ℝ} (hf : Causal f) : causalize f=ᵐ[volume] f := by
  filter_upwards [hf] with t ht
  by_cases hp : 0≤t
  · simp [causalize,hp]
  · simp [causalize,hp,ht (lt_of_not_ge hp)]

-- @paper-step thm:complete_robust/causal_transform_full_injectivity
theorem causal_laplace_ext {f g : ℝ → ℝ} (hf : Integrable f) (hg : Integrable g)
    (hfc : Causal f) (hgc : Causal g)
    (hh : ∀ p : ℝ, 0<p → laplace f p=laplace g p) : f=ᵐ[volume] g :=
  (causalize_of_halfLine_eq hfc (laplace_injective_ae hf hg hh)).trans (causalize_eq_ae hgc)

-- @paper-step thm:complete_robust/causal_operator_transform
theorem convOp_laplace {K : ℝ → ℝ} (hK : Integrable K) (hKc : Causal K)
    {g : RealL1} (hgc : Causal g) {p : ℝ} (hp : 0≤p) :
    laplace (convOp hK g) p=laplace K p*laplace g p := by
  rw [laplace_congr_ae (convOp_coe hK g)]
  exact causal_convolution_laplace hK (L1.integrable_coeFn g) hKc hgc hp

-- @paper-step thm:complete_robust/filter_convolution_commutation
theorem filterAction_convolution (F : IMCFilter) {f g : ℝ → ℝ}
    (hf : Integrable f) (hg : Integrable g) (hfc : Causal f) (hgc : Causal g) :
    filterAction F (f ⋆ g)=ᵐ[volume] (filterAction F f ⋆ g) := by
  have hfg := hf.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hg
  have hfgc : Causal (f ⋆ g) := ae_of_all _ (convolution_causal hfc hgc)
  apply causal_laplace_ext (filterAction_integrable F hfg)
    ((filterAction_integrable F hf).integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hg)
    (filterAction_causal F hfgc)
    (ae_of_all _ (convolution_causal (filterAction_causal F hfc) hgc))
  intro p hp
  rw [filterAction_laplace F hfg hfgc hp.le,causal_convolution_laplace hf hg hfc hgc hp.le,
    causal_convolution_laplace (filterAction_integrable F hf) hg (filterAction_causal F hfc) hgc hp.le,
    filterAction_laplace F hf hfc hp.le]
  ring

-- @paper-step thm:complete_robust/filter_feedback_kernel_identity
theorem filterOp_convOp (F : IMCFilter) {K : ℝ → ℝ} (hK : Integrable K) (hKc : Causal K)
    {g : RealL1} (hgc : Causal g) :
    filterOp F (convOp hK g)=convOp (filterAction_integrable F hK) g := by
  apply Lp.ext
  exact (filterOp_coe F _).trans ((filterAction_congr F (convOp_coe hK g)).trans
    ((filterAction_convolution F hK (L1.integrable_coeFn g) hKc hgc).trans (convOp_coe _ g).symm))

-- @paper-step thm:complete_robust/causal_convolution_associativity
theorem causal_convolution_assoc {f g h : ℝ → ℝ}
    (hf : Integrable f) (hg : Integrable g) (hh : Integrable h)
    (hfc : Causal f) (hgc : Causal g) (hhc : Causal h) :
    ((f ⋆ g) ⋆ h)=ᵐ[volume] (f ⋆ (g ⋆ h)) := by
  have hfg := hf.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hg
  have hgh := hg.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hh
  have hfgc : Causal (f ⋆ g) := ae_of_all _ (convolution_causal hfc hgc)
  have hghc : Causal (g ⋆ h) := ae_of_all _ (convolution_causal hgc hhc)
  apply causal_laplace_ext
    (hfg.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hh)
    (hf.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hgh)
    (ae_of_all _ (convolution_causal hfgc hhc)) (ae_of_all _ (convolution_causal hfc hghc))
  intro p hp
  rw [causal_convolution_laplace hfg hh hfgc hhc hp.le,
    causal_convolution_laplace hf hgh hfc hghc hp.le,
    causal_convolution_laplace hf hg hfc hgc hp.le,
    causal_convolution_laplace hg hh hgc hhc hp.le]
  ring

-- @paper-step thm:complete_robust/weighted_control_smaller_exponent
theorem weightedControl_lower {β η C : ℝ} {f : ℝ → ℝ}
    (hf : WeightedControl β f C) (hc : Causal f) (hη : 0≤η) (hle : η≤β) :
    WeightedControl η f C := by
  have hu := weightedControl_unweighted hf hc (hη.trans hle)
  have hi := expWeight_integrable hu hf.integrable hη hle
  have hh : ∀ᵐ t, |expWeight η f t|≤|expWeight β f t| := by
    filter_upwards [hc] with t ht
    by_cases hp : 0≤t
    · simp only [expWeight,abs_mul,abs_of_pos (Real.exp_pos _)]
      exact mul_le_mul_of_nonneg_right (Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_right hle hp))
        (abs_nonneg _)
    · simp [expWeight,ht (lt_of_not_ge hp)]
  exact ⟨hf.nonneg,hi,(integral_mono_ae hi.abs hf.integrable.abs hh).trans hf.area,
    by filter_upwards [hh,hf.bound] with t ht hb; exact ht.trans hb⟩

end MIACE
