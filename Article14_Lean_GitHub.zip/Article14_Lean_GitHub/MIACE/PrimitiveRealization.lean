import MIACE.LaplaceAE

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def integratedState (x₀ : ℝ) (f : ℝ → ℝ) (t : ℝ) : ℝ := x₀+∫ s in 0..t, f s

-- @paper-step thm:pid_two_rate_optimum/integrated_state_regularities
theorem integratedState_regular (x₀ : ℝ) {f : ℝ → ℝ} (hf : Integrable f) :
    Continuous (integratedState x₀ f) ∧ integratedState x₀ f 0=x₀ ∧
      (∀ a b, AbsolutelyContinuousOnInterval (integratedState x₀ f) a b) ∧
      (∀ᵐ t, HasDerivAt (integratedState x₀ f) (f t) t) := by
  refine ⟨continuous_const.add (intervalIntegral.continuous_primitive
    (fun a b => hf.intervalIntegrable) 0),by simp [integratedState],?_,?_⟩
  · intro a b
    have hc : AbsolutelyContinuousOnInterval (fun _ : ℝ => x₀) a b := by
      apply ContDiffOn.absolutelyContinuousOnInterval; fun_prop
    exact hc.add (intervalPrimitive_ac (fun a b => hf.intervalIntegrable) 0 a b)
  · filter_upwards [LocallyIntegrable.ae_hasDerivAt_integral hf.locallyIntegrable] with t ht
    exact (ht 0).const_add x₀

-- @paper-step thm:pid_two_rate_optimum/integrated_state_actual_transform
theorem integratedState_laplace (x₀ : ℝ) {f : ℝ → ℝ} (hf : Integrable f halfLine)
    {p : ℝ} (hp : 0<p) :
    Integrable (fun t => Real.exp (-p*t)*integratedState x₀ f t) halfLine ∧
      laplace (integratedState x₀ f) p=(x₀+laplace f p)/p := by
  have hc : Integrable (fun t : ℝ => Real.exp (-p*t)) halfLine :=
    integrableOn_exp_mul_Ioi (by linarith : -p<0) 0
  have hF := primitive_laplace hf hp
  have he : (fun t => Real.exp (-p*t)*integratedState x₀ f t)=
      (fun t => x₀*Real.exp (-p*t)+Real.exp (-p*t)*(∫ s in 0..t, f s)) := by
    funext t; unfold integratedState; ring
  refine ⟨by rw [he]; exact (hc.const_mul x₀).add hF.1,?_⟩
  rw [laplace,he,integral_add (hc.const_mul x₀) hF.1,integral_const_mul]
  have hs := laplace_step p hp
  simp only [laplace,mul_one] at hs
  change x₀*(∫ t, Real.exp (-p*t) ∂halfLine)+laplace (fun t => ∫ s in 0..t, f s) p=_
  rw [hs,hF.2]
  ring

-- @paper-step thm:pid_two_rate_optimum/causal_ae_extension_from_halfline
theorem causalize_of_halfLine_eq {f g : ℝ → ℝ} (hf : Causal f)
    (he : f=ᵐ[halfLine] g) : f=ᵐ[volume] causalize g := by
  have hh := (ae_restrict_iff' measurableSet_Ioi).mp he
  filter_upwards [hh,hf,volume.ae_ne (0 : ℝ)] with t ht hc hz
  by_cases hp : 0<t
  · rw [ht hp,causalize,indicator_of_mem (show t∈Ici (0 : ℝ) from hp.le)]
  · have hn : t<0 := lt_of_le_of_ne (le_of_not_gt hp) hz
    simp [hc hn,causalize,not_le.mpr hn]

-- @paper-step thm:pid_two_rate_optimum/primitive_realization_from_actual_transform
theorem integratedState_identification {x f : ℝ → ℝ} (hx : Integrable x)
    (hxc : Causal x) (hf : Integrable f) (x₀ : ℝ)
    (htrans : ∀ p : ℝ, 0<p → p*laplace x p=x₀+laplace f p) :
    x=ᵐ[volume] causalize (integratedState x₀ f) := by
  apply causalize_of_halfLine_eq hxc
  have hwx : Integrable (expWeight (-(1 : ℝ)) (causalize x)) := by
    rw [expWeight_causalize]
    exact causalize_integrable (laplace_integrable (hx.mono_measure Measure.restrict_le_self) (by norm_num))
  have hwf : Integrable (expWeight (-(1 : ℝ)) (causalize (integratedState x₀ f))) := by
    rw [expWeight_causalize]
    exact causalize_integrable (integratedState_laplace x₀
      (hf.mono_measure Measure.restrict_le_self) (by norm_num : (0 : ℝ)<1)).1
  apply laplace_injective_weighted_ae hwx hwf
  intro p hp
  have hp0 : 0<p := by linarith
  rw [(integratedState_laplace x₀ (hf.mono_measure Measure.restrict_le_self) hp0).2]
  exact (eq_div_iff (ne_of_gt hp0)).mpr (by nlinarith [htrans p hp0])

end MIACE
