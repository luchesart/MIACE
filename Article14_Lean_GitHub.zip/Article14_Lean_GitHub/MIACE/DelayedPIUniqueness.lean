import MIACE.DelayedPIEvolution

namespace MIACE
open MeasureTheory Set Filter
open scoped Topology

-- @paper-step lem:delayed_cancellation/classical_stable_lag_uniqueness
theorem stableLag_future_unique {c : ℝ} (hc : 0<c) {y v u : ℝ → ℝ}
    (hy : Continuous y) (hv : Continuous v)
    (h0 : y 0=v 0)
    (hd : ∀ t, 0<t → HasDerivAt y (c*(u t-y t)) t)
    (he : ∀ t, 0<t → HasDerivAt v (c*(u t-v t)) t)
    {t : ℝ} (ht : 0≤t) : y t=v t := by
  have hdiff (s : ℝ) (hs : 0<s) :
      HasDerivAt (fun r => y r-v r) (c*(0-(y s-v s))) s := by
    convert (hd s hs).sub (he s hs) using 1 <;> ring
  have hb := (stableLag_energy_decay (I := 0) hc (hy.sub hv) continuous_const hdiff
    (fun T _ => by simp)).1 t ht
  simp only [Pi.sub_apply,h0,sub_self,sq,mul_zero,zero_add] at hb
  nlinarith [sq_nonneg (y t-v t)]

-- @paper-step lem:delayed_cancellation/physical_delay_equation_unrestricted_uniqueness
theorem scalarDelay_physical_unique {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    {w v : ℝ → ℝ} (hw : Continuous w) (hv : Continuous v)
    (hp : ∀ t, t≤0 → w t=v t)
    (hd : ∀ t, 0<t → HasDerivAt w (-x*w (t-δ)) t)
    (he : ∀ t, 0<t → HasDerivAt v (-x*v (t-δ)) t) : w=v := by
  by_cases hδ0 : δ=0
  · funext t
    by_cases ht : t≤0
    · exact hp t ht
    · apply stableLag_future_unique (u := fun _ => 0) hx hw hv (hp 0 le_rfl)
        (fun s hs => by simpa [hδ0] using hd s hs)
        (fun s hs => by simpa [hδ0] using he s hs) (le_of_lt (lt_of_not_ge ht))
  have hpδ : 0<x*δ := mul_pos hx (lt_of_le_of_ne hδ (Ne.symm hδ0))
  obtain ⟨hW,hWd⟩ := scalarDelay_normalize hx hw hd
  obtain ⟨hV,hVd⟩ := scalarDelay_normalize hx hv he
  have hWeq := scalarDelay_history_unique hpδ (φ := fun t => v (t/x)) hW
    (fun t ht => hp (t/x) (div_nonpos_of_nonpos_of_nonneg ht hx.le)) hWd
  have hVeq := scalarDelay_history_unique hpδ hV (fun t _ => rfl) hVd
  have hWV : (fun t => w (t/x))=(fun t => v (t/x)) := hWeq.trans hVeq.symm
  funext t
  have hh := congrFun hWV (x*t)
  simpa [ne_of_gt hx] using hh

-- @paper-step lem:delayed_cancellation/full_pi_history_unrestricted_uniqueness
theorem delayedPI_history_unique {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    {y z Y Z : ℝ → ℝ} (he : DelayedPIEvolution x δ y z)
    (hE : DelayedPIEvolution x δ Y Z)
    (hy : ∀ t, t≤0 → y t=Y t) (hz : ∀ t, t≤0 → z t=Z t) : y=Y ∧ z=Z := by
  have hW := scalarDelay_physical_unique hx hδ
    ((he.integrator_continuous.sub he.output_continuous).const_mul x)
    ((hE.integrator_continuous.sub hE.output_continuous).const_mul x)
    (fun t ht => by simp [hy t ht,hz t ht])
    (delayedPI_command_deriv he) (delayedPI_command_deriv hE)
  have hc (t : ℝ) : x*(z t-y t)=x*(Z t-Y t) := congrFun hW t
  have hy' : y=Y := by
    funext t
    by_cases ht : t≤0
    · exact hy t ht
    · apply stableLag_future_unique (c := 1) (u := fun t => x*(z (t-δ)-y (t-δ)))
        (by norm_num) he.output_continuous hE.output_continuous (hy 0 le_rfl)
        (fun s hs => by convert he.output_ode s hs using 1 <;> ring)
        (fun s hs => by rw [hc (s-δ)]; convert hE.output_ode s hs using 1 <;> ring)
        (le_of_lt (lt_of_not_ge ht))
  refine ⟨hy',?_⟩
  funext t
  have hh := hc t
  rw [hy'] at hh
  nlinarith

end MIACE
