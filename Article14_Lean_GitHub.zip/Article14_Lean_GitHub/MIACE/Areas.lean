import MIACE.Algebra
import Mathlib.MeasureTheory.Integral.Bochner.Basic

/-! Signal-independent integral part of the MIACE argument.
`μ` may be `volume.restrict (Set.Ici 0)`. Integrability is explicit:
Lean's total Bochner integral must not certify a divergent signal accidentally. -/
namespace MIACE
open MeasureTheory Filter
variable {X : Type*} [MeasurableSpace X] {μ : Measure X}

noncomputable def absArea (f : X → ℝ) (μ : Measure X) : ℝ := ∫ t, |f t| ∂μ
noncomputable def negArea (f : X → ℝ) (μ : Measure X) : ℝ := ∫ t, max (-f t) 0 ∂μ

-- @paper-step thm:miace_shape_gap/pointwise_negative_part
 theorem abs_eq_self_add_neg (x : ℝ) : |x| = x + 2 * max (-x) 0 := by
  by_cases h : 0 ≤ x
  · rw [abs_of_nonneg h, max_eq_right (by linarith)]
    ring
  · have hx : x ≤ 0 := le_of_not_ge h
    rw [abs_of_nonpos hx, max_eq_left (by linarith)]
    ring

-- @paper-step thm:miace_shape_gap/negative_part_integrability
 theorem negative_part_integrable {f : X → ℝ} (hf : Integrable f μ) :
    Integrable (fun t => max (-f t) 0) μ :=
  hf.neg.sup (integrable_zero _ _ _)

-- @paper-step thm:miace_shape_gap/negative_area_nonnegative
 theorem negative_area_nonneg (f : X → ℝ) : 0 ≤ negArea f μ := by
  unfold negArea
  exact integral_nonneg (fun t => le_max_right _ _)

-- @paper-step thm:miace_shape_gap/integral_negative_part
 theorem absolute_area_identity {f : X → ℝ} (hf : Integrable f μ) :
    absArea f μ = (∫ t, f t ∂μ) + 2 * negArea f μ := by
  unfold absArea negArea
  simp_rw [abs_eq_self_add_neg]
  rw [integral_add hf ((negative_part_integrable hf).const_mul 2), integral_const_mul]

-- @paper-step thm:miace_shape_gap/ae_sign_equivalence
 theorem negative_area_zero_iff {f : X → ℝ} (hf : Integrable f μ) :
    negArea f μ = 0 ↔ ∀ᵐ t ∂μ, 0 ≤ f t := by
  unfold negArea
  rw [integral_eq_zero_iff_of_nonneg_ae
    (Eventually.of_forall (fun t => le_max_right (-f t) 0)) (negative_part_integrable hf)]
  constructor
  · intro h
    filter_upwards [h] with t ht
    have hle : -f t ≤ max (-f t) 0 := le_max_left _ _
    change max (-f t) 0 = 0 at ht
    linarith
  · intro h
    filter_upwards [h] with t ht
    change max (-f t) 0 = 0
    exact max_eq_right (by linarith)

-- @paper-step thm:n_gap/area_balance_bridge
 theorem area_balance {e v : X → ℝ} (he : Integrable e μ) (hv : Integrable v μ)
    (S : ℝ) (signed_balance : (∫ t, e t ∂μ) + (∫ t, v t ∂μ) = S) :
    absArea e μ + absArea v μ = S + 2 * (negArea e μ + negArea v μ) := by
  rw [absolute_area_identity he, absolute_area_identity hv]
  linarith

-- @paper-step thm:n_gap/signal_excess_bridge
 theorem signal_excess {e v : X → ℝ} (he : Integrable e μ) (hv : Integrable v μ)
    (α S : ℝ) (hα : 0 < α)
    (signed_balance : (∫ t, e t ∂μ) + (∫ t, v t ∂μ) = S) :
    costSq α (absArea e μ) (absArea v μ) - baseSq α S =
      4 * α / (1+α) * (negArea e μ + negArea v μ) *
        (S + (negArea e μ + negArea v μ)) +
      (absArea e μ - α * absArea v μ)^2 / (1+α) :=
  excess_identity α S _ _ _ hα (area_balance he hv S signed_balance)

-- @paper-step thm:n_gap/signal_equality_bridge
 theorem signal_equality_iff {e v : X → ℝ} (he : Integrable e μ) (hv : Integrable v μ)
    (α S : ℝ) (hα : 0 < α) (hS : 0 < S)
    (signed_balance : (∫ t, e t ∂μ) + (∫ t, v t ∂μ) = S) :
    costSq α (absArea e μ) (absArea v μ) = baseSq α S ↔
      (∀ᵐ t ∂μ, 0 ≤ e t) ∧ (∀ᵐ t ∂μ, 0 ≤ v t) ∧
      absArea e μ = α * absArea v μ := by
  rw [cost_eq_iff α S _ _ _ hα hS
    (add_nonneg (negative_area_nonneg e) (negative_area_nonneg v))
    (area_balance he hv S signed_balance)]
  constructor
  · rintro ⟨hs, hr⟩
    have hn1 := negative_area_nonneg (μ := μ) e
    have hn2 := negative_area_nonneg (μ := μ) v
    exact ⟨(negative_area_zero_iff he).mp (by linarith),
      (negative_area_zero_iff hv).mp (by linarith), hr⟩
  · rintro ⟨h1,h2,hr⟩
    exact ⟨by rw [(negative_area_zero_iff he).mpr h1,
      (negative_area_zero_iff hv).mpr h2]; ring, hr⟩

-- @paper-step thm:miace_variation/integral_triangle
 theorem absolute_area_add_le {e v : X → ℝ} (he : Integrable e μ) (hv : Integrable v μ) :
    absArea (fun t => e t + v t) μ ≤ absArea e μ + absArea v μ := by
  unfold absArea
  rw [← integral_add he.abs hv.abs]
  exact integral_mono (he.add hv).abs (he.abs.add hv.abs) (fun t => abs_add_le (e t) (v t))

end MIACE
