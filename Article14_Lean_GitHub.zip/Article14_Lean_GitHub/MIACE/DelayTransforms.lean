import MIACE.PointwisePID
import MIACE.Delay

/-! Етап 10: преобразуване на действителния транспорт, включително
    интервала на изчакване и непрекъснатото съединяване при t=δ. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:pid_two_rate_optimum/transport_tail_transform
theorem delayTail_laplace (f : ℝ → ℝ) {δ : ℝ} (hδ : 0≤δ) (p : ℝ) :
    laplace (delayTail δ f) p=Real.exp (-δ*p)*laplace f p := by
  have he : (fun t => Real.exp (-p*t)*delayTail δ f t)=
      (fun t => Real.exp (-δ*p)*delayTail δ (fun s => Real.exp (-p*s)*f s) t) := by
    funext t
    by_cases ht : δ<t
    · simp only [delayTail,indicator_of_mem (show t∈Ioi δ from ht)]
      rw [← mul_assoc,← Real.exp_add]
      congr 2; ring
    · simp [delayTail,ht]
  rw [laplace,he,integral_const_mul,delayTail_integral δ hδ]
  rfl

-- @paper-step thm:pid_two_rate_optimum/waiting_pulse_transform
theorem waiting_pulse_laplace {δ p : ℝ} (hδ : 0≤δ) (hp : 0<p) :
    laplace (pulse 1 δ) p=(1-Real.exp (-δ*p))/p := by
  have he : (fun t => Real.exp (-p*t)*pulse 1 δ t)=
      (Ioc (0 : ℝ) δ).indicator (fun t => Real.exp (-p*t)) := by
    funext t
    by_cases ht : t∈Ioc (0 : ℝ) δ <;> simp [pulse,ht]
  rw [laplace,he,halfLine,integral_indicator measurableSet_Ioc,
    Measure.restrict_restrict measurableSet_Ioc,
    show Ioc (0 : ℝ) δ∩Ioi 0=Ioc 0 δ from inter_eq_left.mpr (fun _ ht => ht.1),
    ← intervalIntegral.integral_of_le hδ,finite_exp_integral (ne_of_gt hp)]
  rw [show -p*δ = -δ*p by ring]

-- @paper-step thm:pid_two_rate_optimum/waiting_error_transform
theorem delayedError_laplace {f : ℝ → ℝ} (hf : Integrable f halfLine)
    {δ p : ℝ} (hδ : 0≤δ) (hp : 0<p) :
    laplace (delayedError δ f) p=(1-Real.exp (-δ*p))/p+Real.exp (-δ*p)*laplace f p := by
  rw [laplace_congr_halfLine (delayedError_split δ f)]
  unfold laplace
  simp_rw [mul_add]
  rw [integral_add (laplace_integrable (pulse_integrable 1 δ) hp.le)
    (laplace_integrable (delayTail_integrable δ hδ hf) hp.le)]
  change laplace (pulse 1 δ) p+laplace (delayTail δ f) p=_
  rw [waiting_pulse_laplace hδ hp,delayTail_laplace f hδ p]
  rfl

-- @paper-step thm:pid_two_rate_optimum/continuous_waiting_junction
theorem delayedError_continuous {f : ℝ → ℝ} (hf : Continuous f) (h0 : f 0=1) (δ : ℝ) :
    Continuous (delayedError δ f) := by
  have he : delayedError δ f=(fun t => f (max 0 (t-δ))) := by
    funext t
    by_cases ht : t≤δ
    · simp [delayedError,ht,max_eq_left (show t-δ≤0 by linarith),h0]
    · simp [delayedError,ht,max_eq_right (show 0≤t-δ by linarith)]
  rw [he]
  exact hf.comp (continuous_const.max (continuous_id.sub continuous_const))

end MIACE
