import MIACE.ConvolutionL1
import Mathlib.Topology.Algebra.InfiniteSum.ContinuousEval

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:complete_robust/neumann_inverse_operator
theorem neumann_inverse_operator {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [CompleteSpace E] (T : E →L[ℝ] E) {q : ℝ} (hT : ‖T‖ ≤ q) (hq : q < 1) :
    let R := ∑' n : ℕ, T^n
    Summable (fun n : ℕ => T^n) ∧
      (1-T)*R = 1 ∧ R*(1-T) = 1 ∧ ‖R‖ ≤ 1/(1-q) := by
  dsimp only
  have hsmall := hT.trans_lt hq
  refine ⟨summable_geometric_of_norm_lt_one hsmall,
    mul_neg_geom_series T hsmall,
    geom_series_mul_neg T hsmall, ?_⟩
  have h := tsum_geometric_le_of_norm_lt_one T hsmall
  have hi : ‖(1 : E →L[ℝ] E)‖ ≤ 1 := ContinuousLinearMap.norm_id_le
  have hh : (1-‖T‖)⁻¹ ≤ 1/(1-q) := by
    rw [one_div]
    exact inv_anti₀ (sub_pos.mpr hq) (by linarith)
  linarith

-- @paper-step lem:pid_positive_resolvent/renewal_series_operator
theorem renewal_operator {E : Type*} [NormedAddCommGroup E] [NormedSpace ℝ E]
    [CompleteSpace E] (T : E →L[ℝ] E) {q : ℝ} (hT : ‖T‖ ≤ q) (hq : q < 1) (g : E) :
    ∃! z : E, z = g+T z := by
  obtain ⟨hs,hl,hr,hn⟩ := neumann_inverse_operator T hT hq
  let R := ∑' n : ℕ, T^n
  refine ⟨R g, ?_, ?_⟩
  · have h := congrArg (fun A : E →L[ℝ] E => A g) hl
    change R g - T (R g) = g at h
    exact sub_eq_iff_eq_add.mp h
  · intro z hz
    have h : (1-T) z = g := by change z-T z=g; exact sub_eq_iff_eq_add.mpr hz
    have hh := congrArg (fun A : E →L[ℝ] E => A z) hr
    change R ((1-T) z) = z at hh
    rw [h] at hh
    exact hh.symm

-- @paper-step lem:pid_positive_resolvent/renewal_series_l1
theorem renewal_l1 {K : ℝ → ℝ} (hK : Integrable K)
    (hKn : ∀ᵐ t, 0 ≤ K t) (hq : (∫ t, K t) < 1)
    (g : RealL1) (hg : 0 ≤ g) :
    let T := convOp hK
    let z := (∑' n : ℕ, T^n) g
    HasSum (fun n : ℕ => (T^n) g) z ∧
      0 ≤ z ∧ z = g+T z ∧
      (∀ z' : RealL1, z'=g+T z' → z'=z) ∧
      ‖z‖ ≤ ‖g‖/(1-(∫ t, K t)) := by
  dsimp only
  let T := convOp hK
  have hT : ‖T‖ ≤ ∫ t, K t := by
    rw [← positive_kernel_mass hKn]
    exact convOp_norm hK
  obtain ⟨hs,hl,hr,hn⟩ := neumann_inverse_operator T hT hq
  let R := ∑' n : ℕ, T^n
  have hsum : HasSum (fun n : ℕ => (T^n) g) (R g) :=
    hs.hasSum.map (ContinuousLinearMap.apply ℝ RealL1 g) (by fun_prop)
  have hp : ∀ n : ℕ, 0 ≤ (T^n) g := by
    intro n
    induction n with
    | zero => simpa using hg
    | succ n ih =>
      rw [pow_succ']
      exact convOp_nonneg hK hKn ih
  have hpos : 0 ≤ R g := by
    rw [← hsum.tsum_eq]
    exact tsum_nonneg hp
  have he : R g = g+T (R g) := by
    have h := congrArg (fun A : RealL1 →L[ℝ] RealL1 => A g) hl
    change R g-T (R g)=g at h
    exact sub_eq_iff_eq_add.mp h
  refine ⟨hsum,hpos,he,?_,?_⟩
  · intro z hz
    have hh : (1-T) z = g := by change z-T z=g; exact sub_eq_iff_eq_add.mpr hz
    have h := congrArg (fun A : RealL1 →L[ℝ] RealL1 => A z) hr
    change R ((1-T) z)=z at h
    rw [hh] at h
    exact h.symm
  · calc
      ‖R g‖ ≤ ‖R‖*‖g‖ := ContinuousLinearMap.le_opNorm R g
      _ ≤ (1/(1-(∫ t, K t)))*‖g‖ := mul_le_mul_of_nonneg_right hn (norm_nonneg _)
      _ = _ := by ring

end MIACE
