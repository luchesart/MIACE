import MIACE.CascadeResolvents
import MIACE.PrimitiveRealization

/-! Ordinary representatives of the inverse of R. The differential
equation and initial value are derived from the actual Laplace identity. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

structure CompactResolventEvolution (J : ℝ → ℝ) (δ a c ε : ℝ) (R : ℝ → ℝ) : Prop where
  continuous : Continuous R
  ac : ∀ u v, AbsolutelyContinuousOnInterval R u v
  initial : R 0=1/a
  ode : ∀ᵐ t, 0<t → HasDerivAt R
    (-(c/a)*R t-(ε/a)*(compactKernel J δ ⋆ causalize R) t) t

-- @paper-step thm:n_construction/actual_ordinary_compact_resolvent_equation
theorem compact_resolvent_realization {J : ℝ → ℝ} (hc : Continuous J)
    {δ a c ε : ℝ} (hδ : 0≤δ) (ha : 0<a) (r : RealL1) (hrc : Causal r)
    (htrans : ∀ p : ℝ, 0<p →
      (a*p+c+ε*compactExpMoment J δ (-p))*laplace r p=1) :
    ∃ R : ℝ → ℝ, CompactResolventEvolution J δ a c ε R ∧
      (r : ℝ → ℝ)=ᵐ[volume] causalize R := by
  let H := compactKernel J δ
  let f := fun t => -(c/a)*r t-(ε/a)*(H ⋆ (r : ℝ → ℝ)) t
  have hJ := compactKernel_integrable hc δ
  have hri := L1.integrable_coeFn r
  have hconv := hJ.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hri
  have hfi : Integrable f := (hri.const_mul (-(c/a))).sub (hconv.const_mul (ε/a))
  have hftrans (p : ℝ) (hp : 0<p) : p*laplace r p=1/a+laplace f p := by
    have he : f=(fun t => (-(c/a))*r t+(-(ε/a))*(H ⋆ (r : ℝ → ℝ)) t) := by
      funext t; dsimp [f]; ring
    rw [he,laplace_linear hri hconv (-(c/a)) (-(ε/a)) hp.le,causal_convolution_laplace hJ hri (compactKernel_causal J δ) hrc hp.le,
      compactKernel_laplace J hδ]
    have h := htrans p hp
    have ha0 := ne_of_gt ha
    field_simp
    nlinarith [h]
  let R := integratedState (1/a) f
  have he : (r : ℝ → ℝ)=ᵐ[volume] causalize R :=
    integratedState_identification hri hrc hfi (1/a) hftrans
  obtain ⟨hRc,hR0,hRac,hRd⟩ := integratedState_regular (1/a) hfi
  refine ⟨R,⟨hRc,hRac,hR0,?_⟩,he⟩
  have hce := convolution_congr (ContinuousLinearMap.lsmul ℝ ℝ)
    (EventuallyEq.rfl (f := H)) he
  filter_upwards [hRd,he] with t hd ht ht0
  change HasDerivAt R (-(c/a)*r t-(ε/a)*(H ⋆ (r : ℝ → ℝ)) t) t at hd
  rw [ht,hce] at hd
  simpa only [causalize,indicator_of_mem (show t∈Ici (0 : ℝ) from ht0.le)] using hd

-- @paper-step thm:n_construction/ordinary_nonnegativity_from_positive_series
theorem compact_resolvent_nonneg {J : ℝ → ℝ} {δ a c ε : ℝ} {r : RealL1}
    {R : ℝ → ℝ} (h : CompactResolventEvolution J δ a c ε R)
    (hr : 0≤r) (he : (r : ℝ → ℝ)=ᵐ[volume] causalize R) :
    ∀ t, 0≤t → 0≤R t := by
  apply continuous_halfLine_bound continuous_const h.continuous
  have hh := representative_halfLine_ae he
  have hn := ((Lp.coeFn_nonneg _).mpr hr).filter_mono (ae_mono (Measure.restrict_le_self (s := Ioi (0 : ℝ))))
  filter_upwards [hh,hn] with t he hn
  simpa only [Pi.zero_apply,he] using hn

-- @paper-step thm:n_construction/even_resolvent_integrating_factor_monotone
theorem even_resolvent_tilt_monotone {J : ℝ → ℝ} {δ a c : ℝ}
    (ha : 0<a) (hn : ∀ t∈Icc (0 : ℝ) δ, 0≤J t) {R : ℝ → ℝ}
    (h : CompactResolventEvolution J δ a c (-1) R)
    (hR : ∀ t, 0≤t → 0≤R t) :
    MonotoneOn (fun t => Real.exp ((c/a)*t)*R t) (Ici 0) := by
  have hRn : ∀ᵐ t, 0≤causalize R t := ae_of_all _ (fun t => by
    by_cases ht : 0≤t
    · simpa [causalize,ht] using hR t ht
    · simp [causalize,ht])
  intro u hu v hv huv
  have hac : AbsolutelyContinuousOnInterval (fun t => Real.exp ((c/a)*t)*R t) u v := by
    have he : AbsolutelyContinuousOnInterval (fun t : ℝ => Real.exp ((c/a)*t)) u v := by
      apply ContDiffOn.absolutelyContinuousOnInterval; fun_prop
    exact he.mul (h.ac u v)
  have hd : ∀ᵐ t, 0<t → 0≤deriv (fun s => Real.exp ((c/a)*s)*R s) t := by
    filter_upwards [h.ode] with t hd ht
    have hg := (((hasDerivAt_id t).const_mul (c/a)).exp).mul (hd ht)
    change HasDerivAt (fun s => Real.exp ((c/a)*s)*R s) _ t at hg
    rw [hg.deriv]
    have hconv := convolution_pointwise_nonneg (ae_of_all _ (compactKernel_nonneg hn)) hRn t
    dsimp
    have ha0 := ne_of_gt ha
    have hh := mul_nonneg (Real.exp_nonneg ((c/a)*t)) (div_nonneg hconv ha.le)
    convert hh using 1 <;> ring
  have hi : 0≤∫ t in u..v, deriv (fun s => Real.exp ((c/a)*s)*R s) t := by
    rw [intervalIntegral.integral_of_le huv]
    apply integral_nonneg_of_ae
    have hd' := hd.filter_mono (ae_mono (Measure.restrict_le_self (s := Ioc u v)))
    filter_upwards [hd',ae_restrict_mem measurableSet_Ioc] with t ht hmem
    exact ht (lt_of_le_of_lt hu hmem.1)
  rw [hac.integral_deriv_eq_sub] at hi
  linarith

-- @paper-step thm:n_construction/even_resolvent_backward_comparison
theorem even_resolvent_backward {J : ℝ → ℝ} {δ a c : ℝ}
    (ha : 0<a) (hn : ∀ t∈Icc (0 : ℝ) δ, 0≤J t) {R : ℝ → ℝ}
    (h : CompactResolventEvolution J δ a c (-1) R)
    (hR : ∀ t, 0≤t → 0≤R t) {s t : ℝ} (hs : 0≤s) (hst : s≤t) :
    R (t-s)≤Real.exp ((c/a)*s)*R t := by
  have hh := even_resolvent_tilt_monotone ha hn h hR
    (sub_nonneg.mpr hst) (hs.trans hst) (by linarith : t-s≤t)
  have he : Real.exp ((c/a)*t)=Real.exp ((c/a)*(t-s))*Real.exp ((c/a)*s) := by
    rw [← Real.exp_add]; congr 1; ring
  dsimp only at hh
  rw [he,mul_assoc] at hh
  exact (mul_le_mul_iff_right₀ (Real.exp_pos _)).mp hh

end MIACE
