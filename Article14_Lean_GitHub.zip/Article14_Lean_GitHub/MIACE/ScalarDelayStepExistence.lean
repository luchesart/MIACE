import MIACE.DelayedPIEvolution
import MIACE.ScalarDelayNecessity

namespace MIACE
open MeasureTheory Set Filter
open scoped Topology

-- @paper-step lem:delayed_cancellation/zero_history_shift_has_zero_waiting_integral
theorem scalarDelay_waiting_integral (E : ℝ → ℝ) {δ t : ℝ} (hδ : 0≤δ) (ht : t≤δ) :
    (∫ s in (0 : ℝ)..t, shift δ (causalize E) s)=0 := by
  calc
    _ = ∫ s in (0 : ℝ)..t, (0 : ℝ) := by
      apply intervalIntegral.integral_congr_ae
      filter_upwards [volume.ae_ne δ] with s hs hsi
      have hsle : s≤δ := hsi.2.trans (max_le hδ ht)
      have hslt : s<δ := lt_of_le_of_ne hsle hs
      simp [shift,causalize,show ¬0≤s-δ by linarith]
    _ = 0 := by simp

-- @paper-step lem:delayed_cancellation/ordinary_step_response_exists_at_every_gain_and_delay
theorem scalarDelay_response_exists {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ) :
    ∃ E : ℝ → ℝ, ScalarDelayResponse x δ E := by
  obtain ⟨v,hv,hpast,hvd⟩ := scalarDelay_physical_history_exists hx hδ
    (φ := fun _ => 1) continuous_const
  let E := fun t => v (t-δ)
  have hE : Continuous E := hv.comp (continuous_id.sub continuous_const)
  have heq (t : ℝ) : E t=1-x*(∫ s in (0 : ℝ)..t, shift δ (causalize E) s) := by
    by_cases ht : t≤δ
    · rw [scalarDelay_waiting_integral E hδ ht]
      simpa [E] using hpast (t-δ) (by linarith)
    have htd : 0≤t-δ := by linarith
    have hshift : (∫ s in (0 : ℝ)..t, shift δ (causalize E) s)=∫ s in (0 : ℝ)..t-δ, E s := by
      simpa only [sub_add_cancel] using scalarDelay_shift_primitive E hδ htd
    rw [hshift]
    have hc : Continuous (fun s => -x*v (s-δ)) := by fun_prop
    have hi := intervalIntegral.integral_eq_sub_of_hasDerivAt_of_le htd hv.continuousOn
      (fun s hs => hvd s hs.1) (hc.intervalIntegrable 0 (t-δ))
    rw [intervalIntegral.integral_const_mul,hpast 0 le_rfl] at hi
    change E t=1-x*(∫ s in (0 : ℝ)..t-δ, v (s-δ))
    change -x*(∫ s in (0 : ℝ)..t-δ, v (s-δ))=E t-1 at hi
    linarith
  have hloc := locally_integrable_interval (scalarDelay_shift_local hE δ)
  refine ⟨E,⟨hE,?_,?_,fun t _ => heq t⟩⟩
  · intro a b
    have hc : AbsolutelyContinuousOnInterval (fun _ : ℝ => (1 : ℝ)) a b := by
      apply ContDiffOn.absolutelyContinuousOnInterval; fun_prop
    have hi := hc.sub ((intervalPrimitive_ac hloc 0 a b).const_mul x)
    exact hi.congr (fun t _ => (heq t).symm)
  · simpa [E] using hpast (-δ) (by linarith)

end MIACE
