import MIACE.CompactLaplace
import Mathlib.Analysis.Calculus.ContDiff.Polynomial
import Mathlib.Analysis.Calculus.IteratedDeriv.Lemmas
import Mathlib.Algebra.Polynomial.FieldDivision

namespace MIACE
open MeasureTheory Filter Set Polynomial
open scoped Topology

-- @paper-step lem:n_remainder/factor_polynomial_dc
theorem remainderB_zero (r : ℕ → ℝ) (n : ℕ) : (remainderB r n).eval 0=1 := by
  induction n with
  | zero => simp [remainderB]
  | succ n ih => simp [remainderB,ih]

-- @paper-step lem:n_remainder/factor_polynomial_nonzero
theorem remainderB_ne_zero (r : ℕ → ℝ) (n : ℕ) : remainderB r n≠0 := by
  intro he
  have hz := remainderB_zero r n
  rw [he,eval_zero] at hz
  norm_num at hz

-- @paper-step lem:n_remainder/factor_polynomial_degree
theorem remainderB_degree (r : ℕ → ℝ) (n : ℕ) (hr : ∀ j≤n, r j≠0) :
    (remainderB r n).natDegree=n+1 := by
  have hl (j : ℕ) (hj : r j≠0) : (C (1/r j)*X+(1 : ℝ[X])).natDegree=1 := by
    simpa using (natDegree_linear (b := (1 : ℝ)) (one_div_ne_zero hj))
  induction n with
  | zero => exact hl 0 (hr 0 le_rfl)
  | succ n ih =>
    rw [remainderB,natDegree_mul (remainderB_ne_zero r n)
      (by intro he; have hz := congrArg (fun P : ℝ[X] => P.eval 0) he; simpa using hz),
      ih (fun j hj => hr j (by omega)),hl (n+1) (hr (n+1) le_rfl)]

-- @paper-step lem:n_remainder/interpolation_polynomial_degree_bound
theorem remainderI_degree (r : ℕ → ℝ) (n : ℕ) (δ : ℝ) (hr : ∀ j≤n, r j≠0) :
    (remainderI r δ n).natDegree≤n := by
  induction n with
  | zero => simp [remainderI]
  | succ n ih =>
    apply natDegree_add_le_of_degree_le
      ((ih (fun j hj => hr j (by omega))).trans (by omega))
    apply (natDegree_mul_le).trans
    simp only [natDegree_C,zero_add,remainderB_degree r n (fun j hj => hr j (by omega))]
    exact le_rfl

-- @paper-step lem:n_remainder/polynomial_iterated_derivative_bridge
theorem polynomial_iterated_deriv (P : ℂ[X]) (k : ℕ) (z : ℂ) :
    iteratedDeriv k (fun p => P.eval p) z=((Polynomial.derivative^[k]) P).eval z := by
  induction k generalizing P with
  | zero => rfl
  | succ k ih =>
    rw [iteratedDeriv_succ']
    have he : deriv (fun p => P.eval p)=fun p => P.derivative.eval p := by
      funext p; exact P.deriv
    rw [he,ih,Function.iterate_succ_apply]

-- @paper-step lem:n_remainder/analytic_factor_preserves_root_multiplicities
theorem analytic_product_vanishing (B : ℂ[X]) {H : ℂ → ℂ} {z : ℂ}
    (hH : AnalyticAt ℂ H z) {k : ℕ} (hk : k<B.rootMultiplicity z) :
    iteratedDeriv k (fun p => B.eval p*H p) z=0 := by
  rw [iteratedDeriv_fun_mul (by exact (Differentiable.analyticAt (fun p => B.differentiableAt) z).contDiffAt) hH.contDiffAt]
  apply Finset.sum_eq_zero
  intro i hi
  have hiz : i<B.rootMultiplicity z := (Nat.le_of_lt_succ (Finset.mem_range.mp hi)).trans_lt hk
  have he : iteratedDeriv i (fun p => B.eval p) z=0 := by
    rw [polynomial_iterated_deriv]
    exact isRoot_iterate_derivative_of_lt_rootMultiplicity hiz
  rw [he,mul_zero,zero_mul]

-- @paper-step lem:n_remainder/confluent_hermite_conditions_all_multiplicities
theorem remainder_hermite (r : ℕ → ℝ) (n : ℕ) (δ : ℝ)
    (hr : ∀ j≤n, r j≠0) (z : ℂ) (k : ℕ)
    (hk : k<((remainderB r n).map Complex.ofRealHom).rootMultiplicity z) :
    iteratedDeriv k (fun p : ℂ => (remainderI r δ n).eval₂ Complex.ofRealHom p) z=
      (-(δ : ℂ))^k*Complex.exp (-(δ : ℂ)*z) := by
  let I := (remainderI r δ n).map Complex.ofRealHom
  let B := (remainderB r n).map Complex.ofRealHom
  let H := fun p : ℂ => (-1 : ℂ)^(n+1)*compactLaplace (remainderJ r n δ) δ p
  have hH : AnalyticAt ℂ H z :=
    (analyticAt_const).mul (compactLaplace_analytic (remainderJ_continuous r n δ) δ z)
  have hz := analytic_product_vanishing B hH hk
  have he : (fun p : ℂ => Complex.exp (-(δ : ℂ)*p))=
      (fun p => I.eval p+B.eval p*H p) := by
    funext p
    simpa only [I,B,H,eval_map,mul_assoc,mul_left_comm,mul_comm] using
      exact_delay_remainder_complex r n δ p hr
  have hi : ContDiffAt ℂ k (fun p => I.eval p) z := by exact (Differentiable.analyticAt (fun p => I.differentiableAt) z).contDiffAt
  have hb : ContDiffAt ℂ k (fun p => B.eval p*H p) z :=
    (by exact (Differentiable.analyticAt (fun p => B.differentiableAt) z).contDiffAt : ContDiffAt ℂ k (fun p => B.eval p) z).mul hH.contDiffAt
  have hh := congrArg (fun f : ℂ → ℂ => iteratedDeriv k f z) he
  rw [iteratedDeriv_fun_add hi hb,hz,add_zero,iteratedDeriv_cexp_const_mul] at hh
  simpa only [I,eval_map] using hh.symm

-- @paper-step lem:n_remainder/interpolation_at_every_root
theorem remainder_at_root (r : ℕ → ℝ) (n : ℕ) (δ : ℝ)
    (hr : ∀ j≤n, r j≠0) (z : ℂ)
    (hz : (remainderB r n).eval₂ Complex.ofRealHom z=0) :
    (remainderI r δ n).eval₂ Complex.ofRealHom z=Complex.exp (-(δ : ℂ)*z) := by
  have he := exact_delay_remainder_complex r n δ z hr
  simpa [hz] using he.symm

end MIACE
