import MIACE.ScalarDelayDecay
import MIACE.PositiveLag

namespace MIACE
open MeasureTheory Set Filter
open scoped Topology

-- @paper-step lem:delayed_cancellation/retained_lag_finite_energy_inequality
theorem stableLag_square_energy {c : ℝ} (hc : 0<c) {y u : ℝ → ℝ}
    (hy : Continuous y) (hu : Continuous u)
    (hd : ∀ t, 0<t → HasDerivAt y (c*(u t-y t)) t) {T : ℝ} (hT : 0≤T) :
    (y T)^2+c*(∫ t in (0 : ℝ)..T, (y t)^2)≤
      (y 0)^2+c*(∫ t in (0 : ℝ)..T, (u t)^2) := by
  have hD : Continuous (fun t => 2*c*y t*(u t-y t)) := by fun_prop
  have he := intervalIntegral.integral_eq_sub_of_hasDerivAt_of_le hT (hy.pow 2).continuousOn
    (fun t ht => by convert (hd t ht.1).pow 2 using 1 <;> ring) (hD.intervalIntegrable 0 T)
  have hm := intervalIntegral.integral_mono_on (μ := volume)
    (g := fun t => c*((u t)^2-(y t)^2)) hT (hD.intervalIntegrable 0 T)
    (((hu.pow 2).sub (hy.pow 2)).const_mul c |>.intervalIntegrable 0 T)
    (fun t _ => by nlinarith [mul_nonneg hc.le (sq_nonneg (u t-y t))])
  rw [intervalIntegral.integral_const_mul,intervalIntegral.integral_sub
    (f := fun t => (u t)^2) (g := fun t => (y t)^2)
    ((hu.pow 2).intervalIntegrable 0 T) ((hy.pow 2).intervalIntegrable 0 T)] at hm
  simp only [Pi.pow_apply] at he
  linarith

-- @paper-step lem:delayed_cancellation/retained_lag_square_integrability_and_decay
theorem stableLag_energy_decay {c I : ℝ} (hc : 0<c) {y u : ℝ → ℝ}
    (hy : Continuous y) (hu : Continuous u)
    (hd : ∀ t, 0<t → HasDerivAt y (c*(u t-y t)) t)
    (hb : ∀ T, 0≤T → (∫ t in (0 : ℝ)..T, (u t)^2)≤I) :
    (∀ T, 0≤T → (y T)^2≤(y 0)^2+c*I) ∧ Tendsto y atTop (𝓝 0) := by
  have hye (T : ℝ) (hT : 0≤T) : (∫ t in (0 : ℝ)..T, (y t)^2)≤(y 0)^2/c+I := by
    have he := stableLag_square_energy hc hy hu hd hT
    have hb' := mul_le_mul_of_nonneg_left (hb T hT) hc.le
    calc
      _ ≤ ((y 0)^2+c*I)/c := (le_div_iff₀ hc).mpr (by nlinarith [sq_nonneg (y T)])
      _ = (y 0)^2/c+I := by field_simp
  have hyi : IntegrableOn (fun t => (y t)^2) (Ioi 0) := by
    apply integrableOn_Ioi_of_intervalIntegral_norm_bounded ((y 0)^2/c+I) 0
      (fun T : ℝ => (hy.pow 2).integrableOn_Icc.mono_set Ioc_subset_Icc_self) tendsto_id
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with T hT
    simpa only [Pi.pow_apply,id_eq,Real.norm_eq_abs,abs_pow,sq_abs] using hye T hT
  have hui : IntegrableOn (fun t => (u t)^2) (Ioi 0) := by
    apply integrableOn_Ioi_of_intervalIntegral_norm_bounded I 0
      (fun T : ℝ => (hu.pow 2).integrableOn_Icc.mono_set Ioc_subset_Icc_self) tendsto_id
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with T hT
    simpa only [Pi.pow_apply,id_eq,Real.norm_eq_abs,abs_pow,sq_abs] using hb T hT
  have hdi : IntegrableOn (fun t => 2*c*y t*(u t-y t)) (Ioi 0) := by
    apply ((hui.add (hyi.const_mul 3)).const_mul c).mono'
      (by exact (show Continuous (fun t => 2*c*y t*(u t-y t)) by fun_prop).aestronglyMeasurable)
    apply Eventually.of_forall
    intro t
    change ‖2*c*y t*(u t-y t)‖≤c*((u t)^2+3*(y t)^2)
    rw [Real.norm_eq_abs,abs_le]
    constructor <;> nlinarith [mul_nonneg hc.le (sq_nonneg (u t-y t)),
      mul_nonneg hc.le (sq_nonneg (u t+y t)),mul_nonneg hc.le (sq_nonneg (y t))]
  have hsq : Tendsto (fun t => (y t)^2) atTop (𝓝 0) :=
    tendsto_zero_of_hasDerivAt_of_integrableOn_Ioi
      (fun t ht => by convert (hd t ht).pow 2 using 1 <;> ring) hdi hyi
  refine ⟨?_,tendsto_zero_iff_norm_tendsto_zero.mpr ?_⟩
  · intro T hT
    have he := stableLag_square_energy hc hy hu hd hT
    have hi : 0≤∫ t in (0 : ℝ)..T, (y t)^2 := intervalIntegral.integral_nonneg hT (fun t _ => sq_nonneg _)
    nlinarith [mul_le_mul_of_nonneg_left (hb T hT) hc.le,mul_nonneg hc.le hi]
  · simpa only [Function.comp_def,Real.sqrt_sq_eq_abs,Real.sqrt_zero,Real.norm_eq_abs] using
      Real.continuous_sqrt.continuousAt.tendsto.comp hsq

end MIACE
