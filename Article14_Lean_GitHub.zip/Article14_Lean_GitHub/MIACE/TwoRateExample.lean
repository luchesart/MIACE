import MIACE.TwoRateOptimal

/-! Точният пример α=1, δ=1/4, l=5, m=6.
    Рационални ограждения с доказан остатък на Тейлър; няма външен числов оракул.
    Половинните аргументи позволяват директно използване на Real.exp_bound. -/
set_option maxHeartbeats 1200000
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:pid_two_rate_optimum/balanced_exponential_enclosures
theorem balanced_exp_bounds :
    (28650479 : ℝ)/100000000 < Real.exp (-(5/4 : ℝ)) ∧
    Real.exp (-(5/4 : ℝ)) < 28650480/100000000 ∧
    (22313015 : ℝ)/100000000 < Real.exp (-(3/2 : ℝ)) ∧
    Real.exp (-(3/2 : ℝ)) < 22313017/100000000 := by
  have h₁ := Real.exp_bound (x := -(5/8 : ℝ)) (by norm_num) (n := 12) (by norm_num)
  have h₂ := Real.exp_bound (x := -(3/4 : ℝ)) (by norm_num) (n := 12) (by norm_num)
  norm_num [Finset.sum_range_succ,Nat.factorial] at h₁ h₂
  have hb₁ := (abs_le.mp h₁)
  have hb₂ := (abs_le.mp h₂)
  have ha : (5352614284 : ℝ)/10000000000 < Real.exp (-(5/8 : ℝ)) ∧
      Real.exp (-(5/8 : ℝ)) < 5352614286/10000000000 := by constructor <;> linarith
  have hb : (4723665526 : ℝ)/10000000000 < Real.exp (-(3/4 : ℝ)) ∧
      Real.exp (-(3/4 : ℝ)) < 4723665529/10000000000 := by constructor <;> linarith
  have he₁ : Real.exp (-(5/4 : ℝ))=Real.exp (-(5/8 : ℝ))^2 := by
    rw [pow_two,← Real.exp_add]
    norm_num
  have he₂ : Real.exp (-(3/2 : ℝ))=Real.exp (-(3/4 : ℝ))^2 := by
    rw [pow_two,← Real.exp_add]
    norm_num
  rw [he₁,he₂]
  refine ⟨?_,?_,?_,?_⟩ <;> nlinarith [Real.exp_pos (-(5/8 : ℝ)),Real.exp_pos (-(3/4 : ℝ))]

-- @paper-step thm:pid_two_rate_optimum/balanced_filter_enclosure
theorem balanced_rho_bounds :
    (10711 : ℝ)/100000 < pidRho (8/5) (1/4) 5 6 ∧
      pidRho (8/5) (1/4) 5 6 < 10712/100000 := by
  obtain ⟨ha₁,ha₂,hb₁,hb₂⟩ := balanced_exp_bounds
  have hd : 0 < 5*Real.exp (-(5/4 : ℝ))-6*Real.exp (-(3/2 : ℝ)) := by linarith
  have he : pidRho (8/5) (1/4) 5 6=
      (Real.exp (-(5/4 : ℝ))-Real.exp (-(3/2 : ℝ))-4/75)/
        (5*Real.exp (-(5/4 : ℝ))-6*Real.exp (-(3/2 : ℝ))) := by
    norm_num [pidRho,sub_eq_add_neg]
  rw [he]
  constructor
  · apply (lt_div_iff₀ hd).mpr
    linarith
  · apply (div_lt_iff₀ hd).mpr
    linarith

-- @paper-step thm:pid_two_rate_optimum/balanced_lead_enclosure
theorem balanced_lead_bounds :
    (11683 : ℝ)/100000 < pidLead (8/5) (1/4) 5 (pidRho (8/5) (1/4) 5 6) ∧
      pidLead (8/5) (1/4) 5 (pidRho (8/5) (1/4) 5 6) < 11685/100000 := by
  obtain ⟨hρ₁,hρ₂⟩ := balanced_rho_bounds
  obtain ⟨ha₁,ha₂,_,_⟩ := balanced_exp_bounds
  unfold pidLead
  norm_num
  have h₁ := mul_pos (sub_pos.mpr hρ₁) (sub_pos.mpr ha₁)
  have h₂ := mul_pos (sub_pos.mpr hρ₂) (sub_pos.mpr ha₂)
  constructor <;> nlinarith

-- @paper-step thm:pid_two_rate_optimum/balanced_residue_enclosure
theorem balanced_A_bounds :
    (433 : ℝ)/100 < twoRateA (pidRho (8/5) (1/4) 5 6) 5 6 ∧
      twoRateA (pidRho (8/5) (1/4) 5 6) 5 6 < 434/100 := by
  obtain ⟨hρ₁,hρ₂⟩ := balanced_rho_bounds
  have hρ : 0 < pidRho (8/5) (1/4) 5 6 := by linarith
  norm_num [twoRateA]
  constructor
  · have hh : (933 : ℝ)/100 < 1/pidRho (8/5) (1/4) 5 6 :=
      (lt_div_iff₀ hρ).mpr (by linarith)
    simp only [one_div] at hh
    linarith
  · have hh : 1/pidRho (8/5) (1/4) 5 6 < (934 : ℝ)/100 :=
      (div_lt_iff₀ hρ).mpr (by linarith)
    simp only [one_div] at hh
    linarith

-- @paper-step thm:pid_two_rate_optimum/balanced_command_sign_check
theorem balanced_forcing_check :
    ∀ t ∈ Icc (0 : ℝ) (1/4),
      0 ≤ twoRateR (twoRateA (pidRho (8/5) (1/4) 5 6) 5 6) 5 6 (1/4) t := by
  obtain ⟨hA₁,hA₂⟩ := balanced_A_bounds
  obtain ⟨ha₁,ha₂,hb₁,hb₂⟩ := balanced_exp_bounds
  obtain ⟨hρ₁,hρ₂⟩ := balanced_rho_bounds
  have hρ : 0 < pidRho (8/5) (1/4) 5 6 := by linarith
  let A := twoRateA (pidRho (8/5) (1/4) 5 6) 5 6
  have hA : 0 < A := by dsimp [A]; linarith
  have hAm : 0 ≤ A-1 := by dsimp [A]; linarith
  have ha : (28650 : ℝ)/100000 < Real.exp (-(5/4 : ℝ)) := by linarith
  have hb : Real.exp (-(3/2 : ℝ)) < (22314 : ℝ)/100000 := by linarith
  have h₁ : (433 : ℝ)/100*(28650/100000) < A*Real.exp (-(5/4 : ℝ)) := by
    calc
      _ ≤ A*(28650/100000) := mul_le_mul_of_nonneg_right hA₁.le (by norm_num)
      _ < _ := mul_lt_mul_of_pos_left ha hA
  have h₂ : (A-1)*Real.exp (-(3/2 : ℝ)) ≤ (334 : ℝ)/100*(22314/100000) := by
    calc
      _ ≤ (A-1)*(22314/100000) := mul_le_mul_of_nonneg_left hb.le hAm
      _ ≤ _ := mul_le_mul_of_nonneg_right (by dsimp [A]; linarith [hA₂]) (by norm_num)
  have h₃ : (A-1)*(5*Real.exp (-(3/2 : ℝ))-1) ≤ (334 : ℝ)/100*(5*(22314/100000)-1) := by
    calc
      _ ≤ (A-1)*(5*(22314/100000)-1) := mul_le_mul_of_nonneg_left (by linarith) hAm
      _ ≤ _ := mul_le_mul_of_nonneg_right (by dsimp [A]; linarith [hA₂]) (by norm_num)
  apply twoRate_simple_checks (by norm_num : (1 : ℝ)<5) (by norm_num : (5 : ℝ)<6)
  · apply (le_div_iff₀ hρ).mpr
    linarith
  · norm_num
    linarith
  · norm_num
    linarith
  · change (A-1)*((6-1)*Real.exp (-6*(1/4))-1) ≤ twoRateG A 5 6 (1/4)
    norm_num [twoRateG]
    nlinarith [h₁,h₂,h₃]

-- @paper-step thm:pid_two_rate_optimum/balanced_exact_parameter_witness
theorem balanced_twoRate_data :
    TwoRateData (8/5) (pidRho (8/5) (1/4) 5 6)
      (pidLead (8/5) (1/4) 5 (pidRho (8/5) (1/4) 5 6)) 5 6 (1/4) := by
  obtain ⟨hρ₁,hρ₂⟩ := balanced_rho_bounds
  obtain ⟨hell₁,hell₂⟩ := balanced_lead_bounds
  obtain ⟨ha₁,ha₂,hb₁,hb₂⟩ := balanced_exp_bounds
  have hρ : 0 < pidRho (8/5) (1/4) 5 6 := by linarith
  apply twoRate_data_from_formulas (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  · norm_num
    exact ne_of_gt (by linarith)
  · exact hρ
  · linarith
  · linarith
  · apply (le_div_iff₀ hρ).mpr
    linarith
  · apply (div_le_iff₀ hρ).mpr
    norm_num
    linarith
  · exact balanced_forcing_check

end MIACE
