import MIACE.Quadratic

/-! Complete order-theoretic Pareto classification of the explicit energy
formulas. The integral-energy identification is tracked separately. -/
namespace MIACE
noncomputable def paretoBoundary (E : ℝ) : ℝ := E + 1 / (4*E) - 1
noncomputable def sameTrackingGain (x r : ℝ) : ℝ := x*(1+x)/(x+r)
def EnergyEfficient (x r : ℝ) : Prop :=
  ∀ y s : ℝ, 0 < y → 0 < s → tracking y s ≤ tracking x r →
    effort y s ≤ effort x r → tracking y s = tracking x r ∧ effort y s = effort x r

-- @paper-step thm:l2_pareto/tracking_positive
theorem tracking_positive {x r : ℝ} (hx : 0 < x) (hr : 0 < r) :
    0 < tracking x r := by unfold tracking; positivity

-- @paper-step thm:l2_pareto/same_tracking_controller
theorem same_tracking_controller {x r : ℝ} (hx : 0 < x) (hr : 0 < r) :
    0 < sameTrackingGain x r ∧
    tracking (sameTrackingGain x r) 1 = tracking x r ∧
    effort (sameTrackingGain x r) 1 = paretoBoundary (tracking x r) := by
  have hg : 0 < sameTrackingGain x r := by unfold sameTrackingGain; positivity
  refine ⟨hg, ?_, ?_⟩
  · rw [(cancellation_energies _ hg).1]
    unfold sameTrackingGain tracking
    field_simp <;> ring
  · rw [(cancellation_energies _ hg).2]
    unfold sameTrackingGain tracking paretoBoundary
    have : x + r ≠ 0 := ne_of_gt (add_pos hx hr)
    have : 1 + x ≠ 0 := ne_of_gt (by linarith : 0 < 1+x)
    field_simp <;> ring

-- @paper-step thm:l2_pareto/strict_domination
theorem same_tracking_strict {x r : ℝ} (hx : 0 < x) (hr : 0 < r) (hr1 : r ≠ 1) :
    effort (sameTrackingGain x r) 1 < effort x r := by
  rw [(same_tracking_controller hx hr).2.2]
  have he := tracking_positive hx hr
  have h := pareto_residual x r hx hr
  have hp : 0 < x*(r-1)^2/(r*(1+x)^2) := by
    exact div_pos (mul_pos hx (sq_pos_of_ne_zero (sub_ne_zero.mpr hr1))) (by positivity)
  unfold paretoBoundary
  have hdiv : 1/(4*tracking x r) < effort x r + 1 - tracking x r :=
    (div_lt_iff₀ (by positivity : 0 < 4*tracking x r)).2 (by nlinarith)
  linarith

-- @paper-step thm:l2_pareto/boundary_strict_decrease
theorem pareto_boundary_strict {a b : ℝ} (ha : 0 < a) (hab : a < b) (hb : b ≤ 1/2) :
    paretoBoundary b < paretoBoundary a := by
  have hb0 : 0 < b := ha.trans hab
  have hid : paretoBoundary a - paretoBoundary b = (b-a)*(1-4*a*b)/(4*a*b) := by
    unfold paretoBoundary
    field_simp <;> ring
  have hab1 : 4*a*b < 1 := by
    nlinarith [mul_lt_mul_of_pos_right hab hb0, sq_nonneg (b-1/2)]
  have hp : 0 < (b-a)*(1-4*a*b)/(4*a*b) := by positivity
  linarith

-- @paper-step thm:l2_pareto/cancellation_boundary
theorem cancellation_boundary {x : ℝ} (hx : 0 < x) :
    effort x 1 = paretoBoundary (tracking x 1) := by
  rw [(cancellation_energies x hx).1,(cancellation_energies x hx).2]
  unfold paretoBoundary
  field_simp <;> ring

-- @paper-step thm:l2_pareto/subunit_domination
theorem subunit_gain_dominated {x : ℝ} (hx : 0 < x) (hx1 : x < 1) :
    tracking 1 1 < tracking x 1 ∧ effort 1 1 ≤ effort x 1 := by
  rw [(cancellation_energies x hx).1,(cancellation_energies x hx).2]
  have he1 : tracking 1 1 = 1/2 := by norm_num [tracking]
  have hu1 : effort 1 1 = 0 := by norm_num [effort]
  rw [he1,hu1]
  constructor
  · exact (lt_div_iff₀ (by positivity : 0 < 2*x)).2 (by linarith)
  · positivity

-- @paper-step thm:l2_pareto/complete_efficiency
theorem energy_efficient_iff {x r : ℝ} (hx : 0 < x) (hr : 0 < r) :
    EnergyEfficient x r ↔ r = 1 ∧ 1 ≤ x := by
  constructor
  · intro h
    have hr1 : r = 1 := by
      by_contra hn
      obtain ⟨hg,he,hu⟩ := same_tracking_controller hx hr
      have hs := same_tracking_strict hx hr hn
      have hh := h _ 1 hg zero_lt_one he.le hs.le
      linarith [hh.2]
    subst r
    refine ⟨rfl,?_⟩
    by_contra hn
    have hd := subunit_gain_dominated hx (lt_of_not_ge hn)
    have hh := h 1 1 zero_lt_one zero_lt_one hd.1.le hd.2
    linarith [hh.1]
  · rintro ⟨rfl,hx1⟩ y s hy hs he hu
    have hE := tracking_positive hx zero_lt_one
    have hY := tracking_positive hy hs
    have hbound : tracking x 1 ≤ 1/2 := by
      rw [(cancellation_energies x hx).1]
      apply (div_le_iff₀ (by positivity : 0 < 2*x)).2
      linarith
    have heq : tracking y s = tracking x 1 := by
      by_contra hn
      have ht := pareto_boundary_strict hY (lt_of_le_of_ne he hn) hbound
      have hb := pareto_lower_boundary y s hy hs
      change paretoBoundary (tracking y s) ≤ effort y s at hb
      rw [cancellation_boundary hx] at hu
      linarith
    refine ⟨heq, le_antisymm hu ?_⟩
    rw [cancellation_boundary hx,← heq]
    exact pareto_lower_boundary y s hy hs

-- @paper-step thm:l2_pareto/assembled_formula_classification
theorem formula_pareto_front {x r : ℝ} (hx : 0 < x) (hr : 0 < r) :
    (4*tracking x r*(effort x r+1-tracking x r)-1 = x*(r-1)^2/(r*(1+x)^2)) ∧
    paretoBoundary (tracking x r) ≤ effort x r ∧
    (EnergyEfficient x r ↔ r=1 ∧ 1≤x) :=
  ⟨pareto_residual x r hx hr,pareto_lower_boundary x r hx hr,energy_efficient_iff hx hr⟩
-- @paper-step thm:l2_pareto/strict_convexity
theorem pareto_boundary_strict_convex (a b θ : ℝ) (ha : 0 < a) (hb : 0 < b)
    (hθ : 0 < θ) (hθ1 : θ < 1) (hab : a ≠ b) :
    paretoBoundary (θ*a+(1-θ)*b) < θ*paretoBoundary a+(1-θ)*paretoBoundary b := by
  have hm : 0 < θ*a+(1-θ)*b := by positivity
  have hid : θ*paretoBoundary a+(1-θ)*paretoBoundary b-paretoBoundary (θ*a+(1-θ)*b) =
      θ*(1-θ)*(a-b)^2/(4*a*b*(θ*a+(1-θ)*b)) := by
    unfold paretoBoundary
    field_simp
    <;> ring
  have hp : 0 < θ*(1-θ)*(a-b)^2/(4*a*b*(θ*a+(1-θ)*b)) := by
    apply div_pos
    · exact mul_pos (mul_pos hθ (sub_pos.mpr hθ1)) (sq_pos_of_ne_zero (sub_ne_zero.mpr hab))
    · positivity
  linarith

-- @paper-step thm:l2_pareto/positive_weight_support
theorem efficient_gain_weight (x : ℝ) (hx : 1 < x) :
    0 < x^2-1 ∧ ∀ y r : ℝ, 0 < y → 0 < r →
      (quadratic (x^2-1) y r = x-1 ↔ y=x ∧ r=1) := by
  refine ⟨by nlinarith,?_⟩
  intro y r hy hr
  exact quadratic_equality_iff _ x y r hy hr (by linarith) (by ring)
end MIACE
