import MIACE.Dynamics

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def miace (α : ℝ) (e v : ℝ → ℝ) (μ : Measure ℝ) : ℝ :=
  Real.sqrt (costSq α (absArea e μ) (absArea v μ))
noncomputable def minimum (α : ℝ) : ℝ := Real.sqrt (α/(1+α))
noncomputable def peak (e : ℝ → ℝ) (s : Set ℝ) : ℝ :=
  sSup ((fun t => max (-e t) 0) '' s)

-- @paper-step thm:miace_variation/square_root
 theorem area_sum_le_ratio (α Ae Au : ℝ) (hα : 0 < α) (he : 0 ≤ Ae) (hu : 0 ≤ Au) :
    Ae + Au ≤ Real.sqrt (costSq α Ae Au) / minimum α := by
  have hc : 0 ≤ costSq α Ae Au := by unfold costSq; positivity
  have hb : 0 < α/(1+α) := by positivity
  have hm : 0 < minimum α := Real.sqrt_pos.mpr hb
  have hm2 : (minimum α)^2 = α/(1+α) := Real.sq_sqrt hb.le
  have hM2 := Real.sq_sqrt hc
  have hd := weighted_decomposition α Ae Au hα
  have hr : 0 ≤ (Ae-α*Au)^2/(1+α) := by positivity
  have hs : (minimum α * (Ae+Au))^2 ≤ (Real.sqrt (costSq α Ae Au))^2 := by
    rw [mul_pow, hm2, hM2]
    linarith
  have hl : minimum α * (Ae+Au) ≤ Real.sqrt (costSq α Ae Au) :=
    (sq_le_sq₀ (by positivity) (Real.sqrt_nonneg _)).mp hs
  apply (le_div_iff₀ hm).2
  nlinarith

-- @paper-step thm:miace_variation/complete_chain
 theorem response_variation_chain {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (α : ℝ) (hα : 0 < α) :
    1 ≤ absArea (e+v) halfLine ∧
    absArea (e+v) halfLine ≤ absArea e halfLine + absArea v halfLine ∧
    absArea e halfLine + absArea v halfLine ≤ miace α e v halfLine / minimum α := by
  refine ⟨?_, absolute_area_add_le h.error_integrable h.command_integrable, ?_⟩
  · have hn := negative_area_nonneg (μ := halfLine) (e+v)
    have hi := response_variation_identity h
    change absArea (e+v) halfLine = 1 + 2 * negArea (e+v) halfLine at hi
    linarith
  · apply area_sum_le_ratio α _ _ hα
    all_goals exact integral_nonneg (fun t => abs_nonneg _)

-- @paper-step thm:miace_variation/finite_decrease
 theorem response_decrease_bound {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    {a b : ℝ} (ha : 0 ≤ a) (hab : a ≤ b) :
    e b-e a ≤ ∫ t in a..b, max (-(e t+v t)) 0 := by
  have hsub : Ioc a b ⊆ Ioi (0 : ℝ) := fun _ ht => lt_of_le_of_lt ha ht.1
  have hq : Integrable (e+v) halfLine := h.error_integrable.add h.command_integrable
  have hn := negative_part_integrable hq
  have h1 : IntervalIntegrable (fun t => -(e t+v t)) volume a b :=
    (intervalIntegrable_iff_integrableOn_Ioc_of_le hab).mpr (IntegrableOn.mono_set hq.neg hsub)
  have h2 : IntervalIntegrable (fun t => max (-(e t+v t)) 0) volume a b :=
    (intervalIntegrable_iff_integrableOn_Ioc_of_le hab).mpr (IntegrableOn.mono_set hn hsub)
  have hm := intervalIntegral.integral_mono hab h1 h2 (fun t => le_max_left (-(e t+v t)) 0)
  rw [intervalIntegral.integral_neg, response_increment h ha hab] at hm
  linarith

-- @paper-step thm:miace_variation/pointwise_peak
 theorem response_pointwise_peak {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    {t : ℝ} (ht : 0 ≤ t) : max (-e t) 0 ≤ negArea (e+v) halfLine := by
  have hq := negative_part_integrable (h.error_integrable.add h.command_integrable)
  have bound : ∀ᶠ b : ℝ in atTop, e b-e t ≤ negArea (e+v) halfLine := by
    filter_upwards [eventually_ge_atTop t] with b hb
    have hd := response_decrease_bound h ht hb
    have hi : (∫ s in t..b, max (-(e s+v s)) 0) ≤ negArea (e+v) halfLine := by
      rw [intervalIntegral.integral_of_le hb]
      apply setIntegral_mono_set hq
      · exact ae_of_all _ (fun s => le_max_right _ _)
      · exact Eventually.of_forall (fun s hs => lt_of_le_of_lt ht hs.1)
    exact hd.trans hi
  have hl : -e t ≤ negArea (e+v) halfLine := by
    have hh := le_of_tendsto (h.finalValue.sub_const (e t)) bound
    simpa using hh
  exact max_le hl (negative_area_nonneg _)

-- @paper-step thm:miace_variation/peak
 theorem response_peak_bound {e v : ℝ → ℝ} (h : FirstOrderResponse e v) :
    peak e (Ici 0) ≤ negArea (e+v) halfLine := by
  apply csSup_le
  · exact ⟨max (-e 0) 0, 0, by simp, rfl⟩
  · rintro z ⟨t,ht,rfl⟩
    exact response_pointwise_peak h ht

-- @paper-step thm:miace_variation/miace_peak_bound
 theorem response_peak_miace {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (α : ℝ) (hα : 0 < α) :
    peak e (Ici 0) ≤ (miace α e v halfLine / minimum α - 1)/2 := by
  have hp := response_peak_bound h
  have hi := response_variation_identity h
  have hc := response_variation_chain h α hα
  change absArea (e+v) halfLine = 1+2*negArea (e+v) halfLine at hi
  linarith [hc.2.1, hc.2.2]

-- @paper-step prop:finite_miace_shape/endpoint_decrease
 theorem finite_pointwise_peak {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    {H t : ℝ} (ht : 0 ≤ t) (htH : t ≤ H) :
    max (-e t) 0 ≤ max (-e H) 0 + negArea (e+v) (volume.restrict (Ioc 0 H)) := by
  have hd := response_decrease_bound h ht htH
  have hH : 0 ≤ H := ht.trans htH
  have hq := negative_part_integrable (h.error_integrable.add h.command_integrable)
  have hqi : IntervalIntegrable (fun s => max (-(e s+v s)) 0) volume 0 H :=
    (intervalIntegrable_iff_integrableOn_Ioc_of_le hH).mpr
      (IntegrableOn.mono_set hq (fun _ hs => hs.1))
  have hmono := intervalIntegral.integral_mono_interval ht htH le_rfl
    (ae_of_all _ (fun s => le_max_right (-(e s+v s)) 0)) hqi
  have hB : 0 ≤ negArea (e+v) (volume.restrict (Ioc 0 H)) := negative_area_nonneg _
  rw [intervalIntegral.integral_of_le hH] at hmono
  change (∫ s in t..H, max (-(e s+v s)) 0) ≤ negArea (e+v) (volume.restrict (Ioc 0 H)) at hmono
  apply max_le
  · have hm := le_max_left (-e H) (0 : ℝ)
    linarith
  · exact add_nonneg (le_max_right _ _) hB

-- @paper-step prop:finite_miace_shape/finite_variation
 theorem finite_variation_identity {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    {H : ℝ} (hH : 0 ≤ H) :
    absArea (e+v) (volume.restrict (Ioc 0 H)) =
      1-e H + 2*negArea (e+v) (volume.restrict (Ioc 0 H)) := by
  have hq : Integrable (e+v) (volume.restrict (Ioc 0 H)) :=
    IntegrableOn.mono_set (h.error_integrable.add h.command_integrable) (fun _ hs => hs.1)
  rw [absolute_area_identity hq]
  have hi := response_increment h le_rfl hH
  rw [h.initial, intervalIntegral.integral_of_le hH] at hi
  change (∫ t in Ioc 0 H, (e+v) t) = 1-e H at hi
  rw [hi]

-- @paper-step prop:finite_miace_shape/record
 theorem finite_record_certificate {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (α H : ℝ) (hα : 0 < α) (hH : 0 ≤ H) :
    peak e (Icc 0 H) ≤
      (miace α e v (volume.restrict (Ioc 0 H)) / minimum α - 1 + |e H|)/2 := by
  have he := IntegrableOn.mono_set h.error_integrable (show Ioc 0 H ⊆ Ioi (0 : ℝ) from fun _ hs => hs.1)
  have hv := IntegrableOn.mono_set h.command_integrable (show Ioc 0 H ⊆ Ioi (0 : ℝ) from fun _ hs => hs.1)
  have htri := absolute_area_add_le he hv
  have hsum := area_sum_le_ratio α (absArea e (volume.restrict (Ioc 0 H)))
    (absArea v (volume.restrict (Ioc 0 H))) hα
    (integral_nonneg (fun _ => abs_nonneg _)) (integral_nonneg (fun _ => abs_nonneg _))
  have hvar := finite_variation_identity h hH
  have habs := abs_eq_self_add_neg (e H)
  apply csSup_le
  · exact ⟨max (-e 0) 0, 0, ⟨le_rfl,hH⟩, rfl⟩
  · rintro z ⟨t,ht,rfl⟩
    have hp := finite_pointwise_peak h ht.1 ht.2
    change absArea (e+v) (volume.restrict (Ioc 0 H)) ≤ _ at htri
    change absArea e (volume.restrict (Ioc 0 H)) + absArea v (volume.restrict (Ioc 0 H)) ≤
      miace α e v (volume.restrict (Ioc 0 H)) / minimum α at hsum
    linarith

-- @paper-step prop:finite_miace_shape/record_tolerances
 theorem finite_record_tolerances {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (α H ε εe : ℝ) (hα : 0 < α) (hH : 0 ≤ H)
    (hm : miace α e v (volume.restrict (Ioc 0 H)) ≤ (1+ε)*minimum α)
    (he : |e H| ≤ εe) : peak e (Icc 0 H) ≤ (ε+εe)/2 := by
  have hp := finite_record_certificate h α H hα hH
  have hmin : 0 < minimum α := Real.sqrt_pos.mpr (by positivity)
  have hr := (div_le_iff₀ hmin).mpr hm
  linarith

-- @paper-step thm:miace_variation/near_optimal_response
 theorem response_near_optimal {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (α ε : ℝ) (hα : 0 < α) (hm : miace α e v halfLine ≤ (1+ε)*minimum α) :
    absArea (e+v) halfLine-1 ≤ ε ∧
    negArea (e+v) halfLine ≤ ε/2 ∧
    peak e (Ici 0) ≤ ε/2 ∧
    negArea e halfLine+negArea v halfLine ≤ ε/2 := by
  have hp := response_peak_bound h
  have hB := response_backward_le_negative_area h
  change negArea (e+v) halfLine ≤ negArea e halfLine+negArea v halfLine at hB
  have hvar := response_variation_identity h
  have hbal := area_balance h.error_integrable h.command_integrable 1 (response_signed_balance h)
  have hc := (response_variation_chain h α hα).2.2
  have hmin : 0 < minimum α := Real.sqrt_pos.mpr (by positivity)
  have hr := (div_le_iff₀ hmin).mpr hm
  change absArea (e+v) halfLine = 1+2*negArea (e+v) halfLine at hvar
  refine ⟨?_,?_,?_,?_⟩ <;> linarith

-- @paper-step prop:finite_miace_shape/maximum_attained
 theorem finite_peak_attained {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (H : ℝ) (hH : 0 ≤ H) :
    ∃ t ∈ Icc 0 H, peak e (Icc 0 H) = max (-e t) 0 := by
  have hc := (h.ac H hH).continuousOn
  rw [uIcc_of_le hH] at hc
  have hf : ContinuousOn (fun t => max (-e t) 0) (Icc 0 H) := hc.neg.sup continuousOn_const
  obtain ⟨t,ht,hmax⟩ := isCompact_Icc.exists_isMaxOn ⟨0,le_rfl,hH⟩ hf
  refine ⟨t,ht,?_⟩
  unfold peak
  apply le_antisymm
  · refine csSup_le (s := (fun s => max (-e s) 0) '' Icc 0 H) ?_ ?_
    · exact ⟨max (-e t) 0,t,ht,rfl⟩
    · rintro z ⟨s,hs,rfl⟩
      exact hmax hs
  · apply le_csSup
    · refine ⟨max (-e t) 0,?_⟩
      rintro z ⟨s,hs,rfl⟩
      exact hmax hs
    · exact ⟨t,ht,rfl⟩

end MIACE
