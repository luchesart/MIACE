import MIACE.Crossing
import MIACE.Delay
import MIACE.Transfer
import Mathlib.MeasureTheory.Measure.OpenPos

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:n_monotonic/state_continuity
theorem lag_response_continuous {σ : ℝ} {u x : ℝ → ℝ} (h : LagResponse σ u x) :
    ContinuousOn x (Ioi 0) := by
  intro t ht
  have hT : 0 ≤ t+1 := by linarith [show 0 < t from ht]
  have hc : ContinuousOn x (Icc 0 (t+1)) := by
    simpa [uIcc_of_le hT] using (h.ac (t+1) hT).continuousOn
  exact (hc.continuousAt (Icc_mem_nhds ht (by linarith))).continuousWithinAt

-- @paper-step thm:n_monotonic/ae_to_pointwise
theorem lag_ae_upper_bound {σ : ℝ} {u x : ℝ → ℝ} (h : LagResponse σ u x)
    (he : ∀ᵐ t ∂halfLine, x t ≤ 1) : ∀ t : ℝ, 0 ≤ t → x t ≤ 1 := by
  have hc := lag_response_continuous h
  have heq : (fun t => min (x t) 1) =ᵐ[halfLine] x := by
    filter_upwards [he] with t ht
    exact min_eq_left ht
  have hp := MeasureTheory.Measure.eqOn_open_of_ae_eq heq isOpen_Ioi (hc.inf continuousOn_const) hc
  intro t ht
  rcases ht.eq_or_lt with h0 | ht
  · rw [← h0,h.initial]; norm_num
  · have hh := hp ht
    exact hh ▸ min_le_right (x t) 1

-- @paper-step thm:n_monotonic/remove_wait_from_sign
theorem undelayed_error_nonnegative {δ : ℝ} (hδ : 0 ≤ δ) {f : ℝ → ℝ}
    (he : ∀ᵐ t ∂halfLine, 0 ≤ delayedError δ f t) : ∀ᵐ t ∂halfLine, 0 ≤ f t := by
  have hsub : Ioi δ ⊆ Ioi (0 : ℝ) := fun t ht => lt_of_le_of_lt hδ ht
  have hh := (translate_halfLine δ).quasiMeasurePreserving.ae
    (ae_restrict_of_ae_restrict_of_subset hsub he)
  filter_upwards [hh,ae_restrict_mem measurableSet_Ioi] with t ht htpos
  have hnot : ¬ t+δ ≤ δ := by linarith [show 0 < t from htpos]
  simpa [delayedError,hnot] using ht

-- @paper-step thm:n_monotonic/clipping_to_monotonicity
theorem unclipped_monotone {x : ℝ → ℝ} (hm : ClippedMonotone x)
    (hb : ∀ t : ℝ, 0 ≤ t → x t ≤ 1) : MonotoneOn x (Ici 0) := by
  intro a ha b hb0 hab
  have hh := hm ha hb0 hab
  change min (x a) 1 ≤ min (x b) 1 at hh
  simpa [min_eq_left (hb a ha),min_eq_left (hb b hb0)] using hh

-- @paper-step thm:n_monotonic/restored_delay_monotonicity
theorem cascade_delayed_monotone {δ : ℝ} {x : ℝ → ℝ}
    (hm : MonotoneOn x (Ici 0)) (hn : ∀ t : ℝ, 0 ≤ t → 0 ≤ x t) :
    Monotone (fun t => 1-delayedError δ (fun s => 1-x s) t) := by
  intro a b hab
  by_cases ha : a ≤ δ
  · by_cases hb : b ≤ δ
    · simp [delayedError,ha,hb]
    · have hx := hn (b-δ) (by linarith)
      simp [delayedError,ha,hb]
      exact hx
  · have hb : ¬ b ≤ δ := by linarith
    simp only [delayedError,ha,hb,ite_false,sub_sub_cancel]
    exact hm (by linarith : 0 ≤ a-δ) (by linarith : 0 ≤ b-δ) (by linarith)

-- @paper-step thm:n_monotonic/full_statement
theorem paper_cascade_shape (N : ℕ) (σ : ℕ → ℝ) (x : ℕ → ℝ → ℝ)
    {v H : ℝ → ℝ} (δ α μ : ℝ) (hδ : 0 ≤ δ) (hα : 0 < α) (hS : 0 < μ+δ)
    (hσ : ∀ j ≤ N, 0 < σ j)
    (hx : ∀ j ≤ N, LagResponse (σ j) (x j) (x (j+1)))
    (hw : x 0 = fun t => 1+v t)
    (hfinal : Tendsto (x (N+1)) atTop (𝓝 1))
    (hT : TransferResponse (delayedError δ (fun t => 1-x (N+1) t)) v H δ)
    (hH : HasDerivAt H (-μ) 0) (h0 : H 0 = 1)
    (hopt : miace α (delayedError δ (fun t => 1-x (N+1) t)) v halfLine =
      (μ+δ)*minimum α) :
    let e := delayedError δ (fun t => 1-x (N+1) t)
    Monotone (fun t => 1-e t) ∧ (1-e 0 = 0) ∧
    Tendsto (fun t => 1-e t) atTop (𝓝 1) ∧
    (∀ t : ℝ, 0 ≤ 1-e t ∧ 1-e t ≤ 1) ∧
    (∀ t : ℝ, 0 ≤ deriv (fun s => 1-e s) t) ∧ backwardMotion e = 0 := by
  dsimp only
  obtain ⟨he,hv,hr⟩ := (signal_miace_equality_iff hT.error_integrable hT.command_integrable
    α (μ+δ) hα hS (transfer_signed_balance hT μ hH h0)).mp hopt
  have hw1 : ∀ᵐ t ∂halfLine, 1 ≤ x 0 t := by
    rw [hw]
    filter_upwards [hv] with t ht
    linarith
  have hcs := cascade_clipped_monotone (N+1) σ x (fun j hj => hσ j (by omega))
    (fun j hj => hx j (by omega)) hw1 N (by omega)
  have hf := undelayed_error_nonnegative hδ he
  have hupper : ∀ t : ℝ, 0 ≤ t → x (N+1) t ≤ 1 := by
    apply lag_ae_upper_bound (hx N le_rfl)
    filter_upwards [hf] with t ht
    linarith
  have hm := cascade_delayed_monotone (δ := δ) (unclipped_monotone hcs.2 hupper) hcs.1
  refine ⟨hm,by simp [delayedError,hδ],?_,?_,fun t => hm.deriv_nonneg,?_⟩
  · have hshift : Tendsto (fun t : ℝ => t-δ) atTop atTop := by
      apply tendsto_atTop.2
      intro b
      filter_upwards [eventually_ge_atTop (b+δ)] with t ht
      linarith
    apply (hfinal.comp hshift).congr'
    filter_upwards [eventually_gt_atTop δ] with t ht
    simp [delayedError,not_le.mpr ht]
  · intro t
    by_cases ht : t ≤ δ
    · simp [delayedError,ht]
    · simp only [delayedError,ht,ite_false,sub_sub_cancel]
      exact ⟨hcs.1 (t-δ) (by linarith),hupper (t-δ) (by linarith)⟩
  · unfold backwardMotion negArea
    apply integral_eq_zero_of_ae
    exact Eventually.of_forall (fun t => max_eq_right (neg_nonpos.mpr hm.deriv_nonneg))
end MIACE
