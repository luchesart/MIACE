import MIACE.PIDReduction

/-! Етап 11: произволна транспортна история като краен входен импулс.
    Историята е нужна само върху [-δ,0]; бъдещите стойности не участват.
    Непрекъснатостта е зададена за избрано продължение на историята. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

noncomputable def historyInput (δ : ℝ) (w : ℝ → ℝ) : ℝ → ℝ :=
  (Ico 0 δ).indicator (fun t => w (t-δ))

-- @paper-step thm:pid_two_rate_optimum/transport_history_support
theorem historyInput_support (δ : ℝ) (w : ℝ → ℝ) (t : ℝ)
    (ht : t<0 ∨ δ≤t) : historyInput δ w t=0 := by
  simp only [historyInput]
  apply indicator_of_notMem
  intro hm
  rcases ht with ht | ht
  · linarith [hm.1]
  · linarith [hm.2]

-- @paper-step thm:pid_two_rate_optimum/transport_history_causal
theorem historyInput_causal (δ : ℝ) (w : ℝ → ℝ) : Causal (historyInput δ w) := by
  exact ae_of_all _ (fun t ht => historyInput_support δ w t (Or.inl ht))

-- @paper-step thm:pid_two_rate_optimum/transport_history_locality
theorem historyInput_congr {δ : ℝ} {v w : ℝ → ℝ}
    (h : ∀ s∈Icc (-δ) 0, v s=w s) : historyInput δ v=historyInput δ w := by
  funext t
  by_cases ht : t∈Ico (0 : ℝ) δ
  · simp only [historyInput,indicator_of_mem ht]
    exact h (t-δ) ⟨by linarith [ht.1],by linarith [ht.2]⟩
  · simp [historyInput,ht]

-- @paper-step thm:pid_two_rate_optimum/exact_delay_history_split
theorem historyInput_split (δ : ℝ) (w : ℝ → ℝ) {t : ℝ} (ht : 0≤t) :
    w (t-δ)=historyInput δ w t+causalize w (t-δ) := by
  by_cases htd : t<δ
  · have hi : t∈Ico (0 : ℝ) δ := ⟨ht,htd⟩
    simp [historyInput,indicator_of_mem hi,causalize,show ¬0≤t-δ by linarith]
  · have hi : t∉Ico (0 : ℝ) δ := by simp [htd]
    simp [historyInput,indicator_of_notMem hi,causalize,show 0≤t-δ by linarith]

-- @paper-step thm:pid_two_rate_optimum/history_weighted_integrability
theorem historyInput_weighted_integrable {w : ℝ → ℝ} (hw : Continuous w) (δ η : ℝ) :
    Integrable (expWeight η (historyInput δ w)) := by
  have he : expWeight η (historyInput δ w)=
      (Ico 0 δ).indicator (fun t => Real.exp (η*t)*w (t-δ)) := by
    funext t
    by_cases ht : t∈Ico (0 : ℝ) δ <;> simp [expWeight,historyInput,ht]
  rw [he]
  apply compact_indicator_integrable
  exact (by fun_prop : Continuous (fun t : ℝ => Real.exp (η*t))).mul
    (hw.comp (continuous_id.sub continuous_const))

-- @paper-step thm:pid_two_rate_optimum/history_weighted_norm_bound
theorem historyInput_weighted_bound {w : ℝ → ℝ} (hw : Continuous w)
    {δ η B : ℝ} (hδ : 0≤δ) (hη : 0≤η) (hB : 0≤B)
    (hb : ∀ s∈Icc (-δ) 0, |w s|≤B) :
    (∫ t, |expWeight η (historyInput δ w) t|) ≤ δ*Real.exp (η*δ)*B := by
  let F : ℝ → ℝ := (Ico 0 δ).indicator (fun _ => Real.exp (η*δ)*B)
  have hF : Integrable F := compact_indicator_integrable continuous_const δ
  have hle : ∀ t, |expWeight η (historyInput δ w) t|≤F t := by
    intro t
    by_cases ht : t∈Ico (0 : ℝ) δ
    · simp only [expWeight,historyInput,F,indicator_of_mem ht,abs_mul,
        abs_of_pos (Real.exp_pos _)]
      exact mul_le_mul (Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_left ht.2.le hη))
        (hb (t-δ) ⟨by linarith [ht.1],by linarith [ht.2]⟩)
        (abs_nonneg _) (Real.exp_nonneg _)
    · simp [expWeight,historyInput,F,ht]
  have hn := integral_mono (historyInput_weighted_integrable hw δ η).abs hF hle
  have he : (∫ t, F t)=δ*Real.exp (η*δ)*B := by
    rw [show F=(Ico 0 δ).indicator (fun _ : ℝ => Real.exp (η*δ)*B) from rfl,
      integral_indicator measurableSet_Ico,integral_Ico_eq_integral_Ioc,
      ← intervalIntegral.integral_of_le hδ,intervalIntegral.integral_const]
    simp only [sub_zero,smul_eq_mul]
    ring
  exact he ▸ hn

-- @paper-step thm:pid_two_rate_optimum/history_pointwise_exponential_bound
theorem historyInput_decay {w : ℝ → ℝ} {δ η B : ℝ}
    (hη : 0≤η) (hB : 0≤B) (hb : ∀ s∈Icc (-δ) 0, |w s|≤B)
    {t : ℝ} (ht : 0≤t) :
    |historyInput δ w t|≤(Real.exp (η*δ)*B)*Real.exp (-η*t) := by
  by_cases hi : t∈Ico (0 : ℝ) δ
  · rw [historyInput,indicator_of_mem hi]
    have he : 1≤Real.exp (η*δ)*Real.exp (-η*t) := by
      rw [← Real.exp_add]
      exact Real.one_le_exp_iff.mpr (by nlinarith [hi.2])
    have hh := hb (t-δ) ⟨by linarith [hi.1],by linarith [hi.2]⟩
    nlinarith
  · simp only [historyInput,indicator_of_notMem hi,abs_zero]
    positivity

-- @paper-step thm:pid_two_rate_optimum/physical_command_history_gain
theorem pidHomogeneousCommand_bound (pc i dc ρ : ℝ) {M : ℝ} (hM : 0≤M)
    (x : Fin 3 → ℝ) (hx : ∀ k, |x k|≤M) :
    |pidHomogeneousCommand pc i dc ρ x|≤(|pc+dc/ρ|+|i|+|dc/ρ|)*M := by
  have he : pidHomogeneousCommand pc i dc ρ x=
      -(pc+dc/ρ)*x 0+i*x 1-(dc/ρ)*x 2 := by unfold pidHomogeneousCommand; ring
  rw [he]
  have h₁ := mul_le_mul_of_nonneg_left (hx 0) (abs_nonneg (pc+dc/ρ))
  have h₂ := mul_le_mul_of_nonneg_left (hx 1) (abs_nonneg i)
  have h₃ := mul_le_mul_of_nonneg_left (hx 2) (abs_nonneg (dc/ρ))
  have ha := abs_sub_le (-(pc+dc/ρ)*x 0+i*x 1) 0 ((dc/ρ)*x 2)
  have hb := abs_add_le (-(pc+dc/ρ)*x 0) (i*x 1)
  simp only [sub_zero,zero_sub,abs_neg,abs_mul] at ha hb
  nlinarith

-- @paper-step thm:pid_two_rate_optimum/physical_history_weighted_gain
theorem pid_history_weighted_bound (pc i dc ρ : ℝ) {φ : ℝ → Fin 3 → ℝ}
    (hφ : ∀ k, Continuous (fun t => φ t k)) {δ η M : ℝ}
    (hδ : 0≤δ) (hη : 0≤η) (hM : 0≤M)
    (hb : ∀ s∈Icc (-δ) 0, ∀ k, |φ s k|≤M) :
    (∫ t, |expWeight η (historyInput δ (fun s => pidHomogeneousCommand pc i dc ρ (φ s))) t|)
      ≤ δ*Real.exp (η*δ)*((|pc+dc/ρ|+|i|+|dc/ρ|)*M) := by
  apply historyInput_weighted_bound _ hδ hη (by positivity)
  · intro s hs
    exact pidHomogeneousCommand_bound pc i dc ρ hM (φ s) (hb s hs)
  · unfold pidHomogeneousCommand
    exact (((hφ 0).const_mul _).add ((hφ 1).const_mul _)).add
      (((hφ 0).neg.sub (hφ 2)).const_mul _)

end MIACE
