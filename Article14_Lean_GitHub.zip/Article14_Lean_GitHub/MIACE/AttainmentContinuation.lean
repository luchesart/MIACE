import MIACE.HalfPlaneLaplace
import MIACE.TwoRateAttainment

/-! Stage 19. Equality in the universal area bound supplies the signs and
exponential bound used for analytic continuation. No cancellation, decay
rate or continued transfer identity is assumed in these lemmas. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step prop:pid_necessary_structure/continuous_sign_from_ae_equality
theorem continuous_halfline_nonneg {f : ℝ → ℝ} (hc : Continuous f)
    (hn : ∀ᵐ t ∂halfLine, 0≤f t) : ∀ t, 0≤t → 0≤f t := by
  have he : (fun t => max (f t) 0)=ᵐ[halfLine] f := hn.mono (fun t ht => max_eq_left ht)
  have hpt := MeasureTheory.Measure.eqOn_open_of_ae_eq he isOpen_Ioi
    (hc.max continuous_const).continuousOn hc.continuousOn
  have hall : EqOn (fun t => max (f t) 0) f (Ici 0) :=
    hpt.of_subset_closure (hc.max continuous_const).continuousOn hc.continuousOn
      Ioi_subset_Ici_self (by rw [closure_Ioi])
  intro t ht
  exact (hall ht) ▸ le_max_right (f t) 0

-- @paper-step prop:pid_necessary_structure/attainment_signs_and_positive_error_area
theorem attaining_firstOrder_signs {E V : ℝ → ℝ} {α δ : ℝ}
    (h : TransferResponse E V (fun p => 1/(1+p)) δ)
    (hcE : Continuous E) (hcV : Continuous V) (hα : 0<α) (hδ : 0≤δ)
    (hcost : miace α E V halfLine=(1+δ)*minimum α) :
    (∀ t, 0≤t → 0≤E t) ∧ (∀ t, 0≤t → 0≤V t) ∧
    (∫ t, E t ∂halfLine)=α*(1+δ)/(1+α) ∧
    0<(∫ t, E t ∂halfLine) := by
  obtain ⟨_,_,_,_,heq,hareas⟩ := paper_general_plant h α 1 hα (by linarith)
    firstOrder_transfer_dc (by norm_num)
  obtain ⟨hEn,hVn,_⟩ := heq.mp hcost
  have hm : absArea E halfLine=(∫ t, E t ∂halfLine) := integral_congr_ae
    (hEn.mono (fun t ht => abs_of_nonneg ht))
  have ha := (hareas hcost).1
  rw [hm] at ha
  exact ⟨continuous_halfline_nonneg hcE hEn,continuous_halfline_nonneg hcV hVn,ha,
    by rw [ha]; positivity⟩

-- @paper-step prop:pid_necessary_structure/attainment_implies_unit_rate_exponential_bound
theorem attaining_error_exp_bound {E V : ℝ → ℝ} {δ : ℝ}
    (h : TransferResponse E V (fun p => 1/(1+p)) δ)
    (hcE : Continuous E) (hcV : Continuous V) (hδ : 0≤δ)
    (hnE : ∀ t, 0≤t → 0≤E t) (hnV : ∀ t, 0≤t → 0≤V t) :
    ∀ t, 0≤t → |E t|≤Real.exp δ*Real.exp (-t) := by
  intro t ht
  rw [abs_of_nonneg (hnE t ht),transfer_firstOrder_realization h hδ hcE hcV t ht]
  rw [← Real.exp_add]
  by_cases hd : t≤δ
  · simp only [delayedError,if_pos hd]
    exact Real.one_le_exp (by linarith)
  · simp only [delayedError,if_neg hd,firstOrderError]
    have hn : 0≤lag 1 V (t-δ) := by
      unfold lag
      apply mul_nonneg (by positivity)
      apply intervalIntegral.integral_nonneg (by linarith : 0≤t-δ)
      intro s hs
      exact mul_nonneg (Real.exp_nonneg _) (hnV s hs.1)
    have he : -(t-δ)=δ+-t := by ring
    rw [he]
    linarith

-- @paper-step prop:pid_necessary_structure/extended_real_transform_integrability
theorem laplace_extended_integrable {E : ℝ → ℝ} (hc : Continuous E) {C : ℝ}
    (hE : ∀ t, 0≤t → |E t|≤C*Real.exp (-t)) {p : ℝ} (hp : -1<p) :
    Integrable (fun t => Real.exp (-p*t)*E t) halfLine := by
  have hi := (halfLaplace_integrable hc hE (p := (p : ℂ)) hp).re
  change Integrable (fun t : ℝ => (Complex.exp (-(p : ℂ)*(t : ℂ))*(E t : ℂ)).re) halfLine at hi
  simpa only [← Complex.ofReal_neg,← Complex.ofReal_mul,← Complex.ofReal_exp,Complex.ofReal_re] using hi

-- @paper-step prop:pid_necessary_structure/positive_lower_bound_for_negative_laplace_parameters
theorem laplace_negative_lower_bound {E : ℝ → ℝ} (hc : Continuous E)
    (hi : Integrable E halfLine) {C : ℝ}
    (hE : ∀ t, 0≤t → |E t|≤C*Real.exp (-t)) (hn : ∀ t, 0≤t → 0≤E t)
    {p : ℝ} (hp : -1<p) (hp0 : p≤0) : (∫ t, E t ∂halfLine)≤laplace E p := by
  apply integral_mono_ae hi (laplace_extended_integrable hc hE hp)
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  have ht0 : 0≤t := (show 0<t from ht).le
  exact le_mul_of_one_le_left (hn t ht0) (Real.one_le_exp (mul_nonneg (neg_nonneg.mpr hp0) ht0))

-- @paper-step prop:pid_necessary_structure/vanishing_numerator_forces_boundary_denominator_zero
theorem laplace_boundary_cancellation {E D N : ℝ → ℝ} (hc : Continuous E)
    (hi : Integrable E halfLine) {C : ℝ}
    (hE : ∀ t, 0≤t → |E t|≤C*Real.exp (-t)) (hn : ∀ t, 0≤t → 0≤E t)
    (hm : 0<(∫ t, E t ∂halfLine))
    (hD : ContinuousAt D (-1)) (hN : ContinuousAt N (-1)) (hN0 : N (-1)=0)
    (he : ∀ p, -1<p → D p*laplace E p=N p) : D (-1)=0 := by
  let p := fun n : ℕ => -1+1/((n : ℝ)+1)
  have hp (n : ℕ) : -1<p n ∧ p n≤0 := by
    have hpos : (0 : ℝ)<1/((n : ℝ)+1) := by positivity
    have hle : (1 : ℝ)/((n : ℝ)+1)≤1 := (div_le_one (by positivity)).mpr (by have := Nat.cast_nonneg (α := ℝ) n; linarith)
    dsimp [p]; constructor <;> linarith
  have hlim : Tendsto p atTop (𝓝 (-1)) := by
    simpa only [add_zero] using (tendsto_one_div_add_atTop_nhds_zero_nat (𝕜 := ℝ)).const_add (-1)
  have hineq (n : ℕ) : |D (p n)| *(∫ t, E t ∂halfLine)≤|N (p n)| := by
    have hL := laplace_negative_lower_bound hc hi hE hn (hp n).1 (hp n).2
    have hLp : 0≤laplace E (p n) := hm.le.trans hL
    rw [← he (p n) (hp n).1,abs_mul,abs_of_nonneg hLp]
    exact mul_le_mul_of_nonneg_left hL (abs_nonneg _)
  have hle := le_of_tendsto_of_tendsto ((hD.tendsto.comp hlim).abs.mul_const (∫ t, E t ∂halfLine))
    (hN.tendsto.comp hlim).abs (Eventually.of_forall hineq)
  rw [hN0,abs_zero] at hle
  have hz : |D (-1)|=0 := le_antisymm (by nlinarith [abs_nonneg (D (-1))]) (abs_nonneg _)
  exact abs_eq_zero.mp hz

end MIACE
