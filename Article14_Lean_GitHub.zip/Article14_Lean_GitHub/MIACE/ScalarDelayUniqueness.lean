import MIACE.ScalarDelaySignals
import MIACE.OrdinaryLag

/-! Uniqueness is among all continuous ordinary responses. A competing
response is not required to be integrable or to decay. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step lem:delayed_cancellation/delayed_zero_history_local_integrability
theorem scalarDelay_shift_local {E : ℝ → ℝ} (hc : Continuous E) (δ : ℝ) :
    LocallyIntegrable (shift δ (causalize E)) volume := by
  have he : shift δ (causalize E)=(Ici δ).indicator (fun t => E (t-δ)) := by
    funext t
    by_cases ht : δ≤t <;> simp [shift,causalize,ht,sub_nonneg]
  rw [he]
  exact (hc.comp (continuous_id.sub continuous_const)).locallyIntegrable.indicator measurableSet_Ici

-- @paper-step lem:delayed_cancellation/unrestricted_ordinary_fundamental_uniqueness
theorem scalarDelay_response_unique {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    {E F : ℝ → ℝ} (hE : ScalarDelayResponse x δ E) (hF : ScalarDelayResponse x δ F) :
    ∀ t, 0≤t → E t=F t := by
  let d := fun t => |E t-F t|
  have hd : Continuous d := (hE.continuous.sub hF.continuous).abs
  have hd0 (t : ℝ) : 0≤d t := abs_nonneg _
  have hEi := locally_integrable_interval (scalarDelay_shift_local hE.continuous δ)
  have hFi := locally_integrable_interval (scalarDelay_shift_local hF.continuous δ)
  have hbound (t : ℝ) (ht : 0≤t) :
      d t≤x*(∫ s in 0..t, d s+d (max 0 (s-δ))) := by
    have he : E t-F t= -x*(∫ s in 0..t,
        shift δ (causalize E) s-shift δ (causalize F) s) := by
      rw [intervalIntegral.integral_sub (hEi 0 t) (hFi 0 t),
        hE.integral_eq t ht,hF.integral_eq t ht]
      ring
    have hpoint (s : ℝ) :
        |shift δ (causalize E) s-shift δ (causalize F) s|≤d s+d (max 0 (s-δ)) := by
      by_cases hs : 0≤s-δ
      · simp only [shift,causalize,indicator_of_mem (show s-δ∈Ici (0 : ℝ) from hs),max_eq_right hs]
        exact le_add_of_nonneg_left (hd0 s)
      · simp only [shift,causalize,indicator_of_notMem (show s-δ∉Ici (0 : ℝ) from hs),
          sub_self,abs_zero]
        exact add_nonneg (hd0 s) (hd0 _)
    have hi := intervalIntegral.integral_mono_on ht ((hEi 0 t).sub (hFi 0 t)).abs
      ((hd.add (hd.comp (continuous_const.max (continuous_id.sub continuous_const)))).intervalIntegrable 0 t)
      (fun s _ => hpoint s)
    have habs := intervalIntegral.norm_integral_le_integral_norm
      (f := fun s => shift δ (causalize E) s-shift δ (causalize F) s) (μ := volume) ht
    simp only [Real.norm_eq_abs] at habs
    dsimp only [d]
    rw [he,abs_mul,abs_neg,abs_of_pos hx]
    exact mul_le_mul_of_nonneg_left (habs.trans hi) hx.le
  intro t ht
  have hz := retarded_integral_zero hd hδ hx.le ht
    (fun s _ => hd0 s) (fun s hs => hbound s hs.1) t ⟨ht,le_rfl⟩
  exact sub_eq_zero.mp (abs_eq_zero.mp hz)

end MIACE
