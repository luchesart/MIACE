import MIACE.DelayTransforms

/-! Етап 10: от действителното трансферно равенство към времевия обект.
    Изходът се строи с нулево начално състояние и нулева транспортна история. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def firstOrderError (v : ℝ → ℝ) (t : ℝ) : ℝ :=
  Real.exp (-t)-lag 1 v t

-- @paper-step thm:pid_two_rate_optimum/constructed_plant_error_continuity
theorem firstOrderError_continuous {v : ℝ → ℝ} (hv : Continuous v) :
    Continuous (firstOrderError v) :=
  (by fun_prop : Continuous (fun t : ℝ => Real.exp (-t))).sub (lag_continuous hv 1)

-- @paper-step thm:pid_two_rate_optimum/constructed_plant_error_integrability
theorem firstOrderError_integrable {v : ℝ → ℝ} (hv : Integrable v halfLine) :
    Integrable (firstOrderError v) halfLine := by
  have he : Integrable (fun t : ℝ => Real.exp (-t)) halfLine := by
    change IntegrableOn (fun t : ℝ => Real.exp (-t)) (Ioi 0) volume
    convert integrableOn_exp_mul_Ioi (by norm_num : (-1 : ℝ)<0) 0 using 1
    ext t; congr 1; ring
  exact he.sub (lag_integrable hv (by norm_num : (0 : ℝ)<1))

-- @paper-step thm:pid_two_rate_optimum/constructed_plant_initial_value
theorem firstOrderError_initial (v : ℝ → ℝ) : firstOrderError v 0=1 := by
  simp [firstOrderError,lag]

-- @paper-step thm:pid_two_rate_optimum/constructed_plant_actual_ODE
theorem firstOrderError_derivative {v : ℝ → ℝ} (hv : Continuous v) {t : ℝ} (ht : 0<t) :
    HasDerivAt (firstOrderError v) (-(firstOrderError v t+v t)) t := by
  have he := ((hasDerivAt_id t).neg).exp
  have hl := lag_hasDerivAt hv.continuousOn 1 t (by norm_num) ht
  convert he.sub hl using 1
  · rfl
  · simp only [firstOrderError,Pi.neg_apply,id_eq,div_one]
    ring

-- @paper-step thm:pid_two_rate_optimum/constructed_plant_error_transform
theorem firstOrderError_laplace {v : ℝ → ℝ} (hv : Integrable v halfLine) {p : ℝ}
    (hp : 0≤p) : laplace (firstOrderError v) p=(1-laplace v p)/(1+p) := by
  have he : Integrable (fun t : ℝ => Real.exp (-t)) halfLine := by
    change IntegrableOn (fun t : ℝ => Real.exp (-t)) (Ioi 0) volume
    convert integrableOn_exp_mul_Ioi (by norm_num : (-1 : ℝ)<0) 0 using 1
    ext t; congr 1; ring
  have hae : (fun t : ℝ => Real.exp (-t))=ᵐ[halfLine] lagKernel 1 := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    simp [lagKernel,show t∈Ioi (0 : ℝ) from ht]
  have hx : laplace (fun t : ℝ => Real.exp (-t)) p=1/(1+p) := by
    rw [laplace_congr_halfLine hae,lagKernel_laplace (by norm_num : (0 : ℝ)<1) hp]
    simp
  change (∫ t, Real.exp (-p*t)*(Real.exp (-t)-lag 1 v t) ∂halfLine)=_
  simp_rw [mul_sub]
  rw [integral_sub (laplace_integrable he hp)
    (laplace_integrable (lag_integrable hv (by norm_num : (0 : ℝ)<1)) hp)]
  change laplace (fun t : ℝ => Real.exp (-t)) p-laplace (lag 1 v) p=_
  rw [hx,lag_laplace hv (by norm_num : (0 : ℝ)<1) hp]
  simp only [one_mul]
  ring

-- Единствеността установява точковото равенство, включително t=0 и t=δ.
-- @paper-step thm:pid_two_rate_optimum/transfer_to_actual_delayed_plant
theorem transfer_firstOrder_realization {E V : ℝ → ℝ} {δ : ℝ}
    (h : TransferResponse E V (fun p => 1/(1+p)) δ) (hδ : 0≤δ)
    (hE : Continuous E) (hV : Continuous V) :
    ∀ t : ℝ, 0≤t → E t=delayedError δ (firstOrderError V) t := by
  apply laplace_injective_continuous h.error_integrable
    (delayedError_integrable δ hδ (firstOrderError_integrable h.command_integrable)) hE
    (delayedError_continuous (firstOrderError_continuous hV) (firstOrderError_initial V) δ)
  intro p hp
  rw [transfer_error_identity h p hp,
    delayedError_laplace (firstOrderError_integrable h.command_integrable) hδ hp,
    firstOrderError_laplace h.command_integrable hp.le]
  field_simp
  <;> ring

-- @paper-step thm:pid_two_rate_optimum/shifted_error_pointwise_identification
theorem transfer_shifted_error {E V : ℝ → ℝ} {δ : ℝ}
    (h : TransferResponse E V (fun p => 1/(1+p)) δ) (hδ : 0≤δ)
    (hE : Continuous E) (hV : Continuous V) :
    ∀ t : ℝ, 0≤t → firstOrderError V t=E (t+δ) := by
  intro t ht
  rw [transfer_firstOrder_realization h hδ hE hV (t+δ) (by linarith)]
  by_cases hz : t=0
  · simp [hz,delayedError,firstOrderError_initial]
  · have hp : 0<t := lt_of_le_of_ne ht (Ne.symm hz)
    simp [delayedError,show ¬t+δ≤δ by linarith,add_sub_cancel_right]

-- @paper-step thm:pid_two_rate_optimum/shifted_actual_response_certificate
theorem ordinary_PID_firstOrderResponse {i ρ ell δ : ℝ} {E V : ℝ → ℝ}
    (hδ : 0≤δ) (h : OrdinaryPIDSignals i ρ ell δ E V) : FirstOrderResponse (firstOrderError V) V := by
  refine ⟨?_,?_,firstOrderError_initial V,?_,
    firstOrderError_integrable h.plant.command_integrable,h.plant.command_integrable⟩
  · intro T hT
    have he : AbsolutelyContinuousOnInterval (fun t : ℝ => Real.exp (-t)) 0 T := by
      apply ContDiffOn.absolutelyContinuousOnInterval; fun_prop
    exact he.sub (lag_ac h.command_continuous.continuousOn 1 T hT)
  · exact ae_of_all volume (fun t ht => (firstOrderError_derivative h.command_continuous ht).deriv)
  · have ht : Tendsto (fun t : ℝ => t+δ) atTop atTop := by
      apply tendsto_atTop.2
      intro b
      filter_upwards [eventually_ge_atTop (b-δ)] with t ht
      linarith
    have he := (ordinary_PID_settling h).1.comp ht
    apply he.congr'
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with t ht
    exact (transfer_shifted_error h.plant hδ h.error_continuous h.command_continuous t ht).symm

-- @paper-step thm:pid_two_rate_optimum/actual_output_monotonicity
theorem ordinary_PID_output_shape {i ρ ell δ : ℝ} {E V : ℝ → ℝ}
    (hδ : 0≤δ) (h : OrdinaryPIDSignals i ρ ell δ E V) :
    MonotoneOn (fun t => 1-E t) (Ici 0) ∧
      (∀ t : ℝ, 0≤t → 0≤1-E t ∧ 1-E t<1) ∧
      (∀ t : ℝ, 0≤t → t≤δ → E t=1) := by
  have hr := ordinary_PID_firstOrderResponse hδ h
  have hf : ∀ᵐ t ∂halfLine, 0≤firstOrderError V t := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    rw [transfer_shifted_error h.plant hδ h.error_continuous h.command_continuous t
      (show 0<t from ht).le]
    exact (h.error_positive (t+δ) (by linarith [show 0<t from ht])).le
  have hv : ∀ᵐ t ∂halfLine, 0≤V t := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact h.command_nonneg t (show 0<t from ht).le
  have hm := delayed_output_monotone hr hf hv δ
  have he := transfer_firstOrder_realization h.plant hδ h.error_continuous h.command_continuous
  have hmono : MonotoneOn (fun t => 1-E t) (Ici 0) := by
    intro a ha b hb hab
    dsimp only
    rw [he a ha,he b hb]
    exact hm ha hb hab
  refine ⟨hmono,?_,?_⟩
  · intro t ht
    have hn := hmono (show (0 : ℝ)∈Ici 0 from by simp) ht ht
    dsimp only at hn
    rw [h.error_initial] at hn
    exact ⟨by linarith,(ordinary_PID_settling h).2.2.2.2 t ht⟩
  · intro t ht htd
    rw [he t ht]
    simp [delayedError,htd]

end MIACE
