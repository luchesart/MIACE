import MIACE.Statements

namespace MIACE
open MeasureTheory

-- The square-root step applies to any signed area S, independently of the plant.
-- @paper-step thm:n_gap/scaled_minimum_square
theorem scaled_minimum_square (α S : ℝ) (hα : 0 < α) :
    (S*minimum α)^2 = baseSq α S := by
  rw [mul_pow,minimum_square α hα]
  unfold baseSq
  ring

-- @paper-step thm:n_gap/unsquared_cost
theorem signal_miace_lower_bound {e v : ℝ → ℝ} {μ : Measure ℝ}
    (he : Integrable e μ) (hv : Integrable v μ) (α S : ℝ)
    (hα : 0 < α) (hS : 0 ≤ S)
    (hbal : (∫ t, e t ∂μ)+(∫ t, v t ∂μ) = S) :
    S*minimum α ≤ miace α e v μ := by
  apply (sq_le_sq₀ (mul_nonneg hS (Real.sqrt_nonneg _)) (Real.sqrt_nonneg _)).mp
  change (S*minimum α)^2 ≤ (miace α e v μ)^2
  rw [scaled_minimum_square α S hα,miace_square α e v μ hα]
  exact cost_lower_bound α S _ _ _ hα hS
    (add_nonneg (negative_area_nonneg _) (negative_area_nonneg _)) (area_balance he hv S hbal)

-- @paper-step thm:n_gap/unsquared_equality
theorem signal_miace_equality_iff {e v : ℝ → ℝ} {μ : Measure ℝ}
    (he : Integrable e μ) (hv : Integrable v μ) (α S : ℝ)
    (hα : 0 < α) (hS : 0 < S)
    (hbal : (∫ t, e t ∂μ)+(∫ t, v t ∂μ) = S) :
    miace α e v μ = S*minimum α ↔
      (∀ᵐ t ∂μ, 0 ≤ e t) ∧ (∀ᵐ t ∂μ, 0 ≤ v t) ∧
      absArea e μ = α*absArea v μ := by
  rw [← signal_equality_iff he hv α S hα hS hbal]
  rw [← miace_square α e v μ hα,← scaled_minimum_square α S hα]
  exact (sq_eq_sq₀ (Real.sqrt_nonneg _) (mul_nonneg hS.le (Real.sqrt_nonneg _))).symm

end MIACE
