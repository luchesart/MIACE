import MIACE.ContinuedImpulse
import MIACE.RationalCascade

/-! Complete exact-remainder interface. The index convention is
N = n+2 plant lags, m = n+1 factors in B, r_j = 1/sigma_j.
The compact kernel uses both endpoints; changing either endpoint has no
effect on its integrals. -/
namespace MIACE
open MeasureTheory Filter Set Polynomial
open scoped Topology

noncomputable def finiteRemainder (r : ℕ → ℝ) (n : ℕ) (δ : ℝ) : ℝ → ℝ :=
  (Icc 0 δ).indicator (remainderJ r n δ)

-- @paper-step lem:n_remainder/finite_support_kernel_semantics
theorem finiteRemainder_properties (r : ℕ → ℝ) (n : ℕ) (δ : ℝ)
    (hr : ∀ j≤n, 0<r j) :
    Integrable (finiteRemainder r n δ) ∧
    (∀ t, 0≤finiteRemainder r n δ t) ∧
    (∀ t∈Icc (0 : ℝ) δ, finiteRemainder r n δ t=(-1 : ℝ)^n*continuedImpulse r n (t-δ)) ∧
    (∀ t∉Icc (0 : ℝ) δ, finiteRemainder r n δ t=0) := by
  refine ⟨(remainderJ_continuous r n δ).integrableOn_Icc.integrable_indicator measurableSet_Icc,?_,?_,?_⟩
  · intro t
    by_cases ht : t∈Icc (0 : ℝ) δ
    · rw [finiteRemainder,indicator_of_mem ht]
      exact remainderJ_nonneg r n (fun j hj => (hr j hj).le) ht.2
    · simp [finiteRemainder,ht]
  · intro t ht; rw [finiteRemainder,indicator_of_mem ht,remainderJ_impulse]
  · intro t ht; simp [finiteRemainder,ht]

-- @paper-step lem:n_remainder/finite_support_transform_identity
theorem finiteRemainder_transform (r : ℕ → ℝ) (n : ℕ) {δ : ℝ} (hδ : 0≤δ) (p : ℂ) :
    compactLaplace (finiteRemainder r n δ) δ p=compactLaplace (remainderJ r n δ) δ p := by
  apply intervalIntegral.integral_congr
  intro t ht
  rw [uIcc_of_le hδ] at ht
  simp only [finiteRemainder,indicator_of_mem ht]

-- @paper-step lem:n_remainder/complete_exact_delay_remainder
theorem paper_exact_delay_remainder (r : ℕ → ℝ) (n : ℕ) {δ : ℝ} (hδ : 0≤δ)
    (hr : ∀ j≤n, 0<r j) :
    (remainderB r n).natDegree=n+1 ∧
    (Integrable (continuedImpulse r n) halfLine ∧
      ∀ p : ℝ, 0≤p → laplace (continuedImpulse r n) p=1/(remainderB r n).eval p) ∧
    (Integrable (finiteRemainder r n δ) ∧ (∀ t, 0≤finiteRemainder r n δ t) ∧
      (∀ t∈Icc (0 : ℝ) δ, finiteRemainder r n δ t=(-1 : ℝ)^n*continuedImpulse r n (t-δ)) ∧
      (∀ t∉Icc (0 : ℝ) δ, finiteRemainder r n δ t=0)) ∧
    (∃! P : ℝ[X], P.natDegree≤n ∧
      ∀ z : ℂ, ∀ k<((remainderB r n).map Complex.ofRealHom).rootMultiplicity z,
        iteratedDeriv k (fun p => P.eval₂ Complex.ofRealHom p) z=
          (-(δ : ℂ))^k*Complex.exp (-(δ : ℂ)*z)) ∧
    (∀ p : ℂ, Complex.exp (-(δ : ℂ)*p)=(remainderI r δ n).eval₂ Complex.ofRealHom p+
      (-1 : ℂ)^(n+1)*(remainderB r n).eval₂ Complex.ofRealHom p*
        compactLaplace (finiteRemainder r n δ) δ p) := by
  have hr0 : ∀ j≤n, r j≠0 := fun j hj => ne_of_gt (hr j hj)
  refine ⟨remainderB_degree r n hr0,⟨continuedImpulse_integrable r n hr,
    fun p hp => continuedImpulse_laplace r n hr hp⟩,
    finiteRemainder_properties r n δ hr,?_,?_⟩
  · exact ⟨remainderI r δ n,⟨remainderI_degree r n δ hr0,remainder_hermite r n δ hr0⟩,
      fun P hP => remainderI_unique r n δ hr0 P hP.1 hP.2⟩
  · intro p
    rw [finiteRemainder_transform r n hδ]
    exact exact_delay_remainder_complex r n δ p hr0

-- @paper-step thm:n_construction/simple_integrator_at_optimal_area
theorem rationalCascade_optimal_integrator (r : ℕ → ℝ) (n : ℕ) (δ α : ℝ)
    (hr : ∀ j≤n, 0<r j) (hδ : 0≤δ) (hα : 0<α) :
    let S := 1+(∑ j∈Finset.range (n+1), 1/r j)+δ
    let Q := rationalCascadeQ r n δ (S/(1+α))
    Q.eval 0=0 ∧ Q.derivative.eval 0=α*S/(1+α) ∧ 0<Q.derivative.eval 0 := by
  dsimp only
  have he := rationalCascade_integrator r n δ
    ((1+(∑ j∈Finset.range (n+1), 1/r j)+δ)/(1+α)) (fun j hj => ne_of_gt (hr j hj))
  have hsum : 0≤∑ j∈Finset.range (n+1), 1/r j := by
    apply Finset.sum_nonneg
    intro j hj
    exact le_of_lt (one_div_pos.mpr (hr j (Nat.le_of_lt_succ (Finset.mem_range.mp hj))))
  have hS : 0<1+(∑ j∈Finset.range (n+1), 1/r j)+δ := by linarith
  have hden : 1+α≠0 := ne_of_gt (by linarith)
  have ha : 1+(∑ j∈Finset.range (n+1), 1/r j)+δ-
      (1+(∑ j∈Finset.range (n+1), 1/r j)+δ)/(1+α)=
      α*(1+(∑ j∈Finset.range (n+1), 1/r j)+δ)/(1+α) := by
    field_simp; ring
  refine ⟨he.1,he.2.trans ha,?_⟩
  rw [he.2,ha]
  exact div_pos (mul_pos hα hS) (by linarith)

end MIACE
