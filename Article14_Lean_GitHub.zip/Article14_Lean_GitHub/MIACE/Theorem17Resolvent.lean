import MIACE.CascadeCommandSigns
import MIACE.WeightedACDecay
import MIACE.Theorem16

/-! Article-facing resolvent and command clauses of Theorem 17.
This is deliberately not named a complete attainment theorem: the full
unreduced rational state realization and final optimum assembly are separate. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

noncomputable def cascadeCommand (J : ℝ → ℝ) (δ a ε : ℝ) (R : ℝ → ℝ) (t : ℝ) : ℝ :=
  (1-a)*R t+ε*(compactKernel (compactTail J δ) δ ⋆ causalize R) t

-- @paper-step thm:n_construction/ordinary_command_integrability_and_exact_area
theorem cascadeCommand_integral {J : ℝ → ℝ} (hc : Continuous J) {δ : ℝ} (hδ : 0≤δ)
    (a ε : ℝ) {R : ℝ → ℝ} (hi : Integrable (causalize R))
    (hm : (∫ t, R t ∂halfLine)=1) :
    Integrable (cascadeCommand J δ a ε R) halfLine ∧
      (∫ t, cascadeCommand J δ a ε R t ∂halfLine)=1-a+ε*compactMoment J δ 1 := by
  let K := compactKernel (compactTail J δ) δ
  have hK := compactKernel_integrable (compactTail_continuous hc δ) δ
  have hconv := hK.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hi
  have hRhalf : Integrable R halfLine := by
    apply (hi.mono_measure Measure.restrict_le_self).congr
    exact representative_halfLine_ae (EventuallyEq.rfl (f := causalize R))
  have hconvhalf := hconv.mono_measure (Measure.restrict_le_self (s := Ioi (0 : ℝ)))
  have hcmass : (∫ t, (K ⋆ causalize R) t ∂halfLine)=compactMoment J δ 1 := by
    rw [← causal_integral_halfLine (ae_of_all _ (convolution_causal
      (compactKernel_causal (compactTail J δ) δ) (causalize_causal R))),
      integral_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hK hi,causalize_integral,hm]
    change (∫ t, K t)*1=compactMoment J δ 1
    rw [mul_one,compactKernel_mass _ hδ]
    simpa [compactMoment] using compactTail_integral hc δ
  refine ⟨(hRhalf.const_mul (1-a)).add (hconvhalf.const_mul ε),?_⟩
  rw [show (fun t => cascadeCommand J δ a ε R t)=(fun t => (1-a)*R t+ε*(K ⋆ causalize R) t) by rfl,
    integral_add (hRhalf.const_mul (1-a)) (hconvhalf.const_mul ε),
    integral_const_mul,integral_const_mul,hm,hcmass]
  ring

-- @paper-step thm:n_construction/actual_rational_cascade_resolvent_and_command
theorem rationalCascade_resolvent_and_command (r : ℕ → ℝ) (n : ℕ) {δ U : ℝ}
    (hr : ∀ j≤n, 0<r j) (hδ : 0≤δ)
    (ha : 0<rationalCascadeA r n δ U) (ha1 : rationalCascadeA r n δ U<1)
    (hpar : CascadeParityTest (remainderJ r n δ) δ (rationalCascadeA r n δ U) ((-1 : ℝ)^(n+1))) :
    ∃ R : ℝ → ℝ,
      CompactResolventEvolution (remainderJ r n δ) δ (rationalCascadeA r n δ U)
        (rationalCascadeC r n δ) ((-1 : ℝ)^(n+1)) R ∧
      Integrable (causalize R) ∧
      (∃ η C : ℝ, 0<η ∧ 0≤C ∧ Integrable (expWeight η (causalize R)) ∧
        ∀ t, 0≤t → |R t|≤C*Real.exp (-η*t)) ∧
      (∀ t, 0≤t → 0≤R t) ∧ (∫ t, R t ∂halfLine)=1 ∧
      (∀ p : ℝ, 0≤p →
        (rationalCascadeA r n δ U*p+rationalCascadeC r n δ+
          (-1 : ℝ)^(n+1)*compactExpMoment (remainderJ r n δ) δ (-p))*laplace R p=1) ∧
      let V := cascadeCommand (remainderJ r n δ) δ (rationalCascadeA r n δ U) ((-1 : ℝ)^(n+1)) R
      Integrable V halfLine ∧ (∀ t, 0≤t → 0≤V t) ∧ absArea V halfLine=U := by
  have hc := remainderJ_continuous r n δ
  have hn : ∀ t∈Icc (0 : ℝ) δ, 0≤remainderJ r n δ t :=
    fun t ht => remainderJ_nonneg r n (fun j hj => (hr j hj).le) ht.2
  obtain ⟨R,hR,hi,hw,hRn,hm,hT,hVn⟩ := cascade_ordinary_inverse_and_command hc hδ ha ha1 hn hpar
  obtain ⟨η,hη,hRw⟩ := hw
  obtain ⟨C,hC,hbound⟩ := compact_resolvent_decay hc hη hR hi hRw
  obtain ⟨hVi,hVm⟩ := cascadeCommand_integral hc hδ
    (rationalCascadeA r n δ U) ((-1 : ℝ)^(n+1)) hi hm
  refine ⟨R,hR,hi,⟨η,C,hη,hC,hRw,hbound⟩,hRn,hm,hT,hVi,hVn,?_⟩
  have he : absArea (cascadeCommand (remainderJ r n δ) δ (rationalCascadeA r n δ U)
      ((-1 : ℝ)^(n+1)) R) halfLine=
      ∫ t, cascadeCommand (remainderJ r n δ) δ (rationalCascadeA r n δ U)
        ((-1 : ℝ)^(n+1)) R t ∂halfLine := by
    apply integral_congr_ae
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact abs_of_nonneg (hVn t (show 0<t from ht).le)
  rw [he,hVm]
  unfold rationalCascadeA
  ring

end MIACE
