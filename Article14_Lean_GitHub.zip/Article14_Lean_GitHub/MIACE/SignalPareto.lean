import MIACE.PIState
import MIACE.Pareto

namespace MIACE
open MeasureTheory

/-- Pareto efficiency against every positive-gain PI trajectory in the actual
plant/integrator ODE model, using squared signal integrals as objectives. -/
def SignalEfficient (e v : ℝ → ℝ) : Prop :=
  ∀ y s : ℝ, ∀ f j : ℝ → ℝ, 0 < y → 0 < s → PIStateResponse y s f j →
    (∫ t, (f t)^2 ∂halfLine) ≤ (∫ t, (e t)^2 ∂halfLine) →
    (∫ t, (y*f t+j t)^2 ∂halfLine) ≤ (∫ t, (v t)^2 ∂halfLine) →
    (∫ t, (f t)^2 ∂halfLine) = (∫ t, (e t)^2 ∂halfLine) ∧
    (∫ t, (y*f t+j t)^2 ∂halfLine) = (∫ t, (v t)^2 ∂halfLine)

-- @paper-step thm:l2_pareto/signal_efficiency_equivalence
theorem signal_efficient_iff {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r) :
    SignalEfficient e (fun t => x*e t+i t) ↔ r=1 ∧ 1≤x := by
  obtain ⟨he,hu⟩ := paper_pi_energies h hx hr
  constructor
  · intro hh
    have hgains : ∀ g : ℝ, 0 < g → tracking g 1 ≤ tracking x r →
        effort g 1 ≤ effort x r → tracking g 1=tracking x r ∧ effort g 1=effort x r := by
      intro g hg hge hgu
      have hm := exponential_pi_state g
      obtain ⟨hge',hgu'⟩ := paper_pi_energies hm hg zero_lt_one
      have hresult := hh g 1 (expError g) (fun t => -expError g t) hg zero_lt_one hm
      rw [hge'.2,hgu'.2,he.2,hu.2] at hresult
      exact hresult hge hgu
    have hr1 : r=1 := by
      by_contra hn
      obtain ⟨hg,hge,hgu⟩ := same_tracking_controller hx hr
      have hstrict := same_tracking_strict hx hr hn
      have hz := hgains _ hg hge.le hstrict.le
      linarith [hz.2]
    subst r
    refine ⟨rfl,?_⟩
    by_contra hn
    have hd := subunit_gain_dominated hx (lt_of_not_ge hn)
    have hz := hgains 1 zero_lt_one hd.1.le hd.2
    linarith [hz.1]
  · intro hp y s f j hy hs hj hE hU
    obtain ⟨hfe,hfu⟩ := paper_pi_energies hj hy hs
    simp only [hfe.2,hfu.2,he.2,hu.2] at hE hU ⊢
    exact (energy_efficient_iff hx hr).mpr hp y s hy hs hE hU

-- @paper-step thm:l2_pareto/actual_front_realization
theorem signal_front_realization (x : ℝ) (hx : 1 ≤ x) :
    ∃ e i : ℝ → ℝ, PIStateResponse x 1 e i ∧ SignalEfficient e (fun t => x*e t+i t) ∧
      (∫ t, (e t)^2 ∂halfLine) = 1/(2*x) ∧
      (∫ t, (x*e t+i t)^2 ∂halfLine) = (x-1)^2/(2*x) := by
  have hx0 : 0 < x := by linarith
  have hm := exponential_pi_state x
  obtain ⟨he,hu⟩ := paper_pi_energies hm hx0 zero_lt_one
  refine ⟨expError x,fun t => -expError x t,hm,
    (signal_efficient_iff hm hx0 zero_lt_one).mpr ⟨rfl,hx⟩,?_,?_⟩
  · rw [he.2,(cancellation_energies x hx0).1]
  · rw [hu.2,(cancellation_energies x hx0).2]

-- @paper-step thm:l2_pareto/full_statement
theorem paper_l2_pareto {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r) :
    let E := ∫ t, (e t)^2 ∂halfLine
    let U := ∫ t, (x*e t+i t)^2 ∂halfLine
    (4*E*(U+1-E)-1 = x*(r-1)^2/(r*(1+x)^2)) ∧
    (0 ≤ 4*E*(U+1-E)-1) ∧
    (paretoBoundary E ≤ U) ∧
    (SignalEfficient e (fun t => x*e t+i t) ↔ r=1 ∧ 1≤x) ∧
    (r=1 → E=1/(2*x) ∧ U=(x-1)^2/(2*x)) := by
  dsimp only
  obtain ⟨he,hu⟩ := paper_pi_energies h hx hr
  rw [he.2,hu.2]
  refine ⟨pareto_residual x r hx hr,?_,pareto_lower_boundary x r hx hr,
    signal_efficient_iff h hx hr,?_⟩
  · rw [pareto_residual x r hx hr]
    positivity
  · rintro rfl
    exact cancellation_energies x hx
end MIACE
