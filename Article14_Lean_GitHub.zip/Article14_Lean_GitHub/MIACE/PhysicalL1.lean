import MIACE.L1Front

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- Поправка: промяната на времето и амплитудата е върху действителния интеграл.
-- @paper-step thm:miace/physical_absolute_scaling
theorem physical_absolute_scaling (f : ℝ → ℝ) (a τ k : ℝ) (hτ : 0 < τ) (hk : 0 < k) :
    absArea (fun t => a*f (t/τ)/k) halfLine=(|a| *τ/k)*absArea f halfLine := by
  have hs := integral_comp_mul_right_Ioi (fun t => |f t|) 0 (inv_pos.mpr hτ)
  simp only [zero_mul,inv_inv,smul_eq_mul,← div_eq_mul_inv] at hs
  unfold absArea halfLine
  simp_rw [abs_div,abs_mul,abs_of_pos hk]
  rw [integral_div,integral_const_mul,hs]
  ring

-- @paper-step thm:miace/physical_absolute_integrability
theorem physical_absolute_integrable {f : ℝ → ℝ} (hf : Integrable f halfLine)
    (a τ k : ℝ) (hτ : 0 < τ) : Integrable (fun t => a*f (t/τ)/k) halfLine := by
  have hh := (integrableOn_Ioi_comp_mul_right_iff f 0 (inv_pos.mpr hτ)).mpr
    (by simpa only [zero_mul,halfLine,IntegrableOn] using hf)
  simpa only [← div_eq_mul_inv] using (hh.const_mul a).div_const k

-- @paper-step thm:miace/physical_step_normalization
theorem pi_physical_absolute_areas {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r)
    (a τ k : ℝ) (ha : a ≠ 0) (hτ : 0 < τ) (hk : 0 < k) :
    let IAE := absArea (fun t => a*e (t/τ)) halfLine
    let IAU := absArea (fun t => a*(x*e (t/τ)+i (t/τ))/k) halfLine
    Integrable (fun t => a*e (t/τ)) halfLine ∧
    Integrable (fun t => a*(x*e (t/τ)+i (t/τ))/k) halfLine ∧
    absArea e halfLine=IAE/(|a| *τ) ∧
    absArea (fun t => x*e t+i t) halfLine=k*IAU/(|a| *τ) := by
  dsimp only
  have hf := pi_state_response h hx hr
  have he := physical_absolute_scaling e a τ 1 hτ zero_lt_one
  simp only [div_one] at he
  have hu := physical_absolute_scaling (fun t => x*e t+i t) a τ k hτ hk
  have hden : |a| *τ ≠ 0 := mul_ne_zero (abs_ne_zero.mpr ha) (ne_of_gt hτ)
  refine ⟨?_,physical_absolute_integrable hf.command_integrable a τ k hτ,?_,?_⟩
  · simpa only [div_one] using physical_absolute_integrable hf.error_integrable a τ 1 hτ
  · rw [he]
    field_simp
  · rw [hu]
    field_simp
end MIACE
