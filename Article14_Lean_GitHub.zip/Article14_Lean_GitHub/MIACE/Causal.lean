import MIACE.Neumann
import MIACE.ExponentialWeight

/-! Каузалност в L¹: стойностите върху отрицателната полуос са нула почти
навсякъде. Това свойство се запазва при конволюция и при нормова граница. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

def Causal (f : ℝ → ℝ) : Prop := ∀ᵐ t, t < 0 → f t = 0

-- @paper-step lem:pid_positive_resolvent/causal_convolution
theorem convolution_causal {K g : ℝ → ℝ} (hK : Causal K) (hg : Causal g) :
    ∀ t : ℝ, t < 0 → (K ⋆ g) t = 0 := by
  intro t ht
  apply integral_eq_zero_of_ae
  have hg' := (quasiMeasurePreserving_sub_left_of_right_invariant
    (volume : Measure ℝ) t).tendsto_ae.eventually hg
  filter_upwards [hK,hg'] with s hs hgs
  change K s*g (t-s)=0
  by_cases h : s < 0
  · rw [hs h,zero_mul]
  · rw [hgs (by linarith),mul_zero]

-- @paper-step lem:pid_positive_resolvent/causal_operator
theorem convOp_causal {K : ℝ → ℝ} (hK : Integrable K) (hc : Causal K)
    {g : RealL1} (hg : Causal g) : Causal (convOp hK g) := by
  filter_upwards [convolutionL1_coe hK g] with t ht hn
  change convolutionL1 hK g t=0
  rw [ht]
  exact convolution_causal hc hg t hn

-- @paper-step lem:pid_positive_resolvent/causal_add
theorem causal_add {f g : RealL1} (hf : Causal f) (hg : Causal g) : Causal (↑(f+g) : ℝ → ℝ) := by
  filter_upwards [hf,hg,Lp.coeFn_add f g] with t ht hg hfg hn
  simp only [hfg,Pi.add_apply,ht hn,hg hn,add_zero]

-- @paper-step lem:pid_positive_resolvent/causal_closed
theorem causal_closed : IsClosed {f : RealL1 | Causal f} := by
  apply IsSeqClosed.isClosed
  intro f f₀ hf hlim
  obtain ⟨φ, -, hφ⟩ := (tendstoInMeasure_of_tendsto_Lp hlim).exists_seq_tendsto_ae
  filter_upwards [ae_all_iff.mpr hf,hφ] with t ht hφt hneg
  have heq : (fun n => f (φ n) t) = fun _ : ℕ => 0 := by
    funext n
    exact ht (φ n) hneg
  rw [heq] at hφt
  exact tendsto_nhds_unique hφt tendsto_const_nhds

-- @paper-step lem:pid_positive_resolvent/causal_series
theorem causal_renewal_series {K : ℝ → ℝ} (hK : Integrable K) (hc : Causal K)
    (hs : ‖convOp hK‖ < 1) {g : RealL1} (hg : Causal g) :
    Causal ((∑' n : ℕ, (convOp hK)^n) g) := by
  have hsum := (summable_geometric_of_norm_lt_one hs).hasSum.map
    (ContinuousLinearMap.apply ℝ RealL1 g) (by fun_prop)
  have hp : ∀ n : ℕ, Causal (((convOp hK)^n) g) := by
    intro n
    induction n with
    | zero => simpa using hg
    | succ n ih => rw [pow_succ']; exact convOp_causal hK hc ih
  apply causal_closed.mem_of_tendsto hsum.tendsto_sum_nat
  apply Eventually.of_forall
  intro n
  change Causal (↑(∑ i ∈ Finset.range n, ((convOp hK)^i) g : RealL1) : ℝ → ℝ)
  induction n with
  | zero =>
    simp only [Finset.range_zero,Finset.sum_empty]
    filter_upwards [Lp.coeFn_zero ℝ 1 (volume : Measure ℝ)] with t ht _
    exact ht
  | succ n ih =>
    rw [Finset.sum_range_succ]
    exact causal_add ih (hp n)

-- @paper-step lem:pid_positive_resolvent/causal_weight
theorem expWeight_causal (η : ℝ) {f : ℝ → ℝ} (hf : Causal f) : Causal (expWeight η f) := by
  filter_upwards [hf] with t ht hn
  simp [expWeight,ht hn]

-- @paper-step lem:pid_positive_resolvent/causal_weight_removal
theorem expWeight_negative_integrable {f : ℝ → ℝ} (hf : Integrable f)
    (hc : Causal f) {η : ℝ} (hη : 0 ≤ η) : Integrable (expWeight (-η) f) := by
  apply hf.abs.mono'
  · exact (by fun_prop : Continuous (fun t : ℝ => Real.exp (-η*t))).aestronglyMeasurable.mul
      hf.aestronglyMeasurable
  · filter_upwards [hc] with t ht
    by_cases hn : t < 0
    · simp [expWeight,ht hn]
    · have he : Real.exp (-η*t) ≤ 1 := Real.exp_le_one_iff.mpr (by nlinarith)
      simp only [expWeight,Real.norm_eq_abs,abs_mul,abs_of_pos (Real.exp_pos _)]
      exact mul_le_of_le_one_left (abs_nonneg _) he

end MIACE
