import MIACE.ExplicitPIDKernel
import MIACE.GreenPIDStability

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:pid_explicit_family/constructed_positive_weighted_Green_function
theorem explicitPID_Green {i ρ ell l δ : ℝ} (h : ExplicitPIDData i ρ ell l δ) :
    ∃ η C : ℝ, ∃ G : ℝ → ℝ, 0<η ∧ η≤1/2 ∧ Causal G ∧
      WeightedControl η G C ∧ (∀ᵐ t, 0≤G t) ∧
      ∀ p, 0≤p → (p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p))*laplace G p=1+ρ*p := by
  obtain ⟨η,CK,CG,hη,hηhalf,_,_,hK,hqw,hg⟩ := explicitK_small_weight h
  let K := explicitK i ρ ell l δ
  let g := expKernel l
  let hKi := explicitK_integrable h
  have hKc := explicitK_causal h.delay_pos.le i ρ ell l
  have hq := (explicitK_mass h).2
  have hgc : Causal g := causalize_causal _
  let hgi := weightedControl_unweighted hg hgc hη.le
  let z : RealL1 := (∑' n : ℕ, (convOp hKi)^n) (hgi.toL1 g)
  obtain ⟨hc,hz,hw⟩ := weightedControl_renewal hη.le hKi hKc hq hK hqw hg hgc
  have hgn : 0≤hgi.toL1 g := by
    rw [← Lp.coeFn_nonneg]
    filter_upwards [hgi.coeFn_toL1] with t ht
    rw [ht]; exact expKernel_nonneg l t
  have hm : (∫ t, K t)<1 := by
    rw [← positive_kernel_mass (ae_of_all _ (explicitK_nonneg h))]
    exact hq
  have hn := (renewal_l1 hKi (ae_of_all _ (explicitK_nonneg h)) hm (hgi.toL1 g) hgn).2.1
  refine ⟨η,_,z,hη,hηhalf,hc,hw,?_,?_⟩
  · exact (Lp.coeFn_nonneg z).mpr hn
  · intro p hp
    have he := signed_renewal_function_laplace hKi hKc hq hgi hgc hp
    change (1-laplace (explicitK i ρ ell l δ) p)*laplace z p=laplace (expKernel l) p at he
    rw [explicitK_laplace h hp,expKernel_laplace h.rate_pos hp] at he
    have hr := (explicitPID_order h).1
    have hl := h.rate_pos
    have hf : 1+ρ*p≠0 := ne_of_gt (by positivity)
    have hpL : p+l≠0 := ne_of_gt (by linarith)
    field_simp [hf,hpL] at he
    simp only [neg_mul,mul_comm δ p] at he ⊢
    linear_combination he

-- @paper-step thm:pid_explicit_family/all_physical_states_exponentially_stable
theorem explicitPID_internal_stability {i ρ ell l δ : ℝ} (h : ExplicitPIDData i ρ ell l δ) :
    PIDInternallyExponentiallyStable i ρ ell δ := by
  obtain ⟨η,C,G,hη,hηhalf,hc,hw,_,hT⟩ := explicitPID_Green h
  obtain ⟨hr,_,_,hr1,_⟩ := explicitPID_order h
  exact green_PID_internal_stability hr hr1 h.delay_pos.le hη hηhalf hc hw hT

end MIACE
