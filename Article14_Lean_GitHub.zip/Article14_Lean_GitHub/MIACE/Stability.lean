import MIACE.Energy

/-! A real Lyapunov proof of settling for every positive second-order
canonical ODE, covering real, complex and repeated poles at once. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def stabilityV (a b c z w : ℝ) : ℝ :=
  ((b*z+a*w)^2+c*(a+c)*z^2+a*c*w^2)/(2*b*c)
noncomputable def stabilityC (a b c : ℝ) : ℝ :=
  (2*b^2+2*a^2+c*(a+c)+a*c)/(2*b*c)

-- @paper-step lem:h2/lyapunov_coercivity
theorem stability_bounds (a b c z w : ℝ) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) :
    a/(2*b)*(z^2+w^2) ≤ stabilityV a b c z w ∧
    stabilityV a b c z w ≤ stabilityC a b c*(z^2+w^2) := by
  have hd : 0 < 2*b*c := by positivity
  constructor
  · unfold stabilityV
    apply (le_div_iff₀ hd).2
    have heq : a/(2*b)*(z^2+w^2)*(2*b*c) = a*c*(z^2+w^2) := by field_simp <;> ring
    rw [heq]
    nlinarith [sq_nonneg (b*z+a*w),mul_nonneg (sq_nonneg c) (sq_nonneg z)]
  · unfold stabilityV stabilityC
    rw [div_mul_eq_mul_div]
    apply (div_le_div_iff_of_pos_right hd).2
    nlinarith [sq_nonneg (b*z-a*w),mul_nonneg (sq_nonneg a) (sq_nonneg z),
      mul_nonneg (sq_nonneg b) (sq_nonneg w),
      mul_nonneg (mul_pos hc (add_pos ha hc)).le (sq_nonneg w),
      mul_nonneg (mul_pos ha hc).le (sq_nonneg z)]

-- @paper-step lem:h2/lyapunov_derivative
theorem stabilityV_hasDerivAt {a b c : ℝ} {z w : ℝ → ℝ} {t : ℝ}
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (hz : HasDerivAt z (w t) t)
    (hw : HasDerivAt w (-(c/a)*z t-(b/a)*w t) t) :
    HasDerivAt (fun s => stabilityV a b c (z s) (w s)) (-(z t)^2-(w t)^2) t := by
  have hd := (((((hz.const_mul b).add (hw.const_mul a)).pow 2).add
    ((hz.pow 2).const_mul (c*(a+c)))).add ((hw.pow 2).const_mul (a*c))).div_const (2*b*c)
  convert hd using 1
  · rfl
  · simp only [Pi.add_apply,Pi.pow_apply]
    field_simp
    <;> ring

-- @paper-step lem:h2/weighted_lyapunov_estimate
theorem canonical_exponential_bound {a b c : ℝ} {z w : ℝ → ℝ}
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (hzac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval z 0 T)
    (hwac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval w 0 T)
    (hzode : ∀ᵐ t : ℝ, 0 < t → deriv z t = w t)
    (hwode : ∀ᵐ t : ℝ, 0 < t → deriv w t = -(c/a)*z t-(b/a)*w t)
    (T : ℝ) (hT : 0 ≤ T) :
    (z T)^2+(w T)^2 ≤ (2*b/a)*stabilityV a b c (z 0) (w 0)*
      Real.exp (-(1/stabilityC a b c)*T) := by
  let C := stabilityC a b c
  have hC : 0 < C := by dsimp [C,stabilityC]; positivity
  let k := 1/C
  have hk : 0 < k := by dsimp [k]; positivity
  let V : ℝ → ℝ := fun t => stabilityV a b c (z t) (w t)
  have hvac : AbsolutelyContinuousOnInterval V 0 T := by
    dsimp [V,stabilityV]
    have hz := hzac T hT
    have hw := hwac T hT
    convert ((((((hz.const_mul b).add (hw.const_mul a)).mul
      ((hz.const_mul b).add (hw.const_mul a))).add ((hz.mul hz).const_mul (c*(a+c)))).add
      ((hw.mul hw).const_mul (a*c))).const_mul (1/(2*b*c))) using 1 <;>
      simp only [Pi.add_def,Pi.mul_def,pow_two] <;> (try funext t) <;> ring
  have hexp : AbsolutelyContinuousOnInterval (fun t : ℝ => Real.exp (k*t)) 0 T := by
    apply ContDiffOn.absolutelyContinuousOnInterval
    fun_prop
  have hpac := hexp.mul hvac
  have hi := hpac.integral_deriv_eq_sub
  have hnonpos : (∫ t in 0..T, deriv (fun s => Real.exp (k*s)*V s) t) ≤ 0 := by
    rw [intervalIntegral.integral_of_le hT]
    apply integral_nonpos_of_ae
    have haez := (hzac T hT).ae_differentiableAt
    have haew := (hwac T hT).ae_differentiableAt
    filter_upwards [ae_restrict_of_ae haez,ae_restrict_of_ae haew,
      ae_restrict_of_ae hzode,ae_restrict_of_ae hwode,
      ae_restrict_mem measurableSet_Ioc] with t hzt hwt hzo hwo ht
    have hmem : t ∈ uIcc 0 T := by simpa [uIcc_of_le hT] using Ioc_subset_Icc_self ht
    have hdz := (hzt hmem).hasDerivAt
    have hdw := (hwt hmem).hasDerivAt
    rw [hzo ht.1] at hdz
    rw [hwo ht.1] at hdw
    have hdV := stabilityV_hasDerivAt ha hb hc hdz hdw
    have hde := ((hasDerivAt_id t).const_mul k).exp
    have hdp := hde.mul hdV
    change HasDerivAt (fun s => Real.exp (k*s)*V s) _ t at hdp
    rw [hdp.deriv]
    have hvb := (stability_bounds a b c (z t) (w t) ha hb hc).2
    have hkv : k*V t ≤ (z t)^2+(w t)^2 := by
      calc
        k*V t = V t/C := by dsimp [k]; ring
        _ ≤ _ := (div_le_iff₀ hC).2 (by simpa [V,C,mul_comm] using hvb)
    have hpos := Real.exp_pos (k*t)
    dsimp [V]
    nlinarith
  change (∫ t in 0..T, deriv (fun s => Real.exp (k*s)*V s) t) =
    Real.exp (k*T)*V T-Real.exp (k*0)*V 0 at hi
  simp only [mul_zero,Real.exp_zero,one_mul] at hi
  have hweighted : Real.exp (k*T)*V T ≤ V 0 := by linarith
  have hmul := mul_le_mul_of_nonneg_left hweighted (Real.exp_nonneg (-k*T))
  have he : Real.exp (-k*T)*Real.exp (k*T) = 1 := by
    rw [← Real.exp_add]
    convert Real.exp_zero using 1 <;> ring
  rw [← mul_assoc,he,one_mul] at hmul
  have hlo := (stability_bounds a b c (z T) (w T) ha hb hc).1
  have hs : (z T)^2+(w T)^2 ≤ (2*b/a)*V T := by
    rw [div_mul_eq_mul_div]
    apply (le_div_iff₀ ha).2
    have hq := (div_le_iff₀ (by positivity : 0 < 2*b)).1
      (show a*((z T)^2+(w T)^2)/(2*b) ≤ V T by simpa [div_mul_eq_mul_div] using hlo)
    nlinarith
  have hm := mul_le_mul_of_nonneg_left hmul (by positivity : 0 ≤ 2*b/a)
  dsimp [k,C,V] at hs hm ⊢
  nlinarith

-- @paper-step lem:h2/positive_coefficients_settle
theorem canonical_settles {a b c : ℝ} {z w : ℝ → ℝ}
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (hzac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval z 0 T)
    (hwac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval w 0 T)
    (hzode : ∀ᵐ t : ℝ, 0 < t → deriv z t = w t)
    (hwode : ∀ᵐ t : ℝ, 0 < t → deriv w t = -(c/a)*z t-(b/a)*w t) :
    Tendsto z atTop (𝓝 0) ∧ Tendsto w atTop (𝓝 0) := by
  have hC : 0 < stabilityC a b c := by unfold stabilityC; positivity
  have hk : 0 < 1/stabilityC a b c := by positivity
  have he := Real.tendsto_exp_neg_atTop_nhds_zero.comp (tendsto_id.const_mul_atTop hk)
  have hbound : Tendsto (fun t : ℝ => (2*b/a)*stabilityV a b c (z 0) (w 0)*
      Real.exp (-(1/stabilityC a b c)*t)) atTop (𝓝 0) := by
    simpa [neg_mul] using he.const_mul ((2*b/a)*stabilityV a b c (z 0) (w 0))
  have hbnd : ∀ᶠ t : ℝ in atTop, (z t)^2+(w t)^2 ≤
      (2*b/a)*stabilityV a b c (z 0) (w 0)*Real.exp (-(1/stabilityC a b c)*t) := by
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with t ht
    exact canonical_exponential_bound ha hb hc hzac hwac hzode hwode t ht
  have hzsq : Tendsto (fun t => (z t)^2) atTop (𝓝 0) :=
    squeeze_zero' (Eventually.of_forall (fun t => sq_nonneg _))
      (hbnd.mono (fun t ht => by nlinarith [sq_nonneg (w t)])) hbound
  have hwsq : Tendsto (fun t => (w t)^2) atTop (𝓝 0) :=
    squeeze_zero' (Eventually.of_forall (fun t => sq_nonneg _))
      (hbnd.mono (fun t ht => by nlinarith [sq_nonneg (z t)])) hbound
  constructor
  · apply tendsto_zero_iff_norm_tendsto_zero.mpr
    simpa only [Function.comp_def,Real.sqrt_sq_eq_abs,Real.sqrt_zero,Real.norm_eq_abs]
      using Real.continuous_sqrt.continuousAt.tendsto.comp hzsq
  · apply tendsto_zero_iff_norm_tendsto_zero.mpr
    simpa only [Function.comp_def,Real.sqrt_sq_eq_abs,Real.sqrt_zero,Real.norm_eq_abs]
      using Real.continuous_sqrt.continuousAt.tendsto.comp hwsq

-- @paper-step lem:h2/complete_canonical_energy
theorem canonical_energy {a b c : ℝ} {z w : ℝ → ℝ}
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (hzac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval z 0 T)
    (hwac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval w 0 T)
    (hzode : ∀ᵐ t : ℝ, 0 < t → deriv z t = w t)
    (hwode : ∀ᵐ t : ℝ, 0 < t → deriv w t = -(c/a)*z t-(b/a)*w t)
    (hz0 : z 0 = 0) (hw0 : w 0 = 1/a) (d e : ℝ) :
    Integrable (fun t => (e*z t+d*w t)^2) halfLine ∧
    (∫ t, (e*z t+d*w t)^2 ∂halfLine) = (a*e^2+c*d^2)/(2*a*b*c) := by
  obtain ⟨hzf,hwf⟩ := canonical_settles ha hb hc hzac hwac hzode hwode
  exact impulse_energy ⟨hzac,hwac,hzode,hwode,hz0,hw0,hzf,hwf⟩ ha hb hc d e
-- @paper-step lem:h2/general_initial_state_energy
theorem canonical_state_energy {a b c : ℝ} {z w : ℝ → ℝ}
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (hzac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval z 0 T)
    (hwac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval w 0 T)
    (hzode : ∀ᵐ t : ℝ, 0 < t → deriv z t = w t)
    (hwode : ∀ᵐ t : ℝ, 0 < t → deriv w t = -(c/a)*z t-(b/a)*w t)
    (d e : ℝ) :
    Integrable (fun t => (e*z t+d*w t)^2) halfLine ∧
    (∫ t, (e*z t+d*w t)^2 ∂halfLine) = energyPotential a b c d e (z 0) (w 0) := by
  obtain ⟨hzf,hwf⟩ := canonical_settles ha hb hc hzac hwac hzode hwode
  have hpot : Tendsto (fun t => energyPotential a b c d e (z t) (w t)) atTop (𝓝 0) := by
    unfold energyPotential
    convert (((hzf.pow 2).const_mul _).add
      ((hzf.const_mul _).mul hwf)).add ((hwf.pow 2).const_mul _) using 1 <;> simp
  have hi : ∀ n : ℕ, IntervalIntegrable (fun t => (e*z t+d*w t)^2) volume 0 n := by
    intro n
    exact (((hzac n (by positivity)).continuousOn.const_mul e).add
      ((hwac n (by positivity)).continuousOn.const_mul d)).pow 2 |>.intervalIntegrable
  have hl : Tendsto (fun n : ℕ => ∫ t in 0..(n : ℝ), (e*z t+d*w t)^2) atTop
      (𝓝 (energyPotential a b c d e (z 0) (w 0))) := by
    have hh := (tendsto_const_nhds (x := energyPotential a b c d e (z 0) (w 0))).sub
      (hpot.comp tendsto_natCast_atTop_atTop)
    simp only [sub_zero] at hh
    apply hh.congr'
    exact Eventually.of_forall (fun n => (state_finite_energy ha hb hc d e n (by positivity)
      (hzac n (by positivity)) (hwac n (by positivity)) hzode hwode).symm)
  have hnorm : Tendsto (fun n : ℕ => ∫ t in 0..(n : ℝ), ‖(e*z t+d*w t)^2‖) atTop
      (𝓝 (energyPotential a b c d e (z 0) (w 0))) := by
    simpa only [Real.norm_eq_abs,abs_sq] using hl
  have hint : Integrable (fun t => (e*z t+d*w t)^2) halfLine :=
    integrableOn_Ioi_of_intervalIntegral_norm_tendsto _ 0 (fun n => (hi n).1)
      tendsto_natCast_atTop_atTop hnorm
  exact ⟨hint,tendsto_nhds_unique (intervalIntegral_tendsto_integral_Ioi 0 hint
    tendsto_natCast_atTop_atTop) hl⟩
end MIACE
