import MIACE.PositiveResolvent
import MIACE.Moments

set_option maxHeartbeats 1200000

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step lem:pid_positive_resolvent/causal_integral_halfline
theorem causal_integral_halfLine {f : ℝ → ℝ} (hf : Causal f) :
    (∫ t, f t) = ∫ t, f t ∂halfLine := by
  have he : f =ᵐ[volume] (Ici 0).indicator f := by
    filter_upwards [hf] with t ht
    by_cases h : 0 ≤ t
    · simp [h]
    · simp [h,ht (lt_of_not_ge h)]
  rw [integral_congr_ae he,integral_indicator measurableSet_Ici,integral_Ici_eq_integral_Ioi]

-- @paper-step lem:pid_positive_resolvent/causal_convolution_interval
theorem causal_convolution_interval {K g : ℝ → ℝ} (hK : Causal K) (hg : Causal g)
    {t : ℝ} (ht : 0 ≤ t) : (K ⋆ g) t = ∫ s in 0..t, K (t-s)*g s := by
  have hchange := integral_sub_left_eq_self (fun s => K s*g (t-s)) (volume : Measure ℝ) t
  simp only [sub_sub_cancel] at hchange
  change (∫ s, K s*g (t-s)) = _
  rw [← hchange,intervalIntegral.integral_of_le ht,← integral_Icc_eq_integral_Ioc,
    ← integral_indicator measurableSet_Icc]
  apply integral_congr_ae
  have hK' := (quasiMeasurePreserving_sub_left_of_right_invariant
    (volume : Measure ℝ) t).tendsto_ae.eventually hK
  filter_upwards [hg,hK'] with s hs hKs
  by_cases hmem : s ∈ Icc (0 : ℝ) t
  · simp [hmem]
  · rw [indicator_of_notMem hmem]
    by_cases hneg : s < 0
    · rw [hs hneg,mul_zero]
    · have hgt : t < s := by
        by_contra h
        exact hmem ⟨le_of_not_gt hneg,le_of_not_gt h⟩
      rw [hKs (by linarith),zero_mul]

-- @paper-step lem:pid_positive_resolvent/series_geometric_majorant
theorem renewal_power_bound {K : ℝ → ℝ} (hK : Integrable K)
    (hKn : ∀ᵐ t, 0 ≤ K t) (g : RealL1) (n : ℕ) :
    ‖((convOp hK)^n) g‖ ≤ (∫ t, K t)^n * ‖g‖ := by
  have hq : 0 ≤ ∫ t, K t := integral_nonneg_of_ae hKn
  induction n with
  | zero => simp
  | succ n ih =>
    rw [pow_succ',ContinuousLinearMap.mul_apply]
    have hh := convolutionL1_bound hK (((convOp hK)^n) g)
    rw [positive_kernel_mass hKn] at hh
    apply hh.trans
    calc
      _ ≤ (∫ t, K t)*((∫ t, K t)^n * ‖g‖) := mul_le_mul_of_nonneg_left ih hq
      _ = _ := by rw [pow_succ]; ring

-- @paper-step lem:pid_positive_resolvent/absolute_l1_series
theorem renewal_absolute_convergence {K : ℝ → ℝ} (hK : Integrable K)
    (hKn : ∀ᵐ t, 0 ≤ K t) (hq : (∫ t, K t) < 1) (g : RealL1) :
    Summable (fun n : ℕ => ‖((convOp hK)^n) g‖) := by
  have hq0 : 0 ≤ ∫ t, K t := integral_nonneg_of_ae hKn
  apply Summable.of_nonneg_of_le (fun _ => norm_nonneg _)
    (renewal_power_bound hK hKn g)
    ((summable_geometric_of_lt_one hq0 hq).mul_right ‖g‖)

-- @paper-step lem:pid_positive_resolvent/renewal_interval_equation
theorem renewal_equation_iff {K : ℝ → ℝ} (hK : Integrable K) (hKc : Causal K)
    (g z : RealL1) (hgc : Causal g) (hzc : Causal z) :
    z=g+convOp hK z ↔
      ∀ᵐ t, 0 ≤ t → z t=g t+(∫ s in 0..t, K (t-s)*z s) := by
  constructor
  · intro he
    have hh := Lp.coeFn_add g (convOp hK z)
    rw [← he] at hh
    filter_upwards [hh,convOp_coe hK z] with t ht hc hpos
    rw [ht,Pi.add_apply,hc,causal_convolution_interval hKc hzc hpos]
  · intro he
    apply Lp.ext
    filter_upwards [he,hgc,hzc,Lp.coeFn_add g (convOp hK z),convOp_coe hK z]
      with t ht hg hz hadd hc
    rw [hadd,Pi.add_apply,hc]
    by_cases hpos : 0 ≤ t
    · rw [causal_convolution_interval hKc hzc hpos]
      exact ht hpos
    · have hn := lt_of_not_ge hpos
      rw [hg hn,hz hn,convolution_causal hKc hzc t hn,add_zero]

-- Всички клаузи на Лема 9, с обща тежест η, избрана само от K.
-- @paper-step lem:pid_positive_resolvent/full_statement
theorem paper_positive_resolvent {K : ℝ → ℝ} (hK : Integrable K)
    (hKn : ∀ᵐ t, 0 ≤ K t) (hKc : Causal K) (hq : (∫ t, K t) < 1) :
    (∀ g : RealL1, 0 ≤ g → Causal g →
      let T := convOp hK
      let z := (∑' n : ℕ, T^n) g
      HasSum (fun n : ℕ => (T^n) g) z ∧
      Summable (fun n : ℕ => ‖(T^n) g‖) ∧ 0 ≤ z ∧ Causal z ∧
      (∀ᵐ t, 0 ≤ t → z t=g t+(∫ s in 0..t, K (t-s)*z s)) ∧
      (∀ z' : RealL1, Causal z' →
        (∀ᵐ t, 0 ≤ t → z' t=g t+(∫ s in 0..t, K (t-s)*z' s)) → z'=z) ∧
      ‖z‖ ≤ ‖g‖/(1-(∫ t, K t))) ∧
    (∀ β : ℝ, 0 < β → Integrable (expWeight β K) volume →
      ∃ η : ℝ, ∃ hKw : Integrable (expWeight η K) volume,
        0 < η ∧ η ≤ β ∧ (∫ t, expWeight η K t) < 1 ∧
        (∀ g : RealL1, 0 ≤ g → Causal g →
          ∀ hgw : Integrable (expWeight η g) volume,
          let z := (∑' n : ℕ, (convOp hK)^n) g
          ∃ hz : Integrable (expWeight η z) volume,
            HasSum (fun n : ℕ => ((convOp hKw)^n) (hgw.toL1 (expWeight η g)))
              (hz.toL1 (expWeight η z)) ∧
            Summable (fun n : ℕ => ‖((convOp hKw)^n) (hgw.toL1 (expWeight η g))‖))) := by
  constructor
  · intro g hg hgc
    dsimp only
    obtain ⟨hs,hp,hc,he,hu,hn,_⟩ := positive_resolvent_all_parts hK hKn hKc hq g hg hgc
    refine ⟨hs,renewal_absolute_convergence hK hKn hq g,hp,hc,
      (renewal_equation_iff hK hKc g _ hgc hc).mp he,?_,hn⟩
    intro z' hzc hze
    exact hu z' ((renewal_equation_iff hK hKc g z' hgc hzc).mpr hze)
  · intro β hβ hw
    obtain ⟨η,hη,hle,hKw,hqw⟩ := expWeight_small_mass hK hq hβ hw
    refine ⟨η,hKw,hη,hle,hqw,?_⟩
    intro g hg hgc hgw
    obtain ⟨hz,hs,_⟩ := positive_resolvent_weighted hK hKn hKc hq hη.le hKw hqw g hg hgc hgw
    refine ⟨hz,hs,?_⟩
    apply renewal_absolute_convergence hKw _ hqw
    filter_upwards [hKn] with t ht
    exact mul_nonneg (Real.exp_nonneg _) ht

end MIACE
