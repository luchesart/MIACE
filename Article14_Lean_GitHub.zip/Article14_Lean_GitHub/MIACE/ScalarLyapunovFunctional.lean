import MIACE.CompactParameterIntegral

/-! A positive Lyapunov functional for w'(t) = -w(t-h), throughout
0 ≤ h < π/2. Its exact derivative is -w(t)^2; no positivity or
nonoscillation hypothesis is imposed on the solution. -/
namespace MIACE
open MeasureTheory Set Filter
open scoped Topology

noncomputable def delayWindowEnergy (h : ℝ) (w : ℝ → ℝ) (t : ℝ) : ℝ :=
  ∫ s in (0 : ℝ)..h, (delayCosWindow h w t s/Real.cos s)^2

noncomputable def scalarDelayLyapunov (h : ℝ) (w : ℝ → ℝ) (t : ℝ) : ℝ :=
  let C := w t-delayCosWindow h w t 0
  let S := -delaySinWindow h w t 0
  (1+Real.sin h)/(2*Real.cos h)*(C^2+S^2)-C*S+delayWindowEnergy h w t

-- @paper-step lem:delayed_cancellation/cosine_positive_on_stable_history_interval
theorem delay_cos_pos {h s : ℝ} (hh : h<Real.pi/2) (hs : s∈Icc 0 h) :
    0<Real.cos s := by
  exact Real.cos_pos_of_mem_Ioo ⟨by linarith [Real.pi_pos,hs.1],hs.2.trans_lt hh⟩

-- @paper-step lem:delayed_cancellation/history_energy_spatial_antiderivative
theorem delayWindowEnergy_space_deriv {w : ℝ → ℝ} (hw : Continuous w)
    (h t s : ℝ) (hc : Real.cos s≠0) :
    HasDerivAt (fun r => (delayCosWindow h w t r/Real.cos r)^2-
      (delaySinWindow h w t r-Real.sin r/Real.cos r*delayCosWindow h w t r)^2-
      2*Real.cos h*w t*(delaySinWindow h w t r-
        Real.sin r/Real.cos r*delayCosWindow h w t r))
      (2*delayCosWindow h w t s/(Real.cos s)^2*
        (Real.cos h*w t-Real.cos s*w (t-h+s)+delaySinWindow h w t s)) s := by
  obtain ⟨hp,hq⟩ := delayWindows_space_deriv hw h t s
  have hr := hq.sub (((Real.hasDerivAt_sin s).div (Real.hasDerivAt_cos s) hc).mul hp)
  convert (((hp.div (Real.hasDerivAt_cos s) hc).pow 2).sub (hr.pow 2)).sub
    (hr.const_mul (2*Real.cos h*w t)) using 1
  dsimp
  field_simp
  linear_combination (delayCosWindow h w t s*(delayCosWindow h w t s*Real.sin s-
    Real.cos s*(delaySinWindow h w t s+Real.cos h*w t)))*(Real.sin_sq_add_cos_sq s)

-- @paper-step lem:delayed_cancellation/exact_history_energy_derivative
theorem delayWindowEnergy_deriv {w : ℝ → ℝ} (hw : Continuous w)
    {h : ℝ} (h0 : 0≤h) (hh : h<Real.pi/2) (t : ℝ) :
    HasDerivAt (delayWindowEnergy h w)
      (-(delayCosWindow h w t 0)^2+(delaySinWindow h w t 0)^2+
        2*Real.cos h*w t*delaySinWindow h w t 0) t := by
  let P := delayCosWindow h w
  let Q := delaySinWindow h w
  let D := fun u s => 2*P u s/(Real.cos s)^2*
    (Real.cos h*w u-Real.cos s*w (u-h+s)+Q u s)
  have hP := (delayWindows_continuous hw h).1
  have hQ := (delayWindows_continuous hw h).2
  have hPc (u : ℝ) : Continuous (delayCosWindow h w u) :=
    continuous_iff_continuousAt.mpr (fun s => (delayWindows_space_deriv hw h u s).1.continuousAt)
  have hcos : ∀ s∈Icc 0 h, Real.cos s≠0 := fun s hs => ne_of_gt (delay_cos_pos hh hs)
  have hD : ContinuousOn (fun p : ℝ × ℝ => D p.1 p.2) (univ ×ˢ Icc 0 h) := by
    dsimp [D]
    apply ContinuousOn.mul
    · exact (continuous_const.mul hP).continuousOn.div
        ((Real.continuous_cos.comp continuous_snd).continuousOn.pow 2)
        (fun p hp => pow_ne_zero 2 (hcos p.2 hp.2))
    · have hc : Continuous (fun p : ℝ × ℝ =>
          Real.cos h*w p.1-Real.cos p.2*w (p.1-h+p.2)+Q p.1 p.2) := by
        exact ((continuous_const.mul (hw.comp continuous_fst)).sub
          ((Real.continuous_cos.comp continuous_snd).mul
          (hw.comp ((continuous_fst.sub continuous_const).add continuous_snd)))).add hQ
      exact hc.continuousOn
  have hd := compactParameterIntegral_deriv
    (F := fun u s => (P u s/Real.cos s)^2) (D := D) h0
    (fun u => ((hPc u).continuousOn.div Real.continuous_cos.continuousOn hcos).pow 2)
    hD (fun u s hs => by
      convert (((delayWindows_time_deriv hw h u s).1.div_const (Real.cos s)).pow 2) using 1
      dsimp [D,P]; ring) t
  have hDi : IntervalIntegrable (D t) volume 0 h :=
    (hD.comp (continuous_const.prodMk continuous_id).continuousOn
      (fun s hs => ⟨mem_univ _,hs⟩)).intervalIntegrable_of_Icc h0
  have hFTC := intervalIntegral.integral_eq_sub_of_hasDerivAt
    (fun s (hs : s∈uIcc 0 h) => delayWindowEnergy_space_deriv hw h t s
      (hcos s (by simpa only [uIcc_of_le h0] using hs))) hDi
  have hterm := delayWindows_terminal h t w
  change ∫ s in (0 : ℝ)..h, D t s = _ at hFTC
  simp only [hterm.1,hterm.2,zero_div,zero_pow (by decide : 2≠0),mul_zero,
    sub_zero,zero_sub,Real.sin_zero,Real.cos_zero,div_one,zero_mul] at hFTC
  have he : (∫ s in (0 : ℝ)..h, D t s)=
      -(delayCosWindow h w t 0)^2+(delaySinWindow h w t 0)^2+
        2*Real.cos h*w t*delaySinWindow h w t 0 := by linarith [hFTC]
  rw [he] at hd
  exact hd

-- @paper-step lem:delayed_cancellation/positive_lyapunov_functional_entire_stable_interval
theorem scalarDelayLyapunov_nonneg {h : ℝ} (h0 : 0≤h) (hh : h<Real.pi/2)
    (w : ℝ → ℝ) (t : ℝ) : 0≤scalarDelayLyapunov h w t := by
  have hc := delay_cos_pos hh (show h∈Icc 0 h from ⟨h0,le_rfl⟩)
  have hs : 0≤Real.sin h := Real.sin_nonneg_of_nonneg_of_le_pi h0 (by linarith [Real.pi_pos])
  have ha : 1/2≤(1+Real.sin h)/(2*Real.cos h) := by
    apply (le_div_iff₀ (by positivity)).mpr
    nlinarith [Real.cos_le_one h]
  have hi : 0≤delayWindowEnergy h w t := intervalIntegral.integral_nonneg h0
    (fun s _ => sq_nonneg _)
  unfold scalarDelayLyapunov
  dsimp only
  nlinarith [sq_nonneg (w t-delayCosWindow h w t 0+delaySinWindow h w t 0),
    mul_nonneg (sub_nonneg.mpr ha)
      (add_nonneg (sq_nonneg (w t-delayCosWindow h w t 0)) (sq_nonneg (-delaySinWindow h w t 0)))]

-- @paper-step lem:delayed_cancellation/exact_lyapunov_dissipation_for_arbitrary_signed_solution
theorem scalarDelayLyapunov_deriv {h : ℝ} (h0 : 0≤h) (hh : h<Real.pi/2)
    {w : ℝ → ℝ} (hw : Continuous w) {t : ℝ}
    (hd : HasDerivAt w (-w (t-h)) t) :
    HasDerivAt (scalarDelayLyapunov h w) (-(w t)^2) t := by
  obtain ⟨hp,hq⟩ := delayWindows_time_deriv hw h t 0
  have hC := hd.sub hp
  have hS := hq.neg
  have hI := delayWindowEnergy_deriv hw h0 hh t
  convert (((((hC.pow 2).add (hS.pow 2)).const_mul
    ((1+Real.sin h)/(2*Real.cos h))).sub (hC.mul hS)).add hI) using 1
  · rfl
  · dsimp
    simp only [Real.cos_zero,Real.sin_zero,one_mul,zero_mul,add_zero,sub_zero]
    have hc : Real.cos h≠0 := ne_of_gt (delay_cos_pos hh ⟨h0,le_rfl⟩)
    field_simp
    linear_combination -w t*delaySinWindow h w t 0*(Real.sin_sq_add_cos_sq h)

end MIACE
