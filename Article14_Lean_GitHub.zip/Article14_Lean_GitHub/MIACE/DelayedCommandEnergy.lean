import MIACE.DelayedErrorEnergy

/-! Stage 19. Cross energy is obtained by integrating the actual shifted
delay equation. All improper integrals are justified by square integrability. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step prop:delayed_quadratic/shifted_error_square_integrability
theorem scalarDelay_shift_square_integrable {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    (hb : x*δ<Real.pi/2) {E : ℝ → ℝ} (hE : ScalarDelayResponse x δ E) :
    Integrable (fun t => (E (t+δ))^2) halfLine := by
  have hi := IntegrableOn.mono_set (scalarDelay_response_square_integrable hx hδ hb hE)
    (show Ioi δ ⊆ Ioi (0 : ℝ) from fun t ht => hδ.trans_lt ht)
  exact ((translate_halfLine δ).integrable_comp_emb
    (Homeomorph.addRight δ).isClosedEmbedding.measurableEmbedding).mpr hi

-- @paper-step prop:delayed_quadratic/shifted_error_energy_removes_waiting_area
theorem scalarDelay_shift_energy {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    (hb : x*δ<Real.pi/2) {E : ℝ → ℝ} (hE : ScalarDelayResponse x δ E) :
    (∫ t, (E (t+δ))^2 ∂halfLine)=(∫ t, (E t)^2 ∂halfLine)-δ := by
  have hwait : (∫ t in (0 : ℝ)..δ, (E t)^2)=δ := by
    calc
      _ = ∫ t in (0 : ℝ)..δ, (1 : ℝ) := by
        apply intervalIntegral.integral_congr
        intro t ht
        rw [uIcc_of_le hδ] at ht
        dsimp only; rw [scalarDelay_plateau hE ht.1 ht.2]; norm_num
      _ = _ := by simp
  have he (T : ℝ) : (∫ t in (0 : ℝ)..T, (E (t+δ))^2)=
      (∫ t in (0 : ℝ)..T+δ, (E t)^2)-δ := by
    rw [intervalIntegral.integral_comp_add_right (fun t => (E t)^2) δ]
    simp only [zero_add]
    have ha := intervalIntegral.integral_add_adjacent_intervals
      ((hE.continuous.pow 2).intervalIntegrable (μ := volume) 0 δ)
      ((hE.continuous.pow 2).intervalIntegrable (μ := volume) δ (T+δ))
    simp only [Pi.pow_apply] at ha
    linarith
  have htime : Tendsto (fun T : ℝ => T+δ) atTop atTop := by
    apply tendsto_atTop.2
    intro b
    filter_upwards [eventually_ge_atTop (b-δ)] with T hT
    linarith
  have hl := (intervalIntegral_tendsto_integral_Ioi 0
    (scalarDelay_response_square_integrable hx hδ hb hE) htime).sub_const δ
  have hr := intervalIntegral_tendsto_integral_Ioi 0
    (scalarDelay_shift_square_integrable hx hδ hb hE) tendsto_id
  exact tendsto_nhds_unique hr (by simpa only [← he,id_eq,halfLine] using hl)

-- @paper-step prop:delayed_quadratic/cross_energy_absolute_integrability
theorem scalarDelay_cross_integrable {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    (hb : x*δ<Real.pi/2) {E : ℝ → ℝ} (hE : ScalarDelayResponse x δ E) :
    Integrable (fun t => E t*E (t+δ)) halfLine := by
  have hi := (scalarDelay_response_square_integrable hx hδ hb hE).add
    (scalarDelay_shift_square_integrable hx hδ hb hE)
  apply hi.mono' (hE.continuous.mul (hE.continuous.comp (continuous_id.add_const δ))).aestronglyMeasurable
  apply Eventually.of_forall
  intro t
  change ‖E t*E (t+δ)‖≤(E t)^2+(E (t+δ))^2
  rw [Real.norm_eq_abs,abs_le]
  constructor <;> nlinarith [sq_nonneg (E t+E (t+δ)),sq_nonneg (E t-E (t+δ))]

-- @paper-step prop:delayed_quadratic/exact_cross_energy_from_dde
theorem scalarDelay_cross_energy {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    (hb : x*δ<Real.pi/2) {E : ℝ → ℝ} (hE : ScalarDelayResponse x δ E) :
    (∫ t, E t*E (t+δ) ∂halfLine)=1/(2*x) := by
  have hc : Continuous (fun t => -2*x*(E t*E (t+δ))) := by
    have hEc := hE.continuous
    fun_prop
  have hd (t : ℝ) (ht : 0<t) : HasDerivAt (fun s => (E (s+δ))^2)
      (-2*x*(E t*E (t+δ))) t := by
    have hder := (scalarDelay_derivative_after hδ hE (show δ<t+δ by linarith)).comp t
      ((hasDerivAt_id t).add_const δ)
    convert hder.pow 2 using 1
    · rfl
    · simp only [Function.comp_def,id_eq,add_sub_cancel_right,mul_one]
      ring
  have he (T : ℝ) (hT : 0≤T) :
      -2*x*(∫ t in (0 : ℝ)..T, E t*E (t+δ))=(E (T+δ))^2-1 := by
    have hh := intervalIntegral.integral_eq_sub_of_hasDerivAt_of_le hT
      ((hE.continuous.comp (continuous_id.add_const δ)).pow 2).continuousOn
      (fun t ht => hd t ht.1) (hc.intervalIntegrable 0 T)
    rw [intervalIntegral.integral_const_mul] at hh
    simpa only [Pi.pow_apply,Function.comp_def,id_eq,zero_add,scalarDelay_plateau hE hδ le_rfl,one_pow] using hh
  have htime : Tendsto (fun T : ℝ => T+δ) atTop atTop := by
    apply tendsto_atTop.2
    intro b
    filter_upwards [eventually_ge_atTop (b-δ)] with T hT
    linarith
  have hl := ((scalarDelay_response_decay hx hδ hb hE).comp htime).pow 2
  have hright : Tendsto (fun T => (E (T+δ))^2-1) atTop (𝓝 (-1)) := by simpa using hl.sub_const 1
  have hleft := (intervalIntegral_tendsto_integral_Ioi 0
    (scalarDelay_cross_integrable hx hδ hb hE) tendsto_id).const_mul (-2*x)
  have heq : (fun T : ℝ => -2*x*(∫ t in (0 : ℝ)..T, E t*E (t+δ)))=ᶠ[atTop]
      (fun T => (E (T+δ))^2-1) := by
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with T hT
    exact he T hT
  have hh := tendsto_nhds_unique hleft (hright.congr' heq.symm)
  apply (eq_div_iff (by positivity : 2*x≠0)).mpr
  linarith

-- @paper-step prop:delayed_quadratic/exact_centered_command_energy
theorem scalarDelay_command_energy {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    (hb : x*δ<Real.pi/2) {E : ℝ → ℝ} (hE : ScalarDelayResponse x δ E) :
    Integrable (fun t => (x*E t-E (t+δ))^2) halfLine ∧
    (∫ t, (x*E t-E (t+δ))^2 ∂halfLine)=
      (x^2+1)*((1+Real.sin (x*δ))/(2*x*Real.cos (x*δ)))-δ-1 := by
  have hi := scalarDelay_response_square_integrable hx hδ hb hE
  have hs := scalarDelay_shift_square_integrable hx hδ hb hE
  have hc := scalarDelay_cross_integrable hx hδ hb hE
  have heq : (fun t => (x*E t-E (t+δ))^2)=
      (fun t => (x^2*(E t)^2+(E (t+δ))^2)-(2*x)*(E t*E (t+δ))) := by funext t; ring
  rw [heq]
  refine ⟨((hi.const_mul (x^2)).add hs).sub (hc.const_mul (2*x)),?_⟩
  rw [integral_sub (f := fun t => x^2*(E t)^2+(E (t+δ))^2)
      (g := fun t => (2*x)*(E t*E (t+δ))) ((hi.const_mul (x^2)).add hs) (hc.const_mul (2*x)),
    integral_add (hi.const_mul (x^2)) hs,integral_const_mul,integral_const_mul,
    scalarDelay_shift_energy hx hδ hb hE,scalarDelay_cross_energy hx hδ hb hE,
    scalarDelay_response_energy hx hδ hb hE]
  field_simp
  <;> ring

end MIACE
