import MIACE.PIExplicit

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

def MonotoneDomain (x r : ℝ) : Prop :=
  if x ≤ 1 then 4*x/(1+x)^2 ≤ r else 1 ≤ r

-- @paper-step thm:monotone/real_root_domain_algebra
theorem real_root_domain {x r l m : ℝ} (hx : 0 < x) (hr : 0 < r)
    (hlm : l ≤ m) (hs : l+m=1+x) (hp : l*m=x/r) :
    l ≤ 1 ↔ MonotoneDomain x r := by
  have hprod : l*m*r=x := (eq_div_iff (ne_of_gt hr)).mp hp
  unfold MonotoneDomain
  split_ifs with hx1
  · have hl1 : l ≤ 1 := by linarith
    have hden : 0 < (1+x)^2 := by positivity
    have hc : 4*x/(1+x)^2 ≤ r := by
      apply (div_le_iff₀ hden).2
      rw [← hs]
      nlinarith [mul_nonneg hr.le (sq_nonneg (m-l))]
    exact iff_of_true hl1 hc
  · have hx1 : 1 < x := lt_of_not_ge hx1
    have hm1 : 1 < m := by linarith
    constructor
    · intro hl
      have hp1 : l*m ≤ x := by nlinarith [mul_nonpos_of_nonpos_of_nonneg (sub_nonpos.mpr hl) (sub_nonneg.mpr hm1.le)]
      nlinarith [mul_le_mul_of_nonneg_right hp1 hr.le]
    · intro hr1
      have hp1 : l*m ≤ x := by rw [hp]; exact (div_le_iff₀ hr).2 (by nlinarith)
      by_contra hn
      have hll : 1 < l := lt_of_not_ge hn
      nlinarith [mul_pos (sub_pos.mpr hll) (sub_pos.mpr hm1)]

-- @paper-step thm:monotone/domain_implies_real_poles
theorem domain_discriminant {x r : ℝ} (hx : 0 < x) (hr : 0 < r)
    (hd : MonotoneDomain x r) : 0 ≤ (1+x)^2-4*x/r := by
  unfold MonotoneDomain at hd
  split_ifs at hd with hx1
  · have hh := (div_le_iff₀ (by positivity : 0 < (1+x)^2)).mp hd
    apply (le_sub_iff_add_le).2
    simp only [zero_add]
    exact (div_le_iff₀ hr).2 (by nlinarith)
  · have hh : x/r ≤ x := (div_le_iff₀ hr).2 (by nlinarith)
    simp only [mul_div_assoc]
    nlinarith [sq_nonneg (x-1)]

-- @paper-step thm:monotone/real_root_identities
theorem real_root_identities {x r : ℝ} (hx : 0 < x) (hr : 0 < r)
    (hD : 0 ≤ (1+x)^2-4*x/r) :
    let l := (1+x-Real.sqrt ((1+x)^2-4*x/r))/2
    let m := (1+x+Real.sqrt ((1+x)^2-4*x/r))/2
    0 < l ∧ l ≤ m ∧ l+m=1+x ∧ l*m=x/r := by
  dsimp
  have hs := Real.sq_sqrt hD
  have hn := Real.sqrt_nonneg ((1+x)^2-4*x/r)
  have hp : 0 < x/r := div_pos hx hr
  simp only [mul_div_assoc] at *
  refine ⟨?_,by linarith,by ring,?_⟩
  · nlinarith
  · nlinarith

-- @paper-step thm:monotone/complete_nonovershoot_iff
theorem pi_nonovershoot_iff {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r) :
    (∀ t : ℝ, 0 ≤ t → 0 ≤ e t) ↔ MonotoneDomain x r := by
  by_cases hD : 0 ≤ (1+x)^2-4*x/r
  · let l := (1+x-Real.sqrt ((1+x)^2-4*x/r))/2
    let m := (1+x+Real.sqrt ((1+x)^2-4*x/r))/2
    obtain ⟨hl,hlm,hs,hp⟩ := real_root_identities hx hr hD
    change 0 < l at hl
    change l ≤ m at hlm
    change l+m=1+x at hs
    change l*m=x/r at hp
    rcases hlm.eq_or_lt with heq | hlt
    · have hsum : 2*l=1+x := by linarith
      have hprod : l^2=x/r := by nlinarith
      exact (repeated_error_nonnegative_iff h hx hr hsum hprod).trans
        (real_root_domain hx hr hlm hs hp)
    · exact (distinct_error_nonnegative_iff h hx hr hlt hs hp).trans
        (real_root_domain hx hr hlm hs hp)
  · have hω : 0 < Real.sqrt (4*x/r-(1+x)^2)/2 := by
      apply div_pos (Real.sqrt_pos.mpr (by linarith)) (by norm_num)
    have hs : 2*((1+x)/2)=1+x := by ring
    have hp : ((1+x)/2)^2+(Real.sqrt (4*x/r-(1+x)^2)/2)^2=x/r := by
      have hh := Real.sq_sqrt (show 0 ≤ 4*x/r-(1+x)^2 by linarith)
      simp only [mul_div_assoc] at *
      nlinarith
    have hn := complex_error_negative h hx hr hω hs hp
    constructor
    · intro he
      have hh := he _ hn.1.le
      linarith [hn.2]
    · intro hd
      exact (hD (domain_discriminant hx hr hd)).elim

-- @paper-step thm:monotone/real_pole_velocity
theorem distinct_velocity_nonnegative {x r l m : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r)
    (hl : 0 < l) (hlm : l < m) (hs : l+m=1+x) (hp : l*m=x/r)
    (hl1 : l ≤ 1) (t : ℝ) (ht : 0 ≤ t) : 0 ≤ (1+x)*e t+i t := by
  obtain ⟨he,hi⟩ := pi_state_unique h (distinct_mode_response x r l m hlm hs hp) hx hr t ht
  rw [he,hi]
  have hgap : 0 < m-l := sub_pos.mpr hlm
  have hsum : l*((1-l)/(m-l))+m*((m-1)/(m-l))=x := by
    field_simp
    nlinarith [hs]
  have hn := real_modes_nonnegative hlm.le
    (mul_nonneg hl.le (div_nonneg (by linarith) hgap.le))
    (show 0 ≤ l*((1-l)/(m-l))+m*((m-1)/(m-l)) by rw [hsum]; exact hx.le) ht
  simp only [realModeError,realModeIntegral] at hn ⊢
  have heq : (1+x)*(((1-l)/(m-l))*expError l t+((m-1)/(m-l))*expError m t)+
      (-m*((1-l)/(m-l))*expError l t-l*((m-1)/(m-l))*expError m t) =
      l*((1-l)/(m-l))*expError l t+m*((m-1)/(m-l))*expError m t := by
    linear_combination -(((1-l)/(m-l))*expError l t+((m-1)/(m-l))*expError m t)*hs
  rwa [heq]

-- @paper-step thm:monotone/nonovershoot_velocity
theorem pi_velocity_nonnegative {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r)
    (hd : MonotoneDomain x r) : ∀ t : ℝ, 0 ≤ t → 0 ≤ (1+x)*e t+i t := by
  let l := (1+x-Real.sqrt ((1+x)^2-4*x/r))/2
  let m := (1+x+Real.sqrt ((1+x)^2-4*x/r))/2
  obtain ⟨hl,hlm,hs,hp⟩ := real_root_identities hx hr (domain_discriminant hx hr hd)
  change 0 < l at hl
  change l ≤ m at hlm
  change l+m=1+x at hs
  change l*m=x/r at hp
  have hl1 := (real_root_domain hx hr hlm hs hp).mpr hd
  rcases hlm.eq_or_lt with heq | hlt
  · have hsum : 2*l=1+x := by linarith
    have hprod : l^2=x/r := by nlinarith
    intro t ht
    obtain ⟨he,hi⟩ := pi_state_unique h (repeated_response x r l hsum hprod) hx hr t ht
    rw [he,hi]
    have hid : (1+x)*repeatedError l t+repeatedIntegral l t = expError l t*(x+l*(1-l)*t) := by
      unfold repeatedError repeatedIntegral
      linear_combination -(expError l t*(1-l)*t)*hsum
    rw [hid]
    exact mul_nonneg (Real.exp_nonneg _) (by positivity)
  · exact distinct_velocity_nonnegative h hx hr hl hlt hs hp hl1

-- @paper-step thm:monotone/nonovershoot_monotonicity_equivalence
theorem pi_monotone_iff {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r) :
    MonotoneOn (fun t => 1-e t) (Ici 0) ↔ MonotoneDomain x r := by
  constructor
  · intro hm
    apply (pi_nonovershoot_iff h hx hr).mp
    intro t ht
    have hf := (pi_state_settles h hx hr).1
    have hbound : e t ≥ 0 := by
      apply le_of_tendsto hf
      filter_upwards [eventually_ge_atTop t] with s hs
      have hh := hm ht (ht.trans hs) hs
      linarith
    exact hbound
  · intro hd a ha b hb hab
    have hn : 0 ≤ ∫ t in a..b, e t+(x*e t+i t) := by
      rw [intervalIntegral.integral_of_le hab]
      apply integral_nonneg_of_ae
      filter_upwards [ae_restrict_mem measurableSet_Ioc] with t ht
      have hh := pi_velocity_nonnegative h hx hr hd t (ha.trans ht.1.le)
      change 0 ≤ e t+(x*e t+i t)
      nlinarith
    rw [response_increment (pi_state_response h hx hr) ha hab] at hn
    linarith

-- @paper-step thm:monotone/exponential_peak_bound
theorem two_mode_upper {l m C D X : ℝ} (hl : 0 ≤ l) (hlm : l ≤ m)
    (hC : C ≤ 0) (hs : C+D=X) {t : ℝ} (ht : 0 ≤ t) :
    realModeError l m C D t ≤ max 0 X := by
  have hm : 0 ≤ m := hl.trans hlm
  have heq : expError m t ≤ expError l t := Real.exp_le_exp.mpr (by nlinarith)
  have he0 : 0 ≤ expError m t := Real.exp_nonneg _
  have he1 : expError m t ≤ 1 := Real.exp_le_one_iff.mpr (by nlinarith)
  have hfirst : realModeError l m C D t ≤ X*expError m t := by
    unfold realModeError
    have hh := mul_le_mul_of_nonpos_left heq hC
    nlinarith [hh]
  by_cases hX : 0 ≤ X
  · rw [max_eq_right hX]
    exact hfirst.trans (mul_le_of_le_one_right hX he1)
  · rw [max_eq_left (le_of_not_ge hX)]
    exact hfirst.trans (mul_nonpos_of_nonpos_of_nonneg (le_of_not_ge hX) he0)

-- @paper-step thm:monotone/command_upper_bound
theorem pi_command_upper {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r)
    (hd : MonotoneDomain x r) (t : ℝ) (ht : 0 ≤ t) :
    1+(x*e t+i t) ≤ max 1 x := by
  let l := (1+x-Real.sqrt ((1+x)^2-4*x/r))/2
  let m := (1+x+Real.sqrt ((1+x)^2-4*x/r))/2
  obtain ⟨hl,hlm,hs,hp⟩ := real_root_identities hx hr (domain_discriminant hx hr hd)
  change 0 < l at hl
  change l ≤ m at hlm
  change l+m=1+x at hs
  change l*m=x/r at hp
  have hl1 := (real_root_domain hx hr hlm hs hp).mpr hd
  have hmax : 1+max 0 (x-1)=max 1 x := by
    rw [add_max]
    congr 1 <;> ring
  rcases hlm.eq_or_lt with heq | hlt
  · have hsum : 2*l=1+x := by linarith
    have hprod : l^2=x/r := by nlinarith
    obtain ⟨he,hi⟩ := pi_state_unique h (repeated_response x r l hsum hprod) hx hr t ht
    have hx1 : x ≤ 1 := by linarith
    rw [max_eq_left hx1,he,hi]
    have hid : x*repeatedError l t+repeatedIntegral l t =
        expError l t*((x-1)-(1-l)^2*t) := by
      unfold repeatedError repeatedIntegral
      linear_combination -(expError l t*(1-l)*t)*hsum
    rw [hid]
    have hh : 0 ≤ (1-l)^2*t := mul_nonneg (sq_nonneg _) ht
    have hneg := mul_nonpos_of_nonneg_of_nonpos (Real.exp_nonneg (-l*t))
      (show (x-1)-(1-l)^2*t ≤ 0 by linarith)
    change 1+Real.exp (-l*t)*((x-1)-(1-l)^2*t) ≤ 1
    linarith
  · obtain ⟨he,hi⟩ := pi_state_unique h (distinct_mode_response x r l m hlt hs hp) hx hr t ht
    have hgap : 0 < m-l := sub_pos.mpr hlt
    let C := -((1-l)^2)/(m-l)
    let D := (m-1)^2/(m-l)
    have hC : C ≤ 0 := div_nonpos_of_nonpos_of_nonneg (neg_nonpos.mpr (sq_nonneg _)) hgap.le
    have hsum : C+D=x-1 := by
      dsimp [C,D]
      field_simp
      nlinarith [hs]
    have hv : x*e t+i t = realModeError l m C D t := by
      rw [he,hi]
      dsimp [realModeError,realModeIntegral,C,D]
      field_simp
      linear_combination ((1-l)*expError l t+(m-1)*expError m t)*hs
    rw [hv,← hmax]
    have hh := two_mode_upper hl.le hlt.le hC hsum ht
    linarith

-- @paper-step thm:monotone/command_nonnegativity
theorem pi_command_nonnegative {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r)
    (hd : MonotoneDomain x r) (t : ℝ) (ht : 0 ≤ t) : 0 ≤ 1+(x*e t+i t) := by
  have he := (pi_nonovershoot_iff h hx hr).mpr hd
  rw [pi_state_integral_law h t ht]
  have hi : 0 ≤ ∫ s in 0..t, e s := by
    rw [intervalIntegral.integral_of_le ht]
    apply integral_nonneg_of_ae
    filter_upwards [ae_restrict_mem measurableSet_Ioc] with s hs
    exact he s hs.1.le
  exact add_nonneg (mul_nonneg hx.le (he t ht)) (mul_nonneg (div_nonneg hx.le hr.le) hi)

-- @paper-step thm:monotone/exact_command_supremum
theorem pi_command_peak {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r)
    (hd : MonotoneDomain x r) :
    IsLUB ((fun t => 1+(x*e t+i t)) '' Ici 0) (max 1 x) := by
  constructor
  · rintro u ⟨t,ht,rfl⟩
    exact pi_command_upper h hx hr hd t ht
  · intro B hB
    have hxB : x ≤ B := by
      have hh := hB (mem_image_of_mem (fun t => 1+(x*e t+i t)) (show (0:ℝ) ∈ Ici 0 by simp))
      simpa [h.initial_e,h.initial_i] using hh
    have hlim : Tendsto (fun t => 1+(x*e t+i t)) atTop (𝓝 1) := by
      have hf := pi_state_settles h hx hr
      simpa using tendsto_const_nhds.add ((hf.1.const_mul x).add hf.2)
    have h1B : 1 ≤ B := by
      apply le_of_tendsto hlim
      filter_upwards [eventually_ge_atTop (0:ℝ)] with t ht
      exact hB (mem_image_of_mem _ ht)
    exact max_le h1B hxB

-- @paper-step thm:monotone/full_statement
theorem paper_monotone_pi {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r) :
    ((∀ t : ℝ, 0 ≤ t → 1-e t ≤ 1) ↔ MonotoneDomain x r) ∧
    (MonotoneOn (fun t => 1-e t) (Ici 0) ↔ MonotoneDomain x r) ∧
    (1-e 0=0 ∧ Tendsto (fun t => 1-e t) atTop (𝓝 1)) ∧
    (MonotoneDomain x r →
      (∀ t : ℝ, 0 ≤ t → 0 ≤ 1+(x*e t+i t) ∧ 1+(x*e t+i t) ≤ max 1 x) ∧
      IsLUB ((fun t => 1+(x*e t+i t)) '' Ici 0) (max 1 x)) := by
  refine ⟨?_,pi_monotone_iff h hx hr,⟨by simp [h.initial_e],?_⟩,?_⟩
  · simpa only [sub_le_self_iff] using pi_nonovershoot_iff h hx hr
  · simpa using tendsto_const_nhds.sub (pi_state_settles h hx hr).1
  · intro hd
    exact ⟨fun t ht => ⟨pi_command_nonnegative h hx hr hd t ht,pi_command_upper h hx hr hd t ht⟩,
      pi_command_peak h hx hr hd⟩
end MIACE
