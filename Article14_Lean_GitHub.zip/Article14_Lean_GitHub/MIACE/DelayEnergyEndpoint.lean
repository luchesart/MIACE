import MIACE.ScalarDelayGain

/-! Stage 19. The Lyapunov dissipation identity also evaluates the exact
infinite-horizon energy. The terminal functional vanishes from actual
trajectory decay; the initial constant-history value is integrated exactly. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step prop:delayed_quadratic/lyapunov_history_translation
theorem scalarDelayLyapunov_translate {w : ℝ → ℝ} (hw : Continuous w) (h t : ℝ) :
    scalarDelayLyapunov h w t=scalarDelayLyapunov h (fun r => w (t+r)) 0 := by
  have hc : Continuous (fun r => w (t+r)) := hw.comp (continuous_const.add continuous_id)
  have hp (s : ℝ) : delayCosWindow h w t s=delayCosWindow h (fun r => w (t+r)) 0 s := by
    rw [(delayWindows_integral hw h t s).1,(delayWindows_integral hc h 0 s).1]
    congr 1; funext r; congr 2; ring
  have hq (s : ℝ) : delaySinWindow h w t s=delaySinWindow h (fun r => w (t+r)) 0 s := by
    rw [(delayWindows_integral hw h t s).2,(delayWindows_integral hc h 0 s).2]
    congr 1; funext r; congr 2; ring
  simp only [scalarDelayLyapunov,delayWindowEnergy,add_zero,hp,hq]

-- @paper-step prop:delayed_quadratic/vanishing_terminal_history_energy
theorem scalarDelayLyapunov_tendsto_zero {h : ℝ} (h0 : 0≤h) (hh : h<Real.pi/2)
    {w : ℝ → ℝ} (hw : Continuous w) (hlim : Tendsto w atTop (𝓝 0)) :
    Tendsto (scalarDelayLyapunov h w) atTop (𝓝 0) := by
  rw [Metric.tendsto_atTop]
  intro ε hε
  let K := scalarDelayHistoryGain h
  have hK : 0≤K := scalarDelayHistoryGain_nonneg h0 hh
  let M := Real.sqrt (ε/(K+1))
  have hM : 0<M := Real.sqrt_pos.2 (div_pos hε (by linarith))
  have hMsq : M^2=ε/(K+1) := Real.sq_sqrt (by positivity)
  obtain ⟨T,hT⟩ := (Metric.tendsto_atTop.mp hlim) M hM
  refine ⟨T+h,?_⟩
  intro t ht
  have hb : ∀ s∈Icc (-h) 0, |w (t+s)|≤M := by
    intro s hs
    have hx := hT (t+s) (by linarith [hs.1])
    simpa only [Real.dist_eq,sub_zero] using hx.le
  have hc := hw.comp (continuous_const.add continuous_id : Continuous (fun s : ℝ => t+s))
  have hbound := scalarDelayLyapunov_initial_bound h0 hh hM.le hc hb
  change scalarDelayLyapunov h (fun r => w (t+r)) 0≤K*M^2 at hbound
  rw [← scalarDelayLyapunov_translate hw h t] at hbound
  rw [Real.dist_eq,sub_zero,abs_of_nonneg (scalarDelayLyapunov_nonneg h0 hh w t)]
  have hsmall : K*M^2<ε := by
    rw [hMsq,← mul_div_assoc]
    apply (div_lt_iff₀ (by linarith : 0<K+1)).mpr
    nlinarith
  exact hbound.trans_lt hsmall

-- @paper-step prop:delayed_quadratic/infinite_energy_equals_initial_functional
theorem scalarDelay_exact_energy {h : ℝ} (h0 : 0≤h) (hh : h<Real.pi/2)
    {w : ℝ → ℝ} (hw : Continuous w)
    (hd : ∀ t, 0<t → HasDerivAt w (-w (t-h)) t) :
    (∫ t in Ioi (0 : ℝ), (w t)^2)=scalarDelayLyapunov h w 0 := by
  have hi := scalarDelay_square_integrable h0 hh hw hd
  have hlim := scalarDelayLyapunov_tendsto_zero h0 hh hw (scalarDelay_history_decay h0 hh hw hd)
  have he : (fun T => ∫ t in (0 : ℝ)..T, (w t)^2)=ᶠ[atTop]
      (fun T => scalarDelayLyapunov h w 0-scalarDelayLyapunov h w T) := by
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with T hT
    exact scalarDelay_energy_identity h0 hh hw hd hT
  exact tendsto_nhds_unique (intervalIntegral_tendsto_integral_Ioi 0 hi tendsto_id)
    (by simpa using (tendsto_const_nhds.sub hlim).congr' he.symm)

-- @paper-step prop:delayed_quadratic/constant_initial_history_windows
theorem delayWindows_constant_history {h : ℝ} (h0 : 0≤h) {w : ℝ → ℝ}
    (hw : Continuous w) (hpast : ∀ s∈Icc (-h) 0, w s=1) {s : ℝ} (hs : s∈Icc 0 h) :
    delayCosWindow h w 0 s=Real.sin h-Real.sin s ∧
    delaySinWindow h w 0 s=Real.cos s-Real.cos h := by
  rw [(delayWindows_integral hw h 0 s).1,(delayWindows_integral hw h 0 s).2]
  have he (f : ℝ → ℝ) : (∫ r in s..h, f r*w (0-h+r))=∫ r in s..h, f r := by
    apply intervalIntegral.integral_congr
    intro r hr
    rw [uIcc_of_le hs.2] at hr
    dsimp only
    rw [hpast _ ⟨by linarith [hs.1,hr.1],by linarith [hr.2]⟩,mul_one]
  rw [he,he]
  constructor
  · exact intervalIntegral.integral_eq_sub_of_hasDerivAt (fun r _ => Real.hasDerivAt_sin r)
      (Real.continuous_cos.intervalIntegrable s h)
  · have hh := intervalIntegral.integral_eq_sub_of_hasDerivAt (fun r _ => Real.hasDerivAt_cos r)
      (Real.continuous_sin.neg.intervalIntegrable s h)
    rw [intervalIntegral.integral_neg] at hh
    linarith

-- @paper-step prop:delayed_quadratic/explicit_constant_history_energy_integral
theorem constant_history_window_energy {h : ℝ} (h0 : 0≤h) (hh : h<Real.pi/2) :
    (∫ s in (0 : ℝ)..h, ((Real.sin h-Real.sin s)/Real.cos s)^2)=
      (1+(Real.sin h)^2)*Real.sin h/Real.cos h-2*Real.sin h/Real.cos h+2*Real.sin h-h := by
  let F := fun s => (1+(Real.sin h)^2)*Real.sin s/Real.cos s-2*Real.sin h/Real.cos s-s
  have hd (s : ℝ) (hc : Real.cos s≠0) :
      HasDerivAt F (((Real.sin h-Real.sin s)/Real.cos s)^2) s := by
    convert ((((Real.hasDerivAt_sin s).const_mul (1+(Real.sin h)^2)).div
      (Real.hasDerivAt_cos s) hc).sub
      ((hasDerivAt_const s (2*Real.sin h)).div (Real.hasDerivAt_cos s) hc)).sub (hasDerivAt_id s) using 1
    · rfl
    · field_simp
      linear_combination -((Real.sin h)^2)*(Real.sin_sq_add_cos_sq s)
  have hcont : ContinuousOn (fun s => ((Real.sin h-Real.sin s)/Real.cos s)^2) (Icc 0 h) :=
    ((continuous_const.sub Real.continuous_sin).continuousOn.div Real.continuous_cos.continuousOn
      (fun s hs => ne_of_gt (delay_cos_pos hh hs))).pow 2
  have hi := intervalIntegral.integral_eq_sub_of_hasDerivAt
    (fun s hs => hd s (ne_of_gt (delay_cos_pos hh (by simpa only [uIcc_of_le h0] using hs))))
    (hcont.intervalIntegrable_of_Icc h0)
  dsimp [F] at hi
  simp only [Real.sin_zero,Real.cos_zero,mul_zero,zero_div,div_one,sub_zero,zero_sub] at hi
  linarith

-- @paper-step prop:delayed_quadratic/initial_energy_in_closed_trigonometric_form
theorem scalarDelayLyapunov_constant_history {h : ℝ} (h0 : 0≤h) (hh : h<Real.pi/2)
    {w : ℝ → ℝ} (hw : Continuous w) (hpast : ∀ s∈Icc (-h) 0, w s=1) :
    scalarDelayLyapunov h w 0=(1+Real.sin h)/(2*Real.cos h)-h := by
  have hzero : (0 : ℝ)∈Icc 0 h := ⟨le_rfl,h0⟩
  have hwin := delayWindows_constant_history h0 hw hpast hzero
  have hI : delayWindowEnergy h w 0=
      ∫ s in (0 : ℝ)..h, ((Real.sin h-Real.sin s)/Real.cos s)^2 := by
    apply intervalIntegral.integral_congr
    intro s hs
    dsimp only
    rw [(delayWindows_constant_history h0 hw hpast (by simpa only [uIcc_of_le h0] using hs)).1]
  unfold scalarDelayLyapunov
  rw [hpast 0 ⟨by linarith,le_rfl⟩,hwin.1,hwin.2,hI,constant_history_window_energy h0 hh]
  simp only [Real.sin_zero,Real.cos_zero,sub_zero]
  have hc : Real.cos h≠0 := ne_of_gt (delay_cos_pos hh ⟨h0,le_rfl⟩)
  field_simp
  linear_combination (3*Real.sin h-1)*(Real.sin_sq_add_cos_sq h)

end MIACE
