import MIACE.PaperCompletion

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:complete_robust/every_finite_continuous_history_has_a_bound
theorem imcHistory_bound_exists (N : ℕ) (F : IMCFilter) (δ ε : ℝ) (H : IMCHistory)
    (hp : ContinuousOn H.plantPast (Icc (-(δ+ε)) 0))
    (hm : ContinuousOn H.modelPast (Icc (-δ) 0))
    (hf : ContinuousOn H.filterPast (Icc (-F.delay) 0)) :
    ∃ M : ℝ, IMCHistoryBound N F δ ε H M := by
  obtain ⟨P,hP⟩ := isCompact_Icc.exists_bound_of_continuousOn hp
  obtain ⟨Q,hQ⟩ := isCompact_Icc.exists_bound_of_continuousOn hm
  obtain ⟨R,hR⟩ := isCompact_Icc.exists_bound_of_continuousOn hf
  let A := ∑ j∈Finset.range (N+1), |H.plantInitial j|
  let B := ∑ j∈Finset.range (N+1), |H.modelInitial j|
  have hA : 0≤A := Finset.sum_nonneg (fun _ _ => abs_nonneg _)
  have hB : 0≤B := Finset.sum_nonneg (fun _ _ => abs_nonneg _)
  let M := A+B+|H.filterInitial|+|P|+|Q|+|R|
  have hM : 0≤M := by dsimp [M]; positivity
  refine ⟨M,⟨hM,?_,?_,?_,hp,hm,hf,?_,?_,?_⟩⟩
  · intro j hj
    have hh : |H.plantInitial j|≤A := Finset.single_le_sum (s := Finset.range (N+1)) (f := fun k => |H.plantInitial k|)
      (fun _ _ => abs_nonneg _) (show j∈Finset.range (N+1) from Finset.mem_range.mpr (by omega))
    dsimp [M]; linarith [abs_nonneg H.filterInitial,abs_nonneg P,abs_nonneg Q,abs_nonneg R]
  · intro j hj
    have hh : |H.modelInitial j|≤B := Finset.single_le_sum (s := Finset.range (N+1)) (f := fun k => |H.modelInitial k|)
      (fun _ _ => abs_nonneg _) (show j∈Finset.range (N+1) from Finset.mem_range.mpr (by omega))
    dsimp [M]; linarith [abs_nonneg H.filterInitial,abs_nonneg P,abs_nonneg Q,abs_nonneg R]
  · dsimp [M]; linarith [abs_nonneg P,abs_nonneg Q,abs_nonneg R]
  · intro s hs
    have hh : |H.plantPast s|≤P := hP s hs
    dsimp [M]; linarith [le_abs_self P,abs_nonneg H.filterInitial,abs_nonneg Q,abs_nonneg R]
  · intro s hs
    have hh : |H.modelPast s|≤Q := hQ s hs
    dsimp [M]; linarith [le_abs_self Q,abs_nonneg H.filterInitial,abs_nonneg P,abs_nonneg R]
  · intro s hs
    have hh : |H.filterPast s|≤R := hR s hs
    dsimp [M]; linarith [le_abs_self R,abs_nonneg H.filterInitial,abs_nonneg P,abs_nonneg Q]

-- @paper-step thm:complete_robust/ordinary_step_uniqueness_without_growth_assumptions
theorem imc_step_command_unique (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) {δ ε : ℝ}
    (hδ : 0≤δ) (hδε : 0≤δ+ε) (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1)
    (hq : imcDelayGain F ε<1) {u w : ℝ → ℝ}
    (hu : LocallyIntegrable u volume) (hw : LocallyIntegrable w volume) (huc : Causal u) (hwc : Causal w)
    (hue : u=ᵐ[volume] imcReferenceFeedback N σ F δ ε zeroIMCHistory unitStep u)
    (hwe : w=ᵐ[volume] imcReferenceFeedback N σ F δ ε zeroIMCHistory unitStep w) : u=ᵐ[volume] w := by
  let ss := serialRatios σ N
  have hs : ∀ τ∈ss, 0<τ := fun τ hτ => (serialRatios_normalized σ N hσ τ hτ).1
  have hP := cascadeKernel_properties ss hs
  have hD : Integrable (delayMismatchKernel ss δ ε) :=
    (shift_integrable (δ+ε) hP.1).sub (shift_integrable δ hP.1)
  have hDc : Causal (delayMismatchKernel ss δ ε) := by
    filter_upwards [causal_shift hP.2.2.2 hδε,causal_shift hP.2.2.2 hδ] with t ht hs hn
    simp [delayMismatchKernel,ht hn,hs hn]
  have hK := imcLoopKernel_properties F ss hs hδ hδε
  have hid (v : ℝ → ℝ) (hv : LocallyIntegrable v volume) (hvc : Causal v)
      (he : v=ᵐ[volume] imcReferenceFeedback N σ F δ ε zeroIMCHistory unitStep v) :
      v=ᵐ[volume] (fun t => filterAction F unitStep t+(imcLoopKernel F ss δ ε ⋆ v) t) := by
    have h1 := he.trans (zeroHistory_reference_feedback N σ F hδ hδε
      (fun j hj => (hσ j hj).1) hfirst hv hvc)
    have hDv := causalLocalOperator_local_integrable (convolution_local_operator hD hDc) hv hvc
    have hDvc : Causal (delayMismatchKernel ss δ ε ⋆ v) := ae_of_all volume (convolution_causal hDc hvc)
    have h2 := local_filter_sub F unitStep_local hDv (causalize_causal _) hDvc
    have h3 := imcLoopKernel_convolution F ss δ ε hD hDc hv hvc
    filter_upwards [h1,h2,h3] with t ht hs hj
    change v t=filterAction F (fun s => unitStep s-(delayMismatchKernel ss δ ε ⋆ v) s) t at ht
    rw [ht,hs,hj]
    ring
  exact local_renewal_unique hK.1 hK.2.1 (hK.2.2.trans_lt hq) hu hw huc hwc
    (hid u hu huc hue) (hid w hw hwc hwe)

-- @paper-step thm:complete_attainment/arbitrary_ordinary_storage_evolution_unique
theorem serialEvolution_unique (N : ℕ) (σ ξ : ℕ → ℝ) (u : ℝ → ℝ) (x : ℕ → ℝ → ℝ)
    (hx0 : ∀ t, 0≤t → x 0 t=u t)
    (hx : ∀ j≤N, LagEvolution (σ j) (ξ j) (x j) (x (j+1))) :
    ∀ j≤N+1, ∀ t, 0≤t → x j t=serialState σ ξ u j t := by
  intro j hj
  induction j with
  | zero => exact hx0
  | succ j ih =>
    intro t ht
    rw [lagEvolution_formula (hx j (by omega)) ht]
    change lagState (σ j) (ξ j) (x j) t=lagState (σ j) (ξ j) (serialState σ ξ u j) t
    unfold lagState lag
    congr 2
    apply intervalIntegral.integral_congr
    intro s hs
    rw [uIcc_of_le ht] at hs
    change Real.exp (s/σ j)*x j s=Real.exp (s/σ j)*serialState σ ξ u j s
    rw [ih (by omega) s hs.1]

-- The stored transport segment, not only the outgoing delayed signal,
-- inherits a uniform exponential bound (essentially for ordinary inputs).
-- @paper-step thm:complete_robust/full_transport_memory_exponential_bound
theorem transport_memory_decay {δ η M C t : ℝ} {φ f : ℝ → ℝ}
    (hη : 0≤η) (hM : 0≤M) (ht : 0≤t)
    (hφ : ∀ s∈Icc (-δ) 0, |φ s|≤M) (hf : WeightedControl η f C) :
    ∀ᵐ s, s∈Icc (-δ) 0 →
      |if t+s<0 then φ (t+s) else f (t+s)|≤
        (M+C)*Real.exp (η*δ)*Real.exp (-η*t) := by
  have hh := (measurePreserving_add_left (volume : Measure ℝ) t).quasiMeasurePreserving.tendsto_ae.eventually
    (weightedControl_decay hf)
  filter_upwards [hh] with s hs hsi
  have hex : Real.exp (η*δ)*Real.exp (-η*t)=Real.exp (η*δ-η*t) := by
    rw [← Real.exp_add]; congr 1; ring
  rw [mul_assoc,hex]
  by_cases hn : t+s<0
  · rw [if_pos hn]
    have hmem : t+s∈Icc (-δ) 0 := ⟨by linarith [hsi.1],hn.le⟩
    have he : 1≤Real.exp (η*δ-η*t) := Real.one_le_exp_iff.mpr (by nlinarith [hsi.1])
    have hp := mul_le_mul_of_nonneg_left he (add_nonneg hM hf.nonneg)
    exact (hφ (t+s) hmem).trans (by nlinarith [hf.nonneg])
  · rw [if_neg hn]
    have he : Real.exp (-η*(t+s))≤Real.exp (η*δ-η*t) := Real.exp_le_exp.mpr (by nlinarith [hsi.1])
    exact hs.trans ((mul_le_mul_of_nonneg_left he hf.nonneg).trans
      (mul_le_mul_of_nonneg_right (by linarith) (Real.exp_nonneg _)))

-- The paper's half-open pulse is obtained pointwise, including both jumps.
-- @paper-step thm:complete_cap/actual_half_open_pulse_and_pointwise_cap
theorem pulseIMC_pointwise_command {c T : ℝ} (hc : 0≤c) (hT : 0≤T) :
    (∀ t, 0≤t → filterAction (pulseIMC c T hT) unitStep t=
      if t<T then 1+c else 1) ∧
    ∀ t, 0≤t → 1≤filterAction (pulseIMC c T hT) unitStep t ∧
      filterAction (pulseIMC c T hT) unitStep t≤1+c := by
  have he (t : ℝ) (ht : 0≤t) : filterAction (pulseIMC c T hT) unitStep t=
      if t<T then 1+c else 1 := by
    by_cases hlt : t<T
    · simp [filterAction,pulseIMC,unitStep,causalize,shift,ht,hlt,show ¬0≤t-T by linarith]
    · simp [filterAction,pulseIMC,unitStep,causalize,shift,ht,hlt,show 0≤t-T by linarith]
  refine ⟨he,?_⟩
  intro t ht
  rw [he t ht]
  split_ifs <;> constructor <;> linarith

end MIACE
