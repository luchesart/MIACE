import MIACE.NonlinearExample
import MIACE.NonlinearCompletion

/-! The exact implicit trajectory and original MIACE areas for the
nonlinear example after Theorem 32. All identities use the constructed
physical response; no sampled trajectory is substituted for a proof. -/

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:nonlinear_miace/example_implicit_trajectory
theorem nonlinear_example_flow_clock {y : ℝ → ℝ} {c : ℝ}
    (hy0 : y 0 = 0)
    (hyd : ∀ t, 0 ≤ t → HasDerivAt y (c * nonlinearExampleRate (y t) * (1-y t)) t)
    (hylt : ∀ t, 0 ≤ t → y t < 1) {t : ℝ} (ht : 0 ≤ t) :
    c*t = nonlinearExampleClock (y t) := by
  have hder : ∀ s ∈ uIcc (0 : ℝ) t,
      HasDerivAt (fun z => nonlinearExampleClock (y z)) c s := by
    intro s hs
    rw [uIcc_of_le ht] at hs
    have h1 : 1-y s ≠ 0 := by linarith [hylt s hs.1]
    have h2 : 1+(y s)^2 ≠ 0 := ne_of_gt (by positivity)
    convert (nonlinear_example_clock_derivative (hylt s hs.1)).comp s (hyd s hs.1) using 1
    · rfl
    · unfold nonlinearExampleRate
      field_simp
  have hFTC := intervalIntegral.integral_eq_sub_of_hasDerivAt hder
    (intervalIntegrable_const : IntervalIntegrable (fun _ : ℝ => c) volume 0 t)
  simpa [hy0, nonlinear_example_clock_zero, mul_comm] using hFTC

-- @paper-step thm:nonlinear_miace/example_constructed_feedback
theorem nonlinear_example_feedback_exists {α : ℝ} (hα : 0 < α) :
    ∃ y : ℝ → ℝ,
      NonlinearResponse nonlinearExampleRate y (fun t => 1 + (1-y t)/α) ∧
      (∀ t, 0 ≤ t → 0 ≤ y t ∧ y t < 1 ∧
        (1+1/α)*t = nonlinearExampleClock (y t)) := by
  obtain ⟨y, hyC, hy0, hyd, hyb, hylim, hye⟩ := nonlinear_flow_exists_admissible
    nonlinear_example_rate_continuous nonlinear_example_rate_pos
    (show 0 < 1+1/α by positivity) (show 0 < (1 : ℝ) by norm_num)
    (fun x hx => (nonlinear_example_rate_bounds hx).1)
    (fun x hx => (nonlinear_example_rate_bounds hx).2)
  have hr : NonlinearResponse nonlinearExampleRate y (fun t => 1 + (1-y t)/α) := by
    refine ⟨?_, ?_, hy0, hylim, hye, ?_⟩
    · intro T hT
      exact hyC.contDiffOn.absolutelyContinuousOnInterval
    · apply ae_of_all
      intro t ht
      rw [(hyd t ht.le).deriv]
      ring
    · convert hye.div_const α using 1
      funext t
      ring
  refine ⟨y, hr, ?_⟩
  intro t ht
  exact ⟨(hyb t ht).1, (hyb t ht).2.1,
    nonlinear_example_flow_clock hy0 hyd (fun s hs => (hyb s hs).2.1) ht⟩

-- @paper-step thm:nonlinear_miace/example_equal_weight_cost
theorem nonlinear_example_unit_weight_cost :
    (Real.pi / 4) * minimum 1 = Real.pi / (4 * Real.sqrt 2) := by
  unfold minimum
  norm_num only [show (1 : ℝ)+1 = 2 by norm_num]
  rw [Real.sqrt_div (by norm_num), Real.sqrt_one]
  field_simp

-- @paper-step thm:nonlinear_miace/example_exact_optimal_response
theorem nonlinear_example_exact_response :
    ∃ y : ℝ → ℝ,
      NonlinearResponse nonlinearExampleRate y (fun t => 2-y t) ∧
      (∀ t, 0 ≤ t → 0 ≤ y t ∧ y t < 1 ∧
        2*t = nonlinearExampleClock (y t)) ∧
      absArea (fun t => 1-y t) halfLine = Real.pi / 8 ∧
      absArea (fun t => (2-y t)-1) halfLine = Real.pi / 8 ∧
      miace 1 (fun t => 1-y t) (fun t => (2-y t)-1) halfLine =
        Real.pi / (4 * Real.sqrt 2) := by
  obtain ⟨y, hr, hb⟩ := nonlinear_example_feedback_exists (show 0 < (1 : ℝ) by norm_num)
  obtain ⟨hc, he, hu⟩ := nonlinear_feedback_optimum nonlinear_example_rate_continuous
    nonlinear_example_rate_pos (show 0 < (1 : ℝ) by norm_num) hr
    (fun t ht => (hb t ht).2.1.le)
  have hS : storageArea nonlinearExampleRate = Real.pi / 4 :=
    nonlinear_example_storage_integral
  have hw : (fun t => 1 + (1-y t)/(1 : ℝ)) = (fun t => 2-y t) := by
    funext t
    ring
  rw [hw] at hr
  have hvc : (fun t => (1 + (1-y t)/(1 : ℝ))-1) = (fun t => (2-y t)-1) := by
    funext t
    ring
  rw [hvc, hS] at hc hu
  rw [hS] at he
  refine ⟨y, hr, ?_, ?_, ?_, ?_⟩
  · intro t ht
    simpa only [div_one, show (1 : ℝ)+1=2 by norm_num] using hb t ht
  · convert he using 1
    ring
  · convert hu using 1
    ring
  · exact hc.trans nonlinear_example_unit_weight_cost

end MIACE
