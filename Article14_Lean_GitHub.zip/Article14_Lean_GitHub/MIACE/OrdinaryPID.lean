import MIACE.PIDTimeStates

/-! Етап 9: събран сертификат за конкретни непрекъснати времеви сигнали.
    Всеки член на структурата се доказва от TwoRateData в теоремата за съществуване.
    Уравненията на затворения контур тук все още са в TransferResponse семантиката. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

structure OrdinaryPIDSignals (i ρ ell δ : ℝ) (E V : ℝ → ℝ) : Prop where
  error_continuous : Continuous E
  command_continuous : Continuous V
  error_ac : ∀ a b : ℝ, AbsolutelyContinuousOnInterval E a b
  command_ac : ∀ a b : ℝ, AbsolutelyContinuousOnInterval V a b
  error_initial : E 0=1
  command_initial : V 0=i*(1+ell-ρ)+i*(ell-ρ)*(1-ρ)/ρ-1
  error_positive : ∀ t : ℝ, 0≤t → 0<E t
  command_nonneg : ∀ t : ℝ, 0≤t → 0≤V t
  decay : ∃ η Ce Cv : ℝ, 0<η ∧ η≤1/2 ∧ 0≤Ce ∧ 0≤Cv ∧
    Integrable (expWeight η (causalize E)) ∧ Integrable (expWeight η (causalize V)) ∧
    ∀ t : ℝ, 0≤t → |E t|≤Ce*Real.exp (-η*t) ∧ |V t|≤Cv*Real.exp (-η*t)
  plant : TransferResponse E V (fun p => 1/(1+p)) δ
  controller : ∀ p : ℝ, 0<p → 1/p+laplace V p=
    (i*(1+ell-ρ)+i/p+i*(ell-ρ)*(1-ρ)*p/(1+ρ*p))*laplace E p
  error_mass : (∫ t, E t ∂halfLine)=1/i
  command_mass : (∫ t, V t ∂halfLine)=1+δ-1/i

-- @paper-step thm:pid_two_rate_optimum/representative_halfline_identity
theorem representative_halfLine_ae {z F : ℝ → ℝ} (hz : z=ᵐ[volume] causalize F) :
    z=ᵐ[halfLine] F := by
  have hh := hz.filter_mono (ae_mono (Measure.restrict_le_self (s := Ioi (0 : ℝ))))
  filter_upwards [hh,ae_restrict_mem measurableSet_Ioi] with t ht hpos
  rw [ht,causalize,indicator_of_mem (show t∈Ici (0 : ℝ) from (show 0<t from hpos).le)]

-- @paper-step thm:pid_two_rate_optimum/halfline_transform_invariance
theorem laplace_congr_halfLine {f g : ℝ → ℝ} (he : f=ᵐ[halfLine] g) (p : ℝ) :
    laplace f p=laplace g p := by
  apply integral_congr_ae
  filter_upwards [he] with t ht
  rw [ht]

-- @paper-step thm:pid_two_rate_optimum/ordinary_transfer_invariance
theorem transfer_response_congr {e v E V H : ℝ → ℝ} {δ : ℝ}
    (h : TransferResponse e v H δ) (he : e=ᵐ[halfLine] E) (hv : v=ᵐ[halfLine] V) :
    TransferResponse E V H δ := by
  refine ⟨h.error_integrable.congr he,h.command_integrable.congr hv,?_⟩
  intro p hp
  have hy := laplace_congr_halfLine (he.fun_comp (fun x => 1-x)) p
  have hw := laplace_congr_halfLine (hv.fun_comp (fun x => 1+x)) p
  simp only [Function.comp_def] at hy hw
  rw [← hy,← hw]
  exact h.zero_state p hp

-- @paper-step thm:pid_two_rate_optimum/weighted_representative_invariance
theorem weighted_integrable_congr {f g : ℝ → ℝ} (he : f=ᵐ[volume] g) {η : ℝ}
    (hf : Integrable (expWeight η f)) : Integrable (expWeight η g) := by
  apply hf.congr
  filter_upwards [he] with t ht
  simp only [expWeight,ht]

-- @paper-step thm:pid_two_rate_optimum/assembled_ordinary_signal_certificate
theorem twoRate_ordinary_signals {i ρ ell l m δ : ℝ} (h : TwoRateData i ρ ell l m δ) :
    ∃ E V : ℝ → ℝ, OrdinaryPIDSignals i ρ ell δ E V := by
  obtain ⟨e,v,hs,hen,hvn,hplant,hcontroller,heint,hvint,hw⟩ := twoRate_closed_loop_exists h
  let A := twoRateA ρ l m
  let E := twoRateErrorRep A l m δ e
  let V := twoRateCommandRep A l m δ v
  have hae := twoRate_representatives_ae h hs
  have hehalf := representative_halfLine_ae hae.1
  have hvhalf := representative_halfLine_ae hae.2
  have hec := twoRateErrorRep_regularity (L1.integrable_coeFn e) A l m h.delay_nonneg
  have hvc := twoRateCommandRep_continuous (L1.integrable_coeFn v) A l m h.delay_nonneg
  have hinit := twoRate_representatives_initial h hs
  have hD := twoRateD_initial_gain h
  refine ⟨E,V,⟨hec.1,hvc,hec.2,
    twoRateCommandRep_ac (L1.integrable_coeFn v) A l m h.delay_nonneg,
    hinit.1,?_,?_,?_,?_,transfer_response_congr hplant hehalf hvhalf,?_,?_,?_⟩⟩
  · change twoRateCommandRep A l m δ v 0=_
    rw [hinit.2,hD.1,← hD.2]
  · intro t ht; exact (twoRate_representatives_nonneg h hen hvn ht).1
  · intro t ht; exact (twoRate_representatives_nonneg h hen hvn ht).2
  · obtain ⟨η,hη,hηb,hew,hvw⟩ := hw
    obtain ⟨Ce,Cv,hCe,hCv,hbound⟩ := twoRate_representatives_decay h hη hηb hew hvw
    exact ⟨η,Ce,Cv,hη,hηb,hCe,hCv,weighted_integrable_congr hae.1 hew,
      weighted_integrable_congr hae.2 hvw,hbound⟩
  · intro p hp
    rw [← laplace_congr_halfLine hehalf,← laplace_congr_halfLine hvhalf]
    exact hcontroller p hp
  · rw [← integral_congr_ae hehalf,← causal_integral_halfLine hs.error_causal]
    exact heint
  · rw [← integral_congr_ae hvhalf,← causal_integral_halfLine hs.command_causal]
    exact hvint

-- @paper-step thm:pid_two_rate_optimum/ordinary_signal_settling
theorem ordinary_PID_settling {i ρ ell δ : ℝ} {E V : ℝ → ℝ}
    (h : OrdinaryPIDSignals i ρ ell δ E V) :
    Tendsto E atTop (𝓝 0) ∧ Tendsto V atTop (𝓝 0) ∧
    (1-E 0)=0 ∧ Tendsto (fun t => 1-E t) atTop (𝓝 1) ∧
    ∀ t : ℝ, 0≤t → 1-E t<1 := by
  obtain ⟨η,Ce,Cv,hη,_,_,_,_,_,hb⟩ := h.decay
  have he := tendsto_zero_of_exp_bound hη (fun t ht => (hb t ht).1)
  have hv := tendsto_zero_of_exp_bound hη (fun t ht => (hb t ht).2)
  refine ⟨he,hv,by rw [h.error_initial]; ring,?_,?_⟩
  · simpa using tendsto_const_nhds.sub he
  · intro t ht; linarith [h.error_positive t ht]

-- @paper-step thm:pid_two_rate_optimum/constructed_controller_states_settle
theorem ordinary_PID_controller_states {i ρ ell l m δ : ℝ} (hp : TwoRateData i ρ ell l m δ)
    {E V : ℝ → ℝ} (h : OrdinaryPIDSignals i ρ ell δ E V) :
    (∫ s in (0 : ℝ)..0, E s)=0 ∧ lag ρ E 0=0 ∧
    (∀ t : ℝ, HasDerivAt (fun u => ∫ s in 0..u, E s) (E t) t) ∧
    (∀ t : ℝ, 0<t → HasDerivAt (lag ρ E) ((E t-lag ρ E t)/ρ) t) ∧
    Tendsto (fun t => ∫ s in 0..t, E s) atTop (𝓝 (1/i)) ∧
    Tendsto (lag ρ E) atTop (𝓝 0) := by
  obtain ⟨hz,hζ,hdz,hdζ,_⟩ := pid_state_functions h.error_continuous hp.filter_pos
  refine ⟨hz,hζ,hdz,hdζ,?_,?_⟩
  · have hh := intervalIntegral_tendsto_integral_Ioi 0 h.plant.error_integrable tendsto_id
    rwa [h.error_mass] at hh
  · obtain ⟨η,_,_,hη,hηb,_,_,he,_,_⟩ := h.decay
    have hr : 1<1/ρ := (lt_div_iff₀ hp.filter_pos).mpr (by linarith [hp.filter_lt_one])
    exact tendsto_zero_of_exp_bound hη (fun _ ht => lag_weighted_decay hp.filter_pos
      (by linarith : η≤1/ρ) he ht)

-- @paper-step thm:pid_two_rate_optimum/ordinary_global_MIACE_optimum
theorem twoRate_ordinary_optimum {α ρ ell l m δ : ℝ} (hα : 0<α)
    (h : TwoRateData ((1+1/α)/(1+δ)) ρ ell l m δ) :
    ∃ E V : ℝ → ℝ, OrdinaryPIDSignals ((1+1/α)/(1+δ)) ρ ell δ E V ∧
      absArea E halfLine=α*(1+δ)/(1+α) ∧ absArea V halfLine=(1+δ)/(1+α) ∧
      miace α E V halfLine=(1+δ)*minimum α ∧
      ∀ e v : ℝ → ℝ, TransferResponse e v (fun p => 1/(1+p)) δ →
        miace α E V halfLine≤miace α e v halfLine := by
  obtain ⟨E,V,hs⟩ := twoRate_ordinary_signals h
  have hepos : ∀ᵐ t ∂halfLine, 0≤E t := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact (hs.error_positive t ht.le).le
  have hvpos : ∀ᵐ t ∂halfLine, 0≤V t := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact hs.command_nonneg t ht.le
  have hearea : absArea E halfLine=α*(1+δ)/(1+α) := by
    have heq : absArea E halfLine=∫ t, E t ∂halfLine :=
      integral_congr_ae (hepos.mono (fun _ hn => abs_of_nonneg hn))
    rw [heq,hs.error_mass,(pid_optimal_gain hα h.delay_nonneg).2]
  have hvarea : absArea V halfLine=(1+δ)/(1+α) := by
    have heq : absArea V halfLine=∫ t, V t ∂halfLine :=
      integral_congr_ae (hvpos.mono (fun _ hn => abs_of_nonneg hn))
    rw [heq,hs.command_mass,(pid_optimal_gain hα h.delay_nonneg).2]
    field_simp
    <;> ring
  have hb := transfer_signed_balance hs.plant 1 firstOrder_transfer_dc (by norm_num)
  have hc : miace α E V halfLine=(1+δ)*minimum α := by
    apply (signal_miace_equality_iff hs.plant.error_integrable hs.plant.command_integrable
      α (1+δ) hα (by linarith [h.delay_nonneg]) hb).mpr
    refine ⟨hepos,hvpos,?_⟩
    rw [hearea,hvarea]; ring
  refine ⟨E,V,hs,hearea,hvarea,hc,?_⟩
  intro e v hp
  rw [hc]
  exact signal_miace_lower_bound hp.error_integrable hp.command_integrable α (1+δ) hα
    (by linarith [h.delay_nonneg]) (transfer_signed_balance hp 1 firstOrder_transfer_dc (by norm_num))

-- @paper-step thm:pid_two_rate_optimum/continuous_representative_uniqueness
theorem continuous_halfLine_unique {F G : ℝ → ℝ} (hF : Continuous F) (hG : Continuous G)
    (he : F=ᵐ[halfLine] G) : ∀ t : ℝ, 0≤t → F t=G t := by
  have hi : EqOn F G (Ioi (0 : ℝ)) := Measure.eqOn_open_of_ae_eq he isOpen_Ioi hF.continuousOn hG.continuousOn
  have hc : EqOn F G (Ici (0 : ℝ)) := hi.of_subset_closure hF.continuousOn hG.continuousOn
    Ioi_subset_Ici_self (by rw [closure_Ioi])
  exact fun t ht => hc ht

-- @paper-step thm:pid_two_rate_optimum/balanced_ordinary_signal_certificate
theorem balanced_ordinary_PID :
    let i : ℝ := 8/5
    let δ : ℝ := 1/4
    let ρ := pidRho i δ 5 6
    let ell := pidLead i δ 5 ρ
    ∃ E V : ℝ → ℝ, OrdinaryPIDSignals i ρ ell δ E V ∧
      absArea E halfLine=5/8 ∧ absArea V halfLine=5/8 ∧
      miace 1 E V halfLine=(5/4)*minimum 1 := by
  have h : TwoRateData ((1+1/(1 : ℝ))/(1+1/4))
      (pidRho (8/5) (1/4) 5 6) (pidLead (8/5) (1/4) 5 (pidRho (8/5) (1/4) 5 6)) 5 6 (1/4) := by
    convert balanced_twoRate_data using 1 <;> norm_num
  obtain ⟨E,V,hs,he,hv,hc,_⟩ := twoRate_ordinary_optimum (by norm_num : (0 : ℝ)<1) h
  refine ⟨E,V,?_,?_,?_,?_⟩
  · convert hs using 1 <;> norm_num
  · norm_num at he ⊢; exact he
  · norm_num at hv ⊢; exact hv
  · norm_num at hc ⊢; exact hc

end MIACE
