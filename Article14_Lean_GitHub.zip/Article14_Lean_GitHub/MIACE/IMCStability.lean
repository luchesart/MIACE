import MIACE.IMCHistory

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

structure IMCHistoryBound (N : ℕ) (F : IMCFilter) (δ ε : ℝ) (H : IMCHistory) (M : ℝ) : Prop where
  nonneg : 0≤M
  plant_initial : ∀ j≤N, |H.plantInitial j|≤M
  model_initial : ∀ j≤N, |H.modelInitial j|≤M
  filter_initial : |H.filterInitial|≤M
  plant_continuous : ContinuousOn H.plantPast (Icc (-(δ+ε)) 0)
  model_continuous : ContinuousOn H.modelPast (Icc (-δ) 0)
  filter_continuous : ContinuousOn H.filterPast (Icc (-F.delay) 0)
  plant_bound : ∀ s∈Icc (-(δ+ε)) 0, |H.plantPast s|≤M
  model_bound : ∀ s∈Icc (-δ) 0, |H.modelPast s|≤M
  filter_bound : ∀ s∈Icc (-F.delay) 0, |H.filterPast s|≤M

-- @paper-step thm:complete_robust/finite_cascade_normalization
theorem serialRatios_normalized (σ : ℕ → ℝ) (N : ℕ)
    (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) :
    ∀ τ∈serialRatios σ N, 0<τ ∧ τ≤1 := by
  intro τ hτ
  simp only [serialRatios,List.mem_reverse,List.mem_map] at hτ
  obtain ⟨j,hj,rfl⟩ := hτ
  exact hσ (j+1) (by have := List.mem_range.mp hj; omega)

-- @paper-step thm:complete_robust/normalized_storage_exponents
theorem normalized_storage_exponents (σ : ℕ → ℝ) (N : ℕ) {η : ℝ}
    (hη : η≤1/2) (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) :
    ∀ j<N+1, 0<σ j ∧ η<1/σ j := by
  intro j hj
  have hs := hσ j (by omega)
  have hh : (1 : ℝ)≤1/σ j := (le_div_iff₀ hs.1).mpr (by simpa using hs.2)
  exact ⟨hs.1,by linarith⟩

-- @paper-step thm:complete_robust/uniform_forcing_for_all_finite_histories
theorem imc_history_uniform_control (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) {δ ε η : ℝ}
    (hδ : 0≤δ) (hδε : 0≤δ+ε) (hη : 0≤η) (hηh : η≤1/2)
    (hηF : η<1/F.timeConstant) (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) :
    ∃ A : ℝ, 0≤A ∧ ∀ M H, IMCHistoryBound N F δ ε H M →
      WeightedControl η (imcFreeInput N σ δ ε H) (A*M) ∧
      WeightedControl η (imcHistoryForcing N σ F δ ε H) (A*M) := by
  obtain ⟨Cs,hCs,hstates⟩ := serialState_uniform_control σ (N+1) η
    (normalized_storage_exponents σ N hηh hσ)
  obtain ⟨K,hK⟩ := lagKernel_weightedControl F.timeConstant_pos hηF
  let P := (δ+1+Cs)*Real.exp (η*δ)
  let Q := (δ+ε+1+Cs)*Real.exp (η*(δ+ε))
  let G := |F.direct|+|F.delayed| *Real.exp (η*F.delay)+|F.residue| *K
  let B := |F.delayed| *(F.delay+1)*Real.exp (η*F.delay)+|F.residue| *F.timeConstant*K
  have hP : 0≤P := by dsimp [P]; positivity
  have hQ : 0≤Q := by dsimp [Q]; positivity
  have hG : 0≤G := by dsimp [G]; have := hK.nonneg; positivity
  have hB : 0≤B := by dsimp [B]; have := F.delay_nonneg; have := F.timeConstant_pos; have := hK.nonneg; positivity
  refine ⟨P+Q+G*(P+Q)+B,by positivity,?_⟩
  intro M H hH
  have hz : WeightedControl η (causalize (fun _ => 0)) 0 := by
    have he : causalize (fun _ : ℝ => (0 : ℝ))=(fun _ => 0) := by
      ext t; simp [causalize]
    rw [he]; exact weightedControl_zero η
  have hmodel := hstates M 0 hH.nonneg H.modelInitial (fun j hj => hH.model_initial j (by omega))
    (fun _ => 0) hz (N+1) le_rfl
  have hplant := hstates M 0 hH.nonneg H.plantInitial (fun j hj => hH.plant_initial j (by omega))
    (fun _ => 0) hz (N+1) le_rfl
  simp only [add_zero] at hmodel hplant
  have hp := plantHistoryOutput_control N σ H.modelInitial hδ hη hH.nonneg
    hH.model_continuous hH.model_bound hmodel
  have hq := plantHistoryOutput_control N σ H.plantInitial hδε hη hH.nonneg
    hH.plant_continuous hH.plant_bound hplant
  have hp' : WeightedControl η (plantFreeOutput N σ H.modelInitial δ H.modelPast) (P*M) := by
    convert hp using 1 <;> simp only [plantFreeOutput,P] <;> ring
  have hq' : WeightedControl η (plantFreeOutput N σ H.plantInitial (δ+ε) H.plantPast) (Q*M) := by
    convert hq using 1 <;> simp only [plantFreeOutput,Q] <;> ring
  have hfree : WeightedControl η (imcFreeInput N σ δ ε H) ((P+Q)*M) := by
    have hh := weightedControl_add hp' (weightedControl_smul hq' (-1))
    convert hh using 1
    · funext t; unfold imcFreeInput; ring
    · norm_num; ring
  have hfilt := filterFreeOutput_control F H hη hH.nonneg hK hH.filter_continuous
    hH.filter_bound hH.filter_initial
  have hforce : WeightedControl η (imcHistoryForcing N σ F δ ε H) ((G*(P+Q)+B)*M) := by
    have hh := weightedControl_add (filterAction_weightedControl F hK hfree) hfilt
    convert hh using 1 <;> first | rfl | (dsimp [G,B]; ring)
  exact ⟨weightedControl_mono hfree (mul_le_mul_of_nonneg_right (by nlinarith) hH.nonneg),
    weightedControl_mono hforce (mul_le_mul_of_nonneg_right (by linarith) hH.nonneg)⟩

-- The feedback equation uses the actual finite histories and all physical
-- storage states. Competitors need only be ordinary, locally integrable signals.
-- @paper-step thm:complete_robust/full_history_ordinary_feedback_stability
theorem imc_history_feedback_stability (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) {δ ε : ℝ}
    (hδ : 0≤δ) (hδε : 0≤δ+ε) (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1)
    (hq : imcDelayGain F ε<1) :
    ∃ η C : ℝ, 0<η ∧ η≤1/2 ∧ η<1/F.timeConstant ∧ 0≤C ∧
      ∀ M H, IMCHistoryBound N F δ ε H M →
        ∃ u : ℝ → ℝ, Integrable u ∧ Causal u ∧
          u=ᵐ[volume] imcFeedback N σ F δ ε H u ∧ WeightedControl η u (C*M) ∧
          ∀ v : ℝ → ℝ, LocallyIntegrable v volume → Causal v →
            v=ᵐ[volume] imcFeedback N σ F δ ε H v → v=ᵐ[volume] u := by
  obtain ⟨η,K,hcert⟩ := imc_loop_certificate F (serialRatios σ N)
    (serialRatios_normalized σ N hσ) hδ hδε hq
  obtain ⟨A,hA,hforcing⟩ := imc_history_uniform_control N σ F hδ hδε
    hcert.exponent_pos.le hcert.exponent_half hcert.exponent_filter hσ
  let R := (1+K)/(1-absArea (expWeight η (imcLoopKernel F (serialRatios σ N) δ ε)) volume)
  have hR : 0≤R := div_nonneg (by linarith [hcert.control.nonneg]) (by linarith [hcert.weighted_small])
  refine ⟨η,R*A,hcert.exponent_pos,hcert.exponent_half,hcert.exponent_filter,mul_nonneg hR hA,?_⟩
  intro M H hH
  have hc := imcFreeInput_causal N σ hδ hδε H
  have hf := hforcing M H hH
  have hfi := weightedControl_unweighted hf.1 hc hcert.exponent_pos.le
  obtain ⟨u,hu,huc,he,hw,hunique⟩ := imc_ordinary_loop hcert hf.2
    (imcHistoryForcing_causal N σ F hδ hδε H)
  have hid := imcFeedback_loop_identity N σ F hδ hδε H (fun j hj => (hσ j hj).1)
    hfirst hfi hu.locallyIntegrable huc
  refine ⟨u,hu,huc,he.trans hid.symm,?_,?_⟩
  · convert hw using 1; dsimp [R]; ring
  · intro v hv hvc hvfb
    apply hunique v hv hvc
    exact hvfb.trans (imcFeedback_loop_identity N σ F hδ hδε H (fun j hj => (hσ j hj).1)
      hfirst hfi hv hvc)

end MIACE
