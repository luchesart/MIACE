import MIACE.CascadeCertificates

/-! Stage 19. Continuity is proved for the actual remainder integrals,
including the moving endpoint at zero delay. No continuity certificate is
assumed as an additional hypothesis of Corollary 18. -/
namespace MIACE
open MeasureTheory Filter Set Polynomial
open scoped Topology

-- @paper-step cor:n_small_delay/continuous_integral_with_moving_endpoint
theorem continuous_moving_integral {F : ℝ → ℝ → ℝ}
    (hF : Continuous (Function.uncurry F)) :
    Continuous (fun d => ∫ t in 0..d, F d t) := by
  have hc : Continuous (fun p : ℝ × ℝ => F p.1 (p.1*p.2)) :=
    hF.comp (continuous_fst.prodMk (continuous_fst.mul continuous_snd))
  have hi := continuous_parametric_integral_of_continuous (μ := volume)
    (f := fun d t => F d (d*t)) hc (s := Icc (0 : ℝ) 1) isCompact_Icc
  have he (d : ℝ) : (∫ t in 0..d, F d t)=d*(∫ t in Icc (0 : ℝ) 1, F d (d*t)) := by
    rw [integral_Icc_eq_integral_Ioc,← intervalIntegral.integral_of_le (by norm_num : (0 : ℝ)≤1)]
    simpa using (intervalIntegral.smul_integral_comp_mul_left (F d) d (a := 0) (b := 1)).symm
  simp_rw [he]
  exact continuous_id.mul hi

-- @paper-step cor:n_small_delay/remainder_moments_continuous_in_delay
theorem remainderMoment_continuous (r : ℕ → ℝ) (n k : ℕ) :
    Continuous (fun δ => compactMoment (remainderJ r n δ) δ k) := by
  apply continuous_moving_integral
  exact (continuous_snd.pow k).mul
    ((reverseImpulse_continuous r n).comp (continuous_fst.sub continuous_snd))

-- @paper-step cor:n_small_delay/remainder_exponential_moments_continuous_in_delay
theorem remainderExpMoment_continuous (r : ℕ → ℝ) (n : ℕ) (l : ℝ) :
    Continuous (fun δ => compactExpMoment (remainderJ r n δ) δ l) := by
  apply continuous_moving_integral
  exact (Real.continuous_exp.comp (continuous_snd.const_mul l)).mul
    ((reverseImpulse_continuous r n).comp (continuous_fst.sub continuous_snd))

-- @paper-step cor:n_small_delay/continuous_interpolant_coefficients
theorem remainderI_eval_continuous (r : ℕ → ℝ) (n : ℕ) (p : ℝ) :
    Continuous (fun δ => (remainderI r δ n).eval p) := by
  induction n with
  | zero => simp only [remainderI,eval_C]; fun_prop
  | succ n ih =>
    simp only [remainderI,eval_add,eval_mul,eval_C]
    exact ih.add ((((reverseImpulse_continuous r (n+1)).const_mul _).div_const _).mul_const _)

-- @paper-step cor:n_small_delay/zero_delay_interpolant
theorem remainderI_at_zero (r : ℕ → ℝ) (n : ℕ) : remainderI r 0 n=1 := by
  induction n with
  | zero => simp [remainderI]
  | succ n ih => simp [remainderI,ih,(reverseImpulse_zero r n).2]

-- @paper-step cor:n_small_delay/normalized_factor_at_plant_pole
theorem remainderB_minus_one (r : ℕ → ℝ) (n : ℕ) (hr : ∀ j≤n, 1≤r j) :
    0≤(remainderB r n).eval (-1) ∧ (remainderB r n).eval (-1)<1 := by
  have hf (j : ℕ) (hj : j≤n) : 0≤1-1/r j ∧ 1-1/r j<1 := by
    have hp : 0<r j := lt_of_lt_of_le zero_lt_one (hr j hj)
    have hi : 1/r j≤1 := (div_le_one hp).mpr (hr j hj)
    exact ⟨by linarith,by linarith [one_div_pos.mpr hp]⟩
  induction n with
  | zero => simpa [remainderB] using hf 0 le_rfl
  | succ n ih =>
    obtain ⟨h0,h1⟩ := ih (fun j hj => hr j (by omega))
      (fun j hj => hf j (by omega))
    obtain ⟨hF0,hF1⟩ := hf (n+1) le_rfl
    have he : (remainderB r (n+1)).eval (-1)=
        (remainderB r n).eval (-1)*(1-1/r (n+1)) := by simp only [remainderB,eval_mul,eval_add,eval_C,eval_X,eval_one]; ring
    rw [he]
    exact ⟨mul_nonneg h0 hF0,(mul_le_mul_of_nonneg_right h1.le hF0).trans_lt (by simpa using hF1)⟩

end MIACE
