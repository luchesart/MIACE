import MIACE.ScalarDelayPositive

/-! Ordinary step signals, with the integral delay equation and the PI
command law. The nonoscillatory sufficient direction includes its endpoint. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

structure ScalarDelayResponse (x δ : ℝ) (E : ℝ → ℝ) : Prop where
  continuous : Continuous E
  ac : ∀ a b, AbsolutelyContinuousOnInterval E a b
  initial : E 0=1
  integral_eq : ∀ t, 0≤t → E t=1-x*(∫ s in 0..t, shift δ (causalize E) s)

-- @paper-step lem:delayed_cancellation/nonnegative_fundamental_is_decreasing
theorem scalarDelay_antitone {x δ : ℝ} (hx : 0<x) {E : ℝ → ℝ}
    (h : ScalarDelayResponse x δ E) (hi : Integrable E halfLine)
    (hn : ∀ t, 0≤t → 0≤E t) : AntitoneOn E (Ici 0) := by
  have hf := shift_integrable δ (causalize_integrable hi)
  have hp (t : ℝ) : 0≤shift δ (causalize E) t := by
    by_cases ht : 0≤t-δ
    · simpa [shift,causalize,ht] using hn (t-δ) ht
    · simp [shift,causalize,ht]
  intro a ha b hb hab
  have hI := intervalIntegral.integral_mono_interval le_rfl ha hab
    (ae_of_all _ hp) (hf.intervalIntegrable (a := 0) (b := b))
  rw [h.integral_eq a ha,h.integral_eq b hb]
  nlinarith

-- @paper-step lem:delayed_cancellation/actual_step_command_identity
theorem scalarDelay_command_identity {x δ : ℝ} (hδ : 0≤δ) {E : ℝ → ℝ}
    (h : ScalarDelayResponse x δ E) {t : ℝ} (ht : 0≤t) :
    x*E t-E (t+δ)=x*E t+x*(∫ s in 0..t, E s)-1 := by
  rw [h.integral_eq (t+δ) (add_nonneg ht hδ),scalarDelay_shift_primitive E hδ ht]
  ring

-- @paper-step lem:delayed_cancellation/positive_command_from_gain_and_delay
theorem scalarDelay_command_nonneg {x δ : ℝ} (hx : 1≤x) (hδ : 0≤δ)
    {E : ℝ → ℝ} (hn : ∀ t, 0≤t → 0≤E t) (hm : AntitoneOn E (Ici 0))
    {t : ℝ} (ht : 0≤t) : 0≤x*E t-E (t+δ) := by
  have hh := hm ht (add_nonneg ht hδ) (by linarith : t≤t+δ)
  nlinarith [hn t ht]

-- @paper-step lem:delayed_cancellation/ordinary_dde_derivative_from_integral_equation
theorem scalarDelay_response_derivative {x δ : ℝ} {E : ℝ → ℝ}
    (h : ScalarDelayResponse x δ E) (hi : Integrable E halfLine) :
    ∀ᵐ t, 0<t → HasDerivAt E (-x*shift δ (causalize E) t) t := by
  have hf := shift_integrable δ (causalize_integrable hi)
  filter_upwards [LocallyIntegrable.ae_hasDerivAt_integral hf.locallyIntegrable] with t ht ht0
  have hd := ((ht 0).const_mul x).const_sub 1
  have heq : E=ᶠ[𝓝 t] (fun u => 1-x*(∫ s in 0..u, shift δ (causalize E) s)) := by
    filter_upwards [Ioi_mem_nhds ht0] with s hs
    exact h.integral_eq s (le_of_lt hs)
  convert hd.congr_of_eventuallyEq heq using 1 <;> ring

-- @paper-step lem:delayed_cancellation/assembled_nonoscillatory_step_response
theorem scalarDelay_monotone_sufficient {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    (hb : x*δ≤Real.exp (-1)) :
    ∃ E : ℝ → ℝ, ScalarDelayResponse x δ E ∧
      Integrable E halfLine ∧
      (∃ η C : ℝ, 0<η ∧ 0≤C ∧
        Integrable (expWeight η (causalize E)) ∧
        ∀ t, 0≤t → |E t|≤C*Real.exp (-η*t)) ∧
      (∀ t, 0≤t → 0<E t ∧ E t≤1) ∧
      MonotoneOn (fun t => 1-E t) (Ici 0) ∧
      1-E 0=0 ∧ Tendsto (fun t => 1-E t) atTop (𝓝 1) ∧
      (∫ t, E t ∂halfLine)=1/x ∧
      (∀ t, 0≤t → x*E t-E (t+δ)=x*E t+x*(∫ s in 0..t, E s)-1) ∧
      (1≤x → ∀ t, 0≤t → 0≤x*E t-E (t+δ)) := by
  obtain ⟨l,hl,he⟩ := (scalarDelay_tilt_iff hx hδ).mpr hb
  obtain ⟨E,hc,hac,h0,hn,hi,hw,hT⟩ := scalarDelay_positive_resolvent hx hδ hl he
  have hresp : ScalarDelayResponse x δ E :=
    ⟨hc,hac,h0,scalarDelay_integral_equation hδ hc hi (fun p hp => hT p hp.le)⟩
  have hm := scalarDelay_antitone hx hresp hi (fun t ht => (hn t ht).le)
  have hlim : Tendsto E atTop (𝓝 0) := by
    obtain ⟨η,C,hη,_,_,hbound⟩ := hw
    exact tendsto_zero_of_exp_bound hη hbound
  refine ⟨E,hresp,hi,hw,?_,?_,by rw [h0]; ring,?_,?_,?_,?_⟩
  · intro t ht
    exact ⟨hn t ht,by simpa only [h0] using hm (show (0 : ℝ)∈Ici (0 : ℝ) from by simp) ht ht⟩
  · intro a ha b hb hab
    linarith [hm ha hb hab]
  · simpa using tendsto_const_nhds.sub hlim
  · have hmass := hT 0 le_rfl
    simp only [mul_zero,zero_mul,neg_zero,Real.exp_zero,mul_one,zero_add,laplace,one_mul] at hmass
    exact (eq_div_iff (ne_of_gt hx)).mpr (by nlinarith [hmass])
  · exact fun t ht => scalarDelay_command_identity hδ hresp ht
  · exact fun hx1 t ht => scalarDelay_command_nonneg hx1 hδ (fun s hs => (hn s hs).le) hm ht

end MIACE
