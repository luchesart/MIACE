import MIACE.TwoRate

/-! Точна алгебра на параметрите: изричните формули на статията,
    двете характеристични равенства и физически положителните PID коефициенти. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def pidRho (i δ l m : ℝ) : ℝ :=
  (Real.exp (-l*δ)-Real.exp (-m*δ)+i*(1/m-1/l))/
    (l*Real.exp (-l*δ)-m*Real.exp (-m*δ))
noncomputable def pidLead (i δ l ρ : ℝ) : ℝ :=
  1/l+(ρ*l-1)*Real.exp (-l*δ)/i

-- @paper-step thm:pid_two_rate_optimum/first_exact_rate_equation
theorem pidLead_first_root {i l : ℝ} (hi : i ≠ 0) (hl : l ≠ 0) (δ ρ : ℝ) :
    i*(1-pidLead i δ l ρ*l)=l*(1-ρ*l)*Real.exp (-l*δ) := by
  unfold pidLead
  field_simp
  <;> ring

-- @paper-step thm:pid_two_rate_optimum/second_exact_rate_equation
theorem pidRho_second_root {i l m δ : ℝ} (hi : i ≠ 0) (hl : l ≠ 0) (hm : m ≠ 0)
    (hd : l*Real.exp (-l*δ)-m*Real.exp (-m*δ) ≠ 0) :
    i*(1-pidLead i δ l (pidRho i δ l m)*m)=
      m*(1-pidRho i δ l m*m)*Real.exp (-m*δ) := by
  unfold pidLead pidRho
  generalize Real.exp (-l*δ)=u at hd ⊢
  generalize Real.exp (-m*δ)=v at hd ⊢
  field_simp [hi,hl,hm,hd]
  ring_nf
  field_simp [hd]
  <;> ring

-- @paper-step thm:pid_two_rate_optimum/characteristic_roots
theorem pid_root_equivalence (i ρ ell z δ : ℝ) :
    i*(1-ell*z)=z*(1-ρ*z)*Real.exp (-z*δ) ↔
      i*(1-ell*z)*Real.exp (z*δ)=z*(1-ρ*z) := by
  have he : Real.exp (-z*δ)*Real.exp (z*δ)=1 := by
    rw [← Real.exp_add,show -z*δ+z*δ=0 by ring,Real.exp_zero]
  constructor
  · intro h
    rw [h,mul_assoc,he,mul_one]
  · intro h
    have hh := congrArg (fun x : ℝ => x*Real.exp (-z*δ)) h
    rw [mul_assoc,mul_comm (Real.exp (z*δ)),he,mul_one] at hh
    exact hh

-- @paper-step thm:pid_two_rate_optimum/positive_pid_coefficients
theorem pid_positive_parameters {i ρ ell : ℝ} (hi : 0 < i) (hρ : 0 < ρ)
    (hρ1 : ρ < 1) (hell : ρ < ell) :
    0 < i*(1+ell-ρ) ∧ 0 < i*(ell-ρ)*(1-ρ) ∧
      i < i*(1+ell-ρ) := by
  constructor
  · exact mul_pos hi (by linarith)
  constructor
  · exact mul_pos (mul_pos hi (sub_pos.mpr hell)) (sub_pos.mpr hρ1)
  · nlinarith

-- @paper-step thm:pid_two_rate_optimum/controller_polynomial_factor
theorem pid_polynomial_factor (i ρ ell p : ℝ) :
    (i*(1+ell-ρ)*ρ+i*(ell-ρ)*(1-ρ))*p^2+
      (i*(1+ell-ρ)+i*ρ)*p+i = i*(p+1)*(1+ell*p) := by ring

-- @paper-step thm:pid_two_rate_optimum/controller_law_factor
theorem pid_controller_factor (i ρ ell p : ℝ) (hp : p ≠ 0) (hf : 1+ρ*p ≠ 0) :
    i*(1+ell-ρ)+i/p+(i*(ell-ρ)*(1-ρ))*p/(1+ρ*p)=
      i*(p+1)*(1+ell*p)/(p*(1+ρ*p)) := by
  field_simp
  <;> ring

-- @paper-step thm:pid_two_rate_optimum/full_characteristic_factor
theorem pid_full_characteristic (i ρ ell δ p : ℝ) :
    p*(p+1)*(1+ρ*p)+
      ((i*(1+ell-ρ)*ρ+i*(ell-ρ)*(1-ρ))*p^2+
        (i*(1+ell-ρ)+i*ρ)*p+i)*Real.exp (-δ*p) =
      (p+1)*(p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p)) := by
  rw [pid_polynomial_factor]
  ring

-- @paper-step thm:pid_two_rate_optimum/partial_fraction_identity
theorem twoRate_partial_fraction {ρ l m p : ℝ} (hρ : ρ ≠ 0) (hlm : l ≠ m)
    (hl : p+l ≠ 0) (hm : p+m ≠ 0) :
    twoRateA ρ l m/(p+l)+(1-twoRateA ρ l m)/(p+m)=
      (1+ρ*p)/(ρ*(p+l)*(p+m)) := by
  unfold twoRateA
  have hml : m-l ≠ 0 := sub_ne_zero.mpr hlm.symm
  field_simp
  <;> ring

-- @paper-step thm:pid_two_rate_optimum/first_shifted_residue
theorem twoRate_first_residue {i ρ ell l m δ : ℝ} (hρ : ρ ≠ 0) (hlm : l ≠ m)
    (hroot : i*(1-ell*l)=l*(1-ρ*l)*Real.exp (-l*δ)) :
    l*twoRateA ρ l m*Real.exp (-l*δ)=i*(1-ell*l)/(ρ*(m-l)) := by
  rw [hroot]
  unfold twoRateA
  field_simp
  <;> ring

-- @paper-step thm:pid_two_rate_optimum/second_shifted_residue
theorem twoRate_second_residue {i ρ ell l m δ : ℝ} (hρ : ρ ≠ 0) (hlm : l ≠ m)
    (hroot : i*(1-ell*m)=m*(1-ρ*m)*Real.exp (-m*δ)) :
    m*(1-twoRateA ρ l m)*Real.exp (-m*δ)= -i*(1-ell*m)/(ρ*(m-l)) := by
  rw [show -i*(1-ell*m)= -(i*(1-ell*m)) by ring,hroot]
  unfold twoRateA
  field_simp
  <;> ring

-- @paper-step thm:pid_two_rate_optimum/dc_residue_balance
theorem twoRate_gain_mass {i ρ ell l m δ : ℝ} (hρ : ρ ≠ 0) (hl : l ≠ 0)
    (hm : m ≠ 0) (hlm : l ≠ m)
    (hrootl : i*(1-ell*l)=l*(1-ρ*l)*Real.exp (-l*δ))
    (hrootm : i*(1-ell*m)=m*(1-ρ*m)*Real.exp (-m*δ)) :
    twoRateG (twoRateA ρ l m) l m δ=
      i*(twoRateA ρ l m/l+(1-twoRateA ρ l m)/m) := by
  have h₁ := twoRate_first_residue hρ hlm hrootl
  have h₂ := twoRate_second_residue hρ hlm hrootm
  have he₁ : twoRateA ρ l m*Real.exp (-l*δ)=i*(1-ell*l)/(ρ*(m-l)*l) := by
    apply (mul_left_cancel₀ hl)
    calc
      l*(twoRateA ρ l m*Real.exp (-l*δ)) = i*(1-ell*l)/(ρ*(m-l)) := by nlinarith [h₁]
      _ = l*(i*(1-ell*l)/(ρ*(m-l)*l)) := by field_simp
  have he₂ : (1-twoRateA ρ l m)*Real.exp (-m*δ)= -i*(1-ell*m)/(ρ*(m-l)*m) := by
    apply (mul_left_cancel₀ hm)
    calc
      m*((1-twoRateA ρ l m)*Real.exp (-m*δ)) = -i*(1-ell*m)/(ρ*(m-l)) := by nlinarith [h₂]
      _ = m*(-i*(1-ell*m)/(ρ*(m-l)*m)) := by field_simp
  unfold twoRateG
  rw [he₁,he₂]
  unfold twoRateA
  have hml : m-l ≠ 0 := sub_ne_zero.mpr hlm.symm
  field_simp
  <;> ring

end MIACE
