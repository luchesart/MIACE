import MIACE.Tail

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def truncatedWeight (v : ℝ → ℝ) (H : ℝ) : ℝ → ℝ :=
  (Ioc 0 H).indicator (fun t => Real.exp t*v t)

-- @paper-step thm:command_cone/truncated_moment_integrable
theorem truncatedWeight_integrable {v : ℝ → ℝ} (hv : Integrable v halfLine)
    (H : ℝ) (hH : 0 ≤ H) : Integrable (truncatedWeight v H) halfLine := by
  have hi : IntervalIntegrable v volume 0 H :=
    (intervalIntegrable_iff_integrableOn_Ioc_of_le hH).mpr
      (IntegrableOn.mono_set hv (fun _ hs => hs.1))
  have hw : IntervalIntegrable (fun t => Real.exp t*v t) volume 0 H :=
    hi.continuousOn_mul Real.continuous_exp.continuousOn
  have hg := (intervalIntegrable_iff_integrableOn_Ioc_of_le hH).mp hw
  exact (hg.integrable_indicator measurableSet_Ioc).mono_measure Measure.restrict_le_self

-- @paper-step thm:command_cone/truncated_moment_integral
theorem truncatedWeight_integral (v : ℝ → ℝ) (H : ℝ) (hH : 0 ≤ H) :
    (∫ t, truncatedWeight v H t ∂halfLine) = ∫ t in 0..H, Real.exp t*v t := by
  unfold truncatedWeight halfLine
  rw [integral_indicator measurableSet_Ioc,Measure.restrict_restrict measurableSet_Ioc]
  have hs : Ioc 0 H ∩ Ioi (0 : ℝ) = Ioc 0 H := inter_eq_left.mpr (fun _ ht => ht.1)
  rw [hs,intervalIntegral.integral_of_le hH]

-- @paper-step thm:command_cone/first_state_moment_finiteness
theorem first_state_moment_finite {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (hv : ∀ᵐ t ∂halfLine, 0 ≤ v t) (he : ∀ t : ℝ, 0 ≤ t → 0 ≤ e t) :
    Integrable (fun t => Real.exp t*v t) halfLine ∧ moment v ≤ 1 := by
  refine fatou_moment_bound (G := fun n => truncatedWeight v (n : ℝ))
    (fun n => truncatedWeight_integrable h.command_integrable n (Nat.cast_nonneg n)) ?_ ?_ hv ?_
  · intro n
    filter_upwards [hv] with t ht
    by_cases hn : t ∈ Ioc 0 (n : ℝ)
    · simp only [truncatedWeight,indicator_of_mem hn]
      exact mul_nonneg (Real.exp_nonneg _) ht
    · simp [truncatedWeight,hn]
  · intro n
    rw [truncatedWeight_integral v n (Nat.cast_nonneg n)]
    have hb := response_weighted_balance h n (Nat.cast_nonneg n)
    have hp := mul_nonneg (Real.exp_nonneg (n : ℝ)) (he n (Nat.cast_nonneg n))
    linarith
  · filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    obtain ⟨N,hN⟩ := exists_nat_ge t
    have heq : (fun n : ℕ => truncatedWeight v (n : ℝ) t) =ᶠ[atTop]
        (fun _ => Real.exp t*v t) := by
      filter_upwards [eventually_ge_atTop N] with n hn
      have hcast : (N : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
      have hmem : t ∈ Ioc 0 (n : ℝ) := ⟨ht,hN.trans hcast⟩
      simp [truncatedWeight,hmem]
    exact tendsto_const_nhds.congr' heq.symm

-- The N=1 signal characterization now derives moment integrability itself.
-- @paper-step thm:command_cone/first_order_complete_signal_cone
theorem first_order_complete_cone {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (hv : ∀ᵐ t ∂halfLine, 0 ≤ v t) :
    ((∀ t : ℝ, 0 ≤ t → 1-e t ≤ 1) ↔
      Integrable (fun t => Real.exp t*v t) halfLine ∧ moment v ≤ 1) ∧
    (MonotoneOn (fun t => 1-e t) (Ici 0) ↔
      Integrable (fun t => Real.exp t*v t) halfLine ∧ moment v ≤ 1) := by
  have hsign : (∀ t : ℝ, 0 ≤ t → 1-e t ≤ 1) →
      Integrable (fun t => Real.exp t*v t) halfLine ∧ moment v ≤ 1 := by
    intro hy
    apply first_state_moment_finite h hv
    intro t ht
    have := hy t ht
    linarith
  constructor
  · constructor
    · exact hsign
    · rintro ⟨hJ,hM⟩
      exact (first_order_command_cone h hv hJ).1.mpr hM
  · constructor
    · intro hm
      apply hsign
      intro t ht
      have hl : Tendsto (fun b => 1-e b) atTop (𝓝 1) := by
        simpa using tendsto_const_nhds.sub h.finalValue
      apply ge_of_tendsto hl
      filter_upwards [eventually_ge_atTop t] with b hb
      exact hm ht (ht.trans hb) hb
    · rintro ⟨hJ,hM⟩
      exact (first_order_command_cone h hv hJ).2.mpr hM

end MIACE
