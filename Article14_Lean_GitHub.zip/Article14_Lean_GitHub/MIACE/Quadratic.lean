import MIACE.Algebra

/-! Rational PI energy formulas. GramianProof.lean proves the original H²
derivation and identifies these expressions with the actual PI signal integrals. -/
namespace MIACE
noncomputable def tracking (x r : ℝ) : ℝ := (x + r) / (2 * x * (1 + x))
noncomputable def effort (x r : ℝ) : ℝ :=
  ((x - r)^2 + x * r * (x - 1)^2) / (2 * r * x * (1 + x))
noncomputable def quadratic (q x r : ℝ) : ℝ := q * tracking x r + effort x r

-- @paper-step prop:energies/gramian_tracking_substitution
 theorem energy_tracking_substitution (x r : ℝ) (hx : 0 < x) (hr : 0 < r) :
    (r * r^2 + x * r^2) / (2 * r * (r * (1 + x)) * x) = tracking x r := by
  unfold tracking
  field_simp
  <;> ring

-- @paper-step prop:energies/gramian_effort_substitution
 theorem energy_effort_substitution (x r : ℝ) (hx : 0 < x) (hr : 0 < r) :
    (r * (x-r)^2 + x * (r*(x-1))^2) / (2*r*(r*(1+x))*x) = effort x r := by
  unfold effort
  field_simp
  <;> ring

-- @paper-step thm:global/sos
 theorem quadratic_gap (q s x r : ℝ) (hx : 0 < x) (hr : 0 < r)
    (hs : s^2 = 1 + q) :
    quadratic q x r - (s-1) =
      (s*r-x)^2 / (2*r*x*(1+x)) + (x-s)^2 / (2*(1+x)) := by
  unfold quadratic tracking effort
  have hx0 : x ≠ 0 := ne_of_gt hx
  have hr0 : r ≠ 0 := ne_of_gt hr
  have hx1 : 1 + x ≠ 0 := by linarith
  have hq : q = s^2 - 1 := by linarith
  rw [hq]
  field_simp
  <;> ring

-- @paper-step thm:global/positivity
 theorem quadratic_lower_bound (q s x r : ℝ) (hx : 0 < x) (hr : 0 < r)
    (hs : s^2 = 1 + q) : s-1 ≤ quadratic q x r := by
  have h := quadratic_gap q s x r hx hr hs
  have h1 : 0 ≤ (s*r-x)^2 / (2*r*x*(1+x)) := by positivity
  have h2 : 0 ≤ (x-s)^2 / (2*(1+x)) := by positivity
  linarith

-- @paper-step thm:global/unique_minimizer
 theorem quadratic_equality_iff (q s x r : ℝ) (hx : 0 < x) (hr : 0 < r)
    (hspos : 0 < s) (hs : s^2 = 1+q) :
    quadratic q x r = s-1 ↔ x=s ∧ r=1 := by
  have h := quadratic_gap q s x r hx hr hs
  have hd1 : 0 < 2*r*x*(1+x) := by positivity
  have hd2 : 0 < 2*(1+x) := by positivity
  constructor
  · intro he
    have h1 : 0 ≤ (s*r-x)^2 / (2*r*x*(1+x)) := by positivity
    have h2 : 0 ≤ (x-s)^2 / (2*(1+x)) := by positivity
    have hz2 : (x-s)^2 / (2*(1+x)) = 0 := by linarith
    have hz1 : (s*r-x)^2 / (2*r*x*(1+x)) = 0 := by linarith
    have hx' : x-s = 0 := sq_eq_zero_iff.mp ((div_eq_zero_iff.mp hz2).resolve_right (ne_of_gt hd2))
    have hr' : s*r-x = 0 := sq_eq_zero_iff.mp ((div_eq_zero_iff.mp hz1).resolve_right (ne_of_gt hd1))
    constructor <;> nlinarith
  · rintro ⟨rfl,rfl⟩
    simp at h
    linarith

-- @paper-step thm:global/square_root_specialization
 theorem quadratic_sqrt_optimum (q x r : ℝ) (hq : 0 < q) (hx : 0 < x) (hr : 0 < r) :
    quadratic q x r = Real.sqrt (1+q)-1 ↔ x=Real.sqrt (1+q) ∧ r=1 := by
  apply quadratic_equality_iff q _ x r hx hr
  · exact Real.sqrt_pos.2 (by linarith)
  · exact Real.sq_sqrt (by linarith)

-- @paper-step thm:l2_pareto/residual
 theorem pareto_residual (x r : ℝ) (hx : 0 < x) (hr : 0 < r) :
    4 * tracking x r * (effort x r + 1 - tracking x r) - 1 =
      x * (r-1)^2 / (r*(1+x)^2) := by
  unfold tracking effort
  have hx0 : x ≠ 0 := ne_of_gt hx
  have hr0 : r ≠ 0 := ne_of_gt hr
  have hx1 : 1+x ≠ 0 := by linarith
  field_simp
  <;> ring

-- @paper-step thm:l2_pareto/lower_boundary
 theorem pareto_lower_boundary (x r : ℝ) (hx : 0 < x) (hr : 0 < r) :
    tracking x r + 1 / (4 * tracking x r) - 1 ≤ effort x r := by
  have he : 0 < tracking x r := by unfold tracking; positivity
  have hres := pareto_residual x r hx hr
  have hn : 0 ≤ x * (r-1)^2 / (r*(1+x)^2) := by positivity
  have hprod : 1 ≤ 4 * tracking x r * (effort x r + 1 - tracking x r) := by linarith
  have hdiv : 1 / (4 * tracking x r) ≤ effort x r + 1 - tracking x r :=
    (div_le_iff₀ (by positivity : 0 < 4 * tracking x r)).2 (by nlinarith)
  linarith

-- @paper-step thm:l2_pareto/cancellation_curve
 theorem cancellation_energies (x : ℝ) (hx : 0 < x) :
    tracking x 1 = 1 / (2*x) ∧ effort x 1 = (x-1)^2 / (2*x) := by
  unfold tracking effort
  have hx0 : x ≠ 0 := ne_of_gt hx
  have hx1 : 1+x ≠ 0 := by linarith
  constructor <;> field_simp <;> ring

-- @paper-step thm:l2_pareto/matched_weights
 theorem matched_weights (α : ℝ) (hα : 0 < α) :
    (1 + 1/α)^2 = 1 + (2/α + 1/α^2) := by ring

end MIACE
