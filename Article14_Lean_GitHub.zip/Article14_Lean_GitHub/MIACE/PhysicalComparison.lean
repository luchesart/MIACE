import MIACE.PhysicalPIDStep

/-! Етап 10: конкурентите също се свързват с времевия обект.
    Всеки FirstOrderResponse с произволна интегруема команда дава
    TransferResponse след транспорта; не се изисква непрекъснатост на командата. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:pid_two_rate_optimum/competitor_actual_plant_solution
theorem firstOrderResponse_error_formula {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    {t : ℝ} (ht : 0≤t) : e t=firstOrderError v t := by
  have he := response_first_state_formula h t ht
  simp only [firstOrderError,lag,div_one]
  linarith

-- @paper-step thm:pid_two_rate_optimum/competitor_ODE_implies_transform
theorem firstOrderResponse_laplace {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    {p : ℝ} (hp : 0≤p) : laplace e p=(1-laplace v p)/(1+p) := by
  have he : e=ᵐ[halfLine] firstOrderError v := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact firstOrderResponse_error_formula h (show 0<t from ht).le
  rw [laplace_congr_halfLine he,firstOrderError_laplace h.command_integrable hp]

-- @paper-step thm:pid_two_rate_optimum/competitor_delayed_ODE_implies_transfer
theorem delayed_response_transfer {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    {δ : ℝ} (hδ : 0≤δ) :
    TransferResponse (delayedError δ e) v (fun p => 1/(1+p)) δ := by
  have he := delayedError_integrable δ hδ h.error_integrable
  refine ⟨he,h.command_integrable,?_⟩
  intro p hp
  have hc : Integrable (fun t : ℝ => Real.exp (-p*t)) halfLine :=
    integrableOn_exp_mul_Ioi (by linarith : -p<0) 0
  have hy : laplace (fun t => 1-delayedError δ e t) p=1/p-laplace (delayedError δ e) p := by
    unfold laplace
    simp_rw [mul_sub,mul_one]
    rw [integral_sub hc (laplace_integrable he hp.le)]
    have hs := laplace_step p hp
    simpa only [laplace,mul_one] using congrArg (fun x => x-laplace (delayedError δ e) p) hs
  rw [hy,(laplace_step_add h.command_integrable hp).2,
    delayedError_laplace h.error_integrable hδ hp,firstOrderResponse_laplace h hp.le]
  field_simp [ne_of_gt hp,ne_of_gt (by linarith : 0<1+p)]
  <;> ring

-- @paper-step thm:pid_two_rate_optimum/physical_command_global_optimum
theorem twoRate_physical_global_optimum {α ρ ell l m δ : ℝ} (hα : 0<α)
    (h : TwoRateData ((1+1/α)/(1+δ)) ρ ell l m δ) :
    ∃ E V : ℝ → ℝ,
      OrdinaryPIDSignals ((1+1/α)/(1+δ)) ρ ell δ E V ∧
      PhysicalPIDStep ((1+1/α)/(1+δ)) ρ ell δ E V ∧
      absArea E halfLine=α*(1+δ)/(1+α) ∧ absArea V halfLine=(1+δ)/(1+α) ∧
      miace α E V halfLine=(1+δ)*minimum α ∧
      ∀ e v : ℝ → ℝ, FirstOrderResponse e v →
        miace α E V halfLine≤miace α (delayedError δ e) v halfLine := by
  obtain ⟨E,V,hs,hphys,he,hv,hcost,hglobal⟩ := twoRate_time_domain_optimum hα h
  refine ⟨E,V,hs,hphys,he,hv,hcost,?_⟩
  intro e v hr
  exact hglobal _ v (delayed_response_transfer hr h.delay_nonneg)

end MIACE
