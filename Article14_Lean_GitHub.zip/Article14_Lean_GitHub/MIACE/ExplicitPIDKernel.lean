import MIACE.ExplicitPIDParameters
import MIACE.CompactRenewal

/-! Stage 19. The actual noncompact positive kernel of the explicit PID
family. Its mass and exponential weight are Lebesgue integral statements. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

noncomputable def explicitJ (ρ ell l : ℝ) (t : ℝ) : ℝ :=
  explicitA ρ ell l*expKernel l t+explicitB ρ ell l*expKernel (1/ρ) t
noncomputable def explicitK (i ρ ell l δ : ℝ) (t : ℝ) : ℝ :=
  l*expKernel l t-i*shift δ (explicitJ ρ ell l) t

-- @paper-step thm:pid_explicit_family/exponential_forcing_weighted_control
theorem expKernel_control {l η : ℝ} (hl : η<l) :
    ∃ C : ℝ, WeightedControl η (expKernel l) C := by
  have he : twoRateG 1 l l=(fun t => Real.exp (-l*t)) := by
    funext t; simp [twoRateG]
  simpa only [he,expKernel] using twoRateG_weightedControl 1 hl hl

-- @paper-step thm:pid_explicit_family/partial_fraction_kernel_causality
theorem explicitJ_causal (ρ ell l : ℝ) : Causal (explicitJ ρ ell l) :=
  causal_linear (causalize_causal _) (causalize_causal _) _ _

-- @paper-step thm:pid_explicit_family/partial_fraction_kernel_integrability
theorem explicitJ_integrable {ρ : ℝ} (hρ : 0<ρ) (ell : ℝ) {l : ℝ} (hl : 0<l) :
    Integrable (explicitJ ρ ell l) :=
  ((expKernel_integrable hl).const_mul _).add
    ((expKernel_integrable (one_div_pos.mpr hρ)).const_mul _)

-- @paper-step thm:pid_explicit_family/actual_partial_fraction_Laplace_transform
theorem explicitJ_laplace {i ρ ell l δ : ℝ} (h : ExplicitPIDData i ρ ell l δ)
    {p : ℝ} (hp : 0≤p) :
    laplace (explicitJ ρ ell l) p=(1+ell*p)/((1+ρ*p)*(p+l)) := by
  obtain ⟨hr,_,_,_,hden⟩ := explicitPID_order h
  have hl := h.rate_pos
  have hfp : 1+ρ*p≠0 := ne_of_gt (by positivity)
  have hpl : p+l≠0 := ne_of_gt (by linarith)
  have hpr : p+1/ρ≠0 := ne_of_gt (by positivity)
  change laplace (fun t => explicitA ρ ell l*expKernel l t+explicitB ρ ell l*expKernel (1/ρ) t) p=_
  rw [laplace_linear (expKernel_integrable hl)
    (expKernel_integrable (one_div_pos.mpr hr)) _ _ hp,
    expKernel_laplace hl hp,expKernel_laplace (one_div_pos.mpr hr) hp]
  unfold explicitA explicitB
  field_simp
  <;> ring

-- @paper-step thm:pid_explicit_family/positive_kernel_causality
theorem explicitK_causal {δ : ℝ} (hδ : 0≤δ) (i ρ ell l : ℝ) :
    Causal (explicitK i ρ ell l δ) := by
  change Causal (fun t => l*expKernel l t-i*shift δ (explicitJ ρ ell l) t)
  simpa only [explicitK,expKernel,neg_mul,sub_eq_add_neg] using
    causal_linear (causalize_causal (fun t => Real.exp (-l*t)))
      (causal_shift (explicitJ_causal ρ ell l) hδ) l (-i)

-- @paper-step thm:pid_explicit_family/positive_kernel_integrability
theorem explicitK_integrable {i ρ ell l δ : ℝ} (h : ExplicitPIDData i ρ ell l δ) :
    Integrable (explicitK i ρ ell l δ) :=
  ((expKernel_integrable h.rate_pos).const_mul l).sub
    ((shift_integrable δ (explicitJ_integrable (explicitPID_order h).1 ell h.rate_pos)).const_mul i)

-- @paper-step thm:pid_explicit_family/positive_kernel_actual_transform
theorem explicitK_laplace {i ρ ell l δ : ℝ} (h : ExplicitPIDData i ρ ell l δ)
    {p : ℝ} (hp : 0≤p) :
    laplace (explicitK i ρ ell l δ) p=
      l/(p+l)-i*Real.exp (-δ*p)*(1+ell*p)/((1+ρ*p)*(p+l)) := by
  have he : explicitK i ρ ell l δ=fun t => l*expKernel l t+(-i)*shift δ (explicitJ ρ ell l) t := by
    funext t; simp [explicitK,sub_eq_add_neg]
  rw [he,laplace_linear (expKernel_integrable h.rate_pos)
    (shift_integrable δ (explicitJ_integrable (explicitPID_order h).1 ell h.rate_pos)) _ _ hp,
    expKernel_laplace h.rate_pos hp,laplace_shift (explicitJ_causal ρ ell l) h.delay_pos.le p,
    explicitJ_laplace h hp]
  ring

-- @paper-step thm:pid_explicit_family/kernel_nonnegativity_including_the_entire_tail
theorem explicitK_nonneg {i ρ ell l δ : ℝ} (h : ExplicitPIDData i ρ ell l δ) (t : ℝ) :
    0≤explicitK i ρ ell l δ t := by
  obtain ⟨hr,hrl,hell,_,hden⟩ := explicitPID_order h
  obtain ⟨hA,hB,hAB,_⟩ := explicitPID_coefficients h
  have hi := h.gain_pos
  have hl := h.rate_pos
  have hiAB : i*(explicitA ρ ell l+explicitB ρ ell l)=1 := by
    rw [hAB]; exact (explicitPID_controller_coefficients h).2.2.2.2
  by_cases ht : 0≤t
  · by_cases htd : δ≤t
    · have hu : 0≤t-δ := sub_nonneg.mpr htd
      have hrl' : l≤1/ρ := by
        apply (le_div_iff₀ hr).mpr
        nlinarith
      have he := Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_right (neg_le_neg hrl') hu)
      have hshift : Real.exp (-l*t)=Real.exp (-1)*Real.exp (-l*(t-δ)) := by
        rw [← Real.exp_add]
        congr 1
        nlinarith [h.rate_delay]
      simp only [explicitK,explicitJ,shift,expKernel,causalize,
        indicator_of_mem (show t∈Ici (0 : ℝ) from ht),
        indicator_of_mem (show t-δ∈Ici (0 : ℝ) from hu)]
      rw [hshift]
      have hb := mul_le_mul_of_nonneg_left he (mul_nonneg hi.le hB.le)
      have hj := mul_le_mul_of_nonneg_right h.kernel_jump (Real.exp_nonneg (-l*(t-δ)))
      have hm := congrArg (fun z : ℝ => z*Real.exp (-l*(t-δ))) hiAB
      nlinarith only [hm,hb,hj]
    · have hn : ¬0≤t-δ := by linarith
      simp only [explicitK,explicitJ,shift,expKernel,causalize,indicator_of_mem (show t∈Ici (0 : ℝ) from ht),
        indicator_of_notMem (show t-δ∉Ici (0 : ℝ) from hn),mul_zero,add_zero,sub_zero]
      exact mul_nonneg hl.le (Real.exp_nonneg _)
  · have hn : ¬0≤t-δ := by linarith [h.delay_pos]
    simp [explicitK,explicitJ,shift,expKernel,causalize,ht,hn]

-- @paper-step thm:pid_explicit_family/exact_kernel_mass_and_strict_contraction
theorem explicitK_mass {i ρ ell l δ : ℝ} (h : ExplicitPIDData i ρ ell l δ) :
    (∫ t, explicitK i ρ ell l δ t)=1-i/l ∧ absArea (explicitK i ρ ell l δ) volume<1 := by
  have hc := explicitK_causal h.delay_pos.le i ρ ell l
  have hm : (∫ t, explicitK i ρ ell l δ t)=1-i/l := by
    rw [causal_integral_halfLine hc]
    have hh := explicitK_laplace h (p:=0) le_rfl
    simpa [laplace,ne_of_gt h.rate_pos] using hh
  refine ⟨hm,?_⟩
  rw [positive_kernel_mass (ae_of_all _ (explicitK_nonneg h)),hm]
  have hi := div_pos h.gain_pos h.rate_pos
  linarith

-- @paper-step thm:pid_explicit_family/exponential_kernel_control
theorem explicitK_control {i ρ ell l δ η : ℝ} (h : ExplicitPIDData i ρ ell l δ)
    (hl : η<l) (hr : η<1/ρ) :
    ∃ C : ℝ, WeightedControl η (explicitK i ρ ell l δ) C := by
  obtain ⟨Cg,hg⟩ := expKernel_control hl
  obtain ⟨Ch,hh⟩ := expKernel_control hr
  have hJ := weightedControl_add (weightedControl_smul hg (explicitA ρ ell l))
    (weightedControl_smul hh (explicitB ρ ell l))
  have hK := weightedControl_add (weightedControl_smul hg l)
    (weightedControl_smul (weightedControl_shift hJ δ) (-i))
  refine ⟨|l| *Cg+|(-i)| *(Real.exp (η*δ)*(|explicitA ρ ell l| *Cg+|explicitB ρ ell l| *Ch)),?_⟩
  change WeightedControl η (fun t => l*expKernel l t-i*shift δ
    (fun t => explicitA ρ ell l*expKernel l t+explicitB ρ ell l*expKernel (1/ρ) t) t) _
  simpa only [neg_mul,sub_eq_add_neg] using hK

-- @paper-step thm:pid_explicit_family/strict_contraction_in_a_positive_exponential_weight
theorem explicitK_small_weight {i ρ ell l δ : ℝ} (h : ExplicitPIDData i ρ ell l δ) :
    ∃ η CK CG : ℝ, 0<η ∧ η≤1/2 ∧ η<l ∧ η<1/ρ ∧
      WeightedControl η (explicitK i ρ ell l δ) CK ∧
      absArea (expWeight η (explicitK i ρ ell l δ)) volume<1 ∧
      WeightedControl η (expKernel l) CG := by
  let β := min (1/2 : ℝ) (min (l/2) (1/(2*ρ)))
  have hl := h.rate_pos
  have hr := (explicitPID_order h).1
  have hβ : 0<β := by dsimp [β]; positivity
  have hβhalf : β≤1/2 := min_le_left _ _
  have hβl : β<l := lt_of_le_of_lt ((min_le_right _ _).trans (min_le_left _ _)) (by linarith)
  have hβr : β<1/ρ := by
    apply lt_of_le_of_lt ((min_le_right _ _).trans (min_le_right _ _))
    have he : 1/(2*ρ)=(1/ρ)/2 := by ring
    rw [he]; have := one_div_pos.mpr hr; linarith
  obtain ⟨C,hC⟩ := explicitK_control h hβl hβr
  have hm : (∫ t, explicitK i ρ ell l δ t)<1 := by
    rw [(explicitK_mass h).1]; have := div_pos h.gain_pos hl; linarith
  obtain ⟨η,hη,hle,_,hq⟩ := expWeight_small_mass (explicitK_integrable h) hm hβ hC.integrable
  obtain ⟨CK,hK⟩ := explicitK_control h (hle.trans_lt hβl) (hle.trans_lt hβr)
  obtain ⟨CG,hG⟩ := expKernel_control (hle.trans_lt hβl)
  refine ⟨η,CK,CG,hη,hle.trans hβhalf,hle.trans_lt hβl,hle.trans_lt hβr,hK,?_,hG⟩
  have hn : ∀ᵐ t, 0≤expWeight η (explicitK i ρ ell l δ) t := ae_of_all _
    (fun t => mul_nonneg (Real.exp_nonneg _) (explicitK_nonneg h t))
  rw [positive_kernel_mass hn]
  exact hq

end MIACE
