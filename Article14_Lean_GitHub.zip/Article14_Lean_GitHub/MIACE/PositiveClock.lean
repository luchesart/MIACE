import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Analysis.Calculus.Deriv.Inverse
import Mathlib.Topology.Order.IntermediateValue
import Mathlib.Topology.Order.MonotoneContinuity
import Mathlib.Tactic

/-! A continuous positive clock with a uniform positive lower bound has
a globally defined differentiable inverse. This supplies a global scalar
flow without postulating an ODE solution. -/

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def positiveClock (q : ℝ → ℝ) (x : ℝ) : ℝ :=
  ∫ s in (0 : ℝ)..x, q s

-- @paper-step thm:nonlinear_miace/clock_derivative
theorem positiveClock_hasDerivAt {q : ℝ → ℝ} (hq : Continuous q) (x : ℝ) :
    HasDerivAt (positiveClock q) (q x) x := by
  exact intervalIntegral.integral_hasDerivAt_right (hq.intervalIntegrable _ _)
    hq.aestronglyMeasurable.stronglyMeasurableAtFilter hq.continuousAt

-- @paper-step thm:nonlinear_miace/clock_zero
theorem positiveClock_zero (q : ℝ → ℝ) : positiveClock q 0 = 0 := by
  simp [positiveClock]

-- @paper-step thm:nonlinear_miace/clock_positive_bounds
theorem positiveClock_bounds_nonneg {q : ℝ → ℝ} (hq : Continuous q)
    {l u x : ℝ} (hlo : ∀ z, l ≤ q z) (hup : ∀ z, q z ≤ u) (hx : 0 ≤ x) :
    l*x ≤ positiveClock q x ∧ positiveClock q x ≤ u*x := by
  constructor
  · have h := intervalIntegral.integral_mono hx
      (intervalIntegrable_const : IntervalIntegrable (fun _ : ℝ => l) volume 0 x)
      (hq.intervalIntegrable 0 x) hlo
    simpa [positiveClock, mul_comm] using h
  · have h := intervalIntegral.integral_mono hx (hq.intervalIntegrable 0 x)
      (intervalIntegrable_const : IntervalIntegrable (fun _ : ℝ => u) volume 0 x) hup
    simpa [positiveClock, mul_comm] using h

-- @paper-step thm:nonlinear_miace/clock_negative_bounds
theorem positiveClock_bounds_nonpos {q : ℝ → ℝ} (hq : Continuous q)
    {l u x : ℝ} (hlo : ∀ z, l ≤ q z) (hup : ∀ z, q z ≤ u) (hx : x ≤ 0) :
    u*x ≤ positiveClock q x ∧ positiveClock q x ≤ l*x := by
  have h1 := intervalIntegral.integral_mono hx
    (intervalIntegrable_const : IntervalIntegrable (fun _ : ℝ => l) volume x 0)
    (hq.intervalIntegrable x 0) hlo
  have h2 := intervalIntegral.integral_mono hx (hq.intervalIntegrable x 0)
    (intervalIntegrable_const : IntervalIntegrable (fun _ : ℝ => u) volume x 0) hup
  have heq : positiveClock q x = -(∫ s in x..0, q s) :=
    intervalIntegral.integral_symm x 0
  simp only [intervalIntegral.integral_const, zero_sub, smul_eq_mul] at h1 h2
  constructor <;> rw [heq] <;> nlinarith

-- @paper-step thm:nonlinear_miace/global_positive_clock_inverse
theorem positiveClock_exists_inverse (q : ℝ → ℝ) (hq : Continuous q)
    (l u : ℝ) (hl : 0 < l) (hlo : ∀ x, l ≤ q x) (hup : ∀ x, q x ≤ u) :
    ∃ s : ℝ → ℝ, s 0 = 0 ∧ StrictMono s ∧ Continuous s ∧
      (∀ t, HasDerivAt s (q (s t))⁻¹ t) ∧
      (∀ t, 0 ≤ t → 0 ≤ s t ∧ l*s t ≤ t ∧ t ≤ u*s t) := by
  have hder := positiveClock_hasDerivAt hq
  have hcont : Continuous (positiveClock q) :=
    continuous_iff_continuousAt.mpr (fun x => (hder x).continuousAt)
  have hmono : StrictMono (positiveClock q) :=
    strictMono_of_hasDerivAt_pos hder (fun x => hl.trans_le (hlo x))
  have hsurj : Function.Surjective (positiveClock q) := by
    intro b
    apply mem_range_of_exists_le_of_exists_ge hcont
    · refine ⟨min 0 (b/l), ?_⟩
      have hb := (positiveClock_bounds_nonpos hq hlo hup (min_le_left 0 (b/l))).2
      have hi : l * min 0 (b/l) ≤ b := by
        calc
          l * min 0 (b/l) ≤ l * (b/l) := mul_le_mul_of_nonneg_left (min_le_right _ _) hl.le
          _ = b := by field_simp
      exact hb.trans hi
    · refine ⟨max 0 (b/l), ?_⟩
      have hb := (positiveClock_bounds_nonneg hq hlo hup (le_max_left 0 (b/l))).1
      have hi : b ≤ l * max 0 (b/l) := by
        calc
          b = l * (b/l) := by field_simp
          _ ≤ l * max 0 (b/l) := mul_le_mul_of_nonneg_left (le_max_right _ _) hl.le
      exact hi.trans hb
  let iso : ℝ ≃o ℝ := hmono.orderIsoOfSurjective (positiveClock q) hsurj
  have hinv (t : ℝ) : positiveClock q (iso.symm t) = t := iso.apply_symm_apply t
  have hz : iso.symm 0 = 0 := by
    apply iso.injective
    simp [iso, positiveClock_zero]
  refine ⟨iso.symm, hz, iso.symm.strictMono, iso.symm.continuous, ?_, ?_⟩
  · intro t
    exact (hder (iso.symm t)).of_local_left_inverse iso.symm.continuous.continuousAt
      (ne_of_gt (hl.trans_le (hlo _))) (Eventually.of_forall hinv)
  · intro t ht
    have hs : 0 ≤ iso.symm t := by
      rw [← hz]
      exact iso.symm.monotone ht
    have hb := positiveClock_bounds_nonneg hq hlo hup hs
    rw [hinv] at hb
    exact ⟨hs, hb⟩

end MIACE
