import MIACE.PositiveLag
import Mathlib.Analysis.Calculus.Deriv.Polynomial

/-! Stage 14. Exact finite-interval delay remainder, by induction over the
actual first-order factors. The index n means n+1 factors in B. No distinct
rate assumption and no division by a spectral factor p+r is used. -/
namespace MIACE
open MeasureTheory Filter Set Polynomial
open scoped Topology

/-- The sign-corrected impulse at negative time, before the delay shift. -/
noncomputable def reverseImpulse (r : ℕ → ℝ) : ℕ → ℝ → ℝ
  | 0 => fun t => r 0 * Real.exp (r 0*t)
  | n+1 => fun t => r (n+1)*Real.exp (r (n+1)*t)*
      ∫ s in 0..t, Real.exp (-r (n+1)*s)*reverseImpulse r n s

noncomputable def remainderB (r : ℕ → ℝ) : ℕ → ℝ[X]
  | 0 => C (1/r 0)*X+1
  | n+1 => remainderB r n*(C (1/r (n+1))*X+1)

noncomputable def remainderI (r : ℕ → ℝ) (δ : ℝ) : ℕ → ℝ[X]
  | 0 => C (Real.exp (r 0*δ))
  | n+1 => remainderI r δ n +
      C ((-1 : ℝ)^(n+1)*reverseImpulse r (n+1) δ/r (n+1))*remainderB r n

noncomputable def remainderJ (r : ℕ → ℝ) (n : ℕ) (δ t : ℝ) : ℝ :=
  reverseImpulse r n (δ-t)

noncomputable def remainderTransform (r : ℕ → ℝ) (n : ℕ) (δ p : ℝ) : ℝ :=
  ∫ t in 0..δ, Real.exp (-p*t)*remainderJ r n δ t

-- @paper-step lem:n_remainder/recursive_impulse_continuity
theorem reverseImpulse_continuous (r : ℕ → ℝ) (n : ℕ) :
    Continuous (reverseImpulse r n) := by
  induction n with
  | zero => dsimp [reverseImpulse]; fun_prop
  | succ n ih =>
    have hc : Continuous (fun s => Real.exp (-r (n+1)*s)*reverseImpulse r n s) :=
      (by fun_prop : Continuous (fun s : ℝ => Real.exp (-r (n+1)*s))).mul ih
    exact (by fun_prop : Continuous (fun t => r (n+1)*Real.exp (r (n+1)*t))).mul
      (intervalIntegral.continuous_primitive (fun a b => hc.intervalIntegrable a b) 0)

-- @paper-step lem:n_remainder/recursive_impulse_initial_values
theorem reverseImpulse_zero (r : ℕ → ℝ) (n : ℕ) :
    reverseImpulse r 0 0=r 0 ∧ reverseImpulse r (n+1) 0=0 := by
  simp [reverseImpulse]

-- @paper-step lem:n_remainder/recursive_impulse_derivative
theorem reverseImpulse_deriv (r : ℕ → ℝ) (n : ℕ) (t : ℝ) :
    HasDerivAt (reverseImpulse r (n+1))
      (r (n+1)*(reverseImpulse r (n+1) t+reverseImpulse r n t)) t := by
  have hc : Continuous (fun s => Real.exp (-r (n+1)*s)*reverseImpulse r n s) :=
    (by fun_prop : Continuous (fun s : ℝ => Real.exp (-r (n+1)*s))).mul (reverseImpulse_continuous r n)
  have hd := ((hasDerivAt_id t).const_mul (r (n+1))).exp.const_mul (r (n+1))
  have hi := intervalIntegral.integral_hasDerivAt_right (hc.intervalIntegrable 0 t)
    (hc.stronglyMeasurableAtFilter _ _) hc.continuousAt
  have he : Real.exp (r (n+1)*t)*Real.exp (-r (n+1)*t)=1 := by
    rw [← Real.exp_add]; ring_nf; simp
  convert hd.mul hi using 1
  · rfl
  · dsimp [reverseImpulse, id_eq]
    nlinarith [congrArg (fun z => r (n+1)*reverseImpulse r n t*z) he]

-- @paper-step lem:n_remainder/negative_time_sign_including_repeated_rates
theorem reverseImpulse_nonneg (r : ℕ → ℝ) (n : ℕ)
    (hr : ∀ j≤n, 0≤r j) {t : ℝ} (ht : 0≤t) : 0≤reverseImpulse r n t := by
  induction n generalizing t with
  | zero => exact mul_nonneg (hr 0 le_rfl) (Real.exp_nonneg _)
  | succ n ih =>
    apply mul_nonneg (mul_nonneg (hr (n+1) le_rfl) (Real.exp_nonneg _))
    apply intervalIntegral.integral_nonneg ht
    intro s hs
    exact mul_nonneg (Real.exp_nonneg _) (ih (fun j hj => hr j (by omega)) hs.1)

-- @paper-step lem:n_remainder/compact_remainder_sign
theorem remainderJ_nonneg (r : ℕ → ℝ) (n : ℕ)
    (hr : ∀ j≤n, 0≤r j) {δ t : ℝ} (ht : t≤δ) : 0≤remainderJ r n δ t :=
  reverseImpulse_nonneg r n hr (sub_nonneg.mpr ht)

-- @paper-step lem:n_remainder/compact_remainder_continuity
theorem remainderJ_continuous (r : ℕ → ℝ) (n : ℕ) (δ : ℝ) :
    Continuous (remainderJ r n δ) :=
  (reverseImpulse_continuous r n).comp (by fun_prop)

-- @paper-step lem:n_remainder/first_factor_remainder
theorem remainder_first_factor (r : ℕ → ℝ) (δ p : ℝ) (hr : r 0≠0) :
    Real.exp (-p*δ)=Real.exp (r 0*δ)-(1+p/r 0)*remainderTransform r 0 δ p := by
  have hd : ∀ t : ℝ, HasDerivAt
      (fun s => Real.exp (-p*s)*Real.exp (r 0*(δ-s)))
      (-(1+p/r 0)*(Real.exp (-p*t)*remainderJ r 0 δ t)) t := by
    intro t
    convert (((hasDerivAt_id t).const_mul (-p)).exp).mul
      ((((hasDerivAt_id t).const_sub δ).const_mul (r 0)).exp) using 1
    · rfl
    · dsimp [remainderJ,reverseImpulse, id_eq]
      field_simp [hr]; ring
  have hf := intervalIntegral.integral_eq_sub_of_hasDerivAt (fun t _ => hd t)
    (a := 0) (b := δ)
    (by apply Continuous.intervalIntegrable; exact
      (((by fun_prop : Continuous (fun t : ℝ => Real.exp (-p*t))).mul
        (remainderJ_continuous r 0 δ)).const_mul _))
  rw [intervalIntegral.integral_const_mul] at hf
  simp only [mul_zero,sub_self,Real.exp_zero,mul_one,sub_zero,one_mul] at hf
  change -(1+p/r 0)*remainderTransform r 0 δ p=_ at hf
  linarith

-- @paper-step lem:n_remainder/remainder_recurrence_without_pole_division
theorem remainder_next_factor (r : ℕ → ℝ) (n : ℕ) (δ p : ℝ)
    (hr : r (n+1)≠0) :
    (1+p/r (n+1))*remainderTransform r (n+1) δ p=
      reverseImpulse r (n+1) δ/r (n+1)-remainderTransform r n δ p := by
  have hd : ∀ t : ℝ, HasDerivAt
      (fun s => Real.exp (-p*s)*remainderJ r (n+1) δ s)
      (-(p+r (n+1))*(Real.exp (-p*t)*remainderJ r (n+1) δ t)-
        r (n+1)*(Real.exp (-p*t)*remainderJ r n δ t)) t := by
    intro t
    have hj := (reverseImpulse_deriv r n (δ-t)).comp t ((hasDerivAt_id t).const_sub δ)
    convert (((hasDerivAt_id t).const_mul (-p)).exp).mul hj using 1
    · rfl
    · dsimp [remainderJ, id_eq]; ring
  have hc (m : ℕ) : Continuous (fun t => Real.exp (-p*t)*remainderJ r m δ t) :=
    (by fun_prop : Continuous (fun t : ℝ => Real.exp (-p*t))).mul (remainderJ_continuous r m δ)
  have hf := intervalIntegral.integral_eq_sub_of_hasDerivAt (fun t _ => hd t)
    ((((hc (n+1)).const_mul _).sub ((hc n).const_mul _)).intervalIntegrable 0 δ)
  rw [intervalIntegral.integral_sub (((hc (n+1)).const_mul _).intervalIntegrable 0 δ)
      (((hc n).const_mul _).intervalIntegrable 0 δ),
    intervalIntegral.integral_const_mul,intervalIntegral.integral_const_mul] at hf
  simp only [remainderJ,sub_self,sub_zero,mul_zero,Real.exp_zero,one_mul,
    (reverseImpulse_zero r n).2,zero_sub] at hf
  change -(p+r (n+1))*remainderTransform r (n+1) δ p-
    r (n+1)*remainderTransform r n δ p= -reverseImpulse r (n+1) δ at hf
  field_simp [hr]
  nlinarith

-- @paper-step lem:n_remainder/exact_real_delay_remainder_all_orders
theorem exact_delay_remainder_real (r : ℕ → ℝ) (n : ℕ) (δ p : ℝ)
    (hr : ∀ j≤n, r j≠0) :
    Real.exp (-δ*p)=(remainderI r δ n).eval p+
      (-1 : ℝ)^(n+1)*(remainderB r n).eval p*remainderTransform r n δ p := by
  induction n with
  | zero =>
    have he := remainder_first_factor r δ p (hr 0 le_rfl)
    simp only [remainderI,remainderB,eval_C,eval_add,eval_mul,eval_X,eval_one,
      pow_one] 
    convert he using 1 <;> ring
  | succ n ih =>
    have hi := ih (fun j hj => hr j (by omega))
    have hn := remainder_next_factor r n δ p (hr (n+1) le_rfl)
    simp only [remainderI,remainderB,eval_add,eval_mul,eval_C,eval_X,eval_one]
    rw [hi,pow_succ (-1 : ℝ) (n+1)]
    have hh := congrArg (fun z => (-1 : ℝ)^(n+1)*(remainderB r n).eval p*z) hn
    simp only [div_eq_mul_inv] at hh ⊢
    nlinarith

end MIACE
