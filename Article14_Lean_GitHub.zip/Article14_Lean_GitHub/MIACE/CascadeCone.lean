import MIACE.CascadeNecessity

/-! Stage 13: the complete signal equivalence for an arbitrary ordinary
finite positive cascade. Moment integrability and settling are conclusions.
Controller realization is assembled separately. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:command_cone/ordinary_slowest_moment_sufficiency
theorem slowest_lag_moment_sufficient {v x : ℝ → ℝ}
    (h : LagResponse 1 (fun t => 1+v t) x)
    (hn : ∀ᵐ t ∂halfLine, 0 ≤ v t)
    (hJ : Integrable (fun t => Real.exp t*v t) halfLine) (hM : moment v ≤ 1) :
    ∀ t : ℝ, 0 ≤ t → x t ≤ 1 := by
  intro t ht
  have hp : ∀ᵐ s ∂halfLine, 0 ≤ Real.exp s*v s := hn.mono
    (fun s hs => mul_nonneg (Real.exp_nonneg _) hs)
  have hb : (∫ s in 0..t, Real.exp s*v s) ≤ moment v := by
    rw [intervalIntegral.integral_of_le ht]
    exact setIntegral_mono_set hJ hp (Eventually.of_forall (fun _ hs => hs.1))
  rw [slowest_lag_balance h ht] at hb
  have := Real.exp_pos t
  nlinarith

-- @paper-step thm:command_cone/ordinary_cascade_moment_sufficiency
theorem cascade_moment_sufficient (N : ℕ) (σ : ℕ → ℝ) (x : ℕ → ℝ → ℝ)
    {v : ℝ → ℝ} (hσ : ∀ j ≤ N, 0 < σ j) (hfirst : σ 0=1)
    (hx : ∀ j ≤ N, LagResponse (σ j) (x j) (x (j+1)))
    (hw : x 0=fun t => 1+v t) (hn : ∀ᵐ t ∂halfLine, 0 ≤ v t)
    (hJ : Integrable (fun t => Real.exp t*v t) halfLine) (hM : moment v ≤ 1) :
    ∀ j ≤ N, MonotoneOn (x (j+1)) (Ici 0) ∧
      ∀ t : ℝ, 0 ≤ t → 0 ≤ x (j+1) t ∧ x (j+1) t ≤ 1 := by
  have hw1 : ∀ᵐ t ∂halfLine, 1 ≤ x 0 t := by
    rw [hw]
    filter_upwards [hn] with t ht
    linarith
  have hc := cascade_clipped_monotone (N+1) σ x (fun j hj => hσ j (by omega))
    (fun j hj => hx j (by omega)) hw1
  have hu : ∀ j ≤ N, ∀ t : ℝ, 0 ≤ t → x (j+1) t ≤ 1 := by
    intro j hj
    induction j with
    | zero =>
      exact slowest_lag_moment_sufficient (by simpa [hfirst,hw] using hx 0 (Nat.zero_le N)) hn hJ hM
    | succ j ih =>
      intro t ht
      apply lag_upper_barrier (hx (j+1) hj) (hσ (j+1) hj) le_rfl ht
        (by rw [(hx (j+1) hj).initial]; norm_num)
      filter_upwards [ae_restrict_mem measurableSet_Ioc] with s hs
      exact ih (by omega) s (le_of_lt (show 0<s from hs.1))
  intro j hj
  have hclip := hc j (by omega)
  exact ⟨unclipped_monotone hclip.2 (hu j hj),fun t ht => ⟨hclip.1 t ht,hu j hj t ht⟩⟩

-- A monotone nonnegative L1 error tends to zero. This derives settling
-- rather than adding it to the command-cone hypotheses.
-- @paper-step thm:command_cone/monotone_integrable_error_settles
theorem monotone_error_settles {e : ℝ → ℝ} (he : Integrable e halfLine)
    (hn : ∀ t : ℝ, 0 ≤ t → 0 ≤ e t) (hm : AntitoneOn e (Ici 0)) :
    Tendsto e atTop (𝓝 0) := by
  have ha : ∀ᵐ s ∂halfLine, 0 ≤ e s := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with s hs
    exact hn s (le_of_lt (show 0<s from hs))
  have hb (t : ℝ) (ht : 0<t) : e t ≤ (∫ s, e s ∂halfLine)/t := by
    have hi : IntervalIntegrable e volume 0 t :=
      (intervalIntegrable_iff_integrableOn_Ioc_of_le ht.le).mpr
        (IntegrableOn.mono_set he (fun _ hs => hs.1))
    have h₁ := intervalIntegral.integral_mono_on ht.le intervalIntegrable_const hi
      (fun s hs => hm hs.1 ht.le hs.2)
    have h₂ : (∫ s in 0..t, e s) ≤ ∫ s, e s ∂halfLine := by
      rw [intervalIntegral.integral_of_le ht.le]
      exact setIntegral_mono_set he ha (Eventually.of_forall (fun _ hs => hs.1))
    simp only [intervalIntegral.integral_const,sub_zero,smul_eq_mul] at h₁
    exact (le_div_iff₀ ht).mpr (by nlinarith)
  have hl : Tendsto (fun t : ℝ => (∫ s, e s ∂halfLine)/t) atTop (𝓝 0) := by
    simpa [div_eq_mul_inv] using tendsto_inv_atTop_zero.const_mul (∫ s, e s ∂halfLine)
  apply squeeze_zero_norm' _ hl
  filter_upwards [eventually_gt_atTop (0 : ℝ)] with t ht
  rw [Real.norm_eq_abs,abs_of_nonneg (hn t ht.le)]
  exact hb t ht

-- @paper-step thm:command_cone/restored_delay_signal_equivalence
theorem cascade_signal_cone (N : ℕ) (σ : ℕ → ℝ) (x : ℕ → ℝ → ℝ)
    {v : ℝ → ℝ} {δ : ℝ} (hδ : 0 ≤ δ)
    (hσ : ∀ j ≤ N, 0 < σ j ∧ σ j ≤ 1) (hfirst : σ 0=1)
    (hx : ∀ j ≤ N, LagResponse (σ j) (x j) (x (j+1)))
    (hw : x 0=fun t => 1+v t) (hv : Integrable v halfLine)
    (hn : ∀ᵐ t ∂halfLine, 0 ≤ v t)
    (he : Integrable (delayedError δ (fun t => 1-x (N+1) t)) halfLine) :
    let y := fun t => 1-delayedError δ (fun s => 1-x (N+1) s) t
    ((∀ t : ℝ, 0 ≤ t → y t ≤ 1) ↔
      Integrable (fun t => Real.exp t*v t) halfLine ∧ moment v ≤ 1) ∧
    ((Monotone y ∧ y 0=0 ∧ Tendsto y atTop (𝓝 1)) ↔
      Integrable (fun t => Real.exp t*v t) halfLine ∧ moment v ≤ 1) := by
  dsimp only
  have hnec : (∀ t : ℝ, 0 ≤ t → 1-delayedError δ (fun s => 1-x (N+1) s) t ≤ 1) →
      Integrable (fun t => Real.exp t*v t) halfLine ∧ moment v ≤ 1 := by
    intro hy
    apply cascade_moment_necessary N σ x hσ hfirst hx hw hv hn
    intro t ht
    rcases ht.eq_or_lt with ht | ht
    · rw [← ht,(hx N le_rfl).initial]; norm_num
    · have hh := hy (t+δ) (by linarith)
      simpa [delayedError,show ¬t+δ≤δ by linarith] using hh
  have hsuf : (Integrable (fun t => Real.exp t*v t) halfLine ∧ moment v ≤ 1) →
      (∀ t : ℝ, 0 ≤ t → 1-delayedError δ (fun s => 1-x (N+1) s) t ≤ 1) ∧
      Monotone (fun t => 1-delayedError δ (fun s => 1-x (N+1) s) t) ∧
      (1-delayedError δ (fun s => 1-x (N+1) s) 0=0) ∧
      Tendsto (fun t => 1-delayedError δ (fun s => 1-x (N+1) s) t) atTop (𝓝 1) := by
    rintro ⟨hJ,hM⟩
    have hs := cascade_moment_sufficient N σ x (fun j hj => (hσ j hj).1)
      hfirst hx hw hn hJ hM N le_rfl
    have hy := cascade_delayed_monotone hs.1 (fun t ht => (hs.2 t ht).1) (δ := δ)
    have hb : ∀ t : ℝ, 0 ≤ t → 1-delayedError δ (fun s => 1-x (N+1) s) t ≤ 1 := by
      intro t ht
      by_cases htd : t≤δ
      · simp [delayedError,htd]
      · simpa [delayedError,htd] using (hs.2 (t-δ) (by linarith)).2
    have hlim := monotone_error_settles he (fun t ht => by linarith [hb t ht])
      (fun a ha b hb hab => by have := hy hab; linarith)
    refine ⟨hb,hy,by simp [delayedError,hδ],?_⟩
    simpa using tendsto_const_nhds.sub hlim
  constructor
  · exact ⟨hnec,fun h => (hsuf h).1⟩
  · constructor
    · rintro ⟨hm,hz,hl⟩
      apply hnec
      intro t ht
      apply ge_of_tendsto hl
      filter_upwards [eventually_ge_atTop t] with b hb
      exact hm hb
    · intro h
      exact (hsuf h).2

-- @paper-step thm:command_cone/actual_cascade_front_areas
theorem cascade_cone_areas (N : ℕ) (σ : ℕ → ℝ) (x : ℕ → ℝ → ℝ)
    {v H : ℝ → ℝ} {δ μ : ℝ} (hδ : 0 ≤ δ)
    (hσ : ∀ j ≤ N, 0 < σ j ∧ σ j ≤ 1) (hfirst : σ 0=1)
    (hx : ∀ j ≤ N, LagResponse (σ j) (x j) (x (j+1)))
    (hw : x 0=fun t => 1+v t)
    (h : TransferResponse (delayedError δ (fun t => 1-x (N+1) t)) v H δ)
    (hH : HasDerivAt H (-μ) 0) (h0 : H 0=1)
    (hn : ∀ᵐ t ∂halfLine, 0 ≤ v t)
    (hJ : Integrable (fun t => Real.exp t*v t) halfLine) (hM : moment v ≤ 1) :
    0 ≤ commandArea v ∧ commandArea v < 1 ∧ absArea v halfLine=commandArea v ∧
      absArea (delayedError δ (fun t => 1-x (N+1) t)) halfLine=μ+δ-commandArea v := by
  have hy := (cascade_signal_cone N σ x hδ hσ hfirst hx hw h.command_integrable hn
    h.error_integrable).1.mpr ⟨hJ,hM⟩
  have ha : absArea v halfLine=commandArea v := by
    apply integral_congr_ae
    filter_upwards [hn] with t ht; exact abs_of_nonneg ht
  have he : absArea (delayedError δ (fun t => 1-x (N+1) t)) halfLine=
      ∫ t, delayedError δ (fun t => 1-x (N+1) t) t ∂halfLine := by
    apply integral_congr_ae
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact abs_of_nonneg (by linarith [hy t (le_of_lt (show 0<t from ht))])
  refine ⟨integral_nonneg_of_ae hn,area_lt_one_of_moment h.command_integrable hJ hn hM,ha,?_⟩
  rw [he]
  have hb := transfer_signed_balance h μ hH h0
  change _+commandArea v=μ+δ at hb
  linarith

end MIACE
