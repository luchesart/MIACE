import MIACE.CascadeOrdinary

/-! The even command estimate is a pointwise theorem for the actual
ordinary resolvent, not an assumption on a transform numerator. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:n_construction/even_parity_pointwise_tail_convolution_bound
theorem even_resolvent_tail_bound {J : ℝ → ℝ} (hc : Continuous J) {δ a c : ℝ}
    (hδ : 0≤δ) (ha : 0<a) (hn : ∀ t∈Icc (0 : ℝ) δ, 0≤J t) {R : ℝ → ℝ}
    (h : CompactResolventEvolution J δ a c (-1) R)
    (hR : ∀ t, 0≤t → 0≤R t) {t : ℝ} (ht : 0≤t) :
    (compactKernel (compactTail J δ) δ ⋆ causalize R) t≤
      compactExpMoment (compactTail J δ) δ (c/a)*R t := by
  let K := compactKernel (compactTail J δ) δ
  have hK (s : ℝ) : 0≤K s := compactKernel_nonneg
    (fun u hu => compactTail_nonneg hu.1 hu.2 hn) s
  have hRn (s : ℝ) : 0≤causalize R s := by
    by_cases hs : 0≤s
    · simpa [causalize,hs] using hR s hs
    · simp [causalize,hs]
  have hb (s : ℝ) : K s*causalize R (t-s)≤expWeight (c/a) K s*R t := by
    by_cases hs : s∈Icc (0 : ℝ) δ
    · by_cases hst : s≤t
      · have hh := mul_le_mul_of_nonneg_left
          (even_resolvent_backward ha hn h hR hs.1 hst) (hK s)
        simp only [causalize,indicator_of_mem (show t-s∈Ici (0 : ℝ) from sub_nonneg.mpr hst)]
        dsimp [expWeight]
        nlinarith
      · rw [show causalize R (t-s)=0 by simp [causalize,show ¬0≤t-s by linarith]]
        simp only [mul_zero]
        exact mul_nonneg (mul_nonneg (Real.exp_nonneg _) (hK s)) (hR t ht)
    · simp [K,compactKernel,hs,expWeight]
  have hi := (compactKernel_weighted (compactTail_continuous hc δ) δ (c/a)).mul_const (R t)
  have hh := integral_mono_of_nonneg
    (ae_of_all _ (fun s => mul_nonneg (hK s) (hRn (t-s)))) hi (ae_of_all _ hb)
  rw [integral_mul_const,compactKernel_moment _ hδ] at hh
  exact hh

-- @paper-step thm:n_construction/even_parity_actual_command_nonnegative
theorem even_resolvent_command_nonneg {J : ℝ → ℝ} (hc : Continuous J) {δ a c : ℝ}
    (hδ : 0≤δ) (ha : 0<a) (hn : ∀ t∈Icc (0 : ℝ) δ, 0≤J t) {R : ℝ → ℝ}
    (h : CompactResolventEvolution J δ a c (-1) R)
    (hR : ∀ t, 0≤t → 0≤R t)
    (hcond : compactExpMoment (compactTail J δ) δ (c/a)≤1-a) {t : ℝ} (ht : 0≤t) :
    0≤(1-a)*R t-(compactKernel (compactTail J δ) δ ⋆ causalize R) t := by
  have hb := even_resolvent_tail_bound hc hδ ha hn h hR ht
  have hh := mul_le_mul_of_nonneg_right hcond (hR t ht)
  linarith

-- @paper-step thm:n_construction/odd_parity_actual_command_nonnegative
theorem odd_resolvent_command_nonneg {J : ℝ → ℝ} {δ a : ℝ} (ha : a≤1)
    (hn : ∀ t∈Icc (0 : ℝ) δ, 0≤J t) {R : ℝ → ℝ}
    (hR : ∀ t, 0≤t → 0≤R t) {t : ℝ} (ht : 0≤t) :
    0≤(1-a)*R t+(compactKernel (compactTail J δ) δ ⋆ causalize R) t := by
  have hK : ∀ᵐ t, 0≤compactKernel (compactTail J δ) δ t := ae_of_all _
    (compactKernel_nonneg (fun t ht => compactTail_nonneg ht.1 ht.2 hn))
  have hRn : ∀ᵐ t, 0≤causalize R t := ae_of_all _ (fun s => by
    by_cases hs : 0≤s
    · simpa [causalize,hs] using hR s hs
    · simp [causalize,hs])
  exact add_nonneg (mul_nonneg (sub_nonneg.mpr ha) (hR t ht))
    (convolution_pointwise_nonneg hK hRn t)

/-- The exact parity test displayed in Theorem 17, in the n=N-2 convention. -/
def CascadeParityTest (J : ℝ → ℝ) (δ a ε : ℝ) : Prop :=
  (ε=1 ∧ ∃ l : ℝ, 0<l ∧ 1-compactMoment J δ 0+compactExpMoment J δ l≤a*l) ∨
  (ε= -1 ∧ compactExpMoment (compactTail J δ) δ
    ((1+compactMoment J δ 0)/a)≤1-a)

-- @paper-step thm:n_construction/both_parities_ordinary_inverse_and_command_sign
theorem cascade_ordinary_inverse_and_command {J : ℝ → ℝ} (hc : Continuous J)
    {δ a ε : ℝ} (hδ : 0≤δ) (ha : 0<a) (ha1 : a<1)
    (hn : ∀ t∈Icc (0 : ℝ) δ, 0≤J t) (hpar : CascadeParityTest J δ a ε) :
    ∃ R : ℝ → ℝ,
      CompactResolventEvolution J δ a (1-ε*compactMoment J δ 0) ε R ∧
      Integrable (causalize R) ∧
      (∃ η : ℝ, 0<η ∧ Integrable (expWeight η (causalize R))) ∧
      (∀ t, 0≤t → 0≤R t) ∧ (∫ t, R t ∂halfLine)=1 ∧
      (∀ p : ℝ, 0≤p → (a*p+(1-ε*compactMoment J δ 0)+
        ε*compactExpMoment J δ (-p))*laplace R p=1) ∧
      ∀ t, 0≤t → 0≤(1-a)*R t+
        ε*(compactKernel (compactTail J δ) δ ⋆ causalize R) t := by
  rcases hpar with ⟨he,l,hl,hcond⟩|⟨he,hcond⟩
  · subst ε
    obtain ⟨r,hrn,hrc,hrw,hrmass,hrT⟩ := oddCascade_resolvent hc hδ ha hl hn hcond
    obtain ⟨R,hR,heR⟩ := compact_resolvent_realization hc hδ ha r hrc
      (ε := 1) (fun p hp => by simpa using hrT p hp.le)
    have hRn := compact_resolvent_nonneg hR hrn heR
    refine ⟨R,by simpa using hR,(L1.integrable_coeFn r).congr heR,?_,hRn,?_,?_,?_⟩
    · obtain ⟨η,hη,hw⟩ := hrw
      exact ⟨η,hη,weighted_integrable_congr heR hw⟩
    · rw [← integral_congr_ae (representative_halfLine_ae heR),← causal_integral_halfLine hrc]
      exact hrmass
    · intro p hp
      rw [← laplace_congr_halfLine (representative_halfLine_ae heR)]
      simpa using hrT p hp
    · intro t ht
      simpa using odd_resolvent_command_nonneg ha1.le hn hRn ht
  · subst ε
    obtain ⟨r,hrn,hrc,hrw,hrmass,hrT⟩ := evenCascade_resolvent hc hδ ha hn
    obtain ⟨R,hR,heR⟩ := compact_resolvent_realization hc hδ ha r hrc
      (ε := -1) (fun p hp => by simpa [sub_eq_add_neg] using hrT p hp.le)
    have hRn := compact_resolvent_nonneg hR hrn heR
    refine ⟨R,by simpa using hR,(L1.integrable_coeFn r).congr heR,?_,hRn,?_,?_,?_⟩
    · obtain ⟨η,hη,hw⟩ := hrw
      exact ⟨η,hη,weighted_integrable_congr heR hw⟩
    · rw [← integral_congr_ae (representative_halfLine_ae heR),← causal_integral_halfLine hrc]
      exact hrmass
    · intro p hp
      rw [← laplace_congr_halfLine (representative_halfLine_ae heR)]
      simpa [sub_eq_add_neg] using hrT p hp
    · intro t ht
      simpa using even_resolvent_command_nonneg hc hδ ha hn hR hRn hcond ht

end MIACE
