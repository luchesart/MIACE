import MIACE.SignedRenewal

/-! Етап 11: обикновени представители на подписаната резолвента.
    Оценките се отнасят до зададената функция f, а не до произволен
    представител на нейния клас в L¹. Изборът на η зависи само от ядрото. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

noncomputable def signedRenewalRep {K f : ℝ → ℝ} (hK : Integrable K)
    (hf : Integrable (causalize f)) (t : ℝ) : ℝ :=
  f t + (K ⋆ ((∑' n : ℕ, (convOp hK)^n) (hf.toL1 (causalize f)) : RealL1)) t

-- @paper-step thm:pid_two_rate_optimum/signed_ordinary_identification
theorem signedRenewalRep_ae {K f : ℝ → ℝ} (hK : Integrable K)
    (hKc : Causal K) (hq : absArea K volume<1) (hf : Integrable (causalize f)) :
    ((∑' n : ℕ, (convOp hK)^n) (hf.toL1 (causalize f)) : RealL1) =ᵐ[volume]
      causalize (signedRenewalRep hK hf) := by
  have hgc := causal_congr (causalize_causal f) hf.coeFn_toL1.symm
  exact renewal_representative_ae hK hKc hf
    (causal_renewal_series hK hKc ((convOp_norm hK).trans_lt hq) hgc)
    (signed_renewal_l1 hK hq _).2.1

-- @paper-step thm:pid_two_rate_optimum/signed_ordinary_integral_equation
theorem signedRenewalRep_equation {K f : ℝ → ℝ} (hK : Integrable K)
    (hKc : Causal K) (hq : absArea K volume<1) (hf : Integrable (causalize f))
    {t : ℝ} (ht : 0≤t) :
    signedRenewalRep hK hf t = f t +
      ∫ s in 0..t, K (t-s)*signedRenewalRep hK hf s := by
  have hc := convolution_congr (ContinuousLinearMap.lsmul ℝ ℝ)
    (EventuallyEq.rfl (f := K)) (signedRenewalRep_ae hK hKc hq hf)
  change f t + (K ⋆ _) t = _
  rw [hc,causal_convolution_interval hKc (causalize_causal _) ht]
  congr 1
  apply intervalIntegral.integral_congr
  intro s hs
  rw [uIcc_of_le ht] at hs
  simp [causalize,hs.1]

-- @paper-step thm:pid_two_rate_optimum/signed_ordinary_initial_value
theorem signedRenewalRep_initial {K f : ℝ → ℝ} (hK : Integrable K)
    (hKc : Causal K) (hq : absArea K volume<1) (hf : Integrable (causalize f)) :
    signedRenewalRep hK hf 0=f 0 := by
  simpa using signedRenewalRep_equation hK hKc hq hf (t := 0) le_rfl

-- @paper-step thm:pid_two_rate_optimum/signed_ordinary_weighted_norm
theorem signedRenewalRep_weighted {K f : ℝ → ℝ} (hK : Integrable K)
    (hKc : Causal K) (hq : absArea K volume<1) (hf : Integrable (causalize f))
    {η : ℝ} (hη : 0≤η) (hKw : Integrable (expWeight η K))
    (hqw : absArea (expWeight η K) volume<1)
    (hfw : Integrable (expWeight η (causalize f))) :
    Integrable (expWeight η (causalize (signedRenewalRep hK hf))) ∧
      (∫ t, |expWeight η (causalize (signedRenewalRep hK hf)) t|) ≤
        (∫ t, |expWeight η (causalize f) t|)/(1-absArea (expWeight η K) volume) := by
  let g := hf.toL1 (causalize f)
  have hgc := causal_congr (causalize_causal f) hf.coeFn_toL1.symm
  have hgw := expWeight_toL1_integrable hf hfw
  obtain ⟨_,hz,_,hn⟩ := signed_renewal_weighted hK hKc hq hη hKw hqw g hgc hgw
  have he : expWeight η ((∑' n : ℕ, (convOp hK)^n) g) =ᵐ[volume]
      expWeight η (causalize (signedRenewalRep hK hf)) := by
    filter_upwards [signedRenewalRep_ae hK hKc hq hf] with t ht
    simp only [expWeight,ht,g]
  have hg : expWeight η g =ᵐ[volume] expWeight η (causalize f) := by
    filter_upwards [hf.coeFn_toL1] with t ht
    simp only [expWeight,g,ht]
  refine ⟨hz.congr he,?_⟩
  have heint := integral_congr_ae (he.fun_comp abs)
  have hgint := integral_congr_ae (hg.fun_comp abs)
  simp only [Function.comp_def] at heint hgint
  rw [heint,hgint] at hn
  exact hn

-- @paper-step thm:pid_two_rate_optimum/signed_ordinary_pointwise_bound
theorem signedRenewalRep_decay {K f : ℝ → ℝ} (hK : Integrable K)
    (hKc : Causal K) (hq : absArea K volume<1) (hf : Integrable (causalize f))
    {η C B : ℝ} (hη : 0≤η) (hKw : Integrable (expWeight η K))
    (hqw : absArea (expWeight η K) volume<1) (hC : 0≤C)
    (hKb : ∀ t, |expWeight η K t|≤C)
    (hfw : Integrable (expWeight η (causalize f)))
    (hfb : ∀ t, 0≤t → |f t|≤B*Real.exp (-η*t)) {t : ℝ} (ht : 0≤t) :
    |signedRenewalRep hK hf t|≤
      (B+C*((∫ s, |expWeight η (causalize f) s|)/
        (1-absArea (expWeight η K) volume)))*Real.exp (-η*t) := by
  obtain ⟨hw,hn⟩ := signedRenewalRep_weighted hK hKc hq hf hη hKw hqw hfw
  have hc := convolution_weighted_pointwise_bound hC hKb hw t
  have he := convolution_congr (ContinuousLinearMap.lsmul ℝ ℝ)
    (EventuallyEq.rfl (f := K)) (signedRenewalRep_ae hK hKc hq hf)
  have ha := abs_add_le (f t) ((K ⋆ causalize (signedRenewalRep hK hf)) t)
  have hm := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hn hC)
    (Real.exp_nonneg (-η*t))
  have hb := hfb t ht
  unfold signedRenewalRep
  rw [he]
  nlinarith

-- @paper-step thm:pid_two_rate_optimum/two_rate_common_signed_kernel_certificate
theorem twoRate_signed_kernel {i ρ ell l m δ : ℝ} (h : TwoRateData i ρ ell l m δ) :
    let K := twoRateK (twoRateA ρ l m) l m δ
    absArea K volume<1 ∧ ∃ η C : ℝ, 0<η ∧ η≤1/2 ∧ 0≤C ∧
      Integrable (expWeight η K) ∧ absArea (expWeight η K) volume<1 ∧
      ∀ t, |expWeight η K t|≤C := by
  dsimp only
  let A := twoRateA ρ l m
  have hA := twoRateA_ge_one h.ordered_rates h.filter_lower
  have hn : ∀ᵐ t, 0≤twoRateK A l m δ t := ae_of_all _
    (twoRateK_nonneg hA h.lower_rate h.ordered_rates.le
      (twoRate_rate_condition h.ordered_rates h.filter_upper))
  have hq := twoRateK_small hA h.ordered_rates.le h.delay_nonneg
  refine ⟨by rw [positive_kernel_mass hn]; exact hq,?_⟩
  obtain ⟨η,hη,hle,hw,hqw⟩ := expWeight_small_mass (twoRateK_integrable A l m δ) hq
    (by norm_num : (0 : ℝ)<1/2) (twoRateK_weighted A l m δ (1/2))
  obtain ⟨C,hC,hb⟩ := twoRateK_weighted_bound A l m δ η
  refine ⟨η,C,hη,hle,hC,hw,?_,hb⟩
  rw [positive_kernel_mass (show ∀ᵐ t, 0≤expWeight η (twoRateK A l m δ) t from by
    filter_upwards [hn] with t ht; exact mul_nonneg (Real.exp_nonneg _) ht)]
  exact hqw

-- @paper-step thm:pid_two_rate_optimum/signed_two_rate_ordinary_regularity
theorem twoRate_signed_regularity {f : ℝ → ℝ} (hf : Integrable (causalize f))
    (hfc : Continuous f) (A l m : ℝ) {δ : ℝ} (hδ : 0≤δ) :
    Continuous (signedRenewalRep (twoRateK_integrable A l m δ) hf) := by
  exact hfc.add (twoRateK_convolution_continuous (L1.integrable_coeFn _) A l m hδ)

end MIACE
