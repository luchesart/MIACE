import MIACE.Stability
import MIACE.Pareto

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

/-! Canonical PI impulse states. Stability and all energies are derived; they
are not fields of this structure. The transfer/physical realization bridge is
kept explicit in the map instead of silently identifying arbitrary signals. -/
structure CanonicalImpulse (a b c : ℝ) (z w : ℝ → ℝ) : Prop where
  ac_z : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval z 0 T
  ac_w : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval w 0 T
  ode_z : ∀ᵐ t : ℝ, 0 < t → deriv z t = w t
  ode_w : ∀ᵐ t : ℝ, 0 < t → deriv w t = -(c/a)*z t-(b/a)*w t
  initial_z : z 0 = 0
  initial_w : w 0 = 1/a

-- @paper-step lem:h2/stable_canonical_model
theorem canonical_impulse_settles {a b c : ℝ} {z w : ℝ → ℝ}
    (h : CanonicalImpulse a b c z w) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) :
    SecondOrderImpulse a b c z w := by
  obtain ⟨hz,hw⟩ := canonical_settles ha hb hc h.ac_z h.ac_w h.ode_z h.ode_w
  exact ⟨h.ac_z,h.ac_w,h.ode_z,h.ode_w,h.initial_z,h.initial_w,hz,hw⟩

-- @paper-step prop:energies/canonical_pi_law
theorem canonical_pi_integral_law {x r : ℝ} {z w : ℝ → ℝ}
    (h : CanonicalImpulse r (r*(1+x)) x z w) (hr : 0 < r)
    (T : ℝ) (hT : 0 ≤ T) :
    1+((x-r)*z T+(r*(x-1))*w T) =
      x*(r*z T+r*w T)+(x/r)*(∫ t in 0..T, r*z t+r*w t) := by
  let f : ℝ → ℝ := fun t => ((x-r)*z t+(r*(x-1))*w t)-x*(r*z t+r*w t)
  have hz := h.ac_z T hT
  have hw := h.ac_w T hT
  have hf : AbsolutelyContinuousOnInterval f 0 T :=
    ((hz.const_mul (x-r)).add (hw.const_mul (r*(x-1)))).sub
      (((hz.const_mul r).add (hw.const_mul r)).const_mul x)
  have hi := hf.integral_deriv_eq_sub
  have heq : (∫ t in 0..T, deriv f t) = (x/r)*(∫ t in 0..T, r*z t+r*w t) := by
    rw [← intervalIntegral.integral_const_mul]
    apply intervalIntegral.integral_congr_ae
    filter_upwards [hz.ae_differentiableAt,hw.ae_differentiableAt,h.ode_z,h.ode_w]
      with t hzt hwt hzo hwo ht
    have hmem := uIoc_subset_uIcc ht
    rw [uIoc_of_le hT] at ht
    have hdz := (hzt hmem).hasDerivAt
    have hdw := (hwt hmem).hasDerivAt
    rw [hzo ht.1] at hdz
    rw [hwo ht.1] at hdw
    have hd := ((hdz.const_mul (x-r)).add (hdw.const_mul (r*(x-1)))).sub
      (((hdz.const_mul r).add (hdw.const_mul r)).const_mul x)
    change HasDerivAt f _ t at hd
    rw [hd.deriv]
    field_simp
    <;> ring
  rw [heq] at hi
  have hf0 : f 0 = -1 := by
    dsimp [f]
    rw [h.initial_z,h.initial_w]
    field_simp
    <;> ring
  rw [hf0] at hi
  dsimp [f] at hi
  linarith

-- @paper-step prop:energies/canonical_energy_without_decay_assumption
theorem canonical_pi_energies {x r : ℝ} {z w : ℝ → ℝ}
    (h : CanonicalImpulse r (r*(1+x)) x z w) (hx : 0 < x) (hr : 0 < r) :
    (Integrable (fun t => (r*z t+r*w t)^2) halfLine ∧
      (∫ t, (r*z t+r*w t)^2 ∂halfLine) = tracking x r) ∧
    (Integrable (fun t => ((x-r)*z t+(r*(x-1))*w t)^2) halfLine ∧
      (∫ t, ((x-r)*z t+(r*(x-1))*w t)^2 ∂halfLine) = effort x r) :=
  pi_signal_energies hx hr (canonical_impulse_settles h hr (by positivity) hx)

-- @paper-step thm:global/actual_signal_sos
theorem canonical_pi_global_gap {x r q s : ℝ} {z w : ℝ → ℝ}
    (h : CanonicalImpulse r (r*(1+x)) x z w) (hx : 0 < x) (hr : 0 < r)
    (hs : s^2 = 1+q) :
    q*(∫ t, (r*z t+r*w t)^2 ∂halfLine)+
      (∫ t, ((x-r)*z t+(r*(x-1))*w t)^2 ∂halfLine)-(s-1) =
      (s*r-x)^2/(2*r*x*(1+x))+(x-s)^2/(2*(1+x)) := by
  obtain ⟨he,hu⟩ := canonical_pi_energies h hx hr
  rw [he.2,hu.2]
  exact quadratic_gap q s x r hx hr hs

-- @paper-step thm:global/actual_signal_minimizer
theorem canonical_pi_global_optimum {x r q : ℝ} {z w : ℝ → ℝ}
    (h : CanonicalImpulse r (r*(1+x)) x z w) (hx : 0 < x) (hr : 0 < r) (hq : 0 < q) :
    Real.sqrt (1+q)-1 ≤ q*(∫ t, (r*z t+r*w t)^2 ∂halfLine)+
      (∫ t, ((x-r)*z t+(r*(x-1))*w t)^2 ∂halfLine) ∧
    (q*(∫ t, (r*z t+r*w t)^2 ∂halfLine)+
      (∫ t, ((x-r)*z t+(r*(x-1))*w t)^2 ∂halfLine) = Real.sqrt (1+q)-1 ↔
      x=Real.sqrt (1+q) ∧ r=1) := by
  obtain ⟨he,hu⟩ := canonical_pi_energies h hx hr
  rw [he.2,hu.2]
  exact ⟨quadratic_lower_bound q _ x r hx hr (Real.sq_sqrt (by linarith)),
    quadratic_sqrt_optimum q x r hq hx hr⟩
end MIACE
