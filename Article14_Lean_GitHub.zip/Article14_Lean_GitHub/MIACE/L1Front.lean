import MIACE.MonotonePI
import Mathlib.MeasureTheory.Measure.OpenPos

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:miace/ae_sign_to_pointwise
theorem local_ac_nonnegative {f : ℝ → ℝ}
    (hac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval f 0 T)
    (hae : ∀ᵐ t ∂halfLine, 0 ≤ f t) : ∀ t : ℝ, 0 ≤ t → 0 ≤ f t := by
  have hc := local_ac_continuous hac
  have heq : (fun t => max (f t) 0) =ᵐ[halfLine] f := by
    filter_upwards [hae] with t ht
    exact max_eq_left ht
  have hh := MeasureTheory.Measure.eqOn_open_of_ae_eq heq isOpen_Ioi
    (hc.sup continuousOn_const) hc
  have hpos : ∀ t : ℝ, 0 < t → 0 ≤ f t := by
    intro t ht
    have he := hh ht
    exact he ▸ le_max_right (f t) 0
  intro t ht
  rcases ht.eq_or_lt with heq | hgt
  · subst t
    have hc0 : ContinuousWithinAt f (Icc 0 1) 0 := by
      have hh : ContinuousOn f (Icc 0 1) := by
        simpa using (hac 1 (by norm_num)).continuousOn
      exact hh 0 (by norm_num)
    have htend : Tendsto (fun n : ℕ => (1:ℝ)/(n+1)) atTop (𝓝[Icc 0 1] (0:ℝ)) := by
      apply tendsto_nhdsWithin_iff.mpr
      refine ⟨tendsto_one_div_add_atTop_nhds_zero_nat,Eventually.of_forall ?_⟩
      intro n
      constructor
      · positivity
      · apply (div_le_iff₀ (by positivity : (0:ℝ)<n+1)).mpr
        nlinarith [Nat.cast_nonneg (α := ℝ) n]
    apply ge_of_tendsto (hc0.tendsto.comp htend)
    exact Eventually.of_forall (fun n => hpos _ (by positivity))
  · exact hpos t hgt

-- @paper-step thm:miace/appendix_b_rigidity
theorem pi_sign_rigidity {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r)
    (he : ∀ᵐ t ∂halfLine, 0 ≤ e t)
    (hv : ∀ᵐ t ∂halfLine, 0 ≤ x*e t+i t) : r=1 ∧ 1≤x := by
  have hept := local_ac_nonnegative h.ac_e he
  have hvpt := local_ac_nonnegative (fun T hT => ((h.ac_e T hT).const_mul x).add (h.ac_i T hT)) hv
  change ∀ t : ℝ, 0 ≤ t → 0 ≤ x*e t+i t at hvpt
  have hx1 : 1 ≤ x := by
    have hh := hvpt 0 le_rfl
    simp only [h.initial_e,h.initial_i,mul_one] at hh
    linarith
  have hd := (pi_nonovershoot_iff h hx hr).mp hept
  have hr1 : 1 ≤ r := by
    unfold MonotoneDomain at hd
    split_ifs at hd with hxle
    · have hxeq : x=1 := le_antisymm hxle hx1
      norm_num [hxeq] at hd
      exact hd
    · exact hd
  refine ⟨?_,hx1⟩
  by_contra hne
  have hrg : 1 < r := lt_of_le_of_ne hr1 (Ne.symm hne)
  let l := (1+x-Real.sqrt ((1+x)^2-4*x/r))/2
  let m := (1+x+Real.sqrt ((1+x)^2-4*x/r))/2
  obtain ⟨hl,hlm,hs,hp⟩ := real_root_identities hx hr (domain_discriminant hx hr hd)
  change 0 < l at hl
  change l ≤ m at hlm
  change l+m=1+x at hs
  change l*m=x/r at hp
  have hl1 := (real_root_domain hx hr hlm hs hp).mpr hd
  have hp1 : l*m < x := by rw [hp]; exact (div_lt_iff₀ hr).mpr (by nlinarith)
  have hll : l < 1 := by
    by_contra hn
    have hh : l=1 := le_antisymm hl1 (le_of_not_gt hn)
    rw [hh] at hs hp1
    nlinarith
  have hmm : 1 < m := by
    by_contra hn
    have hmn : m ≤ 1 := le_of_not_gt hn
    nlinarith [mul_nonneg (sub_nonneg.mpr hl1) (sub_nonneg.mpr hmn)]
  have hlt : l < m := hll.trans hmm
  let A := (1-l)/(m-l)
  let B := (m-1)/(m-l)
  have hA : 0 < A := div_pos (sub_pos.mpr hll) (sub_pos.mpr hlt)
  have hC : (l-1)*A < 0 := mul_neg_of_neg_of_pos (by linarith) hA
  have hev := real_modes_eventually_negative (B := (m-1)*B) hlt hC
  obtain ⟨t,htneg,ht⟩ := (hev.and (eventually_ge_atTop (0:ℝ))).exists
  obtain ⟨hee,hii⟩ := pi_state_unique h (distinct_mode_response x r l m hlt hs hp) hx hr t ht
  have hvform : x*e t+i t = realModeError l m ((l-1)*A) ((m-1)*B) t := by
    rw [hee,hii]
    change x*realModeError l m A B t+realModeIntegral l m A B t = _
    unfold realModeError realModeIntegral
    linear_combination (A*expError l t+B*expError m t)*hs
  have hvn := hvpt t ht
  rw [hvform] at hvn
  linarith

-- @paper-step thm:miace/cancellation_actual_areas
theorem pi_cancellation_areas {x : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x 1 e i) (hx : 1 ≤ x) :
    absArea e halfLine=1/x ∧ absArea (fun t => x*e t+i t) halfLine=1-1/x := by
  have hx0 : 0 < x := by linarith
  have hp := pi_cancellation_signals h hx0
  have heq : absArea e halfLine=absArea (expError x) halfLine := by
    apply integral_congr_ae
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    rw [(hp t ht.le).1]
  have huq : absArea (fun t => x*e t+i t) halfLine=absArea (expCommand x) halfLine := by
    apply integral_congr_ae
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    rw [(hp t ht.le).2]
  rw [heq,huq,(exponential_areas x hx).1,(exponential_areas x hx).2]
  refine ⟨rfl,?_⟩
  field_simp

-- @paper-step thm:miace/front_equality_classification
theorem pi_area_front_iff {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r) :
    absArea e halfLine+absArea (fun t => x*e t+i t) halfLine=1 ↔ r=1 ∧ 1≤x := by
  have hf := pi_state_response h hx hr
  have hb := area_balance hf.error_integrable hf.command_integrable 1 (response_signed_balance hf)
  constructor
  · intro heq
    have hN := negative_area_nonneg (μ := halfLine) e
    have hM := negative_area_nonneg (μ := halfLine) (fun t => x*e t+i t)
    apply pi_sign_rigidity h hx hr
    · exact (negative_area_zero_iff hf.error_integrable).mp (by linarith)
    · exact (negative_area_zero_iff hf.command_integrable).mp (by linarith)
  · rintro ⟨rfl,hx1⟩
    have ha := pi_cancellation_areas h hx1
    rw [ha.1,ha.2]
    ring

-- @paper-step thm:miace/actual_area_lower_bounds
theorem pi_area_bounds {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r) :
    r/x ≤ absArea e halfLine ∧ 1-r/x ≤ absArea (fun t => x*e t+i t) halfLine ∧
    0 ≤ absArea (fun t => x*e t+i t) halfLine ∧
    1 ≤ absArea e halfLine+absArea (fun t => x*e t+i t) halfLine := by
  have hf := pi_state_response h hx hr
  have hs := pi_state_signed_areas h hx hr
  have he : (∫ t, e t ∂halfLine) ≤ absArea e halfLine :=
    integral_mono hf.error_integrable hf.error_integrable.abs (fun t => le_abs_self _)
  have hu : (∫ t, (x*e t+i t) ∂halfLine) ≤ absArea (fun t => x*e t+i t) halfLine :=
    integral_mono hf.command_integrable hf.command_integrable.abs (fun t => le_abs_self _)
  rw [hs.1] at he
  rw [hs.2] at hu
  exact ⟨he,hu,integral_nonneg (fun t => abs_nonneg _),by linarith⟩

def L1Efficient (e v : ℝ → ℝ) : Prop :=
  ∀ y s : ℝ, ∀ f j : ℝ → ℝ, 0 < y → 0 < s → PIStateResponse y s f j →
    absArea f halfLine ≤ absArea e halfLine →
    absArea (fun t => y*f t+j t) halfLine ≤ absArea v halfLine →
    absArea f halfLine=absArea e halfLine ∧
    absArea (fun t => y*f t+j t) halfLine=absArea v halfLine

-- @paper-step thm:miace/complete_l1_efficiency
theorem l1_efficient_iff {x r : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r) :
    L1Efficient e (fun t => x*e t+i t) ↔ r=1 ∧ 1≤x := by
  obtain ⟨he,hu,hu0,hb⟩ := pi_area_bounds h hx hr
  constructor
  · intro hh
    apply (pi_area_front_iff h hx hr).mp
    by_cases hz : r/x ≤ 1
    · have hg : 1 ≤ x/r := by
        have hrx : r ≤ x := (div_le_one hx).mp hz
        exact (one_le_div hr).mpr hrx
      have hg0 : 0 < x/r := div_pos hx hr
      have hm := exponential_pi_state (x/r)
      have ha := pi_cancellation_areas hm hg
      have hdiv : 1/(x/r)=r/x := by field_simp
      rw [hdiv] at ha
      have hs := hh (x/r) 1 _ _ hg0 zero_lt_one hm
      rw [ha.1,ha.2] at hs
      obtain ⟨hE,hU⟩ := hs he hu
      linarith
    · have ha := pi_cancellation_areas (exponential_pi_state 1) le_rfl
      simp only [div_one,sub_self] at ha
      have hs := hh 1 1 _ _ zero_lt_one zero_lt_one (exponential_pi_state 1)
      rw [ha.1,ha.2] at hs
      have hrx : 1 < r/x := lt_of_not_ge hz
      have hE := (hs (by linarith) hu0).1
      linarith
  · intro hf y s f j hy hs hj hE hU
    have hfront := (pi_area_front_iff h hx hr).mpr hf
    have hother := (pi_area_bounds hj hy hs).2.2.2
    exact ⟨by linarith,by linarith⟩

-- @paper-step thm:miace/entire_l1_front_realization
theorem l1_front_realization (x : ℝ) (hx : 1 ≤ x) :
    ∃ e i : ℝ → ℝ, PIStateResponse x 1 e i ∧ L1Efficient e (fun t => x*e t+i t) ∧
      absArea e halfLine=1/x ∧ absArea (fun t => x*e t+i t) halfLine=1-1/x := by
  have hx0 : 0 < x := by linarith
  have h := exponential_pi_state x
  exact ⟨_,_,h,(l1_efficient_iff h hx0 zero_lt_one).mpr ⟨rfl,hx⟩,pi_cancellation_areas h hx⟩

-- @paper-step thm:miace/unique_miace_minimizer
theorem pi_miace_equality_iff {x r α : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r) (hα : 0 < α) :
    miace α e (fun t => x*e t+i t) halfLine=minimum α ↔ x=1+1/α ∧ r=1 := by
  rw [response_miace_equality_iff (pi_state_response h hx hr) α hα]
  constructor
  · rintro ⟨he,hv,ha⟩
    obtain ⟨hr1,hx1⟩ := pi_sign_rigidity h hx hr he hv
    subst r
    have harea := pi_cancellation_areas h hx1
    rw [harea.1,harea.2] at ha
    refine ⟨?_,rfl⟩
    field_simp at ha ⊢
    nlinarith
  · rintro ⟨rfl,rfl⟩
    have hx1 : 1 ≤ 1+1/α := by
      have hh : 0 < 1/α := by positivity
      linarith
    have ha := pi_cancellation_areas h hx1
    have hp := pi_cancellation_signals h hx
    refine ⟨?_,?_,?_⟩
    · filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
      rw [(hp t ht.le).1]
      exact Real.exp_nonneg _
    · filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
      rw [(hp t ht.le).2]
      unfold expCommand
      exact mul_nonneg (by linarith) (Real.exp_nonneg _)
    · rw [ha.1,ha.2]
      field_simp
      <;> ring

-- @paper-step thm:miace/full_statement
theorem paper_miace {x r α : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r) (hα : 0 < α) :
    (L1Efficient e (fun t => x*e t+i t) ↔ r=1 ∧ 1≤x) ∧
    (r=1 → 1≤x → absArea e halfLine=1/x ∧ absArea (fun t => x*e t+i t) halfLine=1-1/x) ∧
    minimum α ≤ miace α e (fun t => x*e t+i t) halfLine ∧
    (miace α e (fun t => x*e t+i t) halfLine=minimum α ↔ x=1+1/α ∧ r=1) ∧
    (minimum α)^2=α/(1+α) ∧
    (∃ E I : ℝ → ℝ, PIStateResponse (1+1/α) 1 E I ∧
      miace α E (fun t => (1+1/α)*E t+I t) halfLine=minimum α) ∧
    (∀ g : ℝ, 1 ≤ g → ∃ E I : ℝ → ℝ, PIStateResponse g 1 E I ∧
      L1Efficient E (fun t => g*E t+I t) ∧ absArea E halfLine=1/g ∧
      absArea (fun t => g*E t+I t) halfLine=1-1/g) := by
  refine ⟨l1_efficient_iff h hx hr,?_,response_miace_lower_bound (pi_state_response h hx hr) α hα,
    pi_miace_equality_iff h hx hr hα,?_,?_,l1_front_realization⟩
  · rintro rfl hx1
    exact pi_cancellation_areas h hx1
  · unfold minimum
    exact Real.sq_sqrt (by positivity)
  · have hg : 0 < 1+1/α := by positivity
    have hm := exponential_pi_state (1+1/α)
    exact ⟨_,_,hm,(pi_miace_equality_iff hm hg zero_lt_one hα).mpr ⟨rfl,rfl⟩⟩
end MIACE
