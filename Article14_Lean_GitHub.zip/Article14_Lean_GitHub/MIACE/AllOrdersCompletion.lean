import MIACE.EqualCascadeMoments

/-! Stage 19. A single proof for every natural n=N-2 and every delay in
[0,1/4]. Both parity tests use the proven moments of the actual kernel. -/
namespace MIACE
open MeasureTheory Filter Set Polynomial
open scoped Topology

-- @paper-step thm:n_all_orders/equal_lag_factor_polynomial
theorem equal_remainderB (n : ℕ) : remainderB (fun _ => 1) n=(X+1 : ℝ[X])^(n+1) := by
  induction n with
  | zero => simp [remainderB]
  | succ n ih => simp [remainderB,ih,pow_succ]

-- @paper-step thm:n_all_orders/explicit_Taylor_interpolant_polynomial
theorem equal_remainderI (n : ℕ) (δ : ℝ) :
    remainderI (fun _ => 1) δ n =
      ∑ j∈Finset.range (n+1), C (Real.exp δ*(-δ)^j/(j.factorial : ℝ))*(X+1)^j := by
  induction n with
  | zero => simp [remainderI]
  | succ n ih =>
    rw [remainderI,ih,Finset.sum_range_succ,equal_reverseImpulse,equal_remainderB]
    have hc : (-1 : ℝ)^(n+1)*(Real.exp δ*δ^(n+1)/(↑(n+1).factorial))/1=
        Real.exp δ*(-δ)^(n+1)/(↑(n+1).factorial) := by
      rw [div_one,neg_pow]
      ring
    rw [hc]
    simp only [Finset.sum_range_succ]

-- @paper-step thm:n_all_orders/nonvanishing_denominator_at_the_only_plant_root
theorem equal_Q_minus_one (n : ℕ) (δ U : ℝ) :
    (rationalCascadeQ (fun _ => 1) n δ U).eval (-1)= -Real.exp δ := by
  have hB : (remainderB (fun _ => 1) n).eval (-1)=0 := by simp [equal_remainderB]
  have hI := exact_delay_remainder_real (fun _ => 1) n δ (-1) (fun _ _ => one_ne_zero)
  simp only [hB,mul_zero,zero_mul,add_zero] at hI
  simp only [rationalCascadeQ,eval_sub,eval_mul,hB,zero_mul,zero_sub]
  congr 1
  simpa using hI.symm

-- @paper-step thm:n_all_orders/uniform_even_and_odd_parity_conditions
theorem equal_uniform_conditions (n : ℕ) {δ : ℝ} (hδ : 0≤δ) (hδ1 : δ≤1/4) :
    let U := ((n : ℝ)+2+δ)/(2*((n : ℝ)+2))
    0<rationalCascadeA (fun _ => 1) n δ U ∧
    rationalCascadeA (fun _ => 1) n δ U<1 ∧
    CascadeParityTest (remainderJ (fun _ => 1) n δ) δ
      (rationalCascadeA (fun _ => 1) n δ U) ((-1 : ℝ)^(n+1)) := by
  let N : ℝ := (n : ℝ)+2
  let U : ℝ := (N+δ)/(2*N)
  let J := remainderJ (fun _ => 1) n δ
  let j0 := compactMoment J δ 0
  let j1 := compactMoment J δ 1
  have hN : 2≤N := by dsimp [N]; have := Nat.cast_nonneg (α := ℝ) n; linarith
  have hNp : 0<N := by linarith
  have hU0 : 1/2≤U := by dsimp [U]; apply (le_div_iff₀ (by positivity)).mpr; linarith
  have hU1 : U≤9/16 := by dsimp [U]; apply (div_le_iff₀ (by positivity)).mpr; nlinarith
  obtain ⟨hj00,hj0,hj10,hj1⟩ := equal_uniform_moments n hδ hδ1
  change 0≤j0 at hj00
  change j0≤1/3 at hj0
  change 0≤j1 at hj10
  change j1≤1/24 at hj1
  change 0<1-U+(-1 : ℝ)^(n+1)*j1 ∧ 1-U+(-1 : ℝ)^(n+1)*j1<1 ∧
    CascadeParityTest J δ (1-U+(-1 : ℝ)^(n+1)*j1) ((-1 : ℝ)^(n+1))
  rcases neg_one_pow_eq_or ℝ (n+1) with he|he
  · have hn : 1≤n := by
      by_contra hh
      have hz : n=0 := by omega
      subst n; norm_num at he
    have hN3 : 3≤N := by dsimp [N]; exact_mod_cast (show 3≤n+2 by omega)
    have hU2 : U≤13/24 := by dsimp [U]; apply (div_le_iff₀ (by positivity)).mpr; nlinarith
    have hj02 : j0≤1/24 := equal_uniform_moment_odd hn hδ hδ1
    rw [he,one_mul]
    have ha : 11/24≤1-U+j1 := by linarith
    have ha1 : 1-U+j1≤13/24 := by linarith
    refine ⟨by linarith,by linarith,Or.inl ⟨rfl,3,by norm_num,?_⟩⟩
    have hb := compactExpMoment_bound (remainderJ_continuous (fun _ => 1) n δ) hδ
      (by norm_num : (0 : ℝ)≤3) (fun t ht => remainderJ_nonneg (fun _ => 1) n (by intros; norm_num) ht.2)
    have hex : Real.exp (3*δ)≤3 := (Real.exp_le_exp.mpr (by linarith : 3*δ≤1)).trans uniform_exp_bounds.2.le
    have hm := mul_le_mul_of_nonneg_right hex hj00
    change compactExpMoment J δ 3≤Real.exp (3*δ)*j0 at hb
    nlinarith
  · rw [he,neg_one_mul]
    have ha : 19/48≤1-U+-j1 := by linarith
    have ha1 : 1-U+-j1≤1/2 := by linarith
    have hap : 0<1-U+-j1 := by linarith
    refine ⟨hap,by linarith,Or.inr ⟨rfl,?_⟩⟩
    let γ := (1+j0)/(1-U+-j1)
    have hγ : 0≤γ := div_nonneg (by linarith) hap.le
    have hγ1 : γ≤64/19 := by dsimp [γ]; apply (div_le_iff₀ hap).mpr; linarith
    have hγδ : γ*δ≤1 := by nlinarith [mul_le_mul_of_nonneg_right hγ1 hδ]
    have hex : Real.exp (γ*δ)≤3 := (Real.exp_le_exp.mpr hγδ).trans uniform_exp_bounds.2.le
    have hb := compactTail_exp_bound (remainderJ_continuous (fun _ => 1) n δ) hδ hγ
      (fun t ht => remainderJ_nonneg (fun _ => 1) n (by intros; norm_num) ht.2)
    have hm := mul_le_mul_of_nonneg_right hex hj10
    change compactExpMoment (compactTail J δ) δ γ≤Real.exp (γ*δ)*j1 at hb
    change compactExpMoment (compactTail J δ) δ γ≤1-(1-U+-j1)
    nlinarith

-- @paper-step thm:n_all_orders/complete_uniform_attainment_and_minimal_order
theorem paper_all_orders_attainment (n : ℕ) {δ : ℝ} (hδ : 0≤δ) (hδ1 : δ≤1/4) :
    CascadeMinimalOrder (fun _ => 1) n δ (((n : ℝ)+2+δ)/(2*((n : ℝ)+2))) ∧
    CascadeAttainment (fun _ => 1) n δ (2*((n : ℝ)+2)-1) := by
  obtain ⟨ha,ha1,hpar⟩ := equal_uniform_conditions n hδ hδ1
  have he : (1+(∑ j∈Finset.range (n+1), 1/(1 : ℝ))+δ)/(1+(2*((n : ℝ)+2)-1))=
      ((n : ℝ)+2+δ)/(2*((n : ℝ)+2)) := by simp; ring
  refine ⟨rationalCascade_minimal_order (fun _ => 1) n δ _ (by intros; norm_num)
    (ne_of_gt ha) ?_,?_⟩
  · rw [equal_Q_minus_one]; exact neg_ne_zero.mpr (Real.exp_ne_zero _)
  · apply cascadeAttainment_of_conditions (fun _ => 1) n (by intros; norm_num) hδ
      (by have := Nat.cast_nonneg (α := ℝ) n; linarith : (0 : ℝ)<2*((n : ℝ)+2)-1)
    · simpa only [he] using ha
    · simpa only [he] using ha1
    · simpa only [he] using hpar

end MIACE
