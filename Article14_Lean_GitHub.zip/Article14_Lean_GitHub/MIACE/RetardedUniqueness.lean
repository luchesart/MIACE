import MIACE.PIDHistoryReduction

/-! Етап 12: единственост на ретардираното интегрално уравнение.
    Оценката е върху произволен краен интервал; не се предполага
    експоненциален порядък или интегруемост на конкурентното решение. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:pid_two_rate_optimum/retarded_integral_uniqueness
theorem retarded_integral_zero {f : ℝ → ℝ} (hf : Continuous f)
    {δ L T : ℝ} (hδ : 0≤δ) (hL : 0≤L) (hT : 0≤T)
    (hn : ∀ t∈Icc (0 : ℝ) T, 0≤f t)
    (hi : ∀ t∈Icc (0 : ℝ) T,
      f t≤L*(∫ s in 0..t, f s+f (max 0 (s-δ)))) :
    ∀ t∈Icc (0 : ℝ) T, f t=0 := by
  let p := 2*L+1
  have hp : 0<p := by dsimp [p]; linarith
  have hc : Continuous (fun t => Real.exp (-p*t)*f t) :=
    (by fun_prop : Continuous (fun t : ℝ => Real.exp (-p*t))).mul hf
  obtain ⟨u,hu,hum⟩ := isCompact_Icc.exists_isMaxOn (nonempty_Icc.mpr hT) hc.continuousOn
  let M := Real.exp (-p*u)*f u
  have hM : 0≤M := mul_nonneg (Real.exp_nonneg _) (hn u hu)
  have he (s : ℝ) : Real.exp (-p*s)*Real.exp (p*s)=1 := by
    rw [← Real.exp_add]; ring_nf; simp
  have hb (s : ℝ) (hs : s∈Icc (0 : ℝ) T) : f s≤M*Real.exp (p*s) := by
    have hh := mul_le_mul_of_nonneg_right (hum hs) (Real.exp_nonneg (p*s))
    change (Real.exp (-p*s)*f s)*Real.exp (p*s)≤M*Real.exp (p*s) at hh
    calc
      f s = (Real.exp (-p*s)*f s)*Real.exp (p*s) := by
        calc
          _ = (Real.exp (-p*s)*Real.exp (p*s))*f s := by rw [he s,one_mul]
          _ = _ := by ring
      _ ≤ _ := hh
  have hb' (s : ℝ) (hs : s∈Icc (0 : ℝ) u) :
      f s+f (max 0 (s-δ))≤2*M*Real.exp (p*s) := by
    have hsT : s∈Icc (0 : ℝ) T := ⟨hs.1,hs.2.trans hu.2⟩
    have hmax : max 0 (s-δ)≤s := max_le hs.1 (by linarith)
    have hmaxT : max 0 (s-δ)∈Icc (0 : ℝ) T :=
      ⟨le_max_left _ _,hmax.trans hsT.2⟩
    have hh := (hb _ hmaxT).trans
      (mul_le_mul_of_nonneg_left (Real.exp_le_exp.mpr
        (mul_le_mul_of_nonneg_left hmax hp.le)) hM)
    linarith [hb s hsT]
  have hbint := intervalIntegral.integral_mono_on hu.1
    ((hf.add (hf.comp (continuous_const.max (continuous_id.sub continuous_const)))).intervalIntegrable (μ := volume) 0 u)
    ((by fun_prop : Continuous (fun s : ℝ => 2*M*Real.exp (p*s))).intervalIntegrable (μ := volume) 0 u) hb'
  rw [intervalIntegral.integral_const_mul] at hbint
  have hexp : (∫ s in 0..u, Real.exp (p*s))=(Real.exp (p*u)-1)/p := by
    have hh := finite_exp_integral (neg_ne_zero.mpr (ne_of_gt hp)) u
    simp only [neg_neg,div_neg] at hh
    rw [hh]
    ring
  rw [hexp] at hbint
  have huineq := (hi u hu).trans (mul_le_mul_of_nonneg_left hbint hL)
  have hmul := mul_le_mul_of_nonneg_right huineq hp.le
  have hden : (L*(2*M*((Real.exp (p*u)-1)/p)))*p=
      2*L*M*(Real.exp (p*u)-1) := by field_simp <;> ring
  rw [hden] at hmul
  have hval : f u=M*Real.exp (p*u) := by
    dsimp [M]
    calc
      _ = (Real.exp (-p*u)*Real.exp (p*u))*f u := by rw [he u,one_mul]
      _ = _ := by ring
  rw [hval] at hmul
  have hz : M=0 := by
    have hpos := Real.exp_pos (p*u)
    dsimp [p] at hmul
    nlinarith [mul_nonneg hL hM]
  intro t ht
  have hh := hb t ht
  rw [hz,zero_mul] at hh
  exact le_antisymm hh (hn t ht)

end MIACE
