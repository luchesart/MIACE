import MIACE.DelayedCommandEnergy

/-! Stage 19. Exact delayed quadratic cost and the nonstationarity of the
old delay-free gain, proved after identifying both actual signal energies. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def delayEnergyPsi (z : ℝ) : ℝ := (1+Real.sin z)/Real.cos z
noncomputable def delayedQuadratic (q δ x : ℝ) : ℝ :=
  (1/2)*(x+(q+1)/x)*delayEnergyPsi (x*δ)-δ-1

-- @paper-step prop:delayed_quadratic/energy_multiplier_derivative
theorem delayEnergyPsi_deriv {z : ℝ} (hz : Real.cos z≠0) :
    HasDerivAt delayEnergyPsi ((1+Real.sin z)/(Real.cos z)^2) z := by
  convert ((Real.hasDerivAt_sin z).const_add 1).div (Real.hasDerivAt_cos z) hz using 1
  · rfl
  · field_simp
    linear_combination -(Real.sin_sq_add_cos_sq z)

-- @paper-step prop:delayed_quadratic/exact_cost_of_actual_step_signals
theorem scalarDelay_quadratic_cost {x δ : ℝ} (hx : 0<x) (hδ : 0≤δ)
    (hb : x*δ<Real.pi/2) {E : ℝ → ℝ} (hE : ScalarDelayResponse x δ E) (q : ℝ) :
    q*(∫ t, (E t)^2 ∂halfLine)+(∫ t, (x*E t-E (t+δ))^2 ∂halfLine)=
      delayedQuadratic q δ x := by
  rw [scalarDelay_response_energy hx hδ hb hE,(scalarDelay_command_energy hx hδ hb hE).2]
  unfold delayedQuadratic delayEnergyPsi
  field_simp
  <;> ring

-- @paper-step prop:delayed_quadratic/old_optimum_has_strictly_positive_delayed_derivative
theorem delayedQuadratic_old_gain {q δ : ℝ} (hq : 0<q) (hδ : 0<δ)
    (hb : Real.sqrt (1+q)*δ<Real.pi/2) :
    let s := Real.sqrt (1+q)
    HasDerivAt (delayedQuadratic q δ)
      (s*δ*((1+Real.sin (s*δ))/(Real.cos (s*δ))^2)) s ∧
    0<s*δ*((1+Real.sin (s*δ))/(Real.cos (s*δ))^2) := by
  let s := Real.sqrt (1+q)
  have hs : 0<s := Real.sqrt_pos.mpr (by linarith)
  have hsq : s^2=1+q := Real.sq_sqrt (by linarith)
  have hc : 0<Real.cos (s*δ) := delay_cos_pos hb ⟨mul_nonneg hs.le hδ.le,le_rfl⟩
  have hsin : 0≤Real.sin (s*δ) := Real.sin_nonneg_of_nonneg_of_le_pi
    (mul_nonneg hs.le hδ.le) (by linarith [Real.pi_pos])
  have hd0 := (hasDerivAt_id s).add ((hasDerivAt_const s (q+1)).div (hasDerivAt_id s) (ne_of_gt hs))
  have hd1 : HasDerivAt (fun x : ℝ => x+(q+1)/x) 0 s := by
    convert hd0 using 1
    · rfl
    · dsimp only [id_eq]
      field_simp
      linarith
  have hd2 := (delayEnergyPsi_deriv (ne_of_gt hc)).comp s ((hasDerivAt_id s).mul_const δ)
  have hd := (((hd1.const_mul (1/2 : ℝ)).mul hd2).sub_const δ).sub_const 1
  refine ⟨?_,by positivity⟩
  convert hd using 1
  · rfl
  · simp only [id_eq,zero_mul,zero_add,one_mul]
    have hv : s+(q+1)/s=2*s := by field_simp; nlinarith
    rw [hv]
    ring

-- @paper-step prop:delayed_quadratic/paper_proposition_all_clauses
theorem paper_delayed_quadratic {x δ q : ℝ} (hx : 0<x) (hδ : 0≤δ) (hq : 0<q)
    (hb : x*δ<Real.pi/2) :
    (∃ E : ℝ → ℝ, ScalarDelayResponse x δ E) ∧
    (∀ E : ℝ → ℝ, ScalarDelayResponse x δ E →
      Integrable (fun t => (E t)^2) halfLine ∧
      Integrable (fun t => (x*E t-E (t+δ))^2) halfLine ∧
      (∫ t, (E t)^2 ∂halfLine)=delayEnergyPsi (x*δ)/(2*x) ∧
      (∫ t, (x*E t-E (t+δ))^2 ∂halfLine)=
        (x^2+1)*(delayEnergyPsi (x*δ)/(2*x))-δ-1 ∧
      q*(∫ t, (E t)^2 ∂halfLine)+(∫ t, (x*E t-E (t+δ))^2 ∂halfLine)=delayedQuadratic q δ x ∧
      (∀ t, 0≤t → x*E t-E (t+δ)=x*E t+x*(∫ s in (0 : ℝ)..t, E s)-1)) ∧
    (0<δ → Real.sqrt (1+q)*δ<Real.pi/2 →
      let s := Real.sqrt (1+q)
      HasDerivAt (delayedQuadratic q δ)
        (s*δ*((1+Real.sin (s*δ))/(Real.cos (s*δ))^2)) s ∧
      0<s*δ*((1+Real.sin (s*δ))/(Real.cos (s*δ))^2)) := by
  refine ⟨scalarDelay_response_exists hx hδ,?_,fun hd hs => delayedQuadratic_old_gain hq hd hs⟩
  intro E hE
  have he : (1+Real.sin (x*δ))/(2*x*Real.cos (x*δ))=delayEnergyPsi (x*δ)/(2*x) := by
    unfold delayEnergyPsi; ring
  refine ⟨scalarDelay_response_square_integrable hx hδ hb hE,
    (scalarDelay_command_energy hx hδ hb hE).1,?_,?_,scalarDelay_quadratic_cost hx hδ hb hE q,
    fun t ht => scalarDelay_command_identity hδ hE ht⟩
  · rw [scalarDelay_response_energy hx hδ hb hE,he]
  · rw [(scalarDelay_command_energy hx hδ hb hE).2,he]

end MIACE
