import MIACE.ReducedResolvent
import MIACE.RetardedUniqueness

/-! Етап 12: обикновени времеви решения, получени от действителната
    L¹ резолвента чрез Лапласова единственост и основната теорема на анализа. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

structure ReducedEvolution (i ρ ell δ a₀ b₀ : ℝ) (H a b : ℝ → ℝ) : Prop where
  continuous_a : Continuous a
  continuous_b : Continuous b
  ac_a : ∀ T, 0≤T → AbsolutelyContinuousOnInterval a 0 T
  ac_b : ∀ T, 0≤T → AbsolutelyContinuousOnInterval b 0 T
  initial_a : a 0=a₀
  initial_b : b 0=b₀
  ode_a : ∀ᵐ t, 0<t → HasDerivAt a (-(a t+b t)/ρ) t
  ode_b : ∀ᵐ t, 0<t → HasDerivAt b
    (H t-(i/ρ)*((ell-ρ)*causalize a (t-δ)+ell*causalize b (t-δ))) t

-- @paper-step thm:pid_two_rate_optimum/ordinary_continuous_weighted_bound
theorem weightedControl_continuous_decay {η C : ℝ} {f : ℝ → ℝ}
    (hc : Continuous f) (h : WeightedControl η (causalize f) C) :
    ∀ t, 0≤t → |f t|≤C*Real.exp (-η*t) := by
  apply continuous_halfLine_bound hc.abs (by fun_prop)
  have hh := (weightedControl_decay h).filter_mono
    (ae_mono (Measure.restrict_le_self (s := Ioi (0 : ℝ))))
  filter_upwards [hh,ae_restrict_mem measurableSet_Ioi] with t ht hp
  simpa only [causalize,indicator_of_mem (show t∈Ici (0 : ℝ) from (show 0<t from hp).le)] using ht

-- @paper-step thm:pid_two_rate_optimum/reduced_transform_realization
theorem reduced_transform_realization {i ρ ell δ a₀ b₀ η C : ℝ} {H a b : ℝ → ℝ}
    (hδ : 0≤δ) (h : ReducedTransform i ρ ell δ a₀ b₀ H a b)
    (hH : Integrable H) (ha : WeightedControl η a C) (hb : WeightedControl η b C) :
    ∃ A B : ℝ → ℝ, ReducedEvolution i ρ ell δ a₀ b₀ H A B ∧
      WeightedControl η (causalize A) C ∧ WeightedControl η (causalize B) C := by
  let F := fun t => -(a t+b t)/ρ
  let J := fun t => (ell-ρ)*a t+ell*b t
  let G := fun t => H t-(i/ρ)*shift δ J t
  have hF : Integrable F := (h.integrable_a.add h.integrable_b).neg.div_const ρ
  have hJ : Integrable J := (h.integrable_a.const_mul (ell-ρ)).add (h.integrable_b.const_mul ell)
  have hG : Integrable G := hH.sub ((shift_integrable δ hJ).const_mul (i/ρ))
  have hJc : Causal J := causal_linear h.causal_a h.causal_b (ell-ρ) ell
  have hFa (p : ℝ) (hp : 0<p) : p*laplace a p=a₀+laplace F p := by
    have he : F=fun t => (-1/ρ)*a t+(-1/ρ)*b t := by funext t; dsimp [F]; ring
    rw [he,laplace_linear h.integrable_a h.integrable_b _ _ hp.le,h.equation_a p hp]
    ring
  have hGb (p : ℝ) (hp : 0<p) : p*laplace b p=b₀+laplace G p := by
    have he : G=fun t => 1*H t+(-(i/ρ))*shift δ J t := by funext t; dsimp [G]; ring
    rw [he,laplace_linear hH (shift_integrable δ hJ) _ _ hp.le,
      laplace_shift hJc hδ p,show laplace J p=(ell-ρ)*laplace a p+ell*laplace b p from
        laplace_linear h.integrable_a h.integrable_b _ _ hp.le,h.equation_b p hp]
    ring
  let A := integratedState a₀ F
  let B := integratedState b₀ G
  have heA : a=ᵐ[volume] causalize A := integratedState_identification h.integrable_a h.causal_a hF a₀ hFa
  have heB : b=ᵐ[volume] causalize B := integratedState_identification h.integrable_b h.causal_b hG b₀ hGb
  obtain ⟨hAc,hA0,hAac,hAd⟩ := integratedState_regular a₀ hF
  obtain ⟨hBc,hB0,hBac,hBd⟩ := integratedState_regular b₀ hG
  refine ⟨A,B,⟨hAc,hBc,(fun T _ => hAac 0 T),(fun T _ => hBac 0 T),hA0,hB0,?_,?_⟩,
    weightedControl_congr ha heA,weightedControl_congr hb heB⟩
  · filter_upwards [hAd,heA,heB] with t hd hta htb ht
    simpa only [F,hta,htb,causalize,indicator_of_mem (show t∈Ici (0 : ℝ) from ht.le)] using hd
  · have hea := (measurePreserving_sub_right (volume : Measure ℝ) δ).quasiMeasurePreserving.tendsto_ae.eventually heA
    have heb := (measurePreserving_sub_right (volume : Measure ℝ) δ).quasiMeasurePreserving.tendsto_ae.eventually heB
    filter_upwards [hBd,hea,heb] with t hd hta htb ht
    change HasDerivAt B (H t-(i/ρ)*((ell-ρ)*a (t-δ)+ell*b (t-δ))) t at hd
    rw [hta,htb] at hd
    exact hd

-- @paper-step thm:pid_two_rate_optimum/uniform_reduced_history_evolution
theorem reduced_evolution_exists {i ρ ell l m δ : ℝ} (h : TwoRateData i ρ ell l m δ) :
    ∃ η D : ℝ, 0<η ∧ η≤1/2 ∧ 0<D ∧
      ∀ (H : ℝ → ℝ) (a₀ b₀ M : ℝ), Causal H → WeightedControl η H M →
        |a₀|≤M → |b₀|≤M → ∃ a b : ℝ → ℝ,
          ReducedEvolution i ρ ell δ a₀ b₀ H a b ∧
          WeightedControl η (causalize a) (D*M) ∧ WeightedControl η (causalize b) (D*M) := by
  obtain ⟨_,η,C,hη,hηhalf,hC,hKi,hKq,hKb⟩ := twoRate_signed_kernel h
  let N := ∫ t, |expWeight η (twoRateK (twoRateA ρ l m) l m δ) t|
  have hN : 0≤N := integral_nonneg (fun _ => abs_nonneg _)
  have hK : WeightedControl η (twoRateK (twoRateA ρ l m) l m δ) (N+C) :=
    ⟨add_nonneg hN hC,hKi,by linarith,ae_of_all _ (fun t => (hKb t).trans (by linarith))⟩
  obtain ⟨CG,hG⟩ := twoRateG_weightedControl (twoRateA ρ l m)
    (show η<l by linarith [h.lower_rate]) (show η<m by linarith [h.lower_rate,h.ordered_rates])
  have hηρ : η<1/ρ := by
    apply (lt_div_iff₀ h.filter_pos).mpr
    nlinarith [h.filter_lt_one]
  obtain ⟨CL,hL⟩ := lagKernel_weightedControl h.filter_pos hηρ
  obtain ⟨D,hD,hres⟩ := reduced_resolvent_exists h hη.le hK hKq hG hL
  refine ⟨η,D,hη,hηhalf,hD,?_⟩
  intro H a₀ b₀ M hHc hH ha₀ hb₀
  obtain ⟨a,b,hr,ha,hb⟩ := hres H a₀ b₀ M hHc hH ha₀ hb₀
  exact reduced_transform_realization h.delay_nonneg hr
    (weightedControl_unweighted hH hHc hη.le) ha hb

end MIACE
