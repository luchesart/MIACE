import MIACE.IMCStability

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:complete_robust/weighted_control_difference
theorem weightedControl_sub {η C D : ℝ} {f g : ℝ → ℝ}
    (hf : WeightedControl η f C) (hg : WeightedControl η g D) :
    WeightedControl η (fun t => f t-g t) (C+D) := by
  have hh := weightedControl_add hf (weightedControl_smul hg (-1))
  convert hh using 1
  · funext t; ring
  · norm_num

-- @paper-step thm:complete_robust/actual_internal_input_causality
theorem imcFilterInput_causal (N : ℕ) (σ : ℕ → ℝ) {δ ε : ℝ}
    (hδ : 0≤δ) (hδε : 0≤δ+ε) (H : IMCHistory) (u : ℝ → ℝ) :
    Causal (imcFilterInput N σ δ ε H u) := by
  filter_upwards [plantHistoryOutput_causal N σ H.modelInitial hδ H.modelPast u,
    plantHistoryOutput_causal N σ H.plantInitial hδε H.plantPast u] with t ht hs hn
  change _-_=0
  rw [ht hn,hs hn,sub_self]

structure IMCInternalControl (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) (δ ε : ℝ)
    (H : IMCHistory) (u : ℝ → ℝ) (η C : ℝ) : Prop where
  command : WeightedControl η u C
  plant_states : ∀ j≤N, WeightedControl η (causalize (serialState σ H.plantInitial u (j+1))) C
  model_states : ∀ j≤N, WeightedControl η (causalize (serialState σ H.modelInitial u (j+1))) C
  plant_output : WeightedControl η (plantHistoryOutput N σ H.plantInitial (δ+ε) H.plantPast u) C
  model_output : WeightedControl η (plantHistoryOutput N σ H.modelInitial δ H.modelPast u) C
  filter_input : WeightedControl η (imcFilterInput N σ δ ε H u) C
  filter_state : WeightedControl η
    (causalize (lagState F.timeConstant H.filterInitial (imcFilterInput N σ δ ε H u))) C

-- @paper-step thm:complete_robust/all_internal_states_uniform_history_estimate
theorem imc_internal_uniform_control (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) {δ ε η Cu : ℝ}
    (hδ : 0≤δ) (hδε : 0≤δ+ε) (hη : 0≤η) (hηh : η≤1/2)
    (hηF : η<1/F.timeConstant) (hCu : 0≤Cu) (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) :
    ∃ B : ℝ, 0≤B ∧ ∀ M H, IMCHistoryBound N F δ ε H M →
      ∀ u : ℝ → ℝ, Causal u → WeightedControl η u (Cu*M) →
        IMCInternalControl N σ F δ ε H u η (B*M) := by
  obtain ⟨Cs,hCs,hstates⟩ := serialState_uniform_control σ (N+1) η
    (normalized_storage_exponents σ N hηh hσ)
  obtain ⟨K,hK⟩ := lagKernel_weightedControl F.timeConstant_pos hηF
  let X := Cs*(1+Cu)
  let P := (δ+1+X)*Real.exp (η*δ)
  let Q := (δ+ε+1+X)*Real.exp (η*(δ+ε))
  let Z := F.timeConstant*K+K*(P+Q)
  have hX : 0≤X := by dsimp [X]; positivity
  have hP : 0≤P := by dsimp [P]; positivity
  have hQ : 0≤Q := by dsimp [Q]; positivity
  have hZ : 0≤Z := by dsimp [Z]; have := F.timeConstant_pos; have := hK.nonneg; positivity
  let B := Cu+X+P+Q+Z
  have hB : 0≤B := by dsimp [B]; positivity
  refine ⟨B,hB,?_⟩
  intro M H hH u huc hu
  have hw : WeightedControl η (causalize u) (Cu*M) :=
    weightedControl_congr hu (causalize_eq_ae huc).symm
  have hmodel (j : ℕ) (hj : j≤N+1) :
      WeightedControl η (causalize (serialState σ H.modelInitial u j)) (X*M) := by
    have hh := hstates M (Cu*M) hH.nonneg H.modelInitial
      (fun k hk => hH.model_initial k (by omega)) u hw j hj
    convert hh using 1; dsimp [X]; ring
  have hplant (j : ℕ) (hj : j≤N+1) :
      WeightedControl η (causalize (serialState σ H.plantInitial u j)) (X*M) := by
    have hh := hstates M (Cu*M) hH.nonneg H.plantInitial
      (fun k hk => hH.plant_initial k (by omega)) u hw j hj
    convert hh using 1; dsimp [X]; ring
  have hp : WeightedControl η (plantHistoryOutput N σ H.modelInitial δ H.modelPast u) (P*M) := by
    have hh := plantHistoryOutput_control N σ H.modelInitial hδ hη hH.nonneg
      hH.model_continuous hH.model_bound (hmodel (N+1) le_rfl)
    convert hh using 1; dsimp [P]; ring
  have hq : WeightedControl η (plantHistoryOutput N σ H.plantInitial (δ+ε) H.plantPast u) (Q*M) := by
    have hh := plantHistoryOutput_control N σ H.plantInitial hδε hη hH.nonneg
      hH.plant_continuous hH.plant_bound (hplant (N+1) le_rfl)
    convert hh using 1; dsimp [Q]; ring
  have hinput : WeightedControl η (imcFilterInput N σ δ ε H u) ((P+Q)*M) := by
    have hh := weightedControl_sub hp hq
    convert hh using 1 <;> first | rfl | ring
  have hinput' := weightedControl_congr hinput (causalize_eq_ae (imcFilterInput_causal N σ hδ hδε H u)).symm
  have hz := lagState_weighted_control F.timeConstant_pos hK hinput' H.filterInitial
  have hz' : WeightedControl η
      (causalize (lagState F.timeConstant H.filterInitial (imcFilterInput N σ δ ε H u))) (Z*M) := by
    apply weightedControl_mono hz
    rw [abs_mul,abs_of_pos F.timeConstant_pos]
    have hh := mul_le_mul_of_nonneg_right hH.filter_initial
      (mul_nonneg F.timeConstant_pos.le hK.nonneg)
    dsimp [Z]
    nlinarith
  have h1 : Cu*M≤B*M := mul_le_mul_of_nonneg_right (by dsimp [B]; linarith) hH.nonneg
  have h2 : X*M≤B*M := mul_le_mul_of_nonneg_right (by dsimp [B]; linarith) hH.nonneg
  have h3 : P*M≤B*M := mul_le_mul_of_nonneg_right (by dsimp [B]; linarith) hH.nonneg
  have h4 : Q*M≤B*M := mul_le_mul_of_nonneg_right (by dsimp [B]; linarith) hH.nonneg
  have h5 : (P+Q)*M≤B*M := mul_le_mul_of_nonneg_right (by dsimp [B]; linarith) hH.nonneg
  have h6 : Z*M≤B*M := mul_le_mul_of_nonneg_right (by dsimp [B]; linarith) hH.nonneg
  exact ⟨weightedControl_mono hu h1,
    fun j hj => weightedControl_mono (hplant (j+1) (by omega)) h2,
    fun j hj => weightedControl_mono (hmodel (j+1) (by omega)) h2,
    weightedControl_mono hq h4,weightedControl_mono hp h3,
    weightedControl_mono hinput h5,weightedControl_mono hz' h6⟩

-- Uniform exponential stability of the ordinary IMC realization. The state
-- functions are the actual variation-of-constants solutions, including every
-- plant/model storage state, filter storage state and all finite delay histories.
def IMCInternallyStable (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) (δ ε : ℝ) : Prop :=
  ∃ η C : ℝ, 0<η ∧ 0≤C ∧ ∀ M H, IMCHistoryBound N F δ ε H M →
    ∃ u : ℝ → ℝ, Integrable u ∧ Causal u ∧ u=ᵐ[volume] imcFeedback N σ F δ ε H u ∧
      IMCInternalControl N σ F δ ε H u η (C*M) ∧
      ∀ v : ℝ → ℝ, LocallyIntegrable v volume → Causal v →
        v=ᵐ[volume] imcFeedback N σ F δ ε H v → v=ᵐ[volume] u

-- @paper-step thm:complete_robust/actual_IMC_internal_exponential_stability
theorem imc_internal_stability (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) {δ ε : ℝ}
    (hδ : 0≤δ) (hδε : 0≤δ+ε) (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1)
    (hq : imcDelayGain F ε<1) : IMCInternallyStable N σ F δ ε := by
  obtain ⟨η,Cu,hη,hηh,hηF,hCu,hfeedback⟩ :=
    imc_history_feedback_stability N σ F hδ hδε hσ hfirst hq
  obtain ⟨B,hB,hcontrol⟩ := imc_internal_uniform_control N σ F hδ hδε hη.le hηh hηF hCu hσ
  refine ⟨η,B,hη,hB,?_⟩
  intro M H hH
  obtain ⟨u,hu,huc,he,hw,hunique⟩ := hfeedback M H hH
  exact ⟨u,hu,huc,he,hcontrol M H hH u huc hw,hunique⟩

-- @paper-step thm:complete_attainment/nominal_full_state_IMC_stability
theorem imc_nominal_internal_stability (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) {δ : ℝ}
    (hδ : 0≤δ) (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1) :
    IMCInternallyStable N σ F δ 0 := by
  apply imc_internal_stability N σ F hδ (by simpa using hδ) hσ hfirst
  simp [imcDelayGain]

-- @paper-step thm:complete_robust/internal_control_actual_ODE_and_pointwise_decay
theorem imc_control_actual_states (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) {δ ε η C : ℝ}
    (hδ : 0≤δ) (hδε : 0≤δ+ε) (hη : 0≤η) (H : IMCHistory) {u : ℝ → ℝ}
    (hu : LocallyIntegrable u volume) (h : IMCInternalControl N σ F δ ε H u η C) :
    (∀ j≤N, LagEvolution (σ j) (H.plantInitial j) (serialState σ H.plantInitial u j)
      (serialState σ H.plantInitial u (j+1)) ∧
      ∀ t, 0≤t → |serialState σ H.plantInitial u (j+1) t|≤C*Real.exp (-η*t)) ∧
    (∀ j≤N, LagEvolution (σ j) (H.modelInitial j) (serialState σ H.modelInitial u j)
      (serialState σ H.modelInitial u (j+1)) ∧
      ∀ t, 0≤t → |serialState σ H.modelInitial u (j+1) t|≤C*Real.exp (-η*t)) ∧
    LagEvolution F.timeConstant H.filterInitial (imcFilterInput N σ δ ε H u)
      (lagState F.timeConstant H.filterInitial (imcFilterInput N σ δ ε H u)) ∧
    ∀ t, 0≤t → |lagState F.timeConstant H.filterInitial (imcFilterInput N σ δ ε H u) t|
      ≤C*Real.exp (-η*t) := by
  have hi := weightedControl_unweighted h.filter_input (imcFilterInput_causal N σ hδ hδε H u) hη
  have hz := lagState_evolution hi.locallyIntegrable F.timeConstant H.filterInitial
  refine ⟨?_,?_,hz.2,weightedControl_continuous_decay hz.1 h.filter_state⟩
  · intro j hj
    have hx := serialState_evolution hu σ H.plantInitial j
    exact ⟨hx.2,weightedControl_continuous_decay hx.1 (h.plant_states j hj)⟩
  · intro j hj
    have hx := serialState_evolution hu σ H.modelInitial j
    exact ⟨hx.2,weightedControl_continuous_decay hx.1 (h.model_states j hj)⟩

end MIACE
