import MIACE.RationalUniqueness

namespace MIACE
open MeasureTheory Filter Set Polynomial
open scoped Topology

/-- Uniform exponential stability of the unreduced, finite rational
realization, including every controller/plant state and every finite
continuous transport history. A competing ordinary solution is not
assumed globally integrable or stable. -/
def RationalInternallyStable (r : ℕ → ℝ) (n : ℕ) (δ a c : ℝ) : Prop :=
  ∃ η D : ℝ, 0<η ∧ 0≤D ∧ ∀ M H, RationalHistoryBound n δ H M →
    ∃ w : ℝ → ℝ, RationalHistoryEvolution r n δ a c H w ∧
      RationalInternalControl r n δ H w η (D*M) ∧
      ∀ W, RationalHistoryEvolution r n δ a c H W → ∀ t, 0≤t → W t=w t

-- @paper-step thm:n_construction/all_finite_continuous_rational_histories_are_covered
theorem rational_history_bound_exists (n : ℕ) (δ : ℝ) (H : RationalHistory)
    (hH : ContinuousOn H.past (Icc (-δ) 0)) : ∃ M, RationalHistoryBound n δ H M := by
  obtain ⟨P,hP⟩ := isCompact_Icc.exists_bound_of_continuousOn hH
  let I := ∑ j∈Finset.range (n+1), |H.controllerInitial j|
  let B := ∑ j∈Finset.range (n+1), |H.plantInitial j|
  have hI : 0≤I := Finset.sum_nonneg (fun _ _ => abs_nonneg _)
  have hB : 0≤B := Finset.sum_nonneg (fun _ _ => abs_nonneg _)
  let M := |H.commandInitial|+|H.outputInitial|+I+B+|P|
  have hM : 0≤M := by dsimp [M]; positivity
  refine ⟨M,hM,?_,?_,?_,?_,hH,?_⟩
  · dsimp [M]; linarith [abs_nonneg H.outputInitial,abs_nonneg P]
  · intro j hj
    have hh : |H.controllerInitial j|≤I := Finset.single_le_sum
      (f := fun j => |H.controllerInitial j|) (fun _ _ => abs_nonneg _)
      (show j∈Finset.range (n+1) from Finset.mem_range.mpr (by omega))
    dsimp [M]; linarith [abs_nonneg H.commandInitial,abs_nonneg H.outputInitial,abs_nonneg P]
  · intro j hj
    have hh : |H.plantInitial j|≤B := Finset.single_le_sum
      (f := fun j => |H.plantInitial j|) (fun _ _ => abs_nonneg _)
      (show j∈Finset.range (n+1) from Finset.mem_range.mpr (by omega))
    dsimp [M]; linarith [abs_nonneg H.commandInitial,abs_nonneg H.outputInitial,abs_nonneg P]
  · dsimp [M]; linarith [abs_nonneg H.commandInitial,abs_nonneg P]
  · intro s hs
    have hh : |H.past s|≤P := hP s hs
    dsimp [M]; linarith [abs_nonneg H.commandInitial,abs_nonneg H.outputInitial,le_abs_self P]

-- The formerly open state/history clause, with no scalar spectral-to-time
-- theorem assumed: construction uses the actual positive compact inverse.
-- @paper-step thm:n_construction/unreduced_rational_all_history_internal_stability
theorem rationalCascade_internal_stability (r : ℕ → ℝ) (n : ℕ) {δ U : ℝ}
    (hr : ∀ j≤n, 0<r j) (hδ : 0≤δ)
    (ha : 0<rationalCascadeA r n δ U) (ha1 : rationalCascadeA r n δ U<1)
    (hpar : CascadeParityTest (remainderJ r n δ) δ (rationalCascadeA r n δ U) ((-1 : ℝ)^(n+1))) :
    RationalInternallyStable r n δ (rationalCascadeA r n δ U) (rationalCascadeC r n δ) := by
  obtain ⟨η,D,hη,hD,hh⟩ := rational_parity_full_state_exists r n hr hδ ha ha1 hpar
  refine ⟨η,D,hη,hD,?_⟩
  intro M H hH
  obtain ⟨w,hw,hcontrol⟩ := hh M H hH
  have hi := weightedControl_unweighted
    (historyInput_control_on hδ hη.le hH.nonneg hH.continuous hH.past) (historyInput_causal δ H.past) hη.le
  exact ⟨w,hw,hcontrol,fun W hW => rational_history_unique r n hδ H hi hW hw⟩

-- The original controller storage coordinate is z=a*w+y. This invertible
-- coordinate change retains the plant's canceled unit lag.
-- @paper-step thm:n_construction/proper_rational_controller_original_state_ode
theorem rational_original_controller_state (r : ℕ → ℝ) (n : ℕ) {δ a c : ℝ} (ha : 0<a)
    (H : RationalHistory) (hHi : Integrable (historyInput δ H.past)) {w : ℝ → ℝ}
    (hw : RationalHistoryEvolution r n δ a c H w) :
    let y := rationalOutput r n δ H w
    let z := fun t => a*w t+y t
    Continuous y ∧ LagEvolution 1 H.outputInitial (rationalBState r δ H w n) y ∧
      z 0=a*H.commandInitial+H.outputInitial ∧
      (∀ t, w t=(z t-y t)/a) ∧
      ∀ᵐ t, 0<t → HasDerivAt z (-y t-c*w t+rationalIState r δ H w n t) t := by
  have hu : LocallyIntegrable (rationalDelayed δ H w) volume :=
    hHi.locallyIntegrable.add (scalarDelay_shift_local hw.continuous δ)
  have hB := serialState_evolution hu (fun j => 1/r j) H.plantInitial n
  have hy := lagState_evolution hB.1.locallyIntegrable 1 H.outputInitial
  refine ⟨hy.1,hy.2,?_,?_,?_⟩
  · simp [hw.initial,show rationalOutput r n δ H w 0=H.outputInitial from hy.2.initial]
  · intro t
    field_simp [ne_of_gt ha]
    ring
  · filter_upwards [hw.ode,hy.2.ode] with t ht hyT ht0
    have hh := ((ht ht0).const_mul a).add (hyT ht0)
    change HasDerivAt (fun t => a*w t+rationalOutput r n δ H w t) _ t at hh
    convert hh using 1
    simp only [div_one]
    dsimp [rationalOutput,rationalBState]
    field_simp [ne_of_gt ha]
    ring

-- @paper-step thm:n_construction/rational_controller_transfer_algebra
theorem rational_controller_transfer (r : ℕ → ℝ) (n : ℕ) (δ U p w e z : ℝ)
    (hB : (remainderB r n).eval p≠0)
    (hw : rationalCascadeA r n δ U*w=z+e)
    (hz : p*z=e-rationalCascadeC r n δ*w+
      (remainderI r δ n).eval p/(remainderB r n).eval p*w) :
    (rationalCascadeQ r n δ U).eval p*w=
      (1+p)*(remainderB r n).eval p*e := by
  unfold rationalCascadeQ
  simp only [eval_sub,eval_mul,eval_add,eval_C,eval_X]
  field_simp [hB] at hz
  linear_combination (remainderB r n).eval p*p*hw+hz

-- @paper-step thm:n_construction/all_original_storage_states_pointwise_decay
theorem rational_internal_pointwise (r : ℕ → ℝ) (n : ℕ) {δ a c η D : ℝ}
    (H : RationalHistory) (hHi : Integrable (historyInput δ H.past)) {w : ℝ → ℝ}
    (hw : RationalHistoryEvolution r n δ a c H w)
    (hc : RationalInternalControl r n δ H w η D) :
    (∀ t, 0≤t → |w t|≤D*Real.exp (-η*t)) ∧
    (∀ j≤n, ∀ t, 0≤t → |rationalIState r δ H w j t|≤D*Real.exp (-η*t)) ∧
    (∀ j≤n, ∀ t, 0≤t → |rationalBState r δ H w j t|≤D*Real.exp (-η*t)) ∧
    (∀ t, 0≤t → |rationalOutput r n δ H w t|≤D*Real.exp (-η*t)) ∧
    (∀ t, 0≤t → |a*w t+rationalOutput r n δ H w t|≤(|a|+1)*D*Real.exp (-η*t)) := by
  have hu : LocallyIntegrable (rationalDelayed δ H w) volume :=
    hHi.locallyIntegrable.add (scalarDelay_shift_local hw.continuous δ)
  have hB (j : ℕ) := serialState_evolution hu (fun j => 1/r j) H.plantInitial j
  have hy := (lagState_evolution (hB n).1.locallyIntegrable 1 H.outputInitial).1
  have hwd := weightedControl_continuous_decay hw.continuous hc.command
  have hyd : ∀ t, 0≤t → |rationalOutput r n δ H w t|≤D*Real.exp (-η*t) := weightedControl_continuous_decay hy hc.output
  refine ⟨hwd,?_,?_,hyd,?_⟩
  · intro j hj
    exact weightedControl_continuous_decay (remainderFilter_local hw.continuous.locallyIntegrable r δ H.controllerInitial j) (hc.controller j hj)
  · intro j hj
    exact weightedControl_continuous_decay (hB j).1 (hc.plant j hj)
  · intro t ht
    have hh := abs_add_le (a*w t) (rationalOutput r n δ H w t)
    rw [abs_mul] at hh
    nlinarith [hwd t ht,hyd t ht,mul_le_mul_of_nonneg_left (hwd t ht) (abs_nonneg a)]

-- @paper-step thm:n_construction/full_transport_segment_pointwise_exponential_decay
theorem rational_transport_decay {δ η M D t : ℝ} (hη : 0≤η) (hM : 0≤M) (hD : 0≤D)
    {φ w : ℝ → ℝ} (ht : 0≤t) (hφ : ∀ s∈Icc (-δ) 0, |φ s|≤M)
    (hw : ∀ t, 0≤t → |w t|≤D*Real.exp (-η*t)) :
    ∀ s∈Icc (-δ) 0, |if t+s<0 then φ (t+s) else w (t+s)|≤
      (M+D)*Real.exp (η*δ)*Real.exp (-η*t) := by
  intro s hs
  have he : Real.exp (η*δ)*Real.exp (-η*t)=Real.exp (η*δ-η*t) := by
    rw [← Real.exp_add]; congr 1; ring
  rw [mul_assoc,he]
  by_cases hn : t+s<0
  · rw [if_pos hn]
    have hmem : t+s∈Icc (-δ) 0 := ⟨by linarith [hs.1],hn.le⟩
    have hex : 1≤Real.exp (η*δ-η*t) := Real.one_le_exp_iff.mpr (by nlinarith [hs.1])
    exact (hφ (t+s) hmem).trans (by nlinarith [mul_le_mul_of_nonneg_left hex (add_nonneg hM hD)])
  · rw [if_neg hn]
    have hex : Real.exp (-η*(t+s))≤Real.exp (η*δ-η*t) := Real.exp_le_exp.mpr (by nlinarith [hs.1])
    exact (hw (t+s) (le_of_not_gt hn)).trans ((mul_le_mul_of_nonneg_left hex hD).trans
      (mul_le_mul_of_nonneg_right (by linarith) (Real.exp_nonneg _)))



-- @paper-step thm:n_construction/arbitrary_controller_storage_evolution_unique
theorem remainderEvolution_unique (r : ℕ → ℝ) (δ : ℝ) (ξ : ℕ → ℝ)
    (u : ℝ → ℝ) (q : ℕ → ℝ → ℝ) (n : ℕ)
    (h0 : LagEvolution (1/r 0) (ξ 0) (fun t => remainderFeed r δ 0*u t) (q 0))
    (hq : ∀ j<n, LagEvolution (1/r (j+1)) (ξ (j+1))
      (fun t => q j t+remainderFeed r δ (j+1)*u t) (q (j+1))) :
    ∀ j≤n, ∀ t, 0≤t → q j t=remainderFilter r δ ξ u j t := by
  intro j hj
  induction j with
  | zero => intro t ht; exact lagEvolution_formula h0 ht
  | succ j ih =>
    intro t ht
    rw [lagEvolution_formula (hq j (by omega)) ht]
    change lagState (1/r (j+1)) (ξ (j+1))
      (fun s => q j s+remainderFeed r δ (j+1)*u s) t=
      lagState (1/r (j+1)) (ξ (j+1))
      (fun s => remainderFilter r δ ξ u j s+remainderFeed r δ (j+1)*u s) t
    unfold lagState lag
    congr 2
    apply intervalIntegral.integral_congr
    intro s hs
    rw [uIcc_of_le ht] at hs
    dsimp only
    rw [ih (by omega) s hs.1]

-- @paper-step thm:n_construction/full_paper_theorem_with_internal_stability
theorem paper_rationalCascade_attainment (r : ℕ → ℝ) (n : ℕ) {δ α : ℝ}
    (hr : ∀ j≤n, 0<r j) (hδ : 0≤δ) (hα : 0<α)
    (ha : 0<rationalCascadeA r n δ
      ((1+(∑ j∈Finset.range (n+1), 1/r j)+δ)/(1+α)))
    (ha1 : rationalCascadeA r n δ
      ((1+(∑ j∈Finset.range (n+1), 1/r j)+δ)/(1+α))<1)
    (hpar : CascadeParityTest (remainderJ r n δ) δ (rationalCascadeA r n δ
      ((1+(∑ j∈Finset.range (n+1), 1/r j)+δ)/(1+α))) ((-1 : ℝ)^(n+1))) :
    let S := 1+(∑ j∈Finset.range (n+1), 1/r j)+δ
    RationalInternallyStable r n δ (rationalCascadeA r n δ (S/(1+α))) (rationalCascadeC r n δ) ∧
    ∃ R v : ℝ → ℝ,
      v=causalize (cascadeCommand (remainderJ r n δ) δ
        (rationalCascadeA r n δ (S/(1+α))) ((-1 : ℝ)^(n+1)) R) ∧
      Integrable v ∧
      TransferResponse (rationalCascadeError r n δ v) v
        (cascadeTransfer (rationalCascadeTimes r) (n+2)) δ ∧
      (∀ t, 0≤t → 0≤v t ∧ 0≤rationalCascadeError r n δ v t) ∧
      Monotone (fun t => 1-rationalCascadeError r n δ v t) ∧
      1-rationalCascadeError r n δ v 0=0 ∧
      Tendsto (fun t => 1-rationalCascadeError r n δ v t) atTop (𝓝 1) ∧
      absArea v halfLine=S/(1+α) ∧
      absArea (rationalCascadeError r n δ v) halfLine=α*S/(1+α) ∧
      miace α (rationalCascadeError r n δ v) v halfLine=S*minimum α ∧
      (∀ p : ℝ, 0<p → (rationalCascadeQ r n δ (S/(1+α))).eval p*
        laplace (fun t => 1+v t) p=
        ((1+p)*(remainderB r n).eval p)*laplace (rationalCascadeError r n δ v) p) ∧
      ∀ e' v' : ℝ → ℝ,
        TransferResponse e' v' (cascadeTransfer (rationalCascadeTimes r) (n+2)) δ →
        miace α (rationalCascadeError r n δ v) v halfLine≤miace α e' v' halfLine := by
  exact ⟨rationalCascade_internal_stability r n hr hδ ha ha1 hpar,
    rationalCascade_global_signal_minimum r n hr hδ hα ha ha1 hpar⟩

end MIACE
