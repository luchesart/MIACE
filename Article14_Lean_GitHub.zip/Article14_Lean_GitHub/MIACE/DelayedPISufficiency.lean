import MIACE.DelayedPIRange

/-! Stage 19. Construct the actual ordinary PI response at the closed
positivity threshold, then verify the original controller and plant laws. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:delayed_optimum/future_translation_preserves_integrability
theorem halfline_future_integrable {f : ℝ → ℝ} (hf : Integrable f halfLine)
    {δ : ℝ} (hδ : 0≤δ) : Integrable (fun t => f (t+δ)) halfLine := by
  have hi := IntegrableOn.mono_set hf (show Ioi δ ⊆ Ioi (0 : ℝ) from fun t ht => hδ.trans_lt ht)
  exact ((translate_halfLine δ).integrable_comp_emb
    (Homeomorph.addRight δ).isClosedEmbedding.measurableEmbedding).mpr hi

-- @paper-step thm:delayed_optimum/actual_PI_controller_and_delayed_plant_construction
theorem cancelled_PI_positive_response {x δ : ℝ} (hx : 1≤x) (hδ : 0≤δ)
    (hb : x*δ≤Real.exp (-1)) :
    ∃ E V : ℝ → ℝ, IdealPIResponse x 1 δ E V ∧ ScalarDelayResponse x δ E ∧
      (∀ t, 0≤t → 0<E t ∧ 0≤V t) ∧ (∫ t, E t ∂halfLine)=1/x ∧
      MonotoneOn (fun t => 1-E t) (Ici 0) ∧
      1-E 0=0 ∧ Tendsto (fun t => 1-E t) atTop (𝓝 1) := by
  have hxp : 0<x := by linarith
  obtain ⟨l,hl,he⟩ := (scalarDelay_tilt_iff hxp hδ).mpr hb
  obtain ⟨E,hEc,hAC,h0,hn,hEi,_,hT⟩ := scalarDelay_positive_resolvent hxp hδ hl he
  have hE : ScalarDelayResponse x δ E :=
    ⟨hEc,hAC,h0,scalarDelay_integral_equation hδ hEc hEi (fun p hp => hT p hp.le)⟩
  let V := fun t => x*E t-E (t+δ)
  have hVc : Continuous V := (hEc.const_mul x).sub (hEc.comp (continuous_id.add_const δ))
  have hVi : Integrable V halfLine := (hEi.const_mul x).sub (halfline_future_integrable hEi hδ)
  have hcmd : ∀ t, 0≤t → pidTimeCommand x (x/1) 0 1 E t=1+V t := by
    intro t ht
    have hh := scalarDelay_command_identity hδ hE ht
    simp only [pidTimeCommand,div_one,zero_div,zero_mul,add_zero]
    dsimp [V]; linarith
  have hC (p : ℝ) (hp : 0<p) : (x+x/p)*laplace E p=1/p+laplace V p := by
    have heq : pidTimeCommand x (x/1) 0 1 E=ᵐ[halfLine] (fun t => 1+V t) := by
      filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
      exact hcmd t (show 0<t from ht).le
    have hh := (pidTimeCommand_transform hEi x (x/1) 0 (by norm_num : (0 : ℝ)<1) hp).2
    rw [laplace_congr_halfLine heq,(laplace_step_add hVi hp).2] at hh
    simpa using hh.symm
  have hplant : TransferResponse E V (fun p => 1/(1+p)) δ := by
    refine ⟨hEi,hVi,?_⟩
    intro p hp
    have hs : laplace (fun t => 1-E t) p=1/p-laplace E p := by
      have hh := (laplace_step_add hEi.neg hp).2
      change laplace (fun t => 1-E t) p=1/p-laplace E p
      have hneg : laplace (-E) p= -laplace E p := by
        unfold laplace; simp only [Pi.neg_apply,mul_neg,integral_neg]
      simpa only [Pi.neg_apply,← sub_eq_add_neg,hneg] using hh
    rw [hs,(laplace_step_add hVi hp).2]
    have hcp := hC p hp
    have hep := hT p hp.le
    have hp0 := ne_of_gt hp
    have hp1 : 1+p≠0 := ne_of_gt (by linarith)
    field_simp [hp0,hp1] at hcp ⊢
    simp only [neg_mul,mul_comm δ p] at hep ⊢
    linear_combination -(1+p)*hep+Real.exp (-(p*δ))*hcp
  have hmass := hT 0 le_rfl
  simp only [mul_zero,neg_zero,Real.exp_zero,mul_one,zero_add,laplace,zero_mul,one_mul] at hmass
  have hm : (∫ t, E t ∂halfLine)=1/x := (eq_div_iff (ne_of_gt hxp)).mpr (by nlinarith)
  have hanti := scalarDelay_antitone hxp hE hEi (fun t ht => (hn t ht).le)
  have hshape := (scalarDelay_monotone_iff hxp hδ hE).mpr hb
  refine ⟨E,V,⟨hEc,hVc,hplant,hcmd⟩,hE,?_,hm,hshape.1,hshape.2.1,hshape.2.2⟩
  intro t ht
  exact ⟨hn t ht,scalarDelay_command_nonneg hx hδ (fun s hs => (hn s hs).le) hanti ht⟩

-- @paper-step thm:delayed_optimum/actual_optimum_with_both_areas_and_global_comparison
theorem delayedPI_optimum_exists {α δ : ℝ} (hα : 0<α) (hδ : 0≤δ)
    (hrange : δ≤delayedPIMaxDelay α) :
    ∃ E V : ℝ → ℝ, IdealPIResponse (delayedPIGain α δ) 1 δ E V ∧
      absArea E halfLine=α*(1+δ)/(1+α) ∧ absArea V halfLine=(1+δ)/(1+α) ∧
      miace α E V halfLine=(1+δ)*minimum α ∧
      MonotoneOn (fun t => 1-E t) (Ici 0) ∧ 1-E 0=0 ∧
      Tendsto (fun t => 1-E t) atTop (𝓝 1) ∧
      ∀ e v : ℝ → ℝ, TransferResponse e v (fun p => 1/(1+p)) δ →
        miace α E V halfLine≤miace α e v halfLine := by
  obtain ⟨hx,hb⟩ := (delayedPI_range_iff hα hδ).mpr hrange
  obtain ⟨E,V,h,hE,hn,hmass,hmon,h0,hlim⟩ := cancelled_PI_positive_response hx hδ hb
  have hnE : ∀ᵐ t ∂halfLine, 0≤E t := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact (hn t (show 0<t from ht).le).1.le
  have hnV : ∀ᵐ t ∂halfLine, 0≤V t := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact (hn t (show 0<t from ht).le).2
  have hAe : absArea E halfLine=1/delayedPIGain α δ := by
    rw [absArea,integral_congr_ae (hnE.mono (fun t ht => abs_of_nonneg ht)),hmass]
  have hAv : absArea V halfLine=1+δ-1/delayedPIGain α δ := by
    have hbal := transfer_signed_balance h.plant 1 firstOrder_transfer_dc (by norm_num)
    rw [hmass] at hbal
    rw [absArea,integral_congr_ae (hnV.mono (fun t ht => abs_of_nonneg ht))]
    linarith
  have hr : absArea E halfLine=α*absArea V halfLine := by
    rw [hAe,hAv]; exact delayedPIGain_balance hα hδ
  have hgen := paper_general_plant h.plant α 1 hα (by linarith) firstOrder_transfer_dc (by norm_num)
  have hcost := hgen.2.2.2.2.1.mpr ⟨hnE,hnV,hr⟩
  obtain ⟨hareaE,hareaV⟩ := hgen.2.2.2.2.2 hcost
  refine ⟨E,V,h,hareaE,hareaV,hcost,hmon,h0,hlim,?_⟩
  intro e v h'
  rw [hcost]
  exact (paper_general_plant h' α 1 hα (by linarith) firstOrder_transfer_dc (by norm_num)).2.2.2.1

end MIACE
