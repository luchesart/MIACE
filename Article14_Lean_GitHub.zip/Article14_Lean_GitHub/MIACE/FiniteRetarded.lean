import MIACE.ReducedUniqueness

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- Finite-dimensional uniqueness needs no integrability at infinity and no
-- prior stability estimate for the competing trajectory.
-- @paper-step thm:n_construction/finite_dimensional_retarded_zero_uniqueness
theorem finite_retarded_zero {ι : Type*} [Fintype ι] {x : ι → ℝ → ℝ}
    (hc : ∀ i, Continuous (x i))
    (hac : ∀ i T, 0≤T → AbsolutelyContinuousOnInterval (x i) 0 T)
    (h0 : ∀ i, x i 0=0) {δ : ℝ} (hδ : 0≤δ) (L : ι → ℝ)
    (hL : ∀ i, 0≤L i)
    (hd : ∀ i, ∀ᵐ t, 0<t → |deriv (x i) t|≤L i*
      ((∑ j, |x j t|)+(∑ j, |x j (max 0 (t-δ))|))) :
    ∀ t, 0≤t → ∀ i, x i t=0 := by
  classical
  let f := fun t => ∑ i, |x i t|
  have hf : Continuous f := continuous_finsetSum _ (fun i _ => (hc i).abs)
  have hn (t : ℝ) : 0≤f t := Finset.sum_nonneg (fun i _ => abs_nonneg _)
  intro T hT
  have hi (t : ℝ) (ht : t∈Icc (0 : ℝ) T) :
      f t≤(∑ i, L i)*(∫ s in 0..t, f s+f (max 0 (s-δ))) := by
    have hiD (i : ι) := (hac i t ht.1).intervalIntegrable_deriv
    have hiAbs (i : ι) : |x i t|≤∫ s in 0..t, |deriv (x i) s| := by
      have hh := intervalIntegral.abs_integral_le_integral_abs (f := deriv (x i)) (μ := volume) ht.1
      rw [(hac i t ht.1).integral_deriv_eq_sub,h0 i,sub_zero] at hh
      exact hh
    have hdSum : ∀ᵐ s, 0<s → (∑ i, |deriv (x i) s|)≤
        (∑ i, L i)*(f s+f (max 0 (s-δ))) := by
      filter_upwards [ae_all_iff.mpr hd] with s hs hp
      simpa [Finset.sum_mul,f] using Finset.sum_le_sum (fun i _ => hs i hp)
    have hmajor : Continuous (fun s => (∑ i, L i)*(f s+f (max 0 (s-δ)))) :=
      (hf.add (hf.comp (continuous_const.max (continuous_id.sub continuous_const)))).const_mul _
    have hsumI : IntervalIntegrable (fun s => ∑ i, |deriv (x i) s|) volume 0 t :=
      by simpa only [Finset.sum_fn] using IntervalIntegrable.sum Finset.univ (fun i _ => (hiD i).abs)
    have hh := intervalIntegral.integral_mono_ae_restrict ht.1 hsumI
      (hmajor.intervalIntegrable (μ := volume) 0 t) (show
        (fun s => ∑ i, |deriv (x i) s|) ≤ᵐ[volume.restrict (Icc 0 t)]
        (fun s => (∑ i, L i)*(f s+f (max 0 (s-δ)))) from by
          have hd' := hdSum.filter_mono (ae_mono (Measure.restrict_le_self (s := Icc 0 t)))
          have hz := (volume.ae_ne (0 : ℝ)).filter_mono (ae_mono (Measure.restrict_le_self (s := Icc 0 t)))
          filter_upwards [hd',hz,ae_restrict_mem measurableSet_Icc] with s hs hsz hst
          exact hs (lt_of_le_of_ne hst.1 (Ne.symm hsz)))
    rw [intervalIntegral.integral_finset_sum (fun i _ => (hiD i).abs),intervalIntegral.integral_const_mul] at hh
    exact (Finset.sum_le_sum (fun i _ => hiAbs i)).trans hh
  have hz := retarded_integral_zero hf hδ (Finset.sum_nonneg (fun i _ => hL i)) hT
    (fun t _ => hn t) hi T ⟨hT,le_rfl⟩
  intro i
  have hle : |x i T|≤f T := Finset.single_le_sum (f := fun j => |x j T|) (fun j _ => abs_nonneg _) (Finset.mem_univ i)
  exact abs_eq_zero.mp (le_antisymm (by linarith) (abs_nonneg _))

end MIACE
