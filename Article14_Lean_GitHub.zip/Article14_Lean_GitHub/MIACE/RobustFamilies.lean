import MIACE.CompleteRobust

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- The concrete statement of Theorem 23, with the paper's filter variation f.
def IMCDelayRobust (N : ℕ) (σ : ℕ → ℝ) (F : IMCFilter) (δ ε α : ℝ)
    (v0 : ℝ → ℝ) (f : ℝ) : Prop :=
  let q := 2*f*(1-Real.exp (-|ε|))
  IMCInternallyStable N σ F δ ε ∧
    ∃ w e v : ℝ → ℝ, IMCStepResponse N σ F δ ε w e v ∧
      absArea (fun t => v t-v0 t) halfLine≤f^2*|ε|/(1-q) ∧
      absArea (fun t => e t-cascadeStepError N σ δ v0 t) halfLine≤2*f*|ε|/(1-q) ∧
      |miace α e v halfLine-miace α (cascadeStepError N σ δ v0) v0 halfLine|≤
        f*|ε| *Real.sqrt (4+α*f^2)/(1-q)

-- @paper-step thm:complete_robust/full_exponential_filter_delay_robustness
theorem paper_exponential_delay_robust (N : ℕ) (σ : ℕ → ℝ) {δ ε α a : ℝ}
    (hδ : 0≤δ) (hδε : 0≤δ+ε) (hα : 0≤α) (ha : 0<a) (ha1 : a≤1)
    (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1)
    (hq : 2*(2/a-1)*(1-Real.exp (-|ε|))<1) :
    IMCDelayRobust N σ (exponentialIMC a ha) δ ε α (imcExcess a) (2/a-1) := by
  have hgain := exponentialIMC_gain ha ha1
  have hq' : imcDelayGain (exponentialIMC a ha) ε<1 := by
    simpa only [imcDelayGain,hgain] using hq
  have hbase : ∀ᵐ t, 0≤filterAction (exponentialIMC a ha) (lagKernel 1) t := by
    filter_upwards [exponentialIMC_unitLag ha] with t ht
    rw [ht]
    exact (lagKernel_properties ha).2.1 t
  have hDC : filterTransfer (exponentialIMC a ha) 0=1 := by
    rw [exponentialIMC_transfer ha le_rfl]
    norm_num
  have hh := paper_complete_robust N σ (exponentialIMC a ha) hδ hδε hα hσ hfirst
    (exponential_cascade_IMC N σ hδ ha ha1 hσ hfirst) hbase hDC hq'
  simpa only [IMCDelayRobust,imcDelayGain,hgain] using hh

-- @paper-step thm:complete_robust/full_pulse_filter_delay_robustness
theorem paper_pulse_delay_robust (N : ℕ) (σ : ℕ → ℝ) {δ ε α c T : ℝ}
    (hδ : 0≤δ) (hδε : 0≤δ+ε) (hα : 0≤α) (hc : 0<c) (hT : 0<T)
    (hJ : c*(Real.exp T-1)≤1) (hσ : ∀ j≤N, 0<σ j ∧ σ j≤1) (hfirst : σ 0=1)
    (hq : 2*(1+2*c)*(1-Real.exp (-|ε|))<1) :
    IMCDelayRobust N σ (pulseIMC c T hT.le) δ ε α (pulse c T) (1+2*c) := by
  have hgain := pulseIMC_gain hc.le hT.le
  have hq' : imcDelayGain (pulseIMC c T hT.le) ε<1 := by
    simpa only [imcDelayGain,hgain] using hq
  have hbase := ae_of_all volume (pulseIMC_unitLag_nonnegative hc.le hT.le hJ)
  have hDC : filterTransfer (pulseIMC c T hT.le) 0=1 := by simp [filterTransfer,pulseIMC]
  have hh := paper_complete_robust N σ (pulseIMC c T hT.le) hδ hδε hα hσ hfirst
    (pulse_cascade_IMC N σ c hδ hT.le hσ hfirst) hbase hDC hq'
  simpa only [IMCDelayRobust,imcDelayGain,hgain] using hh

end MIACE
