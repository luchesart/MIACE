import MIACE.ExplicitPIDOrdinary

/-! Stage 19. Complete explicit additional PID attainment interval.
The controller is ordinary and its internal stability covers all finite
continuous histories. All original area and global optimality claims remain. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:pid_explicit_family/exact_optimal_areas_and_global_comparison
theorem explicitPID_optimal_response {α ρ ell l δ : ℝ} (hα : 0<α)
    (h : ExplicitPIDData (delayedPIGain α δ) ρ ell l δ) :
    ∃ E V : ℝ → ℝ,
      FilteredPIDResponse (delayedPIGain α δ+ρ^2) (delayedPIGain α δ)
        (delayedPIGain α δ*ρ^2) ρ δ E V ∧
      absArea E halfLine=α*(1+δ)/(1+α) ∧ absArea V halfLine=(1+δ)/(1+α) ∧
      miace α E V halfLine=(1+δ)*minimum α ∧
      MonotoneOn (fun t => 1-E t) (Ici 0) ∧ 1-E 0=0 ∧
      Tendsto (fun t => 1-E t) atTop (𝓝 1) ∧
      ∀ e v : ℝ → ℝ, TransferResponse e v (fun p => 1/(1+p)) δ →
        miace α E V halfLine≤miace α e v halfLine := by
  obtain ⟨E,V,hpid,hn,h0,hlim,hmass⟩ := explicitPID_ordinary h
  have hδ := h.delay_pos.le
  have hshape := positive_filtered_PID_shape hδ hpid hn h0 hlim
  have hnE : ∀ᵐ t ∂halfLine, 0≤E t := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact (hn t (show 0<t from ht).le).1
  have hnV : ∀ᵐ t ∂halfLine, 0≤V t := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    exact (hn t (show 0<t from ht).le).2
  have hAe : absArea E halfLine=1/delayedPIGain α δ := by
    rw [absArea,integral_congr_ae (hnE.mono (fun t ht => abs_of_nonneg ht)),hmass]
  have hAv : absArea V halfLine=1+δ-1/delayedPIGain α δ := by
    have hb := transfer_signed_balance hpid.plant 1 firstOrder_transfer_dc (by norm_num)
    rw [hmass] at hb
    rw [absArea,integral_congr_ae (hnV.mono (fun t ht => abs_of_nonneg ht))]
    linarith
  have hr : absArea E halfLine=α*absArea V halfLine := by
    rw [hAe,hAv]; exact delayedPIGain_balance hα hδ
  have hg := paper_general_plant hpid.plant α 1 hα (by linarith) firstOrder_transfer_dc (by norm_num)
  have hc := hg.2.2.2.2.1.mpr ⟨hnE,hnV,hr⟩
  obtain ⟨hae,hav⟩ := hg.2.2.2.2.2 hc
  refine ⟨E,V,hpid,hae,hav,hc,hshape.1,hshape.2.1,hshape.2.2,?_⟩
  intro e v hp
  rw [hc]
  exact (paper_general_plant hp α 1 hα (by linarith) firstOrder_transfer_dc (by norm_num)).2.2.2.1

-- @paper-step thm:pid_explicit_family/no_positive_PI_attains_on_the_additional_interval
theorem explicitPID_no_PI {α δ : ℝ} (hα : 0<α) (hδ : 1/α<δ) :
    ¬∃ x r : ℝ, 0<x ∧ 0<r ∧ ∃ E V : ℝ → ℝ, IdealPIResponse x r δ E V ∧
      miace α E V halfLine=(1+δ)*minimum α := by
  intro hh
  have hd : 0≤δ := le_trans (one_div_pos.mpr hα).le hδ.le
  have hr := (paper_delayed_PI_attainment_iff hα hd).mp hh
  have hm : delayedPIMaxDelay α≤1/α := min_le_left _ _
  linarith

-- @paper-step thm:pid_explicit_family/paper_theorem11_all_clauses
theorem paper_explicit_PID_family {α δ : ℝ} (hα : Real.exp 1<α) (hδ : 1/α<δ)
    (hrange : δ≤min (1/Real.exp 1) (Real.exp 1/(α+1-Real.exp 1))) :
    let i := delayedPIGain α δ
    let ρ := 1-i
    let ell := ρ/i
    (0< i+ρ^2 ∧ 0< i ∧ 0< i*ρ^2 ∧ 0<ρ) ∧
    PIDInternallyExponentiallyStable i ρ ell δ ∧
    (∃ E V : ℝ → ℝ, FilteredPIDResponse (i+ρ^2) i (i*ρ^2) ρ δ E V ∧
      absArea E halfLine=α*(1+δ)/(1+α) ∧ absArea V halfLine=(1+δ)/(1+α) ∧
      miace α E V halfLine=(1+δ)*minimum α ∧
      MonotoneOn (fun t => 1-E t) (Ici 0) ∧ 1-E 0=0 ∧
      Tendsto (fun t => 1-E t) atTop (𝓝 1) ∧
      ∀ e v : ℝ → ℝ, TransferResponse e v (fun p => 1/(1+p)) δ →
        miace α E V halfLine≤miace α e v halfLine) ∧
    ¬∃ x r : ℝ, 0<x ∧ 0<r ∧ ∃ E V : ℝ → ℝ, IdealPIResponse x r δ E V ∧
      miace α E V halfLine=(1+δ)*minimum α := by
  have ha : 0<α := lt_trans (Real.exp_pos _) hα
  have hd := explicitPID_data hα hδ (hrange.trans (min_le_left _ _)) (hrange.trans (min_le_right _ _))
  have hc := explicitPID_controller_coefficients hd
  exact ⟨⟨hc.1,hd.gain_pos,hc.2.1,(explicitPID_order hd).1⟩,
    explicitPID_internal_stability hd,explicitPID_optimal_response ha hd,explicitPID_no_PI ha hδ⟩

end MIACE
