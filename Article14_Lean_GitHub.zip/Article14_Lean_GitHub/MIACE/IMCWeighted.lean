import MIACE.LagEvolution
import MIACE.HistoryStability

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:complete_robust/filter_ae_invariance
theorem filterAction_congr (F : IMCFilter) {f g : ℝ → ℝ} (he : f=ᵐ[volume] g) :
    filterAction F f=ᵐ[volume] filterAction F g := by
  have hs := (measurePreserving_sub_right (volume : Measure ℝ) F.delay).quasiMeasurePreserving.tendsto_ae.eventually he
  have hc := convolution_congr (ContinuousLinearMap.lsmul ℝ ℝ)
    (EventuallyEq.rfl (f := lagKernel F.timeConstant)) he
  filter_upwards [he,hs] with t ht hst
  simp only [filterAction,ht,shift,hst,hc]

-- @paper-step thm:complete_robust/filter_actual_L1_bound
theorem filterAction_absArea (F : IMCFilter) {g : ℝ → ℝ} (hg : Integrable g) :
    absArea (filterAction F g) volume≤filterGain F*absArea g volume := by
  let z := hg.toL1 g
  have he := (filterOp_coe F z).trans (filterAction_congr F hg.coeFn_toL1)
  have hn : ‖filterOp F z‖=absArea (filterAction F g) volume := by
    rw [L1.norm_eq_integral_norm]
    exact integral_congr_ae (he.mono (fun t ht => by change ‖filterOp F z t‖=|filterAction F g t|; rw [ht,Real.norm_eq_abs]))
  have hz : ‖z‖=absArea g volume := by
    change ‖hg.toL1 g‖=absArea g volume
    rw [L1.norm_of_fun_eq_integral_norm]
    rfl
  have hb := ((filterOp F).le_opNorm z).trans
    (mul_le_mul_of_nonneg_right (filterOp_bound F) (norm_nonneg z))
  rwa [hn,hz] at hb

-- @paper-step thm:complete_robust/filter_operator_causality
theorem filterOp_causal (F : IMCFilter) {g : RealL1} (hg : Causal g) :
    Causal (filterOp F g) :=
  causal_congr (filterAction_causal F hg) (filterOp_coe F g).symm

-- @paper-step thm:complete_robust/filter_operator_transform
theorem filterOp_laplace (F : IMCFilter) {g : RealL1} (hg : Causal g)
    {p : ℝ} (hp : 0≤p) :
    laplace (filterOp F g) p=filterTransfer F p*laplace g p := by
  rw [laplace_congr_ae (filterOp_coe F g)]
  exact filterAction_laplace F (L1.integrable_coeFn g) hg hp

-- @paper-step thm:complete_robust/filter_weighted_state_gain
theorem filterAction_weightedControl (F : IMCFilter) {η C D : ℝ}
    (hK : WeightedControl η (lagKernel F.timeConstant) C) {g : ℝ → ℝ}
    (hg : WeightedControl η g D) :
    WeightedControl η (filterAction F g)
      ((|F.direct|+|F.delayed| *Real.exp (η*F.delay)+|F.residue| *C)*D) := by
  have hh := weightedControl_add
    (weightedControl_add (weightedControl_smul hg F.direct)
      (weightedControl_smul (weightedControl_shift hg F.delay) F.delayed))
    (weightedControl_smul (weightedControl_convolution hK hg) F.residue)
  convert hh using 1 <;> first | rfl | (ext t; simp only [filterAction]; ring) | ring

-- @paper-step thm:complete_robust/finite_cascade_exponential_moment
theorem cascadeKernel_weightedControl (ss : List ℝ) {η : ℝ} (hη : η<1)
    (hs : ∀ σ∈ss, 0<σ ∧ η<1/σ) :
    ∃ C : ℝ, WeightedControl η (cascadeKernel ss) C := by
  induction ss with
  | nil =>
    have hh := lagKernel_weightedControl (by norm_num : (0 : ℝ)<1) (by simpa using hη)
    simpa [cascadeKernel,unitLagImpulse_eq_lagKernel] using hh
  | cons σ ss ih =>
    obtain ⟨C,hC⟩ := lagKernel_weightedControl (hs σ (by simp)).1 (hs σ (by simp)).2
    obtain ⟨D,hD⟩ := ih (fun r hr => hs r (by simp [hr]))
    exact ⟨C*D,weightedControl_convolution hC hD⟩

-- @paper-step thm:complete_robust/normalized_cascade_half_weight
theorem normalized_cascade_weightedControl (ss : List ℝ)
    (hs : ∀ σ∈ss, 0<σ ∧ σ≤1) :
    ∃ C : ℝ, WeightedControl (1/2) (cascadeKernel ss) C := by
  apply cascadeKernel_weightedControl ss (by norm_num)
  intro σ hσ
  have hh := hs σ hσ
  refine ⟨hh.1,?_⟩
  apply (lt_div_iff₀ hh.1).mpr
  linarith

-- @paper-step thm:complete_robust/delay_mismatch_weighted_control
theorem delay_mismatch_weightedControl (ss : List ℝ) {η C δ ε : ℝ}
    (hK : WeightedControl η (cascadeKernel ss) C) :
    WeightedControl η (fun t => shift (δ+ε) (cascadeKernel ss) t-shift δ (cascadeKernel ss) t)
      ((Real.exp (η*(δ+ε))+Real.exp (η*δ))*C) := by
  have hh := weightedControl_add (weightedControl_shift hK (δ+ε))
    (weightedControl_smul (weightedControl_shift hK δ) (-1))
  simp only [abs_neg,abs_one,one_mul] at hh
  convert hh using 1 <;> first | rfl | (ext t; simp only [filterAction]; ring) | ring

-- @paper-step thm:complete_robust/delay_mismatch_actual_small_gain
theorem delay_mismatch_filter_bound (F : IMCFilter) (ss : List ℝ)
    (hs : ∀ σ∈ss, 0<σ) (δ ε : ℝ) :
    absArea (filterAction F (fun t => shift (δ+ε) (cascadeKernel ss) t-shift δ (cascadeKernel ss) t)) volume
      ≤2*filterGain F*(1-Real.exp (-|ε|)) := by
  have hK := (cascadeKernel_properties ss hs).1
  have hb := filterAction_absArea F ((shift_integrable (δ+ε) hK).sub (shift_integrable δ hK))
  have hf : 0≤filterGain F := by unfold filterGain; positivity
  have hm := mul_le_mul_of_nonneg_left (cascade_delay_error_norm ss hs δ ε) hf
  exact hb.trans (by convert hm using 1 <;> ring)

end MIACE
