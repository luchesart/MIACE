import MIACE.FiniteHistory

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Matrix

-- @paper-step thm:pid_two_rate_optimum/unrestricted_physical_history_uniqueness
theorem pid_history_unique {i ρ ell δ : ℝ} {φ x X : ℝ → Fin 3 → ℝ}
    (hρ : ρ≠0) (hρ1 : ρ≠1) (hδ : 0≤δ)
    (h : PIDHistoryEvolution i ρ ell δ φ x) (h' : PIDHistoryEvolution i ρ ell δ φ X) :
    ∀ t, 0≤t → x t=X t := by
  have he := reduced_evolution_unique hδ (pid_evolution_reduce hρ h) (pid_evolution_reduce hρ h')
  let c := fun t => x t 1-X t 1
  have hc : ∀ T, 0≤T → AbsolutelyContinuousOnInterval c 0 T :=
    fun T hT => (h.ac_state 1 T hT).sub (h'.ac_state 1 T hT)
  have hc0 : c 0=0 := by dsimp [c]; rw [h.initial,h'.initial]; ring
  have hd : ∀ᵐ t, 0<t → deriv c t=-c t-(0 : ℝ) := by
    filter_upwards [h.integrator,h'.integrator] with t ht ht' hp
    have hh := ((ht hp).sub (ht' hp)).deriv
    change deriv c t=-x t 0-(-X t 0) at hh
    rw [hh]
    have hb := (he t hp.le).2
    change x t 0-x t 1=X t 0-X t 1 at hb
    dsimp [c]
    linarith
  intro t ht
  have hz := pidStableState_unique hc hd ht
  have hcEq : x t 1=X t 1 := by
    rw [hc0] at hz
    apply sub_eq_zero.mp
    simpa [pidStableState,lag,c] using hz
  have ha := (he t ht).1
  have hb := (he t ht).2
  change x t 1+(1-ρ)*x t 2=X t 1+(1-ρ)*X t 2 at ha
  change x t 0-x t 1=X t 0-X t 1 at hb
  have hden : 1-ρ≠0 := sub_ne_zero.mpr hρ1.symm
  have hζ : x t 2=X t 2 := mul_left_cancel₀ hden (by linarith)
  ext k
  fin_cases k
  · change x t 0=X t 0
    linarith
  · exact hcEq
  · exact hζ

-- @paper-step thm:pid_two_rate_optimum/uniform_transport_history_control
theorem historyInput_weightedControl {w : ℝ → ℝ} (hw : Continuous w)
    {δ η M : ℝ} (hδ : 0≤δ) (hη : 0≤η) (hM : 0≤M)
    (hb : ∀ s∈Icc (-δ) 0, |w s|≤M) :
    WeightedControl η (historyInput δ w) ((δ+1)*Real.exp (η*δ)*M) := by
  have hE : 0≤Real.exp (η*δ)*M := mul_nonneg (Real.exp_nonneg _) hM
  refine ⟨by positivity,historyInput_weighted_integrable hw δ η,?_,?_⟩
  · have hh := historyInput_weighted_bound hw hδ hη hM hb
    nlinarith
  · apply ae_of_all
    intro t
    by_cases ht : t∈Ico (0 : ℝ) δ
    · simp only [expWeight,historyInput,indicator_of_mem ht,abs_mul,abs_of_pos (Real.exp_pos _)]
      have hh := mul_le_mul (Real.exp_le_exp.mpr (mul_le_mul_of_nonneg_left ht.2.le hη))
        (hb (t-δ) ⟨by linarith [ht.1],by linarith [ht.2]⟩) (abs_nonneg _) (Real.exp_nonneg _)
      nlinarith [mul_nonneg hδ hE]
    · simp [expWeight,historyInput,ht,show 0≤(δ+1)*Real.exp (η*δ)*M by positivity]

-- @paper-step thm:pid_two_rate_optimum/continuous_history_has_finite_norm
theorem history_bound_exists {φ : ℝ → Fin 3 → ℝ}
    (hφ : ∀ k, Continuous (fun t => φ t k)) {δ : ℝ} (hδ : 0≤δ) :
    ∃ M : ℝ, 0≤M ∧ ∀ s∈Icc (-δ) 0, ∀ k, |φ s k|≤M := by
  let f := fun s => ∑ k : Fin 3, |φ s k|
  have hf : Continuous f := by
    apply continuous_finsetSum
    intro k hk
    exact (hφ k).abs
  obtain ⟨u,hu,hm⟩ := isCompact_Icc.exists_isMaxOn
    (nonempty_Icc.mpr (by linarith : -δ≤0)) hf.continuousOn
  refine ⟨f u,Finset.sum_nonneg (fun k _ => abs_nonneg _),?_⟩
  intro s hs k
  have hk : |φ s k|≤f s := Finset.single_le_sum (fun j _ => abs_nonneg (φ s j)) (Finset.mem_univ k)
  exact hk.trans (hm hs)

/-- All continuous histories, with a unique ordinary evolution and constants
    η,C independent of that history. The norm is the maximum coordinate norm
    on the entire transport interval [-δ,0]. -/
def PIDInternallyExponentiallyStable (i ρ ell δ : ℝ) : Prop :=
  ∃ η C : ℝ, 0<η ∧ 0<C ∧ ∀ φ : ℝ → Fin 3 → ℝ,
    (∀ k, ContinuousOn (fun t => φ t k) (Icc (-δ) 0)) → ∃ x : ℝ → Fin 3 → ℝ,
      PIDHistoryEvolution i ρ ell δ φ x ∧
      (∀ X, PIDHistoryEvolution i ρ ell δ φ X → ∀ t, 0≤t → X t=x t) ∧
      ∀ M : ℝ, 0≤M → (∀ s∈Icc (-δ) 0, ∀ k, |φ s k|≤M) →
        ∀ t, 0≤t → ∀ k, |x t k|≤C*M*Real.exp (-η*t)

-- @paper-step thm:pid_two_rate_optimum/uniform_physical_history_exponential_estimate
theorem twoRate_bounded_history_exists {i ρ ell l m δ : ℝ} (h : TwoRateData i ρ ell l m δ) :
    ∃ η C : ℝ, 0<η ∧ 0<C ∧ ∀ (φ : ℝ → Fin 3 → ℝ),
      (∀ k, Continuous (fun t => φ t k)) → ∀ M : ℝ, 0≤M →
      (∀ s∈Icc (-δ) 0, ∀ k, |φ s k|≤M) → ∃ x : ℝ → Fin 3 → ℝ,
        PIDHistoryEvolution i ρ ell δ φ x ∧ ∀ t, 0≤t → ∀ k,
          |x t k|≤C*M*Real.exp (-η*t) := by
  obtain ⟨η,D,hη,hηhalf,hD,hr⟩ := reduced_evolution_exists h
  let G := |i*(1+ell-ρ)+(i*(ell-ρ)*(1-ρ))/ρ|+|i|+|(i*(ell-ρ)*(1-ρ))/ρ|
  let B := (δ+1)*Real.exp (η*δ)*G
  let S := 3+|1-ρ|+B
  let T := 1+2*D*S
  let C := T+T/|1-ρ|
  have hG : 0≤G := by dsimp [G]; positivity
  have hδ := h.delay_nonneg
  have hB : 0≤B := by dsimp [B]; positivity
  have hS : 0<S := by dsimp [S]; positivity
  have hT : 0<T := by dsimp [T]; positivity
  have hden : 0 < |1-ρ| := abs_pos.mpr (ne_of_gt (sub_pos.mpr h.filter_lt_one))
  have hC : 0<C := by dsimp [C]; positivity
  have hTC : T≤C := by dsimp [C]; linarith [show 0≤T/|1-ρ| by positivity]
  have hTdivC : T/|1-ρ|≤C := by dsimp [C]; linarith
  refine ⟨η,C,hη,hC,?_⟩
  intro φ hφ M hM hb
  have hzero : (0 : ℝ)∈Icc (-δ) 0 := ⟨by linarith,le_rfl⟩
  have h0 := hb 0 hzero
  have hw : Continuous (pidCommand i ρ ell φ) := by
    unfold pidCommand pidHomogeneousCommand
    exact (((hφ 0).const_mul _).add ((hφ 1).const_mul _)).add
      (((hφ 0).neg.sub (hφ 2)).const_mul _)
  have hhist : WeightedControl η (pidHistoryForcing i ρ ell δ φ) (B*M) := by
    have hh := historyInput_weightedControl hw hδ hη.le (mul_nonneg hG hM)
      (fun s hs => pidHomogeneousCommand_bound (i*(1+ell-ρ)) i (i*(ell-ρ)*(1-ρ)) ρ hM (φ s) (hb s hs))
    convert hh using 1 <;> dsimp [B,pidHistoryForcing] <;> ring
  have hM' : B*M≤S*M := mul_le_mul_of_nonneg_right (by dsimp [S]; linarith [abs_nonneg (1-ρ)]) hM
  have ha0 : |pidReduce ρ (φ 0) 0|≤S*M := by
    change |φ 0 1+(1-ρ)*φ 0 2|≤_
    have hh := abs_add_le (φ 0 1) ((1-ρ)*φ 0 2)
    rw [abs_mul] at hh
    have hmul := mul_le_mul_of_nonneg_left (h0 2) (abs_nonneg (1-ρ))
    dsimp [S]
    nlinarith [h0 1,mul_nonneg hB hM]
  have hb0 : |pidReduce ρ (φ 0) 1|≤S*M := by
    change |φ 0 0-φ 0 1|≤_
    have hh := abs_sub_le (φ 0 0) 0 (φ 0 1)
    simp only [sub_zero,zero_sub,abs_neg] at hh
    dsimp [S]
    nlinarith [h0 0,h0 1,mul_nonneg (abs_nonneg (1-ρ)) hM,mul_nonneg hB hM]
  obtain ⟨a,b,he,ha,hb'⟩ := hr (pidHistoryForcing i ρ ell δ φ)
    (pidReduce ρ (φ 0) 0) (pidReduce ρ (φ 0) 1) (S*M)
    (historyInput_causal _ _) (weightedControl_mono hhist hM') ha0 hb0
  let x := fun t => pidRestore ρ ![a t,b t,pidStableState (φ 0 1) b t]
  refine ⟨x,pid_evolution_restore (ne_of_gt h.filter_pos) (ne_of_lt h.filter_lt_one) φ he,?_⟩
  have hadec := weightedControl_continuous_decay he.continuous_a ha
  have hbdec := weightedControl_continuous_decay he.continuous_b hb'
  have hx := pidRestore_decay (ne_of_lt h.filter_lt_one) (by linarith : η≤1)
    (φ 0 1) hb'.integrable hadec hbdec
  have hcc : |φ 0 1|+(∫ s, |expWeight η (causalize b) s|)≤M+D*(S*M) := add_le_add (h0 1) hb'.area
  intro t ht k
  obtain ⟨hy,hz,hζ⟩ := hx t ht
  have hsum : D*(S*M)+(|φ 0 1|+∫ s, |expWeight η (causalize b) s|)≤T*M := by dsimp [T]; nlinarith
  have hcsmall : |φ 0 1|+(∫ s, |expWeight η (causalize b) s|)≤T*M := by
    dsimp [T]; nlinarith [mul_nonneg hD.le (mul_nonneg hS.le hM)]
  have hcommon : T*M≤C*M := mul_le_mul_of_nonneg_right hTC hM
  fin_cases k
  · exact hy.trans (mul_le_mul_of_nonneg_right (hsum.trans hcommon) (Real.exp_nonneg _))
  · exact hz.trans (mul_le_mul_of_nonneg_right (hcsmall.trans hcommon) (Real.exp_nonneg _))
  · apply hζ.trans
    apply mul_le_mul_of_nonneg_right _ (Real.exp_nonneg _)
    calc
      _ ≤ (T*M)/|1-ρ| := div_le_div_of_nonneg_right hsum hden.le
      _ = (T/|1-ρ|)*M := by ring
      _ ≤ C*M := mul_le_mul_of_nonneg_right hTdivC hM

-- @paper-step thm:pid_two_rate_optimum/all_history_internal_exponential_stability
theorem twoRate_internal_exponential_stability {i ρ ell l m δ : ℝ}
    (h : TwoRateData i ρ ell l m δ) : PIDInternallyExponentiallyStable i ρ ell δ := by
  obtain ⟨η,C,hη,hC,hr⟩ := twoRate_bounded_history_exists h
  refine ⟨η,C,hη,hC,?_⟩
  intro φ hφ
  obtain ⟨ψ,hψ,heψ⟩ := history_continuous_extension h.delay_nonneg hφ
  obtain ⟨M₀,hM₀,hb₀⟩ := history_bound_exists hψ h.delay_nonneg
  obtain ⟨x,hxψ,_⟩ := hr ψ hψ M₀ hM₀ hb₀
  have hx : PIDHistoryEvolution i ρ ell δ φ x :=
    pid_history_evolution_congr h.delay_nonneg heψ hxψ
  have hu := fun {X} (hX : PIDHistoryEvolution i ρ ell δ φ X) =>
    pid_history_unique (ne_of_gt h.filter_pos) (ne_of_lt h.filter_lt_one) h.delay_nonneg hX hx
  refine ⟨x,hx,(fun X hX => hu hX),?_⟩
  intro M hM hb t ht k
  have hbψ : ∀ s∈Icc (-δ) 0, ∀ j, |ψ s j|≤M := by
    intro s hs j
    rw [heψ s hs]
    exact hb s hs j
  obtain ⟨X,hXψ,hbound⟩ := hr ψ hψ M hM hbψ
  have hX := pid_history_evolution_congr h.delay_nonneg heψ hXψ
  rw [← hu hX t ht]
  exact hbound t ht k

end MIACE
