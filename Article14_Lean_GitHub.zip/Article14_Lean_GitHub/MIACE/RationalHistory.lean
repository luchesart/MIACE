import MIACE.RemainderStates

/-! Full rational feedback realization. The B storage states of both the
controller and plant are retained. Only the command enters the transport
line, so its finite history is the complete delay datum. -/
namespace MIACE
open MeasureTheory Filter Set Polynomial
open scoped Topology Convolution

structure RationalHistory where
  commandInitial : ℝ
  controllerInitial : ℕ → ℝ
  plantInitial : ℕ → ℝ
  outputInitial : ℝ
  past : ℝ → ℝ

noncomputable def rationalDelayed (δ : ℝ) (H : RationalHistory) (w : ℝ → ℝ) : ℝ → ℝ :=
  fun t => historyInput δ H.past t+shift δ (causalize w) t
noncomputable def rationalIState (r : ℕ → ℝ) (δ : ℝ) (H : RationalHistory)
    (w : ℝ → ℝ) (j : ℕ) : ℝ → ℝ := remainderFilter r δ H.controllerInitial w j
noncomputable def rationalBState (r : ℕ → ℝ) (δ : ℝ) (H : RationalHistory)
    (w : ℝ → ℝ) (j : ℕ) : ℝ → ℝ :=
  serialState (fun j => 1/r j) H.plantInitial (rationalDelayed δ H w) (j+1)
noncomputable def rationalOutput (r : ℕ → ℝ) (n : ℕ) (δ : ℝ) (H : RationalHistory)
    (w : ℝ → ℝ) : ℝ → ℝ := lagState 1 H.outputInitial (rationalBState r δ H w n)
noncomputable def rationalFree (r : ℕ → ℝ) (n : ℕ) (δ : ℝ) (H : RationalHistory) : ℝ → ℝ :=
  causalize (fun t => remainderFilter r δ H.controllerInitial (fun _ => 0) n t-
    serialState (fun j => 1/r j) H.plantInitial (historyInput δ H.past) (n+1) t)

structure RationalHistoryEvolution (r : ℕ → ℝ) (n : ℕ) (δ a c : ℝ)
    (H : RationalHistory) (w : ℝ → ℝ) : Prop where
  continuous : Continuous w
  ac : ∀ T, 0≤T → AbsolutelyContinuousOnInterval w 0 T
  initial : w 0=H.commandInitial
  ode : ∀ᵐ t, 0<t → HasDerivAt w
    ((-c*w t+rationalIState r δ H w n t-rationalBState r δ H w n t)/a) t

-- @paper-step thm:n_construction/causal_extension_actual_transform
theorem laplace_causalize (f : ℝ → ℝ) (p : ℝ) : laplace (causalize f) p=laplace f p :=
  laplace_congr_halfLine (causalize_halfLine f) p

-- @paper-step thm:n_construction/full_state_to_compact_forcing_identity
theorem rational_history_reduction (r : ℕ → ℝ) (n : ℕ) {δ : ℝ} (hr : ∀ j≤n, 0<r j)
    (hδ : 0≤δ) (H : RationalHistory) (hHi : Integrable (historyInput δ H.past))
    {w : ℝ → ℝ} (hwi : Integrable (causalize w)) :
    causalize (fun t => rationalIState r δ H w n t-rationalBState r δ H w n t)=ᵐ[volume]
      (fun t => rationalFree r n δ H t-
        (-1 : ℝ)^(n+1)*(compactKernel (remainderJ r n δ) δ ⋆ causalize w) t) := by
  have hw : Integrable w halfLine :=
    (hwi.mono_measure (Measure.restrict_le_self)).congr (causalize_halfLine w)
  have hH : Integrable (historyInput δ H.past) halfLine := hHi.mono_measure Measure.restrict_le_self
  have hdi : Integrable (rationalDelayed δ H w) := hHi.add (shift_integrable δ hwi)
  have hd : Integrable (rationalDelayed δ H w) halfLine := hdi.mono_measure Measure.restrict_le_self
  have hz : Integrable (fun _ : ℝ => (0 : ℝ)) halfLine := integrable_zero _ _ _
  have hs : ∀ j<n+1, 0<1/r j := fun j hj => one_div_pos.mpr (hr j (by omega))
  have hI := remainderFilter_integrable hw r δ H.controllerInitial n hr
  have hIz := remainderFilter_integrable hz r δ H.controllerInitial n hr
  have hB := serialState_integrable hd _ H.plantInitial (n+1) hs
  have hBh := serialState_integrable hH _ H.plantInitial (n+1) hs
  have hF : Integrable (rationalFree r n δ H) := causalize_integrable (hIz.sub hBh)
  have hK := compactKernel_integrable (remainderJ_continuous r n δ) δ
  have hKi := hK.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hwi
  have hKc := compactKernel_causal (remainderJ r n δ) δ
  have hconvC : Causal (compactKernel (remainderJ r n δ) δ ⋆ causalize w) :=
    ae_of_all _ (convolution_causal hKc (causalize_causal w))
  apply causal_laplace_ext (causalize_integrable (hI.sub hB))
    (hF.sub (hKi.const_mul _)) (causalize_causal _) (by
      have hFc : Causal (rationalFree r n δ H) := causalize_causal _
      filter_upwards [hFc,hconvC] with t ht hs hn
      simp [ht hn,hs hn])
  intro p hp
  have hdT : laplace (rationalDelayed δ H w) p=
      laplace (historyInput δ H.past) p+Real.exp (-δ*p)*laplace w p := by
    have hh := laplace_linear hHi (shift_integrable δ hwi) 1 1 hp.le
    simp only [one_mul] at hh
    change laplace (rationalDelayed δ H w) p=_ at hh
    rw [hh,laplace_shift (causalize_causal w) hδ p,laplace_causalize]
  rw [laplace_causalize]
  have hleft := laplace_linear_half hI hB 1 (-1) hp.le
  simp only [one_mul,neg_one_mul] at hleft
  change laplace (fun t => rationalIState r δ H w n t-rationalBState r δ H w n t) p=_ at hleft
  change laplace (fun t => rationalIState r δ H w n t-rationalBState r δ H w n t) p = _
  rw [hleft]
  have hright := laplace_linear hF hKi 1 (-((-1 : ℝ)^(n+1))) hp.le
  simp only [one_mul,neg_mul] at hright
  change _ = laplace (fun t => rationalFree r n δ H t + -( (-1 : ℝ)^(n+1)*(compactKernel (remainderJ r n δ) δ ⋆ causalize w) t)) p
  rw [hright,causal_convolution_laplace hK hwi hKc (causalize_causal w) hp.le,
    compactKernel_laplace _ hδ,laplace_causalize]
  have hFT := laplace_linear_half hIz hBh 1 (-1) hp.le
  simp only [one_mul,neg_one_mul] at hFT
  have hFT' : laplace (rationalFree r n δ H) p=
      laplace (remainderFilter r δ H.controllerInitial (fun _ => 0) n) p-
      laplace (serialState (fun j => 1/r j) H.plantInitial (historyInput δ H.past) (n+1)) p := by
    rw [rationalFree,laplace_causalize]; simpa only [sub_eq_add_neg] using hFT
  rw [hFT']
  change laplace (remainderFilter r δ H.controllerInitial w n) p+ -
    laplace (serialState (fun j => 1/r j) H.plantInitial (rationalDelayed δ H w) (n+1)) p=_
  rw [remainderFilter_laplace hw r δ H.controllerInitial n hr hp.le,
    serialB_laplace hd r H.plantInitial n hr hp.le,
    serialB_laplace hH r H.plantInitial n hr hp.le,hdT]
  have hex := exact_delay_remainder_real r n δ p (fun j hj => ne_of_gt (hr j hj))
  have heq : remainderTransform r n δ p=compactExpMoment (remainderJ r n δ) δ (-p) := by
    unfold remainderTransform compactExpMoment
    congr 1
  rw [heq] at hex
  field_simp [ne_of_gt (remainderB_eval_pos r n hr hp.le)]
  rw [neg_mul] at hex
  linear_combination -(laplace w p)*hex

-- @paper-step thm:n_construction/ordinary_compact_solution_restores_rational_feedback
theorem compact_restores_rational (r : ℕ → ℝ) (n : ℕ) {δ a c : ℝ}
    (hr : ∀ j≤n, 0<r j) (hδ : 0≤δ) (H : RationalHistory)
    (hHi : Integrable (historyInput δ H.past)) {w : ℝ → ℝ}
    (hwi : Integrable (causalize w))
    (hw : CompactForcedEvolution (remainderJ r n δ) δ a c ((-1 : ℝ)^(n+1))
      H.commandInitial (rationalFree r n δ H) w) : RationalHistoryEvolution r n δ a c H w := by
  refine ⟨hw.continuous,(fun T _ => hw.ac 0 T),hw.initial,?_⟩
  filter_upwards [hw.ode,rational_history_reduction r n hr hδ H hHi hwi] with t ht he ht0
  have hh := ht ht0
  simp only [causalize,indicator_of_mem (show t∈Ici (0 : ℝ) from ht0.le)] at he
  convert hh using 1
  congr 1
  change rationalIState r δ H w n t-rationalBState r δ H w n t = rationalFree r n δ H t-(-1 : ℝ)^(n+1)*(compactKernel (remainderJ r n δ) δ ⋆ causalize w) t at he
  linarith

end MIACE
