import MIACE.ExplicitPIDKernel

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:pid_explicit_family/exponential_integral_over_the_delay_window
theorem exp_delay_box_integral {δ t : ℝ} (hδ : 0≤δ) (ht : 0≤t) (r : ℝ) :
    (∫ s in (0 : ℝ)..t, Real.exp (r*s)*compactKernel (fun _ => 1) δ s)=
      ∫ s in (0 : ℝ)..min t δ, Real.exp (r*s) := by
  have he : (fun s => Real.exp (r*s)*compactKernel (fun _ => 1) δ s)=
      (Icc (0 : ℝ) δ).indicator (fun s => Real.exp (r*s)) := by
    funext s
    by_cases hs : s∈Icc (0 : ℝ) δ <;> simp [compactKernel,hs]
  rw [he,intervalIntegral.integral_of_le ht,← integral_Icc_eq_integral_Ioc,
    integral_indicator measurableSet_Icc,Measure.restrict_restrict measurableSet_Icc,
    Icc_inter_Icc,max_self,min_comm δ t,integral_Icc_eq_integral_Ioc,
    ← intervalIntegral.integral_of_le (le_min ht hδ)]

-- @paper-step thm:pid_explicit_family/actual_box_convolution_with_an_exponential
theorem exp_delay_box_convolution {δ t r : ℝ} (hδ : 0≤δ) (ht : 0≤t) (hr : 0<r) :
    (expKernel r ⋆ compactKernel (fun _ => 1) δ) t=
      (Real.exp (-r*(t-min t δ))-Real.exp (-r*t))/r := by
  rw [expKernel_convolution_formula r (compactKernel_causal _ δ) ht,
    exp_delay_box_integral hδ ht r]
  have hi := finite_exp_integral (neg_ne_zero.mpr (ne_of_gt hr)) (min t δ)
  simp only [neg_neg] at hi
  rw [hi]
  have he : Real.exp (-r*t)*Real.exp (r*min t δ)=Real.exp (-r*(t-min t δ)) := by
    rw [← Real.exp_add]; congr 1; ring
  field_simp
  simp only [neg_mul] at he
  nlinarith only [he]

-- @paper-step thm:pid_explicit_family/actual_box_Laplace_transform
theorem delay_box_laplace {δ p : ℝ} (hδ : 0≤δ) (hp : 0<p) :
    laplace (compactKernel (fun _ => 1) δ) p=(1-Real.exp (-δ*p))/p := by
  rw [compactKernel_laplace _ hδ]
  simp only [compactExpMoment,mul_one]
  rw [finite_exp_integral (ne_of_gt hp)]
  simp only [neg_mul,mul_comm δ p]

end MIACE
