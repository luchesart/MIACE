import MIACE.CascadeTransfer

/-! Stage 13. Concrete causal filters: feedthrough, a finite transport,
and one stable lag. The two filters in the paper are instances. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

noncomputable def shiftOp (δ : ℝ) : RealL1 →L[ℝ] RealL1 :=
  (Lp.compMeasurePreservingₗᵢ ℝ (fun t : ℝ => t-δ)
    (measurePreserving_sub_right (volume : Measure ℝ) δ)).toContinuousLinearMap

-- @paper-step thm:complete_robust/actual_translation_operator
theorem shiftOp_coe (δ : ℝ) (g : RealL1) :
    (shiftOp δ g : ℝ → ℝ)=ᵐ[volume] shift δ g :=
  Lp.coeFn_compMeasurePreserving g (measurePreserving_sub_right (volume : Measure ℝ) δ)

-- @paper-step thm:complete_robust/translation_operator_norm
theorem shiftOp_norm (δ : ℝ) : ‖shiftOp δ‖≤1 := by
  apply ContinuousLinearMap.opNorm_le_bound _ zero_le_one
  intro g
  simpa [shiftOp] using (le_refl ‖g‖)

structure IMCFilter where
  direct : ℝ
  delayed : ℝ
  residue : ℝ
  delay : ℝ
  timeConstant : ℝ
  delay_nonneg : 0≤delay
  timeConstant_pos : 0<timeConstant

noncomputable def filterAction (F : IMCFilter) (g : ℝ → ℝ) (t : ℝ) : ℝ :=
  F.direct*g t+F.delayed*shift F.delay g t+F.residue*(lagKernel F.timeConstant ⋆ g) t
noncomputable def filterOp (F : IMCFilter) : RealL1 →L[ℝ] RealL1 :=
  F.direct • (1 : RealL1 →L[ℝ] RealL1)+F.delayed • shiftOp F.delay+
    F.residue • convOp (lagKernel_properties F.timeConstant_pos).1
noncomputable def filterGain (F : IMCFilter) : ℝ := |F.direct|+|F.delayed|+|F.residue|
noncomputable def filterTransfer (F : IMCFilter) (p : ℝ) : ℝ :=
  F.direct+F.delayed*Real.exp (-F.delay*p)+F.residue/(1+F.timeConstant*p)

-- @paper-step thm:complete_robust/filter_operator_ordinary_semantics
theorem filterOp_coe (F : IMCFilter) (g : RealL1) :
    (filterOp F g : ℝ → ℝ)=ᵐ[volume] filterAction F g := by
  change (↑(F.direct • g+F.delayed • shiftOp F.delay g+
    F.residue • convOp (lagKernel_properties F.timeConstant_pos).1 g) : ℝ → ℝ)=ᵐ[volume] _
  filter_upwards [Lp.coeFn_add (F.direct • g+F.delayed • shiftOp F.delay g)
    (F.residue • convOp (lagKernel_properties F.timeConstant_pos).1 g),
    Lp.coeFn_add (F.direct • g) (F.delayed • shiftOp F.delay g),
    Lp.coeFn_smul F.direct g,Lp.coeFn_smul F.delayed (shiftOp F.delay g),
    Lp.coeFn_smul F.residue (convOp (lagKernel_properties F.timeConstant_pos).1 g),
    shiftOp_coe F.delay g,convOp_coe (lagKernel_properties F.timeConstant_pos).1 g]
    with t ht ha hd hb hk hs hc
  simp only [ht,Pi.add_apply,ha,hd,hb,hk,Pi.smul_apply,smul_eq_mul,hs,hc,filterAction]

-- @paper-step thm:complete_robust/filter_operator_total_variation_bound
theorem filterOp_bound (F : IMCFilter) : ‖filterOp F‖≤filterGain F := by
  have hk : ‖convOp (lagKernel_properties F.timeConstant_pos).1‖≤1 := by
    calc
      _ ≤ absArea (lagKernel F.timeConstant) volume := convOp_norm _
      _ = 1 := by rw [positive_kernel_mass (ae_of_all _ (lagKernel_properties F.timeConstant_pos).2.1),
        (lagKernel_properties F.timeConstant_pos).2.2.1]
  have h₁ := norm_add_le (F.direct • (1 : RealL1 →L[ℝ] RealL1)) (F.delayed • shiftOp F.delay)
  have h₂ := norm_add_le (F.direct • (1 : RealL1 →L[ℝ] RealL1)+F.delayed • shiftOp F.delay)
    (F.residue • convOp (lagKernel_properties F.timeConstant_pos).1)
  rw [norm_smul,norm_smul] at h₁
  rw [norm_smul] at h₂
  simp only [Real.norm_eq_abs] at h₁ h₂
  have hi : ‖(1 : RealL1 →L[ℝ] RealL1)‖≤1 := ContinuousLinearMap.norm_id_le
  dsimp [filterOp,filterGain]
  nlinarith [mul_le_mul_of_nonneg_left hi (abs_nonneg F.direct),
    mul_le_mul_of_nonneg_left (shiftOp_norm F.delay) (abs_nonneg F.delayed),
    mul_le_mul_of_nonneg_left hk (abs_nonneg F.residue)]

-- @paper-step thm:complete_attainment/filter_ordinary_integrability
theorem filterAction_integrable (F : IMCFilter) {g : ℝ → ℝ} (hg : Integrable g) :
    Integrable (filterAction F g) :=
  ((hg.const_mul F.direct).add ((shift_integrable F.delay hg).const_mul F.delayed)).add
    (((lagKernel_properties F.timeConstant_pos).1.integrable_convolution
      (ContinuousLinearMap.lsmul ℝ ℝ) hg).const_mul F.residue)

-- @paper-step thm:complete_attainment/filter_causality
theorem filterAction_causal (F : IMCFilter) {g : ℝ → ℝ} (hg : Causal g) :
    Causal (filterAction F g) := by
  filter_upwards [hg,causal_shift hg F.delay_nonneg] with t ht hs hn
  unfold filterAction
  rw [ht hn,hs hn,convolution_causal (lagKernel_properties F.timeConstant_pos).2.2.2 hg t hn]
  ring

-- @paper-step thm:complete_attainment/filter_actual_transform
theorem filterAction_laplace (F : IMCFilter) {g : ℝ → ℝ} (hg : Integrable g)
    (hc : Causal g) {p : ℝ} (hp : 0≤p) :
    laplace (filterAction F g) p=filterTransfer F p*laplace g p := by
  have hI : Integrable (fun t => F.direct*g t+F.delayed*shift F.delay g t) :=
    (hg.const_mul F.direct).add ((shift_integrable F.delay hg).const_mul F.delayed)
  have hh := laplace_linear hI
    ((lagKernel_properties F.timeConstant_pos).1.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hg)
    1 F.residue hp
  simp only [one_mul] at hh
  change laplace (filterAction F g) p=_ at hh
  rw [hh,laplace_linear hg (shift_integrable F.delay hg) F.direct F.delayed hp,
    laplace_shift hc F.delay_nonneg,
    causal_convolution_laplace (lagKernel_properties F.timeConstant_pos).1 hg
      (lagKernel_properties F.timeConstant_pos).2.2.2 hc hp,
    lagKernel_laplace F.timeConstant_pos hp]
  unfold filterTransfer
  ring

noncomputable def exponentialIMC (a : ℝ) (ha : 0<a) : IMCFilter :=
  ⟨1/a,0,1-1/a,0,a,le_rfl,ha⟩
noncomputable def pulseIMC (c T : ℝ) (hT : 0≤T) : IMCFilter :=
  ⟨1+c,-c,0,T,1,hT,zero_lt_one⟩

-- @paper-step thm:complete_attainment/exponential_filter_transfer
theorem exponentialIMC_transfer {a : ℝ} (ha : 0<a) {p : ℝ} (hp : 0≤p) :
    filterTransfer (exponentialIMC a ha) p=(1+p)/(1+a*p) := by
  unfold filterTransfer exponentialIMC
  dsimp only
  field_simp [ne_of_gt ha,ne_of_gt (by positivity : 0<1+a*p)]
  ring

-- @paper-step thm:complete_robust/exponential_filter_gain
theorem exponentialIMC_gain {a : ℝ} (ha : 0<a) (ha1 : a≤1) :
    filterGain (exponentialIMC a ha)=2/a-1 := by
  have hi : (1 : ℝ)≤1/a := (le_div_iff₀ ha).2 (by simpa using ha1)
  simp only [filterGain,exponentialIMC,abs_zero,add_zero,abs_of_nonneg (by positivity : 0≤1/a),
    abs_of_nonpos (show 1-1/a≤0 by linarith)]
  ring

-- @paper-step thm:complete_cap/pulse_filter_transfer
theorem pulseIMC_transfer (c T p : ℝ) (hT : 0≤T) :
    filterTransfer (pulseIMC c T hT) p=1+c-c*Real.exp (-T*p) := by
  simp [filterTransfer,pulseIMC]; ring

-- @paper-step thm:complete_robust/pulse_filter_gain
theorem pulseIMC_gain {c T : ℝ} (hc : 0≤c) (hT : 0≤T) :
    filterGain (pulseIMC c T hT)=1+2*c := by
  simp [filterGain,pulseIMC,abs_of_nonneg hc,abs_of_nonneg (show 0≤1+c by linarith)]
  ring

end MIACE
