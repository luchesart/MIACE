import MIACE.LocalRenewal

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

noncomputable def serialState (σ ξ : ℕ → ℝ) (u : ℝ → ℝ) : ℕ → ℝ → ℝ
  | 0 => u
  | n+1 => lagState (σ n) (ξ n) (serialState σ ξ u n)
noncomputable def serialImpulse (σ : ℕ → ℝ) : ℕ → ℝ → ℝ
  | 0 => lagKernel (σ 0)
  | n+1 => lagKernel (σ (n+1)) ⋆ serialImpulse σ n

def serialRatios (σ : ℕ → ℝ) (n : ℕ) : List ℝ :=
  ((List.range n).map (fun j => σ (j+1))).reverse

-- @paper-step thm:complete_attainment/finite_cascade_local_state_construction
theorem serialState_local {u : ℝ → ℝ} (hu : LocallyIntegrable u volume)
    (σ ξ : ℕ → ℝ) (n : ℕ) : LocallyIntegrable (serialState σ ξ u n) volume := by
  induction n with
  | zero => exact hu
  | succ n ih => exact (lagState_evolution ih (σ n) (ξ n)).1.locallyIntegrable

-- @paper-step thm:complete_attainment/finite_cascade_full_state_ODE
theorem serialState_evolution {u : ℝ → ℝ} (hu : LocallyIntegrable u volume)
    (σ ξ : ℕ → ℝ) (n : ℕ) :
    Continuous (serialState σ ξ u (n+1)) ∧
      LagEvolution (σ n) (ξ n) (serialState σ ξ u n) (serialState σ ξ u (n+1)) :=
  lagState_evolution (serialState_local hu σ ξ n) (σ n) (ξ n)

-- @paper-step thm:complete_attainment/ordinary_lag_input_linearity
theorem lag_add_local {u v : ℝ → ℝ} (hu : LocallyIntegrable u volume)
    (hv : LocallyIntegrable v volume) (σ t : ℝ) :
    lag σ (fun s => u s+v s) t=lag σ u t+lag σ v t := by
  have hui := (locally_integrable_interval hu 0 t).continuousOn_mul
    (by fun_prop : Continuous (fun s : ℝ => Real.exp (s/σ))).continuousOn
  have hvi := (locally_integrable_interval hv 0 t).continuousOn_mul
    (by fun_prop : Continuous (fun s : ℝ => Real.exp (s/σ))).continuousOn
  unfold lag
  simp_rw [mul_add]
  rw [intervalIntegral.integral_add hui hvi]
  ring

-- @paper-step thm:complete_attainment/initial_state_and_forced_state_split
theorem serialState_split {u : ℝ → ℝ} (hu : LocallyIntegrable u volume)
    (σ ξ : ℕ → ℝ) (n : ℕ) :
    serialState σ ξ u n=(fun t => serialState σ ξ (fun _ => 0) n t+ordinaryCascade σ u n t) := by
  induction n with
  | zero => funext t; simp [serialState,ordinaryCascade]
  | succ n ih =>
    funext t
    simp only [serialState,lagState,ih,ordinaryCascade]
    rw [lag_add_local (serialState_local (continuous_const.locallyIntegrable) σ ξ n)
      (ordinaryCascade_local hu σ n)]
    ring

-- @paper-step thm:complete_robust/normalized_cascade_impulse_identification
theorem serialImpulse_eq_cascade (σ : ℕ → ℝ) (hfirst : σ 0=1) (n : ℕ) :
    serialImpulse σ n=cascadeKernel (serialRatios σ n) := by
  induction n with
  | zero => simp [serialImpulse,serialRatios,cascadeKernel,hfirst,unitLagImpulse_eq_lagKernel]
  | succ n ih =>
    simp [serialImpulse,serialRatios,List.range_succ,List.map_append,List.reverse_append,cascadeKernel,ih,
      serialRatios]

-- @paper-step thm:complete_robust/finite_cascade_impulse_properties
theorem serialImpulse_properties (σ : ℕ → ℝ) (n : ℕ) (hσ : ∀ j≤n, 0<σ j) :
    Integrable (serialImpulse σ n) ∧ Causal (serialImpulse σ n) := by
  induction n with
  | zero => exact ⟨(lagKernel_properties (hσ 0 le_rfl)).1,(lagKernel_properties (hσ 0 le_rfl)).2.2.2⟩
  | succ n ih =>
    have hp := lagKernel_properties (hσ (n+1) le_rfl)
    have hh := ih (fun j hj => hσ j (by omega))
    exact ⟨hp.1.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hh.1,
      ae_of_all _ (convolution_causal hp.2.2.2 hh.2)⟩

-- @paper-step thm:complete_attainment/zero_initial_lag_state
 theorem lagState_zero (σ : ℝ) (u : ℝ → ℝ) : lagState σ 0 u=lag σ u := by
  funext t; simp [lagState]

-- @paper-step thm:complete_robust/ordinary_cascade_kernel_representation
theorem ordinaryCascade_kernel {u : ℝ → ℝ} (hu : Integrable u) (huc : Causal u)
    (σ : ℕ → ℝ) (n : ℕ) (hσ : ∀ j≤n, 0<σ j) :
    causalize (ordinaryCascade σ u (n+1))=ᵐ[volume] (serialImpulse σ n ⋆ u) := by
  induction n with
  | zero =>
    have hh := lagState_causal_formula (hσ 0 le_rfl) 0 u
    simpa only [lagState_zero,zero_mul,zero_add,ordinaryCascade,serialImpulse,
      convolution_congr (ContinuousLinearMap.lsmul ℝ ℝ) (EventuallyEq.rfl (f := lagKernel (σ 0)))
        (causalize_eq_ae huc)] using hh
  | succ n ih =>
    have hn : ∀ j≤n, 0<σ j := fun j hj => hσ j (by omega)
    have hs := hσ (n+1) le_rfl
    have hh := lagState_causal_formula hs 0 (ordinaryCascade σ u (n+1))
    simp only [lagState_zero,zero_mul,zero_add] at hh
    have he := convolution_congr (ContinuousLinearMap.lsmul ℝ ℝ)
      (EventuallyEq.rfl (f := lagKernel (σ (n+1)))) (ih hn)
    exact hh.trans ((Filter.EventuallyEq.of_eq he).trans
      (causal_convolution_assoc (lagKernel_properties hs).1 (serialImpulse_properties σ n hn).1 hu
        (lagKernel_properties hs).2.2.2 (serialImpulse_properties σ n hn).2 huc).symm)

-- @paper-step thm:complete_attainment/zero_signal_weighted_control
theorem weightedControl_zero (η : ℝ) : WeightedControl η (fun _ => 0) 0 := by
  have he : expWeight η (fun _ => 0)=(fun _ : ℝ => (0 : ℝ)) := by funext t; simp [expWeight]
  refine ⟨le_rfl,?_,?_,?_⟩
  · rw [he]; exact integrable_zero _ _ _
  · rw [he]; simp
  · rw [he]; simp

-- Every internal storage state is bounded with a constant independent of
-- its initial value and of the forcing, not merely the final output.
-- @paper-step thm:complete_robust/all_cascade_storage_states_decay
theorem serialState_uniform_control (σ : ℕ → ℝ) (n : ℕ) (η : ℝ)
    (hσ : ∀ j<n, 0<σ j ∧ η<1/σ j) :
    ∃ C : ℝ, 0≤C ∧ ∀ M D : ℝ, 0≤M → ∀ ξ : ℕ → ℝ,
      (∀ j<n, |ξ j|≤M) → ∀ u : ℝ → ℝ, WeightedControl η (causalize u) D →
      ∀ j≤n, WeightedControl η (causalize (serialState σ ξ u j)) (C*(M+D)) := by
  induction n with
  | zero =>
    refine ⟨1,zero_le_one,?_⟩
    intro M D hM ξ hξ u hu j hj
    have hj0 : j=0 := by omega
    subst j
    exact weightedControl_mono hu (by nlinarith)
  | succ n ih =>
    obtain ⟨C,hC,hprev⟩ := ih (fun j hj => hσ j (by omega))
    obtain ⟨K,hK⟩ := lagKernel_weightedControl (hσ n (by omega)).1 (hσ n (by omega)).2
    let A := K*(σ n+C)
    have hA : 0≤A := mul_nonneg hK.nonneg (add_nonneg (hσ n (by omega)).1.le hC)
    refine ⟨C+A,add_nonneg hC hA,?_⟩
    intro M D hM ξ hξ u hu j hj
    have hMD : 0≤M+D := add_nonneg hM hu.nonneg
    by_cases hjn : j≤n
    · exact weightedControl_mono (hprev M D hM ξ (fun j hj => hξ j (by omega)) u hu j hjn)
        (by nlinarith)
    · have hje : j=n+1 := by omega
      subst j
      have hh := lagState_weighted_control (hσ n (by omega)).1 hK
        (hprev M D hM ξ (fun j hj => hξ j (by omega)) u hu n le_rfl) (ξ n)
      apply weightedControl_mono hh
      have hi := hξ n (by omega)
      rw [abs_mul,abs_of_pos (hσ n (by omega)).1]
      dsimp [A]
      have hxi := mul_le_mul_of_nonneg_right
        (mul_le_mul_of_nonneg_right hi (hσ n (by omega)).1.le) hK.nonneg
      have hKD := mul_nonneg (mul_nonneg hK.nonneg (hσ n (by omega)).1.le) hu.nonneg
      nlinarith [mul_nonneg hC hMD]


end MIACE
