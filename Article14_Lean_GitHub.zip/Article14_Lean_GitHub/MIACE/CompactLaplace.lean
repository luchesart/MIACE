import MIACE.CompactMoments
import Mathlib.Analysis.Calculus.ParametricIntervalIntegral
import Mathlib.Analysis.Complex.CauchyIntegral
import Mathlib.Analysis.Calculus.IteratedDeriv.Analytic

/-! Actual compact Laplace integrals are entire; unlike a quotient identity
away from the poles, this includes all confluent interpolation nodes. -/
namespace MIACE
open MeasureTheory Filter Set Polynomial
open scoped Topology

noncomputable def compactLaplace (J : ℝ → ℝ) (δ : ℝ) (p : ℂ) : ℂ :=
  ∫ t in 0..δ, Complex.exp (-p*(t : ℂ))*(J t : ℂ)

-- @paper-step lem:n_remainder/compact_transform_complex_derivative
theorem compactLaplace_deriv {J : ℝ → ℝ} (hJ : Continuous J) (δ : ℝ) (p : ℂ) :
    HasDerivAt (compactLaplace J δ)
      (∫ t in 0..δ, -(t : ℂ)*Complex.exp (-p*(t : ℂ))*(J t : ℂ)) p := by
  have hc : Continuous (fun z : ℂ × ℝ =>
      -(z.2 : ℂ)*Complex.exp (-z.1*(z.2 : ℂ))*(J z.2 : ℂ)) := by
    fun_prop
  obtain ⟨C,hC⟩ := (isCompact_closedBall (x := p) (r := (1 : ℝ))).prod (isCompact_uIcc : IsCompact (uIcc (0 : ℝ) δ))
    |>.exists_bound_of_continuousOn hc.continuousOn
  apply (intervalIntegral.hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (s := Metric.ball p 1) (bound := fun _ => C) (Metric.ball_mem_nhds p (by norm_num))
    (Filter.Eventually.of_forall (fun q =>
      (by fun_prop : Continuous (fun t : ℝ => Complex.exp (-q*(t : ℂ))*(J t : ℂ))).aestronglyMeasurable))
    (by apply Continuous.intervalIntegrable; fun_prop)
    (by apply Continuous.aestronglyMeasurable; fun_prop) ?_
    (intervalIntegrable_const) ?_).2
  · apply ae_of_all
    intro t ht q hq
    exact hC (q,t) ⟨Metric.ball_subset_closedBall hq,uIoc_subset_uIcc ht⟩
  · apply ae_of_all
    intro t _ q _
    convert (((hasDerivAt_id q).neg.mul_const (t : ℂ)).cexp).mul_const (J t : ℂ)
      using 1
    · funext x; dsimp <;> ring_nf
    · dsimp <;> ring

-- @paper-step lem:n_remainder/entire_compact_transform
theorem compactLaplace_analytic {J : ℝ → ℝ} (hJ : Continuous J) (δ : ℝ) (p : ℂ) :
    AnalyticAt ℂ (compactLaplace J δ) p :=
  Differentiable.analyticAt (fun q => (compactLaplace_deriv hJ δ q).differentiableAt) p

-- @paper-step lem:n_remainder/complex_first_factor_remainder
theorem remainder_first_factor_complex (r : ℕ → ℝ) (δ : ℝ) (p : ℂ) (hr : r 0≠0) :
    Complex.exp (-p*(δ : ℂ))=(Real.exp (r 0*δ) : ℂ)-
      (1+p/(r 0 : ℂ))*compactLaplace (remainderJ r 0 δ) δ p := by
  have hd : ∀ t : ℝ, HasDerivAt
      (fun s : ℝ => Complex.exp (-p*(s : ℂ))*(Real.exp (r 0*(δ-s)) : ℂ))
      (-(1+p/(r 0 : ℂ))*(Complex.exp (-p*(t : ℂ))*(remainderJ r 0 δ t : ℂ))) t := by
    intro t
    have h₁ := ((((hasDerivAt_id t).ofReal_comp).const_mul (-p)).cexp)
    have h₂ := ((((hasDerivAt_id t).const_sub δ).const_mul (r 0)).exp).ofReal_comp
    convert h₁.mul h₂ using 1
    · rfl
    · dsimp [remainderJ,reverseImpulse,id_eq]
      push_cast
      have hr' : (r 0 : ℂ)≠0 := Complex.ofReal_ne_zero.mpr hr
      field_simp [hr']; ring
  have hf := intervalIntegral.integral_eq_sub_of_hasDerivAt (fun t _ => hd t)
    (a := 0) (b := δ)
    (by apply Continuous.intervalIntegrable; exact
      (((by fun_prop : Continuous (fun t : ℝ => Complex.exp (-p*(t : ℂ)))).mul
      (Complex.continuous_ofReal.comp (remainderJ_continuous r 0 δ))).const_mul _))
  rw [intervalIntegral.integral_const_mul] at hf
  simp only [Complex.ofReal_zero,mul_zero,sub_self,Real.exp_zero,Complex.ofReal_one,
    Complex.exp_zero,mul_one,sub_zero,one_mul] at hf
  change -(1+p/(r 0 : ℂ))*compactLaplace (remainderJ r 0 δ) δ p=_ at hf
  linear_combination -hf

-- @paper-step lem:n_remainder/complex_remainder_recurrence
theorem remainder_next_factor_complex (r : ℕ → ℝ) (n : ℕ) (δ : ℝ) (p : ℂ)
    (hr : r (n+1)≠0) :
    (1+p/(r (n+1) : ℂ))*compactLaplace (remainderJ r (n+1) δ) δ p=
      (reverseImpulse r (n+1) δ : ℂ)/r (n+1)-compactLaplace (remainderJ r n δ) δ p := by
  have hd : ∀ t : ℝ, HasDerivAt
      (fun s : ℝ => Complex.exp (-p*(s : ℂ))*(remainderJ r (n+1) δ s : ℂ))
      (-(p+(r (n+1) : ℂ))*(Complex.exp (-p*(t : ℂ))*(remainderJ r (n+1) δ t : ℂ))-
        (r (n+1) : ℂ)*(Complex.exp (-p*(t : ℂ))*(remainderJ r n δ t : ℂ))) t := by
    intro t
    have hj := ((reverseImpulse_deriv r n (δ-t)).comp t ((hasDerivAt_id t).const_sub δ)).ofReal_comp
    convert ((((hasDerivAt_id t).ofReal_comp).const_mul (-p)).cexp).mul hj using 1
    · rfl
    · dsimp [remainderJ,id_eq]; push_cast; ring
  have hc (m : ℕ) : Continuous (fun t : ℝ => Complex.exp (-p*(t : ℂ))*(remainderJ r m δ t : ℂ)) :=
    (by fun_prop : Continuous (fun t : ℝ => Complex.exp (-p*(t : ℂ)))).mul (Complex.continuous_ofReal.comp (remainderJ_continuous r m δ))
  have hf := intervalIntegral.integral_eq_sub_of_hasDerivAt (fun t _ => hd t)
    ((((hc (n+1)).const_mul _).sub ((hc n).const_mul _)).intervalIntegrable 0 δ)
  rw [intervalIntegral.integral_sub (((hc (n+1)).const_mul _).intervalIntegrable 0 δ)
      (((hc n).const_mul _).intervalIntegrable 0 δ),
    intervalIntegral.integral_const_mul,intervalIntegral.integral_const_mul] at hf
  simp only [remainderJ,sub_self,sub_zero,Complex.ofReal_zero,mul_zero,Complex.exp_zero,one_mul,
    (reverseImpulse_zero r n).2,zero_sub] at hf
  change -(p+(r (n+1) : ℂ))*compactLaplace (remainderJ r (n+1) δ) δ p-
    (r (n+1) : ℂ)*compactLaplace (remainderJ r n δ) δ p= -(reverseImpulse r (n+1) δ : ℂ) at hf
  have hr' : (r (n+1) : ℂ)≠0 := Complex.ofReal_ne_zero.mpr hr
  field_simp [hr']
  linear_combination -hf

-- @paper-step lem:n_remainder/exact_complex_delay_remainder_all_orders
theorem exact_delay_remainder_complex (r : ℕ → ℝ) (n : ℕ) (δ : ℝ) (p : ℂ)
    (hr : ∀ j≤n, r j≠0) :
    Complex.exp (-(δ : ℂ)*p)=(remainderI r δ n).eval₂ Complex.ofRealHom p+
      (-1 : ℂ)^(n+1)*(remainderB r n).eval₂ Complex.ofRealHom p*
        compactLaplace (remainderJ r n δ) δ p := by
  have hcoe (x : ℝ) : Complex.ofRealHom x=(x : ℂ) := rfl
  induction n with
  | zero =>
    have he := remainder_first_factor_complex r δ p (hr 0 le_rfl)
    simp only [remainderI,remainderB,eval₂_C,eval₂_add,eval₂_mul,eval₂_X,eval₂_one,
      hcoe,Complex.ofReal_div,Complex.ofReal_one]
    convert he using 1 <;> ring
  | succ n ih =>
    have hi := ih (fun j hj => hr j (by omega))
    have hn := remainder_next_factor_complex r n δ p (hr (n+1) le_rfl)
    simp only [remainderI,remainderB,eval₂_add,eval₂_mul,eval₂_C,eval₂_X,eval₂_one]
    simp only [hcoe,Complex.ofReal_div,Complex.ofReal_mul,
      Complex.ofReal_pow,Complex.ofReal_neg,Complex.ofReal_one]
    rw [hi,pow_succ (-1 : ℂ) (n+1)]
    linear_combination ((-1 : ℂ)^(n+1)*(remainderB r n).eval₂ Complex.ofRealHom p)*hn

end MIACE
