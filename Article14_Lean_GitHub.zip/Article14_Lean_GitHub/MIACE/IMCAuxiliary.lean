import MIACE.IMCStepMismatch

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:complete_robust/absolute_area_ae_invariance
theorem absArea_congr {f g : ℝ → ℝ} {μ : Measure ℝ} (he : f=ᵐ[μ] g) :
    absArea f μ=absArea g μ := by
  apply integral_congr_ae
  filter_upwards [he] with t ht
  rw [ht]

-- @paper-step thm:complete_robust/absolute_area_difference_bound
theorem absArea_sub_le {f g : ℝ → ℝ} {μ : Measure ℝ} (hf : Integrable f μ) (hg : Integrable g μ) :
    absArea (fun t => f t-g t) μ≤absArea f μ+absArea g μ := by
  have hh := integral_mono (hf.sub hg).abs (hf.abs.add hg.abs) (fun t => by
    change |f t-g t|≤|f t|+|g t|
    simpa only [sub_zero,zero_sub,abs_neg] using abs_sub_le (f t) 0 (g t))
  change (∫ t, |f t-g t| ∂μ)≤∫ t, |f t|+|g t| ∂μ at hh
  rw [integral_add hf.abs hg.abs] at hh
  exact hh

-- @paper-step thm:complete_robust/actual_loop_kernel_convolution
theorem imcLoopKernel_convolution (F : IMCFilter) (ss : List ℝ) (δ ε : ℝ)
    (hD : Integrable (delayMismatchKernel ss δ ε)) (hDc : Causal (delayMismatchKernel ss δ ε))
    {u : ℝ → ℝ} (hu : LocallyIntegrable u volume) (huc : Causal u) :
    (imcLoopKernel F ss δ ε ⋆ u)=ᵐ[volume]
      (fun t => -filterAction F (delayMismatchKernel ss δ ε ⋆ u) t) := by
  have hk : imcLoopKernel F ss δ ε=(-1 : ℝ) • filterAction F (delayMismatchKernel ss δ ε) := by
    ext t; simp [imcLoopKernel]
  have hn : (imcLoopKernel F ss δ ε ⋆ u)=
      (fun t => -(filterAction F (delayMismatchKernel ss δ ε) ⋆ u) t) := by
    rw [hk,smul_convolution]
    ext t; simp
  rw [hn]
  filter_upwards [local_filter_convolution F hD hDc hu huc] with t ht
  rw [ht]

-- @paper-step thm:complete_robust/concrete_step_resolvent_and_sharp_gain
theorem imc_step_auxiliary (F : IMCFilter) (ss : List ℝ) (hs : ∀ σ∈ss, 0<σ)
    {δ ε : ℝ} (hδ : 0≤δ) (hδε : 0≤δ+ε) (hq : imcDelayGain F ε<1) :
    ∃ z : ℝ → ℝ, Integrable z ∧ Causal z ∧
      z=ᵐ[volume] (fun t => (delayMismatchKernel ss δ ε ⋆ unitStep) t-
        filterAction F (delayMismatchKernel ss δ ε ⋆ z) t) ∧
      absArea z volume≤|ε|/(1-imcDelayGain F ε) := by
  have hP := cascadeKernel_properties ss hs
  have hD : Integrable (delayMismatchKernel ss δ ε) :=
    (shift_integrable (δ+ε) hP.1).sub (shift_integrable δ hP.1)
  have hDc : Causal (delayMismatchKernel ss δ ε) := by
    filter_upwards [causal_shift hP.2.2.2 hδε,causal_shift hP.2.2.2 hδ] with t ht hs hn
    simp [delayMismatchKernel,ht hn,hs hn]
  have hK := imcLoopKernel_properties F ss hs hδ hδε
  have hsmall := hK.2.2.trans_lt hq
  have hg := delayMismatch_step_properties ss hs hδ hδε
  let g := hg.1.toL1 (delayMismatchKernel ss δ ε ⋆ unitStep)
  let z := (∑' n : ℕ, (convOp hK.1)^n) g
  have hgc : Causal g := causal_congr hg.2.1 hg.1.coeFn_toL1.symm
  have hzc : Causal z := causal_renewal_series hK.1 hK.2.1 ((convOp_norm hK.1).trans_lt hsmall) hgc
  have hzi := L1.integrable_coeFn z
  have he := signed_renewal_representative hK.1 hsmall g
  have hk := imcLoopKernel_convolution F ss δ ε hD hDc hzi.locallyIntegrable hzc
  refine ⟨z,hzi,hzc,?_,?_⟩
  · filter_upwards [he,hg.1.coeFn_toL1,hk] with t ht hgt hkt
    change z t=g t+(imcLoopKernel F ss δ ε ⋆ (z : ℝ → ℝ)) t at ht
    rw [ht,hgt,hkt]
    ring
  · have hn := (signed_renewal_l1 hK.1 hsmall g).2.2.2
    have hzarea : ‖z‖=absArea z volume := by rw [L1.norm_eq_integral_norm]; rfl
    have hgarea : ‖g‖=|ε| := by
      rw [L1.norm_of_fun_eq_integral_norm]
      exact hg.2.2
    change ‖z‖≤‖g‖/(1-absArea (imcLoopKernel F ss δ ε) volume) at hn
    rw [hzarea,hgarea] at hn
    exact hn.trans (div_le_div_of_nonneg_left (abs_nonneg ε) (sub_pos.mpr hq)
      (by linarith [hK.2.2]))

end MIACE
