import MIACE.Theorem17Resolvent
import MIACE.ReducedEvolution

/-! Arbitrary signed forcing and arbitrary initial value, constructed from
the actual compact-delay inverse. The forcing bound is quantitative and
does not depend on the sign of the initial state or of the history. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

structure CompactForcedEvolution (J : ℝ → ℝ) (δ a c ε w₀ : ℝ)
    (F w : ℝ → ℝ) : Prop where
  continuous : Continuous w
  ac : ∀ u v, AbsolutelyContinuousOnInterval w u v
  initial : w 0=w₀
  ode : ∀ᵐ t, 0<t → HasDerivAt w
    ((F t-c*w t-ε*(compactKernel J δ ⋆ causalize w) t)/a) t

-- @paper-step thm:n_construction/ordinary_resolvent_quantitative_weighted_control
theorem ordinary_resolvent_control {R : ℝ → ℝ} {η C : ℝ}
    (hC : 0≤C) (hi : Integrable (expWeight η (causalize R)))
    (hb : ∀ t, 0≤t → |R t|≤C*Real.exp (-η*t)) :
    WeightedControl η (causalize R) ((∫ t, |expWeight η (causalize R) t|)+C) := by
  have hI : 0≤∫ t, |expWeight η (causalize R) t| := integral_nonneg (fun _ => abs_nonneg _)
  refine ⟨add_nonneg hI hC,hi,by linarith,ae_of_all _ (fun t => ?_)⟩
  suffices hh : |expWeight η (causalize R) t|≤C from hh.trans (by linarith)
  by_cases ht : 0≤t
  · simp only [expWeight,causalize,indicator_of_mem (show t∈Ici (0 : ℝ) from ht),
      abs_mul,abs_of_pos (Real.exp_pos _)]
    have hh := mul_le_mul_of_nonneg_left (hb t ht) (Real.exp_nonneg (η*t))
    have he : Real.exp (η*t)*Real.exp (-η*t)=1 := by
      rw [← Real.exp_add]; ring_nf; simp
    have hx : Real.exp (η*t)*(C*Real.exp (-η*t))=C := by
      calc
        _ = C*(Real.exp (η*t)*Real.exp (-η*t)) := by ring
        _ = C := by rw [he,mul_one]
    rw [hx] at hh
    exact hh
  · simpa [expWeight,causalize,ht] using hC

-- @paper-step thm:n_construction/forced_compact_inverse_actual_time_realization
theorem compact_forced_realization {J : ℝ → ℝ} (hJ : Continuous J)
    {δ a c ε w₀ η D : ℝ} (hδ : 0≤δ) (ha : 0<a) {F W : ℝ → ℝ}
    (hF : Integrable F) (hW : Integrable W) (hWc : Causal W)
    (hw : WeightedControl η W D)
    (hT : ∀ p : ℝ, 0<p →
      (a*p+c+ε*compactExpMoment J δ (-p))*laplace W p=a*w₀+laplace F p) :
    ∃ w : ℝ → ℝ, CompactForcedEvolution J δ a c ε w₀ F w ∧
      W=ᵐ[volume] causalize w ∧ WeightedControl η (causalize w) D := by
  let K := compactKernel J δ
  let G := fun t => (F t-c*W t-ε*(K ⋆ W) t)/a
  have hK := compactKernel_integrable hJ δ
  have hconv := hK.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hW
  have hG : Integrable G := ((hF.sub (hW.const_mul c)).sub (hconv.const_mul ε)).div_const a
  have ht (p : ℝ) (hp : 0<p) : p*laplace W p=w₀+laplace G p := by
    have hsum : Integrable (fun t => c*W t+ε*(K ⋆ W) t) :=
      (hW.const_mul c).add (hconv.const_mul ε)
    have he : G=fun t => (1/a)*F t+(-1/a)*(c*W t+ε*(K ⋆ W) t) := by
      funext t; dsimp [G]; ring
    rw [he,laplace_linear hF hsum (1/a) (-1/a) hp.le,
      laplace_linear hW hconv c ε hp.le,
      causal_convolution_laplace hK hW (compactKernel_causal J δ) hWc hp.le,
      compactKernel_laplace J hδ]
    have hh := hT p hp
    field_simp [ne_of_gt ha]
    nlinarith [hh]
  let w := integratedState w₀ G
  have he : W=ᵐ[volume] causalize w := integratedState_identification hW hWc hG w₀ ht
  obtain ⟨hc,h0,hac,hd⟩ := integratedState_regular w₀ hG
  refine ⟨w,⟨hc,hac,h0,?_⟩,he,weightedControl_congr hw he⟩
  have hce := convolution_congr (ContinuousLinearMap.lsmul ℝ ℝ)
    (EventuallyEq.rfl (f := K)) he
  filter_upwards [hd,he] with t hdt het ht0
  change HasDerivAt w ((F t-c*W t-ε*(K ⋆ W) t)/a) t at hdt
  rw [het,hce] at hdt
  simpa only [causalize,indicator_of_mem (show t∈Ici (0 : ℝ) from ht0.le)] using hdt

-- @paper-step thm:n_construction/arbitrary_signed_forcing_and_initial_value_decay
theorem compact_forced_exists {J : ℝ → ℝ} (hJ : Continuous J)
    {δ a c ε η C : ℝ} (hδ : 0≤δ) (ha : 0<a) (hη : 0≤η)
    {R : ℝ → ℝ} (hRi : Integrable R) (hRc : Causal R)
    (hRw : WeightedControl η R C)
    (hInv : ∀ p : ℝ, 0<p →
      (a*p+c+ε*compactExpMoment J δ (-p))*laplace R p=1) :
    ∀ (F : ℝ → ℝ) (w₀ M : ℝ), Causal F → WeightedControl η F M →
      ∃ w : ℝ → ℝ, CompactForcedEvolution J δ a c ε w₀ F w ∧
        WeightedControl η (causalize w) (C*(|a*w₀|+M)) ∧
        ∀ t, 0≤t → |w t|≤(C*(|a*w₀|+M))*Real.exp (-η*t) := by
  intro F w₀ M hFc hFw
  have hFi := weightedControl_unweighted hFw hFc hη
  let W := fun t => (a*w₀)*R t+(R ⋆ F) t
  have hconv := hRi.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hFi
  have hWi : Integrable W := (hRi.const_mul (a*w₀)).add hconv
  have hWc : Causal W := by
    simpa only [one_mul] using causal_linear hRc (ae_of_all _ (convolution_causal hRc hFc)) (a*w₀) 1
  have hWw : WeightedControl η W (C*(|a*w₀|+M)) := by
    have hh := weightedControl_add (weightedControl_smul hRw (a*w₀))
      (weightedControl_convolution hRw hFw)
    convert hh using 1 <;> ring
  have hT (p : ℝ) (hp : 0<p) :
      (a*p+c+ε*compactExpMoment J δ (-p))*laplace W p=a*w₀+laplace F p := by
    have hh := laplace_linear hRi hconv (a*w₀) 1 hp.le
    simp only [one_mul] at hh
    change laplace W p=_ at hh
    rw [hh,causal_convolution_laplace hRi hFi hRc hFc hp.le]
    have h := hInv p hp
    linear_combination (a*w₀+laplace F p)*h
  obtain ⟨w,he,_,hw⟩ := compact_forced_realization hJ hδ ha hFi hWi hWc hWw hT
  exact ⟨w,he,hw,weightedControl_continuous_decay he.continuous hw⟩

end MIACE
