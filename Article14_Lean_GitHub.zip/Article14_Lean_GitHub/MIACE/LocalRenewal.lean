import MIACE.CausalAlgebra

/-! Stage 13. Finite-interval uniqueness for ordinary Volterra solutions.
A competing solution is only locally integrable; global decay or L1
integrability is not assumed. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

noncomputable def causalTruncate (T : ℝ) (f : ℝ → ℝ) : ℝ → ℝ := (Icc 0 T).indicator f

-- @paper-step thm:complete_robust/finite_record_causal_integrability
theorem causalTruncate_integrable {f : ℝ → ℝ} (hf : LocallyIntegrable f volume) (T : ℝ) :
    Integrable (causalTruncate T f) :=
  (hf.integrableOn_isCompact isCompact_Icc).integrable_indicator measurableSet_Icc

-- @paper-step thm:complete_robust/finite_record_causality
theorem causalTruncate_causal (f : ℝ → ℝ) (T : ℝ) : Causal (causalTruncate T f) := by
  apply ae_of_all
  intro t ht
  simp [causalTruncate,show t∉Icc (0 : ℝ) T from fun h => not_le.mpr ht h.1]

-- @paper-step thm:complete_robust/causal_finite_record_locality
theorem convolution_causalTruncate {K f : ℝ → ℝ} (hKc : Causal K) (hfc : Causal f)
    {t T : ℝ} (ht : t∈Icc (0 : ℝ) T) :
    (K ⋆ causalTruncate T f) t=(K ⋆ f) t := by
  rw [causal_convolution_interval hKc (causalTruncate_causal f T) ht.1,
    causal_convolution_interval hKc hfc ht.1]
  apply intervalIntegral.integral_congr
  intro s hs
  rw [uIcc_of_le ht.1] at hs
  simp [causalTruncate,show s∈Icc (0 : ℝ) T from ⟨hs.1,hs.2.trans ht.2⟩]

-- @paper-step thm:complete_robust/local_causal_convolution_linearity
theorem local_convolution_sub {K f g : ℝ → ℝ} (hK : Integrable K) (hKc : Causal K)
    (hf : LocallyIntegrable f volume) (hg : LocallyIntegrable g volume)
    (hfc : Causal f) (hgc : Causal g) :
    (K ⋆ (fun t => f t-g t))=ᵐ[volume] (fun t => (K ⋆ f) t-(K ⋆ g) t) := by
  have hsub : Causal (fun t => f t-g t) := by
    filter_upwards [hfc,hgc] with t ht hs hn
    simp [ht hn,hs hn]
  have hN (n : ℕ) : ∀ᵐ t, t∈Icc (0 : ℝ) n →
      (K ⋆ (fun t => f t-g t)) t=(K ⋆ f) t-(K ⋆ g) t := by
    have hfn := causalTruncate_integrable hf n
    have hgn := causalTruncate_integrable hg n
    filter_upwards [hK.ae_convolution_exists (ContinuousLinearMap.lsmul ℝ ℝ) hfn,
      hK.ae_convolution_exists (ContinuousLinearMap.lsmul ℝ ℝ) hgn] with t ht hs htn
    rw [← convolution_causalTruncate hKc hsub htn,
      ← convolution_causalTruncate hKc hfc htn,← convolution_causalTruncate hKc hgc htn]
    have he : causalTruncate n (fun t => f t-g t)=
        (fun t => causalTruncate n f t-causalTruncate n g t) := by
      ext s; by_cases hs : s∈Icc (0 : ℝ) n <;> simp [causalTruncate,hs]
    rw [he]
    change (∫ s, K s*(causalTruncate n f (t-s)-causalTruncate n g (t-s)))=_
    simp_rw [mul_sub]
    exact integral_sub ht hs
  filter_upwards [ae_all_iff.mpr hN] with t ht
  by_cases hp : 0≤t
  · obtain ⟨n,hn⟩ := exists_nat_ge t
    exact ht n ⟨hp,hn⟩
  · have hn := lt_of_not_ge hp
    rw [convolution_causal hKc hsub t hn,convolution_causal hKc hfc t hn,
      convolution_causal hKc hgc t hn,sub_self]

-- @paper-step thm:complete_robust/unrestricted_local_renewal_zero
theorem local_renewal_zero {K f : ℝ → ℝ} (hK : Integrable K) (hKc : Causal K)
    (hq : absArea K volume<1) (hf : LocallyIntegrable f volume) (hfc : Causal f)
    (he : f=ᵐ[volume] K ⋆ f) : f=ᵐ[volume] (fun _ => 0) := by
  have hN (n : ℕ) : causalTruncate n f=ᵐ[volume] (fun _ => 0) := by
    have hfn := causalTruncate_integrable hf n
    have hkn := hK.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hfn
    have hb : ∀ᵐ t, |causalTruncate n f t|≤|(K ⋆ causalTruncate n f) t| := by
      filter_upwards [he] with t ht
      by_cases hn : t∈Icc (0 : ℝ) n
      · rw [convolution_causalTruncate hKc hfc hn]
        simp only [causalTruncate,indicator_of_mem hn,ht,le_refl]
      · simp [causalTruncate,hn]
    have hi := (integral_mono_ae hfn.abs hkn.abs hb).trans (convolution_absArea hK hfn)
    have hp : 0≤absArea (causalTruncate n f) volume := integral_nonneg (fun _ => abs_nonneg _)
    have hz : absArea (causalTruncate n f) volume=0 := by
      change absArea (causalTruncate n f) volume≤absArea K volume*absArea (causalTruncate n f) volume at hi
      nlinarith
    have hza := (integral_eq_zero_iff_of_nonneg_ae (ae_of_all _ (fun _ => abs_nonneg _)) hfn.abs).mp hz
    exact hza.mono (fun _ ht => abs_eq_zero.mp ht)
  filter_upwards [ae_all_iff.mpr hN,hfc] with t ht hc
  by_cases hp : 0≤t
  · obtain ⟨n,hn⟩ := exists_nat_ge t
    simpa [causalTruncate,show t∈Icc (0 : ℝ) n from ⟨hp,hn⟩] using ht n
  · exact hc (lt_of_not_ge hp)

-- @paper-step thm:complete_robust/unrestricted_ordinary_renewal_uniqueness
theorem local_renewal_unique {K f u v : ℝ → ℝ} (hK : Integrable K) (hKc : Causal K)
    (hq : absArea K volume<1) (hu : LocallyIntegrable u volume) (hv : LocallyIntegrable v volume)
    (huc : Causal u) (hvc : Causal v)
    (hue : u=ᵐ[volume] (fun t => f t+(K ⋆ u) t))
    (hve : v=ᵐ[volume] (fun t => f t+(K ⋆ v) t)) : u=ᵐ[volume] v := by
  have hsub : Causal (fun t => u t-v t) := by
    filter_upwards [huc,hvc] with t ht hs hn
    simp [ht hn,hs hn]
  have he : (fun t => u t-v t)=ᵐ[volume] (K ⋆ (fun t => u t-v t)) := by
    filter_upwards [hue,hve,local_convolution_sub hK hKc hu hv huc hvc] with t ht hs hh
    rw [hh,ht,hs]; ring
  have hz := local_renewal_zero hK hKc hq (hu.sub hv) hsub he
  exact hz.mono (fun _ ht => sub_eq_zero.mp ht)

end MIACE
