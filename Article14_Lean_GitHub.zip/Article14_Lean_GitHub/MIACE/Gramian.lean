import MIACE.AnalyticBridge
import Mathlib.Analysis.SpecialFunctions.Exponential

/-! Поправка: първоначалният път през грамияна вече включва съществуване
на импулсния отклик, действителното преобразувание на Лаплас, извъндиагоналния
интеграл и единствеността на решението на уравнението на Ляпунов. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def canonicalOperator (a b c : ℝ) : (ℝ × ℝ) →L[ℝ] (ℝ × ℝ) :=
  (ContinuousLinearMap.snd ℝ ℝ ℝ).prod
    ((-(c/a)) • ContinuousLinearMap.fst ℝ ℝ ℝ -
      (b/a) • ContinuousLinearMap.snd ℝ ℝ ℝ)

noncomputable def canonicalFlow (a b c t : ℝ) : ℝ × ℝ :=
  NormedSpace.exp (t • canonicalOperator a b c) (0,1/a)

-- @paper-step lem:h2/matrix_exponential_derivative
theorem canonical_flow_derivative (a b c t : ℝ) :
    HasDerivAt (canonicalFlow a b c) (canonicalOperator a b c (canonicalFlow a b c t)) t := by
  have hd := (hasDerivAt_exp_smul_const' (canonicalOperator a b c) t).clm_apply
    (hasDerivAt_const t (0,1/a))
  change HasDerivAt (fun t => NormedSpace.exp (t • canonicalOperator a b c) (0,1/a)) _ t
  simpa [canonicalFlow] using hd

-- @paper-step lem:h2/matrix_exponential_realization
theorem canonical_flow_realization (a b c : ℝ) :
    CanonicalImpulse a b c (fun t => (canonicalFlow a b c t).1)
      (fun t => (canonicalFlow a b c t).2) := by
  have hExp : ContDiff ℝ 1 (NormedSpace.exp : ((ℝ × ℝ) →L[ℝ] (ℝ × ℝ)) → _) :=
    contDiff_iff_contDiffAt.mpr (fun x => (NormedSpace.exp_analytic x).contDiffAt)
  have hflow : ContDiff ℝ 1 (canonicalFlow a b c) :=
    (hExp.comp (contDiff_id.smul contDiff_const)).clm_apply contDiff_const
  refine ⟨?_,?_,?_,?_,?_,?_⟩
  · intro T hT
    exact hflow.fst.contDiffOn.absolutelyContinuousOnInterval
  · intro T hT
    exact hflow.snd.contDiffOn.absolutelyContinuousOnInterval
  · apply ae_of_all
    intro t ht
    simpa [canonicalOperator,Function.comp_def] using ((ContinuousLinearMap.fst ℝ ℝ ℝ).hasFDerivAt.comp_hasDerivAt t
      (canonical_flow_derivative a b c t)).deriv
  · apply ae_of_all
    intro t ht
    simpa [canonicalOperator,Function.comp_def] using ((ContinuousLinearMap.snd ℝ ℝ ℝ).hasFDerivAt.comp_hasDerivAt t
      (canonical_flow_derivative a b c t)).deriv
  · simp [canonicalFlow]
  · simp [canonicalFlow]

-- @paper-step lem:h2/actual_rational_transfer
theorem canonical_laplace {a b c : ℝ} {z w : ℝ → ℝ}
    (h : CanonicalImpulse a b c z w) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (d e p : ℝ) (hp : 0 ≤ p) :
    laplace (fun t => e*z t+d*w t) p = (d*p+e)/(a*p^2+b*p+c) := by
  have hint := canonical_integrable ha hb hc h.ac_z h.ac_w h.ode_z h.ode_w
  have hfinal := canonical_settles ha hb hc h.ac_z h.ac_w h.ode_z h.ode_w
  have hz := laplace_ode_identity h.ac_z h.ode_z hint.1 hint.2 hfinal.1 p hp
  have hw := laplace_ode_identity h.ac_w h.ode_w hint.2
    ((hint.1.const_mul (-(c/a))).sub (hint.2.const_mul (b/a))) hfinal.2 p hp
  rw [h.initial_z,sub_zero] at hz
  rw [h.initial_w] at hw
  have hlin : laplace (fun t => -(c/a)*z t-(b/a)*w t) p =
      -(c/a)*laplace z p-(b/a)*laplace w p := by
    unfold laplace
    simp_rw [mul_sub,mul_left_comm (Real.exp (-p*_) : ℝ)]
    rw [integral_sub ((laplace_integrable hint.1 hp).const_mul _)
      ((laplace_integrable hint.2 hp).const_mul _),integral_const_mul,integral_const_mul]
  rw [hlin,hz] at hw
  have hden : 0 < a*p^2+b*p+c := by positivity
  have hbase : (a*p^2+b*p+c)*laplace z p = 1 := by
    field_simp at hw
    nlinarith [hw]
  have hout : laplace (fun t => e*z t+d*w t) p = e*laplace z p+d*laplace w p := by
    unfold laplace
    simp_rw [mul_add,mul_left_comm (Real.exp (-p*_) : ℝ)]
    rw [integral_add ((laplace_integrable hint.1 hp).const_mul _)
      ((laplace_integrable hint.2 hp).const_mul _),integral_const_mul,integral_const_mul]
  rw [hout,hz]
  apply (eq_div_iff (ne_of_gt hden)).2
  linear_combination (e+d*p)*hbase

-- @paper-step lem:h2/actual_gramian_off_diagonal
theorem canonical_cross_integral {a b c : ℝ} {z w : ℝ → ℝ}
    (h : CanonicalImpulse a b c z w) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) :
    Integrable (fun t => z t*w t) halfLine ∧ (∫ t, z t*w t ∂halfLine) = 0 := by
  have hp := canonical_energy ha hb hc h.ac_z h.ac_w h.ode_z h.ode_w h.initial_z h.initial_w 1 1
  have hm := canonical_energy ha hb hc h.ac_z h.ac_w h.ode_z h.ode_w h.initial_z h.initial_w (-1) 1
  have heq : (fun t => z t*w t) = (fun t => (1/4:ℝ)*((1*z t+1*w t)^2-(1*z t+(-1)*w t)^2)) := by
    funext t
    ring
  rw [heq]
  refine ⟨(hp.1.sub hm.1).const_mul _,?_⟩
  rw [integral_const_mul,integral_sub hp.1 hm.1,hp.2,hm.2]
  ring

-- @paper-step lem:h2/gramian_lyapunov_unique
theorem gramian_unique (a b c P11 P12 P22 : ℝ)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) :
    (2*P12=0 ∧ P22-(c/a)*P11-(b/a)*P12=0 ∧
      -(2*c/a)*P12-(2*b/a)*P22+1/a^2=0) ↔
    (P11=1/(2*b*c) ∧ P12=0 ∧ P22=1/(2*a*b)) := by
  constructor
  · rintro ⟨h12,h11,h22⟩
    have hp12 : P12=0 := by linarith
    rw [hp12] at h11 h22
    have hp22 : P22=1/(2*a*b) := by
      field_simp at h22 ⊢
      nlinarith
    have hp11 : P11=1/(2*b*c) := by
      rw [hp22] at h11
      field_simp at h11 ⊢
      nlinarith
    exact ⟨hp11,hp12,hp22⟩
  · rintro ⟨rfl,rfl,rfl⟩
    constructor
    · ring
    constructor <;> field_simp <;> ring

-- @paper-step lem:h2/gramian_output_identity
theorem gramian_output (a b c d e : ℝ)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) :
    e^2*(1/(2*b*c))+2*e*d*0+d^2*(1/(2*a*b)) =
      (a*e^2+c*d^2)/(2*a*b*c) := by
  field_simp
  <;> ring

-- @paper-step lem:h2/full_statement
theorem paper_second_order_energy (a b c d e : ℝ)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) :
    ∃ z w : ℝ → ℝ, CanonicalImpulse a b c z w ∧
      (∀ p : ℝ, 0 ≤ p → laplace (fun t => e*z t+d*w t) p = (d*p+e)/(a*p^2+b*p+c)) ∧
      Integrable (fun t => (e*z t+d*w t)^2) halfLine ∧
      (∫ t, (z t)^2 ∂halfLine) = 1/(2*b*c) ∧
      (∫ t, z t*w t ∂halfLine) = 0 ∧
      (∫ t, (w t)^2 ∂halfLine) = 1/(2*a*b) ∧
      (∫ t, (e*z t+d*w t)^2 ∂halfLine) = (a*e^2+c*d^2)/(2*a*b*c) := by
  let z := fun t => (canonicalFlow a b c t).1
  let w := fun t => (canonicalFlow a b c t).2
  have h : CanonicalImpulse a b c z w := canonical_flow_realization a b c
  have hE := canonical_energy ha hb hc h.ac_z h.ac_w h.ode_z h.ode_w h.initial_z h.initial_w d e
  have hD := impulse_gramian_diagonal (canonical_impulse_settles h ha hb hc) ha hb hc
  exact ⟨z,w,h,fun p hp => canonical_laplace h ha hb hc d e p hp,hE.1,
    hD.1,(canonical_cross_integral h ha hb hc).2,hD.2,hE.2⟩
end MIACE
