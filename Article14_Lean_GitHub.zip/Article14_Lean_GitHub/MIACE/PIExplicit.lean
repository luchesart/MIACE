import MIACE.AnalyticBridge

/-! Поправка: явните формули се проверяват срещу ОДУ и началните условия.
Единствеността ги свързва с произволен действителен PI отклик. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:monotone/local_ac_ae_differentiability
theorem local_ac_ae_differentiable {f : ℝ → ℝ}
    (h : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval f 0 T) :
    ∀ᵐ t : ℝ, 0 < t → DifferentiableAt ℝ f t := by
  have hh : ∀ᵐ t : ℝ, ∀ n : ℕ, t ∈ uIcc 0 (n : ℝ) → DifferentiableAt ℝ f t :=
    ae_all_iff.mpr (fun n => (h n (by positivity)).ae_differentiableAt)
  filter_upwards [hh] with t ht hpos
  obtain ⟨n,hn⟩ := exists_nat_gt t
  apply ht n
  rw [uIcc_of_le (by positivity : (0:ℝ) ≤ n)]
  exact ⟨hpos.le,hn.le⟩

-- @paper-step thm:monotone/canonical_uniqueness
theorem canonical_unique {a b c : ℝ} {z w Z W : ℝ → ℝ}
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (hz : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval z 0 T)
    (hw : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval w 0 T)
    (hZ : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval Z 0 T)
    (hW : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval W 0 T)
    (ho : ∀ᵐ t : ℝ, 0 < t → deriv z t = w t)
    (hp : ∀ᵐ t : ℝ, 0 < t → deriv w t = -(c/a)*z t-(b/a)*w t)
    (hO : ∀ᵐ t : ℝ, 0 < t → deriv Z t = W t)
    (hP : ∀ᵐ t : ℝ, 0 < t → deriv W t = -(c/a)*Z t-(b/a)*W t)
    (h0 : z 0=Z 0) (h1 : w 0=W 0) :
    ∀ t : ℝ, 0 ≤ t → z t=Z t ∧ w t=W t := by
  have hdo : ∀ᵐ t : ℝ, 0 < t → deriv (fun s => z s-Z s) t = w t-W t := by
    filter_upwards [ho,hO,local_ac_ae_differentiable hz,local_ac_ae_differentiable hZ]
      with t hot hOt hdt hDt ht
    rw [deriv_fun_sub (hdt ht) (hDt ht),hot ht,hOt ht]
  have hdp : ∀ᵐ t : ℝ, 0 < t → deriv (fun s => w s-W s) t =
      -(c/a)*(z t-Z t)-(b/a)*(w t-W t) := by
    filter_upwards [hp,hP,local_ac_ae_differentiable hw,local_ac_ae_differentiable hW]
      with t hpt hPt hdt hDt ht
    rw [deriv_fun_sub (hdt ht) (hDt ht),hpt ht,hPt ht]
    ring
  intro t ht
  have hh := canonical_exponential_bound ha hb hc (fun T hT => (hz T hT).sub (hZ T hT))
    (fun T hT => (hw T hT).sub (hW T hT)) hdo hdp t ht
  simp [h0,h1,stabilityV] at hh
  constructor <;> nlinarith [sq_nonneg (z t-Z t),sq_nonneg (w t-W t)]

-- @paper-step thm:monotone/pi_state_uniqueness
theorem pi_state_unique {x r : ℝ} {e i E I : ℝ → ℝ}
    (h : PIStateResponse x r e i) (h' : PIStateResponse x r E I)
    (hx : 0 < x) (hr : 0 < r) : ∀ t : ℝ, 0 ≤ t → e t=E t ∧ i t=I t := by
  have ho := pi_state_canonical_ode h hx hr
  have hO := pi_state_canonical_ode h' hx hr
  have hu := canonical_unique hr (by positivity : 0 < r*(1+x)) hx
    (fun T hT => (h.ac_i T hT).const_mul (-(r/x))) (fun T hT => (h.ac_e T hT).neg)
    (fun T hT => (h'.ac_i T hT).const_mul (-(r/x))) (fun T hT => (h'.ac_e T hT).neg)
    ho.1 ho.2 hO.1 hO.2 (by rw [h.initial_i,h'.initial_i]) (by simp only [Pi.neg_apply,h.initial_e,h'.initial_e])
  intro t ht
  obtain ⟨hi,he⟩ := hu t ht
  change -e t = -E t at he
  constructor
  · linarith
  · have hn : -(r/x) ≠ 0 := neg_ne_zero.mpr (div_ne_zero (ne_of_gt hr) (ne_of_gt hx))
    exact (mul_left_cancel₀ hn) hi

-- @paper-step thm:miace/cancellation_signal_identification
theorem pi_cancellation_signals {x : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x 1 e i) (hx : 0 < x) :
    ∀ t : ℝ, 0 ≤ t → e t=expError x t ∧ x*e t+i t=expCommand x t := by
  intro t ht
  obtain ⟨he,hi⟩ := pi_state_unique h (exponential_pi_state x) hx (by norm_num) t ht
  refine ⟨he,?_⟩
  rw [he,hi]
  unfold expCommand
  ring

noncomputable def realModeError (l m A B t : ℝ) := A*expError l t+B*expError m t
noncomputable def realModeIntegral (l m A B t : ℝ) := -m*A*expError l t-l*B*expError m t

-- @paper-step thm:monotone/real_mode_realization
theorem real_mode_response (x r l m A B : ℝ)
    (hs : l+m=1+x) (hp : l*m=x/r) (he : A+B=1) (hi : m*A+l*B=1) :
    PIStateResponse x r (realModeError l m A B) (realModeIntegral l m A B) := by
  have hdE : ∀ t : ℝ, HasDerivAt (realModeError l m A B)
      (-l*A*expError l t-m*B*expError m t) t := by
    intro t
    convert ((exp_error_derivative l t).const_mul A).add ((exp_error_derivative m t).const_mul B) using 1 <;>
      (try rfl) <;> ring
  have hdI : ∀ t : ℝ, HasDerivAt (realModeIntegral l m A B)
      (l*m*(A*expError l t+B*expError m t)) t := by
    intro t
    convert ((exp_error_derivative l t).const_mul (-m*A)).sub
      ((exp_error_derivative m t).const_mul (l*B)) using 1 <;> (try rfl) <;> ring
  refine ⟨?_,?_,?_,?_,?_ ,?_⟩
  · intro T hT
    apply ContDiffOn.absolutelyContinuousOnInterval
    unfold realModeError expError
    fun_prop
  · intro T hT
    apply ContDiffOn.absolutelyContinuousOnInterval
    unfold realModeIntegral expError
    fun_prop
  · apply ae_of_all
    intro t ht
    rw [(hdE t).deriv]
    unfold realModeError realModeIntegral
    linear_combination -(A*expError l t+B*expError m t)*hs
  · apply ae_of_all
    intro t ht
    rw [(hdI t).deriv,hp]
    rfl
  · simpa [realModeError,expError] using he
  · simp [realModeIntegral,expError]
    linarith

-- @paper-step thm:monotone/distinct_pole_coefficients
theorem distinct_mode_response (x r l m : ℝ) (hlm : l < m)
    (hs : l+m=1+x) (hp : l*m=x/r) :
    PIStateResponse x r (realModeError l m ((1-l)/(m-l)) ((m-1)/(m-l)))
      (realModeIntegral l m ((1-l)/(m-l)) ((m-1)/(m-l))) := by
  have hgap : m-l ≠ 0 := ne_of_gt (sub_pos.mpr hlm)
  apply real_mode_response x r l m _ _ hs hp
  · field_simp
    <;> ring
  · field_simp
    <;> ring

-- @paper-step thm:monotone/slower_exponential_dominates
theorem real_modes_eventually_negative {l m A B : ℝ} (hlm : l < m) (hA : A < 0) :
    ∀ᶠ t : ℝ in atTop, realModeError l m A B t < 0 := by
  have hexp : Tendsto (fun t : ℝ => Real.exp (-(m-l)*t)) atTop (𝓝 0) := by
    have hh := Real.tendsto_exp_neg_atTop_nhds_zero.comp
      (tendsto_id.const_mul_atTop (sub_pos.mpr hlm))
    convert hh using 1
    funext t
    simp only [Function.comp_def,id_eq]
    congr 1
    ring
  have hlim : Tendsto (fun t : ℝ => A+B*Real.exp (-(m-l)*t)) atTop (𝓝 A) := by
    simpa using tendsto_const_nhds.add (hexp.const_mul B)
  have hn := hlim.eventually (gt_mem_nhds hA)
  filter_upwards [hn] with t ht
  have heq : realModeError l m A B t = expError l t*(A+B*Real.exp (-(m-l)*t)) := by
    have hex : expError m t = expError l t*Real.exp (-(m-l)*t) := by
      unfold expError
      rw [← Real.exp_add]
      congr 1
      ring
    unfold realModeError
    rw [hex]
    ring
  rw [heq]
  exact mul_neg_of_pos_of_neg (Real.exp_pos _) ht

-- @paper-step thm:monotone/two_mode_sign
theorem real_modes_nonnegative {l m A B : ℝ} (hlm : l ≤ m)
    (hA : 0 ≤ A) (hs : 0 ≤ A+B) {t : ℝ} (ht : 0 ≤ t) :
    0 ≤ realModeError l m A B t := by
  have hθ : 0 ≤ Real.exp (-(m-l)*t) := Real.exp_nonneg _
  have hθ1 : Real.exp (-(m-l)*t) ≤ 1 := Real.exp_le_one_iff.mpr (by nlinarith)
  have hex : expError m t = expError l t*Real.exp (-(m-l)*t) := by
    unfold expError
    rw [← Real.exp_add]
    congr 1
    ring
  have hbr : 0 ≤ A+B*Real.exp (-(m-l)*t) := by
    by_cases hB : 0 ≤ B
    · positivity
    · have hB := le_of_lt (lt_of_not_ge hB)
      nlinarith
  have hh := mul_nonneg (Real.exp_nonneg (-l*t)) hbr
  unfold realModeError
  rw [hex]
  change 0 ≤ A*Real.exp (-l*t)+B*(Real.exp (-l*t)*Real.exp (-(m-l)*t))
  nlinarith

-- @paper-step thm:monotone/distinct_real_sign_classification
theorem distinct_error_nonnegative_iff {x r l m : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r)
    (hlm : l < m) (hs : l+m=1+x) (hp : l*m=x/r) :
    (∀ t : ℝ, 0 ≤ t → 0 ≤ e t) ↔ l ≤ 1 := by
  have hu := pi_state_unique h (distinct_mode_response x r l m hlm hs hp) hx hr
  have hgap : 0 < m-l := sub_pos.mpr hlm
  constructor
  · intro he
    by_contra hn
    have ha : (1-l)/(m-l) < 0 := div_neg_of_neg_of_pos (by linarith) hgap
    have hev := real_modes_eventually_negative (B := (m-1)/(m-l)) hlm ha
    obtain ⟨t,ht,htn⟩ := (hev.and (eventually_ge_atTop (0:ℝ))).exists
    have hh := he t htn
    rw [(hu t htn).1] at hh
    linarith
  · intro hl t ht
    rw [(hu t ht).1]
    apply real_modes_nonnegative hlm.le (div_nonneg (by linarith) hgap.le) _ ht
    have hsum : (1-l)/(m-l)+(m-1)/(m-l)=1 := by field_simp; ring
    rw [hsum]
    norm_num

noncomputable def repeatedError (l t : ℝ) := expError l t*(1+(1-l)*t)
noncomputable def repeatedIntegral (l t : ℝ) := expError l t*(-1-l*(1-l)*t)

-- @paper-step thm:monotone/repeated_pole_realization
theorem repeated_response (x r l : ℝ) (hs : 2*l=1+x) (hp : l^2=x/r) :
    PIStateResponse x r (repeatedError l) (repeatedIntegral l) := by
  have hE : ∀ t : ℝ, HasDerivAt (repeatedError l)
      (expError l t*((1-2*l)-l*(1-l)*t)) t := by
    intro t
    convert (exp_error_derivative l t).mul
      (((hasDerivAt_id t).const_mul (1-l)).const_add 1) using 1 <;> (try rfl) <;>
      simp only [id_eq] <;> ring
  have hI : ∀ t : ℝ, HasDerivAt (repeatedIntegral l)
      (l^2*repeatedError l t) t := by
    intro t
    convert (exp_error_derivative l t).mul
      (((hasDerivAt_id t).const_mul (l*(1-l))).const_sub (-1)) using 1 <;>
      (try rfl) <;> simp only [id_eq,repeatedError] <;> ring
  refine ⟨?_,?_,?_,?_,?_,?_⟩
  · intro T hT
    apply ContDiffOn.absolutelyContinuousOnInterval
    unfold repeatedError expError
    fun_prop
  · intro T hT
    apply ContDiffOn.absolutelyContinuousOnInterval
    unfold repeatedIntegral expError
    fun_prop
  · apply ae_of_all
    intro t ht
    rw [(hE t).deriv]
    unfold repeatedError repeatedIntegral
    linear_combination -(expError l t*(1+(1-l)*t))*hs
  · apply ae_of_all
    intro t ht
    rw [(hI t).deriv,hp]
  · simp [repeatedError,expError]
  · simp [repeatedIntegral,expError]

-- @paper-step thm:monotone/repeated_pole_sign_classification
theorem repeated_error_nonnegative_iff {x r l : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r)
    (hs : 2*l=1+x) (hp : l^2=x/r) :
    (∀ t : ℝ, 0 ≤ t → 0 ≤ e t) ↔ l ≤ 1 := by
  have hu := pi_state_unique h (repeated_response x r l hs hp) hx hr
  constructor
  · intro he
    by_contra hn
    have hl : 0 < l-1 := by linarith
    have ht : 0 ≤ 2/(l-1) := by positivity
    have hh := he _ ht
    rw [(hu _ ht).1] at hh
    have hbr : 1+(1-l)*(2/(l-1)) = -1 := by field_simp; ring
    simp only [repeatedError,hbr,mul_neg_one] at hh
    have hhpos := Real.exp_pos (-l*(2/(l-1)))
    change 0 ≤ -Real.exp (-l*(2/(l-1))) at hh
    linarith
  · intro hl t ht
    rw [(hu t ht).1]
    unfold repeatedError
    exact mul_nonneg (Real.exp_nonneg _) (by nlinarith)

noncomputable def complexError (d ω t : ℝ) :=
  expError d t*(Real.cos (ω*t)+(1-d)/ω*Real.sin (ω*t))
noncomputable def complexIntegral (d ω t : ℝ) :=
  expError d t*(-Real.cos (ω*t)+(d^2+ω^2-d)/ω*Real.sin (ω*t))

-- @paper-step thm:monotone/complex_pole_realization
theorem complex_response (x r d ω : ℝ) (hω : 0 < ω)
    (hs : 2*d=1+x) (hp : d^2+ω^2=x/r) :
    PIStateResponse x r (complexError d ω) (complexIntegral d ω) := by
  have hE : ∀ t : ℝ, HasDerivAt (complexError d ω)
      (-(1+x)*complexError d ω t-complexIntegral d ω t) t := by
    intro t
    have hd := (exp_error_derivative d t).mul
      ((((hasDerivAt_id t).const_mul ω).cos).add
        ((((hasDerivAt_id t).const_mul ω).sin).const_mul ((1-d)/ω)))
    convert hd using 1
    · rfl
    · simp only [id_eq,Pi.add_apply,Pi.neg_apply,complexError,complexIntegral]
      rw [← hs]
      field_simp
      <;> ring
  have hI : ∀ t : ℝ, HasDerivAt (complexIntegral d ω)
      ((x/r)*complexError d ω t) t := by
    intro t
    have hd := (exp_error_derivative d t).mul
      (((((hasDerivAt_id t).const_mul ω).cos).neg).add
        ((((hasDerivAt_id t).const_mul ω).sin).const_mul ((d^2+ω^2-d)/ω)))
    convert hd using 1
    · rfl
    · simp only [id_eq,Pi.add_apply,Pi.neg_apply,complexError]
      rw [← hp]
      field_simp
      <;> ring
  refine ⟨?_,?_,ae_of_all volume (fun t ht => (hE t).deriv),ae_of_all volume (fun t ht => (hI t).deriv),?_,?_⟩
  · intro T hT
    apply ContDiffOn.absolutelyContinuousOnInterval
    unfold complexError expError
    fun_prop
  · intro T hT
    apply ContDiffOn.absolutelyContinuousOnInterval
    unfold complexIntegral expError
    fun_prop
  · simp [complexError,expError]
  · simp [complexIntegral,expError]

-- @paper-step thm:monotone/complex_poles_overshoot
theorem complex_error_negative {x r d ω : ℝ} {e i : ℝ → ℝ}
    (h : PIStateResponse x r e i) (hx : 0 < x) (hr : 0 < r) (hω : 0 < ω)
    (hs : 2*d=1+x) (hp : d^2+ω^2=x/r) :
    0 < Real.pi/ω ∧ e (Real.pi/ω) < 0 := by
  have ht : 0 < Real.pi/ω := div_pos Real.pi_pos hω
  refine ⟨ht,?_⟩
  rw [(pi_state_unique h (complex_response x r d ω hω hs hp) hx hr _ ht.le).1]
  have heq : ω*(Real.pi/ω)=Real.pi := by field_simp
  simp only [complexError,heq,Real.cos_pi,Real.sin_pi,mul_zero,add_zero,mul_neg_one]
  exact neg_neg_of_pos (Real.exp_pos _)
end MIACE
