import MIACE.IMCResolvent

/-! Stage 13: causal operators on ordinary locally integrable signals.
Finite truncations extend the checked L1 identities without assuming
exponential order or eventual decay of a competing evolution. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

structure CausalLocalOperator (A : (ℝ → ℝ) → ℝ → ℝ) : Prop where
  integrable : ∀ {f}, Integrable f → Integrable (A f)
  causal : ∀ {f}, Causal f → Causal (A f)
  congr : ∀ {f g}, f=ᵐ[volume] g → A f=ᵐ[volume] A g
  locality : ∀ {f}, Causal f → ∀ T : ℝ, ∀ᵐ t, t≤T → A f t=A (causalTruncate T f) t

-- @paper-step thm:complete_robust/causal_convolution_local_operator
theorem convolution_local_operator {K : ℝ → ℝ} (hK : Integrable K) (hKc : Causal K) :
    CausalLocalOperator (fun f => K ⋆ f) := by
  refine ⟨fun hf => hK.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hf,
    fun hf => ae_of_all _ (convolution_causal hKc hf),?_,?_⟩
  · intro f g he
    exact EventuallyEq.of_eq (convolution_congr (ContinuousLinearMap.lsmul ℝ ℝ)
      (EventuallyEq.rfl (f := K)) he)
  · intro f hf T
    apply ae_of_all
    intro t ht
    by_cases hp : 0≤t
    · exact (convolution_causalTruncate hKc hf ⟨hp,ht⟩).symm
    · rw [convolution_causal hKc hf t (lt_of_not_ge hp),
        convolution_causal hKc (causalTruncate_causal f T) t (lt_of_not_ge hp)]

-- @paper-step thm:complete_robust/filter_local_operator
theorem filter_local_operator (F : IMCFilter) : CausalLocalOperator (filterAction F) := by
  refine ⟨filterAction_integrable F,filterAction_causal F,filterAction_congr F,?_⟩
  intro f hf T
  have hs := (measurePreserving_sub_right (volume : Measure ℝ) F.delay).quasiMeasurePreserving.tendsto_ae.eventually hf
  have hc := (convolution_local_operator (lagKernel_properties F.timeConstant_pos).1
    (lagKernel_properties F.timeConstant_pos).2.2.2).locality hf T
  filter_upwards [hf,hs,hc,filterAction_causal F hf,
    filterAction_causal F (causalTruncate_causal f T)] with t ht hst hct hft hgt htT
  by_cases hp : 0≤t
  · have h₁ : causalTruncate T f t=f t := by simp [causalTruncate,show t∈Icc (0 : ℝ) T from ⟨hp,htT⟩]
    have h₂ : shift F.delay (causalTruncate T f) t=shift F.delay f t := by
      unfold shift
      by_cases hd : 0≤t-F.delay
      · simp [causalTruncate,show t-F.delay∈Icc (0 : ℝ) T from ⟨hd,by linarith [F.delay_nonneg]⟩]
      · simp [causalTruncate,show t-F.delay∉Icc (0 : ℝ) T from fun h => hd h.1,hst (lt_of_not_ge hd)]
    simp only [filterAction,h₁,h₂,hct htT]
  · rw [hft (lt_of_not_ge hp),hgt (lt_of_not_ge hp)]

-- @paper-step thm:complete_robust/local_operator_preserves_local_integrability
theorem causalLocalOperator_local_integrable {A : (ℝ → ℝ) → ℝ → ℝ}
    (hA : CausalLocalOperator A) {f : ℝ → ℝ} (hf : LocallyIntegrable f volume) (hfc : Causal f) :
    LocallyIntegrable (A f) volume := by
  apply locallyIntegrable_iff.mpr
  intro k hk
  obtain ⟨T,hT⟩ := hk.bddAbove
  have hi := (hA.integrable (causalTruncate_integrable hf T)).integrableOn (s := k)
  apply hi.congr
  have hl := (hA.locality hfc T).filter_mono (ae_mono (Measure.restrict_le_self (s := k)))
  filter_upwards [hl,ae_restrict_mem hk.measurableSet] with t ht htk
  exact (ht (hT htk)).symm

-- @paper-step thm:complete_robust/causal_local_operator_composition
theorem causalLocalOperator_comp {A B : (ℝ → ℝ) → ℝ → ℝ}
    (hA : CausalLocalOperator A) (hB : CausalLocalOperator B) :
    CausalLocalOperator (fun f => A (B f)) := by
  refine ⟨fun hf => hA.integrable (hB.integrable hf),
    fun hf => hA.causal (hB.causal hf),fun he => hA.congr (hB.congr he),?_⟩
  intro f hf T
  have he : causalTruncate T (B f)=ᵐ[volume] causalTruncate T (B (causalTruncate T f)) := by
    filter_upwards [hB.locality hf T] with t ht
    by_cases hm : t∈Icc (0 : ℝ) T
    · simp only [causalTruncate,indicator_of_mem hm]
      exact ht hm.2
    · simp [causalTruncate,hm]
  filter_upwards [hA.locality (hB.causal hf) T,
    hA.locality (hB.causal (causalTruncate_causal f T)) T,hA.congr he] with t ht hs hh htT
  exact (ht htT).trans (hh.trans (hs htT).symm)

-- @paper-step thm:complete_robust/L1_identity_extends_to_all_ordinary_signals
theorem causalLocalOperator_ext {A B : (ℝ → ℝ) → ℝ → ℝ}
    (hA : CausalLocalOperator A) (hB : CausalLocalOperator B)
    (he : ∀ f : ℝ → ℝ, Integrable f → Causal f → A f=ᵐ[volume] B f)
    {f : ℝ → ℝ} (hf : LocallyIntegrable f volume) (hfc : Causal f) :
    A f=ᵐ[volume] B f := by
  have hN (n : ℕ) : ∀ᵐ t : ℝ, t≤n → A f t=B f t := by
    filter_upwards [hA.locality hfc n,hB.locality hfc n,
      he (causalTruncate n f) (causalTruncate_integrable hf n) (causalTruncate_causal f n)]
      with t ht hs hh htn
    rw [ht htn,hs htn,hh]
  filter_upwards [ae_all_iff.mpr hN] with t ht
  obtain ⟨n,hn⟩ := exists_nat_ge t
  exact ht n hn

-- @paper-step thm:complete_robust/local_operator_linear_combination
theorem causalLocalOperator_linear {A B : (ℝ → ℝ) → ℝ → ℝ}
    (hA : CausalLocalOperator A) (hB : CausalLocalOperator B) (a b : ℝ) :
    CausalLocalOperator (fun f t => a*A f t+b*B f t) := by
  refine ⟨fun hf => ((hA.integrable hf).const_mul a).add ((hB.integrable hf).const_mul b),
    fun hf => causal_linear (hA.causal hf) (hB.causal hf) a b,?_,?_⟩
  · intro f g he
    filter_upwards [hA.congr he,hB.congr he] with t ht hs
    rw [ht,hs]
  · intro f hf T
    filter_upwards [hA.locality hf T,hB.locality hf T] with t ht hs htT
    rw [ht htT,hs htT]

-- @paper-step thm:complete_robust/local_kernel_difference_identity
theorem local_kernel_sub {K H u : ℝ → ℝ}
    (hK : Integrable K) (hH : Integrable H) (hKc : Causal K) (hHc : Causal H)
    (hu : LocallyIntegrable u volume) (huc : Causal u) :
    ((fun t => K t-H t) ⋆ u)=ᵐ[volume] (fun t => (K ⋆ u) t-(H ⋆ u) t) := by
  have hDc : Causal (fun t => K t-H t) := by
    filter_upwards [hKc,hHc] with t ht hs hn; simp [ht hn,hs hn]
  have hB := causalLocalOperator_linear (convolution_local_operator hK hKc)
    (convolution_local_operator hH hHc) 1 (-1)
  have hh := causalLocalOperator_ext (convolution_local_operator (hK.sub hH) hDc) hB
    (fun f hf hfc => by
      filter_upwards [hK.ae_convolution_exists (ContinuousLinearMap.lsmul ℝ ℝ) hf,
        hH.ae_convolution_exists (ContinuousLinearMap.lsmul ℝ ℝ) hf] with t ht hs
      change (∫ s, (K s-H s)*f (t-s))=1*(∫ s, K s*f (t-s))+(-1)*(∫ s, H s*f (t-s))
      simp_rw [sub_mul]
      have hti : Integrable (fun s => K s*f (t-s)) := ht
      have hsi : Integrable (fun s => H s*f (t-s)) := hs
      rw [integral_sub hti hsi]; ring) hu huc
  filter_upwards [hh] with t ht
  change ((fun s => K s-H s) ⋆ u) t=1*(K ⋆ u) t+(-1)*(H ⋆ u) t at ht
  linarith

-- @paper-step thm:complete_robust/local_filter_difference_identity
theorem local_filter_sub (F : IMCFilter) {u v : ℝ → ℝ}
    (hu : LocallyIntegrable u volume) (hv : LocallyIntegrable v volume)
    (huc : Causal u) (hvc : Causal v) :
    filterAction F (fun t => u t-v t)=ᵐ[volume] (fun t => filterAction F u t-filterAction F v t) := by
  filter_upwards [local_convolution_sub (lagKernel_properties F.timeConstant_pos).1
    (lagKernel_properties F.timeConstant_pos).2.2.2 hu hv huc hvc] with t ht
  unfold filterAction
  rw [ht]
  simp only [shift]
  ring

end MIACE
