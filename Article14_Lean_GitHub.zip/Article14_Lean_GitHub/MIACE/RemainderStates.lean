import MIACE.RemainderFilter
import MIACE.CompactForced
import MIACE.IMCWellPosed

namespace MIACE
open MeasureTheory Filter Set Polynomial
open scoped Topology Convolution

-- @paper-step thm:n_construction/causal_linear_combination_weighted_control
theorem causal_linear_control {η C D : ℝ} {f g : ℝ → ℝ}
    (hf : WeightedControl η (causalize f) C) (hg : WeightedControl η (causalize g) D)
    (a b : ℝ) : WeightedControl η (causalize (fun t => a*f t+b*g t)) (|a| *C+|b| *D) := by
  apply weightedControl_congr (weightedControl_add (weightedControl_smul hf a) (weightedControl_smul hg b))
  apply ae_of_all
  intro t
  by_cases ht : 0≤t <;> simp [causalize,ht]

-- Every storage coordinate of the I/B realization is controlled uniformly.
-- @paper-step thm:n_construction/remainder_filter_uniform_all_state_control
theorem remainderFilter_uniform_control (r : ℕ → ℝ) (δ η : ℝ) (n : ℕ)
    (hr : ∀ j≤n, 0<r j ∧ η<r j) :
    ∃ C : ℝ, 0≤C ∧ ∀ M D : ℝ, 0≤M → ∀ ξ : ℕ → ℝ,
      (∀ j≤n, |ξ j|≤M) → ∀ u : ℝ → ℝ, WeightedControl η (causalize u) D →
      ∀ j≤n, WeightedControl η (causalize (remainderFilter r δ ξ u j)) (C*(M+D)) := by
  induction n with
  | zero =>
    obtain ⟨K,hK⟩ := lagKernel_weightedControl (one_div_pos.mpr (hr 0 le_rfl).1)
      (by simpa using (hr 0 le_rfl).2)
    let C := K*(1/r 0+|remainderFeed r δ 0|)
    have hC : 0≤C := by dsimp [C]; have := hK.nonneg; have := (hr 0 le_rfl).1; positivity
    refine ⟨C,hC,?_⟩
    intro M D hM ξ hξ u hu j hj
    have hj0 : j=0 := by omega
    subst j
    have hinput : WeightedControl η (causalize (fun t => remainderFeed r δ 0*u t))
        (|remainderFeed r δ 0| *D) := by
      apply weightedControl_congr (weightedControl_smul hu (remainderFeed r δ 0))
      exact ae_of_all _ (fun t => by by_cases ht : 0≤t <;> simp [causalize,ht])
    apply weightedControl_mono (lagState_weighted_control (one_div_pos.mpr (hr 0 le_rfl).1) hK hinput (ξ 0))
    rw [abs_mul,abs_of_pos (one_div_pos.mpr (hr 0 le_rfl).1)]
    have hh := mul_le_mul_of_nonneg_right (hξ 0 le_rfl)
      (mul_nonneg (one_div_pos.mpr (hr 0 le_rfl).1).le hK.nonneg)
    dsimp [C]
    nlinarith [mul_nonneg (mul_nonneg hK.nonneg (one_div_pos.mpr (hr 0 le_rfl).1).le) hu.nonneg,
      mul_nonneg (mul_nonneg hK.nonneg (abs_nonneg (remainderFeed r δ 0))) hM]
  | succ n ih =>
    obtain ⟨C,hC,hprev⟩ := ih (fun j hj => hr j (by omega))
    obtain ⟨K,hK⟩ := lagKernel_weightedControl (one_div_pos.mpr (hr (n+1) le_rfl).1)
      (by simpa using (hr (n+1) le_rfl).2)
    let A := K*(1/r (n+1)+C+|remainderFeed r δ (n+1)|)
    have hA : 0≤A := by dsimp [A]; have := hK.nonneg; have := (hr (n+1) le_rfl).1; positivity
    refine ⟨C+A,add_nonneg hC hA,?_⟩
    intro M D hM ξ hξ u hu j hj
    have hMD := add_nonneg hM hu.nonneg
    by_cases hjn : j≤n
    · apply weightedControl_mono (hprev M D hM ξ (fun k hk => hξ k (by omega)) u hu j hjn)
      nlinarith
    · have hje : j=n+1 := by omega
      subst j
      have hh := causal_linear_control (hprev M D hM ξ (fun k hk => hξ k (by omega)) u hu n le_rfl)
        hu 1 (remainderFeed r δ (n+1))
      simp only [abs_one,one_mul] at hh
      apply weightedControl_mono (lagState_weighted_control (one_div_pos.mpr (hr (n+1) le_rfl).1) hK hh (ξ (n+1)))
      rw [abs_mul,abs_of_pos (one_div_pos.mpr (hr (n+1) le_rfl).1)]
      have hi := mul_le_mul_of_nonneg_right (hξ (n+1) le_rfl)
        (mul_nonneg (one_div_pos.mpr (hr (n+1) le_rfl).1).le hK.nonneg)
      dsimp [A]
      nlinarith [mul_nonneg hC hMD,
        mul_nonneg (mul_nonneg hK.nonneg (one_div_pos.mpr (hr (n+1) le_rfl).1).le) hu.nonneg,
        mul_nonneg (mul_nonneg hK.nonneg (abs_nonneg (remainderFeed r δ (n+1)))) hM]

-- @paper-step thm:n_construction/plant_B_cascade_integrability
theorem serialState_integrable {u : ℝ → ℝ} (hu : Integrable u halfLine)
    (σ ξ : ℕ → ℝ) (n : ℕ) (hσ : ∀ j<n, 0<σ j) :
    Integrable (serialState σ ξ u n) halfLine := by
  induction n with
  | zero => exact hu
  | succ n ih => exact lagState_integrable (ih (fun j hj => hσ j (by omega))) (hσ n (by omega)) _

-- @paper-step thm:n_construction/plant_B_actual_transform_with_initial_transient
theorem serialB_laplace {u : ℝ → ℝ} (hu : Integrable u halfLine)
    (r ξ : ℕ → ℝ) (n : ℕ) (hr : ∀ j≤n, 0<r j) {p : ℝ} (hp : 0≤p) :
    laplace (serialState (fun j => 1/r j) ξ u (n+1)) p=
      laplace (serialState (fun j => 1/r j) ξ (fun _ => 0) (n+1)) p+
        laplace u p/(remainderB r n).eval p := by
  have hz : Integrable (fun _ : ℝ => (0 : ℝ)) halfLine := integrable_zero _ _ _
  induction n with
  | zero =>
    simp only [serialState]
    rw [lagState_laplace hu (one_div_pos.mpr (hr 0 le_rfl)) hp,
      lagState_laplace hz (one_div_pos.mpr (hr 0 le_rfl)) hp]
    simp [laplace,remainderB]
    ring
  | succ n ih =>
    have hr' : ∀ j≤n, 0<r j := fun j hj => hr j (by omega)
    have hs : ∀ j<n+1, 0<1/r j := fun j hj => one_div_pos.mpr (hr' j (by omega))
    change laplace (lagState (1/r (n+1)) (ξ (n+1)) (serialState (fun j => 1/r j) ξ u (n+1))) p = laplace (lagState (1/r (n+1)) (ξ (n+1)) (serialState (fun j => 1/r j) ξ (fun _ => 0) (n+1))) p + _
    rw [lagState_laplace (serialState_integrable hu _ ξ _ hs) (one_div_pos.mpr (hr (n+1) le_rfl)) hp,
      lagState_laplace (serialState_integrable hz _ ξ _ hs) (one_div_pos.mpr (hr (n+1) le_rfl)) hp,
      ih hr']
    simp only [remainderB,eval_mul,eval_add,eval_C,eval_X,eval_one]
    have hd : 1+1/r (n+1)*p≠0 := ne_of_gt (by have := hr (n+1) le_rfl; positivity)
    field_simp [ne_of_gt (remainderB_eval_pos r n hr' hp),hd]
    ring

-- Choose one decay rate for the compact resolvent and every storage pole.
-- @paper-step thm:n_construction/common_positive_full_state_decay_rate
theorem finite_decay_rate (r : ℕ → ℝ) (n : ℕ) (hr : ∀ j≤n, 0<r j)
    {β : ℝ} (hβ : 0<β) : ∃ η : ℝ, 0<η ∧ η≤β ∧ η<1 ∧ ∀ j≤n, η<r j := by
  induction n with
  | zero =>
    let η := min β (min 1 (r 0))/2
    have hp : 0<min β (min 1 (r 0)) := lt_min hβ (lt_min zero_lt_one (hr 0 le_rfl))
    refine ⟨η,by dsimp [η]; positivity,?_,?_,?_⟩
    · dsimp [η]; linarith [min_le_left β (min 1 (r 0))]
    · dsimp [η]; linarith [(min_le_right β (min 1 (r 0))).trans (min_le_left 1 (r 0))]
    · intro j hj
      have hj0 : j=0 := by omega
      subst j
      dsimp [η]; linarith [(min_le_right β (min 1 (r 0))).trans (min_le_right 1 (r 0))]
  | succ n ih =>
    obtain ⟨η,hη,hηβ,hη1,hηr⟩ := ih (fun j hj => hr j (by omega))
    have hnext := hr (n+1) le_rfl
    refine ⟨min η (r (n+1))/2,by positivity,?_,?_,?_⟩
    · linarith [min_le_left η (r (n+1))]
    · linarith [min_le_left η (r (n+1))]
    · intro j hj
      by_cases hjn : j≤n
      · linarith [hηr j hjn,min_le_left η (r (n+1))]
      · have hj' : j=n+1 := by omega
        subst j
        linarith [min_le_right η (r (n+1)),hr (n+1) le_rfl]

end MIACE
