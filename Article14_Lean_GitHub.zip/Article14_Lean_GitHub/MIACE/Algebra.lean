import Mathlib.Tactic

/-! Exact real algebra shared by the MIACE proofs.
No signal balance or dynamical stability is asserted in this module.
The comments @paper-step are stable links into docs/proof-map.json. -/
namespace MIACE

noncomputable def costSq (α Ae Au : ℝ) : ℝ := Ae ^ 2 + α * Au ^ 2
noncomputable def baseSq (α S : ℝ) : ℝ := S ^ 2 * α / (1 + α)

-- @paper-step thm:miace_shape_gap/decomposition
 theorem weighted_decomposition (α Ae Au : ℝ) (hα : 0 < α) :
    costSq α Ae Au = α / (1 + α) * (Ae + Au)^2 +
      (Ae - α * Au)^2 / (1 + α) := by
  unfold costSq
  have h : 1 + α ≠ 0 := ne_of_gt (by linarith)
  field_simp
  <;> ring

-- @paper-step thm:n_gap/excess
 theorem excess_identity (α S Ae Au N : ℝ) (hα : 0 < α)
    (balance : Ae + Au = S + 2 * N) :
    costSq α Ae Au - baseSq α S =
      4 * α / (1 + α) * N * (S + N) + (Ae - α * Au)^2 / (1 + α) := by
  rw [weighted_decomposition α Ae Au hα, balance]
  unfold baseSq
  have h : 1 + α ≠ 0 := ne_of_gt (by linarith)
  field_simp
  <;> ring

-- @paper-step thm:n_gap/lower_bound
 theorem cost_lower_bound (α S Ae Au N : ℝ) (hα : 0 < α)
    (hS : 0 ≤ S) (hN : 0 ≤ N) (balance : Ae + Au = S + 2 * N) :
    baseSq α S ≤ costSq α Ae Au := by
  have h := excess_identity α S Ae Au N hα balance
  have hp : 0 ≤ 4 * α / (1 + α) * N * (S + N) := by positivity
  have hq : 0 ≤ (Ae - α * Au)^2 / (1 + α) := by positivity
  linarith

-- @paper-step thm:n_gap/equality
 theorem cost_eq_iff (α S Ae Au N : ℝ) (hα : 0 < α)
    (hS : 0 < S) (hN : 0 ≤ N) (balance : Ae + Au = S + 2 * N) :
    costSq α Ae Au = baseSq α S ↔ N = 0 ∧ Ae = α * Au := by
  have hid := excess_identity α S Ae Au N hα balance
  have hp : 0 ≤ 4 * α / (1 + α) * N * (S + N) := by positivity
  have hq : 0 ≤ (Ae - α * Au)^2 / (1 + α) := by positivity
  constructor
  · intro heq
    have hz : 4 * α / (1 + α) * N * (S + N) = 0 := by linarith
    have hco : 0 < 4 * α / (1 + α) := by positivity
    have hsn : 0 < S + N := by linarith
    have hn : N = 0 := by
      by_contra hn
      have : 0 < 4 * α / (1 + α) * N * (S + N) :=
        mul_pos (mul_pos hco (lt_of_le_of_ne hN (Ne.symm hn))) hsn
      linarith
    have hdiv : (Ae - α * Au)^2 / (1 + α) = 0 := by linarith
    have hs : (Ae - α * Au)^2 = 0 := (div_eq_zero_iff).mp hdiv |>.resolve_right (by linarith)
    have hd : Ae - α * Au = 0 := (sq_eq_zero_iff).mp hs
    exact ⟨hn, by linarith⟩
  · rintro ⟨rfl, heq⟩
    rw [heq] at hid
    simp at hid
    rw [heq]
    linarith

-- @paper-step thm:complete_attainment/optimal_areas
 theorem equality_areas (α S Ae Au : ℝ) (hα : 0 < α)
    (balance : Ae + Au = S) (ratio : Ae = α * Au) :
    Au = S / (1 + α) ∧ Ae = α * S / (1 + α) := by
  have h : 1 + α ≠ 0 := ne_of_gt (by linarith)
  constructor
  · apply (eq_div_iff h).2
    nlinarith
  · apply (eq_div_iff h).2
    nlinarith

-- @paper-step thm:complete_attainment/threshold
 theorem attainment_threshold (α S : ℝ) (hα : 0 < α) :
    S / (1 + α) < 1 ↔ S - 1 < α := by
  rw [div_lt_iff₀ (by linarith : 0 < 1 + α)]
  constructor <;> intro h <;> linarith

-- @paper-step thm:complete_attainment/filter_parameter
 theorem filter_parameter (U : ℝ) (hU : 0 < U) (hU1 : U < 1) :
    0 < 1 - U ∧ 1 - U < 1 ∧ 1 - (1 - U) = U := by
  constructor
  · linarith
  constructor <;> linarith

-- @paper-step thm:complete_cap/completion
 theorem front_completion (α S U : ℝ) (hα : 0 < α) :
    costSq α (S - U) U = baseSq α S +
      (1 + α) * (U - S / (1 + α))^2 := by
  unfold costSq baseSq
  have h : 1 + α ≠ 0 := ne_of_gt (by linarith)
  field_simp
  <;> ring

-- @paper-step thm:complete_cap/projection
 theorem capped_front_minimizer (α S cap U : ℝ) (hα : 0 < α)
    (hU : U ≤ cap) :
    costSq α (S - min (S / (1 + α)) cap) (min (S / (1 + α)) cap) ≤
      costSq α (S - U) U := by
  rw [front_completion α S _ hα, front_completion α S _ hα]
  by_cases h : S / (1 + α) ≤ cap
  · rw [min_eq_left h]
    simp only [sub_self, zero_pow (by decide : 2 ≠ 0), mul_zero, add_zero]
    have hn : 0 ≤ (1 + α) * (U - S / (1 + α))^2 := by positivity
    linarith
  · rw [min_eq_right (le_of_not_ge h)]
    have hcu : cap < S / (1 + α) := lt_of_not_ge h
    have hs : (cap - S / (1 + α))^2 ≤ (U - S / (1 + α))^2 := by
      nlinarith [sq_nonneg (cap - U)]
    have hp := mul_le_mul_of_nonneg_left hs (show 0 ≤ 1 + α by linarith)
    linarith

-- @paper-step thm:miace_variation/near_optimal
 theorem near_optimal_shape (M m V B N ε : ℝ) (hm : 0 < m)
    (hM : M ≤ (1 + ε) * m) (hVN : V = 1 + 2 * B)
    (hBN : B ≤ N) (hNM : 1 + 2 * N ≤ M / m) :
    V - 1 ≤ ε ∧ B ≤ ε / 2 ∧ N ≤ ε / 2 := by
  have hratio : M / m ≤ 1 + ε := (div_le_iff₀ hm).2 hM
  constructor
  · linarith
  constructor <;> linarith

end MIACE
