import MIACE.GeneralCost

/-! Exact transport delay. The paper assumes an admissible shifted response f;
the physical error is 1 during the wait and f(t-δ) afterwards. Translation
of Lebesgue measure accounts for every area; no balance is postulated. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def delayTail (δ : ℝ) (f : ℝ → ℝ) : ℝ → ℝ :=
  (Ioi δ).indicator (fun t => f (t-δ))
noncomputable def delayedError (δ : ℝ) (f : ℝ → ℝ) (t : ℝ) : ℝ :=
  if t ≤ δ then 1 else f (t-δ)

-- @paper-step thm:delayed_shape/translation_measure
theorem translate_halfLine (δ : ℝ) :
    MeasurePreserving (fun t : ℝ => t+δ) halfLine (volume.restrict (Ioi δ)) := by
  convert (measurePreserving_add_right (volume : Measure ℝ) δ).restrict_preimage
    (measurableSet_Ioi : MeasurableSet (Ioi δ)) using 1 <;> simp [halfLine]

-- @paper-step thm:delayed_shape/translation_integral
theorem tail_integral_translation (δ : ℝ) (f : ℝ → ℝ) :
    (∫ t in Ioi δ, f (t-δ)) = ∫ t, f t ∂halfLine := by
  have hm := (translate_halfLine δ).integral_comp
    (Homeomorph.addRight δ).isClosedEmbedding.measurableEmbedding (fun t => f (t-δ))
  simpa using hm.symm

-- @paper-step thm:delayed_shape/translation_integrable
theorem tail_integrable_translation (δ : ℝ) {f : ℝ → ℝ}
    (hf : Integrable f halfLine) : IntegrableOn (fun t => f (t-δ)) (Ioi δ) := by
  have hm := (translate_halfLine δ).integrable_comp_emb
    (Homeomorph.addRight δ).isClosedEmbedding.measurableEmbedding
    (g := fun t => f (t-δ))
  apply hm.mp
  simpa [Function.comp_def] using hf

-- @paper-step thm:delayed_shape/tail_integral
theorem delayTail_integral (δ : ℝ) (hδ : 0 ≤ δ) (f : ℝ → ℝ) :
    (∫ t, delayTail δ f t ∂halfLine) = ∫ t, f t ∂halfLine := by
  unfold delayTail halfLine
  rw [integral_indicator measurableSet_Ioi, Measure.restrict_restrict measurableSet_Ioi]
  have hs : Ioi δ ∩ Ioi (0 : ℝ) = Ioi δ := inter_eq_left.mpr
    (fun t ht => lt_of_le_of_lt hδ ht)
  rw [hs]
  exact tail_integral_translation δ f

-- @paper-step thm:delayed_shape/tail_integrable
theorem delayTail_integrable (δ : ℝ) (hδ : 0 ≤ δ) {f : ℝ → ℝ}
    (hf : Integrable f halfLine) : Integrable (delayTail δ f) halfLine := by
  apply (tail_integrable_translation δ hf).integrable_indicator measurableSet_Ioi |>.mono_measure
  exact Measure.restrict_le_self

-- @paper-step thm:delayed_shape/waiting_split
theorem delayedError_split (δ : ℝ) (f : ℝ → ℝ) :
    delayedError δ f =ᵐ[halfLine] (fun t => pulse 1 δ t + delayTail δ f t) := by
  filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
  change 0 < t at ht
  by_cases h : t ≤ δ
  · simp [delayedError,pulse,delayTail,h,ht,not_lt.mpr h]
  · have hd : δ < t := lt_of_not_ge h
    simp [delayedError,pulse,delayTail,h,hd]

-- @paper-step thm:delayed_shape/error_integrable
theorem delayedError_integrable (δ : ℝ) (hδ : 0 ≤ δ) {f : ℝ → ℝ}
    (hf : Integrable f halfLine) : Integrable (delayedError δ f) halfLine :=
  ((pulse_integrable 1 δ).add (delayTail_integrable δ hδ hf)).congr
    (delayedError_split δ f).symm

-- @paper-step thm:delayed_shape/error_area
theorem delayedError_absArea (δ : ℝ) (hδ : 0 ≤ δ) {f : ℝ → ℝ}
    (hf : Integrable f halfLine) :
    absArea (delayedError δ f) halfLine = δ+absArea f halfLine := by
  have heq : (fun t => |delayedError δ f t|) = delayedError δ (fun t => |f t|) := by
    funext t
    by_cases ht : t ≤ δ <;> simp [delayedError,ht]
  unfold absArea
  have habs : Integrable (fun t => |f t|) halfLine := hf.norm
  rw [heq,integral_congr_ae (delayedError_split δ _),
    integral_add (pulse_integrable 1 δ) (delayTail_integrable δ hδ habs),
    delayTail_integral δ hδ]
  have hp := pulse_area 1 δ hδ
  simpa [commandArea] using congrArg (fun a => a+∫ t, |f t| ∂halfLine) hp

-- @paper-step thm:delayed_shape/negative_area
theorem delayedError_negArea (δ : ℝ) (hδ : 0 ≤ δ) (f : ℝ → ℝ) :
    negArea (delayedError δ f) halfLine = negArea f halfLine := by
  have heq : (fun t => max (-delayedError δ f t) 0) =
      delayTail δ (fun t => max (-f t) 0) := by
    funext t
    by_cases ht : t ≤ δ
    · simp [delayedError,delayTail,ht,not_lt.mpr ht]
    · simp [delayedError,delayTail,ht,lt_of_not_ge ht]
  unfold negArea
  rw [heq,delayTail_integral δ hδ]

-- @paper-step thm:delayed_shape/delay_balance
theorem delayed_signed_balance {f v : ℝ → ℝ} (h : FirstOrderResponse f v)
    (δ : ℝ) (hδ : 0 ≤ δ) :
    (∫ t, delayedError δ f t ∂halfLine)+(∫ t, v t ∂halfLine) = 1+δ := by
  rw [integral_congr_ae (delayedError_split δ f),
    integral_add (pulse_integrable 1 δ) (delayTail_integrable δ hδ h.error_integrable),
    delayTail_integral δ hδ]
  have hp := pulse_area 1 δ hδ
  have hb := response_signed_balance h
  unfold commandArea at hp
  linarith

-- @paper-step thm:delayed_shape/output_derivative
theorem delayed_output_derivative (δ : ℝ) (f : ℝ → ℝ) :
    deriv (fun t => 1-delayedError δ f t) =ᵐ[volume]
      delayTail δ (deriv (fun t => 1-f t)) := by
  have hne : ∀ᵐ t : ℝ, t ≠ δ := by rw [ae_iff]; simp
  filter_upwards [hne] with t ht
  by_cases hd : t < δ
  · have heq : (fun s => 1-delayedError δ f s) =ᶠ[𝓝 t] (fun _ => 0) := by
      filter_upwards [Iio_mem_nhds hd] with s hs
      change s < δ at hs
      simp [delayedError,le_of_lt hs]
    rw [heq.deriv_eq]
    simp [delayTail,not_lt.mpr hd.le]
  · have hd' : δ < t := lt_of_le_of_ne (le_of_not_gt hd) (Ne.symm ht)
    have heq : (fun s => 1-delayedError δ f s) =ᶠ[𝓝 t]
        (fun s => (fun u => 1-f u) (s-δ)) := by
      filter_upwards [Ioi_mem_nhds hd'] with s hs
      change δ < s at hs
      simp [delayedError,not_le.mpr hs]
    rw [heq.deriv_eq,deriv_comp_sub_const (fun u => 1-f u) δ t]
    simp [delayTail,hd']

-- @paper-step thm:delayed_shape/variation_translation
theorem delayed_variation_eq (δ : ℝ) (hδ : 0 ≤ δ) (f : ℝ → ℝ) :
    outputVariation (delayedError δ f) = outputVariation f ∧
    backwardMotion (delayedError δ f) = backwardMotion f := by
  have hd := ae_restrict_of_ae (μ := volume) (s := Ioi 0) (delayed_output_derivative δ f)
  constructor
  · unfold outputVariation absArea
    calc
      _ = ∫ t, delayTail δ (fun s => |deriv (fun u => 1-f u) s|) t ∂halfLine := by
        apply integral_congr_ae
        filter_upwards [hd] with t ht
        rw [ht]
        by_cases h : δ < t <;> simp [delayTail,h]
      _ = _ := delayTail_integral δ hδ _
  · unfold backwardMotion negArea
    calc
      _ = ∫ t, delayTail δ (fun s => max (-deriv (fun u => 1-f u) s) 0) t ∂halfLine := by
        apply integral_congr_ae
        filter_upwards [hd] with t ht
        rw [ht]
        by_cases h : δ < t <;> simp [delayTail,h]
      _ = _ := delayTail_integral δ hδ _

-- @paper-step thm:delayed_shape/peak_translation
theorem delayed_peak_bound {f v : ℝ → ℝ} (h : FirstOrderResponse f v)
    (δ : ℝ) : peak (delayedError δ f) (Ici 0) ≤ backwardMotion f := by
  rw [(actual_variation_eq h).2]
  apply csSup_le
  · exact ⟨max (-delayedError δ f 0) 0,0,by simp,rfl⟩
  · rintro z ⟨t,ht,rfl⟩
    by_cases hd : t ≤ δ
    · simp only [delayedError,if_pos hd]
      norm_num
      exact negative_area_nonneg _
    · simp only [delayedError,if_neg hd]
      exact response_pointwise_peak h (by linarith)

-- @paper-step thm:delayed_shape/monotone_translation
theorem delayed_output_monotone {f v : ℝ → ℝ} (h : FirstOrderResponse f v)
    (hf : ∀ᵐ t ∂halfLine, 0 ≤ f t) (hv : ∀ᵐ t ∂halfLine, 0 ≤ v t)
    (δ : ℝ) : MonotoneOn (fun t => 1-delayedError δ f t) (Ici 0) := by
  intro a ha b hb hab
  by_cases hbd : b ≤ δ
  · simp [delayedError,hbd,hab.trans hbd]
  · by_cases had : a ≤ δ
    · simp only [delayedError,if_pos had,if_neg hbd,sub_self]
      exact (response_output_bounds h hf hv (by linarith : 0 ≤ b-δ)).1
    · simp only [delayedError,if_neg had,if_neg hbd]
      apply response_output_monotone h hf hv
      · change 0 ≤ a-δ
        linarith
      · change 0 ≤ b-δ
        linarith
      · linarith

-- @paper-step thm:delayed_shape/output_endpoints
theorem delayed_endpoints {f v : ℝ → ℝ} (h : FirstOrderResponse f v)
    (δ : ℝ) (hδ : 0 ≤ δ) :
    1-delayedError δ f 0 = 0 ∧
    Tendsto (fun t => 1-delayedError δ f t) atTop (𝓝 1) := by
  refine ⟨by simp [delayedError,hδ],?_⟩
  have ht : Tendsto (fun t : ℝ => t-δ) atTop atTop := by
    apply tendsto_atTop.2
    intro b
    filter_upwards [eventually_ge_atTop (b+δ)] with t ht
    linarith
  have hf : Tendsto (fun t => f (t-δ)) atTop (𝓝 0) := h.finalValue.comp ht
  have heq : delayedError δ f =ᶠ[atTop] (fun t => f (t-δ)) := by
    filter_upwards [eventually_gt_atTop δ] with t ht
    simp [delayedError,not_le.mpr ht]
  have hd : Tendsto (delayedError δ f) atTop (𝓝 0) := hf.congr' heq.symm
  simpa using tendsto_const_nhds.sub hd

-- All clauses of Theorem 5, including the waiting area and actual y' semantics.
-- @paper-step thm:delayed_shape/full_statement
theorem paper_delayed_shape {f v : ℝ → ℝ} (h : FirstOrderResponse f v)
    (α δ : ℝ) (hα : 0 < α) (hδ : 0 ≤ δ) :
    let e := delayedError δ f
    ((miace α e v halfLine)^2-(1+δ)^2*(minimum α)^2 =
      4*(minimum α)^2*(negArea e halfLine+negArea v halfLine)*
        (1+δ+(negArea e halfLine+negArea v halfLine)) +
      (absArea e halfLine-α*absArea v halfLine)^2/(1+α)) ∧
    (1+δ)*minimum α ≤ miace α e v halfLine ∧
    (miace α e v halfLine = (1+δ)*minimum α ↔
      (∀ᵐ t ∂halfLine, 0 ≤ e t) ∧ (∀ᵐ t ∂halfLine, 0 ≤ v t) ∧
      absArea e halfLine = α*absArea v halfLine) ∧
    (miace α e v halfLine = (1+δ)*minimum α →
      MonotoneOn (fun t => 1-e t) (Ici 0)) ∧
    (1-e 0 = 0 ∧ Tendsto (fun t => 1-e t) atTop (𝓝 1)) ∧
    1 ≤ outputVariation e ∧ outputVariation e = 1+2*backwardMotion e ∧
    outputVariation e ≤ absArea e halfLine+absArea v halfLine-δ ∧
    absArea e halfLine+absArea v halfLine-δ = 1+2*(negArea e halfLine+negArea v halfLine) ∧
    absArea e halfLine+absArea v halfLine-δ ≤ miace α e v halfLine/minimum α-δ ∧
    peak e (Ici 0) ≤ backwardMotion e ∧
    backwardMotion e ≤ negArea e halfLine+negArea v halfLine ∧
    negArea e halfLine+negArea v halfLine ≤ (miace α e v halfLine/minimum α-1-δ)/2 := by
  dsimp only
  have he := delayedError_integrable δ hδ h.error_integrable
  have hb := delayed_signed_balance h δ hδ
  have hS : 0 < 1+δ := by linarith
  have heq := signal_miace_equality_iff he h.command_integrable α (1+δ) hα hS hb
  have hv := (actual_variation_eq h).1
  have hB := (actual_variation_eq h).2
  have hd := delayed_variation_eq δ hδ f
  have ha := delayedError_absArea δ hδ h.error_integrable
  have hn := delayedError_negArea δ hδ f
  have hchain := response_variation_chain h α hα
  have hvar := response_variation_identity h
  have hback := response_backward_le_negative_area h
  have hbal := area_balance he h.command_integrable (1+δ) hb
  have hsum : absArea (delayedError δ f) halfLine+absArea v halfLine ≤
      miace α (delayedError δ f) v halfLine/minimum α :=
    area_sum_le_ratio α _ _ hα (integral_nonneg fun _ => abs_nonneg _)
      (integral_nonneg fun _ => abs_nonneg _)
  refine ⟨?_,signal_miace_lower_bound he h.command_integrable α (1+δ) hα hS.le hb,
    heq,?_,delayed_endpoints h δ hδ,?_,?_,?_,?_,?_,?_,?_,?_⟩
  · rw [miace_square α _ _ _ hα,minimum_square α hα]
    have hi := signal_excess he h.command_integrable α (1+δ) hα hb
    convert hi using 1 <;> (try unfold baseSq) <;> ring
  · intro hm
    obtain ⟨hpos,hvpos,_⟩ := heq.mp hm
    have hz := (negative_area_zero_iff he).mpr hpos
    rw [hn] at hz
    exact delayed_output_monotone h ((negative_area_zero_iff h.error_integrable).mp hz) hvpos δ
  · rw [hd.1,hv]
    exact hchain.1
  · rw [hd.1,hd.2,hv,hB]
    exact hvar
  · rw [hd.1,hv,ha]
    linarith [hchain.2.1]
  · linarith
  · linarith
  · rw [hd.2]
    exact delayed_peak_bound h δ
  · rw [hd.2,hB,hn]
    exact hback
  · linarith

end MIACE
