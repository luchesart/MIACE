import MIACE.IMCPositive
import MIACE.IMCAuxiliary

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

noncomputable def imcPerturbedStep (F : IMCFilter) (z : ℝ → ℝ) (t : ℝ) : ℝ :=
  filterAction F unitStep t-filterAction F (filterAction F z) t

-- This identity is proved for the concrete ordinary feedback equation,
-- including the feedthrough taps of the IMC filter.
-- @paper-step thm:complete_robust/actual_perturbed_step_feedback_and_output_identity
theorem imc_perturbed_step_identity (F : IMCFilter) {P Pe z : ℝ → ℝ}
    (hP : Integrable P) (hPe : Integrable Pe) (hPc : Causal P) (hPec : Causal Pe)
    (hz : Integrable z) (hzc : Causal z)
    (hg : Integrable ((fun t => Pe t-P t) ⋆ unitStep))
    (he : z=ᵐ[volume] (fun t => ((fun s => Pe s-P s) ⋆ unitStep) t-
      filterAction F ((fun s => Pe s-P s) ⋆ z) t)) :
    LocallyIntegrable (imcPerturbedStep F z) volume ∧ Causal (imcPerturbedStep F z) ∧
      imcPerturbedStep F z=ᵐ[volume]
        filterAction F (fun t => unitStep t-((fun s => Pe s-P s) ⋆ imcPerturbedStep F z) t) ∧
      (fun t => (Pe ⋆ imcPerturbedStep F z) t-(P ⋆ filterAction F unitStep) t)=ᵐ[volume]
        filterAction F (fun t => z t-(P ⋆ filterAction F z) t) := by
  let D := fun t => Pe t-P t
  let g := D ⋆ unitStep
  let b := filterAction F z
  let c := filterAction F b
  let w0 := filterAction F unitStep
  have hD : Integrable D := hPe.sub hP
  have hDc : Causal D := by
    filter_upwards [hPec,hPc] with t ht hs hn
    simp [D,ht hn,hs hn]
  have hgc : Causal g := ae_of_all volume (convolution_causal hDc (causalize_causal _))
  have hb : Integrable b := filterAction_integrable F hz
  have hbc : Causal b := filterAction_causal F hzc
  have hc : Integrable c := filterAction_integrable F hb
  have hcc : Causal c := filterAction_causal F hbc
  have hw0 : LocallyIntegrable w0 volume :=
    causalLocalOperator_local_integrable (filter_local_operator F) unitStep_local (causalize_causal _)
  have hw0c : Causal w0 := filterAction_causal F (causalize_causal _)
  have hw : LocallyIntegrable (imcPerturbedStep F z) volume := hw0.sub hc.locallyIntegrable
  have hwc : Causal (imcPerturbedStep F z) := by
    filter_upwards [hw0c,hcc] with t ht hs hn
    change w0 t-c t=0
    rw [ht hn,hs hn,sub_self]
  have hDz := hD.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hz
  have hDzc : Causal (D ⋆ z) := ae_of_all volume (convolution_causal hDc hzc)
  have hFhe := (filterAction_congr F he).trans
    (local_filter_sub F hg.locallyIntegrable (filterAction_integrable F hDz).locallyIntegrable
      hgc (filterAction_causal F hDzc))
  have hcomm1 := filterAction_congr F (local_filter_commute F hD hDc hz.locallyIntegrable hzc)
  have hcomm2 := local_filter_commute F hD hDc hb.locallyIntegrable hbc
  have hbid : b=ᵐ[volume] (fun t => filterAction F g t-(D ⋆ c) t) := by
    filter_upwards [hFhe,hcomm1,hcomm2] with t ht hs hj
    change b t=filterAction F g t-filterAction F (filterAction F (D ⋆ z)) t at ht
    change filterAction F (filterAction F (D ⋆ z)) t=filterAction F (D ⋆ b) t at hs
    change filterAction F (D ⋆ b) t=(D ⋆ c) t at hj
    rw [ht,hs,hj]
  have hD0 := (local_filter_commute F hD hDc unitStep_local (causalize_causal _)).symm
  have hDu : (D ⋆ imcPerturbedStep F z)=ᵐ[volume] b := by
    filter_upwards [local_convolution_sub hD hDc hw0 hc.locallyIntegrable hw0c hcc,hD0,hbid]
      with t ht hs hj
    change (D ⋆ imcPerturbedStep F z) t=(D ⋆ w0) t-(D ⋆ c) t at ht
    change (D ⋆ w0) t=filterAction F g t at hs
    rw [ht,hs,← hj]
  have hqin : (fun t => unitStep t-(D ⋆ imcPerturbedStep F z) t)=ᵐ[volume]
      (fun t => unitStep t-b t) := hDu.mono (fun t ht => by
        change unitStep t-(D ⋆ imcPerturbedStep F z) t=unitStep t-b t
        rw [ht])
  have hfeedback := (filterAction_congr F hqin).trans
    (local_filter_sub F unitStep_local hb.locallyIntegrable (causalize_causal _) hbc)
  have hPb := hP.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hb
  have hPbc : Causal (P ⋆ b) := ae_of_all volume (convolution_causal hPc hbc)
  have hE := local_filter_sub F hz.locallyIntegrable hPb.locallyIntegrable hzc hPbc
  have hPcF := local_filter_commute F hP hPc hb.locallyIntegrable hbc
  refine ⟨hw,hwc,hfeedback.symm,?_⟩
  filter_upwards [local_convolution_sub hPe hPec hw0 hc.locallyIntegrable hw0c hcc,
    local_kernel_sub hPe hP hPec hPc hw0 hw0c,
    local_kernel_sub hPe hP hPec hPc hc.locallyIntegrable hcc,hD0,hbid,hE,hPcF]
    with t h1 h2 h3 h4 h5 h6 h7
  change (Pe ⋆ imcPerturbedStep F z) t=(Pe ⋆ w0) t-(Pe ⋆ c) t at h1
  change (D ⋆ w0) t=(Pe ⋆ w0) t-(P ⋆ w0) t at h2
  change (D ⋆ c) t=(Pe ⋆ c) t-(P ⋆ c) t at h3
  change (D ⋆ w0) t=filterAction F g t at h4
  change filterAction F (fun s => z s-(P ⋆ b) s) t=b t-filterAction F (P ⋆ b) t at h6
  change filterAction F (P ⋆ b) t=(P ⋆ c) t at h7
  change (Pe ⋆ imcPerturbedStep F z) t-(P ⋆ w0) t=filterAction F (fun s => z s-(P ⋆ b) s) t
  linarith

-- @paper-step thm:complete_robust/sharp_actual_signal_gain_constants
theorem imc_step_difference_gains (F : IMCFilter) {P z : ℝ → ℝ}
    (hP : Integrable P) (hPc : Causal P) (hz : Integrable z) (hzc : Causal z)
    (hFP : absArea (filterAction F P) volume≤1) :
    absArea (filterAction F (filterAction F z)) volume≤(filterGain F)^2*absArea z volume ∧
      absArea (filterAction F (fun t => z t-(P ⋆ filterAction F z) t)) volume≤
        2*filterGain F*absArea z volume := by
  have hf : 0≤filterGain F := by unfold filterGain; positivity
  have hb := filterAction_integrable F hz
  have hbc := filterAction_causal F hzc
  have hPb := hP.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hb
  have he := (local_filter_commute F hP hPc hz.locallyIntegrable hzc).symm.trans
    (local_filter_convolution F hP hPc hz.locallyIntegrable hzc)
  have hPbB : absArea (P ⋆ filterAction F z) volume≤absArea z volume := by
    rw [absArea_congr he]
    have hAz : 0≤absArea z volume := integral_nonneg (fun t => abs_nonneg (z t))
    exact (convolution_absArea (filterAction_integrable F hP) hz).trans
      (by simpa only [one_mul] using mul_le_mul_of_nonneg_right hFP hAz)
  have hdiff := absArea_sub_le hz hPb
  constructor
  · have hh := (filterAction_absArea F hb).trans
      (mul_le_mul_of_nonneg_left (filterAction_absArea F hz) hf)
    nlinarith
  · have hdi : Integrable (fun t => z t-(P ⋆ filterAction F z) t) := hz.sub hPb
    have hh := filterAction_absArea F hdi
    have hm := mul_le_mul_of_nonneg_left (show absArea (fun t => z t-(P ⋆ filterAction F z) t) volume≤
      2*absArea z volume by linarith) hf
    nlinarith

end MIACE
