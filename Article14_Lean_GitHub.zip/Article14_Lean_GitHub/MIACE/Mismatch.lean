import MIACE.Amplitude
import MIACE.Physical
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Analysis.Asymptotics.AsymptoticEquivalent

namespace MIACE
open MeasureTheory Filter Set Asymptotics
open scoped Topology

noncomputable def mismatchSigma (s κ : ℝ) := Real.sqrt (1+(s^2-1)*κ^2)
noncomputable def mismatchLoss (s κ η : ℝ) :=
  (mismatchSigma s κ-κ*s*η)^2/(2*η*κ*s*(1+κ*s))+
    (κ*s-mismatchSigma s κ)^2/(2*(1+κ*s))

-- @paper-step cor:mismatch/exact_sos_substitution
theorem mismatch_exact_loss {s κ η : ℝ} (hs : 1 < s) (hκ : 0 < κ) (hη : 0 < η) :
    quadratic ((s^2-1)*κ^2) (κ*s) (1/η)-(mismatchSigma s κ-1)=mismatchLoss s κ η := by
  have hs0 : 0 < s := by linarith
  have hrad : 0 ≤ 1+(s^2-1)*κ^2 := by nlinarith [mul_nonneg (show 0 ≤ s^2-1 by nlinarith) (sq_nonneg κ)]
  rw [quadratic_gap _ (mismatchSigma s κ) _ _ (mul_pos hκ hs0) (by positivity)
    (Real.sq_sqrt hrad)]
  unfold mismatchLoss
  field_simp
  <;> ring

-- @paper-step cor:mismatch/loss_nonnegativity_and_uniqueness
theorem mismatch_loss_zero_iff {s κ η : ℝ} (hs : 1 < s) (hκ : 0 < κ) (hη : 0 < η) :
    0 ≤ mismatchLoss s κ η ∧ (mismatchLoss s κ η=0 ↔ κ=1 ∧ η=1) := by
  have hs0 : 0 < s := by linarith
  have hrad : 0 < 1+(s^2-1)*κ^2 := by nlinarith [mul_nonneg (show 0 ≤ s^2-1 by nlinarith) (sq_nonneg κ)]
  have hsig : 0 < mismatchSigma s κ := Real.sqrt_pos.mpr hrad
  have hsigsq : (mismatchSigma s κ)^2=1+(s^2-1)*κ^2 := Real.sq_sqrt hrad.le
  have hn : 0 ≤ mismatchLoss s κ η := by unfold mismatchLoss; positivity
  refine ⟨hn,?_⟩
  rw [← mismatch_exact_loss hs hκ hη,sub_eq_zero,
    quadratic_equality_iff _ _ _ _ (mul_pos hκ hs0) (by positivity) hsig hsigsq]
  constructor
  · rintro ⟨hg,hr⟩
    have hκ2 : κ^2=1 := by nlinarith [sq_nonneg (κ*s-mismatchSigma s κ)]
    have hκ1 : κ=1 := by nlinarith
    have hη1 : η=1 := by
      have hh := (div_eq_one_iff_eq (ne_of_gt hη)).mp hr
      linarith
    exact ⟨hκ1,hη1⟩
  · rintro ⟨rfl,rfl⟩
    constructor
    · simp [mismatchSigma,Real.sqrt_sq hs0.le]
    · norm_num

-- @paper-step cor:mismatch/exact_nonovershoot_conditions
theorem mismatch_nonovershoot {s κ η : ℝ} {e i : ℝ → ℝ}
    (hs : 1 < s) (hκ : 0 < κ) (hη : 0 < η)
    (h : PIStateResponse (κ*s) (1/η) e i) :
    (∀ t : ℝ, 0 ≤ t → 0 ≤ e t) ↔
      if 1 ≤ κ*s then η ≤ 1 else η ≤ (1+κ*s)^2/(4*κ*s) := by
  have hx : 0 < κ*s := mul_pos hκ (by linarith)
  rw [pi_nonovershoot_iff h hx (by positivity)]
  unfold MonotoneDomain
  by_cases hx1 : 1 ≤ κ*s
  · rw [if_pos hx1]
    by_cases hxle : κ*s ≤ 1
    · have heq : κ*s=1 := le_antisymm hxle hx1
      norm_num [heq]
      simpa only [one_div] using (one_le_div hη : 1 ≤ 1/η ↔ η ≤ 1)
    · rw [if_neg hxle]
      simpa only [one_div] using (one_le_div hη : 1 ≤ 1/η ↔ η ≤ 1)
  · have hxle : κ*s ≤ 1 := le_of_lt (lt_of_not_ge hx1)
    rw [if_neg hx1,if_pos hxle]
    have hd : 0 < (1+κ*s)^2 := by positivity
    rw [div_le_div_iff₀ hd hη,le_div_iff₀ (by positivity : 0 < 4*κ*s)]
    constructor <;> intro hh <;> nlinarith

-- Поправка: кубичният остатък ще следва от точна факторизация и локални
-- диференцируеми коефициенти, без формално отхвърляне на неизвестни членове.
noncomputable def mismatchFactor (s κ : ℝ) := (κ+1)/(κ*s+mismatchSigma s κ)
noncomputable def mismatchA (s : ℝ) (p : ℝ × ℝ) :=
  (mismatchFactor s (1+p.1))^2*(1+(1+p.2)*(1+p.1)*s)/
    (2*(1+p.2)*(1+p.1)*s*(1+(1+p.1)*s))
noncomputable def mismatchB (s : ℝ) (p : ℝ × ℝ) :=
  mismatchFactor s (1+p.1)/((1+p.2)*(1+(1+p.1)*s))
noncomputable def mismatchC (s : ℝ) (p : ℝ × ℝ) :=
  (1+p.1)*s/(2*(1+p.2)*(1+(1+p.1)*s))

-- @paper-step cor:mismatch/square_root_rationalization
theorem mismatch_factor_identity {s κ : ℝ} (hs : 1 < s) (hκ : 0 < κ) :
    κ*s-mismatchSigma s κ=(κ-1)*mismatchFactor s κ := by
  have hs0 : 0 < s := by linarith
  have hrad : 0 ≤ 1+(s^2-1)*κ^2 := by nlinarith [mul_nonneg (show 0 ≤ s^2-1 by nlinarith) (sq_nonneg κ)]
  have hsigsq : (mismatchSigma s κ)^2=1+(s^2-1)*κ^2 := Real.sq_sqrt hrad
  have hden : 0 < κ*s+mismatchSigma s κ := add_pos_of_pos_of_nonneg (mul_pos hκ hs0) (Real.sqrt_nonneg _)
  unfold mismatchFactor
  rw [← mul_div_assoc]
  apply (eq_div_iff (ne_of_gt hden)).mpr
  nlinarith

-- @paper-step cor:mismatch/exact_quadratic_coefficient_factorization
theorem mismatch_coefficient_identity {s : ℝ} (hs : 1 < s) (p : ℝ × ℝ)
    (hκ : 0 < 1+p.1) (hη : 0 < 1+p.2) :
    mismatchLoss s (1+p.1) (1+p.2)=p.1^2*mismatchA s p+p.1*p.2*mismatchB s p+p.2^2*mismatchC s p := by
  have hs0 : 0 < s := by linarith
  have hfactor := mismatch_factor_identity hs hκ
  have hsig : mismatchSigma s (1+p.1)=(1+p.1)*s-p.1*mismatchFactor s (1+p.1) := by linarith
  unfold mismatchLoss mismatchA mismatchB mismatchC
  rw [hsig]
  field_simp
  <;> ring

-- @paper-step cor:mismatch/local_quadratic_coefficients
theorem mismatch_coefficients_at_zero {s : ℝ} (hs : 1 < s) :
    mismatchA s 0=1/(2*s^3) ∧ mismatchB s 0=1/(s*(1+s)) ∧ mismatchC s 0=s/(2*(1+s)) := by
  have hs0 : 0 < s := by linarith
  have hsig : mismatchSigma s 1=s := by simp [mismatchSigma,Real.sqrt_sq hs0.le]
  simp only [mismatchA,mismatchB,mismatchC,Prod.fst_zero,Prod.snd_zero,add_zero,one_mul,hsig,mismatchFactor]
  constructor
  · field_simp
    <;> ring
  constructor
  · field_simp
    <;> ring
  · ring

-- @paper-step cor:mismatch/differentiable_quotient
theorem differentiable_ratio {f g : (ℝ × ℝ) → ℝ}
    (hf : DifferentiableAt ℝ f 0) (hg : DifferentiableAt ℝ g 0) (hne : g 0 ≠ 0) :
    DifferentiableAt ℝ (fun p => f p/g p) 0 := by
  simpa only [div_eq_mul_inv,Pi.mul_def,Pi.inv_def] using hf.mul (hg.inv hne)

-- @paper-step cor:mismatch/differentiable_local_coefficients
theorem mismatch_coefficients_differentiable {s : ℝ} (hs : 1 < s) :
    DifferentiableAt ℝ (mismatchA s) 0 ∧ DifferentiableAt ℝ (mismatchB s) 0 ∧
      DifferentiableAt ℝ (mismatchC s) 0 := by
  have hs0 : 0 < s := by linarith
  have hsig0 : mismatchSigma s 1=s := by simp [mismatchSigma,Real.sqrt_sq hs0.le]
  have hsig : DifferentiableAt ℝ (fun p : ℝ × ℝ => mismatchSigma s (1+p.1)) 0 := by
    unfold mismatchSigma
    apply DifferentiableAt.sqrt (by fun_prop)
    simp only [Prod.fst_zero,add_zero,one_pow,mul_one,add_sub_cancel]
    positivity
  have hfac : DifferentiableAt ℝ (fun p : ℝ × ℝ => mismatchFactor s (1+p.1)) 0 := by
    unfold mismatchFactor
    change DifferentiableAt ℝ ((fun p : ℝ × ℝ => 1+p.1+1) / (fun p => (1+p.1)*s+mismatchSigma s (1+p.1))) 0
    apply differentiable_ratio (by fun_prop) ((by fun_prop : DifferentiableAt ℝ (fun p : ℝ × ℝ => (1+p.1)*s) 0).add hsig)
    simp only [Pi.add_apply,Prod.fst_zero,add_zero,one_mul,hsig0]
    positivity
  have hA : DifferentiableAt ℝ (mismatchA s) 0 := by
    unfold mismatchA
    change DifferentiableAt ℝ ((fun p : ℝ × ℝ => (mismatchFactor s (1+p.1))^2*(1+(1+p.2)*(1+p.1)*s)) / (fun p => 2*(1+p.2)*(1+p.1)*s*(1+(1+p.1)*s))) 0
    apply differentiable_ratio ((hfac.pow 2).mul (by fun_prop)) (by fun_prop)
    simp only [Prod.fst_zero,Prod.snd_zero,add_zero,mul_one,one_mul]
    positivity
  have hB : DifferentiableAt ℝ (mismatchB s) 0 := by
    unfold mismatchB
    change DifferentiableAt ℝ ((fun p : ℝ × ℝ => mismatchFactor s (1+p.1)) / (fun p => (1+p.2)*(1+(1+p.1)*s))) 0
    apply differentiable_ratio hfac (by fun_prop)
    simp only [Prod.fst_zero,Prod.snd_zero,add_zero,mul_one,one_mul]
    positivity
  have hC : DifferentiableAt ℝ (mismatchC s) 0 := by
    unfold mismatchC
    change DifferentiableAt ℝ ((fun p : ℝ × ℝ => (1+p.1)*s) / (fun p => 2*(1+p.2)*(1+(1+p.1)*s))) 0
    apply differentiable_ratio (by fun_prop) (by fun_prop)
    simp only [Prod.fst_zero,Prod.snd_zero,add_zero,mul_one,one_mul]
    positivity
  exact ⟨hA,hB,hC⟩

-- @paper-step cor:mismatch/cubic_remainder_principle
theorem quadratic_coefficient_remainder {A B C : (ℝ × ℝ) → ℝ}
    (hA : DifferentiableAt ℝ A 0) (hB : DifferentiableAt ℝ B 0) (hC : DifferentiableAt ℝ C 0) :
    (fun p : ℝ × ℝ => p.1^2*(A p-A 0)+p.1*p.2*(B p-B 0)+p.2^2*(C p-C 0))
      =O[𝓝 0] (fun p => (|p.1|+|p.2|)^3) := by
  have hfst : (fun p : ℝ × ℝ => p.1) =O[𝓝 0] (fun p => ‖p‖) :=
    isBigO_of_le _ (fun p => by simpa using norm_fst_le p)
  have hsnd : (fun p : ℝ × ℝ => p.2) =O[𝓝 0] (fun p => ‖p‖) :=
    isBigO_of_le _ (fun p => by simpa using norm_snd_le p)
  have ha : (fun p => A p-A 0) =O[𝓝 (0:ℝ × ℝ)] (fun p => ‖p‖) := by
    simpa using hA.isBigO_sub.norm_right
  have hb : (fun p => B p-B 0) =O[𝓝 (0:ℝ × ℝ)] (fun p => ‖p‖) := by
    simpa using hB.isBigO_sub.norm_right
  have hc : (fun p => C p-C 0) =O[𝓝 (0:ℝ × ℝ)] (fun p => ‖p‖) := by
    simpa using hC.isBigO_sub.norm_right
  have hcross : (fun p : ℝ × ℝ => p.1*p.2*(B p-B 0)) =O[𝓝 0] (fun p => ‖p‖^2*‖p‖) := by
    simpa only [pow_two] using (hfst.mul hsnd).mul hb
  have he := (((hfst.pow 2).mul ha).add hcross).add ((hsnd.pow 2).mul hc)
  have he' : (fun p : ℝ × ℝ => p.1^2*(A p-A 0)+p.1*p.2*(B p-B 0)+p.2^2*(C p-C 0))
      =O[𝓝 0] (fun p => ‖p‖^3) := by
    convert he using 1 <;> (try funext p) <;> ring
  apply he'.trans
  apply isBigO_of_le
  intro p
  have hnorm : ‖p‖ ≤ |p.1|+|p.2| := by
    rw [Prod.norm_def,Real.norm_eq_abs,Real.norm_eq_abs]
    exact max_le (by linarith [abs_nonneg p.2]) (by linarith [abs_nonneg p.1])
  simpa only [norm_pow,norm_norm,Real.norm_of_nonneg (by positivity : 0 ≤ |p.1|+|p.2|)]
    using pow_le_pow_left₀ (norm_nonneg p) hnorm 3

-- @paper-step cor:mismatch/rigorous_multivariate_taylor
theorem mismatch_taylor {s : ℝ} (hs : 1 < s) :
    (fun p : ℝ × ℝ => mismatchLoss s (1+p.1) (1+p.2)-
      (p.1^2/(2*s^3)+p.1*p.2/(s*(1+s))+s*p.2^2/(2*(1+s))))
      =O[𝓝 0] (fun p => (|p.1|+|p.2|)^3) := by
  obtain ⟨ha,hb,hc⟩ := mismatch_coefficients_differentiable hs
  have hrem := quadratic_coefficient_remainder ha hb hc
  obtain ⟨hA,hB,hC⟩ := mismatch_coefficients_at_zero hs
  apply hrem.congr' _ EventuallyEq.rfl
  have hκ : ∀ᶠ p : ℝ × ℝ in 𝓝 0, 0 < 1+p.1 := by
    have hh : Continuous (fun p : ℝ × ℝ => 1+p.1) := by fun_prop
    exact hh.continuousAt.eventually (lt_mem_nhds (show (0:ℝ) < 1+(0:ℝ × ℝ).1 by norm_num))
  have hη : ∀ᶠ p : ℝ × ℝ in 𝓝 0, 0 < 1+p.2 := by
    have hh : Continuous (fun p : ℝ × ℝ => 1+p.2) := by fun_prop
    exact hh.continuousAt.eventually (lt_mem_nhds (show (0:ℝ) < 1+(0:ℝ × ℝ).2 by norm_num))
  filter_upwards [hκ,hη] with p hp hq
  rw [mismatch_coefficient_identity hs p hp hq,hA,hB,hC]
  ring

-- @paper-step cor:mismatch/internal_stability_arbitrary_initial_state
theorem positive_pi_internal_stability {x r : ℝ} {e i : ℝ → ℝ}
    (hx : 0 < x) (hr : 0 < r)
    (heac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval e 0 T)
    (hiac : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval i 0 T)
    (heode : ∀ᵐ t : ℝ, 0 < t → deriv e t=-(1+x)*e t-i t)
    (hiode : ∀ᵐ t : ℝ, 0 < t → deriv i t=(x/r)*e t) :
    Tendsto e atTop (𝓝 0) ∧ Tendsto i atTop (𝓝 0) ∧
    ∃ K γ : ℝ, 0 ≤ K ∧ 0 < γ ∧ ∀ t : ℝ, 0 ≤ t →
      ((r/x)*i t)^2+(e t)^2 ≤ K*Real.exp (-γ*t) := by
  have ho : ∀ᵐ t : ℝ, 0 < t → deriv (fun s => -(r/x)*i s) t = -e t := by
    filter_upwards [hiode] with t ht hp
    rw [deriv_const_mul_field,ht hp]
    field_simp
    <;> ring
  have hp : ∀ᵐ t : ℝ, 0 < t → deriv (fun s => -e s) t =
      -(x/r)*(-(r/x)*i t)-(r*(1+x)/r)*(-e t) := by
    filter_upwards [heode] with t ht hp
    change deriv (-e) t = _
    rw [deriv.neg,ht hp]
    field_simp
    <;> ring
  have hb : 0 < r*(1+x) := by positivity
  have hz := fun T hT => (hiac T hT).const_mul (-(r/x))
  have hw := fun T hT => (heac T hT).neg
  have hf := canonical_settles hr hb hx hz hw ho hp
  have hfE : Tendsto e atTop (𝓝 0) := by simpa using hf.2.neg
  have hfI : Tendsto i atTop (𝓝 0) := by
    have hh := hf.1.const_mul (-(x/r))
    have hid : (fun t => -(x/r)*(-(r/x)*i t))=i := by funext t; field_simp
    simpa only [hid,mul_zero] using hh
  refine ⟨hfE,hfI, (2*(r*(1+x))/r)*stabilityV r (r*(1+x)) x (-(r/x)*i 0) (-e 0),
    1/stabilityC r (r*(1+x)) x,?_,?_,?_⟩
  · apply mul_nonneg (by positivity)
    exact le_trans (by positivity) (stability_bounds r (r*(1+x)) x (-(r/x)*i 0) (-e 0) hr hb hx).1
  · unfold stabilityC
    positivity
  · intro t ht
    have hh := canonical_exponential_bound hr hb hx hz hw ho hp t ht
    simpa only [Pi.neg_apply,neg_mul,neg_sq] using hh

-- @paper-step cor:mismatch/actual_signal_loss
theorem mismatch_signal_loss {s κ η : ℝ} {e i : ℝ → ℝ}
    (hs : 1 < s) (hκ : 0 < κ) (hη : 0 < η)
    (h : PIStateResponse (κ*s) (1/η) e i) :
    ((s^2-1)*κ^2)*(∫ t, (e t)^2 ∂halfLine)+
      (∫ t, (κ*s*e t+i t)^2 ∂halfLine)-(mismatchSigma s κ-1)=mismatchLoss s κ η := by
  have hx : 0 < κ*s := mul_pos hκ (by linarith)
  obtain ⟨he,hu⟩ := paper_pi_energies h hx (by positivity)
  rw [he.2,hu.2]
  exact mismatch_exact_loss hs hκ hη

-- @paper-step cor:mismatch/physical_fixed_vs_retuned_loss
theorem mismatch_physical_loss {s κ η : ℝ} {e i : ℝ → ℝ}
    (hs : 1 < s) (hκ : 0 < κ) (hη : 0 < η)
    (h : PIStateResponse (κ*s) (1/η) e i)
    (R τ k : ℝ) (hR : 0 < R) (hτ : 0 < τ) (hk : 0 < k) :
    physicalCost (((s^2-1)*κ^2)*R/k^2) R τ k e (fun t => κ*s*e t+i t)-
      physicalCost (((s^2-1)*κ^2)*R/k^2) R τ k (expError (mismatchSigma s κ))
        (fun t => mismatchSigma s κ*expError (mismatchSigma s κ) t-expError (mismatchSigma s κ) t)=
      (R*τ/k^2)*mismatchLoss s κ η := by
  have hx : 0 < κ*s := mul_pos hκ (by linarith)
  have hq : 0 < (s^2-1)*κ^2 := mul_pos (by nlinarith) (sq_pos_of_pos hκ)
  have hsig : 0 < mismatchSigma s κ := Real.sqrt_pos.mpr (by linarith)
  have hsigsq : (mismatchSigma s κ)^2=1+(s^2-1)*κ^2 := Real.sq_sqrt (by linarith)
  have hfixed := pi_physical_cost h hx (by positivity) (((s^2-1)*κ^2)*R/k^2) R τ k hR hτ hk
  have hretuned := pi_physical_cost (exponential_pi_state (mismatchSigma s κ)) hsig zero_lt_one
    (((s^2-1)*κ^2)*R/k^2) R τ k hR hτ hk
  have hweight : (((s^2-1)*κ^2)*R/k^2)*k^2/R=(s^2-1)*κ^2 := by field_simp
  rw [hweight] at hfixed hretuned
  have hopt : quadratic ((s^2-1)*κ^2) (mismatchSigma s κ) 1=mismatchSigma s κ-1 :=
    (quadratic_equality_iff _ _ _ _ hsig zero_lt_one hsig hsigsq).mpr ⟨rfl,rfl⟩
  rw [hopt] at hretuned
  have hRet : physicalCost (((s^2-1)*κ^2)*R/k^2) R τ k (expError (mismatchSigma s κ))
        (fun t => mismatchSigma s κ*expError (mismatchSigma s κ) t-expError (mismatchSigma s κ) t)=
      (R*τ/k^2)*(mismatchSigma s κ-1) := by simpa only [sub_eq_add_neg] using hretuned
  rw [hfixed,hRet]
  rw [← mul_sub,mismatch_exact_loss hs hκ hη]

-- @paper-step cor:mismatch/nominal_weight_parameterization
theorem nominal_gain_parameterization {q : ℝ} (hq : 0 < q) :
    1 < Real.sqrt (1+q) ∧ (Real.sqrt (1+q))^2-1=q := by
  have hs := Real.sq_sqrt (show 0 ≤ 1+q by linarith)
  have hn := Real.sqrt_nonneg (1+q)
  constructor <;> nlinarith

-- @paper-step cor:mismatch/full_statement
theorem paper_mismatch {s κ η : ℝ} {e i : ℝ → ℝ}
    (hs : 1 < s) (hκ : 0 < κ) (hη : 0 < η)
    (h : PIStateResponse (κ*s) (1/η) e i) :
    (Tendsto e atTop (𝓝 0) ∧ Tendsto i atTop (𝓝 0)) ∧
    (((s^2-1)*κ^2)*(∫ t, (e t)^2 ∂halfLine)+
      (∫ t, (κ*s*e t+i t)^2 ∂halfLine)-(mismatchSigma s κ-1)=mismatchLoss s κ η) ∧
    (0 ≤ mismatchLoss s κ η ∧ (mismatchLoss s κ η=0 ↔ κ=1 ∧ η=1)) ∧
    ((fun p : ℝ × ℝ => mismatchLoss s (1+p.1) (1+p.2)-
      (p.1^2/(2*s^3)+p.1*p.2/(s*(1+s))+s*p.2^2/(2*(1+s))))
      =O[𝓝 0] (fun p => (|p.1|+|p.2|)^3)) ∧
    ((∀ t : ℝ, 0 ≤ t → 0 ≤ e t) ↔
      if 1 ≤ κ*s then η ≤ 1 else η ≤ (1+κ*s)^2/(4*κ*s)) ∧
    (∀ R τ k : ℝ, 0 < R → 0 < τ → 0 < k →
      physicalCost (((s^2-1)*κ^2)*R/k^2) R τ k e (fun t => κ*s*e t+i t)-
        physicalCost (((s^2-1)*κ^2)*R/k^2) R τ k (expError (mismatchSigma s κ))
          (fun t => mismatchSigma s κ*expError (mismatchSigma s κ) t-expError (mismatchSigma s κ) t)=
        (R*τ/k^2)*mismatchLoss s κ η) := by
  exact ⟨pi_state_settles h (mul_pos hκ (by linarith)) (by positivity),
    mismatch_signal_loss hs hκ hη h,mismatch_loss_zero_iff hs hκ hη,
    mismatch_taylor hs,mismatch_nonovershoot hs hκ hη h,
    fun R τ k hR hτ hk => mismatch_physical_loss hs hκ hη h R τ k hR hτ hk⟩

-- @paper-step cor:mismatch/physical_mismatch_coordinates
theorem mismatch_coordinates (Q R k₀ τ₀ s κ η : ℝ)
    (hk : 0 < k₀) (hτ : 0 < τ₀) (hR : 0 < R) (hη : 0 < η) :
    (κ*k₀)*(s/k₀)=κ*s ∧ τ₀/(η*τ₀)=1/η ∧
    Q*(κ*k₀)^2/R=(Q*k₀^2/R)*κ^2 := by
  constructor
  · field_simp
  constructor
  · field_simp
  · ring

-- @paper-step cor:mismatch/positive_definite_quadratic_loss
theorem mismatch_quadratic_positive {s : ℝ} (hs : 1 < s) (u v : ℝ) :
    u^2/(2*s^3)+u*v/(s*(1+s))+s*v^2/(2*(1+s)) =
      (u/s+s*v)^2/(2*s*(1+s))+(u/s)^2/(2*(1+s)) ∧
    (u^2/(2*s^3)+u*v/(s*(1+s))+s*v^2/(2*(1+s))=0 ↔ u=0 ∧ v=0) := by
  have hs0 : 0 < s := by linarith
  have hid : u^2/(2*s^3)+u*v/(s*(1+s))+s*v^2/(2*(1+s)) =
      (u/s+s*v)^2/(2*s*(1+s))+(u/s)^2/(2*(1+s)) := by
    field_simp
    <;> ring
  refine ⟨hid,?_⟩
  rw [hid]
  constructor
  · intro heq
    have h1 : 0 ≤ (u/s+s*v)^2/(2*s*(1+s)) := by positivity
    have h2 : 0 ≤ (u/s)^2/(2*(1+s)) := by positivity
    have hz : (u/s)^2/(2*(1+s))=0 := by linarith
    have hu : u=0 := by
      have hh := (div_eq_zero_iff.mp hz).resolve_right (by positivity)
      exact (div_eq_zero_iff.mp (sq_eq_zero_iff.mp hh)).resolve_right (ne_of_gt hs0)
    subst u
    simp only [zero_div,zero_add,add_zero,mul_pow,zero_pow (by decide : 2 ≠ 0)] at heq
    have hh := (div_eq_zero_iff.mp heq).resolve_right (by positivity)
    have hv := (mul_eq_zero.mp hh).resolve_left (ne_of_gt (sq_pos_of_pos hs0))
    exact ⟨rfl,sq_eq_zero_iff.mp hv⟩
  · rintro ⟨rfl,rfl⟩
    simp
end MIACE
