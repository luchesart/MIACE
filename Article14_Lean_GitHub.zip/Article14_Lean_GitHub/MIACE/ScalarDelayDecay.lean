import MIACE.ScalarLyapunovFunctional
import Mathlib.MeasureTheory.Integral.IntegralEqImproper

namespace MIACE
open MeasureTheory Set Filter
open scoped Topology

-- @paper-step lem:delayed_cancellation/lyapunov_functional_continuity_at_initial_time
theorem scalarDelayLyapunov_continuous {h : ℝ} (h0 : 0≤h) (hh : h<Real.pi/2)
    {w : ℝ → ℝ} (hw : Continuous w) : Continuous (scalarDelayLyapunov h w) := by
  have hI : Continuous (delayWindowEnergy h w) := continuous_iff_continuousAt.mpr
    (fun t => (delayWindowEnergy_deriv hw h0 hh t).continuousAt)
  have hP := (delayWindows_continuous hw h).1.comp
    (show Continuous (fun t : ℝ => (t,0)) from continuous_id.prodMk continuous_const)
  have hQ := (delayWindows_continuous hw h).2.comp
    (show Continuous (fun t : ℝ => (t,0)) from continuous_id.prodMk continuous_const)
  exact ((continuous_const.mul (((hw.sub hP).pow 2).add (hQ.neg.pow 2))).sub
    ((hw.sub hP).mul hQ.neg)).add hI

-- @paper-step lem:delayed_cancellation/exact_finite_time_energy_identity
theorem scalarDelay_energy_identity {h : ℝ} (h0 : 0≤h) (hh : h<Real.pi/2)
    {w : ℝ → ℝ} (hw : Continuous w)
    (hd : ∀ t, 0<t → HasDerivAt w (-w (t-h)) t) {T : ℝ} (hT : 0≤T) :
    (∫ t in (0 : ℝ)..T, (w t)^2)=scalarDelayLyapunov h w 0-scalarDelayLyapunov h w T := by
  have he := intervalIntegral.integral_eq_sub_of_hasDerivAt_of_le hT
    (scalarDelayLyapunov_continuous h0 hh hw).continuousOn
    (fun t ht => scalarDelayLyapunov_deriv h0 hh hw (hd t ht.1))
    ((hw.pow 2).neg.intervalIntegrable 0 T)
  rw [intervalIntegral.integral_neg] at he
  linarith

-- @paper-step lem:delayed_cancellation/uniform_energy_bound_without_sign_restriction
theorem scalarDelay_energy_bound {h : ℝ} (h0 : 0≤h) (hh : h<Real.pi/2)
    {w : ℝ → ℝ} (hw : Continuous w)
    (hd : ∀ t, 0<t → HasDerivAt w (-w (t-h)) t) {T : ℝ} (hT : 0≤T) :
    (∫ t in (0 : ℝ)..T, (w t)^2)≤scalarDelayLyapunov h w 0 := by
  rw [scalarDelay_energy_identity h0 hh hw hd hT]
  exact sub_le_self _ (scalarDelayLyapunov_nonneg h0 hh w T)

-- @paper-step lem:delayed_cancellation/square_integrability_derived_from_dissipation
theorem scalarDelay_square_integrable {h : ℝ} (h0 : 0≤h) (hh : h<Real.pi/2)
    {w : ℝ → ℝ} (hw : Continuous w)
    (hd : ∀ t, 0<t → HasDerivAt w (-w (t-h)) t) :
    IntegrableOn (fun t => (w t)^2) (Ioi 0) := by
  apply integrableOn_Ioi_of_intervalIntegral_norm_bounded (scalarDelayLyapunov h w 0) 0
    (fun T : ℝ => (hw.pow 2).integrableOn_Icc.mono_set Ioc_subset_Icc_self) tendsto_id
  filter_upwards [eventually_ge_atTop (0 : ℝ)] with T hT
  simpa only [Pi.pow_apply,id_eq,Real.norm_eq_abs,abs_pow,sq_abs] using
    scalarDelay_energy_bound h0 hh hw hd hT

-- @paper-step lem:delayed_cancellation/delayed_square_energy_including_arbitrary_past
theorem scalarDelay_shifted_energy_bound {h : ℝ} (h0 : 0≤h) (hh : h<Real.pi/2)
    {w : ℝ → ℝ} (hw : Continuous w)
    (hd : ∀ t, 0<t → HasDerivAt w (-w (t-h)) t) {T : ℝ} (hT : 0≤T) :
    (∫ t in (0 : ℝ)..T, (w (t-h))^2)≤
      (∫ t in -h..(0 : ℝ), (w t)^2)+scalarDelayLyapunov h w 0 := by
  rw [intervalIntegral.integral_comp_sub_right (fun t => (w t)^2)]
  simp only [zero_sub]
  have hm := intervalIntegral.integral_mono_interval (μ := volume) (a := -h) (b := T-h)
    (c := -h) (d := T) le_rfl (by linarith) (by linarith)
    (Eventually.of_forall (fun t => sq_nonneg (w t))) ((hw.pow 2).intervalIntegrable (-h) T)
  have ha := intervalIntegral.integral_add_adjacent_intervals (μ := volume)
    ((hw.pow 2).intervalIntegrable (-h) 0) ((hw.pow 2).intervalIntegrable 0 T)
  simp only [Pi.pow_apply] at ha
  linarith [scalarDelay_energy_bound h0 hh hw hd hT]

-- @paper-step lem:delayed_cancellation/delayed_square_integrability
theorem scalarDelay_shifted_square_integrable {h : ℝ} (h0 : 0≤h) (hh : h<Real.pi/2)
    {w : ℝ → ℝ} (hw : Continuous w)
    (hd : ∀ t, 0<t → HasDerivAt w (-w (t-h)) t) :
    IntegrableOn (fun t => (w (t-h))^2) (Ioi 0) := by
  have hc : Continuous (fun t => (w (t-h))^2) := (hw.comp (continuous_id.sub continuous_const)).pow 2
  apply integrableOn_Ioi_of_intervalIntegral_norm_bounded
    ((∫ t in -h..(0 : ℝ), (w t)^2)+scalarDelayLyapunov h w 0) 0
    (fun T : ℝ => hc.integrableOn_Icc.mono_set Ioc_subset_Icc_self) tendsto_id
  filter_upwards [eventually_ge_atTop (0 : ℝ)] with T hT
  simpa only [Pi.pow_apply,id_eq,Real.norm_eq_abs,abs_pow,sq_abs] using
    scalarDelay_shifted_energy_bound h0 hh hw hd hT

-- @paper-step lem:delayed_cancellation/arbitrary_signed_history_decay_entire_stable_interval
theorem scalarDelay_history_decay {h : ℝ} (h0 : 0≤h) (hh : h<Real.pi/2)
    {w : ℝ → ℝ} (hw : Continuous w)
    (hd : ∀ t, 0<t → HasDerivAt w (-w (t-h)) t) : Tendsto w atTop (𝓝 0) := by
  have hi := scalarDelay_square_integrable h0 hh hw hd
  have hsi := scalarDelay_shifted_square_integrable h0 hh hw hd
  have hdi : IntegrableOn (fun t => -2*w t*w (t-h)) (Ioi 0) := by
    apply (hi.add hsi).mono'
      ((continuous_const.mul hw).mul (hw.comp (continuous_id.sub continuous_const))).aestronglyMeasurable
    apply Eventually.of_forall
    intro t
    change ‖-2*w t*w (t-h)‖≤(w t)^2+(w (t-h))^2
    rw [Real.norm_eq_abs,abs_le]
    constructor <;> nlinarith [sq_nonneg (w t+w (t-h)),sq_nonneg (w t-w (t-h))]
  have hsq : Tendsto (fun t => (w t)^2) atTop (𝓝 0) :=
    tendsto_zero_of_hasDerivAt_of_integrableOn_Ioi
      (fun t ht => by convert (hd t ht).pow 2 using 1 <;> ring) hdi hi
  have habs : Tendsto (fun t => |w t|) atTop (𝓝 0) := by
    simpa only [Function.comp_def,Real.sqrt_sq_eq_abs,Real.sqrt_zero] using Real.continuous_sqrt.continuousAt.tendsto.comp hsq
  exact (tendsto_zero_iff_norm_tendsto_zero).mpr (by simpa only [Real.norm_eq_abs] using habs)

-- @paper-step lem:delayed_cancellation/pointwise_bound_from_initial_energy_and_history
theorem scalarDelay_pointwise_energy_bound {h : ℝ} (h0 : 0≤h) (hh : h<Real.pi/2)
    {w : ℝ → ℝ} (hw : Continuous w)
    (hd : ∀ t, 0<t → HasDerivAt w (-w (t-h)) t) {T : ℝ} (hT : 0≤T) :
    (w T)^2≤(w 0)^2+(∫ t in -h..(0 : ℝ), (w t)^2)+2*scalarDelayLyapunov h w 0 := by
  have hc : Continuous (fun t => -2*w t*w (t-h)) :=
    (continuous_const.mul hw).mul (hw.comp (continuous_id.sub continuous_const))
  have he := intervalIntegral.integral_eq_sub_of_hasDerivAt_of_le hT (hw.pow 2).continuousOn
    (fun t ht => by convert (hd t ht.1).pow 2 using 1 <;> ring) (hc.intervalIntegrable 0 T)
  have hm := intervalIntegral.integral_mono_on (μ := volume) (g := fun t => (w t)^2+(w (t-h))^2) hT (hc.intervalIntegrable 0 T)
    (((hw.pow 2).add ((hw.comp (continuous_id.sub continuous_const)).pow 2)).intervalIntegrable 0 T)
    (fun t _ => by nlinarith [sq_nonneg (w t+w (t-h))])
  rw [intervalIntegral.integral_add (f := fun t => (w t)^2) (g := fun t => (w (t-h))^2) ((hw.pow 2).intervalIntegrable 0 T)
    (((hw.comp (continuous_id.sub continuous_const)).pow 2).intervalIntegrable 0 T)] at hm
  simp only [Pi.pow_apply] at he
  linarith [scalarDelay_energy_bound h0 hh hw hd hT,scalarDelay_shifted_energy_bound h0 hh hw hd hT]

end MIACE
