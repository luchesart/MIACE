import MIACE.WeightedControl

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:pid_two_rate_optimum/uniform_signed_renewal_gain
theorem weightedControl_renewal {K f : ℝ → ℝ} {η C D : ℝ}
    (hη : 0≤η) (hK : Integrable K) (hKc : Causal K)
    (hq : absArea K volume<1) (hKC : WeightedControl η K C)
    (hqw : absArea (expWeight η K) volume<1)
    (hf : WeightedControl η f D) (hfc : Causal f) :
    let hfi := weightedControl_unweighted hf hfc hη
    let g := hfi.toL1 f
    let z := (∑' n : ℕ, (convOp hK)^n) g
    Causal z ∧ z=g+convOp hK z ∧
      WeightedControl η z (((1+C)/(1-absArea (expWeight η K) volume))*D) := by
  dsimp only
  let hfi := weightedControl_unweighted hf hfc hη
  let g := hfi.toL1 f
  let z := (∑' n : ℕ, (convOp hK)^n) g
  have hgc := causal_congr hfc hfi.coeFn_toL1.symm
  have hgf := weightedControl_congr hf hfi.coeFn_toL1.symm
  obtain ⟨hc,hw,_,hn⟩ := signed_renewal_weighted hK hKc hq hη hKC.integrable hqw
    g hgc hgf.integrable
  have hd : 0<1-absArea (expWeight η K) volume := sub_pos.mpr hqw
  have hq0 : 0≤absArea (expWeight η K) volume := integral_nonneg (fun _ => abs_nonneg _)
  have hC0 := hKC.nonneg
  have hD0 := hf.nonneg
  have hn' : (∫ t, |expWeight η z t|)≤D/(1-absArea (expWeight η K) volume) :=
    hn.trans (div_le_div_of_nonneg_right hgf.area hd.le)
  have hD : D≤D/(1-absArea (expWeight η K) volume) := by
    apply (le_div_iff₀ hd).mpr
    nlinarith [hf.nonneg]
  have he := (signed_renewal_l1 hK hq g).2.1
  refine ⟨hc,he,⟨by positivity,hw,?_,?_⟩⟩
  · have hh := mul_le_mul_of_nonneg_left
      (show (1 : ℝ)≤1+C by linarith [hKC.nonneg])
      (show 0≤D/(1-absArea (expWeight η K) volume) by positivity)
    calc
      _ ≤ D/(1-absArea (expWeight η K) volume) := hn'
      _ ≤ _ := by convert hh using 1 <;> ring
  · have hcB := weighted_convolution_bound hKC.nonneg hKC.bound hw
    have hr := signed_renewal_representative hK hq g
    filter_upwards [hr,hgf.bound] with t ht hgt
    have hmul : expWeight η z t=expWeight η g t+expWeight η (K ⋆ (z : ℝ → ℝ)) t := by
      change Real.exp (η*t)*z t=_
      rw [ht,mul_add]
      rfl
    rw [hmul]
    have hh := (abs_add_le _ _).trans (add_le_add hgt (hcB t))
    have hnC := mul_le_mul_of_nonneg_left hn' hKC.nonneg
    calc
      _ ≤ D+C*(∫ t, |expWeight η z t|) := hh
      _ ≤ (1+C)*(D/(1-absArea (expWeight η K) volume)) := by nlinarith
      _ = _ := by ring

-- @paper-step thm:pid_two_rate_optimum/weighted_lag_kernel_integrability
theorem lagKernel_weighted_integrable {ρ η : ℝ} (hρ : 0<ρ) (hη : η<1/ρ) :
    Integrable (expWeight η (lagKernel ρ)) := by
  have he : expWeight η (lagKernel ρ)=
      (Ioi 0).indicator (fun t => (1/ρ)*Real.exp ((η-1/ρ)*t)) := by
    funext t
    by_cases ht : t∈Ioi (0 : ℝ)
    · simp only [expWeight,lagKernel,indicator_of_mem ht]
      rw [mul_left_comm,← Real.exp_add]
      congr 2
      ring
    · simp [expWeight,lagKernel,ht]
  rw [he]
  apply IntegrableOn.integrable_indicator _ measurableSet_Ioi
  exact (integrableOn_exp_mul_Ioi (sub_neg.mpr hη) 0).const_mul (1/ρ)

-- @paper-step thm:pid_two_rate_optimum/weighted_lag_kernel_control
theorem lagKernel_weightedControl {ρ η : ℝ} (hρ : 0<ρ) (hη : η<1/ρ) :
    ∃ C : ℝ, WeightedControl η (lagKernel ρ) C := by
  let N := ∫ t, |expWeight η (lagKernel ρ) t|
  have hN : 0≤N := integral_nonneg (fun _ => abs_nonneg _)
  refine ⟨N+1/ρ,⟨by positivity,lagKernel_weighted_integrable hρ hη,by linarith [show 0≤1/ρ by positivity],?_⟩⟩
  exact ae_of_all _ (fun t => (lagKernel_weighted_bound hρ hη.le t).trans (by linarith))

-- @paper-step thm:pid_two_rate_optimum/weighted_two_rate_forcing_control
theorem twoRateG_weightedControl (A : ℝ) {l m η : ℝ} (hl : η<l) (hm : η<m) :
    ∃ C : ℝ, WeightedControl η (causalize (twoRateG A l m)) C := by
  let N := ∫ t, |expWeight η (causalize (twoRateG A l m)) t|
  have hN : 0≤N := integral_nonneg (fun _ => abs_nonneg _)
  refine ⟨N+|A|+|1-A|,⟨by positivity,twoRateG_weighted A hl hm,by linarith [abs_nonneg A,abs_nonneg (1-A)],?_⟩⟩
  apply ae_of_all
  intro t
  by_cases ht : 0≤t
  · have hh := exp_pair_decay_bound A (1-A) hl.le hm.le ht
    have he : Real.exp (η*t)*Real.exp (-η*t)=1 := by rw [← Real.exp_add]; ring_nf; simp
    have hb := mul_le_mul_of_nonneg_left hh (Real.exp_nonneg (η*t))
    have hb' : Real.exp (η*t)*((|A|+|1-A|)*Real.exp (-η*t))=|A|+|1-A| := by
      calc
        _ = (Real.exp (η*t)*Real.exp (-η*t))*(|A|+|1-A|) := by ring
        _ = _ := by rw [he,one_mul]
    rw [hb'] at hb
    simp only [expWeight,causalize,indicator_of_mem (show t∈Ici (0 : ℝ) from ht),
      abs_mul,abs_of_pos (Real.exp_pos _)]
    exact hb.trans (by linarith)
  · simp [expWeight,causalize,ht,show 0≤N+|A|+|1-A| by positivity]

end MIACE
