import MIACE.PositiveResolvent
import MIACE.Moments

/-! Етап 6: точни L¹ оценки за реално транспортно закъснение.
Всички интеграли са върху ℝ с каузално продължение с нула. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution
noncomputable def shift (d : ℝ) (f : ℝ → ℝ) (t : ℝ) : ℝ := f (t-d)
noncomputable def unitLagImpulse : ℝ → ℝ := (Ioi 0).indicator (fun t => Real.exp (-t))

-- @paper-step thm:complete_robust/translation_isometry
theorem shift_absArea (d : ℝ) (f : ℝ → ℝ) :
    absArea (shift d f) volume = absArea f volume := by
  exact integral_sub_right_eq_self (fun t => |f t|) d

-- @paper-step thm:complete_robust/translation_integrability
theorem shift_integrable (d : ℝ) {f : ℝ → ℝ} (hf : Integrable f) : Integrable (shift d f) :=
  hf.comp_sub_right d

-- @paper-step thm:complete_robust/lag_impulse_integrable
theorem unitLagImpulse_integrable : Integrable unitLagImpulse :=
  (integrableOn_exp_mul_Ioi (by norm_num : (-1 : ℝ) < 0) 0).congr_fun
    (fun _ _ => by rw [neg_one_mul]) measurableSet_Ioi |>.integrable_indicator measurableSet_Ioi

-- @paper-step thm:complete_robust/lag_impulse_mass
theorem unitLagImpulse_mass : (∫ t, unitLagImpulse t) = 1 := by
  rw [unitLagImpulse,integral_indicator measurableSet_Ioi]
  simpa using integral_exp_mul_Ioi (by norm_num : (-1 : ℝ) < 0) (0 : ℝ)

-- @paper-step thm:complete_robust/lag_impulse_nonnegative
theorem unitLagImpulse_nonneg (t : ℝ) : 0 ≤ unitLagImpulse t := by
  by_cases ht : t ∈ Ioi (0 : ℝ) <;> simp [unitLagImpulse,ht,Real.exp_nonneg]

-- @paper-step thm:complete_robust/lag_shift_absolute_identity
theorem unitLagImpulse_shift_abs {d : ℝ} (hd : 0 ≤ d) (t : ℝ) :
    |unitLagImpulse t-shift d unitLagImpulse t| =
      2*(Ioc 0 d).indicator (fun s => Real.exp (-s)) t +
        shift d unitLagImpulse t-unitLagImpulse t := by
  by_cases ht : 0 < t
  · by_cases htd : t ≤ d
    · have hneg : ¬ 0 < t-d := by linarith
      simp [unitLagImpulse,shift,ht,htd,hneg,abs_of_pos (Real.exp_pos _)]
      ring
    · have hpos : 0 < t-d := by linarith
      have he : Real.exp (-t) ≤ Real.exp (-(t-d)) := Real.exp_le_exp.mpr (by linarith)
      have hnot : t ∉ Ioc (0 : ℝ) d := fun h => htd h.2
      simp only [unitLagImpulse,shift,mem_Ioi,ht,hpos,indicator_of_mem,
        indicator_of_notMem hnot,zero_mul,zero_add]
      rw [abs_of_nonpos (sub_nonpos.mpr he)]
      ring
  · have hneg : ¬ 0 < t-d := by linarith
    simp [unitLagImpulse,shift,ht,hneg]

-- @paper-step thm:complete_robust/exact_lag_delay_distance
theorem unitLagImpulse_delay_distance {d : ℝ} (hd : 0 ≤ d) :
    absArea (fun t => unitLagImpulse t-shift d unitLagImpulse t) volume =
      2*(1-Real.exp (-d)) := by
  have hp : Integrable ((Ioc 0 d).indicator (fun t => Real.exp (-t))) :=
    (by fun_prop : Continuous (fun t : ℝ => Real.exp (-t))).integrableOn_Icc.mono_set
      Ioc_subset_Icc_self |>.integrable_indicator measurableSet_Ioc
  have hs := shift_integrable d unitLagImpulse_integrable
  unfold absArea
  simp_rw [unitLagImpulse_shift_abs hd]
  rw [integral_sub (μ := volume) (g := unitLagImpulse) (show Integrable (fun t => 2*(Ioc 0 d).indicator (fun s => Real.exp (-s)) t + shift d unitLagImpulse t) from (hp.const_mul 2).add hs) unitLagImpulse_integrable,
    integral_add (hp.const_mul 2) hs,integral_const_mul,integral_indicator measurableSet_Ioc,
    show (∫ t, shift d unitLagImpulse t) = 1 by
      rw [show (∫ t, shift d unitLagImpulse t) = ∫ t, unitLagImpulse t from
        integral_sub_right_eq_self _ d,unitLagImpulse_mass],unitLagImpulse_mass]
  rw [← intervalIntegral.integral_of_le hd]
  have hi : (∫ t in (0 : ℝ)..d, Real.exp (-t)) = 1-Real.exp (-d) := by
    rw [intervalIntegral.integral_comp_neg,integral_exp]
    simp
  rw [hi]
  ring

-- @paper-step thm:complete_robust/shift_convolution
theorem shift_convolution (d : ℝ) (f g : ℝ → ℝ) :
    shift d (f ⋆ g) = f ⋆ shift d g := by
  funext t
  unfold shift convolution
  congr 1
  funext s
  congr 2
  ring

-- @paper-step thm:complete_robust/convolution_delay_difference
theorem convolution_delay_difference {f g : ℝ → ℝ} (hf : Integrable f) (hg : Integrable g)
    (d : ℝ) :
    (fun t => (f ⋆ g) t-shift d (f ⋆ g) t) =ᵐ[volume]
      f ⋆ (fun t => g t-shift d g t) := by
  have hs := shift_integrable d hg
  filter_upwards [hf.ae_convolution_exists (ContinuousLinearMap.lsmul ℝ ℝ) hg,
    hf.ae_convolution_exists (ContinuousLinearMap.lsmul ℝ ℝ) hs] with t ht htd
  rw [shift_convolution]
  change (∫ s, f s*g (t-s)) - (∫ s, f s*shift d g (t-s)) =
    ∫ s, f s*(g (t-s)-shift d g (t-s))
  change Integrable (fun s => f s*g (t-s)) at ht
  change Integrable (fun s => f s*shift d g (t-s)) at htd
  rw [← integral_sub ht htd]
  apply integral_congr_ae
  exact ae_of_all volume (fun _ => by ring)

-- @paper-step thm:complete_robust/positive_cascade_delay_bound
theorem positive_cascade_delay_bound {b : ℝ → ℝ} (hb : Integrable b)
    (hbn : ∀ᵐ t, 0 ≤ b t) (hbm : (∫ t, b t) = 1) {d : ℝ} (hd : 0 ≤ d) :
    absArea (fun t => (b ⋆ unitLagImpulse) t-shift d (b ⋆ unitLagImpulse) t) volume ≤
      2*(1-Real.exp (-d)) := by
  have he := convolution_delay_difference hb unitLagImpulse_integrable d
  have hae : absArea (fun t => (b ⋆ unitLagImpulse) t-shift d (b ⋆ unitLagImpulse) t) volume =
      absArea (b ⋆ (fun t => unitLagImpulse t-shift d unitLagImpulse t)) volume :=
    integral_congr_ae (he.fun_comp abs)
  rw [hae]
  have hh := convolution_absArea hb (unitLagImpulse_integrable.sub
    (shift_integrable d unitLagImpulse_integrable))
  simp only [Pi.sub_def] at hh
  rwa [positive_kernel_mass hbn,hbm,one_mul,unitLagImpulse_delay_distance hd] at hh

-- @paper-step thm:complete_robust/step_delay_convolution
theorem step_delay_convolution (d : ℝ) (hd : 0 ≤ d) (h : ℝ → ℝ) (t : ℝ) :
    (pulse 1 d ⋆ h) t = ∫ s in t-d..t, h s := by
  unfold convolution pulse
  simp only [ContinuousLinearMap.lsmul_apply,smul_eq_mul]
  have hid : (fun s => (Ioc 0 d).indicator (fun _ => (1 : ℝ)) s*h (t-s)) =
      (Ioc 0 d).indicator (fun s => h (t-s)) := by
    funext s
    by_cases hs : s ∈ Ioc (0 : ℝ) d <;> simp [hs]
  rw [hid,integral_indicator measurableSet_Ioc,← intervalIntegral.integral_of_le hd,
    intervalIntegral.integral_comp_sub_left]
  simp

-- @paper-step thm:complete_robust/exact_step_delay_norm
theorem step_delay_norm {h : ℝ → ℝ} (hh : Integrable h)
    (hn : ∀ᵐ t, 0 ≤ h t) (hm : (∫ t, h t) = 1) {d : ℝ} (hd : 0 ≤ d) :
    absArea (fun t => ∫ s in t-d..t, h s) volume = d := by
  have hp : Integrable (pulse 1 d) :=
    continuous_const.integrableOn_Icc.mono_set Ioc_subset_Icc_self |>.integrable_indicator measurableSet_Ioc
  have hpos : ∀ᵐ t, 0 ≤ (pulse 1 d ⋆ h) t := by
    apply ae_of_all
    intro t
    apply integral_nonneg_of_ae
    have hn' := (quasiMeasurePreserving_sub_left_of_right_invariant
      (volume : Measure ℝ) t).tendsto_ae.eventually hn
    filter_upwards [hn'] with s hs
    change pulse 1 d s*h (t-s) ≥ 0
    apply mul_nonneg _ hs
    by_cases ht : s ∈ Ioc (0 : ℝ) d <;> simp [pulse,ht]
  have he : (fun t => ∫ s in t-d..t, h s) = pulse 1 d ⋆ h := by
    funext t
    exact (step_delay_convolution d hd h t).symm
  rw [he,positive_kernel_mass hpos,integral_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hp hh,hm]
  change (∫ t, pulse 1 d t)*1=d
  rw [mul_one,pulse,integral_indicator measurableSet_Ioc]
  simp [hd]

end MIACE
