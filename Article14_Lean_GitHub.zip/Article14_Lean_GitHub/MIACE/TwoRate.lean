import MIACE.KernelTransfer

/-! Етап 7. Конкретното двуекспоненциално ядро от §6d.
    D е точно −g′; причинните функции се нулират за t<0.
    Стойностите в крайните точки се запазват, но L¹ твърденията са ae. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

noncomputable def twoRateA (ρ l m : ℝ) : ℝ := (1/ρ-l)/(m-l)
noncomputable def twoRateG (A l m t : ℝ) : ℝ :=
  A*Real.exp (-l*t)+(1-A)*Real.exp (-m*t)
noncomputable def twoRateD (A l m t : ℝ) : ℝ :=
  l*A*Real.exp (-l*t)+m*(1-A)*Real.exp (-m*t)
noncomputable def causalize (f : ℝ → ℝ) : ℝ → ℝ := (Ici 0).indicator f
noncomputable def twoRateK (A l m δ : ℝ) : ℝ → ℝ :=
  (Ico 0 δ).indicator (twoRateD A l m)
noncomputable def twoRateR (A l m δ t : ℝ) : ℝ :=
  twoRateD A l m (t+δ)-twoRateG A l m (t+δ)+
    twoRateG A l m (max δ t)-twoRateG A l m t

-- @paper-step thm:pid_two_rate_optimum/coefficient_lower_bound
theorem twoRateA_ge_one {ρ l m : ℝ} (hlm : l < m) (hr : m ≤ 1/ρ) :
    1 ≤ twoRateA ρ l m := by
  unfold twoRateA
  exact (le_div_iff₀ (sub_pos.mpr hlm)).mpr (by linarith)

-- @paper-step thm:pid_two_rate_optimum/initial_values
theorem twoRate_initial (A l m : ℝ) :
    twoRateG A l m 0=1 ∧ twoRateD A l m 0=l*A+m*(1-A) := by
  simp [twoRateG,twoRateD]

-- @paper-step thm:pid_two_rate_optimum/actual_derivative
theorem twoRate_derivative (A l m t : ℝ) :
    HasDerivAt (twoRateG A l m) (-twoRateD A l m t) t := by
  have hl := (((hasDerivAt_id t).const_mul (-l)).exp).const_mul A
  have hm := (((hasDerivAt_id t).const_mul (-m)).exp).const_mul (1-A)
  convert hl.add hm using 1
  · rfl
  · dsimp [twoRateD]
    ring

-- @paper-step thm:pid_two_rate_optimum/continuity
theorem twoRate_continuous (A l m : ℝ) :
    Continuous (twoRateG A l m) ∧ Continuous (twoRateD A l m) := by
  constructor
  · change Continuous (fun t : ℝ => A*Real.exp (-l*t)+(1-A)*Real.exp (-m*t))
    fun_prop
  · change Continuous (fun t : ℝ => l*A*Real.exp (-l*t)+m*(1-A)*Real.exp (-m*t))
    fun_prop

-- @paper-step thm:pid_two_rate_optimum/exponential_order
theorem twoRate_exp_order {l m t : ℝ} (hlm : l ≤ m) (ht : 0 ≤ t) :
    Real.exp (-m*t) ≤ Real.exp (-l*t) := by
  apply Real.exp_le_exp.mpr
  nlinarith

-- @paper-step thm:pid_two_rate_optimum/strict_positive_forcing
theorem twoRateG_positive {A l m t : ℝ} (hA : 1 ≤ A) (hlm : l ≤ m)
    (ht : 0 ≤ t) : 0 < twoRateG A l m t := by
  have he := twoRate_exp_order hlm ht
  have hm := mul_nonneg (sub_nonneg.mpr hA) (sub_nonneg.mpr he)
  have hp := Real.exp_pos (-l*t)
  unfold twoRateG
  nlinarith

-- @paper-step thm:pid_two_rate_optimum/decay_dominates_signal
theorem twoRateD_ge_G {A l m t : ℝ} (hA : 1 ≤ A) (hl : 1 < l)
    (hlm : l ≤ m) (hzero : 1 ≤ l*A+m*(1-A)) (ht : 0 ≤ t) :
    twoRateG A l m t ≤ twoRateD A l m t := by
  have he := twoRate_exp_order hlm ht
  have hm1 : 0 ≤ m-1 := by linarith
  have hm : 0 ≤ (m-1)*(A-1)*(Real.exp (-l*t)-Real.exp (-m*t)) :=
    mul_nonneg (mul_nonneg hm1 (sub_nonneg.mpr hA)) (sub_nonneg.mpr he)
  have hn : 0 ≤ (l*A+m*(1-A)-1)*Real.exp (-l*t) := by positivity
  unfold twoRateG twoRateD
  nlinarith

-- @paper-step thm:pid_two_rate_optimum/rate_restriction
theorem twoRate_rate_condition {ρ l m : ℝ} (hlm : l < m)
    (hr : 1/ρ ≤ l+m-1) :
    1 ≤ l*twoRateA ρ l m+m*(1-twoRateA ρ l m) := by
  have he : l*twoRateA ρ l m+m*(1-twoRateA ρ l m)=l+m-1/ρ := by
    unfold twoRateA
    field_simp [ne_of_gt (sub_pos.mpr hlm)]
    <;> ring
  rw [he]
  linarith

-- @paper-step thm:pid_two_rate_optimum/causal_extension
theorem causalize_causal (f : ℝ → ℝ) : Causal (causalize f) := by
  apply ae_of_all
  intro t ht
  simp [causalize,not_le.mpr ht]

-- @paper-step thm:pid_two_rate_optimum/causal_extension_integral
theorem causalize_integral (f : ℝ → ℝ) :
    (∫ t, causalize f t) = ∫ t, f t ∂halfLine := by
  rw [causalize,integral_indicator measurableSet_Ici,integral_Ici_eq_integral_Ioi]

-- @paper-step thm:pid_two_rate_optimum/causal_extension_integrability
theorem causalize_integrable {f : ℝ → ℝ} (hf : Integrable f halfLine) :
    Integrable (causalize f) := by
  apply IntegrableOn.integrable_indicator _ measurableSet_Ici
  exact (integrableOn_Ici_iff_integrableOn_Ioi).mpr hf

-- @paper-step thm:pid_two_rate_optimum/exponential_integrability
theorem causal_exp_integrable {r : ℝ} (hr : 0 < r) :
    Integrable (causalize (fun t => Real.exp (-r*t))) := by
  exact causalize_integrable (integrableOn_exp_mul_Ioi (by linarith : -r<0) 0)

-- @paper-step thm:pid_two_rate_optimum/exponential_integral
theorem causal_exp_integral {r : ℝ} (hr : 0 < r) :
    (∫ t, causalize (fun t => Real.exp (-r*t)) t)=1/r := by
  rw [causalize_integral]
  unfold halfLine
  rw [integral_exp_mul_Ioi (by linarith : -r<0)]
  simp

-- @paper-step thm:pid_two_rate_optimum/forcing_integrability
theorem twoRateG_integrable (A : ℝ) {l m : ℝ} (hl : 0 < l) (hm : 0 < m) :
    Integrable (causalize (twoRateG A l m)) := by
  apply causalize_integrable
  exact ((integrableOn_exp_mul_Ioi (neg_neg_of_pos hl) 0).const_mul A).add
    ((integrableOn_exp_mul_Ioi (neg_neg_of_pos hm) 0).const_mul (1-A))

-- @paper-step thm:pid_two_rate_optimum/forcing_area
theorem twoRateG_integral (A : ℝ) {l m : ℝ} (hl : 0 < l) (hm : 0 < m) :
    (∫ t, causalize (twoRateG A l m) t)=A/l+(1-A)/m := by
  rw [causalize_integral]
  unfold twoRateG halfLine
  rw [integral_add ((integrableOn_exp_mul_Ioi (neg_neg_of_pos hl) 0).const_mul A)
    ((integrableOn_exp_mul_Ioi (neg_neg_of_pos hm) 0).const_mul (1-A)),
    integral_const_mul,integral_const_mul,
    integral_exp_mul_Ioi (neg_neg_of_pos hl),integral_exp_mul_Ioi (neg_neg_of_pos hm)]
  simp [div_eq_mul_inv]

end MIACE
