import MIACE.HistoryStability

/-! Stage 19. A weighted causal Green function gives an ordinary reduced
solution for every forcing and hence stability of every physical PID state. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution Matrix

-- @paper-step thm:pid_explicit_family/forced_reduced_solution_from_actual_Green_function
theorem green_reduced_resolvent {i ρ ell δ η CG CL : ℝ} {G : ℝ → ℝ}
    (hρ : 0<ρ) (hδ : 0≤δ) (hη : 0≤η) (hGc : Causal G)
    (hG : WeightedControl η G CG) (hL : WeightedControl η (lagKernel ρ) CL)
    (hGT : ∀ p, 0≤p →
      (p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p))*laplace G p=1+ρ*p) :
    ∃ D : ℝ, 0<D ∧ ∀ (H : ℝ → ℝ) (a₀ b₀ M : ℝ), Causal H →
      WeightedControl η H M → |a₀|≤M → |b₀|≤M →
      ∃ a b : ℝ → ℝ, ReducedTransform i ρ ell δ a₀ b₀ H a b ∧
        WeightedControl η a (D*M) ∧ WeightedControl η b (D*M) := by
  let L := lagKernel ρ
  let CF := CG+|i*(ρ-ell)| *Real.exp (η*δ)*(CL*CG)+CG
  let CB := CF
  let CA := |ρ| *CL+CL*CB
  have hCG := hG.nonneg
  have hCL := hL.nonneg
  have hCF : 0≤CF := by dsimp [CF]; positivity
  have hCB : 0≤CB := hCF
  have hCA : 0≤CA := by dsimp [CA]; positivity
  refine ⟨1+CA+CB,by linarith,?_⟩
  intro H a₀ b₀ M hHc hH ha₀ hb₀
  have hM := hH.nonneg
  have hLc : Causal L := (lagKernel_properties hρ).2.2.2
  have hGi : Integrable G := weightedControl_unweighted hG hGc hη
  have hLi : Integrable L := (lagKernel_properties hρ).1
  have hHi : Integrable H := weightedControl_unweighted hH hHc hη
  let J := L ⋆ G
  have hJ := weightedControl_convolution hL hG
  have hJc : Causal J := ae_of_all _ (convolution_causal hLc hGc)
  have hJi : Integrable J := hLi.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hGi
  let f := fun t => (b₀*G t+(i*(ρ-ell)*a₀)*shift δ J t)+(G ⋆ H) t
  have hfc : Causal f := by
    have h₁ := causal_linear hGc (causal_shift hJc hδ) b₀ (i*(ρ-ell)*a₀)
    have h₂ : Causal (G ⋆ H) := ae_of_all _ (convolution_causal hGc hHc)
    simpa only [one_mul] using causal_linear h₁ h₂ 1 1
  have hfw0 := weightedControl_add
    (weightedControl_add (weightedControl_smul hG b₀)
      (weightedControl_smul (weightedControl_shift hJ δ) (i*(ρ-ell)*a₀)))
    (weightedControl_convolution hG hH)
  have hfw : WeightedControl η f (CF*M) := by
    apply weightedControl_mono hfw0
    rw [abs_mul]
    dsimp [CF]
    have h₁ := mul_le_mul_of_nonneg_right hb₀ hCG
    have h₂ := mul_le_mul_of_nonneg_left ha₀
      (show 0≤|i*(ρ-ell)| *Real.exp (η*δ)*(CL*CG) by positivity)
    nlinarith
  let b := f
  have hbc : Causal b := hfc
  have hbw' : WeightedControl η b (CB*M) := hfw
  have hbi : Integrable b := weightedControl_unweighted hbw' hbc hη
  let a := fun t => (ρ*a₀)*L t-(L ⋆ b) t
  have hac : Causal a := by
    have hc : Causal (L ⋆ b) := ae_of_all _ (convolution_causal hLc hbc)
    simpa only [a,L,neg_one_mul,sub_eq_add_neg] using causal_linear hLc hc (ρ*a₀) (-1)
  have haw0 := weightedControl_add (weightedControl_smul hL (ρ*a₀))
    (weightedControl_smul (weightedControl_convolution hL hbw') (-1))
  have haw : WeightedControl η a (CA*M) := by
    apply weightedControl_mono (by simpa only [a,L,neg_one_mul,sub_eq_add_neg] using haw0)
    simp only [abs_neg,abs_one,one_mul,abs_mul]
    dsimp [CA]
    have hh := mul_le_mul_of_nonneg_left ha₀ (mul_nonneg (abs_nonneg ρ) hCL)
    nlinarith
  have hai : Integrable a := weightedControl_unweighted haw hac hη
  have hAlap (p : ℝ) (hp : 0≤p) :
      laplace a p=(ρ*a₀-laplace b p)/(1+ρ*p) := by
    have he := laplace_linear hLi
      (hLi.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hbi) (ρ*a₀) (-1) hp
    simp only [neg_one_mul,← sub_eq_add_neg] at he
    change laplace a p=_ at he
    rw [causal_convolution_laplace hLi hbi hLc hbc hp,lagKernel_laplace hρ hp] at he
    rw [he]
    ring
  have hBchar (p : ℝ) (hp : 0≤p) :
      (p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p))*laplace b p=
      (1+ρ*p)*(b₀+laplace H p)+i*(ρ-ell)*a₀*Real.exp (-δ*p) := by
    have hFhat : laplace f p=
        b₀*laplace G p+(i*(ρ-ell)*a₀)*
          (Real.exp (-δ*p)*(laplace L p*laplace G p))+laplace G p*laplace H p := by
      have h₁ := laplace_linear ((hGi.const_mul b₀).add
        ((shift_integrable δ hJi).const_mul (i*(ρ-ell)*a₀)))
        (hGi.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hHi) 1 1 hp
      simp only [one_mul,Pi.add_apply] at h₁
      change laplace f p=_ at h₁
      rw [h₁]
      change laplace (fun t => b₀*G t+(i*(ρ-ell)*a₀)*shift δ J t) p+laplace (G ⋆ H) p=_
      rw [laplace_linear hGi (shift_integrable δ hJi) b₀ (i*(ρ-ell)*a₀) hp,
        laplace_shift hJc hδ p,
        causal_convolution_laplace hLi hGi hLc hGc hp,
        causal_convolution_laplace hGi hHi hGc hHc hp]
    change (p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p))*laplace f p=_
    rw [hFhat,show laplace L p=1/(1+ρ*p) from lagKernel_laplace hρ hp]
    have hg := hGT p hp
    have hfp : 1+ρ*p≠0 := ne_of_gt (by positivity)
    field_simp [hfp]
    simp only [neg_mul,mul_comm δ p] at hg ⊢
    linear_combination ((1+ρ*p)*(b₀+laplace H p)+i*(ρ-ell)*a₀*Real.exp (-(p*δ)))*hg

  refine ⟨a,b,⟨hai,hbi,hac,hbc,?_,?_⟩,
    weightedControl_mono haw (by nlinarith),weightedControl_mono hbw' (by nlinarith)⟩
  · intro p hp
    have hρ0 := ne_of_gt hρ
    have hfp : 1+ρ*p≠0 := ne_of_gt (by have hh:=hρ; positivity)
    have ha := (eq_div_iff hfp).mp (hAlap p hp.le)
    field_simp [hρ0]
    nlinarith [ha]
  · intro p hp
    have hρ0 := ne_of_gt hρ
    have hfp : 1+ρ*p≠0 := ne_of_gt (by have hh:=hρ; positivity)
    have ha := (eq_div_iff hfp).mp (hAlap p hp.le)
    have hh := hBchar p hp.le
    field_simp [hρ0]
    apply (mul_left_cancel₀ hfp)
    linear_combination (norm := skip) ρ*hh + i*Real.exp (-δ*p)*(ell-ρ)*ha
    simp only [neg_mul,mul_comm δ p]
    ring


-- @paper-step thm:pid_explicit_family/Green_function_implies_uniform_reduced_evolution
theorem green_reduced_evolution {i ρ ell δ η CG : ℝ} {G : ℝ → ℝ}
    (hρ : 0<ρ) (hρ1 : ρ<1) (hδ : 0≤δ) (hη : 0<η) (hηhalf : η≤1/2)
    (hGc : Causal G) (hG : WeightedControl η G CG)
    (hGT : ∀ p, 0≤p →
      (p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p))*laplace G p=1+ρ*p) :
    ∃ D : ℝ, 0<D ∧
      ∀ (H : ℝ → ℝ) (a₀ b₀ M : ℝ), Causal H → WeightedControl η H M →
        |a₀|≤M → |b₀|≤M → ∃ a b : ℝ → ℝ,
          ReducedEvolution i ρ ell δ a₀ b₀ H a b ∧
          WeightedControl η (causalize a) (D*M) ∧ WeightedControl η (causalize b) (D*M) := by
  have hηρ : η<1/ρ := by apply (lt_div_iff₀ hρ).mpr; nlinarith
  obtain ⟨CL,hL⟩ := lagKernel_weightedControl hρ hηρ
  obtain ⟨D,hD,hres⟩ := green_reduced_resolvent hρ hδ hη.le hGc hG hL hGT
  refine ⟨D,hD,?_⟩
  intro H a₀ b₀ M hHc hH ha₀ hb₀
  obtain ⟨a,b,hr,ha,hb⟩ := hres H a₀ b₀ M hHc hH ha₀ hb₀
  exact reduced_transform_realization hδ hr
    (weightedControl_unweighted hH hHc hη.le) ha hb

-- @paper-step thm:pid_explicit_family/uniform_physical_history_exponential_estimate
theorem green_bounded_history_exists {i ρ ell δ η CG : ℝ} {G : ℝ → ℝ}
    (hρ : 0<ρ) (hρ1 : ρ<1) (hδ : 0≤δ) (hη : 0<η) (hηhalf : η≤1/2)
    (hGc : Causal G) (hG : WeightedControl η G CG)
    (hGT : ∀ p, 0≤p →
      (p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p))*laplace G p=1+ρ*p) :
    ∃ η C : ℝ, 0<η ∧ 0<C ∧ ∀ (φ : ℝ → Fin 3 → ℝ),
      (∀ k, Continuous (fun t => φ t k)) → ∀ M : ℝ, 0≤M →
      (∀ s∈Icc (-δ) 0, ∀ k, |φ s k|≤M) → ∃ x : ℝ → Fin 3 → ℝ,
        PIDHistoryEvolution i ρ ell δ φ x ∧ ∀ t, 0≤t → ∀ k,
          |x t k|≤C*M*Real.exp (-η*t) := by
  obtain ⟨D,hD,hr⟩ := green_reduced_evolution hρ hρ1 hδ hη hηhalf hGc hG hGT
  let G := |i*(1+ell-ρ)+(i*(ell-ρ)*(1-ρ))/ρ|+|i|+|(i*(ell-ρ)*(1-ρ))/ρ|
  let B := (δ+1)*Real.exp (η*δ)*G
  let S := 3+|1-ρ|+B
  let T := 1+2*D*S
  let C := T+T/|1-ρ|
  have hG : 0≤G := by dsimp [G]; positivity
  have hB : 0≤B := by dsimp [B]; positivity
  have hS : 0<S := by dsimp [S]; positivity
  have hT : 0<T := by dsimp [T]; positivity
  have hden : 0 < |1-ρ| := abs_pos.mpr (ne_of_gt (sub_pos.mpr hρ1))
  have hC : 0<C := by dsimp [C]; positivity
  have hTC : T≤C := by dsimp [C]; linarith [show 0≤T/|1-ρ| by positivity]
  have hTdivC : T/|1-ρ|≤C := by dsimp [C]; linarith
  refine ⟨η,C,hη,hC,?_⟩
  intro φ hφ M hM hb
  have hzero : (0 : ℝ)∈Icc (-δ) 0 := ⟨by linarith,le_rfl⟩
  have h0 := hb 0 hzero
  have hw : Continuous (pidCommand i ρ ell φ) := by
    unfold pidCommand pidHomogeneousCommand
    exact (((hφ 0).const_mul _).add ((hφ 1).const_mul _)).add
      (((hφ 0).neg.sub (hφ 2)).const_mul _)
  have hhist : WeightedControl η (pidHistoryForcing i ρ ell δ φ) (B*M) := by
    have hh := historyInput_weightedControl hw hδ hη.le (mul_nonneg hG hM)
      (fun s hs => pidHomogeneousCommand_bound (i*(1+ell-ρ)) i (i*(ell-ρ)*(1-ρ)) ρ hM (φ s) (hb s hs))
    convert hh using 1 <;> dsimp [B,pidHistoryForcing] <;> ring
  have hM' : B*M≤S*M := mul_le_mul_of_nonneg_right (by dsimp [S]; linarith [abs_nonneg (1-ρ)]) hM
  have ha0 : |pidReduce ρ (φ 0) 0|≤S*M := by
    change |φ 0 1+(1-ρ)*φ 0 2|≤_
    have hh := abs_add_le (φ 0 1) ((1-ρ)*φ 0 2)
    rw [abs_mul] at hh
    have hmul := mul_le_mul_of_nonneg_left (h0 2) (abs_nonneg (1-ρ))
    dsimp [S]
    nlinarith [h0 1,mul_nonneg hB hM]
  have hb0 : |pidReduce ρ (φ 0) 1|≤S*M := by
    change |φ 0 0-φ 0 1|≤_
    have hh := abs_sub_le (φ 0 0) 0 (φ 0 1)
    simp only [sub_zero,zero_sub,abs_neg] at hh
    dsimp [S]
    nlinarith [h0 0,h0 1,mul_nonneg (abs_nonneg (1-ρ)) hM,mul_nonneg hB hM]
  obtain ⟨a,b,he,ha,hb'⟩ := hr (pidHistoryForcing i ρ ell δ φ)
    (pidReduce ρ (φ 0) 0) (pidReduce ρ (φ 0) 1) (S*M)
    (historyInput_causal _ _) (weightedControl_mono hhist hM') ha0 hb0
  let x := fun t => pidRestore ρ ![a t,b t,pidStableState (φ 0 1) b t]
  refine ⟨x,pid_evolution_restore (ne_of_gt hρ) (ne_of_lt hρ1) φ he,?_⟩
  have hadec := weightedControl_continuous_decay he.continuous_a ha
  have hbdec := weightedControl_continuous_decay he.continuous_b hb'
  have hx := pidRestore_decay (ne_of_lt hρ1) (by linarith : η≤1)
    (φ 0 1) hb'.integrable hadec hbdec
  have hcc : |φ 0 1|+(∫ s, |expWeight η (causalize b) s|)≤M+D*(S*M) := add_le_add (h0 1) hb'.area
  intro t ht k
  obtain ⟨hy,hz,hζ⟩ := hx t ht
  have hsum : D*(S*M)+(|φ 0 1|+∫ s, |expWeight η (causalize b) s|)≤T*M := by dsimp [T]; nlinarith
  have hcsmall : |φ 0 1|+(∫ s, |expWeight η (causalize b) s|)≤T*M := by
    dsimp [T]; nlinarith [mul_nonneg hD.le (mul_nonneg hS.le hM)]
  have hcommon : T*M≤C*M := mul_le_mul_of_nonneg_right hTC hM
  fin_cases k
  · exact hy.trans (mul_le_mul_of_nonneg_right (hsum.trans hcommon) (Real.exp_nonneg _))
  · exact hz.trans (mul_le_mul_of_nonneg_right (hcsmall.trans hcommon) (Real.exp_nonneg _))
  · apply hζ.trans
    apply mul_le_mul_of_nonneg_right _ (Real.exp_nonneg _)
    calc
      _ ≤ (T*M)/|1-ρ| := div_le_div_of_nonneg_right hsum hden.le
      _ = (T/|1-ρ|)*M := by ring
      _ ≤ C*M := mul_le_mul_of_nonneg_right hTdivC hM

-- @paper-step thm:pid_explicit_family/all_history_internal_exponential_stability
theorem green_PID_internal_stability {i ρ ell δ η CG : ℝ} {G : ℝ → ℝ}
    (hρ : 0<ρ) (hρ1 : ρ<1) (hδ : 0≤δ) (hη : 0<η) (hηhalf : η≤1/2)
    (hGc : Causal G) (hG : WeightedControl η G CG)
    (hGT : ∀ p, 0≤p →
      (p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p))*laplace G p=1+ρ*p) :
    PIDInternallyExponentiallyStable i ρ ell δ := by
  obtain ⟨η,C,hη,hC,hr⟩ := green_bounded_history_exists hρ hρ1 hδ hη hηhalf hGc hG hGT
  refine ⟨η,C,hη,hC,?_⟩
  intro φ hφ
  obtain ⟨ψ,hψ,heψ⟩ := history_continuous_extension hδ hφ
  obtain ⟨M₀,hM₀,hb₀⟩ := history_bound_exists hψ hδ
  obtain ⟨x,hxψ,_⟩ := hr ψ hψ M₀ hM₀ hb₀
  have hx : PIDHistoryEvolution i ρ ell δ φ x :=
    pid_history_evolution_congr hδ heψ hxψ
  have hu := fun {X} (hX : PIDHistoryEvolution i ρ ell δ φ X) =>
    pid_history_unique (ne_of_gt hρ) (ne_of_lt hρ1) hδ hX hx
  refine ⟨x,hx,(fun X hX => hu hX),?_⟩
  intro M hM hb t ht k
  have hbψ : ∀ s∈Icc (-δ) 0, ∀ j, |ψ s j|≤M := by
    intro s hs j
    rw [heψ s hs]
    exact hb s hs j
  obtain ⟨X,hXψ,hbound⟩ := hr ψ hψ M hM hbψ
  have hX := pid_history_evolution_congr hδ heψ hXψ
  rw [← hu hX t ht]
  exact hbound t ht k


end MIACE
