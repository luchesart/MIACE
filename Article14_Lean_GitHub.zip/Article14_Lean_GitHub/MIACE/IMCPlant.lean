import MIACE.IMCSteps

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:complete_robust/ordinary_local_convolution_associativity
theorem local_convolution_assoc {K H u : ℝ → ℝ}
    (hK : Integrable K) (hH : Integrable H) (hKc : Causal K) (hHc : Causal H)
    (hu : LocallyIntegrable u volume) (huc : Causal u) :
    (K ⋆ (H ⋆ u))=ᵐ[volume] ((K ⋆ H) ⋆ u) := by
  apply causalLocalOperator_ext
    (causalLocalOperator_comp (convolution_local_operator hK hKc) (convolution_local_operator hH hHc))
    (convolution_local_operator (hK.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hH)
      (ae_of_all _ (convolution_causal hKc hHc))) _ hu huc
  intro f hf hfc
  exact (causal_convolution_assoc hK hH hf hKc hHc hfc).symm

-- @paper-step thm:complete_robust/ordinary_local_filter_convolution
theorem local_filter_convolution (F : IMCFilter) {K u : ℝ → ℝ}
    (hK : Integrable K) (hKc : Causal K) (hu : LocallyIntegrable u volume) (huc : Causal u) :
    filterAction F (K ⋆ u)=ᵐ[volume] (filterAction F K ⋆ u) := by
  apply causalLocalOperator_ext
    (causalLocalOperator_comp (filter_local_operator F) (convolution_local_operator hK hKc))
    (convolution_local_operator (filterAction_integrable F hK) (filterAction_causal F hKc)) _ hu huc
  intro f hf hfc
  exact filterAction_convolution F hK hf hKc hfc

-- @paper-step thm:complete_robust/arbitrary_ordinary_cascade_kernel_semantics
theorem ordinaryCascade_kernel_local {u : ℝ → ℝ} (hu : LocallyIntegrable u volume) (huc : Causal u)
    (σ : ℕ → ℝ) (n : ℕ) (hσ : ∀ j≤n, 0<σ j) :
    causalize (ordinaryCascade σ u (n+1))=ᵐ[volume] (serialImpulse σ n ⋆ u) := by
  induction n with
  | zero =>
    have hh := lagState_causal_formula (hσ 0 le_rfl) 0 u
    simpa only [lagState_zero,zero_mul,zero_add,ordinaryCascade,serialImpulse,
      convolution_congr (ContinuousLinearMap.lsmul ℝ ℝ) (EventuallyEq.rfl (f := lagKernel (σ 0)))
        (causalize_eq_ae huc)] using hh
  | succ n ih =>
    have hn : ∀ j≤n, 0<σ j := fun j hj => hσ j (by omega)
    have hs := hσ (n+1) le_rfl
    have hh := lagState_causal_formula hs 0 (ordinaryCascade σ u (n+1))
    simp only [lagState_zero,zero_mul,zero_add] at hh
    have he := convolution_congr (ContinuousLinearMap.lsmul ℝ ℝ)
      (EventuallyEq.rfl (f := lagKernel (σ (n+1)))) (ih hn)
    exact hh.trans ((Filter.EventuallyEq.of_eq he).trans
      (local_convolution_assoc (lagKernel_properties hs).1 (serialImpulse_properties σ n hn).1
        (lagKernel_properties hs).2.2.2 (serialImpulse_properties σ n hn).2 hu huc))

-- @paper-step thm:complete_robust/transport_left_convolution_identity
theorem shift_convolution_left (δ : ℝ) (f g : ℝ → ℝ) :
    (shift δ f ⋆ g)=shift δ (f ⋆ g) := by
  funext t
  rw [convolution_lsmul_swap,show shift δ (f ⋆ g) t=(f ⋆ g) (t-δ) from rfl,
    convolution_lsmul_swap]
  apply integral_congr_ae
  exact ae_of_all _ (fun s => by
    have he : t-s-δ=t-δ-s := by ring
    simp [shift,he])

-- @paper-step thm:complete_robust/transport_ae_invariance
theorem shift_congr {f g : ℝ → ℝ} (he : f=ᵐ[volume] g) (δ : ℝ) :
    shift δ f=ᵐ[volume] shift δ g :=
  (measurePreserving_sub_right (volume : Measure ℝ) δ).quasiMeasurePreserving.tendsto_ae.eventually he

noncomputable def plantHistoryOutput (N : ℕ) (σ ξ : ℕ → ℝ) (δ : ℝ)
    (φ u : ℝ → ℝ) (t : ℝ) : ℝ :=
  historyInput δ φ t+shift δ (causalize (serialState σ ξ u (N+1))) t
noncomputable def plantFreeOutput (N : ℕ) (σ ξ : ℕ → ℝ) (δ : ℝ) (φ : ℝ → ℝ) : ℝ → ℝ :=
  plantHistoryOutput N σ ξ δ φ (fun _ => 0)

-- @paper-step thm:complete_robust/full_history_plant_decomposition
theorem plantHistoryOutput_split (N : ℕ) (σ ξ : ℕ → ℝ) (δ : ℝ) (φ : ℝ → ℝ)
    {u : ℝ → ℝ} (hu : LocallyIntegrable u volume) (huc : Causal u)
    (hσ : ∀ j≤N, 0<σ j) :
    plantHistoryOutput N σ ξ δ φ u=ᵐ[volume]
      (fun t => plantFreeOutput N σ ξ δ φ t+(shift δ (serialImpulse σ N) ⋆ u) t) := by
  have he : causalize (serialState σ ξ u (N+1))=ᵐ[volume]
      (fun t => causalize (serialState σ ξ (fun _ => 0) (N+1)) t+(serialImpulse σ N ⋆ u) t) := by
    filter_upwards [ordinaryCascade_kernel_local hu huc σ N hσ] with t ht
    rw [serialState_split hu σ ξ]
    by_cases hp : 0≤t
    · simp only [causalize,indicator_of_mem (show t∈Ici (0 : ℝ) from hp)] at ht ⊢
      rw [ht]
    · have hn := lt_of_not_ge hp
      simp [causalize,hp,convolution_causal (serialImpulse_properties σ N hσ).2 huc t hn]
  filter_upwards [shift_congr he δ] with t ht
  have hh : shift δ (causalize (serialState σ ξ u (N+1))) t=
      shift δ (causalize (serialState σ ξ (fun _ => 0) (N+1))) t+
        shift δ (serialImpulse σ N ⋆ u) t := ht
  simp only [plantHistoryOutput,plantFreeOutput,shift_convolution_left]
  rw [hh]
  ring

-- @paper-step thm:complete_robust/history_plant_causality
theorem plantHistoryOutput_causal (N : ℕ) (σ ξ : ℕ → ℝ) {δ : ℝ} (hδ : 0≤δ)
    (φ u : ℝ → ℝ) : Causal (plantHistoryOutput N σ ξ δ φ u) := by
  filter_upwards [historyInput_causal δ φ,
    causal_shift (causalize_causal (serialState σ ξ u (N+1))) hδ] with t ht hs hn
  simp [plantHistoryOutput,ht hn,hs hn]

-- Only the actual finite delay interval is assumed continuous.
-- @paper-step thm:complete_robust/finite_history_weighted_control
theorem historyInput_control_on {φ : ℝ → ℝ} {δ η M : ℝ}
    (hδ : 0≤δ) (hη : 0≤η) (hM : 0≤M)
    (hφ : ContinuousOn φ (Icc (-δ) 0)) (hb : ∀ s∈Icc (-δ) 0, |φ s|≤M) :
    WeightedControl η (historyInput δ φ) ((δ+1)*Real.exp (η*δ)*M) := by
  let q := fun t : ℝ => max (-δ) (min 0 t)
  have hq : Continuous q := continuous_const.max (continuous_const.min continuous_id)
  have hmem (t : ℝ) : q t∈Icc (-δ) 0 :=
    ⟨le_max_left _ _,max_le (by linarith) (min_le_left _ _)⟩
  have he (t : ℝ) (ht : t∈Icc (-δ) 0) : q t=t := by
    dsimp [q]; rw [min_eq_right ht.2,max_eq_right ht.1]
  have hh := historyInput_weightedControl (hφ.comp_continuous hq hmem) hδ hη hM
    (fun s hs => hb (q s) (hmem s))
  have hid : historyInput δ (φ ∘ q)=historyInput δ φ := by
    apply historyInput_congr
    intro t ht
    change φ (q t)=φ t
    rw [he t ht]
  rwa [hid] at hh

-- @paper-step thm:complete_robust/plant_output_full_history_decay
theorem plantHistoryOutput_control (N : ℕ) (σ ξ : ℕ → ℝ) {δ η C M : ℝ}
    (hδ : 0≤δ) (hη : 0≤η) (hM : 0≤M) {φ u : ℝ → ℝ}
    (hφ : ContinuousOn φ (Icc (-δ) 0)) (hb : ∀ s∈Icc (-δ) 0, |φ s|≤M)
    (hx : WeightedControl η (causalize (serialState σ ξ u (N+1))) C) :
    WeightedControl η (plantHistoryOutput N σ ξ δ φ u)
      ((δ+1)*Real.exp (η*δ)*M+Real.exp (η*δ)*C) :=
  weightedControl_add (historyInput_control_on hδ hη hM hφ hb) (weightedControl_shift hx δ)

end MIACE
