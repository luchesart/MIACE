import MIACE.Moments
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Analysis.Calculus.Deriv.MeanValue

/-! Етап 6: затваряме скаларното уравнение за най-малкия команден пик.
Непрекъснатостта при c=0 се доказва, не се приема като хипотеза. -/
namespace MIACE
open Set Filter MeasureTheory
open scoped Topology
noncomputable def capacity (c : ℝ) : ℝ := c * Real.log (1 + 1/c)

-- @paper-step thm:complete_cap/capacity_continuity
theorem capacity_continuous : ContinuousOn capacity (Ici 0) := by
  have hid : ∀ c ∈ Ici (0 : ℝ), capacity c =
      c * Real.log (1+c) - c * Real.log c := by
    intro c hc
    change 0 ≤ c at hc
    rcases hc.eq_or_lt with rfl | hc
    · simp [capacity]
    · rw [capacity, show 1+1/c = (1+c)/c by field_simp; ring,
        Real.log_div (by positivity) (ne_of_gt hc)]
      ring
  apply ContinuousOn.congr _ hid
  apply ContinuousOn.sub _ Real.continuous_mul_log.continuousOn
  exact continuousOn_id.mul ((continuous_const.add continuous_id).continuousOn.log
    (fun c hc => ne_of_gt (by change 0 ≤ c at hc; change 0 < 1+c; linarith)))

-- @paper-step thm:complete_cap/capacity_derivative
theorem capacity_hasDerivAt {c : ℝ} (hc : 0 < c) :
    HasDerivAt capacity (Real.log (1+1/c) - 1/(1+c)) c := by
  have hc0 := ne_of_gt hc
  have hpos : 0 < 1+1/c := by positivity
  have h := (hasDerivAt_id c).mul
    (((hasDerivAt_const c 1).add ((hasDerivAt_const c 1).div
      (hasDerivAt_id c) hc0)).log (ne_of_gt hpos))
  convert h using 1
  · rfl
  · dsimp
    field_simp [hc0, ne_of_gt (show 0 < 1+c by linarith)]
    <;> ring

-- @paper-step thm:complete_cap/capacity_log_strict_lower
theorem capacity_log_lower {c : ℝ} (hc : 0 < c) :
    1/(1+c) < Real.log (1+1/c) := by
  have ht : 0 < 1+1/c := by positivity
  have hi : (1+1/c)⁻¹ ≠ 1 := by
    intro h
    have := inv_eq_one.mp h
    have : 1/c = 0 := by linarith
    simp [ne_of_gt hc] at this
  have h := Real.log_lt_sub_one_of_pos (inv_pos.mpr ht) hi
  rw [Real.log_inv] at h
  have hid : 1 - (1+1/c)⁻¹ = 1/(1+c) := by field_simp; ring
  linarith

-- @paper-step thm:complete_cap/capacity_strict_monotonicity
theorem capacity_strictMono : StrictMonoOn capacity (Ici 0) := by
  apply strictMonoOn_of_deriv_pos (convex_Ici _) capacity_continuous
  intro c hc
  rw [interior_Ici] at hc
  rw [(capacity_hasDerivAt hc).deriv]
  exact sub_pos.mpr (capacity_log_lower hc)

-- @paper-step thm:complete_cap/capacity_lower_bound
theorem capacity_lower {c : ℝ} (hc : 0 < c) :
    c/(1+c) < capacity c := by
  have h := mul_lt_mul_of_pos_left (capacity_log_lower hc) hc
  simpa [capacity, div_eq_mul_inv] using h

-- @paper-step thm:complete_cap/minimum_peak_unique
theorem capacity_unique {U : ℝ} (hU : 0 < U) (hU1 : U < 1) :
    ∃! c : ℝ, 0 < c ∧ capacity c = U := by
  let b := U/(1-U)
  have hb : 0 < b := by dsimp [b]; positivity
  have hlow : b/(1+b) = U := by
    dsimp [b]
    have hh : 1-U ≠ 0 := ne_of_gt (sub_pos.mpr hU1)
    field_simp [hh]
    <;> ring
  have hUb : U < capacity b := by rw [← hlow]; exact capacity_lower hb
  have hz : capacity 0 = 0 := by simp [capacity]
  obtain ⟨c, hc, he⟩ := intermediate_value_Icc hb.le
    (capacity_continuous.mono (fun _ h => h.1))
    (show U ∈ Icc (capacity 0) (capacity b) from ⟨by rw [hz]; exact hU.le, hUb.le⟩)
  have hcp : 0 < c := lt_of_le_of_ne hc.1 (by intro h; subst c; rw [hz] at he; linarith)
  refine ⟨c, ⟨hcp, he⟩, ?_⟩
  rintro d ⟨hd, he'⟩
  exact capacity_strictMono.injOn hd.le hcp.le (he'.trans he.symm)

-- @paper-step thm:complete_cap/minimum_peak_order
theorem capacity_minimum_peak {U c : ℝ} (hc : 0 < c) (he : capacity c = U)
    {d : ℝ} (hd : 0 < d) : U ≤ capacity d ↔ c ≤ d := by
  rw [← he]
  exact capacity_strictMono.le_iff_le hc.le hd.le

-- @paper-step thm:complete_cap/exponential_peak_strict_gap
theorem minimum_peak_lt_exponential {U c : ℝ} (hU : 0 < U) (hU1 : U < 1)
    (hc : 0 < c) (he : capacity c = U) : 1+c < 1/(1-U) := by
  have hb : 0 < U/(1-U) := by positivity
  have hb' : U/(1-U)/(1+U/(1-U)) = U := by
    have hh : 1-U ≠ 0 := ne_of_gt (sub_pos.mpr hU1)
    field_simp [hh]
    <;> ring
  have h := capacity_lower hb
  rw [hb'] at h
  have h' : capacity c < capacity (U/(1-U)) := by simpa only [he] using h
  have hcd := (capacity_strictMono.lt_iff_lt hc.le hb.le).mp h'
  have hid : 1+U/(1-U) = 1/(1-U) := by field_simp [ne_of_gt (sub_pos.mpr hU1)]; ring
  linarith

-- @paper-step thm:complete_cap/capacity_range
theorem capacity_image : capacity '' Ioi 0 = Ioo 0 1 := by
  ext U
  constructor
  · rintro ⟨c,hc,rfl⟩
    exact ⟨capacity_positive c hc,capacity_lt_one c hc⟩
  · rintro ⟨hU,hU1⟩
    obtain ⟨c,hc,_⟩ := capacity_unique hU hU1
    exact ⟨c,hc.1,hc.2⟩

-- @paper-step thm:complete_cap/capacity_zero_limit
theorem capacity_zero_limit : Tendsto capacity (𝓝[≥] 0) (𝓝 0) := by
  simpa [capacity] using (capacity_continuous.continuousWithinAt (show (0 : ℝ) ∈ Ici 0 from by simp)).tendsto

-- @paper-step thm:complete_cap/capacity_infinity_limit
theorem capacity_infinity_limit : Tendsto capacity atTop (𝓝 1) := by
  have htop : Tendsto (fun c : ℝ => 1+c) atTop atTop := tendsto_const_nhds.add_atTop tendsto_id
  have hlo : Tendsto (fun c : ℝ => 1-1/(1+c)) atTop (𝓝 1) := by
    simpa using tendsto_const_nhds.sub (tendsto_const_nhds.div_atTop htop :
      Tendsto (fun c : ℝ => 1/(1+c)) atTop (𝓝 0))
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' hlo tendsto_const_nhds
  · filter_upwards [eventually_gt_atTop (0 : ℝ)] with c hc
    have hid : 1-1/(1+c) = c/(1+c) := by field_simp; ring
    rw [hid]
    exact (capacity_lower hc).le
  · filter_upwards [eventually_gt_atTop (0 : ℝ)] with c hc
    exact (capacity_lt_one c hc).le

end MIACE
