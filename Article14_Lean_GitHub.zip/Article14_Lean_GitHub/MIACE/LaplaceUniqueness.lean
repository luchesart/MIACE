import MIACE.OrdinaryPID
import Mathlib.Topology.ContinuousMap.Weierstrass

/-! Етап 10: единственост на действителното преобразуване на Лаплас.
    Доказателството използва полиноми върху [0,1] след x=exp(-t).
    Не се добавя аксиома за обратно преобразуване. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Polynomial

noncomputable def expUnit (t : ℝ) : Icc (0 : ℝ) 1 :=
  ⟨Real.exp (-max 0 t), (Real.exp_pos _).le,
    Real.exp_le_one_iff.mpr (neg_nonpos.mpr (le_max_left _ _))⟩

noncomputable def laplaceProbe (f : ℝ → ℝ) (h : C(Icc (0 : ℝ) 1, ℝ)) : ℝ :=
  ∫ t, Real.exp (-t)*f t*h (expUnit t) ∂halfLine

-- @paper-step thm:pid_two_rate_optimum/laplace_compact_coordinate
theorem expUnit_continuous : Continuous expUnit := by
  apply Continuous.subtype_mk
  change Continuous (fun t : ℝ => Real.exp (-max 0 t))
  fun_prop

-- @paper-step thm:pid_two_rate_optimum/laplace_test_integrability
theorem laplaceProbe_integrable {f : ℝ → ℝ} (hf : Integrable f halfLine)
    (h : C(Icc (0 : ℝ) 1, ℝ)) :
    Integrable (fun t => Real.exp (-t)*f t*h (expUnit t)) halfLine := by
  have hw : Integrable (fun t => Real.exp (-t)*f t) halfLine := by
    simpa using laplace_integrable hf (p := 1) (by norm_num)
  exact hw.mul_bdd (h.continuous.comp expUnit_continuous).aestronglyMeasurable
    (ae_of_all _ (fun t => h.norm_coe_le_norm (expUnit t)))

-- @paper-step thm:pid_two_rate_optimum/laplace_test_norm_bound
theorem laplaceProbe_bound {f : ℝ → ℝ} (hf : Integrable f halfLine)
    (h : C(Icc (0 : ℝ) 1, ℝ)) :
    |laplaceProbe f h| ≤ (∫ t, |Real.exp (-t)*f t| ∂halfLine)*‖h‖ := by
  have hw : Integrable (fun t => Real.exp (-t)*f t) halfLine := by
    simpa using laplace_integrable hf (p := 1) (by norm_num)
  calc
    _ ≤ ∫ t, |Real.exp (-t)*f t*h (expUnit t)| ∂halfLine := by
      simpa only [laplaceProbe, Real.norm_eq_abs] using
        (norm_integral_le_integral_norm (fun t => Real.exp (-t)*f t*h (expUnit t))
          (μ := halfLine))
    _ ≤ ∫ t, |Real.exp (-t)*f t| * ‖h‖ ∂halfLine := by
      apply integral_mono (laplaceProbe_integrable hf h).abs (hw.abs.mul_const _)
      intro t
      dsimp only
      rw [abs_mul]
      exact mul_le_mul_of_nonneg_left (h.norm_coe_le_norm (expUnit t)) (abs_nonneg _)
    _ = _ := integral_mul_const _ _

-- @paper-step thm:pid_two_rate_optimum/laplace_test_polynomial_moments
theorem laplaceProbe_polynomial_zero {f : ℝ → ℝ} (hf : Integrable f halfLine)
    (hz : ∀ p : ℝ, 0<p → laplace f p=0) (q : ℝ[X]) :
    laplaceProbe f (q.toContinuousMapOn (Icc (0 : ℝ) 1))=0 := by
  induction q using Polynomial.induction_on' with
  | add p q hp hq =>
    have he : laplaceProbe f ((p+q).toContinuousMapOn (Icc (0 : ℝ) 1))=
        laplaceProbe f (p.toContinuousMapOn (Icc (0 : ℝ) 1))+
        laplaceProbe f (q.toContinuousMapOn (Icc (0 : ℝ) 1)) := by
      unfold laplaceProbe
      simp only [Polynomial.toContinuousMapOn_apply, Polynomial.toContinuousMap_apply,
        Polynomial.eval_add, mul_add]
      exact integral_add (laplaceProbe_integrable hf (p.toContinuousMapOn _))
        (laplaceProbe_integrable hf (q.toContinuousMapOn _))
    rw [he,hp,hq,add_zero]
  | monomial n c =>
    have he : laplaceProbe f ((Polynomial.monomial n c).toContinuousMapOn (Icc (0 : ℝ) 1))=
        c*laplace f ((n : ℝ)+1) := by
      rw [laplaceProbe,laplace,← integral_const_mul]
      apply integral_congr_ae
      filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
      have ht' : 0≤t := (show 0<t from ht).le
      simp only [Polynomial.toContinuousMapOn_apply,Polynomial.toContinuousMap_apply,Polynomial.eval_monomial,
        expUnit,max_eq_right ht']
      have hx : Real.exp (-t)*(Real.exp (-t))^n=Real.exp (-((n : ℝ)+1)*t) := by
        rw [← Real.exp_nat_mul,← Real.exp_add]
        congr 1; ring
      calc
        _ = c*(Real.exp (-t)*(Real.exp (-t))^n)*f t := by ring
        _ = _ := by rw [hx]; ring
    rw [he,hz _ (by positivity),mul_zero]

-- @paper-step thm:pid_two_rate_optimum/laplace_test_density
theorem laplaceProbe_zero {f : ℝ → ℝ} (hf : Integrable f halfLine)
    (hz : ∀ p : ℝ, 0<p → laplace f p=0) (h : C(Icc (0 : ℝ) 1, ℝ)) :
    laplaceProbe f h=0 := by
  let B := ∫ t, |Real.exp (-t)*f t| ∂halfLine
  have hB : 0≤B := integral_nonneg (fun _ => abs_nonneg _)
  by_contra hn
  have hp : 0 < |laplaceProbe f h| := abs_pos.mpr hn
  obtain ⟨q,hq⟩ := exists_polynomial_near_continuousMap 0 1 h
    (|laplaceProbe f h|/(B+1)) (div_pos hp (by linarith))
  let Q := q.toContinuousMapOn (Icc (0 : ℝ) 1)
  have he : laplaceProbe f (Q-h)= -laplaceProbe f h := by
    unfold laplaceProbe
    simp only [ContinuousMap.sub_apply,mul_sub]
    rw [integral_sub (laplaceProbe_integrable hf Q) (laplaceProbe_integrable hf h)]
    change laplaceProbe f Q-laplaceProbe f h= -laplaceProbe f h
    rw [laplaceProbe_polynomial_zero hf hz q,zero_sub]
  have hb := laplaceProbe_bound hf (Q-h)
  rw [he,abs_neg] at hb
  have hq' : ‖Q-h‖*(B+1) < |laplaceProbe f h| :=
    (lt_div_iff₀ (by linarith : 0<B+1)).mp hq
  have hnn := norm_nonneg (Q-h)
  change |laplaceProbe f h|≤B*‖Q-h‖ at hb
  nlinarith

-- Положителен локализиращ множител прави интеграла квадрат на f.
-- Така не се предполага ограниченост на f или гладкост на обратен образ.
-- @paper-step thm:pid_two_rate_optimum/laplace_zero_implies_pointwise_zero
theorem laplace_zero_unique {f : ℝ → ℝ} (hf : Integrable f halfLine)
    (hc : Continuous f) (hz : ∀ p : ℝ, 0<p → laplace f p=0) :
    ∀ t : ℝ, 0≤t → f t=0 := by
  intro t ht
  let ε := Real.exp (-t)/2
  have hε : 0<ε := by dsimp [ε]; positivity
  have hl : Continuous (fun x : ℝ => Real.log (max x ε)) :=
    (continuous_id.max continuous_const).log
      (fun x => ne_of_gt (lt_of_lt_of_le hε (le_max_right x ε)))
  let h : C(Icc (0 : ℝ) 1, ℝ) :=
    ⟨fun x => f (-Real.log (max (x : ℝ) ε))*max ((x : ℝ)-ε) 0,
      (hc.comp (hl.neg.comp continuous_subtype_val)).mul
        ((continuous_subtype_val.sub continuous_const).max continuous_const)⟩
  let φ : ℝ → ℝ := fun u => Real.exp (-u)*(f u)^2*max (Real.exp (-u)-ε) 0
  have hi : ∀ u : ℝ, 0≤u → Real.exp (-u)*f u*h (expUnit u)=φ u := by
    intro u hu
    dsimp [h,expUnit,φ]
    rw [max_eq_right hu]
    by_cases he : ε≤Real.exp (-u)
    · rw [max_eq_left he,Real.log_exp,neg_neg]
      ring
    · rw [max_eq_right (show Real.exp (-u)-ε≤0 by linarith)]
      simp
  have hae : (fun u => Real.exp (-u)*f u*h (expUnit u))=ᵐ[halfLine] φ := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with u hu
    exact hi u (show 0<u from hu).le
  have hφi := (laplaceProbe_integrable hf h).congr hae
  have hφz : (∫ u, φ u ∂halfLine)=0 := by
    rw [← integral_congr_ae hae]
    exact laplaceProbe_zero hf hz h
  have hφn : ∀ u, 0≤φ u := by intro u; dsimp [φ]; positivity
  have hφae : φ=ᵐ[halfLine] (fun _ => (0 : ℝ)) :=
    (integral_eq_zero_iff_of_nonneg_ae (ae_of_all _ hφn) hφi).mp hφz
  have hφc : Continuous φ := by dsimp [φ]; fun_prop
  have heq := continuous_halfLine_unique hφc continuous_const hφae t ht
  by_contra hn
  have hcut : 0<max (Real.exp (-t)-ε) 0 := by
    apply lt_of_lt_of_le _ (le_max_left _ _)
    dsimp [ε]; linarith [Real.exp_pos (-t)]
  have hp : 0<φ t := mul_pos (mul_pos (Real.exp_pos _) (sq_pos_of_ne_zero hn)) hcut
  linarith

-- @paper-step thm:pid_two_rate_optimum/laplace_pointwise_injectivity
theorem laplace_injective_continuous {f g : ℝ → ℝ}
    (hf : Integrable f halfLine) (hg : Integrable g halfLine)
    (hfc : Continuous f) (hgc : Continuous g)
    (he : ∀ p : ℝ, 0<p → laplace f p=laplace g p) :
    ∀ t : ℝ, 0≤t → f t=g t := by
  have hz : ∀ p : ℝ, 0<p → laplace (fun t => f t-g t) p=0 := by
    intro p hp
    unfold laplace
    simp_rw [mul_sub]
    rw [integral_sub (laplace_integrable hf hp.le) (laplace_integrable hg hp.le)]
    exact sub_eq_zero.mpr (he p hp)
  intro t ht
  exact sub_eq_zero.mp (laplace_zero_unique (hf.sub hg) (hfc.sub hgc) hz t ht)

-- Експоненциалното претегляне допуска и сигнали, които не са L¹,
-- например интегратора преди изваждане на установената му стойност.
-- @paper-step thm:pid_two_rate_optimum/laplace_weighted_injectivity
theorem laplace_injective_weighted {f g : ℝ → ℝ} {a : ℝ}
    (hf : Integrable (fun t => Real.exp (-a*t)*f t) halfLine)
    (hg : Integrable (fun t => Real.exp (-a*t)*g t) halfLine)
    (hfc : Continuous f) (hgc : Continuous g)
    (he : ∀ p : ℝ, a<p → laplace f p=laplace g p) :
    ∀ t : ℝ, 0≤t → f t=g t := by
  have hs : ∀ (F : ℝ → ℝ) (p : ℝ),
      laplace (fun t => Real.exp (-a*t)*F t) p=laplace F (p+a) := by
    intro F p
    apply integral_congr_ae
    apply ae_of_all
    intro t
    change Real.exp (-p*t)*(Real.exp (-a*t)*F t)=Real.exp (-(p+a)*t)*F t
    rw [← mul_assoc,← Real.exp_add]
    congr 2; ring
  have hh := laplace_injective_continuous hf hg
    ((by fun_prop : Continuous (fun t : ℝ => Real.exp (-a*t))).mul hfc)
    ((by fun_prop : Continuous (fun t : ℝ => Real.exp (-a*t))).mul hgc)
    (fun p hp => by rw [hs,hs]; exact he (p+a) (by linarith))
  intro t ht
  exact (mul_left_cancel₀ (ne_of_gt (Real.exp_pos (-a*t)))) (hh t ht)

end MIACE
