import MIACE.DelayCascade
import MIACE.Transfer

/-! Свързване на действителните ядра и Лапласови интеграли с H(p) от статията. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:complete_robust/kernel_laplace_semantics
theorem kernel_laplace_full {f : ℝ → ℝ} (hc : Causal f) (p : ℝ) :
    (∫ t, expWeight (-p) f t) = laplace f p := by
  exact causal_integral_halfLine (expWeight_causal (-p) hc)

-- @paper-step thm:complete_robust/convolution_laplace_product
theorem causal_convolution_laplace {f g : ℝ → ℝ}
    (hf : Integrable f) (hg : Integrable g) (hfc : Causal f) (hgc : Causal g)
    {p : ℝ} (hp : 0 ≤ p) : laplace (f ⋆ g) p = laplace f p*laplace g p := by
  have hc : Causal (f ⋆ g) := ae_of_all volume (convolution_causal hfc hgc)
  rw [← kernel_laplace_full hc p,expWeight_convolution,
    integral_convolution (ContinuousLinearMap.lsmul ℝ ℝ)
      (expWeight_negative_integrable hf hfc hp) (expWeight_negative_integrable hg hgc hp),
    kernel_laplace_full hfc p,kernel_laplace_full hgc p]
  rfl

-- @paper-step thm:complete_robust/lag_kernel_laplace
theorem lagKernel_laplace {σ p : ℝ} (hσ : 0 < σ) (hp : 0 ≤ p) :
    laplace (lagKernel σ) p = 1/(1+σ*p) := by
  have hr : -p-1/σ < 0 := by
    have : 0 < 1/σ := by positivity
    linarith
  have heq : expWeight (-p) (lagKernel σ) =
      (Ioi 0).indicator (fun t => (1/σ)*Real.exp ((-p-1/σ)*t)) := by
    funext t
    by_cases ht : t ∈ Ioi (0 : ℝ)
    · simp only [expWeight,lagKernel,indicator_of_mem ht]
      calc
        _ = (1/σ)*(Real.exp (-p*t)*Real.exp ((-1/σ)*t)) := by ring
        _ = _ := by rw [← Real.exp_add]; congr 2; ring
    · simp [expWeight,lagKernel,ht]
  rw [← kernel_laplace_full (lagKernel_properties hσ).2.2.2 p,heq,
    integral_indicator measurableSet_Ioi,integral_const_mul,integral_exp_mul_Ioi hr]
  simp only [mul_zero,Real.exp_zero]
  have hh : 1+σ*p ≠ 0 := ne_of_gt (by positivity)
  have hr0 := ne_of_lt hr
  rw [show -p-1/σ = -(1+σ*p)/σ by field_simp; ring]
  field_simp [ne_of_gt hσ,hh]
  <;> ring

-- @paper-step thm:complete_robust/unit_lag_identification
theorem unitLagImpulse_eq_lagKernel : unitLagImpulse = lagKernel 1 := by
  simp [unitLagImpulse,lagKernel]

-- @paper-step thm:complete_robust/cascade_transfer_identification
theorem cascadeKernel_laplace (ss : List ℝ) (hs : ∀ σ ∈ ss, 0 < σ)
    {p : ℝ} (hp : 0 ≤ p) :
    laplace (cascadeKernel ss) p = (1/(1+p))*(ss.map (fun σ => 1/(1+σ*p))).prod := by
  induction ss with
  | nil =>
    simp only [cascadeKernel,unitLagImpulse_eq_lagKernel,lagKernel_laplace zero_lt_one hp,
      one_mul,List.map_nil,List.prod_nil,mul_one]
  | cons σ ss ih =>
    have hσ := hs σ (by simp)
    have hss : ∀ σ ∈ ss, 0 < σ := fun r hr => hs r (by simp [hr])
    have hl := lagKernel_properties hσ
    have hk := cascadeKernel_properties ss hss
    rw [cascadeKernel,causal_convolution_laplace hl.1 hk.1 hl.2.2.2 hk.2.2.2 hp,
      lagKernel_laplace hσ hp,ih hss,List.map_cons,List.prod_cons]
    ring

end MIACE
