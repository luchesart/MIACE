import MIACE.TwoRateLaplace
import Mathlib.Analysis.Complex.Trigonometric
import Mathlib.Analysis.SpecialFunctions.Integrals.Basic

/-! Етап 8: комплексен Лапласов интеграл и оценка в затворена полуплоскост.
    Каузалността и положителността са условия за действителното ядро K. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

noncomputable def complexLaplace (f : ℝ → ℝ) (p : ℂ) : ℂ :=
  ∫ t : ℝ, Complex.exp (-p*(t : ℂ))*(f t : ℂ)

-- @paper-step thm:pid_two_rate_optimum/complex_kernel_domination
theorem complex_laplace_domination {K : ℝ → ℝ} (hc : Causal K)
    (hn : ∀ᵐ t, 0 ≤ K t) {η : ℝ} {p : ℂ} (hp : -η ≤ p.re) :
    ∀ᵐ t : ℝ, ‖Complex.exp (-p*(t : ℂ))*(K t : ℂ)‖ ≤ expWeight η K t := by
  filter_upwards [hc,hn] with t hct hnt
  by_cases ht : 0 ≤ t
  · rw [norm_mul,Complex.norm_exp,Complex.norm_real,Real.norm_of_nonneg hnt]
    have he : (-p*(t : ℂ)).re= -p.re*t := by simp
    rw [he]
    exact mul_le_mul_of_nonneg_right (Real.exp_le_exp.mpr (by nlinarith)) hnt
  · rw [hct (lt_of_not_ge ht)]
    simp [expWeight,hct (lt_of_not_ge ht)]

-- @paper-step thm:pid_two_rate_optimum/complex_weighted_kernel_integrability
theorem complex_laplace_integrable {K : ℝ → ℝ} (hK : Integrable K)
    (hc : Causal K) (hn : ∀ᵐ t, 0 ≤ K t) {η : ℝ}
    (hw : Integrable (expWeight η K)) {p : ℂ} (hp : -η ≤ p.re) :
    Integrable (fun t : ℝ => Complex.exp (-p*(t : ℂ))*(K t : ℂ)) := by
  apply hw.mono'
  · exact (by fun_prop : Continuous (fun t : ℝ => Complex.exp (-p*(t : ℂ)))).aestronglyMeasurable.mul
      (Complex.continuous_ofReal.comp_aestronglyMeasurable hK.aestronglyMeasurable)
  · exact complex_laplace_domination hc hn hp

-- @paper-step thm:pid_two_rate_optimum/complex_kernel_norm_bound
theorem complex_laplace_norm_le {K : ℝ → ℝ} (hc : Causal K)
    (hn : ∀ᵐ t, 0 ≤ K t) {η : ℝ} (hw : Integrable (expWeight η K))
    {p : ℂ} (hp : -η ≤ p.re) :
    ‖complexLaplace K p‖ ≤ ∫ t, expWeight η K t :=
  norm_integral_le_of_norm_le hw (complex_laplace_domination hc hn hp)

-- @paper-step thm:pid_two_rate_optimum/complex_resolvent_nonvanishing
theorem complex_resolvent_ne_zero {K : ℝ → ℝ} (hc : Causal K)
    (hn : ∀ᵐ t, 0 ≤ K t) {η : ℝ} (hw : Integrable (expWeight η K))
    (hq : (∫ t, expWeight η K t)<1) {p : ℂ} (hp : -η ≤ p.re) :
    1-complexLaplace K p ≠ 0 := by
  have hb := (complex_laplace_norm_le hc hn hw hp).trans_lt hq
  intro hz
  have he : complexLaplace K p=1 := (sub_eq_zero.mp hz).symm
  rw [he,norm_one] at hb
  exact (lt_irrefl 1) hb

-- @paper-step thm:pid_two_rate_optimum/finite_complex_exponential_integral
theorem finite_complex_exp_integral {r : ℂ} (hr : r ≠ 0) (δ : ℝ) :
    (∫ t : ℝ in 0..δ, Complex.exp (-r*(t : ℂ)))=(1-Complex.exp (-r*(δ : ℂ)))/r := by
  rw [integral_exp_mul_complex (neg_ne_zero.mpr hr)]
  simp only [Complex.ofReal_zero,mul_zero,Complex.exp_zero]
  field_simp
  <;> ring

-- @paper-step thm:pid_two_rate_optimum/actual_complex_compact_kernel_transform
theorem twoRateK_complex_laplace (A l m : ℝ) {δ : ℝ} (hδ : 0 ≤ δ)
    {p : ℂ} (hlp : p+(l : ℂ) ≠ 0) (hmp : p+(m : ℂ) ≠ 0) :
    complexLaplace (twoRateK A l m δ) p=
      (l : ℂ)*A*(1-Complex.exp (-(p+l)*δ))/(p+l)+
      (m : ℂ)*(1-A)*(1-Complex.exp (-(p+m)*δ))/(p+m) := by
  have he : (fun t : ℝ => Complex.exp (-p*(t : ℂ))*(twoRateK A l m δ t : ℂ))=
      (Ico (0 : ℝ) δ).indicator (fun t =>
        (l : ℂ)*A*Complex.exp (-(p+l)*t)+(m : ℂ)*(1-A)*Complex.exp (-(p+m)*t)) := by
    funext t
    by_cases ht : t ∈ Ico (0 : ℝ) δ
    · simp only [twoRateK,indicator_of_mem ht,twoRateD]
      push_cast
      have h₁ : Complex.exp (-p*(t : ℂ))*Complex.exp (-(l : ℂ)*t)=Complex.exp (-(p+l)*t) := by
        rw [← Complex.exp_add]; congr 1; ring
      have h₂ : Complex.exp (-p*(t : ℂ))*Complex.exp (-(m : ℂ)*t)=Complex.exp (-(p+m)*t) := by
        rw [← Complex.exp_add]; congr 1; ring
      calc
        _ = (l : ℂ)*A*(Complex.exp (-p*(t : ℂ))*Complex.exp (-(l : ℂ)*t))+
          (m : ℂ)*(1-A)*(Complex.exp (-p*(t : ℂ))*Complex.exp (-(m : ℂ)*t)) := by ring
        _ = _ := by rw [h₁,h₂]
    · simp [twoRateK,ht]
  unfold complexLaplace
  rw [he,integral_indicator measurableSet_Ico,integral_Ico_eq_integral_Ioc,
    ← intervalIntegral.integral_of_le hδ]
  rw [intervalIntegral.integral_add (by apply Continuous.intervalIntegrable; fun_prop)
      (by apply Continuous.intervalIntegrable; fun_prop),
    intervalIntegral.integral_const_mul,intervalIntegral.integral_const_mul,
    finite_complex_exp_integral hlp,finite_complex_exp_integral hmp]
  ring

end MIACE
