import MIACE.Quadratic
import MIACE.Dynamics

/-! The integral/Gramian bridge for actual canonical impulse states.
Settling of the canonical ODE is explicit; square integrability is a conclusion.
Stability.lean, AnalyticBridge.lean and GramianProof.lean now discharge the
positive-coefficient settling, realization and original Gramian proof bridges. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

structure SecondOrderImpulse (a b c : ℝ) (z w : ℝ → ℝ) : Prop where
  ac_z : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval z 0 T
  ac_w : ∀ T : ℝ, 0 ≤ T → AbsolutelyContinuousOnInterval w 0 T
  ode_z : ∀ᵐ t : ℝ, 0 < t → deriv z t = w t
  ode_w : ∀ᵐ t : ℝ, 0 < t → deriv w t = -(c/a)*z t-(b/a)*w t
  initial_z : z 0 = 0
  initial_w : w 0 = 1/a
  final_z : Tendsto z atTop (𝓝 0)
  final_w : Tendsto w atTop (𝓝 0)

noncomputable def energyPotential (a b c d e z w : ℝ) : ℝ :=
  (b*e^2/(2*c)+(a*e^2+c*d^2)/(2*b)-e*d)*z^2 +
  (a*e^2/c)*z*w + (a*(a*e^2+c*d^2)/(2*b*c))*w^2

-- @paper-step lem:h2/observability_lyapunov_identity
theorem energy_potential_identity (a b c d e z w : ℝ)
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) :
    (b*e^2/(2*c)+(a*e^2+c*d^2)/(2*b)-e*d)*(2*z*w) +
      (a*e^2/c)*(w*w+z*(-(c/a)*z-(b/a)*w)) +
      (a*(a*e^2+c*d^2)/(2*b*c))*(2*w*(-(c/a)*z-(b/a)*w)) = -(e*z+d*w)^2 := by
  field_simp
  <;> ring

-- @paper-step lem:h2/general_finite_energy_identity
theorem state_finite_energy {a b c : ℝ} {z w : ℝ → ℝ}
    (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) (d e T : ℝ) (hT : 0 ≤ T)
    (hzac : AbsolutelyContinuousOnInterval z 0 T)
    (hwac : AbsolutelyContinuousOnInterval w 0 T)
    (hzode : ∀ᵐ t : ℝ, 0 < t → deriv z t = w t)
    (hwode : ∀ᵐ t : ℝ, 0 < t → deriv w t = -(c/a)*z t-(b/a)*w t) :
    (∫ t in 0..T, (e*z t+d*w t)^2) =
      energyPotential a b c d e (z 0) (w 0)-energyPotential a b c d e (z T) (w T) := by
  have hz := hzac
  have hw := hwac
  have hp : AbsolutelyContinuousOnInterval
      (fun t => energyPotential a b c d e (z t) (w t)) 0 T := by
    unfold energyPotential
    convert (((hz.mul hz).const_mul (b*e^2/(2*c)+(a*e^2+c*d^2)/(2*b)-e*d)).add
      ((hz.const_mul (a*e^2/c)).mul hw)).add
      ((hw.mul hw).const_mul (a*(a*e^2+c*d^2)/(2*b*c))) using 1 <;>
      simp only [pow_two,Pi.add_def,Pi.mul_def]
  have hi := hp.integral_deriv_eq_sub
  have heq : (∫ t in 0..T, deriv (fun s => energyPotential a b c d e (z s) (w s)) t) =
      -(∫ t in 0..T, (e*z t+d*w t)^2) := by
    rw [← intervalIntegral.integral_neg]
    apply intervalIntegral.integral_congr_ae
    filter_upwards [hz.ae_differentiableAt,hw.ae_differentiableAt,hzode,hwode]
      with t hzt hwt hzode hwode ht
    have hmem : t ∈ uIcc 0 T := uIoc_subset_uIcc ht
    rw [uIoc_of_le hT] at ht
    have hdz := (hzt hmem).hasDerivAt
    have hdw := (hwt hmem).hasDerivAt
    rw [hzode ht.1] at hdz
    rw [hwode ht.1] at hdw
    have hd := (((hdz.pow 2).const_mul (b*e^2/(2*c)+(a*e^2+c*d^2)/(2*b)-e*d)).add
      ((hdz.const_mul (a*e^2/c)).mul hdw)).add
      ((hdw.pow 2).const_mul (a*(a*e^2+c*d^2)/(2*b*c)))
    change deriv (fun s => energyPotential a b c d e (z s) (w s)) t = _
    rw [show deriv (fun s => energyPotential a b c d e (z s) (w s)) t = _ from hd.deriv]
    convert energy_potential_identity a b c d e (z t) (w t) ha hb hc using 1 <;> ring
  rw [heq] at hi
  linarith

-- @paper-step lem:h2/finite_energy_identity
theorem impulse_finite_energy {a b c : ℝ} {z w : ℝ → ℝ}
    (h : SecondOrderImpulse a b c z w) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (d e T : ℝ) (hT : 0 ≤ T) :
    (∫ t in 0..T, (e*z t+d*w t)^2) =
      (a*e^2+c*d^2)/(2*a*b*c)-energyPotential a b c d e (z T) (w T) := by
  have hz := h.ac_z T hT
  have hw := h.ac_w T hT
  have hp : AbsolutelyContinuousOnInterval
      (fun t => energyPotential a b c d e (z t) (w t)) 0 T := by
    unfold energyPotential
    convert (((hz.mul hz).const_mul (b*e^2/(2*c)+(a*e^2+c*d^2)/(2*b)-e*d)).add
      ((hz.const_mul (a*e^2/c)).mul hw)).add
      ((hw.mul hw).const_mul (a*(a*e^2+c*d^2)/(2*b*c))) using 1 <;>
      simp only [pow_two,Pi.add_def,Pi.mul_def]
  have hi := hp.integral_deriv_eq_sub
  have heq : (∫ t in 0..T, deriv (fun s => energyPotential a b c d e (z s) (w s)) t) =
      -(∫ t in 0..T, (e*z t+d*w t)^2) := by
    rw [← intervalIntegral.integral_neg]
    apply intervalIntegral.integral_congr_ae
    filter_upwards [hz.ae_differentiableAt,hw.ae_differentiableAt,h.ode_z,h.ode_w]
      with t hzt hwt hzode hwode ht
    have hmem : t ∈ uIcc 0 T := uIoc_subset_uIcc ht
    rw [uIoc_of_le hT] at ht
    have hdz := (hzt hmem).hasDerivAt
    have hdw := (hwt hmem).hasDerivAt
    rw [hzode ht.1] at hdz
    rw [hwode ht.1] at hdw
    have hd := (((hdz.pow 2).const_mul (b*e^2/(2*c)+(a*e^2+c*d^2)/(2*b)-e*d)).add
      ((hdz.const_mul (a*e^2/c)).mul hdw)).add
      ((hdw.pow 2).const_mul (a*(a*e^2+c*d^2)/(2*b*c)))
    change deriv (fun s => energyPotential a b c d e (z s) (w s)) t = _
    rw [show deriv (fun s => energyPotential a b c d e (z s) (w s)) t = _ from hd.deriv]
    convert energy_potential_identity a b c d e (z t) (w t) ha hb hc using 1 <;> ring
  rw [heq,h.initial_z,h.initial_w] at hi
  have hinit : energyPotential a b c d e 0 (1/a) = (a*e^2+c*d^2)/(2*a*b*c) := by
    unfold energyPotential
    field_simp
    <;> ring
  rw [hinit] at hi
  linarith

-- @paper-step lem:h2/potential_decay
theorem impulse_potential_decay {a b c : ℝ} {z w : ℝ → ℝ}
    (h : SecondOrderImpulse a b c z w) (d e : ℝ) :
    Tendsto (fun t => energyPotential a b c d e (z t) (w t)) atTop (𝓝 0) := by
  unfold energyPotential
  convert (((h.final_z.pow 2).const_mul _).add
    ((h.final_z.const_mul _).mul h.final_w)).add ((h.final_w.pow 2).const_mul _) using 1 <;> simp

-- Square integrability is derived from the exact finite integral and settling.
-- @paper-step lem:h2/actual_integral_energy
theorem impulse_energy {a b c : ℝ} {z w : ℝ → ℝ}
    (h : SecondOrderImpulse a b c z w) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c)
    (d e : ℝ) :
    Integrable (fun t => (e*z t+d*w t)^2) halfLine ∧
    (∫ t, (e*z t+d*w t)^2 ∂halfLine) = (a*e^2+c*d^2)/(2*a*b*c) := by
  have hi : ∀ n : ℕ, IntervalIntegrable (fun t => (e*z t+d*w t)^2) volume 0 n := by
    intro n
    exact (((h.ac_z n (by positivity)).continuousOn.const_mul e).add
      ((h.ac_w n (by positivity)).continuousOn.const_mul d)).pow 2 |>.intervalIntegrable
  have hl : Tendsto (fun n : ℕ => ∫ t in 0..(n : ℝ), (e*z t+d*w t)^2) atTop
      (𝓝 ((a*e^2+c*d^2)/(2*a*b*c))) := by
    have hh := (tendsto_const_nhds (x := (a*e^2+c*d^2)/(2*a*b*c))).sub ((impulse_potential_decay h d e).comp tendsto_natCast_atTop_atTop)
    simp only [sub_zero] at hh
    apply hh.congr'
    exact Eventually.of_forall (fun n => (impulse_finite_energy h ha hb hc d e n (by positivity)).symm)
  have hnorm : Tendsto (fun n : ℕ => ∫ t in 0..(n : ℝ), ‖(e*z t+d*w t)^2‖) atTop
      (𝓝 ((a*e^2+c*d^2)/(2*a*b*c))) := by
    simpa only [Real.norm_eq_abs,abs_sq] using hl
  have hint : Integrable (fun t => (e*z t+d*w t)^2) halfLine :=
    integrableOn_Ioi_of_intervalIntegral_norm_tendsto _ 0 (fun n => (hi n).1) tendsto_natCast_atTop_atTop hnorm
  exact ⟨hint,tendsto_nhds_unique (intervalIntegral_tendsto_integral_Ioi 0 hint
    tendsto_natCast_atTop_atTop) hl⟩

-- The actual controllability-Gramian entries follow by choosing output rows.
-- @paper-step lem:h2/actual_gramian_diagonal
theorem impulse_gramian_diagonal {a b c : ℝ} {z w : ℝ → ℝ}
    (h : SecondOrderImpulse a b c z w) (ha : 0 < a) (hb : 0 < b) (hc : 0 < c) :
    (∫ t, (z t)^2 ∂halfLine) = 1/(2*b*c) ∧
    (∫ t, (w t)^2 ∂halfLine) = 1/(2*a*b) := by
  have hz := (impulse_energy h ha hb hc 0 1).2
  have hw := (impulse_energy h ha hb hc 1 0).2
  simp only [one_mul,zero_mul,mul_zero,add_zero,zero_add,one_pow,zero_pow (by decide : 2 ≠ 0)] at hz hw
  constructor
  · rw [hz]; field_simp
  · rw [hw]; field_simp

-- @paper-step prop:energies/actual_signal_integrals
theorem pi_signal_energies {x r : ℝ} {z w : ℝ → ℝ}
    (hx : 0 < x) (hr : 0 < r) (h : SecondOrderImpulse r (r*(1+x)) x z w) :
    (Integrable (fun t => (r*z t+r*w t)^2) halfLine ∧
      (∫ t, (r*z t+r*w t)^2 ∂halfLine) = tracking x r) ∧
    (Integrable (fun t => ((x-r)*z t+(r*(x-1))*w t)^2) halfLine ∧
      (∫ t, ((x-r)*z t+(r*(x-1))*w t)^2 ∂halfLine) = effort x r) := by
  have hb : 0 < r*(1+x) := by positivity
  have he := impulse_energy h hr hb hx r r
  have hu := impulse_energy h hr hb hx (r*(x-1)) (x-r)
  rw [energy_tracking_substitution x r hx hr] at he
  rw [energy_effort_substitution x r hx hr] at hu
  exact ⟨he,hu⟩
end MIACE
