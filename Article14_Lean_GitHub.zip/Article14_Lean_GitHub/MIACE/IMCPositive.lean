import MIACE.IMCStepMismatch

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:complete_robust/exponential_filter_slowest_lag_cancellation
theorem exponentialIMC_unitLag {a : ℝ} (ha : 0<a) :
    filterAction (exponentialIMC a ha) (lagKernel 1)=ᵐ[volume] lagKernel a := by
  have h1 := lagKernel_properties (by norm_num : (0 : ℝ)<1)
  have haK := lagKernel_properties ha
  apply causal_laplace_ext (filterAction_integrable _ h1.1) haK.1
    (filterAction_causal _ h1.2.2.2) haK.2.2.2
  intro p hp
  rw [filterAction_laplace _ h1.1 h1.2.2.2 hp.le,exponentialIMC_transfer ha hp.le,
    lagKernel_laplace (by norm_num) hp.le,lagKernel_laplace ha hp.le]
  have hden : 1+p≠0 := by linarith
  have haden : 1+a*p≠0 := by positivity
  field_simp

-- @paper-step thm:complete_robust/pulse_filtered_slowest_lag_positive
theorem pulseIMC_unitLag_nonnegative {c T : ℝ} (hc : 0≤c) (hT : 0≤T)
    (hJ : c*(Real.exp T-1)≤1) :
    ∀ t, 0≤filterAction (pulseIMC c T hT) (lagKernel 1) t := by
  intro t
  simp only [filterAction,pulseIMC,zero_mul,add_zero]
  by_cases ht : 0<t
  · by_cases htT : 0<t-T
    · have he : Real.exp (-(t-T))=Real.exp (-t)*Real.exp T := by
        rw [← Real.exp_add]; congr 1; ring
      simp only [lagKernel,shift,one_div_one,neg_div,div_one,
        indicator_of_mem (show t∈Ioi (0 : ℝ) from ht),
        indicator_of_mem (show t-T∈Ioi (0 : ℝ) from htT),one_mul,neg_one_mul]
      rw [he]
      have hp := mul_nonneg (show 0≤1+c-c*Real.exp T by nlinarith) (Real.exp_nonneg (-t))
      nlinarith
    · have hz : lagKernel 1 (t-T)=0 := by simp [lagKernel,htT]
      have hk := (lagKernel_properties (by norm_num : (0 : ℝ)<1)).2.1 t
      change 0≤(1+c)*lagKernel 1 t+(-c)*lagKernel 1 (t-T)
      rw [hz,mul_zero,add_zero]
      exact mul_nonneg (by linarith) hk
  · have htT : ¬0<t-T := by linarith
    simp [lagKernel,shift,ht,htT]

-- @paper-step thm:complete_robust/filter_unit_DC_preserves_mass
theorem filterAction_unit_mass (F : IMCFilter) {K : ℝ → ℝ}
    (hK : Integrable K) (hKc : Causal K) (hm : (∫ t, K t)=1) (hF : filterTransfer F 0=1) :
    (∫ t, filterAction F K t)=1 := by
  have hh := filterAction_laplace F hK hKc (le_rfl : (0 : ℝ)≤0)
  simp only [laplace,neg_zero,zero_mul,Real.exp_zero,one_mul,hF] at hh
  rw [← causal_integral_halfLine (filterAction_causal F hKc),← causal_integral_halfLine hKc] at hh
  exact hh.trans hm

-- @paper-step thm:complete_robust/nominal_positive_cascade_filter_induction
theorem filtered_cascade_nonnegative (F : IMCFilter) (ss : List ℝ)
    (hs : ∀ σ∈ss, 0<σ) (hbase : ∀ᵐ t, 0≤filterAction F (lagKernel 1) t) :
    ∀ᵐ t, 0≤filterAction F (cascadeKernel ss) t := by
  induction ss with
  | nil => simpa only [cascadeKernel,unitLagImpulse_eq_lagKernel] using hbase
  | cons σ ss ih =>
    have hσ := hs σ (by simp)
    have hss : ∀ τ∈ss, 0<τ := fun τ hτ => hs τ (by simp [hτ])
    have hp := cascadeKernel_properties ss hss
    have hF := filterAction_integrable F hp.1
    have he := local_filter_commute F (lagKernel_properties hσ).1
      (lagKernel_properties hσ).2.2.2 hp.1.locallyIntegrable hp.2.2.2
    have hn := ih hss
    filter_upwards [he] with t ht
    change 0≤filterAction F (lagKernel σ ⋆ cascadeKernel ss) t
    rw [ht]
    apply integral_nonneg_of_ae
    have hshift := (quasiMeasurePreserving_sub_left_of_right_invariant (volume : Measure ℝ) t).tendsto_ae.eventually hn
    filter_upwards [hshift] with s hs
    exact mul_nonneg ((lagKernel_properties hσ).2.1 s) hs

-- @paper-step thm:complete_robust/nominal_delay_preserves_positive_filtered_kernel
theorem filtered_delayed_kernel (F : IMCFilter) (ss : List ℝ)
    (hs : ∀ σ∈ss, 0<σ) {δ : ℝ} (hδ : 0≤δ)
    (hbase : ∀ᵐ t, 0≤filterAction F (lagKernel 1) t) (hF : filterTransfer F 0=1) :
    Integrable (filterAction F (shift δ (cascadeKernel ss))) ∧
      Causal (filterAction F (shift δ (cascadeKernel ss))) ∧
      (∀ᵐ t, 0≤filterAction F (shift δ (cascadeKernel ss)) t) ∧
      absArea (filterAction F (shift δ (cascadeKernel ss))) volume=1 := by
  have hp := cascadeKernel_properties ss hs
  have hPi := shift_integrable δ hp.1
  have hPc := causal_shift hp.2.2.2 hδ
  have he : filterAction F (shift δ (cascadeKernel ss))=ᵐ[volume]
      shift δ (filterAction F (cascadeKernel ss)) := by
    apply causal_laplace_ext (filterAction_integrable F hPi)
      (shift_integrable δ (filterAction_integrable F hp.1))
      (filterAction_causal F hPc) (causal_shift (filterAction_causal F hp.2.2.2) hδ)
    intro p hpp
    rw [filterAction_laplace F hPi hPc hpp.le,laplace_shift hp.2.2.2 hδ p,
      laplace_shift (filterAction_causal F hp.2.2.2) hδ p,
      filterAction_laplace F hp.1 hp.2.2.2 hpp.le]
    ring
  have hn0 := filtered_cascade_nonnegative F ss hs hbase
  have hn1 := (measurePreserving_sub_right (volume : Measure ℝ) δ).quasiMeasurePreserving.tendsto_ae.eventually hn0
  have hn : ∀ᵐ t, 0≤filterAction F (shift δ (cascadeKernel ss)) t := by
    filter_upwards [he,hn1] with t ht hs
    rw [ht]; exact hs
  have hm : (∫ t, shift δ (cascadeKernel ss) t)=1 := by
    unfold shift
    rw [integral_sub_right_eq_self,hp.2.2.1]
  exact ⟨filterAction_integrable F hPi,filterAction_causal F hPc,hn,
    (positive_kernel_mass hn).trans (filterAction_unit_mass F hPi hPc hm hF)⟩

end MIACE
