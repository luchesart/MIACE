import MIACE.DelayNorm
import MIACE.CausalConvolution

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution
noncomputable def lagKernel (σ : ℝ) : ℝ → ℝ :=
  (Ioi 0).indicator (fun t => (1/σ)*Real.exp ((-1/σ)*t))
noncomputable def cascadeKernel : List ℝ → ℝ → ℝ
  | [] => unitLagImpulse
  | σ :: ss => lagKernel σ ⋆ cascadeKernel ss

-- @paper-step thm:complete_robust/lag_kernel_integral
theorem lagKernel_properties {σ : ℝ} (hσ : 0 < σ) :
    Integrable (lagKernel σ) ∧ (∀ t, 0 ≤ lagKernel σ t) ∧
      (∫ t, lagKernel σ t)=1 ∧ Causal (lagKernel σ) := by
  have hr : -1/σ < 0 := div_neg_of_neg_of_pos (by norm_num) hσ
  have hi : IntegrableOn (fun t => (1/σ)*Real.exp ((-1/σ)*t)) (Ioi 0) :=
    (integrableOn_exp_mul_Ioi hr 0).const_mul (1/σ)
  refine ⟨hi.integrable_indicator measurableSet_Ioi,?_,?_,?_⟩
  · intro t
    by_cases ht : t ∈ Ioi (0 : ℝ)
    · simp only [lagKernel,indicator_of_mem ht]
      positivity
    · simp [lagKernel,ht]
  · rw [lagKernel,integral_indicator measurableSet_Ioi,integral_const_mul,
      integral_exp_mul_Ioi hr]
    simp [ne_of_gt hσ]
  · apply ae_of_all
    intro t ht
    simp [lagKernel,show ¬ 0 < t by linarith]

-- @paper-step thm:complete_robust/cascade_impulse_properties
theorem cascadeKernel_properties (ss : List ℝ) (hs : ∀ σ ∈ ss, 0 < σ) :
    Integrable (cascadeKernel ss) ∧ (∀ t, 0 ≤ cascadeKernel ss t) ∧
      (∫ t, cascadeKernel ss t)=1 ∧ Causal (cascadeKernel ss) := by
  induction ss with
  | nil =>
    refine ⟨unitLagImpulse_integrable,unitLagImpulse_nonneg,unitLagImpulse_mass,?_⟩
    apply ae_of_all
    intro t ht
    simp [cascadeKernel,unitLagImpulse,show ¬ 0 < t by linarith]
  | cons σ ss ih =>
    have hp := lagKernel_properties (hs σ (by simp))
    have hprev := ih (fun r hr => hs r (by simp [hr]))
    refine ⟨hp.1.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hprev.1,?_,?_,?_⟩
    · intro t
      apply integral_nonneg
      intro s
      exact mul_nonneg (hp.2.1 s) (hprev.2.1 (t-s))
    · rw [cascadeKernel,integral_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hp.1 hprev.1,
        hp.2.2.1,hprev.2.2.1]
      norm_num
    · exact ae_of_all volume (convolution_causal hp.2.2.2 hprev.2.2.2)

-- @paper-step thm:complete_robust/cascade_delay_distance
theorem cascadeKernel_delay_distance (ss : List ℝ) (hs : ∀ σ ∈ ss, 0 < σ)
    {d : ℝ} (hd : 0 ≤ d) :
    absArea (fun t => cascadeKernel ss t-shift d (cascadeKernel ss) t) volume ≤
      2*(1-Real.exp (-d)) := by
  induction ss with
  | nil => exact (unitLagImpulse_delay_distance hd).le
  | cons σ ss ih =>
    have hp := lagKernel_properties (hs σ (by simp))
    have hss : ∀ σ ∈ ss, 0 < σ := fun r hr => hs r (by simp [hr])
    have hprev := cascadeKernel_properties ss hss
    have he := convolution_delay_difference hp.1 hprev.1 d
    have heq : absArea (fun t => cascadeKernel (σ::ss) t-shift d (cascadeKernel (σ::ss)) t) volume =
        absArea (lagKernel σ ⋆ (fun t => cascadeKernel ss t-shift d (cascadeKernel ss) t)) volume :=
      integral_congr_ae (he.fun_comp abs)
    rw [heq]
    have hh := convolution_absArea hp.1 (hprev.1.sub (shift_integrable d hprev.1))
    rw [positive_kernel_mass (ae_of_all volume hp.2.1),hp.2.2.1,one_mul] at hh
    exact hh.trans (ih hss)

-- @paper-step thm:complete_robust/two_delay_distance
theorem two_shift_distance (a b : ℝ) (f : ℝ → ℝ) :
    absArea (fun t => shift a f t-shift b f t) volume =
      absArea (fun t => f t-shift |b-a| f t) volume := by
  have hordered : ∀ a b : ℝ, a ≤ b →
      absArea (fun t => shift a f t-shift b f t) volume =
        absArea (fun t => f t-shift (b-a) f t) volume := by
    intro a b _
    have heq : (fun t => shift a f t-shift b f t) =
        shift a (fun t => f t-shift (b-a) f t) := by
      funext t
      simp only [shift]
      congr 2
      ring
    rw [heq,shift_absArea]
  rcases le_total a b with h | h
  · rw [abs_of_nonneg (sub_nonneg.mpr h)]
    exact hordered a b h
  · have hsym : absArea (fun t => shift a f t-shift b f t) volume =
        absArea (fun t => shift b f t-shift a f t) volume := by
      unfold absArea
      simp_rw [abs_sub_comm]
    rw [hsym,hordered b a h,abs_of_nonpos (sub_nonpos.mpr h),neg_sub]

-- @paper-step thm:complete_robust/cascade_delay_error_norm
theorem cascade_delay_error_norm (ss : List ℝ) (hs : ∀ σ ∈ ss, 0 < σ)
    (δ ε : ℝ) :
    absArea (fun t => shift (δ+ε) (cascadeKernel ss) t-shift δ (cascadeKernel ss) t) volume ≤
      2*(1-Real.exp (-|ε|)) := by
  rw [two_shift_distance]
  have hid : |δ-(δ+ε)| = |ε| := by rw [show δ-(δ+ε) = -ε by ring,abs_neg]
  rw [hid]
  exact cascadeKernel_delay_distance ss hs (abs_nonneg ε)

-- @paper-step thm:complete_robust/two_delay_step_distance
theorem two_delay_step_distance {h : ℝ → ℝ} (hh : Integrable h)
    (hn : ∀ᵐ t, 0 ≤ h t) (hm : (∫ t, h t) = 1) (a b : ℝ) :
    absArea (fun t => ∫ s in t-b..t-a, h s) volume = |b-a| := by
  have hh' : ∀ a b : ℝ, a ≤ b →
      absArea (fun t => ∫ s in t-b..t-a, h s) volume = b-a := by
    intro a b hab
    have heq : (fun t => ∫ s in t-b..t-a, h s) =
        shift a (fun t => ∫ s in t-(b-a)..t, h s) := by
      funext t
      unfold shift
      congr 1
      ring
    rw [heq,shift_absArea,step_delay_norm hh hn hm (sub_nonneg.mpr hab)]
  rcases le_total a b with hab | hba
  · rw [hh' a b hab,abs_of_nonneg (sub_nonneg.mpr hab)]
  · have heq : absArea (fun t => ∫ s in t-b..t-a, h s) volume =
        absArea (fun t => ∫ s in t-a..t-b, h s) volume := by
      unfold absArea
      congr 1
      funext t
      dsimp only
      rw [intervalIntegral.integral_symm,abs_neg]
    rw [heq,hh' b a hba,abs_of_nonpos (sub_nonpos.mpr hba),neg_sub]

-- @paper-step thm:complete_robust/cascade_step_error_norm
theorem cascade_step_error_norm (ss : List ℝ) (hs : ∀ σ ∈ ss, 0 < σ)
    (δ ε : ℝ) :
    absArea (fun t => ∫ s in t-(δ+ε)..t-δ, cascadeKernel ss s) volume = |ε| := by
  have hp := cascadeKernel_properties ss hs
  have hh := two_delay_step_distance hp.1 (ae_of_all volume hp.2.1) hp.2.2.1 δ (δ+ε)
  simpa only [add_sub_cancel_left] using hh

end MIACE
