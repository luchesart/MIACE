import MIACE.CascadeCertificates

/-! Stage 19. Uniform estimates follow from the actual recursive impulse.
The pointwise bounds below avoid any unproved asymptotic or numerical oracle. -/
namespace MIACE
open MeasureTheory Filter Set Polynomial
open scoped Topology

-- @paper-step thm:n_all_orders/exact_polynomial_primitive
theorem integral_nat_pow (n : ℕ) (t : ℝ) :
    (∫ s in 0..t, s^n)=t^(n+1)/(n+1) := by
  have hn : (n : ℝ)+1≠0 := by positivity
  have hd (s : ℝ) : HasDerivAt (fun u : ℝ => u^(n+1)/((n : ℝ)+1)) (s^n) s := by
    convert ((hasDerivAt_id s).pow (n+1)).div_const ((n : ℝ)+1) using 1
    · rfl
    · simp only [id_eq,Nat.add_sub_cancel,Nat.cast_add,Nat.cast_one,mul_one]
      field_simp
  have he := intervalIntegral.integral_eq_sub_of_hasDerivAt (fun s _ => hd s)
    ((continuous_id.pow n).intervalIntegrable (μ := volume) 0 t)
  simpa using he

-- @paper-step thm:n_all_orders/equal_lag_impulse_exact_formula
theorem equal_reverseImpulse (n : ℕ) (t : ℝ) :
    reverseImpulse (fun _ => 1) n t=Real.exp t*t^n/(n.factorial : ℝ) := by
  induction n generalizing t with
  | zero => simp [reverseImpulse]
  | succ n ih =>
    simp only [reverseImpulse,one_mul]
    have hi : (∫ s in 0..t, Real.exp (-1*s)*reverseImpulse (fun _ => 1) n s)=
        (∫ s in 0..t, s^n)/(n.factorial : ℝ) := by
      simp only [div_eq_mul_inv]
      rw [← intervalIntegral.integral_mul_const]
      apply intervalIntegral.integral_congr
      intro s _
      dsimp only
      rw [ih s]
      have he : Real.exp (-1*s)*Real.exp s=1 := by rw [← Real.exp_add]; ring_nf; simp
      calc
        Real.exp (-1*s)*(Real.exp s*s^n/(n.factorial : ℝ))=
            (Real.exp (-1*s)*Real.exp s)*s^n/(n.factorial : ℝ) := by ring
        _ = _ := by rw [he,one_mul]; rfl
    rw [hi,integral_nat_pow,Nat.factorial_succ]
    push_cast
    field_simp
    <;> ring

-- @paper-step thm:n_all_orders/explicit_equal_lag_compact_kernel
theorem equal_remainderJ (n : ℕ) (δ t : ℝ) :
    remainderJ (fun _ => 1) n δ t=Real.exp (δ-t)*(δ-t)^n/(n.factorial : ℝ) :=
  equal_reverseImpulse n (δ-t)

-- @paper-step thm:n_all_orders/exponential_bounds_by_exact_taylor_remainders
theorem uniform_exp_bounds : Real.exp (1/4 : ℝ)<4/3 ∧ Real.exp 1<3 := by
  have h := Real.exp_bound (x := 1/4) (by norm_num) (n := 3) (by norm_num)
  have h1 := Real.exp_bound (x := 1) (by norm_num) (n := 4) (by norm_num)
  norm_num [Finset.sum_range_succ,Nat.factorial] at h h1
  constructor <;> linarith [(abs_le.mp h).2,(abs_le.mp h1).2]

-- @paper-step thm:n_all_orders/kernel_uniform_pointwise_bound
theorem equal_kernel_bound (n : ℕ) {δ t : ℝ} (hδ : 0≤δ) (hδ1 : δ≤1/4)
    (ht : t∈Icc (0 : ℝ) δ) :
    0≤remainderJ (fun _ => 1) n δ t ∧
    remainderJ (fun _ => 1) n δ t≤Real.exp δ := by
  have hu : 0≤δ-t := sub_nonneg.mpr ht.2
  have hu1 : δ-t≤1 := by linarith [ht.1]
  have hf : (1 : ℝ)≤(n.factorial : ℝ) := by exact_mod_cast Nat.factorial_pos n
  rw [equal_remainderJ]
  refine ⟨by positivity,?_⟩
  apply (div_le_iff₀ (by positivity : (0 : ℝ)<(n.factorial : ℝ))).mpr
  have he : Real.exp (δ-t)≤Real.exp δ := Real.exp_le_exp.mpr (by linarith [ht.1])
  have hp := pow_le_one₀ (n := n) hu hu1
  calc
    Real.exp (δ-t)*(δ-t)^n≤Real.exp δ*1 := mul_le_mul he hp (pow_nonneg hu _) (Real.exp_nonneg _)
    _ ≤ Real.exp δ*(n.factorial : ℝ) := mul_le_mul_of_nonneg_left hf (Real.exp_nonneg _)

-- @paper-step thm:n_all_orders/improved_kernel_bound_above_order_two
theorem equal_kernel_linear_bound {n : ℕ} (hn : 1≤n) {δ t : ℝ}
    (hδ : 0≤δ) (hδ1 : δ≤1/4) (ht : t∈Icc (0 : ℝ) δ) :
    remainderJ (fun _ => 1) n δ t≤Real.exp δ*(δ-t) := by
  obtain ⟨m,rfl⟩ := Nat.exists_eq_add_of_le hn
  have hu : 0≤δ-t := sub_nonneg.mpr ht.2
  have hu1 : δ-t≤1 := by linarith [ht.1]
  have hf : (1 : ℝ)≤((1+m).factorial : ℝ) := by exact_mod_cast Nat.factorial_pos (1+m)
  rw [equal_remainderJ]
  apply (div_le_iff₀ (by positivity : (0 : ℝ)<((1+m).factorial : ℝ))).mpr
  have hp : (δ-t)^(1+m)≤δ-t := by
    rw [pow_add,pow_one]
    simpa using mul_le_mul_of_nonneg_left (pow_le_one₀ (n := m) hu hu1) hu
  have he : Real.exp (δ-t)≤Real.exp δ := Real.exp_le_exp.mpr (by linarith [ht.1])
  calc
    Real.exp (δ-t)*(δ-t)^(1+m)≤Real.exp δ*(δ-t) :=
      mul_le_mul he hp (pow_nonneg hu _) (Real.exp_nonneg _)
    _ ≤ Real.exp δ*(δ-t)*((1+m).factorial : ℝ) :=
      le_mul_of_one_le_right (mul_nonneg (Real.exp_nonneg _) hu) hf

-- @paper-step thm:n_all_orders/uniform_zero_and_first_moment_bounds
theorem equal_uniform_moments (n : ℕ) {δ : ℝ} (hδ : 0≤δ) (hδ1 : δ≤1/4) :
    0≤compactMoment (remainderJ (fun _ => 1) n δ) δ 0 ∧
    compactMoment (remainderJ (fun _ => 1) n δ) δ 0≤1/3 ∧
    0≤compactMoment (remainderJ (fun _ => 1) n δ) δ 1 ∧
    compactMoment (remainderJ (fun _ => 1) n δ) δ 1≤1/24 := by
  let J := remainderJ (fun _ => 1) n δ
  have hJ : Continuous J := remainderJ_continuous _ n δ
  have hbound {t : ℝ} (ht : t∈Icc (0 : ℝ) δ) := equal_kernel_bound n hδ hδ1 ht
  have h0 : compactMoment J δ 0≤Real.exp δ*δ := by
    simp only [compactMoment,pow_zero,one_mul]
    calc
      (∫ t in 0..δ, J t)≤∫ t in 0..δ, Real.exp δ :=
        intervalIntegral.integral_mono_on hδ (hJ.intervalIntegrable 0 δ)
          (continuous_const.intervalIntegrable 0 δ) (fun t ht => (hbound ht).2)
      _ = _ := by simp; ring
  have h1 : compactMoment J δ 1≤Real.exp δ*δ^2/2 := by
    simp only [compactMoment,pow_one]
    calc
      (∫ t in 0..δ, t*J t)≤∫ t in 0..δ, Real.exp δ*t :=
        intervalIntegral.integral_mono_on hδ ((continuous_id.mul hJ).intervalIntegrable 0 δ)
          ((continuous_id.const_mul _).intervalIntegrable 0 δ)
          (fun t ht => by simpa [mul_comm] using mul_le_mul_of_nonneg_left (hbound ht).2 ht.1)
      _ = _ := by
        have hi : (∫ t in 0..δ, t)=δ^2/2 := by simpa using integral_nat_pow 1 δ
        rw [intervalIntegral.integral_const_mul,hi]; ring
  have he : Real.exp δ≤4/3 := (Real.exp_le_exp.mpr hδ1).trans uniform_exp_bounds.1.le
  have hn (k : ℕ) : 0≤compactMoment J δ k := by
    apply intervalIntegral.integral_nonneg hδ
    intro t ht; exact mul_nonneg (pow_nonneg ht.1 _) (hbound ht).1
  refine ⟨hn 0,?_,hn 1,?_⟩
  · nlinarith [mul_le_mul_of_nonneg_right he hδ]
  · have hsq : δ^2≤1/16 := by nlinarith
    nlinarith [mul_le_mul_of_nonneg_right he (sq_nonneg δ)]

-- @paper-step thm:n_all_orders/improved_zero_moment_for_odd_order
theorem equal_uniform_moment_odd {n : ℕ} (hn : 1≤n) {δ : ℝ}
    (hδ : 0≤δ) (hδ1 : δ≤1/4) :
    compactMoment (remainderJ (fun _ => 1) n δ) δ 0≤1/24 := by
  have hJ := remainderJ_continuous (fun _ => 1) n δ
  have hb : compactMoment (remainderJ (fun _ => 1) n δ) δ 0≤Real.exp δ*δ^2/2 := by
    simp only [compactMoment,pow_zero,one_mul]
    calc
      (∫ t in 0..δ, remainderJ (fun _ => 1) n δ t)≤∫ t in 0..δ, Real.exp δ*(δ-t) :=
        intervalIntegral.integral_mono_on hδ (hJ.intervalIntegrable 0 δ)
          (((continuous_const.sub continuous_id).const_mul _).intervalIntegrable 0 δ)
          (fun t ht => equal_kernel_linear_bound hn hδ hδ1 ht)
      _ = _ := by
        rw [intervalIntegral.integral_const_mul,intervalIntegral.integral_sub
          (continuous_const.intervalIntegrable 0 δ) (show IntervalIntegrable (fun t : ℝ => t) volume 0 δ from continuous_id.intervalIntegrable 0 δ)]
        have hi := integral_nat_pow 1 δ
        simp only [pow_one] at hi
        rw [hi]
        simp; ring
  have he : Real.exp δ≤4/3 := (Real.exp_le_exp.mpr hδ1).trans uniform_exp_bounds.1.le
  have hsq : δ^2≤1/16 := by nlinarith
  nlinarith [mul_le_mul_of_nonneg_right he (sq_nonneg δ)]

end MIACE
