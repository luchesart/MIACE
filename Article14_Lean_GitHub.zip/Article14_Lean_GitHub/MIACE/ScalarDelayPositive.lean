import MIACE.ScalarDelayThreshold
import MIACE.PrimitiveRealization
import MIACE.LaplaceLinear
import MIACE.RetardedUniqueness

/-! Construct the ordinary fundamental solution in the nonoscillatory
range from a positive renewal kernel. The spectral criterion alone is
not used as a time-domain stability theorem. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step lem:delayed_cancellation/positive_scalar_renewal_kernel
theorem scalarDelay_kernel_nonneg {l : ℝ} (hl : 0<l) (δ t : ℝ) :
    0≤twoRateK 1 l l δ t := by
  by_cases ht : t∈Ico (0 : ℝ) δ
  · simp only [twoRateK,twoRateD,indicator_of_mem ht,one_mul,mul_one,sub_self,mul_zero,zero_mul,add_zero]
    positivity
  · simp [twoRateK,ht]

-- @paper-step lem:delayed_cancellation/constructed_positive_decaying_fundamental
theorem scalarDelay_positive_resolvent {x δ l : ℝ} (hx : 0<x) (hδ : 0≤δ)
    (hl : 0<l) (he : l*Real.exp (-l*δ)=x) :
    ∃ E : ℝ → ℝ, Continuous E ∧
      (∀ a b, AbsolutelyContinuousOnInterval E a b) ∧ E 0=1 ∧
      (∀ t, 0≤t → 0<E t) ∧ Integrable E halfLine ∧
      (∃ η C : ℝ, 0<η ∧ 0≤C ∧
        Integrable (expWeight η (causalize E)) ∧
        ∀ t, 0≤t → |E t|≤C*Real.exp (-η*t)) ∧
      (∀ p : ℝ, 0≤p → (p+x*Real.exp (-δ*p))*laplace E p=1) := by
  let K := twoRateK 1 l l δ
  let G := twoRateG 1 l l
  have hK := twoRateK_integrable 1 l l δ
  have hKc := twoRateK_causal 1 l l δ
  have hKn : ∀ᵐ t, 0≤K t := ae_of_all _ (scalarDelay_kernel_nonneg hl δ)
  have hq : (∫ t, K t)<1 := twoRateK_small (by norm_num) le_rfl hδ
  have hG : Integrable (causalize G) := twoRateG_integrable 1 hl hl
  let g := hG.toL1 (causalize G)
  have hgc : Causal g := causal_congr (causalize_causal G) hG.coeFn_toL1.symm
  have hgn : 0≤g := by
    rw [← Lp.coeFn_nonneg]
    filter_upwards [hG.coeFn_toL1] with t ht
    rw [ht]
    by_cases ht0 : 0≤t <;> simp [G,causalize,twoRateG,ht0,Real.exp_nonneg]
  let z : RealL1 := (∑' n : ℕ, (convOp hK)^n) g
  obtain ⟨_,hzn,hzc,hze,_,_,_⟩ := positive_resolvent_all_parts hK hKn hKc hq g hgn hgc
  let E := twoRateErrorRep 1 l l δ z
  have hEa : (z : ℝ → ℝ)=ᵐ[volume] causalize E :=
    renewal_representative_ae hK hKc hG hzc hze
  have hEh := representative_halfLine_ae hEa
  have hr := twoRateErrorRep_regularity (L1.integrable_coeFn z) 1 l l hδ
  have hEi : Integrable E halfLine :=
    ((L1.integrable_coeFn z).mono_measure Measure.restrict_le_self).congr hEh
  refine ⟨E,hr.1,hr.2,?_,?_,hEi,?_,?_⟩
  · change G 0+(K ⋆ (z : ℝ → ℝ)) 0=1
    rw [causal_convolution_zero hKc hzc]
    simp [G,twoRateG]
  · intro t _
    have hn := convolution_pointwise_nonneg hKn ((Lp.coeFn_nonneg _).mpr hzn) t
    change twoRateG 1 l l t+(K ⋆ (z : ℝ → ℝ)) t>0
    simpa [twoRateG] using add_pos_of_pos_of_nonneg (Real.exp_pos (-l*t)) hn
  · obtain ⟨η,hη,hle,hKw,hqw⟩ := expWeight_small_mass hK hq
      (half_pos hl) (twoRateK_weighted 1 l l δ (l/2))
    have hηl : η<l := by linarith
    have hGw := twoRateG_weighted 1 hηl hηl
    have hgw := expWeight_toL1_integrable hG hGw
    obtain ⟨hzw,_,_⟩ := positive_resolvent_weighted hK hKn hKc hq hη.le hKw hqw
      g hgn hgc hgw
    obtain ⟨C,hC,hKb⟩ := twoRateK_weighted_bound 1 l l δ η
    let Z := ∫ t, |expWeight η z t|
    have hZ : 0≤Z := integral_nonneg (fun _ => abs_nonneg _)
    refine ⟨η,1+C*Z,hη,by positivity,weighted_integrable_congr hEa hzw,?_⟩
    intro t ht
    have hc := convolution_weighted_pointwise_bound hC hKb hzw t
    have hg : |G t|≤Real.exp (-η*t) := by
      simp only [G,twoRateG,one_mul,sub_self,zero_mul,add_zero,
        abs_of_pos (Real.exp_pos _)]
      exact Real.exp_le_exp.mpr (by nlinarith)
    have hb := (abs_add_le (G t) ((K ⋆ (z : ℝ → ℝ)) t)).trans (add_le_add hg hc)
    change |G t+(K ⋆ (z : ℝ → ℝ)) t|≤_
    dsimp only [Z]
    nlinarith
  · intro p hp
    have h := renewal_laplace hK hKc g z hgc hzc hze hp
    rw [laplace_congr_ae hG.coeFn_toL1,twoRateG_laplace 1 hl hl hp,
      twoRateK_laplace 1 hl hl hp hδ] at h
    simp only [one_mul,mul_one,sub_self,zero_mul,zero_div,add_zero] at h
    have hden : p+l≠0 := ne_of_gt (by linarith)
    have hexp : Real.exp (-(p+l)*δ)=Real.exp (-δ*p)*Real.exp (-l*δ) := by
      rw [← Real.exp_add]; congr 1; ring
    rw [hexp] at h
    rw [← laplace_congr_halfLine hEh]
    have hh := (eq_div_iff hden).mp h
    rw [he.symm]
    field_simp at hh
    simp only [neg_mul, zero_mul, mul_zero, add_zero, one_mul] at hh ⊢
    linear_combination hh

-- @paper-step lem:delayed_cancellation/fundamental_integral_equation_from_transform
theorem scalarDelay_integral_equation {x δ : ℝ} (hδ : 0≤δ) {E : ℝ → ℝ}
    (hc : Continuous E) (hi : Integrable E halfLine)
    (ht : ∀ p : ℝ, 0<p → (p+x*Real.exp (-δ*p))*laplace E p=1) :
    ∀ t : ℝ, 0≤t → E t=1-x*(∫ s in 0..t, shift δ (causalize E) s) := by
  have hEi := causalize_integrable hi
  have hfi := (shift_integrable δ hEi).const_mul (-x)
  let f := fun t => -x*shift δ (causalize E) t
  have hfc : Continuous (integratedState 1 f) := (integratedState_regular 1 hfi).1
  have htrans (p : ℝ) (hp : 0<p) : laplace E p=laplace (integratedState 1 f) p := by
    rw [(integratedState_laplace 1 (hfi.mono_measure Measure.restrict_le_self) hp).2]
    have hf : laplace f p= -x*(Real.exp (-δ*p)*laplace E p) := by
      rw [show laplace f p= -x*laplace (shift δ (causalize E)) p by
        unfold laplace f; simp_rw [mul_left_comm _ (-x)]; rw [integral_const_mul]]
      rw [laplace_shift (causalize_causal E) hδ p]
      rw [laplace_congr_halfLine (representative_halfLine_ae (EventuallyEq.rfl (f := causalize E)))]
    rw [hf]
    apply (eq_div_iff (ne_of_gt hp)).mpr
    nlinarith [ht p hp]
  have heq := laplace_injective_weighted
    (laplace_integrable hi (by norm_num : (0 : ℝ)≤1))
    (integratedState_laplace 1 (hfi.mono_measure Measure.restrict_le_self)
      (by norm_num : (0 : ℝ)<1)).1 hc hfc (fun p hp => htrans p (by linarith))
  intro t ht0
  rw [heq t ht0,integratedState]
  rw [intervalIntegral.integral_const_mul]
  ring

-- @paper-step lem:delayed_cancellation/delayed_integral_removes_waiting_interval
theorem scalarDelay_shift_primitive (E : ℝ → ℝ) {δ t : ℝ} (hδ : 0≤δ) (ht : 0≤t) :
    (∫ s in 0..t+δ, shift δ (causalize E) s)=∫ s in 0..t, E s := by
  rw [show (fun s => shift δ (causalize E) s)=(fun s => causalize E (s-δ)) by rfl,
    intervalIntegral.integral_comp_sub_right]
  simp only [zero_sub,add_sub_cancel_right]
  rw [intervalIntegral.integral_of_le (by linarith : -δ≤t),
    intervalIntegral.integral_of_le ht]
  rw [← integral_indicator measurableSet_Ioc,← integral_indicator measurableSet_Ioc]
  apply integral_congr_ae
  filter_upwards [volume.ae_ne (0 : ℝ)] with s hz
  by_cases hs : s∈Ioc (0 : ℝ) t
  · simp [causalize,hs,show s∈Ioc (-δ) t from ⟨by linarith [hs.1],hs.2⟩,hs.1.le]
  · by_cases hp : 0≤s
    · have hst : ¬s≤t := fun h => hs ⟨lt_of_le_of_ne hp (Ne.symm hz),h⟩
      simp [causalize,hst]
    · simp [causalize,hp,hs]

end MIACE
