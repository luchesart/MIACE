import MIACE.TwoRateCommand

/-! Етап 8: връзка на двата реда с нулевосъстоянния PID контур.
    Структурата по-долу събира само вече доказаните интегрални уравнения.
    Уравненията на обекта и регулатора се извеждат след това. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

structure TwoRateRenewalPair {i ρ ell l m δ : ℝ}
    (h : TwoRateData i ρ ell l m δ) (e v : RealL1) : Prop where
  error_causal : Causal e
  command_causal : Causal v
  error_eq : e=(twoRateG_integrable (twoRateA ρ l m)
      (by linarith [h.lower_rate]) (by linarith [h.lower_rate,h.ordered_rates])).toL1
        (causalize (twoRateG (twoRateA ρ l m) l m))+
    convOp (twoRateK_integrable (twoRateA ρ l m) l m δ) e
  command_eq : v=(twoRateR_integrable (twoRateA ρ l m) δ
      (by linarith [h.lower_rate]) (by linarith [h.lower_rate,h.ordered_rates])).toL1
        (causalize (twoRateR (twoRateA ρ l m) l m δ))+
    convOp (twoRateK_integrable (twoRateA ρ l m) l m δ) v

-- @paper-step thm:pid_two_rate_optimum/command_transfer_identification
theorem twoRate_command_transfer {i ρ ell l m δ : ℝ} (h : TwoRateData i ρ ell l m δ)
    {e v : RealL1} (hs : TwoRateRenewalPair h e v) {p : ℝ} (hp : 0 < p) :
    laplace v p=(i*(1+ell*p)/(1+ρ*p)*(1+(1-Real.exp (-δ*p))/p)-1)*laplace e p := by
  let A := twoRateA ρ l m
  have hl : 0 < l := by linarith [h.lower_rate]
  have hm : 0 < m := by linarith [h.lower_rate,h.ordered_rates]
  let hG := twoRateG_integrable A hl hm
  let hR := twoRateR_integrable A δ hl hm
  let G := hG.toL1 (causalize (twoRateG A l m))
  let R := hR.toL1 (causalize (twoRateR A l m δ))
  have he := renewal_laplace (twoRateK_integrable A l m δ) (twoRateK_causal A l m δ)
    G e (causal_congr (causalize_causal _) hG.coeFn_toL1.symm) hs.error_causal hs.error_eq hp.le
  have hv := renewal_laplace (twoRateK_integrable A l m δ) (twoRateK_causal A l m δ)
    R v (causal_congr (causalize_causal _) hR.coeFn_toL1.symm) hs.command_causal hs.command_eq hp.le
  rw [laplace_congr_ae hG.coeFn_toL1] at he
  rw [laplace_congr_ae hR.coeFn_toL1,twoRateR_controller_laplace h hp] at hv
  have hden : 1-laplace (twoRateK A l m δ) p ≠ 0 := by
    intro hz
    have hf := twoRate_characteristic_factor h hp.le
    rw [hz,mul_zero] at hf
    linarith [pid_characteristic_positive h hp.le]
  apply mul_left_cancel₀ hden
  rw [hv,← he]
  ring

-- @paper-step thm:pid_two_rate_optimum/actual_PID_controller_transfer
theorem twoRate_controller_transfer {i ρ ell l m δ : ℝ} (h : TwoRateData i ρ ell l m δ)
    {e v : RealL1} (hs : TwoRateRenewalPair h e v) {p : ℝ} (hp : 0 < p) :
    1/p+laplace v p=
      (i*(1+ell-ρ)+i/p+i*(ell-ρ)*(1-ρ)*p/(1+ρ*p))*laplace e p := by
  have hf : 1+ρ*p ≠ 0 := ne_of_gt (by have hρ:=h.filter_pos; positivity)
  have hd : p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p) ≠ 0 :=
    ne_of_gt (pid_characteristic_positive h hp.le)
  rw [pid_controller_factor i ρ ell p (ne_of_gt hp) hf,
    twoRate_command_transfer h hs hp,twoRate_error_transfer h e hs.error_causal hs.error_eq hp.le]
  generalize Real.exp (-δ*p)=q at hd ⊢
  generalize 1+ρ*p=F at hf hd ⊢
  field_simp [hf,hd,ne_of_gt hp]
  ring_nf at hd ⊢
  linear_combination -(mul_inv_cancel₀ hd)

-- @paper-step thm:pid_two_rate_optimum/actual_plant_transfer_identity
theorem twoRate_plant_transfer {i ρ ell l m δ : ℝ} (h : TwoRateData i ρ ell l m δ)
    {e v : RealL1} (hs : TwoRateRenewalPair h e v) {p : ℝ} (hp : 0 < p) :
    1/p-laplace e p=1/(1+p)*Real.exp (-δ*p)*(1/p+laplace v p) := by
  have hf : 1+ρ*p ≠ 0 := ne_of_gt (by have hρ:=h.filter_pos; positivity)
  have hd : p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p) ≠ 0 :=
    ne_of_gt (pid_characteristic_positive h hp.le)
  rw [twoRate_controller_transfer h hs hp,pid_controller_factor i ρ ell p (ne_of_gt hp) hf,
    twoRate_error_transfer h e hs.error_causal hs.error_eq hp.le]
  generalize Real.exp (-δ*p)=q at hd ⊢
  generalize 1+ρ*p=F at hf hd ⊢
  field_simp [hf,hd,ne_of_gt hp,ne_of_gt (by positivity : 0<1+p)]
  ring_nf at hd ⊢
  linear_combination -(1+p) * (mul_inv_cancel₀ hd)

-- @paper-step thm:pid_two_rate_optimum/assembled_zero_state_plant
theorem twoRate_transfer_response {i ρ ell l m δ : ℝ} (h : TwoRateData i ρ ell l m δ)
    {e v : RealL1} (hs : TwoRateRenewalPair h e v) :
    TransferResponse e v (fun p => 1/(1+p)) δ := by
  have heI : Integrable (e : ℝ → ℝ) halfLine := (L1.integrable_coeFn e).restrict
  have hvI : Integrable (v : ℝ → ℝ) halfLine := (L1.integrable_coeFn v).restrict
  refine ⟨heI,hvI,?_⟩
  intro p hp
  have hc : Integrable (fun t : ℝ => Real.exp (-p*t)) halfLine :=
    integrableOn_exp_mul_Ioi (by linarith : -p<0) 0
  have hy : laplace (fun t => 1-e t) p=1/p-laplace e p := by
    unfold laplace
    simp_rw [mul_sub,mul_one]
    rw [integral_sub hc (laplace_integrable heI hp.le)]
    simpa [laplace] using congrArg (fun z : ℝ => z-laplace e p) (laplace_step p hp)
  have hw : laplace (fun t => 1+v t) p=1/p+laplace v p := by
    unfold laplace
    simp_rw [mul_add,mul_one]
    rw [integral_add hc (laplace_integrable hvI hp.le)]
    simpa [laplace] using congrArg (fun z : ℝ => z+laplace v p) (laplace_step p hp)
  rw [hy,hw]
  exact twoRate_plant_transfer h hs hp

-- @paper-step thm:pid_two_rate_optimum/positive_PID_transfer_pair_exists
theorem twoRate_closed_loop_exists {i ρ ell l m δ : ℝ} (h : TwoRateData i ρ ell l m δ) :
    ∃ e v : RealL1,
      TwoRateRenewalPair h e v ∧ 0 ≤ e ∧ 0 ≤ v ∧
      TransferResponse e v (fun p => 1/(1+p)) δ ∧
      (∀ p : ℝ, 0<p → 1/p+laplace v p=
        (i*(1+ell-ρ)+i/p+i*(ell-ρ)*(1-ρ)*p/(1+ρ*p))*laplace e p) ∧
      (∫ t, e t)=1/i ∧ (∫ t, v t)=1+δ-1/i ∧
      (∃ η : ℝ, 0<η ∧ η≤1/2 ∧ Integrable (expWeight η e) volume ∧ Integrable (expWeight η v) volume) := by
  obtain ⟨_,_,_,_,hen,hvn,hec,hvc,hee,hve,_,_,heint,hvint,hw⟩ := twoRate_signal_certificate h
  let hs : TwoRateRenewalPair h _ _ := ⟨hec,hvc,hee,hve⟩
  exact ⟨_,_,hs,hen,hvn,twoRate_transfer_response h hs,
    fun _ hp => twoRate_controller_transfer h hs hp,heint,hvint,hw⟩

end MIACE
