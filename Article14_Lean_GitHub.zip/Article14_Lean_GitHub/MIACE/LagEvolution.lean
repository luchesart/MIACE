import MIACE.IMCFilter

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

noncomputable def lagState (σ z₀ : ℝ) (u : ℝ → ℝ) (t : ℝ) : ℝ :=
  z₀*Real.exp (-t/σ)+lag σ u t

structure LagEvolution (σ z₀ : ℝ) (u x : ℝ → ℝ) : Prop where
  ac : ∀ T, 0≤T → AbsolutelyContinuousOnInterval x 0 T
  input_integrable : ∀ T, 0≤T → IntervalIntegrable u volume 0 T
  ode : ∀ᵐ t, 0<t → HasDerivAt x ((u t-x t)/σ) t
  initial : x 0=z₀

-- @paper-step thm:complete_attainment/ordinary_lag_arbitrary_initial_state
theorem lagState_evolution {u : ℝ → ℝ} (hu : LocallyIntegrable u volume) (σ z₀ : ℝ) :
    Continuous (lagState σ z₀ u) ∧ LagEvolution σ z₀ u (lagState σ z₀ u) := by
  have hr := ordinary_lag_regular hu σ
  refine ⟨(by fun_prop : Continuous (fun t : ℝ => z₀*Real.exp (-t/σ))).add hr.1,?_,
    fun T _ => locally_integrable_interval hu 0 T,?_,by simp [lagState,lag]⟩
  · intro T hT
    have he : AbsolutelyContinuousOnInterval (fun t : ℝ => z₀*Real.exp (-t/σ)) 0 T := by
      apply ContDiffOn.absolutelyContinuousOnInterval; fun_prop
    exact he.add (hr.2.1 0 T)
  · filter_upwards [hr.2.2] with t ht hp
    have hd := ((((hasDerivAt_id t).neg.div_const σ).exp).const_mul z₀).add ht
    convert hd using 1
    · rfl
    · simp only [lagState,Pi.neg_apply,id_eq]
      ring

-- @paper-step thm:complete_attainment/zero_initial_lag_unique_formula
theorem lag_response_formula {σ : ℝ} {u x : ℝ → ℝ} (h : LagResponse σ u x)
    {t : ℝ} (ht : 0≤t) : x t=lag σ u t := by
  have hi := lag_weighted_increment h (show (0 : ℝ)≤0 from le_rfl) ht 0
  simp only [sub_zero,h.initial,mul_zero] at hi
  rw [intervalIntegral.integral_div] at hi
  have hh := congrArg (fun z => Real.exp (-t/σ)*z) hi
  have he : Real.exp (-t/σ)*Real.exp (t/σ)=1 := by
    rw [← Real.exp_add]; ring_nf; simp
  rw [← mul_assoc,he,one_mul] at hh
  unfold lag
  linear_combination -hh

-- @paper-step thm:complete_attainment/ordinary_lag_unrestricted_uniqueness
theorem lagEvolution_formula {σ z₀ : ℝ} {u x : ℝ → ℝ} (h : LagEvolution σ z₀ u x)
    {t : ℝ} (ht : 0≤t) : x t=lagState σ z₀ u t := by
  have hz : LagResponse σ u (fun s => x s-z₀*Real.exp (-s/σ)) := by
    refine ⟨?_,h.input_integrable,?_,by simp [h.initial]⟩
    · intro T hT
      have hc : AbsolutelyContinuousOnInterval (fun s : ℝ => z₀*Real.exp (-s/σ)) 0 T := by
        apply ContDiffOn.absolutelyContinuousOnInterval; fun_prop
      exact (h.ac T hT).sub hc
    · filter_upwards [h.ode] with s hs hp
      have hd := (hs hp).sub ((((hasDerivAt_id s).neg.div_const σ).exp).const_mul z₀)
      change HasDerivAt (fun r => x r-z₀*Real.exp (-r/σ)) _ s at hd
      rw [hd.deriv]
      simp only [Pi.neg_apply,id_eq]
      ring
  have hh := lag_response_formula hz ht
  unfold lagState
  linarith

-- @paper-step thm:complete_attainment/initial_transient_causal_kernel
theorem lag_transient_kernel (σ : ℝ) (hσ : 0<σ) :
    causalize (fun t => Real.exp (-t/σ))=ᵐ[volume] (fun t => σ*lagKernel σ t) := by
  filter_upwards [volume.ae_ne (0 : ℝ)] with t ht
  by_cases hp : 0<t
  · simp only [causalize,indicator_of_mem (show t∈Ici (0 : ℝ) from hp.le),
      lagKernel,indicator_of_mem (show t∈Ioi (0 : ℝ) from hp)]
    have he : -t/σ=(-1/σ)*t := by ring
    rw [he]; field_simp
  · have hn : ¬0≤t := not_le.mpr (lt_of_le_of_ne (le_of_not_gt hp) ht)
    simp [causalize,lagKernel,hp,hn]

-- @paper-step thm:complete_attainment/lag_state_causal_representation
theorem lagState_causal_formula {σ : ℝ} (hσ : 0<σ) (z₀ : ℝ) (u : ℝ → ℝ) :
    causalize (lagState σ z₀ u)=ᵐ[volume]
      (fun t => (z₀*σ)*lagKernel σ t+(lagKernel σ ⋆ causalize u) t) := by
  filter_upwards [lag_transient_kernel σ hσ] with t ht
  by_cases hp : 0≤t
  · rw [causalize,indicator_of_mem (show t∈Ici (0 : ℝ) from hp),lagState,
      lag_as_causal_convolution σ hσ u hp]
    simp only [causalize,indicator_of_mem (show t∈Ici (0 : ℝ) from hp)] at ht
    rw [ht]; ring
  · have hn : t<0 := lt_of_not_ge hp
    rw [convolution_causal (lagKernel_properties hσ).2.2.2 (causalize_causal u) t hn]
    simp [causalize,hp,lagKernel,show ¬0<t by linarith]

-- @paper-step thm:complete_attainment/lag_state_quantitative_decay
theorem lagState_weighted_control {σ η C D : ℝ} (hσ : 0<σ)
    (hK : WeightedControl η (lagKernel σ) C) {u : ℝ → ℝ}
    (hu : WeightedControl η (causalize u) D) (z₀ : ℝ) :
    WeightedControl η (causalize (lagState σ z₀ u)) (|z₀*σ| *C+C*D) := by
  exact weightedControl_congr
    (weightedControl_add (weightedControl_smul hK (z₀*σ)) (weightedControl_convolution hK hu))
    (lagState_causal_formula hσ z₀ u).symm

end MIACE
