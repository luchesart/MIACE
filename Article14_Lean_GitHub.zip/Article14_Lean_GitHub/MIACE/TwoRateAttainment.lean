import MIACE.TwoRateClosedLoop
import MIACE.PIDStateSpectrum
import MIACE.TwoRateExample

/-! Етап 8: събран сертификат за глобален оптимум в TransferResponse семантиката.
    Включва действителните преобразувания на обекта и PID и пълния спектрален резултат.
    Не замества оставащата теорема за всички DDE истории и точковата форма на изхода. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:pid_two_rate_optimum/first_order_transfer_DC
theorem firstOrder_transfer_dc :
    HasDerivAt (fun p : ℝ => 1/(1+p)) (-1) 0 := by
  convert (hasDerivAt_const (0 : ℝ) (1 : ℝ)).div
    ((hasDerivAt_id (0 : ℝ)).const_add 1) (by norm_num) using 1 <;> norm_num
  funext p
  simp [Pi.div_apply,one_div]

-- @paper-step thm:pid_two_rate_optimum/assembled_transfer_spectral_optimum
theorem twoRate_transfer_optimum {α ρ ell l m δ : ℝ} (hα : 0 < α)
    (h : TwoRateData ((1+1/α)/(1+δ)) ρ ell l m δ) :
    let i := (1+1/α)/(1+δ)
    ∃ e v : RealL1,
      TwoRateRenewalPair h e v ∧ 0 ≤ e ∧ 0 ≤ v ∧
      TransferResponse e v (fun p => 1/(1+p)) δ ∧
      (∀ p : ℝ, 0<p → 1/p+laplace v p=
        (i*(1+ell-ρ)+i/p+i*(ell-ρ)*(1-ρ)*p/(1+ρ*p))*laplace e p) ∧
      absArea e halfLine=α*(1+δ)/(1+α) ∧
      absArea v halfLine=(1+δ)/(1+α) ∧
      miace α e v halfLine=(1+δ)*minimum α ∧
      (∃ η : ℝ, 0<η ∧ η≤1/2 ∧ Integrable (expWeight η e) volume ∧ Integrable (expWeight η v) volume) ∧
      (∃ η : ℝ, 0<η ∧ η≤1/2 ∧ ∀ p : ℂ, -η≤p.re →
        (pidStateSymbol (i*(1+ell-ρ)) i (i*(ell-ρ)*(1-ρ)) ρ δ p).det ≠ 0) ∧
      (∀ e' v' : ℝ → ℝ, TransferResponse e' v' (fun p => 1/(1+p)) δ →
        miace α e v halfLine ≤ miace α e' v' halfLine) := by
  dsimp only
  obtain ⟨e,v,hs,hen,hvn,hplant,hcontroller,heint,hvint,hw⟩ := twoRate_closed_loop_exists h
  have hearea : absArea e halfLine=α*(1+δ)/(1+α) := by
    rw [← causal_absArea hs.error_causal,positive_l1_area _ hen,heint,(pid_optimal_gain hα h.delay_nonneg).2]
  have hvarea : absArea v halfLine=(1+δ)/(1+α) := by
    rw [← causal_absArea hs.command_causal,positive_l1_area _ hvn,hvint,(pid_optimal_gain hα h.delay_nonneg).2]
    field_simp
    <;> ring
  have hb := transfer_signed_balance hplant 1 firstOrder_transfer_dc (by norm_num)
  have hcost : miace α e v halfLine=(1+δ)*minimum α := by
    apply (signal_miace_equality_iff hplant.error_integrable hplant.command_integrable
      α (1+δ) hα (by linarith [h.delay_nonneg]) hb).mpr
    refine ⟨?_,?_,?_⟩
    · exact ((Lp.coeFn_nonneg _).mpr hen).filter_mono (ae_mono Measure.restrict_le_self)
    · exact ((Lp.coeFn_nonneg _).mpr hvn).filter_mono (ae_mono Measure.restrict_le_self)
    · rw [hearea,hvarea]; ring
  refine ⟨e,v,hs,hen,hvn,hplant,hcontroller,hearea,hvarea,hcost,hw,twoRate_physical_spectrum h,?_⟩
  intro e' v' hc
  rw [hcost]
  exact signal_miace_lower_bound hc.error_integrable hc.command_integrable α (1+δ) hα
    (by linarith [h.delay_nonneg]) (transfer_signed_balance hc 1 firstOrder_transfer_dc (by norm_num))

-- @paper-step thm:pid_two_rate_optimum/balanced_physical_spectrum
theorem balanced_pid_spectrum :
    let i : ℝ := 8/5
    let δ : ℝ := 1/4
    let ρ := pidRho i δ 5 6
    let ell := pidLead i δ 5 ρ
    ∃ η : ℝ, 0<η ∧ η≤1/2 ∧ ∀ p : ℂ, -η≤p.re →
      (pidStateSymbol (i*(1+ell-ρ)) i (i*(ell-ρ)*(1-ρ)) ρ δ p).det ≠ 0 :=
  twoRate_physical_spectrum balanced_twoRate_data

-- @paper-step thm:pid_two_rate_optimum/balanced_actual_PID_optimal_areas
theorem balanced_pid_optimal_pair :
    let i : ℝ := 8/5
    let δ : ℝ := 1/4
    let ρ := pidRho i δ 5 6
    let ell := pidLead i δ 5 ρ
    ∃ e v : RealL1, 0 ≤ e ∧ 0 ≤ v ∧
      TransferResponse e v (fun p => 1/(1+p)) δ ∧
      (∀ p : ℝ, 0<p → 1/p+laplace v p=
        (i*(1+ell-ρ)+i/p+i*(ell-ρ)*(1-ρ)*p/(1+ρ*p))*laplace e p) ∧
      absArea e halfLine=5/8 ∧ absArea v halfLine=5/8 ∧
      miace 1 e v halfLine=(5/4)*minimum 1 := by
  have h : TwoRateData ((1+1/(1 : ℝ))/(1+1/4))
      (pidRho (8/5) (1/4) 5 6) (pidLead (8/5) (1/4) 5 (pidRho (8/5) (1/4) 5 6)) 5 6 (1/4) := by
    convert balanced_twoRate_data using 1 <;> norm_num
  obtain ⟨e,v,_,hen,hvn,hp,hc,hea,hva,hm,_⟩ := twoRate_transfer_optimum (by norm_num : (0 : ℝ)<1) h
  refine ⟨e,v,hen,hvn,hp,?_,?_,?_,?_⟩
  · convert hc using 1 <;> norm_num
  · norm_num at hea ⊢; exact hea
  · norm_num at hva ⊢; exact hva
  · norm_num at hm ⊢; exact hm

end MIACE
