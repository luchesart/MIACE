import MIACE.Algebra
import Mathlib.Analysis.SpecialFunctions.Integrals.Basic

/-! Exact calculations for the nonlinear example following manuscript Theorem 32.
The integral is the original storage intercept; no numerical approximation is used. -/
namespace MIACE
open MeasureTheory Set

def nonlinearExampleRate (y : ℝ) : ℝ := 1 + y ^ 2

-- @paper-step thm:nonlinear_miace/example_positive_rate
theorem nonlinear_example_rate_pos (y : ℝ) : 0 < nonlinearExampleRate y := by
  unfold nonlinearExampleRate
  positivity

-- @paper-step thm:nonlinear_miace/example_continuous_rate
theorem nonlinear_example_rate_continuous : Continuous nonlinearExampleRate := by
  unfold nonlinearExampleRate
  fun_prop

-- @paper-step thm:nonlinear_miace/example_storage_integral
theorem nonlinear_example_storage_integral :
    (∫ y : ℝ in 0..1, (nonlinearExampleRate y)⁻¹) = Real.pi / 4 := by
  unfold nonlinearExampleRate
  rw [integral_inv_one_add_sq]
  simp

-- @paper-step thm:nonlinear_miace/example_compact_bounds
theorem nonlinear_example_rate_bounds {y : ℝ} (hy : y ∈ Icc (0 : ℝ) 1) :
    1 ≤ nonlinearExampleRate y ∧ nonlinearExampleRate y ≤ 2 := by
  unfold nonlinearExampleRate
  constructor
  · nlinarith [sq_nonneg y]
  · nlinarith [hy.1, hy.2]

noncomputable def nonlinearExampleClock (y : ℝ) : ℝ :=
  -(1 / 2 : ℝ) * Real.log (1 - y) +
    (1 / 4 : ℝ) * Real.log (1 + y ^ 2) + (1 / 2 : ℝ) * Real.arctan y

-- @paper-step thm:nonlinear_miace/example_clock_initial
theorem nonlinear_example_clock_zero : nonlinearExampleClock 0 = 0 := by
  simp [nonlinearExampleClock]

-- @paper-step thm:nonlinear_miace/example_implicit_derivative
theorem nonlinear_example_clock_derivative {y : ℝ} (hy : y < 1) :
    HasDerivAt nonlinearExampleClock ((1 + y ^ 2) * (1 - y))⁻¹ y := by
  have h1 : 1 - y ≠ 0 := by linarith
  have h2 : 1 + y ^ 2 ≠ 0 := ne_of_gt (by positivity)
  have hd1 := ((hasDerivAt_const y (1 : ℝ)).sub (hasDerivAt_id y)).log h1
  have hd2 := ((hasDerivAt_const y (1 : ℝ)).add ((hasDerivAt_id y).pow 2)).log h2
  have hd := ((hd1.const_mul (-(1 / 2 : ℝ))).add
    (hd2.const_mul (1 / 4 : ℝ))).add ((Real.hasDerivAt_arctan y).const_mul (1 / 2 : ℝ))
  convert hd using 1
  · rfl
  · simp only [Pi.sub_apply, Pi.add_apply, Pi.pow_apply, id_eq]
    field_simp; ring

end MIACE
