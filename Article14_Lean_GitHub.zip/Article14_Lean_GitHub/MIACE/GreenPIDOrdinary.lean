import MIACE.ExplicitPIDGreen
import MIACE.PIDNecessaryStructure

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:pid_explicit_family/ordinary_continuous_error_from_the_Green_transform
theorem green_PID_error_ordinary {i ρ ell δ η C : ℝ} {G : ℝ → ℝ}
    (hρ : 0<ρ) (hδ : 0≤δ) (hη : 0<η) (hGc : Causal G)
    (hG : WeightedControl η G C) (hGn : ∀ᵐ t, 0≤G t)
    (hGT : ∀ p, 0≤p →
      (p*(1+ρ*p)+i*(1+ell*p)*Real.exp (-δ*p))*laplace G p=1+ρ*p) :
    ∃ E : ℝ → ℝ, Continuous E ∧ (∀ a b, AbsolutelyContinuousOnInterval E a b) ∧
      E 0=1 ∧ G=ᵐ[volume] causalize E ∧ (∀ t, 0≤t → 0≤E t) ∧
      Integrable E halfLine ∧ Tendsto E atTop (𝓝 0) := by
  have hGi := weightedControl_unweighted hG hGc hη.le
  let L := lagKernel ρ
  have hLi := (lagKernel_properties hρ).1
  have hLc : Causal L := (lagKernel_properties hρ).2.2.2
  let J := fun t => ell*G t+(ρ-ell)*(L ⋆ G) t
  have hJi : Integrable J := (hGi.const_mul ell).add
    ((hLi.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hGi).const_mul (ρ-ell))
  have hJc : Causal J := causal_linear hGc (ae_of_all _ (convolution_causal hLc hGc)) ell (ρ-ell)
  let F := fun t => (-i/ρ)*shift δ J t
  have hFi : Integrable F := (shift_integrable δ hJi).const_mul (-i/ρ)
  have hFhat (p : ℝ) (hp : 0<p) : p*laplace G p=1+laplace F p := by
    have hJhat : laplace J p=(ell+(ρ-ell)/(1+ρ*p))*laplace G p := by
      rw [show J=(fun t => ell*G t+(ρ-ell)*(L ⋆ G) t) from rfl,
        laplace_linear hGi (hLi.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hGi) _ _ hp.le,
        causal_convolution_laplace hLi hGi hLc hGc hp.le,
        show laplace L p=1/(1+ρ*p) from lagKernel_laplace hρ hp.le]
      ring
    have hF : laplace F p=(-i/ρ)*Real.exp (-δ*p)*laplace J p := by
      unfold F laplace
      simp_rw [show ∀ t, Real.exp (-p*t)*((-i/ρ)*shift δ J t)=
        (-i/ρ)*(Real.exp (-p*t)*shift δ J t) by intro t; ring]
      rw [integral_const_mul]
      change (-i/ρ)*laplace (shift δ J) p=_
      rw [laplace_shift hJc hδ p]
      change (-i/ρ)*(Real.exp (-δ*p)*laplace J p)=(-i/ρ)*Real.exp (-δ*p)*laplace J p
      ring
    rw [hF,hJhat]
    have ht := hGT p hp.le
    have hρ0 := ne_of_gt hρ
    have hfp : 1+ρ*p≠0 := ne_of_gt (by positivity)
    field_simp
    simp only [neg_mul,mul_comm δ p] at ht ⊢
    linear_combination ρ*ht
  let E := integratedState 1 F
  have he : G=ᵐ[volume] causalize E := integratedState_identification hGi hGc hFi 1 hFhat
  obtain ⟨hc,h0,hac,_⟩ := integratedState_regular 1 hFi
  have hehalf := representative_halfLine_ae he
  have hn : ∀ᵐ t ∂halfLine, 0≤E t := by
    have hghalf := hGn.filter_mono (ae_mono (Measure.restrict_le_self (s:=Ioi (0 : ℝ))))
    filter_upwards [hghalf,hehalf] with t ht heq
    rw [← heq]; exact ht
  have hew := weightedControl_congr hG he
  refine ⟨E,hc,hac,h0,he,continuous_halfline_nonneg hc hn,hGi.restrict.congr hehalf,?_⟩
  exact tendsto_zero_of_exp_bound hη (weightedControl_continuous_decay hc hew)

-- @paper-step thm:pid_explicit_family/ordinary_controller_from_actual_transform_and_L1_pair
theorem filteredPID_ordinary_realization {pc i dc ρ δ : ℝ} {E v : ℝ → ℝ}
    (hρ : 0<ρ) (hEc : Continuous E) (hplant : TransferResponse E v (fun p => 1/(1+p)) δ)
    (hvn : ∀ᵐ t ∂halfLine, 0≤v t)
    (hcontroller : ∀ p, 0<p → 1/p+laplace v p=(pc+i/p+dc*p/(1+ρ*p))*laplace E p) :
    ∃ V : ℝ → ℝ, FilteredPIDResponse pc i dc ρ δ E V ∧
      v=ᵐ[halfLine] V ∧ ∀ t, 0≤t → 0≤V t := by
  let W := pidTimeCommand pc i dc ρ E
  let V := fun t => W t-1
  have hVc : Continuous V := (pidTimeCommand_continuous hEc pc i dc ρ).sub continuous_const
  have hvw : Integrable (expWeight (-1) (causalize (fun t => 1+v t))) := by
    rw [expWeight_causalize]
    exact causalize_integrable (laplace_step_add hplant.command_integrable (by norm_num : (0 : ℝ)<1)).1
  have hWw : Integrable (expWeight (-1) (causalize W)) := by
    rw [expWeight_causalize]
    exact causalize_integrable (pidTimeCommand_transform hplant.error_integrable pc i dc hρ
      (by norm_num : (0 : ℝ)<1)).1
  have he : (fun t => 1+v t)=ᵐ[halfLine] W := by
    apply laplace_injective_weighted_ae hvw hWw
    intro p hp
    have hp0 : 0<p := by linarith
    rw [(laplace_step_add hplant.command_integrable hp0).2,
      (pidTimeCommand_transform hplant.error_integrable pc i dc hρ hp0).2]
    exact hcontroller p hp0
  have hev : v=ᵐ[halfLine] V := by
    filter_upwards [he] with t ht
    dsimp [V]; linarith
  have hVn : ∀ᵐ t ∂halfLine, 0≤V t := by
    filter_upwards [hev,hvn] with t ht hn
    rw [← ht]; exact hn
  refine ⟨V,⟨hEc,hVc,transfer_response_congr hplant EventuallyEq.rfl hev,?_⟩,
    hev,continuous_halfline_nonneg hVc hVn⟩
  intro t _
  dsimp [V,W]; ring

end MIACE
