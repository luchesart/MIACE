import MIACE.FirstOrderRealization

/-! Етап 10: нулевата начална траектория на физическия PID контур.
    Транспортът получава причинно продължената команда: нула за t<0.
    Това не е твърдение за устойчивост при произволни начални истории. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

structure PhysicalPIDStep (i ρ ell δ : ℝ) (E V : ℝ → ℝ) : Prop where
  command : ∀ t : ℝ, 0≤t →
    pidTimeCommand (i*(1+ell-ρ)) i (i*(ell-ρ)*(1-ρ)) ρ E t=1+V t
  plant_ode : ∀ᵐ t : ℝ, 0<t → deriv (fun s => 1-E s) t=
    -(1-E t)+causalize (pidTimeCommand (i*(1+ell-ρ)) i (i*(ell-ρ)*(1-ρ)) ρ E) (t-δ)
  output_initial : 1-E 0=0
  integrator_initial : (∫ s in (0 : ℝ)..0, E s)=0
  filter_initial : lag ρ E 0=0
  integrator_ode : ∀ t : ℝ, HasDerivAt (fun u => ∫ s in 0..u, E s) (E t) t
  filter_ode : ∀ t : ℝ, 0<t → HasDerivAt (lag ρ E) ((E t-lag ρ E t)/ρ) t
  integrator_final : Tendsto (fun t => ∫ s in 0..t, E s) atTop (𝓝 (1/i))
  filter_final : Tendsto (lag ρ E) atTop (𝓝 0)
  zero_transport_history : ∀ s : ℝ, s<0 →
    causalize (pidTimeCommand (i*(1+ell-ρ)) i (i*(ell-ρ)*(1-ρ)) ρ E) s=0
  waiting : ∀ t : ℝ, 0≤t → t≤δ → E t=1
  output_monotone : MonotoneOn (fun t => 1-E t) (Ici 0)
  output_bounds : ∀ t : ℝ, 0≤t → 0≤1-E t ∧ 1-E t<1

-- @paper-step thm:pid_two_rate_optimum/actual_delayed_plant_derivative
theorem ordinary_PID_plant_derivative {i ρ ell δ : ℝ} {E V : ℝ → ℝ}
    (hδ : 0≤δ) (h : OrdinaryPIDSignals i ρ ell δ E V) {t : ℝ} (ht : 0<t) (hne : t≠δ) :
    HasDerivAt (fun s => 1-E s)
      (-(1-E t)+causalize (fun s => 1+V s) (t-δ)) t := by
  have he := transfer_firstOrder_realization h.plant hδ h.error_continuous h.command_continuous
  by_cases hw : t<δ
  · have hlocal : (fun s => 1-E s)=ᶠ[𝓝 t] (fun _ => (0 : ℝ)) := by
      filter_upwards [Ioo_mem_nhds ht hw] with s hs
      rw [he s hs.1.le]
      simp [delayedError,hs.2.le]
    have hd := (hasDerivAt_const t (0 : ℝ)).congr_of_eventuallyEq hlocal
    apply hd.congr_deriv
    rw [he t ht.le]
    simp [delayedError,hw.le,causalize,show ¬0≤t-δ by linarith]
  · have hp : δ<t := lt_of_le_of_ne (le_of_not_gt hw) (Ne.symm hne)
    have hlocal : (fun s => 1-E s)=ᶠ[𝓝 t] (fun s => 1-firstOrderError V (s-δ)) := by
      filter_upwards [Ioi_mem_nhds hp] with s hs
      have hs' : δ<s := hs
      rw [he s (by linarith)]
      simp [delayedError,not_le.mpr hs']
    have hf := (firstOrderError_derivative h.command_continuous (sub_pos.mpr hp)).comp t
      ((hasDerivAt_id t).sub_const δ)
    have hd := (hf.const_sub 1).congr_of_eventuallyEq hlocal
    apply hd.congr_deriv
    rw [he t ht.le]
    simp only [delayedError,if_neg (not_le.mpr hp),causalize,
      indicator_of_mem (show t-δ∈Ici (0 : ℝ) from (sub_pos.mpr hp).le)]
    ring

-- @paper-step thm:pid_two_rate_optimum/full_physical_PID_step_ODE
theorem ordinary_PID_plant_ode {i ρ ell δ : ℝ} {E V : ℝ → ℝ}
    (hρ : 0<ρ) (hδ : 0≤δ) (h : OrdinaryPIDSignals i ρ ell δ E V) :
    ∀ᵐ t : ℝ, 0<t → deriv (fun s => 1-E s) t=
      -(1-E t)+causalize (pidTimeCommand (i*(1+ell-ρ)) i (i*(ell-ρ)*(1-ρ)) ρ E) (t-δ) := by
  filter_upwards [volume.ae_ne δ] with t ht hpos
  rw [(ordinary_PID_plant_derivative hδ h hpos ht).deriv]
  by_cases hs : 0≤t-δ
  · simp only [causalize,indicator_of_mem (show t-δ∈Ici (0 : ℝ) from hs)]
    rw [ordinary_PID_command hρ h (t-δ) hs]
  · simp [causalize,hs]

-- Всеки член на сертификата се извежда от параметрите и построените сигнали.
-- @paper-step thm:pid_two_rate_optimum/assembled_physical_step_certificate
theorem ordinary_PID_physical_step {i ρ ell l m δ : ℝ} (hp : TwoRateData i ρ ell l m δ)
    {E V : ℝ → ℝ} (h : OrdinaryPIDSignals i ρ ell δ E V) : PhysicalPIDStep i ρ ell δ E V := by
  obtain ⟨hz,hζ,hdz,hdζ,hlz,hlζ⟩ := ordinary_PID_controller_states hp h
  obtain ⟨hm,hb,hw⟩ := ordinary_PID_output_shape hp.delay_nonneg h
  refine ⟨ordinary_PID_command hp.filter_pos h,
    ordinary_PID_plant_ode hp.filter_pos hp.delay_nonneg h,
    by rw [h.error_initial]; ring,hz,hζ,hdz,hdζ,hlz,hlζ,?_,hw,hm,hb⟩
  intro s hs
  simp [causalize,not_le.mpr hs]

-- @paper-step thm:pid_two_rate_optimum/time_domain_global_optimum
theorem twoRate_time_domain_optimum {α ρ ell l m δ : ℝ} (hα : 0<α)
    (h : TwoRateData ((1+1/α)/(1+δ)) ρ ell l m δ) :
    ∃ E V : ℝ → ℝ,
      OrdinaryPIDSignals ((1+1/α)/(1+δ)) ρ ell δ E V ∧
      PhysicalPIDStep ((1+1/α)/(1+δ)) ρ ell δ E V ∧
      absArea E halfLine=α*(1+δ)/(1+α) ∧ absArea V halfLine=(1+δ)/(1+α) ∧
      miace α E V halfLine=(1+δ)*minimum α ∧
      ∀ e v : ℝ → ℝ, TransferResponse e v (fun p => 1/(1+p)) δ →
        miace α E V halfLine≤miace α e v halfLine := by
  obtain ⟨E,V,hs,he,hv,hcost,hglobal⟩ := twoRate_ordinary_optimum hα h
  exact ⟨E,V,hs,ordinary_PID_physical_step h hs,he,hv,hcost,hglobal⟩

-- @paper-step thm:pid_two_rate_optimum/balanced_physical_step_certificate
theorem balanced_physical_PID :
    let i : ℝ := 8/5
    let δ : ℝ := 1/4
    let ρ := pidRho i δ 5 6
    let ell := pidLead i δ 5 ρ
    ∃ E V : ℝ → ℝ, OrdinaryPIDSignals i ρ ell δ E V ∧ PhysicalPIDStep i ρ ell δ E V ∧
      absArea E halfLine=5/8 ∧ absArea V halfLine=5/8 ∧
      miace 1 E V halfLine=(5/4)*minimum 1 := by
  obtain ⟨E,V,hs,he,hv,hc⟩ := balanced_ordinary_PID
  exact ⟨E,V,hs,ordinary_PID_physical_step balanced_twoRate_data hs,he,hv,hc⟩

end MIACE
