import MIACE.Dynamics
import MIACE.Cap
import Mathlib.Analysis.SpecialFunctions.ImproperIntegrals

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def moment (v : ℝ → ℝ) : ℝ := ∫ t, Real.exp t * v t ∂halfLine
noncomputable def commandArea (v : ℝ → ℝ) : ℝ := ∫ t, v t ∂halfLine
noncomputable def pulse (c T : ℝ) : ℝ → ℝ := (Ioc 0 T).indicator (fun _ => c)

-- @paper-step thm:n_necessary/strict_area
 theorem area_lt_moment {v : ℝ → ℝ} (hv : Integrable v halfLine)
    (hJ : Integrable (fun t => Real.exp t*v t) halfLine)
    (hn : ∀ᵐ t ∂halfLine, 0 ≤ v t) (hU : 0 < commandArea v) :
    commandArea v < moment v := by
  have ht : ∀ᵐ t ∂halfLine, 0 < t := ae_restrict_mem measurableSet_Ioi
  have hle : v ≤ᵐ[halfLine] (fun t => Real.exp t*v t) := by
    filter_upwards [ht,hn] with t ht hn
    have hexp : 1 < Real.exp t := Real.one_lt_exp_iff.mpr ht
    nlinarith
  have hi : commandArea v ≤ moment v := integral_mono_ae hv hJ hle
  apply lt_of_le_of_ne hi
  intro heq
  have heqae := (integral_eq_iff_of_ae_le hv hJ hle).mp heq
  have hz : v =ᵐ[halfLine] 0 := by
    filter_upwards [heqae,ht,hn] with t heq ht hn
    have hexp : 1 < Real.exp t := Real.one_lt_exp_iff.mpr ht
    change v t = 0
    nlinarith
  have hi0 : commandArea v = 0 := by
    unfold commandArea
    rw [integral_congr_ae hz]
    simp
  linarith

-- @paper-step thm:command_cone/strictness
 theorem area_lt_one_of_moment {v : ℝ → ℝ} (hv : Integrable v halfLine)
    (hJ : Integrable (fun t => Real.exp t*v t) halfLine)
    (hn : ∀ᵐ t ∂halfLine, 0 ≤ v t) (hm : moment v ≤ 1) : commandArea v < 1 := by
  have hU : 0 ≤ commandArea v := integral_nonneg_of_ae hn
  rcases hU.eq_or_lt with hz | hp
  · linarith
  · exact (area_lt_moment hv hJ hn hp).trans_le hm

-- @paper-step thm:complete_cap/pulse_integrable
 theorem pulse_integrable (c T : ℝ) : Integrable (pulse c T) halfLine := by
  have hi : IntegrableOn (fun _ : ℝ => c) (Ioc 0 T) :=
    continuous_const.integrableOn_Icc.mono_set Ioc_subset_Icc_self
  exact (hi.integrable_indicator measurableSet_Ioc).mono_measure Measure.restrict_le_self

-- @paper-step thm:complete_cap/pulse_weighted_identity
 theorem weighted_pulse (c T : ℝ) :
    (fun t => Real.exp t*pulse c T t) = (Ioc 0 T).indicator (fun t => c*Real.exp t) := by
  funext t
  by_cases ht : t ∈ Ioc 0 T <;> simp [pulse,ht,mul_comm]

-- @paper-step thm:complete_cap/pulse_moment_integrable
 theorem pulse_moment_integrable (c T : ℝ) :
    Integrable (fun t => Real.exp t*pulse c T t) halfLine := by
  rw [weighted_pulse]
  have hi : IntegrableOn (fun t : ℝ => c*Real.exp t) (Ioc 0 T) :=
    (continuous_const.mul Real.continuous_exp).integrableOn_Icc.mono_set Ioc_subset_Icc_self
  exact (hi.integrable_indicator measurableSet_Ioc).mono_measure Measure.restrict_le_self

-- @paper-step thm:complete_cap/pulse_area
 theorem pulse_area (c T : ℝ) (hT : 0 ≤ T) : commandArea (pulse c T) = c*T := by
  unfold commandArea pulse halfLine
  rw [integral_indicator measurableSet_Ioc, Measure.restrict_restrict measurableSet_Ioc]
  have hs : Ioc 0 T ∩ Ioi (0 : ℝ) = Ioc 0 T := inter_eq_left.mpr (fun _ ht => ht.1)
  rw [hs, ← intervalIntegral.integral_of_le hT]
  simp [mul_comm]

-- @paper-step thm:complete_cap/pulse_integrals
 theorem pulse_moment (c T : ℝ) (hT : 0 ≤ T) : moment (pulse c T) = c*(Real.exp T-1) := by
  unfold moment
  rw [weighted_pulse]
  unfold halfLine
  rw [integral_indicator measurableSet_Ioc, Measure.restrict_restrict measurableSet_Ioc]
  have hs : Ioc 0 T ∩ Ioi (0 : ℝ) = Ioc 0 T := inter_eq_left.mpr (fun _ ht => ht.1)
  rw [hs, ← intervalIntegral.integral_of_le hT, intervalIntegral.integral_const_mul, integral_exp]
  simp

-- @paper-step thm:complete_cap/rearrangement_pointwise
 theorem pulse_rearrangement_nonneg (c T t z : ℝ) (ht : 0 < t)
    (hz : 0 ≤ z) (hzc : z ≤ c) :
    0 ≤ (Real.exp t-Real.exp T)*(z-pulse c T t) := by
  by_cases h : t ≤ T
  · have he : Real.exp t ≤ Real.exp T := Real.exp_le_exp.mpr h
    simp only [pulse, mem_Ioc, ht, h, and_self, indicator_of_mem, sub_nonpos] at *
    exact mul_nonneg_of_nonpos_of_nonpos (sub_nonpos.mpr he) (sub_nonpos.mpr hzc)
  · have he : Real.exp T ≤ Real.exp t := Real.exp_le_exp.mpr (le_of_not_ge h)
    have hnot : t ∉ Ioc 0 T := fun hm => h hm.2
    simp only [pulse, indicator_of_notMem hnot, sub_zero]
    exact mul_nonneg (sub_nonneg.mpr he) hz

-- @paper-step thm:complete_cap/rearrangement_identity
 theorem rearrangement_identity {v : ℝ → ℝ} (c T : ℝ)
    (hv : Integrable v halfLine) (hJ : Integrable (fun t => Real.exp t*v t) halfLine) :
    (∫ t, (Real.exp t-Real.exp T)*(v t-pulse c T t) ∂halfLine) =
      moment v - moment (pulse c T) - Real.exp T*(commandArea v-commandArea (pulse c T)) := by
  have hp := pulse_integrable c T
  have hJp := pulse_moment_integrable c T
  calc
    _ = ∫ t, ((Real.exp t*v t)-(Real.exp t*pulse c T t)) -
        Real.exp T*(v t-pulse c T t) ∂halfLine := by
      apply integral_congr_ae
      exact ae_of_all _ (fun t => by ring)
    _ = _ := by
      have hl : Integrable (fun t => Real.exp t*v t-Real.exp t*pulse c T t) halfLine := hJ.sub hJp
      have hr : Integrable (fun t => Real.exp T*(v t-pulse c T t)) halfLine := (hv.sub hp).const_mul _
      rw [integral_sub hl hr,
        integral_sub hJ hJp, integral_const_mul, integral_sub hv hp]
      rfl

-- @paper-step thm:complete_cap/rearrangement
 theorem pulse_minimizes_moment {v : ℝ → ℝ} (c T : ℝ) (hT : 0 ≤ T)
    (hv : Integrable v halfLine) (hJ : Integrable (fun t => Real.exp t*v t) halfLine)
    (hcap : ∀ᵐ t ∂halfLine, 0 ≤ v t ∧ v t ≤ c)
    (harea : commandArea v = c*T) : c*(Real.exp T-1) ≤ moment v := by
  have hnonneg : 0 ≤ ∫ t, (Real.exp t-Real.exp T)*(v t-pulse c T t) ∂halfLine := by
    apply integral_nonneg_of_ae
    filter_upwards [hcap,ae_restrict_mem measurableSet_Ioi] with t ht htpos
    exact pulse_rearrangement_nonneg c T t (v t) htpos ht.1 ht.2
  rw [rearrangement_identity c T hv hJ, harea, pulse_area c T hT,
    sub_self, mul_zero, sub_zero, pulse_moment c T hT] at hnonneg
  linarith

-- @paper-step thm:complete_cap/necessary_capacity
 theorem cap_area_necessary {v : ℝ → ℝ} (c : ℝ) (hc : 0 < c)
    (hv : Integrable v halfLine) (hJ : Integrable (fun t => Real.exp t*v t) halfLine)
    (hcap : ∀ᵐ t ∂halfLine, 0 ≤ v t ∧ v t ≤ c) (hm : moment v ≤ 1) :
    commandArea v ≤ c*Real.log (1+1/c) := by
  have hU : 0 ≤ commandArea v := integral_nonneg_of_ae (hcap.mono fun _ h => h.1)
  have hT : 0 ≤ commandArea v/c := div_nonneg hU hc.le
  have harea : commandArea v = c*(commandArea v/c) := by field_simp
  have hb := pulse_minimizes_moment c (commandArea v/c) hT hv hJ hcap harea
  exact (pulse_moment_criterion c (commandArea v) hc).mp (hb.trans hm)

-- @paper-step thm:complete_cap/pulse_uniqueness
 theorem pulse_unique_of_equal_moment {v : ℝ → ℝ} (c T : ℝ)
    (hv : Integrable v halfLine) (hJ : Integrable (fun t => Real.exp t*v t) halfLine)
    (hcap : ∀ᵐ t ∂halfLine, 0 ≤ v t ∧ v t ≤ c)
    (harea : commandArea v = commandArea (pulse c T))
    (hmoment : moment v = moment (pulse c T)) : v =ᵐ[halfLine] pulse c T := by
  let g := fun t => (Real.exp t-Real.exp T)*(v t-pulse c T t)
  have hp := pulse_integrable c T
  have hJp := pulse_moment_integrable c T
  have hg : Integrable g halfLine := by
    apply ((hJ.sub hJp).sub ((hv.sub hp).const_mul (Real.exp T))).congr
    exact ae_of_all _ (fun t => by dsimp [g]; ring)
  have hn : 0 ≤ᵐ[halfLine] g := by
    filter_upwards [hcap,ae_restrict_mem measurableSet_Ioi] with t ht htpos
    exact pulse_rearrangement_nonneg c T t (v t) htpos ht.1 ht.2
  have hi : (∫ t, g t ∂halfLine) = 0 := by
    rw [rearrangement_identity c T hv hJ, harea, hmoment]
    ring
  have hz := (integral_eq_zero_iff_of_nonneg_ae hn hg).mp hi
  have hne : ∀ᵐ t ∂halfLine, t ≠ T := by
    apply ae_restrict_of_ae
    rw [ae_iff]
    simp
  filter_upwards [hz,hne] with t ht hneq
  have hexp : Real.exp t-Real.exp T ≠ 0 := sub_ne_zero.mpr (Real.exp_injective.ne hneq)
  change (Real.exp t-Real.exp T)*(v t-pulse c T t) = 0 at ht
  exact sub_eq_zero.mp ((mul_eq_zero.mp ht).resolve_left hexp)

-- @paper-step thm:complete_cap/sufficient_capacity
 theorem cap_area_sufficient (c U : ℝ) (hc : 0 < c) (hU : 0 ≤ U)
    (hcap : U ≤ c*Real.log (1+1/c)) :
    Integrable (pulse c (U/c)) halfLine ∧
    Integrable (fun t => Real.exp t*pulse c (U/c) t) halfLine ∧
    (∀ᵐ t ∂halfLine, 0 ≤ pulse c (U/c) t ∧ pulse c (U/c) t ≤ c) ∧
    commandArea (pulse c (U/c)) = U ∧ moment (pulse c (U/c)) ≤ 1 := by
  have hT : 0 ≤ U/c := div_nonneg hU hc.le
  refine ⟨pulse_integrable _ _,pulse_moment_integrable _ _,?_,?_,?_⟩
  · apply ae_of_all
    intro t
    by_cases ht : t ∈ Ioc 0 (U/c) <;> simp [pulse,ht,hc.le]
  · rw [pulse_area _ _ hT]
    field_simp
  · rw [pulse_moment _ _ hT]
    exact (pulse_moment_criterion c U hc).mpr hcap

-- @paper-step thm:complete_cap/exact_moment_class
 theorem capped_moment_area_iff (c U : ℝ) (hc : 0 < c) :
    (∃ v : ℝ → ℝ, Integrable v halfLine ∧
      Integrable (fun t => Real.exp t*v t) halfLine ∧
      (∀ᵐ t ∂halfLine, 0 ≤ v t ∧ v t ≤ c) ∧
      commandArea v = U ∧ moment v ≤ 1) ↔
    0 ≤ U ∧ U ≤ c*Real.log (1+1/c) := by
  constructor
  · rintro ⟨v,hv,hJ,hcap,harea,hm⟩
    rw [← harea]
    exact ⟨integral_nonneg_of_ae (hcap.mono fun _ h => h.1),
      cap_area_necessary c hc hv hJ hcap hm⟩
  · rintro ⟨hU,hcap⟩
    exact ⟨pulse c (U/c),cap_area_sufficient c U hc hU hcap⟩

-- @paper-step thm:n_necessary/threshold_from_moment
 theorem necessary_weight_from_moment {v : ℝ → ℝ} (α S : ℝ) (hα : 0 < α)
    (hv : Integrable v halfLine) (hJ : Integrable (fun t => Real.exp t*v t) halfLine)
    (hn : ∀ᵐ t ∂halfLine, 0 ≤ v t) (hm : moment v ≤ 1)
    (harea : commandArea v = S/(1+α)) : S-1 < α := by
  apply (attainment_threshold α S hα).mp
  rw [← harea]
  exact area_lt_one_of_moment hv hJ hn hm

end MIACE
