import MIACE.TwoRateIntegrals

/-! Събраният сертификат за двата действителни L¹ реда.
    Това е сертификат за сигнали на интегралното уравнение, не още теорема
    за всички вътрешни състояния и истории на физическия PID с транспортно закъснение. -/
set_option maxHeartbeats 1200000
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

structure TwoRateData (i ρ ell l m δ : ℝ) : Prop where
  integral_pos : 0 < i
  filter_pos : 0 < ρ
  filter_lt_one : ρ < 1
  lead_gt_filter : ρ < ell
  delay_nonneg : 0 ≤ δ
  lower_rate : 1 < l
  ordered_rates : l < m
  filter_lower : m ≤ 1/ρ
  filter_upper : 1/ρ ≤ l+m-1
  root_l : i*(1-ell*l)=l*(1-ρ*l)*Real.exp (-l*δ)
  root_m : i*(1-ell*m)=m*(1-ρ*m)*Real.exp (-m*δ)
  initial_forcing : ∀ t ∈ Icc (0 : ℝ) δ,
    0 ≤ twoRateR (twoRateA ρ l m) l m δ t

-- @paper-step thm:pid_two_rate_optimum/explicit_parameters_certificate
theorem twoRate_data_from_formulas {i l m δ : ℝ} (hi : 0 < i) (hl : 1 < l)
    (hlm : l < m) (hδ : 0 ≤ δ)
    (hd : l*Real.exp (-l*δ)-m*Real.exp (-m*δ) ≠ 0)
    (hρ : 0 < pidRho i δ l m) (hρ1 : pidRho i δ l m < 1)
    (hell : pidRho i δ l m < pidLead i δ l (pidRho i δ l m))
    (hlo : m ≤ 1/pidRho i δ l m) (hhi : 1/pidRho i δ l m ≤ l+m-1)
    (hinit : ∀ t ∈ Icc (0 : ℝ) δ,
      0 ≤ twoRateR (twoRateA (pidRho i δ l m) l m) l m δ t) :
    TwoRateData i (pidRho i δ l m) (pidLead i δ l (pidRho i δ l m)) l m δ := by
  have hl0 : l ≠ 0 := ne_of_gt (by linarith)
  have hm0 : m ≠ 0 := ne_of_gt (by linarith)
  exact ⟨hi,hρ,hρ1,hell,hδ,hl,hlm,hlo,hhi,
    pidLead_first_root (ne_of_gt hi) hl0 δ _,
    pidRho_second_root (ne_of_gt hi) hl0 hm0 hd,hinit⟩

-- @paper-step thm:pid_two_rate_optimum/scalar_checks_certificate
theorem twoRate_simple_checks {ρ l m δ : ℝ} (hl : 1 < l) (hlm : l < m)
    (hr : m ≤ 1/ρ)
    (hc₁ : 0 ≤ (l-1)*Real.exp (-l*δ)-1)
    (hc₂ : 0 ≤ (m-1)*Real.exp (-m*δ)-1)
    (hcheck : (twoRateA ρ l m-1)*((m-1)*Real.exp (-m*δ)-1) ≤ twoRateG (twoRateA ρ l m) l m δ) :
    ∀ t ∈ Icc (0 : ℝ) δ, 0 ≤ twoRateR (twoRateA ρ l m) l m δ t := by
  intro t ht
  exact twoRateR_initial_nonneg (twoRateA_ge_one hlm hr) (by linarith) hc₁ hc₂ hcheck ht.1 ht.2

-- @paper-step thm:pid_two_rate_optimum/positive_causal_L1_forcing
theorem causalize_toL1_nonneg {f : ℝ → ℝ} (hf : Integrable (causalize f))
    (hn : ∀ t ∈ Ici (0 : ℝ), 0 ≤ f t) : 0 ≤ hf.toL1 (causalize f) := by
  rw [← Lp.coeFn_nonneg]
  filter_upwards [hf.coeFn_toL1] with t ht
  rw [ht]
  by_cases h : t ∈ Ici (0 : ℝ)
  · rw [causalize,indicator_of_mem h]
    exact hn t h
  · simp [causalize,h]

-- @paper-step thm:pid_two_rate_optimum/weighted_L1_forcing_coercion
theorem expWeight_toL1_integrable {f : ℝ → ℝ} (hf : Integrable f) {η : ℝ}
    (hw : Integrable (expWeight η f)) :
    Integrable (expWeight η (hf.toL1 f)) volume := by
  apply hw.congr
  filter_upwards [hf.coeFn_toL1] with t ht
  simp only [expWeight,ht]

-- @paper-step thm:pid_two_rate_optimum/assembled_positive_weighted_signals
theorem twoRate_signal_certificate {i ρ ell l m δ : ℝ} (h : TwoRateData i ρ ell l m δ) :
    let A := twoRateA ρ l m
    let hK := twoRateK_integrable A l m δ
    let hG := twoRateG_integrable A (by linarith [h.lower_rate] : 0<l)
      (by linarith [h.lower_rate,h.ordered_rates] : 0<m)
    let hR := twoRateR_integrable A δ (by linarith [h.lower_rate] : 0<l)
      (by linarith [h.lower_rate,h.ordered_rates] : 0<m)
    let G := hG.toL1 (causalize (twoRateG A l m))
    let R := hR.toL1 (causalize (twoRateR A l m δ))
    let T := convOp hK
    let e := (∑' n : ℕ, T^n) G
    let v := (∑' n : ℕ, T^n) R
    HasSum (fun n : ℕ => (T^n) G) e ∧ HasSum (fun n : ℕ => (T^n) R) v ∧
      Summable (fun n : ℕ => ‖(T^n) G‖) ∧ Summable (fun n : ℕ => ‖(T^n) R‖) ∧
      0 ≤ e ∧ 0 ≤ v ∧ Causal e ∧ Causal v ∧
      e=G+T e ∧ v=R+T v ∧
      (∀ z : RealL1, z=G+T z → z=e) ∧ (∀ z : RealL1, z=R+T z → z=v) ∧
      (∫ t, e t)=1/i ∧ (∫ t, v t)=1+δ-1/i ∧
      (∃ η : ℝ, 0 < η ∧ η ≤ 1/2 ∧
        Integrable (expWeight η e) volume ∧ Integrable (expWeight η v) volume) := by
  dsimp only
  let A := twoRateA ρ l m
  have hl : 0 < l := by linarith [h.lower_rate]
  have hm : 0 < m := by linarith [h.lower_rate,h.ordered_rates]
  let hK := twoRateK_integrable A l m δ
  let hG := twoRateG_integrable A hl hm
  let hR := twoRateR_integrable A δ hl hm
  let G := hG.toL1 (causalize (twoRateG A l m))
  let R := hR.toL1 (causalize (twoRateR A l m δ))
  have hA := twoRateA_ge_one h.ordered_rates h.filter_lower
  have hzero := twoRate_rate_condition h.ordered_rates h.filter_upper
  have hKn : ∀ᵐ t, 0 ≤ twoRateK A l m δ t :=
    ae_of_all volume (twoRateK_nonneg hA h.lower_rate h.ordered_rates.le hzero)
  have hKc := twoRateK_causal A l m δ
  have hq := twoRateK_small hA h.ordered_rates.le h.delay_nonneg
  have hGn : 0 ≤ G := causalize_toL1_nonneg hG
    (fun t ht => (twoRateG_positive hA h.ordered_rates.le ht).le)
  have hRn : 0 ≤ R := causalize_toL1_nonneg hR
    (twoRateR_nonneg hA h.lower_rate h.ordered_rates.le hzero h.delay_nonneg h.initial_forcing)
  have hGc : Causal G := causal_congr (causalize_causal _) hG.coeFn_toL1.symm
  have hRc : Causal R := causal_congr (causalize_causal _) hR.coeFn_toL1.symm
  obtain ⟨heS,hen,hec,hee,heu,_,_⟩ := positive_resolvent_all_parts hK hKn hKc hq G hGn hGc
  obtain ⟨hvS,hvn,hvc,hve,hvu,_,_⟩ := positive_resolvent_all_parts hK hKn hKc hq R hRn hRc
  refine ⟨heS,hvS,renewal_absolute_convergence hK hKn hq G,
    renewal_absolute_convergence hK hKn hq R,hen,hvn,hec,hvc,hee,hve,heu,hvu,?_,?_,?_⟩
  · have heint := renewal_integral_balance hK G _ hee
    have hgm := twoRate_gain_mass (ne_of_gt h.filter_pos) (ne_of_gt hl)
      (ne_of_gt hm) (ne_of_lt h.ordered_rates) h.root_l h.root_m
    have hGint : (∫ t, G t)=A/l+(1-A)/m :=
      (integral_congr_ae hG.coeFn_toL1).trans (twoRateG_integral A hl hm)
    rw [twoRateK_integral A l m h.delay_nonneg,hGint] at heint
    have hgpos := twoRateG_positive hA h.ordered_rates.le h.delay_nonneg
    have hgmpos : 0 < A/l+(1-A)/m := by
      change 0 < twoRateG A l m δ at hgpos
      change twoRateG A l m δ=i*(A/l+(1-A)/m) at hgm
      nlinarith [h.integral_pos]
    rw [hgm] at heint
    apply (eq_div_iff (ne_of_gt h.integral_pos)).mpr
    nlinarith
  · have heint := renewal_integral_balance hK R _ hve
    have hgm := twoRate_gain_mass (ne_of_gt h.filter_pos) (ne_of_gt hl)
      (ne_of_gt hm) (ne_of_lt h.ordered_rates) h.root_l h.root_m
    have hRint : (∫ t, R t)=(1+δ)*twoRateG A l m δ-(A/l+(1-A)/m) :=
      (integral_congr_ae hR.coeFn_toL1).trans (twoRateR_integral A hl hm h.delay_nonneg)
    rw [twoRateK_integral A l m h.delay_nonneg,hRint] at heint
    have hgpos := twoRateG_positive hA h.ordered_rates.le h.delay_nonneg
    change twoRateG A l m δ=i*(A/l+(1-A)/m) at hgm
    have hz : twoRateG A l m δ / i=A/l+(1-A)/m := by
      rw [hgm]
      field_simp [ne_of_gt h.integral_pos]
    apply mul_left_cancel₀ (ne_of_gt hgpos)
    calc
      _ = (1+δ)*twoRateG A l m δ-(A/l+(1-A)/m) := by nlinarith [heint]
      _ = _ := by rw [← hz]; ring
  · obtain ⟨η,hη,hle,hKw,hqw⟩ := expWeight_small_mass hK hq (by norm_num : (0 : ℝ)<1/2)
      (twoRateK_weighted A l m δ (1/2))
    have hηl : η < l := by linarith [h.lower_rate]
    have hηm : η < m := by linarith [h.lower_rate,h.ordered_rates]
    have hGw := expWeight_toL1_integrable hG (twoRateG_weighted A hηl hηm)
    have hRw := expWeight_toL1_integrable hR (twoRateR_weighted A δ hηl hηm)
    obtain ⟨he,_,_⟩ := positive_resolvent_weighted hK hKn hKc hq hη.le hKw hqw G hGn hGc hGw
    obtain ⟨hv,_,_⟩ := positive_resolvent_weighted hK hKn hKc hq hη.le hKw hqw R hRn hRc hRw
    exact ⟨η,hη,hle,he,hv⟩

end MIACE
