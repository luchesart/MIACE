import MIACE.ScalarDelaySpectrum
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus
import Mathlib.Analysis.Calculus.ParametricIntegral

/-! Trigonometric history windows for the exact scalar-delay Lyapunov
functional. Primitives make their time derivatives valid even when the
initial history is merely continuous, rather than differentiable. -/
namespace MIACE
open MeasureTheory Set Filter
open scoped Topology

noncomputable def trigPrimitive (c w : ℝ → ℝ) (t : ℝ) : ℝ :=
  ∫ r in (0 : ℝ)..t, c r*w r

noncomputable def delayCosWindow (h : ℝ) (w : ℝ → ℝ) (t s : ℝ) : ℝ :=
  Real.cos (h-t)*(trigPrimitive Real.cos w t-trigPrimitive Real.cos w (t-h+s))-
  Real.sin (h-t)*(trigPrimitive Real.sin w t-trigPrimitive Real.sin w (t-h+s))

noncomputable def delaySinWindow (h : ℝ) (w : ℝ → ℝ) (t s : ℝ) : ℝ :=
  Real.sin (h-t)*(trigPrimitive Real.cos w t-trigPrimitive Real.cos w (t-h+s))+
  Real.cos (h-t)*(trigPrimitive Real.sin w t-trigPrimitive Real.sin w (t-h+s))

-- @paper-step lem:delayed_cancellation/continuous_history_primitive_derivative
theorem trigPrimitive_deriv {c w : ℝ → ℝ} (hc : Continuous c)
    (hw : Continuous w) (t : ℝ) :
    HasDerivAt (trigPrimitive c w) (c t*w t) t := by
  exact intervalIntegral.integral_hasDerivAt_right ((hc.mul hw).intervalIntegrable 0 t)
    ((hc.mul hw).stronglyMeasurableAtFilter _ _) (hc.mul hw).continuousAt

-- @paper-step lem:delayed_cancellation/continuous_history_primitive_continuity
theorem trigPrimitive_continuous {c w : ℝ → ℝ} (hc : Continuous c)
    (hw : Continuous w) : Continuous (trigPrimitive c w) := by
  exact continuous_iff_continuousAt.mpr (fun t => (trigPrimitive_deriv hc hw t).continuousAt)

-- @paper-step lem:delayed_cancellation/joint_continuity_of_history_windows
theorem delayWindows_continuous {w : ℝ → ℝ} (hw : Continuous w) (h : ℝ) :
    Continuous (fun p : ℝ × ℝ => delayCosWindow h w p.1 p.2) ∧
    Continuous (fun p : ℝ × ℝ => delaySinWindow h w p.1 p.2) := by
  have hc := trigPrimitive_continuous Real.continuous_cos hw
  have hs := trigPrimitive_continuous Real.continuous_sin hw
  constructor <;> simp only [delayCosWindow,delaySinWindow] <;> fun_prop

-- @paper-step lem:delayed_cancellation/history_window_terminal_values
theorem delayWindows_terminal (h t : ℝ) (w : ℝ → ℝ) :
    delayCosWindow h w t h=0 ∧ delaySinWindow h w t h=0 := by
  simp [delayCosWindow,delaySinWindow]

-- @paper-step lem:delayed_cancellation/history_window_spatial_derivatives
theorem delayWindows_space_deriv {w : ℝ → ℝ} (hw : Continuous w) (h t s : ℝ) :
    HasDerivAt (delayCosWindow h w t) (-Real.cos s*w (t-h+s)) s ∧
    HasDerivAt (delaySinWindow h w t) (-Real.sin s*w (t-h+s)) s := by
  have ha : HasDerivAt (fun r : ℝ => t-h+r) 1 s := by simpa using (hasDerivAt_id s).const_add (t-h)
  have hc := (trigPrimitive_deriv Real.continuous_cos hw (t-h+s)).comp s ha
  have hs := (trigPrimitive_deriv Real.continuous_sin hw (t-h+s)).comp s ha
  have hcos : Real.cos (h-t)*Real.cos (t-h+s)-Real.sin (h-t)*Real.sin (t-h+s)=Real.cos s := by
    rw [← Real.cos_add]; congr 1 <;> ring
  have hsin : Real.sin (h-t)*Real.cos (t-h+s)+Real.cos (h-t)*Real.sin (t-h+s)=Real.sin s := by
    rw [← Real.sin_add]; congr 1 <;> ring
  constructor
  · convert ((hc.const_sub _).const_mul (Real.cos (h-t))).sub
      ((hs.const_sub _).const_mul (Real.sin (h-t))) using 1
    · rfl
    · linear_combination w (t-h+s)*hcos
  · convert ((hc.const_sub _).const_mul (Real.sin (h-t))).add
      ((hs.const_sub _).const_mul (Real.cos (h-t))) using 1
    · rfl
    · linear_combination w (t-h+s)*hsin

-- @paper-step lem:delayed_cancellation/history_window_time_derivatives
theorem delayWindows_time_deriv {w : ℝ → ℝ} (hw : Continuous w) (h t s : ℝ) :
    HasDerivAt (fun u => delayCosWindow h w u s)
      (Real.cos h*w t-Real.cos s*w (t-h+s)+delaySinWindow h w t s) t ∧
    HasDerivAt (fun u => delaySinWindow h w u s)
      (Real.sin h*w t-Real.sin s*w (t-h+s)-delayCosWindow h w t s) t := by
  have ha : HasDerivAt (fun r : ℝ => r-h+s) 1 t := by
    simpa using ((hasDerivAt_id t).sub_const h).add_const s
  have hc := (trigPrimitive_deriv Real.continuous_cos hw t).sub
    ((trigPrimitive_deriv Real.continuous_cos hw (t-h+s)).comp t ha)
  have hs := (trigPrimitive_deriv Real.continuous_sin hw t).sub
    ((trigPrimitive_deriv Real.continuous_sin hw (t-h+s)).comp t ha)
  have hd := (hasDerivAt_id t).const_sub h
  have hcos : Real.cos (h-t)*Real.cos t-Real.sin (h-t)*Real.sin t=Real.cos h := by
    rw [← Real.cos_add]; congr 1 <;> ring
  have hsin : Real.sin (h-t)*Real.cos t+Real.cos (h-t)*Real.sin t=Real.sin h := by
    rw [← Real.sin_add]; congr 1 <;> ring
  have hcos' : Real.cos (h-t)*Real.cos (t-h+s)-Real.sin (h-t)*Real.sin (t-h+s)=Real.cos s := by
    rw [← Real.cos_add]; congr 1 <;> ring
  have hsin' : Real.sin (h-t)*Real.cos (t-h+s)+Real.cos (h-t)*Real.sin (t-h+s)=Real.sin s := by
    rw [← Real.sin_add]; congr 1 <;> ring
  constructor
  · convert (hd.cos.mul hc).sub (hd.sin.mul hs) using 1
    · rfl
    · dsimp [delaySinWindow]; linear_combination -w t*hcos+w (t-h+s)*hcos'
  · convert (hd.sin.mul hc).add (hd.cos.mul hs) using 1
    · rfl
    · dsimp [delayCosWindow]; linear_combination -w t*hsin+w (t-h+s)*hsin'

end MIACE
