import MIACE.SignedOrdinary
import MIACE.HistoryInput

/-! Етап 12: количествени оценки, затворени спрямо линейните операции,
    конволюцията и транспорта. Константите не зависят от историята. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

structure WeightedControl (η : ℝ) (f : ℝ → ℝ) (C : ℝ) : Prop where
  nonneg : 0≤C
  integrable : Integrable (expWeight η f)
  area : (∫ t, |expWeight η f t|)≤C
  bound : ∀ᵐ t, |expWeight η f t|≤C

-- @paper-step thm:pid_two_rate_optimum/weighted_control_addition
theorem weightedControl_add {η C D : ℝ} {f g : ℝ → ℝ}
    (hf : WeightedControl η f C) (hg : WeightedControl η g D) :
    WeightedControl η (fun t => f t+g t) (C+D) := by
  have he : expWeight η (fun t => f t+g t)=fun t => expWeight η f t+expWeight η g t := by
    funext t; simp [expWeight,mul_add]
  refine ⟨add_nonneg hf.nonneg hg.nonneg,?_,?_,?_⟩
  · rw [he]; exact hf.integrable.add hg.integrable
  · rw [he]
    have hh := integral_mono (hf.integrable.add hg.integrable).abs
      (hf.integrable.abs.add hg.integrable.abs) (fun t => abs_add_le _ _)
    simp only [Pi.add_apply] at hh
    rw [integral_add hf.integrable.abs hg.integrable.abs] at hh
    linarith [hf.area,hg.area]
  · filter_upwards [hf.bound,hg.bound] with t ht hs
    rw [he]
    exact (abs_add_le _ _).trans (add_le_add ht hs)

-- @paper-step thm:pid_two_rate_optimum/weighted_control_scaling
theorem weightedControl_smul {η C : ℝ} {f : ℝ → ℝ}
    (hf : WeightedControl η f C) (a : ℝ) :
    WeightedControl η (fun t => a*f t) (|a| *C) := by
  have he : expWeight η (fun t => a*f t)=fun t => a*expWeight η f t := by
    funext t; unfold expWeight; ring
  refine ⟨mul_nonneg (abs_nonneg _) hf.nonneg,?_,?_,?_⟩
  · rw [he]; exact hf.integrable.const_mul a
  · rw [he]
    simp_rw [abs_mul]
    rw [integral_const_mul]
    exact mul_le_mul_of_nonneg_left hf.area (abs_nonneg _)
  · filter_upwards [hf.bound] with t ht
    rw [he,abs_mul]
    exact mul_le_mul_of_nonneg_left ht (abs_nonneg _)

-- @paper-step thm:pid_two_rate_optimum/weighted_control_enlargement
theorem weightedControl_mono {η C D : ℝ} {f : ℝ → ℝ}
    (hf : WeightedControl η f C) (h : C≤D) : WeightedControl η f D :=
  ⟨hf.nonneg.trans h,hf.integrable,hf.area.trans h,hf.bound.mono (fun _ ht => ht.trans h)⟩

-- @paper-step thm:pid_two_rate_optimum/weighted_control_ae_invariance
theorem weightedControl_congr {η C : ℝ} {f g : ℝ → ℝ}
    (hf : WeightedControl η f C) (he : f=ᵐ[volume] g) : WeightedControl η g C := by
  have hw : expWeight η f=ᵐ[volume] expWeight η g := by
    filter_upwards [he] with t ht; simp only [expWeight,ht]
  refine ⟨hf.nonneg,hf.integrable.congr hw,?_,?_⟩
  · have hi := integral_congr_ae (hw.fun_comp abs)
    simp only [Function.comp_def] at hi
    rw [← hi]; exact hf.area
  · filter_upwards [hf.bound,hw] with t ht hh; rw [← hh]; exact ht

-- @paper-step thm:pid_two_rate_optimum/weighted_control_convolution_bound
theorem weighted_convolution_bound {η C : ℝ} {f g : ℝ → ℝ}
    (hC : 0≤C) (hf : ∀ᵐ t, |expWeight η f t|≤C)
    (hg : Integrable (expWeight η g)) (t : ℝ) :
    |expWeight η (f ⋆ g) t|≤C*(∫ s, |expWeight η g s|) := by
  rw [expWeight_convolution]
  change ‖∫ s, expWeight η f s*expWeight η g (t-s)‖≤_
  have hh := norm_integral_le_of_norm_le ((hg.abs.comp_sub_left t).const_mul C)
    (hf.mono (fun s hs => by
      rw [Real.norm_eq_abs,abs_mul]
      exact mul_le_mul_of_nonneg_right hs (abs_nonneg _)))
  rw [integral_const_mul,integral_sub_left_eq_self (fun s => |expWeight η g s|) volume t] at hh
  exact hh

-- @paper-step thm:pid_two_rate_optimum/weighted_control_convolution
theorem weightedControl_convolution {η C D : ℝ} {f g : ℝ → ℝ}
    (hf : WeightedControl η f C) (hg : WeightedControl η g D) :
    WeightedControl η (f ⋆ g) (C*D) := by
  refine ⟨mul_nonneg hf.nonneg hg.nonneg,?_,?_,?_⟩
  · rw [expWeight_convolution]
    exact hf.integrable.integrable_convolution (ContinuousLinearMap.lsmul ℝ ℝ) hg.integrable
  · rw [expWeight_convolution]
    exact (convolution_absArea hf.integrable hg.integrable).trans
      (mul_le_mul hf.area hg.area (integral_nonneg (fun _ => abs_nonneg _)) hf.nonneg)
  · exact ae_of_all _ (fun t => (weighted_convolution_bound hf.nonneg hf.bound hg.integrable t).trans
      (mul_le_mul_of_nonneg_left hg.area hf.nonneg))

-- @paper-step thm:pid_two_rate_optimum/weighted_translation_identity
theorem expWeight_shift (η δ : ℝ) (f : ℝ → ℝ) :
    expWeight η (shift δ f)=fun t => Real.exp (η*δ)*shift δ (expWeight η f) t := by
  funext t
  simp only [expWeight,shift,← mul_assoc,← Real.exp_add]
  congr 2
  ring

-- @paper-step thm:pid_two_rate_optimum/weighted_control_transport
theorem weightedControl_shift {η C : ℝ} {f : ℝ → ℝ}
    (hf : WeightedControl η f C) (δ : ℝ) :
    WeightedControl η (shift δ f) (Real.exp (η*δ)*C) := by
  refine ⟨mul_nonneg (Real.exp_nonneg _) hf.nonneg,?_,?_,?_⟩
  · rw [expWeight_shift]
    exact (shift_integrable δ hf.integrable).const_mul _
  · rw [expWeight_shift]
    simp_rw [abs_mul,abs_of_pos (Real.exp_pos _)]
    rw [integral_const_mul]
    apply mul_le_mul_of_nonneg_left _ (Real.exp_nonneg _)
    change absArea (MIACE.shift δ (expWeight η f)) volume≤C
    rw [shift_absArea]
    exact hf.area
  · have hh := (measurePreserving_sub_right (volume : Measure ℝ) δ).quasiMeasurePreserving.tendsto_ae.eventually hf.bound
    filter_upwards [hh] with t ht
    rw [expWeight_shift,abs_mul,abs_of_pos (Real.exp_pos _)]
    exact mul_le_mul_of_nonneg_left ht (Real.exp_nonneg _)

-- @paper-step thm:pid_two_rate_optimum/causal_transport_preservation
theorem causal_shift {f : ℝ → ℝ} (hf : Causal f) {δ : ℝ} (hδ : 0≤δ) :
    Causal (shift δ f) := by
  have hh := (measurePreserving_sub_right (volume : Measure ℝ) δ).quasiMeasurePreserving.tendsto_ae.eventually hf
  filter_upwards [hh] with t ht hneg
  exact ht (by linarith)

-- @paper-step thm:pid_two_rate_optimum/causal_function_linear_combination
theorem causal_linear {f g : ℝ → ℝ} (hf : Causal f) (hg : Causal g) (a b : ℝ) :
    Causal (fun t => a*f t+b*g t) := by
  filter_upwards [hf,hg] with t ht hs hn
  simp [ht hn,hs hn]

-- @paper-step thm:pid_two_rate_optimum/causal_weighted_control_integrability
theorem weightedControl_unweighted {η C : ℝ} {f : ℝ → ℝ}
    (hf : WeightedControl η f C) (hc : Causal f) (hη : 0≤η) : Integrable f := by
  have hh := expWeight_negative_integrable hf.integrable (expWeight_causal η hc) hη
  rwa [expWeight_inverse] at hh

-- @paper-step thm:pid_two_rate_optimum/weighted_control_exponential_estimate
theorem weightedControl_decay {η C : ℝ} {f : ℝ → ℝ}
    (hf : WeightedControl η f C) : ∀ᵐ t, |f t|≤C*Real.exp (-η*t) := by
  filter_upwards [hf.bound] with t ht
  have hh := mul_le_mul_of_nonneg_left ht (Real.exp_nonneg (-η*t))
  have he : Real.exp (-η*t)*|expWeight η f t|=|f t| := by
    rw [← abs_of_pos (Real.exp_pos (-η*t)),← abs_mul]
    exact congrArg abs (congrFun (expWeight_inverse η f) t)
  rw [he] at hh
  simpa [mul_comm] using hh

end MIACE
