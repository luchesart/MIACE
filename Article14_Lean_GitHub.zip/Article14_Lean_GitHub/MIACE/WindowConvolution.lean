import MIACE.TwoRateAttainment
import Mathlib.MeasureTheory.Integral.IntervalIntegral.LebesgueDifferentiationThm

/-! Етап 9: обикновени времеви функции за отрязаните експоненциални ядра.
    Всички свойства се извеждат за произволен L¹ вход, без да се предполага
    неговата непрекъснатост или диференцируемост. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution
noncomputable def cutExp (r δ : ℝ) : ℝ → ℝ :=
  (Ico 0 δ).indicator (fun t => Real.exp (-r*t))

-- @paper-step thm:pid_two_rate_optimum/weighted_local_integrability
theorem l1_weighted_intervalIntegrable {f : ℝ → ℝ} (hf : Integrable f) (r a b : ℝ) :
    IntervalIntegrable (fun t => Real.exp (r*t)*f t) volume a b :=
  hf.intervalIntegrable.continuousOn_mul (by fun_prop)

-- @paper-step thm:pid_two_rate_optimum/primitive_absolute_continuity
theorem intervalPrimitive_ac {f : ℝ → ℝ}
    (hf : ∀ a b : ℝ, IntervalIntegrable f volume a b) (c a b : ℝ) :
    AbsolutelyContinuousOnInterval (fun t => ∫ s in c..t, f s) a b := by
  have hi := (hf a b).absolutelyContinuousOnInterval_intervalIntegral (left_mem_uIcc : a∈uIcc a b)
  have hc : AbsolutelyContinuousOnInterval (fun _ : ℝ => ∫ s in c..a, f s) a b := by
    apply ContDiffOn.absolutelyContinuousOnInterval; fun_prop
  apply (hc.add hi).congr
  intro t _
  exact intervalIntegral.integral_add_adjacent_intervals (hf c a) (hf a t)

-- @paper-step thm:pid_two_rate_optimum/shifted_primitive_absolute_continuity
theorem shiftedPrimitive_ac {f : ℝ → ℝ}
    (hf : ∀ a b : ℝ, IntervalIntegrable f volume a b) (c d a b : ℝ) :
    AbsolutelyContinuousOnInterval (fun t => ∫ s in c..t-d, f s) a b := by
  have hs : ∀ a b : ℝ, IntervalIntegrable (fun t => f (t-d)) volume a b := by
    intro a b
    simpa using (hf (a-d) (b-d)).comp_sub_right d
  have hi := intervalPrimitive_ac hs (c+d) a b
  apply hi.congr
  intro t _
  dsimp only
  rw [intervalIntegral.integral_comp_sub_right]
  simp

-- @paper-step thm:pid_two_rate_optimum/cut_exponential_convolution_integrability
theorem cutExp_convolution_integrable {f : ℝ → ℝ} (hf : Integrable f) (r δ t : ℝ) :
    Integrable (fun s => cutExp r δ s*f (t-s)) := by
  have he : (fun s => cutExp r δ s*f (t-s))=
      (Ico (0 : ℝ) δ).indicator (fun s => Real.exp (-r*s)*f (t-s)) := by
    funext s
    by_cases hs : s∈Ico (0 : ℝ) δ <;> simp [cutExp,hs]
  rw [he]
  apply IntegrableOn.integrable_indicator _ measurableSet_Ico
  apply IntegrableOn.mono_set _ Ico_subset_Icc_self
  exact ((hf.comp_sub_left t).integrableOn).continuousOn_mul
    (by fun_prop) isCompact_Icc

-- @paper-step thm:pid_two_rate_optimum/cut_exponential_window_formula
theorem cutExp_convolution_formula (r : ℝ) {δ : ℝ} (hδ : 0 ≤ δ)
    (f : ℝ → ℝ) (t : ℝ) :
    (cutExp r δ ⋆ f) t=
      Real.exp (-r*t)*(∫ s in t-δ..t, Real.exp (r*s)*f s) := by
  change (∫ s, cutExp r δ s*f (t-s))=_
  have he : (fun s => cutExp r δ s*f (t-s))=
      (Ico (0 : ℝ) δ).indicator (fun s => Real.exp (-r*s)*f (t-s)) := by
    funext s
    by_cases hs : s∈Ico (0 : ℝ) δ <;> simp [cutExp,hs]
  rw [he,integral_indicator measurableSet_Ico,integral_Ico_eq_integral_Ioc,
    ← intervalIntegral.integral_of_le hδ]
  have hx : (fun s => Real.exp (-r*s)*f (t-s))=
      (fun s => Real.exp (-r*(t-(t-s)))*f (t-s)) := by
    funext s; congr 2; ring
  rw [hx,intervalIntegral.integral_comp_sub_left (fun s => Real.exp (-r*(t-s))*f s) t]
  simp only [sub_zero]
  rw [← intervalIntegral.integral_const_mul]
  apply intervalIntegral.integral_congr
  intro s _
  have hh : Real.exp (-r*t)*Real.exp (r*s)=Real.exp (-r*(t-s)) := by
    rw [← Real.exp_add]; congr 1; ring
  dsimp only
  rw [← mul_assoc,hh]

-- @paper-step thm:pid_two_rate_optimum/cut_exponential_primitive_formula
theorem cutExp_convolution_primitive {f : ℝ → ℝ} (hf : Integrable f) (r : ℝ)
    {δ : ℝ} (hδ : 0 ≤ δ) (t : ℝ) :
    (cutExp r δ ⋆ f) t=Real.exp (-r*t)*
      ((∫ s in 0..t, Real.exp (r*s)*f s)-(∫ s in 0..t-δ, Real.exp (r*s)*f s)) := by
  rw [cutExp_convolution_formula r hδ]
  congr 1
  have hi := intervalIntegral.integral_add_adjacent_intervals
    (l1_weighted_intervalIntegrable hf r 0 (t-δ))
    (l1_weighted_intervalIntegrable hf r (t-δ) t)
  linarith

-- @paper-step thm:pid_two_rate_optimum/cut_exponential_continuity
theorem cutExp_convolution_continuous {f : ℝ → ℝ} (hf : Integrable f) (r : ℝ)
    {δ : ℝ} (hδ : 0 ≤ δ) : Continuous (cutExp r δ ⋆ f) := by
  have hp := intervalIntegral.continuous_primitive (l1_weighted_intervalIntegrable hf r) 0
  have he : cutExp r δ ⋆ f=(fun t => Real.exp (-r*t)*
      ((∫ s in 0..t, Real.exp (r*s)*f s)-(∫ s in 0..t-δ, Real.exp (r*s)*f s))) :=
    funext (cutExp_convolution_primitive hf r hδ)
  rw [he]
  exact (by fun_prop : Continuous (fun t : ℝ => Real.exp (-r*t))).mul
    (hp.sub (hp.comp (continuous_id.sub continuous_const)))

-- @paper-step thm:pid_two_rate_optimum/cut_exponential_absolute_continuity
theorem cutExp_convolution_ac {f : ℝ → ℝ} (hf : Integrable f) (r : ℝ)
    {δ : ℝ} (hδ : 0 ≤ δ) (a b : ℝ) :
    AbsolutelyContinuousOnInterval (cutExp r δ ⋆ f) a b := by
  have he : AbsolutelyContinuousOnInterval (fun t : ℝ => Real.exp (-r*t)) a b := by
    apply ContDiffOn.absolutelyContinuousOnInterval; fun_prop
  have hi := he.mul ((intervalPrimitive_ac (l1_weighted_intervalIntegrable hf r) 0 a b).sub
    (shiftedPrimitive_ac (l1_weighted_intervalIntegrable hf r) 0 δ a b))
  exact hi.congr (fun t _ => (cutExp_convolution_primitive hf r hδ t).symm)

end MIACE
