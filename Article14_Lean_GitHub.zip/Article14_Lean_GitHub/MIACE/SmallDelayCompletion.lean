import MIACE.SmallDelayContinuity

/-! Stage 19. The open inequalities are obtained from the concrete moment
functions. Normalization by the largest plant time constant means r_j≥1.
The index n=N-2 covers every cascade order N≥2. -/
namespace MIACE
open MeasureTheory Filter Set Polynomial
open scoped Topology

-- @paper-step cor:n_small_delay/strict_conditions_persist_at_zero_delay
theorem rational_small_delay_conditions (r : ℕ → ℝ) (n : ℕ) {α : ℝ}
    (hr : ∀ j≤n, 1≤r j) (hα : (∑ j∈Finset.range (n+1), 1/r j)<α) :
    ∃ δ₀ : ℝ, 0<δ₀ ∧ ∀ δ : ℝ, 0≤δ → δ<δ₀ →
      let U := (1+(∑ j∈Finset.range (n+1), 1/r j)+δ)/(1+α)
      0<rationalCascadeA r n δ U ∧ rationalCascadeA r n δ U<1 ∧
      CascadeParityTest (remainderJ r n δ) δ (rationalCascadeA r n δ U)
        ((-1 : ℝ)^(n+1)) ∧
      (rationalCascadeQ r n δ U).eval (-1)<0 := by
  let μ : ℝ := 1+∑ j∈Finset.range (n+1), 1/r j
  have hrp (j : ℕ) (hj : j≤n) : 0<r j := lt_of_lt_of_le zero_lt_one (hr j hj)
  have hs : 0≤∑ j∈Finset.range (n+1), 1/r j :=
    Finset.sum_nonneg (fun j hj => (one_div_pos.mpr (hrp j (by simpa using Nat.le_of_lt_succ (Finset.mem_range.mp hj)))).le)
  have hαp : 0<α := hs.trans_lt hα
  have hμ : 0<μ := by dsimp [μ]; linarith
  let U : ℝ → ℝ := fun δ => (μ+δ)/(1+α)
  let A : ℝ → ℝ := fun δ => rationalCascadeA r n δ (U δ)
  let Cc : ℝ → ℝ := fun δ => rationalCascadeC r n δ
  let Q : ℝ → ℝ := fun δ => (rationalCascadeQ r n δ (U δ)).eval (-1)
  have hU : Continuous U := by dsimp [U]; fun_prop
  have hA : Continuous A := (continuous_const.sub hU).add
    ((remainderMoment_continuous r n 1).const_mul _)
  have hC : Continuous Cc := continuous_const.sub ((remainderMoment_continuous r n 0).const_mul _)
  have hQ : Continuous Q := by
    simp only [Q,rationalCascadeQ,eval_sub,eval_mul,eval_add,eval_C,eval_X]
    change Continuous (fun δ => (remainderB r n).eval (-1)*(A δ*(-1)+Cc δ)-
      (remainderI r δ n).eval (-1))
    exact (((hA.mul_const _).add hC).const_mul _).sub (remainderI_eval_continuous r n (-1))
  have hU0 : 0<U 0 ∧ U 0<1 := by
    dsimp [U,μ]
    constructor
    · exact div_pos (by linarith) (by linarith)
    · apply (div_lt_one (by linarith)).mpr; linarith
  have hA0 : A 0=1-U 0 := by simp [A,rationalCascadeA,compactMoment]
  have hC0 : Cc 0=1 := by simp [Cc,rationalCascadeC,compactMoment]
  have ha0 : 0<A 0 := by rw [hA0]; linarith [hU0.2]
  have ha1 : A 0<1 := by rw [hA0]; linarith [hU0.1]
  have hQ0 : Q 0<0 := by
    have hB := remainderB_minus_one r n hr
    simp only [Q,rationalCascadeQ,eval_sub,eval_mul,eval_add,eval_C,eval_X]
    change (remainderB r n).eval (-1)*(A 0*(-1)+Cc 0)-(remainderI r 0 n).eval (-1)<0
    rw [hA0,hC0,remainderI_at_zero,eval_one]
    nlinarith [mul_le_mul_of_nonneg_left hU0.2.le hB.1]
  have hbase : ∀ᶠ δ in 𝓝 (0 : ℝ), 0<A δ ∧ A δ<1 ∧ Q δ<0 := by
    filter_upwards [hA.continuousAt.eventually (lt_mem_nhds ha0),
      hA.continuousAt.eventually (gt_mem_nhds ha1),
      hQ.continuousAt.eventually (gt_mem_nhds hQ0)] with δ h1 h2 h3
    exact ⟨h1,h2,h3⟩
  have hpar : ∀ᶠ δ in 𝓝 (0 : ℝ), 0≤δ →
      CascadeParityTest (remainderJ r n δ) δ (A δ) ((-1 : ℝ)^(n+1)) := by
    rcases neg_one_pow_eq_or ℝ (n+1) with he|he
    · let l : ℝ := 2/A 0
      have hl : 0<l := div_pos (by norm_num) ha0
      have he0 : 1-compactMoment (remainderJ r n 0) 0 0+
          compactExpMoment (remainderJ r n 0) 0 l<A 0*l := by
        simp only [compactMoment,compactExpMoment,intervalIntegral.integral_same,sub_zero,add_zero]
        dsimp [l]; field_simp; linarith
      have hc : Continuous (fun δ => A δ*l-(1-compactMoment (remainderJ r n δ) δ 0+
          compactExpMoment (remainderJ r n δ) δ l)) :=
        (hA.mul_const _).sub ((continuous_const.sub (remainderMoment_continuous r n 0)).add
          (remainderExpMoment_continuous r n l))
      have hp := hc.continuousAt.eventually (lt_mem_nhds (sub_pos.mpr he0))
      filter_upwards [hp] with δ hd _
      exact Or.inl ⟨he,l,hl,le_of_lt (by linarith)⟩
    · let G : ℝ := 4/A 0
      have hG : 0<G := div_pos (by norm_num) ha0
      have hc : Continuous (fun δ => 1-A δ-Real.exp (G*δ)*compactMoment (remainderJ r n δ) δ 1) :=
        (continuous_const.sub hA).sub ((Real.continuous_exp.comp (continuous_id.const_mul G)).mul
          (remainderMoment_continuous r n 1))
      have hz : 0<1-A 0-Real.exp (G*0)*compactMoment (remainderJ r n 0) 0 1 := by
        simpa [compactMoment] using sub_pos.mpr ha1
      filter_upwards [hbase,hA.continuousAt.eventually (lt_mem_nhds (show A 0/2<A 0 by linarith)),
        hC.continuousAt.eventually (gt_mem_nhds (show Cc 0<2 by rw [hC0]; norm_num)),
        hc.continuousAt.eventually (lt_mem_nhds hz)] with δ hb hhalf hC2 hmargin hδ
      have hj : 0≤compactMoment (remainderJ r n δ) δ 0 := by
        apply intervalIntegral.integral_nonneg hδ
        intro t ht
        simpa using remainderJ_nonneg r n (fun j hj => (hrp j hj).le) ht.2
      have hcval : Cc δ=1+compactMoment (remainderJ r n δ) δ 0 := by simp [Cc,rationalCascadeC,he]
      have hγ : 0≤(1+compactMoment (remainderJ r n δ) δ 0)/A δ := div_nonneg (by linarith) hb.1.le
      have hγG : (1+compactMoment (remainderJ r n δ) δ 0)/A δ≤G := by
        rw [← hcval,div_le_iff₀ hb.1]
        dsimp [G]
        rw [div_mul_eq_mul_div]
        apply (le_div_iff₀ ha0).mpr
        nlinarith
      have hm : 0≤compactMoment (remainderJ r n δ) δ 1 := by
        apply intervalIntegral.integral_nonneg hδ
        intro t ht
        exact mul_nonneg (pow_nonneg ht.1 _) (remainderJ_nonneg r n (fun j hj => (hrp j hj).le) ht.2)
      have hbound := compactTail_exp_bound (remainderJ_continuous r n δ) hδ hγ
        (fun t ht => remainderJ_nonneg r n (fun j hj => (hrp j hj).le) ht.2)
      have hex := mul_le_mul_of_nonneg_right (Real.exp_le_exp.mpr
        (mul_le_mul_of_nonneg_right hγG hδ)) hm
      exact Or.inr ⟨he,hbound.trans (hex.trans (by linarith))⟩
  have hall : ∀ᶠ δ in 𝓝 (0 : ℝ), 0≤δ →
      0<A δ ∧ A δ<1 ∧ CascadeParityTest (remainderJ r n δ) δ (A δ) ((-1 : ℝ)^(n+1)) ∧ Q δ<0 := by
    filter_upwards [hbase,hpar] with δ hb hp hd
    exact ⟨hb.1,hb.2.1,hp hd,hb.2.2⟩
  obtain ⟨d,hd,hsub⟩ := Metric.mem_nhds_iff.mp hall
  refine ⟨d,hd,?_⟩
  intro δ hδ hsmall
  apply hsub
  · simpa [Metric.mem_ball,Real.dist_eq,abs_of_nonneg hδ] using hsmall
  · exact hδ

-- @paper-step cor:n_small_delay/complete_small_delay_attainment_and_exact_order
theorem paper_small_delay_attainment (r : ℕ → ℝ) (n : ℕ) {α : ℝ}
    (hr : ∀ j≤n, 1≤r j) (hα : (∑ j∈Finset.range (n+1), 1/r j)<α) :
    ∃ δ₀ : ℝ, 0<δ₀ ∧ ∀ δ : ℝ, 0≤δ → δ<δ₀ →
      CascadeMinimalOrder r n δ ((1+(∑ j∈Finset.range (n+1), 1/r j)+δ)/(1+α)) ∧
      CascadeAttainment r n δ α := by
  have hrp (j : ℕ) (hj : j≤n) : 0<r j := lt_of_lt_of_le zero_lt_one (hr j hj)
  have hαp : 0<α := lt_of_le_of_lt
    (Finset.sum_nonneg (fun j hj => (one_div_pos.mpr (hrp j (by simpa using Nat.le_of_lt_succ (Finset.mem_range.mp hj)))).le)) hα
  obtain ⟨d,hd,hall⟩ := rational_small_delay_conditions r n hr hα
  refine ⟨d,hd,?_⟩
  intro δ hδ hsmall
  obtain ⟨ha,ha1,hpar,hQ⟩ := hall δ hδ hsmall
  exact ⟨rationalCascade_minimal_order r n δ _ (fun j hj => ne_of_gt (hrp j hj))
    (ne_of_gt ha) (ne_of_lt hQ),cascadeAttainment_of_conditions r n hrp hδ hαp ha ha1 hpar⟩

end MIACE
