import MIACE.Moments

/-! Integrating factors for the actual absolutely continuous first state.
The moment condition is characterized at the slowest first lag. Propagating
necessity backwards through a general cascade is a separate obligation. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:command_cone/first_state_integrating_factor
theorem response_weighted_balance {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (t : ℝ) (ht : 0 ≤ t) :
    Real.exp t*e t = 1-(∫ s in 0..t, Real.exp s*v s) := by
  have hexp : AbsolutelyContinuousOnInterval Real.exp 0 t := by
    apply ContDiffOn.absolutelyContinuousOnInterval
    fun_prop
  have hi := (h.ac t ht).integral_deriv_mul_eq_sub hexp
  have heq : (∫ s in 0..t, deriv e s*Real.exp s+e s*deriv Real.exp s) =
      -(∫ s in 0..t, Real.exp s*v s) := by
    rw [← intervalIntegral.integral_neg]
    apply intervalIntegral.integral_congr_ae
    filter_upwards [h.ode] with s hs hsmem
    rw [uIoc_of_le ht] at hsmem
    rw [hs hsmem.1,Real.deriv_exp]
    ring
  rw [heq,h.initial,Real.exp_zero] at hi
  nlinarith

-- @paper-step thm:command_cone/first_state
theorem response_first_state_formula {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (t : ℝ) (ht : 0 ≤ t) :
    1-e t = 1-Real.exp (-t)+Real.exp (-t)*(∫ s in 0..t, Real.exp s*v s) := by
  have hi := response_weighted_balance h t ht
  have hm := congrArg (fun x => Real.exp (-t)*x) hi
  have hcancel : Real.exp (-t)*Real.exp t = 1 := by rw [← Real.exp_add]; simp
  rw [← mul_assoc,hcancel,one_mul] at hm
  linarith

-- @paper-step thm:command_cone/first_state_moment_equivalence
theorem first_state_nonnegative_iff_moment {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (hn : ∀ᵐ t ∂halfLine, 0 ≤ v t)
    (hJ : Integrable (fun t => Real.exp t*v t) halfLine) :
    (∀ t : ℝ, 0 ≤ t → 0 ≤ e t) ↔ moment v ≤ 1 := by
  constructor
  · intro he
    have hl := intervalIntegral_tendsto_integral_Ioi 0 hJ tendsto_id
    apply le_of_tendsto hl
    filter_upwards [eventually_ge_atTop (0 : ℝ)] with t ht
    have hi := response_weighted_balance h t ht
    have hp : 0 ≤ Real.exp t*e t := mul_nonneg (Real.exp_nonneg _) (he t ht)
    change (∫ s in 0..t, Real.exp s*v s) ≤ 1
    linarith
  · intro hM t ht
    have hp : 0 ≤ᵐ[halfLine] (fun s => Real.exp s*v s) := by
      filter_upwards [hn] with s hs
      exact mul_nonneg (Real.exp_nonneg _) hs
    have hb : (∫ s in 0..t, Real.exp s*v s) ≤ moment v := by
      rw [intervalIntegral.integral_of_le ht]
      apply setIntegral_mono_set hJ hp
      exact Eventually.of_forall (fun s hs => hs.1)
    have hi := response_weighted_balance h t ht
    have hexp := Real.exp_pos t
    nlinarith

-- @paper-step thm:command_cone/first_order_cone
theorem first_order_command_cone {e v : ℝ → ℝ} (h : FirstOrderResponse e v)
    (hn : ∀ᵐ t ∂halfLine, 0 ≤ v t)
    (hJ : Integrable (fun t => Real.exp t*v t) halfLine) :
    ((∀ t : ℝ, 0 ≤ t → 1-e t ≤ 1) ↔ moment v ≤ 1) ∧
    (MonotoneOn (fun t => 1-e t) (Ici 0) ↔ moment v ≤ 1) := by
  have heq := first_state_nonnegative_iff_moment h hn hJ
  have hyp : (∀ t : ℝ, 0 ≤ t → 1-e t ≤ 1) ↔ (∀ t : ℝ, 0 ≤ t → 0 ≤ e t) := by
    constructor <;> intro hg t ht <;> have := hg t ht <;> linarith
  refine ⟨hyp.trans heq,?_⟩
  constructor
  · intro hm
    apply heq.mp
    intro t ht
    have hl : Tendsto (fun b => 1-e b) atTop (𝓝 1) := by
      simpa using tendsto_const_nhds.sub h.finalValue
    have hb : 1-e t ≤ 1 := by
      apply ge_of_tendsto hl
      filter_upwards [eventually_ge_atTop t] with b hb
      exact hm ht (ht.trans hb) hb
    linarith
  · intro hM
    have he : ∀ᵐ t ∂halfLine, 0 ≤ e t := by
      filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
      exact heq.mpr hM t (le_of_lt (show 0 < t from ht))
    exact response_output_monotone h he hn

end MIACE
