import MIACE.OrdinaryLag
import MIACE.LaplaceLinear
import MIACE.DelayTransforms

namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

noncomputable def cascadeTransfer (σ : ℕ → ℝ) : ℕ → ℝ → ℝ
  | 0 => fun _ => 1
  | n+1 => fun p => cascadeTransfer σ n p/(1+σ n*p)
noncomputable def cascadeMean (σ : ℕ → ℝ) (n : ℕ) : ℝ := ∑ j ∈ Finset.range n, σ j

-- @paper-step thm:complete_attainment/cascade_actual_DC_gain
theorem cascadeTransfer_zero (σ : ℕ → ℝ) (n : ℕ) : cascadeTransfer σ n 0=1 := by
  induction n with
  | zero => rfl
  | succ n ih => simp [cascadeTransfer,ih]

-- @paper-step thm:complete_attainment/cascade_actual_DC_derivative
theorem cascadeTransfer_derivative (σ : ℕ → ℝ) (n : ℕ) :
    HasDerivAt (cascadeTransfer σ n) (-cascadeMean σ n) 0 := by
  induction n with
  | zero => simpa [cascadeTransfer,cascadeMean] using hasDerivAt_const (0 : ℝ) (1 : ℝ)
  | succ n ih =>
    have hd := ih.div (((hasDerivAt_id (0 : ℝ)).const_mul (σ n)).const_add 1) (by norm_num)
    convert hd using 1
    · rfl
    · simp [cascadeTransfer_zero,cascadeMean,Finset.sum_range_succ]
      ring

-- @paper-step thm:complete_attainment/lag_transient_transform
theorem lag_transient_transform {σ p : ℝ} (hσ : 0<σ) (hp : 0≤p) :
    Integrable (fun t : ℝ => Real.exp (-t/σ)) halfLine ∧
      laplace (fun t : ℝ => Real.exp (-t/σ)) p=σ/(1+σ*p) := by
  have he : (fun t : ℝ => Real.exp (-t/σ)) =ᵐ[halfLine] (fun t => σ*lagKernel σ t) := by
    filter_upwards [ae_restrict_mem measurableSet_Ioi] with t ht
    simp only [lagKernel,indicator_of_mem (show t∈Ioi (0 : ℝ) from ht)]
    have hx : -t/σ=(-1/σ)*t := by ring
    rw [hx]; field_simp
  refine ⟨(((lagKernel_properties hσ).1.const_mul σ).mono_measure Measure.restrict_le_self).congr he.symm,?_⟩
  rw [laplace_congr_halfLine he,laplace_smul,lagKernel_laplace hσ hp]
  ring

-- @paper-step thm:complete_attainment/lag_deficit_transform
theorem lag_deficit_transform {u : ℝ → ℝ} (hu : LocallyIntegrable u volume)
    (he : Integrable (fun t => 1-u t) halfLine) {σ p : ℝ} (hσ : 0<σ) (hp : 0≤p) :
    laplace (fun t => 1-lag σ u t) p=(σ+laplace (fun t => 1-u t) p)/(1+σ*p) := by
  have hexp := lag_transient_transform hσ hp
  have hf : (fun t => 1-lag σ u t)=(fun t => Real.exp (-t/σ)+lag σ (fun s => 1-u s) t) :=
    funext (lag_deficit hu hσ)
  rw [hf,laplace]
  simp_rw [mul_add]
  rw [integral_add (laplace_integrable hexp.1 hp)
    (laplace_integrable (lag_integrable he hσ) hp)]
  change laplace (fun t : ℝ => Real.exp (-t/σ)) p+laplace (lag σ (fun s => 1-u s)) p=_
  rw [hexp.2,lag_laplace he hσ hp]
  ring

-- @paper-step thm:complete_attainment/cascade_actual_step_transform
theorem ordinaryCascade_transform {v : ℝ → ℝ} (hv : Integrable v)
    (σ : ℕ → ℝ) (n : ℕ) (hσ : ∀ j<n, 0<σ j) {p : ℝ} (hp : 0<p) :
    1/p-laplace (fun t => 1-ordinaryCascade σ (fun s => 1+v s) n t) p=
      cascadeTransfer σ n p*(1/p+laplace v p) := by
  have hu : LocallyIntegrable (fun t => 1+v t) volume :=
    (continuous_const : Continuous (fun _ : ℝ => (1 : ℝ))).locallyIntegrable.add hv.locallyIntegrable
  have he : Integrable (fun t => 1-(1+v t)) halfLine := by
    convert (hv.mono_measure Measure.restrict_le_self).neg using 1
    ext t; simp
  induction n with
  | zero =>
    have heq : (fun t => 1-ordinaryCascade σ (fun s => 1+v s) 0 t)=(fun t => (-1)*v t) := by
      ext t; simp [ordinaryCascade]
    rw [heq,laplace_smul,cascadeTransfer]
    ring
  | succ n ih =>
    have hn : ∀ j<n, 0<σ j := fun j hj => hσ j (by omega)
    have hpσ : 0<σ n := hσ n (by omega)
    have hi := ih hn
    rw [ordinaryCascade,lag_deficit_transform (ordinaryCascade_local hu σ n)
      (ordinaryCascade_deficit_integrable hu he σ n hn) hpσ hp.le,cascadeTransfer]
    have hden : 1+σ n*p≠0 := ne_of_gt (by positivity)
    field_simp [ne_of_gt hp,hden] at hi ⊢
    nlinarith

-- @paper-step thm:complete_attainment/ordinary_cascade_transfer_response
theorem ordinaryCascade_transfer_response {v : ℝ → ℝ} (hv : Integrable v)
    (σ : ℕ → ℝ) (n : ℕ) (hσ : ∀ j<n, 0<σ j) {δ : ℝ} (hδ : 0≤δ) :
    TransferResponse (delayedError δ (fun t => 1-ordinaryCascade σ (fun s => 1+v s) n t))
      v (cascadeTransfer σ n) δ := by
  have hu : LocallyIntegrable (fun t => 1+v t) volume :=
    (continuous_const : Continuous (fun _ : ℝ => (1 : ℝ))).locallyIntegrable.add hv.locallyIntegrable
  have he0 : Integrable (fun t => 1-(1+v t)) halfLine := by
    convert (hv.mono_measure Measure.restrict_le_self).neg using 1
    ext t; simp
  have he := ordinaryCascade_deficit_integrable hu he0 σ n hσ
  have hd := delayedError_integrable δ hδ he
  refine ⟨hd,hv.mono_measure Measure.restrict_le_self,?_⟩
  intro p hp
  have hc : Integrable (fun t : ℝ => Real.exp (-p*t)) halfLine :=
    integrableOn_exp_mul_Ioi (by linarith : -p<0) 0
  have hy : laplace (fun t => 1-delayedError δ (fun t => 1-ordinaryCascade σ (fun s => 1+v s) n t) t) p=
      1/p-laplace (delayedError δ (fun t => 1-ordinaryCascade σ (fun s => 1+v s) n t)) p := by
    unfold laplace
    simp_rw [mul_sub,mul_one]
    rw [integral_sub hc (laplace_integrable hd hp.le)]
    simpa [laplace] using congrArg (fun z : ℝ => z-laplace
      (delayedError δ (fun t => 1-ordinaryCascade σ (fun s => 1+v s) n t)) p) (laplace_step p hp)
  rw [hy,delayedError_laplace he hδ hp,(laplace_step_add (hv.mono_measure Measure.restrict_le_self) hp).2]
  have hh := ordinaryCascade_transform hv σ n hσ hp
  calc
    _ = Real.exp (-δ*p)*(1/p-laplace (fun t => 1-ordinaryCascade σ (fun s => 1+v s) n t) p) := by ring
    _ = _ := by rw [hh]; ring

end MIACE
