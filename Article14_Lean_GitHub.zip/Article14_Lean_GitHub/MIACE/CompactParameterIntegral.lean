import MIACE.ScalarLyapunovWindows

namespace MIACE
open MeasureTheory Set Filter
open scoped Topology

-- @paper-step lem:delayed_cancellation/differentiation_over_compact_history_interval
theorem compactParameterIntegral_deriv {F D : ℝ → ℝ → ℝ} {a b : ℝ}
    (hab : a≤b)
    (hF : ∀ t, ContinuousOn (F t) (Icc a b))
    (hD : ContinuousOn (fun p : ℝ × ℝ => D p.1 p.2) (univ ×ˢ Icc a b))
    (hd : ∀ t s, s∈Icc a b → HasDerivAt (fun u => F u s) (D t s) t)
    (t : ℝ) : HasDerivAt (fun u => ∫ s in a..b, F u s) (∫ s in a..b, D t s) t := by
  have hDc (u : ℝ) : ContinuousOn (D u) (Icc a b) :=
    hD.comp (continuous_const.prodMk continuous_id).continuousOn (fun s hs => ⟨mem_univ _,hs⟩)
  obtain ⟨K,hK⟩ := (isCompact_Icc.prod isCompact_Icc).exists_bound_of_continuousOn
    (hD.mono (show Icc (t-1) (t+1) ×ˢ Icc a b ⊆ univ ×ˢ Icc a b by
      intro p hp; exact ⟨mem_univ _,hp.2⟩))
  have hnh : Icc (t-1) (t+1)∈𝓝 t := Icc_mem_nhds (by linarith) (by linarith)
  have hh := hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (μ := volume.restrict (Icc a b)) (F := F) (F' := D) (bound := fun _ => K) hnh
    (Eventually.of_forall (fun u => (hF u).aestronglyMeasurable measurableSet_Icc))
    (hF t).integrableOn_Icc ((hDc t).aestronglyMeasurable measurableSet_Icc)
    (by filter_upwards [self_mem_ae_restrict measurableSet_Icc] with s hs u hu
        exact hK (u,s) ⟨hu,hs⟩)
    (continuousOn_const.integrableOn_Icc (μ := volume))
    (by filter_upwards [self_mem_ae_restrict measurableSet_Icc] with s hs u _
        exact hd u s hs)
  simpa only [integral_Icc_eq_integral_Ioc,intervalIntegral.integral_of_le hab] using hh.2

end MIACE
