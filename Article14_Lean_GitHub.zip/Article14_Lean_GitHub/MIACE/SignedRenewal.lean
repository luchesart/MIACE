import MIACE.PointwiseDecay

/-! Етап 11: резолвента за произволен знак на входа и на ядрото.
    Нормата на абсолютната стойност заменя положителната маса. Това е
    необходимо за начални истории, които не са положителни стъпкови входове. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:pid_two_rate_optimum/signed_neumann_solution
theorem signed_renewal_l1 {K : ℝ → ℝ} (hK : Integrable K)
    (hq : absArea K volume < 1) (g : RealL1) :
    let z := (∑' n : ℕ, (convOp hK)^n) g
    HasSum (fun n : ℕ => ((convOp hK)^n) g) z ∧
      z = g + convOp hK z ∧
      (∀ z' : RealL1, z' = g + convOp hK z' → z' = z) ∧
      ‖z‖ ≤ ‖g‖ / (1 - absArea K volume) := by
  dsimp only
  let T := convOp hK
  let R := ∑' n : ℕ, T^n
  obtain ⟨hs, hl, hr, hn⟩ := neumann_inverse_operator T (convOp_norm hK) hq
  refine ⟨hs.hasSum.map (ContinuousLinearMap.apply ℝ RealL1 g) (by fun_prop), ?_, ?_, ?_⟩
  · have hh := congrArg (fun A : RealL1 →L[ℝ] RealL1 => A g) hl
    change R g - T (R g) = g at hh
    exact sub_eq_iff_eq_add.mp hh
  · intro z hz
    have hh : (1-T) z = g := by change z-T z=g; exact sub_eq_iff_eq_add.mpr hz
    have he := congrArg (fun A : RealL1 →L[ℝ] RealL1 => A z) hr
    change R ((1-T) z)=z at he
    rw [hh] at he
    exact he.symm
  · calc
      ‖R g‖ ≤ ‖R‖ * ‖g‖ := R.le_opNorm g
      _ ≤ (1 / (1 - absArea K volume)) * ‖g‖ :=
        mul_le_mul_of_nonneg_right hn (norm_nonneg _)
      _ = _ := by ring

-- @paper-step thm:pid_two_rate_optimum/signed_weighted_resolvent
theorem signed_renewal_weighted {K : ℝ → ℝ} (hK : Integrable K)
    (hKc : Causal K) (hq : absArea K volume < 1)
    {η : ℝ} (hη : 0 ≤ η) (hKw : Integrable (expWeight η K))
    (hqw : absArea (expWeight η K) volume < 1)
    (g : RealL1) (hgc : Causal g) (hgw : Integrable (expWeight η g)) :
    let z := (∑' n : ℕ, (convOp hK)^n) g
    Causal z ∧ ∃ hz : Integrable (expWeight η z),
      HasSum (fun n : ℕ => ((convOp hKw)^n) (hgw.toL1 (expWeight η g)))
        (hz.toL1 (expWeight η z)) ∧
      (∫ t, |expWeight η z t|) ≤
        (∫ t, |expWeight η g t|) / (1 - absArea (expWeight η K) volume) := by
  dsimp only
  let gw := hgw.toL1 (expWeight η g)
  let Z := (∑' n : ℕ, (convOp hKw)^n) gw
  have hgwc : Causal gw := causal_congr (expWeight_causal η hgc) hgw.coeFn_toL1.symm
  obtain ⟨hs, he, _, hn⟩ := signed_renewal_l1 hKw hqw gw
  have hZc : Causal Z := causal_renewal_series hKw (expWeight_causal η hKc)
    ((convOp_norm hKw).trans_lt hqw) hgwc
  obtain ⟨hz, hze⟩ := weighted_renewal_identification hK hη hKw g _ Z hgw hZc he
    (signed_renewal_l1 hK hq g).2.2.1
  have heq : hz.toL1 _ = Z := Lp.ext (hz.coeFn_toL1.trans hze)
  refine ⟨causal_renewal_series hK hKc ((convOp_norm hK).trans_lt hq) hgc,
    hz, heq.symm ▸ hs, ?_⟩
  change ‖Z‖ ≤ ‖gw‖ / (1 - absArea (expWeight η K) volume) at hn
  rw [← heq] at hn
  simpa only [gw, L1.norm_of_fun_eq_integral_norm, Real.norm_eq_abs] using hn

-- @paper-step thm:pid_two_rate_optimum/signed_representative_equation
theorem signed_renewal_representative {K : ℝ → ℝ} (hK : Integrable K)
    (hq : absArea K volume < 1) (g : RealL1) :
    let z := (∑' n : ℕ, (convOp hK)^n) g
    (z : ℝ → ℝ) =ᵐ[volume] (fun t => g t + (K ⋆ (z : ℝ → ℝ)) t) := by
  dsimp only
  have he := (signed_renewal_l1 hK hq g).2.1
  have ha := Lp.coeFn_add g (convOp hK ((∑' n : ℕ, (convOp hK)^n) g))
  rw [← he] at ha
  filter_upwards [ha, convOp_coe hK ((∑' n : ℕ, (convOp hK)^n) g)] with t ht hc
  simpa only [Pi.add_apply, hc] using ht

-- @paper-step thm:pid_two_rate_optimum/signed_pointwise_resolvent_bound
theorem signed_renewal_pointwise_bound {K : ℝ → ℝ} (hK : Integrable K)
    (hKc : Causal K) (hq : absArea K volume < 1)
    {η C B : ℝ} (hη : 0 ≤ η) (hKw : Integrable (expWeight η K))
    (hqw : absArea (expWeight η K) volume < 1) (hC : 0 ≤ C)
    (hKb : ∀ t, |expWeight η K t| ≤ C)
    (g : RealL1) (hgc : Causal g) (hgw : Integrable (expWeight η g))
    (hgb : ∀ t, 0 ≤ t → |g t| ≤ B * Real.exp (-η*t)) :
    let z := (∑' n : ℕ, (convOp hK)^n) g
    ∀ t, 0 ≤ t → |g t + (K ⋆ (z : ℝ → ℝ)) t| ≤
      (B + C * ((∫ s, |expWeight η g s|) /
        (1 - absArea (expWeight η K) volume))) * Real.exp (-η*t) := by
  dsimp only
  obtain ⟨_, hz, _, hn⟩ := signed_renewal_weighted hK hKc hq hη hKw hqw g hgc hgw
  intro t ht
  have hc := convolution_weighted_pointwise_bound hC hKb hz t
  have hb := hgb t ht
  have hm := mul_le_mul_of_nonneg_left hn hC
  have hm' := mul_le_mul_of_nonneg_right hm (Real.exp_nonneg (-η*t))
  have ha := abs_add_le (g t) ((K ⋆ ((∑' n : ℕ, (convOp hK)^n) g : RealL1)) t)
  nlinarith

end MIACE
