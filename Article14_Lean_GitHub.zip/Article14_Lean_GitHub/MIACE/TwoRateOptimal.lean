import MIACE.TwoRateCertificate

/-! Площи и MIACE за построените редове при точната настройка i_c⋆.
    Идентификацията с физическия PID и неговата вътрешна устойчивост остават отделни. -/
set_option maxHeartbeats 1200000
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology Convolution

-- @paper-step thm:pid_two_rate_optimum/causal_absolute_area
theorem causal_absArea {f : ℝ → ℝ} (hc : Causal f) :
    absArea f volume=absArea f halfLine := by
  apply causal_integral_halfLine
  filter_upwards [hc] with t ht hn
  simp [ht hn]

-- @paper-step thm:pid_two_rate_optimum/optimal_integral_gain
theorem pid_optimal_gain {α δ : ℝ} (hα : 0 < α) (hδ : 0 ≤ δ) :
    0 < (1+1/α)/(1+δ) ∧
      1/((1+1/α)/(1+δ))=α*(1+δ)/(1+α) := by
  have ha : 1+α ≠ 0 := ne_of_gt (by positivity)
  have hd : 1+δ ≠ 0 := ne_of_gt (by positivity)
  constructor
  · positivity
  · field_simp
    <;> ring

-- @paper-step thm:pid_two_rate_optimum/ordinary_forcing_equation
theorem renewal_ordinary_equation {K f : ℝ → ℝ} (hK : Integrable K)
    (hKc : Causal K) (hf : Integrable (causalize f) volume) (z : RealL1) (hzc : Causal z)
    (hz : z=hf.toL1 (causalize f)+convOp hK z) :
    ∀ᵐ t, 0 ≤ t → z t=f t+(∫ s in 0..t, K (t-s)*z s) := by
  have hfc : Causal (hf.toL1 (causalize f)) :=
    causal_congr (causalize_causal f) hf.coeFn_toL1.symm
  have he := (renewal_equation_iff hK hKc _ z hfc hzc).mp hz
  filter_upwards [he,hf.coeFn_toL1] with t ht hft hpos
  rw [ht hpos,hft,causalize,indicator_of_mem (show t ∈ Ici (0 : ℝ) from hpos)]

-- @paper-step thm:pid_two_rate_optimum/optimal_signal_areas_and_MIACE
theorem twoRate_optimal_signals {α ρ ell l m δ : ℝ} (hα : 0 < α)
    (h : TwoRateData ((1+1/α)/(1+δ)) ρ ell l m δ) :
    ∃ e v : RealL1,
      0 ≤ e ∧ 0 ≤ v ∧ Causal e ∧ Causal v ∧
      (∀ᵐ t, 0 ≤ t → e t=twoRateG (twoRateA ρ l m) l m t+
        (∫ s in 0..t, twoRateK (twoRateA ρ l m) l m δ (t-s)*e s)) ∧
      (∀ᵐ t, 0 ≤ t → v t=twoRateR (twoRateA ρ l m) l m δ t+
        (∫ s in 0..t, twoRateK (twoRateA ρ l m) l m δ (t-s)*v s)) ∧
      absArea e halfLine=α*(1+δ)/(1+α) ∧
      absArea v halfLine=(1+δ)/(1+α) ∧
      miace α e v halfLine=(1+δ)*minimum α ∧
      (∃ η : ℝ, 0 < η ∧ η ≤ 1/2 ∧
        Integrable (expWeight η e) volume ∧ Integrable (expWeight η v) volume) ∧
      (∀ e' v' : ℝ → ℝ, Integrable e' halfLine → Integrable v' halfLine →
        (∫ t, e' t ∂halfLine)+(∫ t, v' t ∂halfLine)=1+δ →
          miace α e v halfLine ≤ miace α e' v' halfLine) := by
  let A := twoRateA ρ l m
  let hK := twoRateK_integrable A l m δ
  have hl : 0 < l := by linarith [h.lower_rate]
  have hm : 0 < m := by linarith [h.lower_rate,h.ordered_rates]
  let hG := twoRateG_integrable A hl hm
  let hR := twoRateR_integrable A δ hl hm
  let G := hG.toL1 (causalize (twoRateG A l m))
  let R := hR.toL1 (causalize (twoRateR A l m δ))
  let T := convOp hK
  let e := (∑' n : ℕ, T^n) G
  let v := (∑' n : ℕ, T^n) R
  obtain ⟨_,_,_,_,hen,hvn,hec,hvc,hee,hve,_,_,heint,hvint,hw⟩ := twoRate_signal_certificate h
  have hei : (∫ t, e t ∂halfLine)=1/((1+1/α)/(1+δ)) := by
    rw [← causal_integral_halfLine hec]
    exact heint
  have hvi : (∫ t, v t ∂halfLine)=1+δ-1/((1+1/α)/(1+δ)) := by
    rw [← causal_integral_halfLine hvc]
    exact hvint
  have hearea : absArea e halfLine=α*(1+δ)/(1+α) := by
    rw [← causal_absArea hec,positive_l1_area _ hen,heint,(pid_optimal_gain hα h.delay_nonneg).2]
  have hvarea : absArea v halfLine=(1+δ)/(1+α) := by
    rw [← causal_absArea hvc,positive_l1_area _ hvn,hvint,(pid_optimal_gain hα h.delay_nonneg).2]
    field_simp
    <;> ring
  have heI : Integrable (e : ℝ → ℝ) halfLine :=
    (L1.integrable_coeFn e).mono_measure Measure.restrict_le_self
  have hvI : Integrable (v : ℝ → ℝ) halfLine :=
    (L1.integrable_coeFn v).mono_measure Measure.restrict_le_self
  have hbal : (∫ t, e t ∂halfLine)+(∫ t, v t ∂halfLine)=1+δ := by rw [hei,hvi]; ring
  have hcost : miace α e v halfLine=(1+δ)*minimum α := by
    apply (signal_miace_equality_iff heI hvI α (1+δ) hα (by linarith [h.delay_nonneg]) hbal).mpr
    refine ⟨?_,?_,?_⟩
    · exact ((Lp.coeFn_nonneg _).mpr hen).filter_mono (ae_mono Measure.restrict_le_self)
    · exact ((Lp.coeFn_nonneg _).mpr hvn).filter_mono (ae_mono Measure.restrict_le_self)
    · rw [hearea,hvarea]; ring
  refine ⟨e,v,hen,hvn,hec,hvc,
    renewal_ordinary_equation hK (twoRateK_causal A l m δ) hG e hec hee,
    renewal_ordinary_equation hK (twoRateK_causal A l m δ) hR v hvc hve,
    hearea,hvarea,hcost,hw,?_⟩
  intro e' v' he' hv' hb
  rw [hcost]
  exact signal_miace_lower_bound he' hv' α (1+δ) hα (by linarith [h.delay_nonneg]) hb

end MIACE
