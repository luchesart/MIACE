import MIACE.GeneralCost

/-! Етап 6: оценката за MIACE се извежда от действителните L¹ разстояния.
Тя не предполага запазване на знаците при грешка в модела. -/
namespace MIACE
open MeasureTheory

-- @paper-step thm:complete_robust/weighted_triangle
theorem weighted_triangle (α a b c d : ℝ) (hα : 0 ≤ α) :
    Real.sqrt (a^2+α*b^2) ≤
      Real.sqrt (c^2+α*d^2) + Real.sqrt ((a-c)^2+α*(b-d)^2) := by
  let A := Real.sqrt (c^2+α*d^2)
  let B := Real.sqrt ((a-c)^2+α*(b-d)^2)
  have ha : 0 ≤ A := Real.sqrt_nonneg _
  have hb : 0 ≤ B := Real.sqrt_nonneg _
  have ha2 : A^2 = c^2+α*d^2 := Real.sq_sqrt (by positivity)
  have hb2 : B^2 = (a-c)^2+α*(b-d)^2 := Real.sq_sqrt (by positivity)
  have hcs : c*(a-c)+α*d*(b-d) ≤ A*B := by
    have hlag : (c*(a-c)+α*d*(b-d))^2 + α*(c*(b-d)-d*(a-c))^2 =
        (c^2+α*d^2)*((a-c)^2+α*(b-d)^2) := by ring
    have hn : 0 ≤ α*(c*(b-d)-d*(a-c))^2 := by positivity
    have hp : 0 ≤ A*B := mul_nonneg ha hb
    nlinarith [sq_nonneg (c*(a-c)+α*d*(b-d)+A*B)]
  apply (Real.sqrt_le_iff).2
  refine ⟨add_nonneg ha hb, ?_⟩
  nlinarith

-- @paper-step thm:complete_robust/weighted_reverse_triangle
theorem weighted_reverse_triangle (α a b c d : ℝ) (hα : 0 ≤ α) :
    |Real.sqrt (a^2+α*b^2) - Real.sqrt (c^2+α*d^2)| ≤
      Real.sqrt ((a-c)^2+α*(b-d)^2) := by
  have h₁ := weighted_triangle α a b c d hα
  have h₂ := weighted_triangle α c d a b hα
  have hh : (c-a)^2+α*(d-b)^2 = (a-c)^2+α*(b-d)^2 := by ring
  rw [hh] at h₂
  exact abs_le.mpr ⟨by linarith, by linarith⟩

-- @paper-step thm:complete_robust/absolute_area_lipschitz
theorem absArea_lipschitz {X : Type*} [MeasurableSpace X] {μ : Measure X}
    {f g : X → ℝ} (hf : Integrable f μ) (hg : Integrable g μ) :
    |absArea f μ - absArea g μ| ≤ absArea (fun t => f t-g t) μ := by
  unfold absArea
  rw [← integral_sub hf.abs hg.abs]
  exact abs_integral_le_integral_abs.trans
    (integral_mono (hf.abs.sub hg.abs).abs (hf.sub hg).abs
      (fun t => abs_abs_sub_abs_le_abs_sub (f t) (g t)))

-- @paper-step thm:complete_robust/miace_l1_lipschitz
theorem miace_lipschitz {e v e₀ v₀ : ℝ → ℝ} {μ : Measure ℝ}
    (he : Integrable e μ) (hv : Integrable v μ)
    (he₀ : Integrable e₀ μ) (hv₀ : Integrable v₀ μ)
    {α : ℝ} (hα : 0 ≤ α) :
    |miace α e v μ - miace α e₀ v₀ μ| ≤
      Real.sqrt ((absArea (fun t => e t-e₀ t) μ)^2 +
        α*(absArea (fun t => v t-v₀ t) μ)^2) := by
  apply (weighted_reverse_triangle α _ _ _ _ hα).trans
  apply Real.sqrt_le_sqrt
  have he' := absArea_lipschitz he he₀
  have hv' := absArea_lipschitz hv hv₀
  have heN : 0 ≤ absArea (fun t => e t-e₀ t) μ := integral_nonneg (fun _ => abs_nonneg _)
  have hvN : 0 ≤ absArea (fun t => v t-v₀ t) μ := integral_nonneg (fun _ => abs_nonneg _)
  have he2 := (sq_le_sq₀ (abs_nonneg _) heN).mpr he'
  have hv2 := (sq_le_sq₀ (abs_nonneg _) hvN).mpr hv'
  rw [sq_abs] at he2 hv2
  nlinarith [mul_le_mul_of_nonneg_left hv2 hα]

-- @paper-step thm:complete_robust/miace_delay_deviation
theorem robust_miace_bound {e v e₀ v₀ : ℝ → ℝ} {μ : Measure ℝ}
    (he : Integrable e μ) (hv : Integrable v μ)
    (he₀ : Integrable e₀ μ) (hv₀ : Integrable v₀ μ)
    {α f d q : ℝ} (hα : 0 ≤ α) (hf : 0 ≤ f) (hd : 0 ≤ d) (hq : q < 1)
    (heB : absArea (fun t => e t-e₀ t) μ ≤ 2*f*d/(1-q))
    (hvB : absArea (fun t => v t-v₀ t) μ ≤ f^2*d/(1-q)) :
    |miace α e v μ - miace α e₀ v₀ μ| ≤ f*d*Real.sqrt (4+α*f^2)/(1-q) := by
  apply (miace_lipschitz he hv he₀ hv₀ hα).trans
  have hden : 0 < 1-q := sub_pos.mpr hq
  have heN : 0 ≤ absArea (fun t => e t-e₀ t) μ := integral_nonneg (fun _ => abs_nonneg _)
  have hvN : 0 ≤ absArea (fun t => v t-v₀ t) μ := integral_nonneg (fun _ => abs_nonneg _)
  have he2 := (sq_le_sq₀ heN (by positivity)).mpr heB
  have hv2 := (sq_le_sq₀ hvN (by positivity)).mpr hvB
  have hs := Real.sq_sqrt (show 0 ≤ 4+α*f^2 by positivity)
  apply (Real.sqrt_le_iff).2
  refine ⟨by positivity, ?_⟩
  have hsum : (absArea (fun t => e t-e₀ t) μ)^2 + α*(absArea (fun t => v t-v₀ t) μ)^2 ≤
      (2*f*d/(1-q))^2+α*(f^2*d/(1-q))^2 := by nlinarith [mul_le_mul_of_nonneg_left hv2 hα]
  apply hsum.trans_eq
  simp only [div_pow,mul_pow,hs]
  ring

end MIACE
