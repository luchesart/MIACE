import MIACE.HistoryInput

/-! Етап 11: точният принос на историята в редуцираните физически уравнения.
    Не се диференцира историята. Формулата важи и на първия интервал [0,δ]. -/
namespace MIACE
open MeasureTheory Filter Set
open scoped Topology

-- @paper-step thm:pid_two_rate_optimum/reduced_command_with_transport_history
theorem pid_reduced_history_command (i ell δ : ℝ) {ρ : ℝ} (hρ : ρ ≠ 0)
    (y z ζ : ℝ → ℝ) {t : ℝ} (ht : 0≤t) :
    let w := fun s => pidHomogeneousCommand (i*(1+ell-ρ)) i
      (i*(ell-ρ)*(1-ρ)) ρ ![y s,z s,ζ s]
    w (t-δ)=historyInput δ w t-(i/ρ)*
      ((ell-ρ)*causalize (fun s => z s+(1-ρ)*ζ s) (t-δ)+
        ell*causalize (fun s => y s-z s) (t-δ)) := by
  dsimp only
  rw [historyInput_split δ (fun s => pidHomogeneousCommand (i*(1+ell-ρ)) i
    (i*(ell-ρ)*(1-ρ)) ρ ![y s,z s,ζ s]) ht]
  congr 1
  by_cases hs : 0≤t-δ
  · simp only [causalize,indicator_of_mem (show t-δ∈Ici (0 : ℝ) from hs)]
    simpa [pidReduce] using pid_command_reduced i ell hρ ![y (t-δ),z (t-δ),ζ (t-δ)]
  · simp [causalize,hs]

-- @paper-step thm:pid_two_rate_optimum/actual_reduced_ODE_with_history_forcing
theorem pid_reduced_history_derivatives {y z ζ : ℝ → ℝ} {i ρ ell δ t : ℝ}
    (hρ : ρ ≠ 0) (ht : 0≤t)
    (hy : HasDerivAt y (-y t+pidHomogeneousCommand (i*(1+ell-ρ)) i
      (i*(ell-ρ)*(1-ρ)) ρ ![y (t-δ),z (t-δ),ζ (t-δ)]) t)
    (hz : HasDerivAt z (-y t) t)
    (hζ : HasDerivAt ζ ((-y t-ζ t)/ρ) t) :
    let a := fun s => z s+(1-ρ)*ζ s
    let b := fun s => y s-z s
    let w := fun s => pidHomogeneousCommand (i*(1+ell-ρ)) i
      (i*(ell-ρ)*(1-ρ)) ρ ![y s,z s,ζ s]
    HasDerivAt a (-(a t+b t)/ρ) t ∧
      HasDerivAt b (historyInput δ w t-(i/ρ)*
        ((ell-ρ)*causalize a (t-δ)+ell*causalize b (t-δ))) t ∧
      HasDerivAt z (-z t-b t) t := by
  dsimp only
  obtain ⟨ha,_,hc⟩ := pid_reduced_derivatives hρ hy hz hζ
  refine ⟨ha,?_,hc⟩
  have hb := hy.sub hz
  have he := pid_reduced_history_command i ell δ hρ y z ζ ht
  dsimp only at he
  convert hb using 1
  rw [he]
  ring

end MIACE
